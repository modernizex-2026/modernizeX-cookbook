      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Receiving detail
      *----------------------------------------------------------------
       FD  RCVDF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RCVDF".
       01  RD-REC.
           02  RD-NO               PIC 9(10).
           02  RD-LINE             PIC 9(3).
           02  RD-PO               PIC 9(10).
           02  RD-PO-LINE          PIC 9(3).
           02  RD-PROD             PIC 9(8).
           02  RD-WHSE             PIC 9(3).
           02  RD-QTY              PIC S9(9) COMP-3.
           02  RD-UNIT-COST        PIC S9(9)V9(2) COMP-3.
           02  RD-AMOUNT           PIC S9(11) COMP-3.
           02  FILLER              PIC X(10).
