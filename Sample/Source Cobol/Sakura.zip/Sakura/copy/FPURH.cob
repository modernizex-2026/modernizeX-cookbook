      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Purchase header
      *----------------------------------------------------------------
       FD  PURHF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "PURHF".
       01  VH-REC.
           02  VH-NO               PIC 9(10).
           02  VH-DATE             PIC 9(8).
           02  VH-SUPP             PIC 9(6).
           02  VH-RECV-NO          PIC 9(10).
           02  VH-CLOSE-YM         PIC 9(6).
           02  VH-TAX-TYPE         PIC 9(1).
           02  VH-AMOUNT           PIC S9(11) COMP-3.
           02  VH-TAX-AMOUNT       PIC S9(11) COMP-3.
           02  VH-TOTAL            PIC S9(11) COMP-3.
           02  VH-STATUS           PIC 9(1).
           02  VH-KIND             PIC 9(1).
           02  VH-LINES            PIC 9(3).
           02  VH-REMARK           PIC X(40).
           02  VH-ADD-DATE         PIC 9(8).
           02  VH-ADD-USER         PIC 9(6).
           02  VH-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
