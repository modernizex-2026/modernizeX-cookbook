      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Sales order header
      *----------------------------------------------------------------
           SELECT  ORDHF        ASSIGN  TO  ORDHF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            OH-NO
                   ALTERNATE RECORD KEY  OH-CUST
                                         OH-DATE  WITH DUPLICATES
                   ALTERNATE RECORD KEY  OH-DATE
                                         OH-NO
                   FILE STATUS       FSTS.
