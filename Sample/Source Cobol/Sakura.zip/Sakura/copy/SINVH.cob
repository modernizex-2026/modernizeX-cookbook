      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Sales invoice header
      *----------------------------------------------------------------
           SELECT  INVHF        ASSIGN  TO  INVHF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            IH-NO
                   ALTERNATE RECORD KEY  IH-CUST
                                         IH-DATE  WITH DUPLICATES
                   ALTERNATE RECORD KEY  IH-DATE
                                         IH-NO
                   FILE STATUS       FSTS.
