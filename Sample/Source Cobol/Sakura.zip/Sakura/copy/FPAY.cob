      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Payment
      *----------------------------------------------------------------
       FD  PAYF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "PAYF".
       01  PY-REC.
           02  PY-NO               PIC 9(10).
           02  PY-DATE             PIC 9(8).
           02  PY-SUPP             PIC 9(6).
           02  PY-METHOD           PIC 9(1).
           02  PY-AMOUNT           PIC S9(11) COMP-3.
           02  PY-BANK-CODE        PIC 9(4).
           02  PY-CLOSE-YM         PIC 9(6).
           02  PY-STATUS           PIC 9(1).
           02  PY-REMARK           PIC X(30).
           02  PY-ADD-DATE         PIC 9(8).
           02  PY-ADD-USER         PIC 9(6).
           02  PY-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(10).
