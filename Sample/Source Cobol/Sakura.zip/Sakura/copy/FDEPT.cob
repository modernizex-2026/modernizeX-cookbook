      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Department master
      *----------------------------------------------------------------
       FD  DEPTF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "DEPTF".
       01  DP-REC.
           02  DP-CODE             PIC 9(4).
           02  DP-NAME             PIC X(30).
           02  DP-PARENT           PIC 9(4).
           02  DP-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
