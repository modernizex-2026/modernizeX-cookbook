      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : AP ledger
      *----------------------------------------------------------------
       FD  APLF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "APLF".
       01  PL-REC.
           02  PL-SEQ              PIC 9(10).
           02  PL-SUPP             PIC 9(6).
           02  PL-DATE             PIC 9(8).
           02  PL-CLOSE-YM         PIC 9(6).
           02  PL-KIND             PIC 9(1).
           02  PL-REF-TYPE         PIC 9(2).
           02  PL-REF-NO           PIC 9(10).
           02  PL-DEBIT            PIC S9(11) COMP-3.
           02  PL-CREDIT           PIC S9(11) COMP-3.
           02  PL-BALANCE          PIC S9(11) COMP-3.
           02  PL-REMARK           PIC X(30).
           02  PL-USER             PIC 9(6).
           02  FILLER              PIC X(10).
