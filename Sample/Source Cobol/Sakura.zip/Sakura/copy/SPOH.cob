      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Purchase order header
      *----------------------------------------------------------------
           SELECT  POHF         ASSIGN  TO  POHF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            PH-NO
                   ALTERNATE RECORD KEY  PH-SUPP
                                         PH-DATE  WITH DUPLICATES
                   FILE STATUS       FSTS.
