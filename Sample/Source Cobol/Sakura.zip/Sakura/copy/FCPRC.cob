      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Customer price master
      *----------------------------------------------------------------
       FD  CPRCF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "CPRCF".
       01  CP-REC.
           02  CP-CUST             PIC 9(6).
           02  CP-PROD             PIC 9(8).
           02  CP-PRICE            PIC S9(9)V9(2) COMP-3.
           02  CP-START-DATE       PIC 9(8).
           02  CP-END-DATE         PIC 9(8).
           02  CP-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(10).
