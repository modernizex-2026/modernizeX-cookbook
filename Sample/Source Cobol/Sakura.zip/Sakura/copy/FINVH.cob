      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Sales invoice header
      *----------------------------------------------------------------
       FD  INVHF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "INVHF".
       01  IH-REC.
           02  IH-NO               PIC 9(10).
           02  IH-DATE             PIC 9(8).
           02  IH-CUST             PIC 9(6).
           02  IH-STAFF            PIC 9(4).
           02  IH-SHIP-NO          PIC 9(10).
           02  IH-CLOSE-YM         PIC 9(6).
           02  IH-TAX-TYPE         PIC 9(1).
           02  IH-AMOUNT           PIC S9(11) COMP-3.
           02  IH-TAX-AMOUNT       PIC S9(11) COMP-3.
           02  IH-TOTAL            PIC S9(11) COMP-3.
           02  IH-COST-TOTAL       PIC S9(11) COMP-3.
           02  IH-STATUS           PIC 9(1).
           02  IH-KIND             PIC 9(1).
           02  IH-LINES            PIC 9(3).
           02  IH-REMARK           PIC X(40).
           02  IH-ADD-DATE         PIC 9(8).
           02  IH-ADD-USER         PIC 9(6).
           02  IH-UPD-DATE         PIC 9(8).
           02  IH-UPD-USER         PIC 9(6).
           02  IH-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
