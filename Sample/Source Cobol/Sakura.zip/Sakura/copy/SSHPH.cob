      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Shipment header
      *----------------------------------------------------------------
           SELECT  SHPHF        ASSIGN  TO  SHPHF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            XH-NO
                   ALTERNATE RECORD KEY  XH-ORDER  WITH DUPLICATES
                   ALTERNATE RECORD KEY  XH-DATE
                                         XH-NO
                   FILE STATUS       FSTS.
