      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Cash receipt
      *----------------------------------------------------------------
       FD  RCPTF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RCPTF".
       01  RE-REC.
           02  RE-NO               PIC 9(10).
           02  RE-DATE             PIC 9(8).
           02  RE-CUST             PIC 9(6).
           02  RE-METHOD           PIC 9(1).
           02  RE-AMOUNT           PIC S9(11) COMP-3.
           02  RE-BANK-CODE        PIC 9(4).
           02  RE-CLOSE-YM         PIC 9(6).
           02  RE-STATUS           PIC 9(1).
           02  RE-REMARK           PIC X(30).
           02  RE-ADD-DATE         PIC 9(8).
           02  RE-ADD-USER         PIC 9(6).
           02  RE-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(10).
