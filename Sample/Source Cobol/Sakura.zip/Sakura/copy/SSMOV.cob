      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Stock movement history
      *----------------------------------------------------------------
           SELECT  SMOVF        ASSIGN  TO  SMOVF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            SM-SEQ
                   ALTERNATE RECORD KEY  SM-PROD
                                         SM-DATE  WITH DUPLICATES
                   FILE STATUS       FSTS.
