      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Purchase detail
      *----------------------------------------------------------------
           SELECT  PURDF        ASSIGN  TO  PURDF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            VD-NO
                                         VD-LINE
                   FILE STATUS       FSTS.
