      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Warehouse master
      *----------------------------------------------------------------
       FD  WHSEF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "WHSEF".
       01  WH-REC.
           02  WH-CODE             PIC 9(3).
           02  WH-NAME             PIC X(30).
           02  WH-ZIP              PIC X(8).
           02  WH-ADDR             PIC X(40).
           02  WH-TEL              PIC X(15).
           02  WH-TYPE             PIC 9(1).
           02  WH-MANAGER          PIC 9(4).
           02  WH-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
