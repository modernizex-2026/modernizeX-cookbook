      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Supplier master
      *----------------------------------------------------------------
           SELECT  SUPPF        ASSIGN  TO  SUPPF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            SP-CODE
                   ALTERNATE RECORD KEY  SP-NAME  WITH DUPLICATES
                   FILE STATUS       FSTS.
