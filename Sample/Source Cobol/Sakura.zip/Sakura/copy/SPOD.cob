      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Purchase order detail
      *----------------------------------------------------------------
           SELECT  PODF         ASSIGN  TO  PODF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            PD-NO
                                         PD-LINE
                   FILE STATUS       FSTS.
