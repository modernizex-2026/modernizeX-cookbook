      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  common screen footer / PF-key guide
      *  Program MOVEs the guide text to WK-FKEY-LINE then DISPLAY.
      *----------------------------------------------------------------
       01  DS-FOOTER.
           02  LINE 23 COLUMN 1  PIC X(78) FROM WK-RULE COLOR CYAN.
           02  LINE 24 COLUMN 2  PIC X(78) FROM WK-FKEY-LINE COLOR CYAN.
