      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Sales order detail
      *----------------------------------------------------------------
       FD  ORDDF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "ORDDF".
       01  OD-REC.
           02  OD-NO               PIC 9(10).
           02  OD-LINE             PIC 9(3).
           02  OD-PROD             PIC 9(8).
           02  OD-WHSE             PIC 9(3).
           02  OD-QTY              PIC S9(9) COMP-3.
           02  OD-UNIT-PRICE       PIC S9(9)V9(2) COMP-3.
           02  OD-AMOUNT           PIC S9(11) COMP-3.
           02  OD-TAX-CATEGORY     PIC 9(1).
           02  OD-SHIPPED-QTY      PIC S9(9) COMP-3.
           02  OD-ALLOC-QTY        PIC S9(9) COMP-3.
           02  OD-DUE-DATE         PIC 9(8).
           02  OD-STATUS           PIC 9(1).
           02  OD-REMARK           PIC X(30).
           02  FILLER              PIC X(10).
