      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Tax rate master
      *----------------------------------------------------------------
       FD  TAXF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "TAXF".
       01  TX-REC.
           02  TX-CODE             PIC 9(1).
           02  TX-START-DATE       PIC 9(8).
           02  TX-RATE             PIC S9(2)V9(3) COMP-3.
           02  TX-NAME             PIC X(20).
           02  FILLER              PIC X(10).
