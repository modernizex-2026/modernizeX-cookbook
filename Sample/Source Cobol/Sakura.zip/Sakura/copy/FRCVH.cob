      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Receiving header
      *----------------------------------------------------------------
       FD  RCVHF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RCVHF".
       01  RH-REC.
           02  RH-NO               PIC 9(10).
           02  RH-DATE             PIC 9(8).
           02  RH-PO               PIC 9(10).
           02  RH-SUPP             PIC 9(6).
           02  RH-WHSE             PIC 9(3).
           02  RH-STATUS           PIC 9(1).
           02  RH-LINES            PIC 9(3).
           02  RH-REMARK           PIC X(40).
           02  RH-ADD-DATE         PIC 9(8).
           02  RH-ADD-USER         PIC 9(6).
           02  RH-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
