      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Category master
      *----------------------------------------------------------------
       FD  CATGF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "CATGF".
       01  CT-REC.
           02  CT-CODE             PIC 9(4).
           02  CT-NAME             PIC X(30).
           02  CT-PARENT           PIC 9(4).
           02  CT-LEVEL            PIC 9(1).
           02  CT-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
