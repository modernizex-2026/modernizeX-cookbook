      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : AR ledger
      *----------------------------------------------------------------
           SELECT  ARLF         ASSIGN  TO  ARLF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            AL-SEQ
                   ALTERNATE RECORD KEY  AL-CUST
                                         AL-DATE  WITH DUPLICATES
                   ALTERNATE RECORD KEY  AL-CUST
                                         AL-CLOSE-YM  WITH DUPLICATES
                   FILE STATUS       FSTS.
