      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Message master
      *----------------------------------------------------------------
       FD  MSGF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "MSGF".
       01  MG-REC.
           02  MG-CODE             PIC X(6).
           02  MG-TEXT             PIC X(60).
           02  FILLER              PIC X(10).
