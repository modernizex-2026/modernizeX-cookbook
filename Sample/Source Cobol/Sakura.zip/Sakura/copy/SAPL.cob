      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : AP ledger
      *----------------------------------------------------------------
           SELECT  APLF         ASSIGN  TO  APLF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            PL-SEQ
                   ALTERNATE RECORD KEY  PL-SUPP
                                         PL-DATE  WITH DUPLICATES
                   FILE STATUS       FSTS.
