      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  common-subroutine linkage layouts
      *  Copied into WORKING-STORAGE by callers; pass the relevant 01.
      *----------------------------------------------------------------
      *----- NUMGEN : assign next document number ----------------------
       01  KNUM.
           02  KNUM-KEY            PIC X(8).
           02  KNUM-NUMBER         PIC 9(10).
           02  KNUM-STATUS         PIC X(2).
      *----- DATEUT : date utilities -----------------------------------
       01  KDATE.
           02  KD-FUNC             PIC X(4).
           02  KD-DATE1            PIC 9(8).
           02  KD-DATE2            PIC 9(8).
           02  KD-DAYS             PIC S9(7).
           02  KD-WEEKDAY          PIC 9(1).
           02  KD-STATUS           PIC X(2).
      *----- GETMSG : fetch message text -------------------------------
       01  KMSG.
           02  KM-CODE             PIC X(6).
           02  KM-TEXT             PIC X(60).
           02  KM-STATUS           PIC X(2).
      *----- TAXCAL : tax computation ----------------------------------
       01  KTAX.
           02  KT-CATEGORY         PIC 9(1).
           02  KT-TAX-TYPE         PIC 9(1).
           02  KT-ROUND            PIC 9(1).
           02  KT-DATE             PIC 9(8).
           02  KT-AMOUNT           PIC S9(11)     COMP-3.
           02  KT-TAX              PIC S9(11)     COMP-3.
           02  KT-NET              PIC S9(11)     COMP-3.
           02  KT-GROSS            PIC S9(11)     COMP-3.
           02  KT-RATE             PIC S9(2)V9(3) COMP-3.
           02  KT-STATUS           PIC X(2).
      *----- CHKLOG : login validation ---------------------------------
       01  KLOGIN.
           02  KL-LOGIN            PIC X(12).
           02  KL-PASSWORD         PIC X(16).
           02  KL-USER-CODE        PIC 9(6).
           02  KL-USER-NAME        PIC X(30).
           02  KL-ROLE             PIC 9(1).
           02  KL-AUTH             PIC X(5).
           02  KL-STATUS           PIC X(2).
      *----- ABORTX : abend logger -------------------------------------
       01  KABEND.
           02  KA-PROGID           PIC X(6).
           02  KA-FILE             PIC X(8).
           02  KA-FSTS             PIC X(2).
           02  KA-MSGCODE          PIC X(6).
           02  KA-DETAIL           PIC X(40).
