      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : System control
      *----------------------------------------------------------------
       FD  SYSCF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "SYSCF".
       01  SY-REC.
           02  SY-KEY              PIC 9(1).
           02  SY-COMPANY-NAME     PIC X(40).
           02  SY-COMPANY-ZIP      PIC X(8).
           02  SY-COMPANY-ADDR     PIC X(40).
           02  SY-COMPANY-TEL      PIC X(15).
           02  SY-FISCAL-START     PIC 9(2).
           02  SY-CURR-YM          PIC 9(6).
           02  SY-LAST-DAY-CLOSE   PIC 9(8).
           02  SY-LAST-MON-CLOSE   PIC 9(6).
           02  SY-TAX-DFLT-RATE    PIC S9(2)V9(3) COMP-3.
           02  SY-DEC-ROUND        PIC 9(1).
           02  FILLER              PIC X(30).
