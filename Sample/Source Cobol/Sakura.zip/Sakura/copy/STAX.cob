      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Tax rate master
      *----------------------------------------------------------------
           SELECT  TAXF         ASSIGN  TO  TAXF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            TX-CODE
                                         TX-START-DATE
                   FILE STATUS       FSTS.
