      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Supplier master
      *----------------------------------------------------------------
       FD  SUPPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "SUPPF".
       01  SP-REC.
           02  SP-CODE             PIC 9(6).
           02  SP-NAME             PIC X(40).
           02  SP-KANA             PIC X(40).
           02  SP-ZIP              PIC X(8).
           02  SP-ADDR1            PIC X(40).
           02  SP-ADDR2            PIC X(40).
           02  SP-TEL              PIC X(15).
           02  SP-FAX              PIC X(15).
           02  SP-CLOSE-DAY        PIC 9(2).
           02  SP-PAY-MONTH        PIC 9(1).
           02  SP-PAY-DAY          PIC 9(2).
           02  SP-PAY-METHOD       PIC 9(1).
           02  SP-TAX-TYPE         PIC 9(1).
           02  SP-BALANCE          PIC S9(11) COMP-3.
           02  SP-BANK-CODE        PIC 9(4).
           02  SP-BANK-ACCT        PIC X(20).
           02  SP-ADD-DATE         PIC 9(8).
           02  SP-ADD-USER         PIC 9(6).
           02  SP-UPD-DATE         PIC 9(8).
           02  SP-UPD-USER         PIC 9(6).
           02  SP-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
