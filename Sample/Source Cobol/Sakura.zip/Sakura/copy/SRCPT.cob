      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Cash receipt
      *----------------------------------------------------------------
           SELECT  RCPTF        ASSIGN  TO  RCPTF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            RE-NO
                   ALTERNATE RECORD KEY  RE-CUST
                                         RE-DATE  WITH DUPLICATES
                   FILE STATUS       FSTS.
