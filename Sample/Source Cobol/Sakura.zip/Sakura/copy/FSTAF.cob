      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Staff master
      *----------------------------------------------------------------
       FD  STAFF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "STAFF".
       01  SF-REC.
           02  SF-CODE             PIC 9(4).
           02  SF-NAME             PIC X(30).
           02  SF-KANA             PIC X(30).
           02  SF-DEPT             PIC 9(4).
           02  SF-TEL              PIC X(15).
           02  SF-EMAIL            PIC X(40).
           02  SF-TITLE            PIC X(20).
           02  SF-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
