      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Warehouse master
      *----------------------------------------------------------------
           SELECT  WHSEF        ASSIGN  TO  WHSEF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            WH-CODE
                   FILE STATUS       FSTS.
