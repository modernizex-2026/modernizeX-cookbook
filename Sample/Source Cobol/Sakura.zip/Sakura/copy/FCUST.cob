      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Customer master
      *----------------------------------------------------------------
       FD  CUSTF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "CUSTF".
       01  CU-REC.
           02  CU-CODE             PIC 9(6).
           02  CU-NAME             PIC X(40).
           02  CU-KANA             PIC X(40).
           02  CU-ZIP              PIC X(8).
           02  CU-ADDR1            PIC X(40).
           02  CU-ADDR2            PIC X(40).
           02  CU-TEL              PIC X(15).
           02  CU-FAX              PIC X(15).
           02  CU-REGION           PIC 9(3).
           02  CU-STAFF            PIC 9(4).
           02  CU-CLOSE-DAY        PIC 9(2).
           02  CU-PAY-MONTH        PIC 9(1).
           02  CU-PAY-DAY          PIC 9(2).
           02  CU-PAY-METHOD       PIC 9(1).
           02  CU-TAX-TYPE         PIC 9(1).
           02  CU-TAX-ROUND        PIC 9(1).
           02  CU-CREDIT-LIMIT     PIC S9(11) COMP-3.
           02  CU-BALANCE          PIC S9(11) COMP-3.
           02  CU-PRICE-RANK       PIC 9(1).
           02  CU-BANK-CODE        PIC 9(4).
           02  CU-BANK-ACCT        PIC X(20).
           02  CU-START-DATE       PIC 9(8).
           02  CU-ADD-DATE         PIC 9(8).
           02  CU-ADD-USER         PIC 9(6).
           02  CU-UPD-DATE         PIC 9(8).
           02  CU-UPD-USER         PIC 9(6).
           02  CU-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
