      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  message / confirm work area
      *----------------------------------------------------------------
       01  WK-MSG.
           02  WK-MSG-CODE         PIC X(6)  VALUE SPACE.
           02  WK-MSG-TEXT         PIC X(60) VALUE SPACE.
           02  WK-CONFIRM          PIC X(1)  VALUE SPACE.
             88  CONFIRM-YES                 VALUE "Y" "y".
             88  CONFIRM-NO                  VALUE "N" "n".
