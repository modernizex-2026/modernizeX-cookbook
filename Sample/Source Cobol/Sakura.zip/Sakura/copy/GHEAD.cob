      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  common screen header (SCREEN SECTION)
      *  Program MOVEs WK-PROGID / WK-TITLE / WK-SYSYMD then DISPLAY.
      *----------------------------------------------------------------
       SD  SAKSCR END STATUS IS ESTS.
       01  DS-HEADER.
           02  CLEAR SCREEN.
           02  LINE 1.
             03  COLUMN 3   PIC X(6)  FROM WK-PROGID  COLOR CYAN.
             03  COLUMN 22  PIC X(36) FROM WK-TITLE
                            REVERSE   COLOR YELLOW.
             03  COLUMN 65  PIC 9999B99B99 FROM WK-SYSYMD COLOR WHITE.
           02  LINE 2 COLUMN 1  PIC X(78) FROM WK-RULE COLOR CYAN.
