      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Shipment header
      *----------------------------------------------------------------
       FD  SHPHF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "SHPHF".
       01  XH-REC.
           02  XH-NO               PIC 9(10).
           02  XH-DATE             PIC 9(8).
           02  XH-ORDER            PIC 9(10).
           02  XH-CUST             PIC 9(6).
           02  XH-WHSE             PIC 9(3).
           02  XH-STAFF            PIC 9(4).
           02  XH-STATUS           PIC 9(1).
           02  XH-LINES            PIC 9(3).
           02  XH-REMARK           PIC X(40).
           02  XH-ADD-DATE         PIC 9(8).
           02  XH-ADD-USER         PIC 9(6).
           02  XH-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
