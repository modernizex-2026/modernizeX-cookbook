      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Sales invoice detail
      *----------------------------------------------------------------
       FD  INVDF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "INVDF".
       01  ID-REC.
           02  ID-NO               PIC 9(10).
           02  ID-LINE             PIC 9(3).
           02  ID-PROD             PIC 9(8).
           02  ID-WHSE             PIC 9(3).
           02  ID-QTY              PIC S9(9) COMP-3.
           02  ID-UNIT-PRICE       PIC S9(9)V9(2) COMP-3.
           02  ID-AMOUNT           PIC S9(11) COMP-3.
           02  ID-UNIT-COST        PIC S9(9)V9(2) COMP-3.
           02  ID-COST-AMOUNT      PIC S9(11) COMP-3.
           02  ID-TAX-CATEGORY     PIC 9(1).
           02  ID-REMARK           PIC X(30).
           02  FILLER              PIC X(10).
