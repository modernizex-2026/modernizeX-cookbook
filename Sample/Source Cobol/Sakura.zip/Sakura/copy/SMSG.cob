      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Message master
      *----------------------------------------------------------------
           SELECT  MSGF         ASSIGN  TO  MSGF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            MG-CODE
                   FILE STATUS       FSTS.
