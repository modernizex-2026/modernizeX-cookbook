      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Number control
      *----------------------------------------------------------------
       FD  NUMCF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "NUMCF".
       01  NM-REC.
           02  NM-KEY              PIC X(8).
           02  NM-PREFIX           PIC X(2).
           02  NM-CURRENT          PIC 9(10).
           02  NM-WIDTH            PIC 9(2).
           02  FILLER              PIC X(10).
