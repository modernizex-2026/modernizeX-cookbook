      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Customer master
      *----------------------------------------------------------------
           SELECT  CUSTF        ASSIGN  TO  CUSTF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            CU-CODE
                   ALTERNATE RECORD KEY  CU-NAME  WITH DUPLICATES
                   ALTERNATE RECORD KEY  CU-REGION
                                         CU-CODE
                   FILE STATUS       FSTS.
