      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : System control
      *----------------------------------------------------------------
           SELECT  SYSCF        ASSIGN  TO  SYSCF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            SY-KEY
                   FILE STATUS       FSTS.
