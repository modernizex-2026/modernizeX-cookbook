      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  message line (SCREEN SECTION, line 22)
      *  Program MOVEs message text to WK-MSG-LINE then DISPLAY DS-MSG.
      *----------------------------------------------------------------
       01  DS-MSG.
           02  LINE 22 COLUMN 2  PIC X(78) FROM WK-MSG-LINE COLOR RED.
