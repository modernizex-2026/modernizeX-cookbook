      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Category master
      *----------------------------------------------------------------
           SELECT  CATGF        ASSIGN  TO  CATGF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            CT-CODE
                   FILE STATUS       FSTS.
