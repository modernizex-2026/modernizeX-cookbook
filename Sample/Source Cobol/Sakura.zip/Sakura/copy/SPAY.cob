      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Payment
      *----------------------------------------------------------------
           SELECT  PAYF         ASSIGN  TO  PAYF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            PY-NO
                   ALTERNATE RECORD KEY  PY-SUPP
                                         PY-DATE  WITH DUPLICATES
                   FILE STATUS       FSTS.
