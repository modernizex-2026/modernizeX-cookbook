      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Shipment detail
      *----------------------------------------------------------------
           SELECT  SHPDF        ASSIGN  TO  SHPDF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            XD-NO
                                         XD-LINE
                   FILE STATUS       FSTS.
