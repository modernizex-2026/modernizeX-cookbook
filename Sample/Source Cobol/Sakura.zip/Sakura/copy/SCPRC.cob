      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Customer price master
      *----------------------------------------------------------------
           SELECT  CPRCF        ASSIGN  TO  CPRCF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            CP-CUST
                                         CP-PROD
                   FILE STATUS       FSTS.
