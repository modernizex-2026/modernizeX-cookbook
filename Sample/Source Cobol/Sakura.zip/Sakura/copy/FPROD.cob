      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Product master
      *----------------------------------------------------------------
       FD  PRODF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "PRODF".
       01  PR-REC.
           02  PR-CODE             PIC 9(8).
           02  PR-NAME             PIC X(40).
           02  PR-KANA             PIC X(40).
           02  PR-SPEC             PIC X(30).
           02  PR-CATEGORY         PIC 9(4).
           02  PR-BARCODE          PIC X(13).
           02  PR-UNIT             PIC X(6).
           02  PR-STD-COST         PIC S9(9)V9(2) COMP-3.
           02  PR-LAST-COST        PIC S9(9)V9(2) COMP-3.
           02  PR-LIST-PRICE       PIC S9(9)V9(2) COMP-3.
           02  PR-PRICE-TBL        OCCURS 5.
             03  PR-RANK-PRICE     PIC S9(9)V9(2) COMP-3.
           02  PR-TAX-CATEGORY     PIC 9(1).
           02  PR-SAFETY-STOCK     PIC S9(9) COMP-3.
           02  PR-REORDER-POINT    PIC S9(9) COMP-3.
           02  PR-REORDER-QTY      PIC S9(9) COMP-3.
           02  PR-LEAD-DAYS        PIC 9(3).
           02  PR-DFLT-SUPP        PIC 9(6).
           02  PR-DFLT-WHSE        PIC 9(3).
           02  PR-STOCK-MNG        PIC 9(1).
           02  PR-ADD-DATE         PIC 9(8).
           02  PR-ADD-USER         PIC 9(6).
           02  PR-UPD-DATE         PIC 9(8).
           02  PR-UPD-USER         PIC 9(6).
           02  PR-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
