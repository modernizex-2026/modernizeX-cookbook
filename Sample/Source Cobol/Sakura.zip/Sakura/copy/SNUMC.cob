      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Number control
      *----------------------------------------------------------------
           SELECT  NUMCF        ASSIGN  TO  NUMCF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            NM-KEY
                   FILE STATUS       FSTS.
