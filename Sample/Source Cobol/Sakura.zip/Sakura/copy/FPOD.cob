      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Purchase order detail
      *----------------------------------------------------------------
       FD  PODF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "PODF".
       01  PD-REC.
           02  PD-NO               PIC 9(10).
           02  PD-LINE             PIC 9(3).
           02  PD-PROD             PIC 9(8).
           02  PD-WHSE             PIC 9(3).
           02  PD-QTY              PIC S9(9) COMP-3.
           02  PD-UNIT-COST        PIC S9(9)V9(2) COMP-3.
           02  PD-AMOUNT           PIC S9(11) COMP-3.
           02  PD-RECV-QTY         PIC S9(9) COMP-3.
           02  PD-DUE-DATE         PIC 9(8).
           02  PD-STATUS           PIC 9(1).
           02  FILLER              PIC X(10).
