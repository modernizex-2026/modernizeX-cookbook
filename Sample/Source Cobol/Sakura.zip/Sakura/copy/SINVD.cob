      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Sales invoice detail
      *----------------------------------------------------------------
           SELECT  INVDF        ASSIGN  TO  INVDF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            ID-NO
                                         ID-LINE
                   FILE STATUS       FSTS.
