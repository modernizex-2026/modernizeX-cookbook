      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Region master
      *----------------------------------------------------------------
           SELECT  REGNF        ASSIGN  TO  REGNF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            RG-CODE
                   FILE STATUS       FSTS.
