      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Bank master
      *----------------------------------------------------------------
           SELECT  BANKF        ASSIGN  TO  BANKF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            BK-CODE
                   FILE STATUS       FSTS.
