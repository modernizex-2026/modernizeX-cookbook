      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Stock balance
      *----------------------------------------------------------------
           SELECT  STOKF        ASSIGN  TO  STOKF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            SK-PROD
                                         SK-WHSE
                   ALTERNATE RECORD KEY  SK-WHSE
                                         SK-PROD
                   FILE STATUS       FSTS.
