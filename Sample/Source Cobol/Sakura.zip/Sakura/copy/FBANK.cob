      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Bank master
      *----------------------------------------------------------------
       FD  BANKF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "BANKF".
       01  BK-REC.
           02  BK-CODE             PIC 9(4).
           02  BK-NAME             PIC X(30).
           02  BK-BRANCH           PIC X(30).
           02  BK-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
