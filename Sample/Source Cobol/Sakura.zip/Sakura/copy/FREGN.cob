      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Region master
      *----------------------------------------------------------------
       FD  REGNF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "REGNF".
       01  RG-REC.
           02  RG-CODE             PIC 9(3).
           02  RG-NAME             PIC X(30).
           02  RG-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
