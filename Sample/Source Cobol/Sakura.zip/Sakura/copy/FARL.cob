      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : AR ledger
      *----------------------------------------------------------------
       FD  ARLF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "ARLF".
       01  AL-REC.
           02  AL-SEQ              PIC 9(10).
           02  AL-CUST             PIC 9(6).
           02  AL-DATE             PIC 9(8).
           02  AL-CLOSE-YM         PIC 9(6).
           02  AL-KIND             PIC 9(1).
           02  AL-REF-TYPE         PIC 9(2).
           02  AL-REF-NO           PIC 9(10).
           02  AL-DEBIT            PIC S9(11) COMP-3.
           02  AL-CREDIT           PIC S9(11) COMP-3.
           02  AL-BALANCE          PIC S9(11) COMP-3.
           02  AL-REMARK           PIC X(30).
           02  AL-USER             PIC 9(6).
           02  FILLER              PIC X(10).
