      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Stock movement history
      *----------------------------------------------------------------
       FD  SMOVF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "SMOVF".
       01  SM-REC.
           02  SM-SEQ              PIC 9(10).
           02  SM-DATE             PIC 9(8).
           02  SM-PROD             PIC 9(8).
           02  SM-WHSE             PIC 9(3).
           02  SM-KIND             PIC 9(2).
           02  SM-QTY              PIC S9(9) COMP-3.
           02  SM-UNIT-COST        PIC S9(9)V9(2) COMP-3.
           02  SM-BAL-AFTER        PIC S9(9) COMP-3.
           02  SM-REF-TYPE         PIC 9(2).
           02  SM-REF-NO           PIC 9(10).
           02  SM-USER             PIC 9(6).
           02  FILLER              PIC X(10).
