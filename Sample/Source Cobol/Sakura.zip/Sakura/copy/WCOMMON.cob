      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  common WORKING-STORAGE block
      *  Copied into WORKING-STORAGE by every program.
      *----------------------------------------------------------------
       01  FSTS                    PIC X(2)  VALUE "00".
      *  NOTE: ESTS (screen end-status) is auto-defined by the
      *  END STATUS IS ESTS clause on the SD in GHEAD; do NOT
      *  declare it here (NEC COBOL85 would report H0009).
      *----- program identity / screen header work ---------------------
       01  WK-PROGID               PIC X(6)  VALUE SPACE.
       01  WK-TITLE                PIC X(36) VALUE SPACE.
       01  WK-RULE                 PIC X(78) VALUE ALL "-".
       01  WK-FKEY-LINE            PIC X(78) VALUE SPACE.
       01  WK-MSG-LINE             PIC X(78) VALUE SPACE.
      *----- control switches ------------------------------------------
       01  WK-SWITCHES.
           02  END-FLG             PIC 9(1)  VALUE 0.
             88  END-YES                     VALUE 1.
           02  ERR-FLG             PIC 9(1)  VALUE 0.
             88  ERR-YES                     VALUE 1.
           02  FOUND-FLG           PIC 9(1)  VALUE 0.
             88  FOUND-YES                   VALUE 1.
           02  EOF-FLG             PIC 9(1)  VALUE 0.
             88  EOF-YES                     VALUE 1.
           02  MODE-FLG            PIC 9(1)  VALUE 0.
             88  MODE-ADD                    VALUE 1.
             88  MODE-CHG                    VALUE 2.
             88  MODE-DEL                    VALUE 3.
             88  MODE-INQ                    VALUE 4.
      *----- function key end-status values ----------------------------
       01  WK-FKEYS.
           02  FK-ENTER            PIC 9(2)  VALUE 0.
           02  FK-HELP             PIC 9(2)  VALUE 1.
           02  FK-END              PIC 9(2)  VALUE 3.
           02  FK-CLEAR            PIC 9(2)  VALUE 4.
           02  FK-PREV             PIC 9(2)  VALUE 5.
           02  FK-NEXT             PIC 9(2)  VALUE 6.
           02  FK-DELETE           PIC 9(2)  VALUE 9.
           02  FK-BACK             PIC 9(2)  VALUE 12.
      *----- system date / time ----------------------------------------
       01  WK-DATE-TIME.
           02  WK-SYSDATE          PIC 9(8)  VALUE 0.
           02  WK-SYSTIME          PIC 9(8)  VALUE 0.
           02  WK-SYSYMD           PIC 9(8)  VALUE 0.
           02  WK-SYS-YM           PIC 9(6)  VALUE 0.
      *----- generic work / counters -----------------------------------
       01  WK-WORK.
           02  WK-CNT              PIC 9(7)  VALUE 0.
           02  WK-CNT2             PIC 9(7)  VALUE 0.
           02  WK-IDX              PIC 9(3)  VALUE 0.
           02  WK-IDX2             PIC 9(3)  VALUE 0.
           02  WK-LINE             PIC 9(2)  VALUE 0.
           02  WK-PAGE             PIC 9(4)  VALUE 0.
           02  WK-AMT              PIC S9(13)V9(2) VALUE 0.
           02  WK-AMT2             PIC S9(13)V9(2) VALUE 0.
           02  WK-QTY              PIC S9(11)      VALUE 0.
           02  WK-RATE             PIC S9(2)V9(3)  VALUE 0.
      *----- current operator ------------------------------------------
       01  WK-OPER.
           02  WK-USER-CODE        PIC 9(6)  VALUE 0.
           02  WK-USER-NAME        PIC X(30) VALUE SPACE.
           02  WK-USER-ROLE        PIC 9(1)  VALUE 0.
           02  WK-USER-AUTH        PIC X(5)  VALUE SPACE.
      *----- numeric edit fields (for screen / report edit) ------------
       01  WK-EDIT.
           02  WK-ED-AMT           PIC ---,---,---,--9.
           02  WK-ED-AMT2          PIC ---,---,---,--9.99.
           02  WK-ED-QTY           PIC ----,---,--9.
           02  WK-ED-PRICE         PIC ---,---,--9.99.
           02  WK-ED-RATE          PIC Z9.999.
           02  WK-ED-DATE          PIC 9999/99/99.
           02  WK-ED-NO            PIC ZZZZZZZZZ9.
