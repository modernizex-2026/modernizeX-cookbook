      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Product master
      *----------------------------------------------------------------
           SELECT  PRODF        ASSIGN  TO  PRODF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            PR-CODE
                   ALTERNATE RECORD KEY  PR-NAME  WITH DUPLICATES
                   ALTERNATE RECORD KEY  PR-CATEGORY
                                         PR-CODE
                   ALTERNATE RECORD KEY  PR-BARCODE  WITH DUPLICATES
                   FILE STATUS       FSTS.
