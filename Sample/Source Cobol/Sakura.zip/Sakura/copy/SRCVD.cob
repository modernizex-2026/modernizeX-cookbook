      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Receiving detail
      *----------------------------------------------------------------
           SELECT  RCVDF        ASSIGN  TO  RCVDF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            RD-NO
                                         RD-LINE
                   FILE STATUS       FSTS.
