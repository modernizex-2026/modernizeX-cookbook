      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Purchase detail
      *----------------------------------------------------------------
       FD  PURDF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "PURDF".
       01  VD-REC.
           02  VD-NO               PIC 9(10).
           02  VD-LINE             PIC 9(3).
           02  VD-PROD             PIC 9(8).
           02  VD-WHSE             PIC 9(3).
           02  VD-QTY              PIC S9(9) COMP-3.
           02  VD-UNIT-COST        PIC S9(9)V9(2) COMP-3.
           02  VD-AMOUNT           PIC S9(11) COMP-3.
           02  VD-TAX-CATEGORY     PIC 9(1).
           02  FILLER              PIC X(10).
