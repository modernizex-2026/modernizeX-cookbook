      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Staff master
      *----------------------------------------------------------------
           SELECT  STAFF        ASSIGN  TO  STAFF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            SF-CODE
                   ALTERNATE RECORD KEY  SF-DEPT
                                         SF-CODE
                   FILE STATUS       FSTS.
