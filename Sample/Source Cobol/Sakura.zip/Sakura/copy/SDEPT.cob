      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Department master
      *----------------------------------------------------------------
           SELECT  DEPTF        ASSIGN  TO  DEPTF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            DP-CODE
                   FILE STATUS       FSTS.
