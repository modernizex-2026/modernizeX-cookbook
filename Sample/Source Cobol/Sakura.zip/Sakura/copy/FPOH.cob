      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Purchase order header
      *----------------------------------------------------------------
       FD  POHF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "POHF".
       01  PH-REC.
           02  PH-NO               PIC 9(10).
           02  PH-DATE             PIC 9(8).
           02  PH-SUPP             PIC 9(6).
           02  PH-WHSE             PIC 9(3).
           02  PH-STAFF            PIC 9(4).
           02  PH-DUE-DATE         PIC 9(8).
           02  PH-TAX-TYPE         PIC 9(1).
           02  PH-AMOUNT           PIC S9(11) COMP-3.
           02  PH-TAX-AMOUNT       PIC S9(11) COMP-3.
           02  PH-TOTAL            PIC S9(11) COMP-3.
           02  PH-STATUS           PIC 9(1).
           02  PH-LINES            PIC 9(3).
           02  PH-REMARK           PIC X(40).
           02  PH-ADD-DATE         PIC 9(8).
           02  PH-ADD-USER         PIC 9(6).
           02  PH-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
