      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Stock balance
      *----------------------------------------------------------------
       FD  STOKF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "STOKF".
       01  SK-REC.
           02  SK-PROD             PIC 9(8).
           02  SK-WHSE             PIC 9(3).
           02  SK-ONHAND           PIC S9(9) COMP-3.
           02  SK-ALLOCATED        PIC S9(9) COMP-3.
           02  SK-ON-ORDER         PIC S9(9) COMP-3.
           02  SK-AVG-COST         PIC S9(9)V9(2) COMP-3.
           02  SK-LAST-IN-DATE     PIC 9(8).
           02  SK-LAST-OUT-DATE    PIC 9(8).
           02  SK-YTD-IN           PIC S9(11) COMP-3.
           02  SK-YTD-OUT          PIC S9(11) COMP-3.
           02  SK-LOCATION         PIC X(10).
           02  FILLER              PIC X(10).
