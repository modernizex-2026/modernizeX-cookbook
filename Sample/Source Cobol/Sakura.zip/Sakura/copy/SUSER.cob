      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : User master
      *----------------------------------------------------------------
           SELECT  USERF        ASSIGN  TO  USERF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            US-CODE
                   ALTERNATE RECORD KEY  US-LOGIN
                   FILE STATUS       FSTS.
