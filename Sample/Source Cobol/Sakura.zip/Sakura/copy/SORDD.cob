      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Sales order detail
      *----------------------------------------------------------------
           SELECT  ORDDF        ASSIGN  TO  ORDDF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            OD-NO
                                         OD-LINE
                   FILE STATUS       FSTS.
