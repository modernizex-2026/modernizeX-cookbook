      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Sales order header
      *----------------------------------------------------------------
       FD  ORDHF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "ORDHF".
       01  OH-REC.
           02  OH-NO               PIC 9(10).
           02  OH-DATE             PIC 9(8).
           02  OH-CUST             PIC 9(6).
           02  OH-STAFF            PIC 9(4).
           02  OH-WHSE             PIC 9(3).
           02  OH-DUE-DATE         PIC 9(8).
           02  OH-CUST-PO          PIC X(20).
           02  OH-TAX-TYPE         PIC 9(1).
           02  OH-AMOUNT           PIC S9(11) COMP-3.
           02  OH-TAX-AMOUNT       PIC S9(11) COMP-3.
           02  OH-TOTAL            PIC S9(11) COMP-3.
           02  OH-STATUS           PIC 9(1).
           02  OH-LINES            PIC 9(3).
           02  OH-REMARK           PIC X(40).
           02  OH-ADD-DATE         PIC 9(8).
           02  OH-ADD-USER         PIC 9(6).
           02  OH-UPD-DATE         PIC 9(8).
           02  OH-UPD-USER         PIC 9(6).
           02  OH-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
