      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : Shipment detail
      *----------------------------------------------------------------
       FD  SHPDF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "SHPDF".
       01  XD-REC.
           02  XD-NO               PIC 9(10).
           02  XD-LINE             PIC 9(3).
           02  XD-ORDER            PIC 9(10).
           02  XD-ORDER-LINE       PIC 9(3).
           02  XD-PROD             PIC 9(8).
           02  XD-WHSE             PIC 9(3).
           02  XD-QTY              PIC S9(9) COMP-3.
           02  XD-UNIT-PRICE       PIC S9(9)V9(2) COMP-3.
           02  XD-AMOUNT           PIC S9(11) COMP-3.
           02  XD-UNIT-COST        PIC S9(9)V9(2) COMP-3.
           02  FILLER              PIC X(10).
