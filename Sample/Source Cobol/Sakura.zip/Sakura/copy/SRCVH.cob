      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Receiving header
      *----------------------------------------------------------------
           SELECT  RCVHF        ASSIGN  TO  RCVHF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            RH-NO
                   ALTERNATE RECORD KEY  RH-PO  WITH DUPLICATES
                   ALTERNATE RECORD KEY  RH-DATE
                                         RH-NO
                   FILE STATUS       FSTS.
