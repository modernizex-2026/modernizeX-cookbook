      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  FD/RECORD : User master
      *----------------------------------------------------------------
       FD  USERF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "USERF".
       01  US-REC.
           02  US-CODE             PIC 9(6).
           02  US-LOGIN            PIC X(12).
           02  US-PASSWORD         PIC X(16).
           02  US-NAME             PIC X(30).
           02  US-ROLE             PIC 9(1).
           02  US-AUTH-MASTER      PIC 9(1).
           02  US-AUTH-ORDER       PIC 9(1).
           02  US-AUTH-SALES       PIC 9(1).
           02  US-AUTH-PURCH       PIC 9(1).
           02  US-AUTH-CLOSE       PIC 9(1).
           02  US-LAST-LOGIN       PIC 9(8).
           02  US-DEL-FLAG         PIC 9(1).
           02  FILLER              PIC X(20).
