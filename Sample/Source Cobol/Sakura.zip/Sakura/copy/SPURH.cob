      *----------------------------------------------------------------
      *  SAKURA-SMS  copybook  -  SELECT : Purchase header
      *----------------------------------------------------------------
           SELECT  PURHF        ASSIGN  TO  PURHF-RDB
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY            VH-NO
                   ALTERNATE RECORD KEY  VH-SUPP
                                         VH-DATE  WITH DUPLICATES
                   FILE STATUS       FSTS.
