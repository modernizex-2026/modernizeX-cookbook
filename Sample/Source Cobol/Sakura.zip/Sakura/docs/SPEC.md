# SAKURA Sales Management System — Build Specification (single source of truth)

> This document is the authoritative contract for every program and copybook in
> the system. All field names, PICTURE clauses, record keys, copybook names,
> program IDs and common-subroutine linkage layouts are defined HERE. Any program
> that reads/writes a file, or CALLs a common subroutine, MUST use exactly the
> names defined in this document. Do not invent field names.

SAKURA-SMS is an original wholesale / distribution **sales management system**
written from scratch. It is NOT derived from any existing product's source code;
it only implements the standard, non-copyrightable business domain (customers,
products, orders, shipments, sales, purchasing, inventory, receivables,
payables). Comments and identifiers are English/ASCII.

---

## 1. Dialect & source format

* Target compiler: **NEC COBOL85 Pro Ver8.5** with **WEBCOBOL Ver2.0** screen
  extensions (`cbl85pro`).
* **Fixed format.** Columns 1–6 = sequence area, leave **blank**. Column 7 =
  indicator (`*` comment, `/` page-eject, `-` continuation). Area A starts at
  **column 8**, Area B at **column 12**. Keep code within column 72.
* Encoding **ASCII** (plain English). No Shift-JIS.
* One logical construct per copybook file; copybook file name = `COPY` name +
  `.cob`, stored in `copy/`.
* Every program: `IDENTIFICATION`, `ENVIRONMENT`, `DATA`, `PROCEDURE` divisions.
* `SOURCE-COMPUTER` / `OBJECT-COMPUTER` = `SAKURA-HOST`.

### Standard program header banner (top of every program)
```
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : <ID>  -  <one-line title>                        *
      *  FUNCTION : <what it does>                                   *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
```

---

## 2. Naming conventions

### Program IDs (6 chars: `<SS><NNNN>`)
| Subsystem | Prefix | Meaning              |
|-----------|--------|----------------------|
| Menu      | `MENU` | menu / navigation    |
| Master    | `MS`   | master maintenance   |
| Order     | `OE`   | sales order          |
| Shipping  | `SH`   | shipping / picking   |
| Sales     | `SL`   | sales / invoicing    |
| Purchase  | `PU`   | purchasing           |
| Receiving | `RC`   | goods receiving      |
| Inventory | `IV`   | inventory            |
| Receivable| `AR`   | accounts receivable  |
| Payable   | `AP`   | accounts payable     |
| Report    | `RP`   | reports              |
| Batch     | `BT`   | batch / closing      |
| Subroutine| (name) | see §6               |

### Copybook names
* `S<name>` — SELECT clause(s) for a file, e.g. `SCUST`.
* `F<name>` — FD + 01 record layout for a file, e.g. `FCUST`.
* `W<name>` — WORKING-STORAGE common block, e.g. `WCOMMON`.
* `G<name>` — SCREEN SECTION common block, e.g. `GHEAD`.
* `K<name>` — constants / linkage layouts for CALLs, e.g. `KLINK`.

### Field name prefixes (record fields = `<PFX>-<field>`)
| Entity                 | File id  | Copybook  | Fld pfx |
|------------------------|----------|-----------|---------|
| Customer master        | CUSTF    | FCUST     | CU      |
| Supplier master        | SUPPF    | FSUPP     | SP      |
| Product master         | PRODF    | FPROD     | PR      |
| Warehouse master       | WHSEF    | FWHSE     | WH      |
| Staff (sales rep)      | STAFF    | FSTAF     | SF      |
| Category master        | CATGF    | FCATG     | CT      |
| Customer price master  | CPRCF    | FCPRC     | CP      |
| Department master      | DEPTF    | FDEPT     | DP      |
| Tax rate master        | TAXF     | FTAX      | TX      |
| Bank master            | BANKF    | FBANK     | BK      |
| Region master          | REGNF    | FREGN     | RG      |
| User master            | USERF    | FUSER     | US      |
| Message master         | MSGF     | FMSG      | MG      |
| System control         | SYSCF    | FSYSC     | SY      |
| Number control (採番)  | NUMCF    | FNUMC     | NM      |
| Stock balance          | STOKF    | FSTOK     | SK      |
| Stock movement history | SMOVF    | FSMOV     | SM      |
| Order header           | ORDHF    | FORDH     | OH      |
| Order detail           | ORDDF    | FORDD     | OD      |
| Shipment header        | SHPHF    | FSHPH     | XH      |
| Shipment detail        | SHPDF    | FSHPD     | XD      |
| Invoice(sales) header  | INVHF    | FINVH     | IH      |
| Invoice(sales) detail  | INVDF    | FINVD     | ID      |
| Purchase-order header  | POHF     | FPOH      | PH      |
| Purchase-order detail  | PODF     | FPOD      | PD      |
| Receiving header       | RCVHF    | FRCVH     | RH      |
| Receiving detail       | RCVDF    | FRCVD     | RD      |
| Purchase header        | PURHF    | FPURH     | VH      |
| Purchase detail        | PURDF    | FPURD     | VD      |
| AR ledger              | ARLF     | FARL      | AL      |
| AP ledger              | APLF     | FAPL      | PL      |
| Cash receipt           | RCPTF    | FRCPT     | RE      |
| Payment                | PAYF     | FPAY      | PY      |

---

## 3. Standard technical conventions

### File assignment (ISAM)
Every indexed file is assigned to a physical file in `data/`. Pattern in the
SELECT copybook:
```
           SELECT  CUSTF        ASSIGN  TO  "data/CUSTF.DAT"
                   ORGANIZATION      INDEXED
                   ACCESS MODE       DYNAMIC
                   RECORD KEY        CU-CODE
                   ALTERNATE RECORD KEY CU-NAME  WITH DUPLICATES
                   FILE STATUS       FSTS.
```
FD copybook:
```
       FD  CUSTF
           LABEL RECORD STANDARD.
       01  CU-REC.
           02  ...
```
* Use `FILE STATUS FSTS` for **every** file (FSTS is defined once in `WCOMMON`).
* Every I-O program includes `I-O-CONTROL. APPLY SHARED-MODE ON <file>...` for
  files opened `I-O` in an on-line program.

### File status handling
After every OPEN / READ / WRITE / REWRITE / DELETE / START, test `FSTS`:
* `"00"` success. `"02"` duplicate alt-key (info). `"10"` at end.
* `"23"` record not found. `"22"` duplicate key on write.
* Anything else unexpected → `PERFORM ABEND-RTN` (see §5).

### Packed decimals & signs
* Money / amounts: `PIC S9(11)V9(2) USAGE COMP-3` (unit price `S9(9)V9(2)`).
* Quantities: `PIC S9(9) COMP-3` (or `S9(9)V9(2)` where fractional units).
* Counts / small: `PIC S9(7) COMP-3`.
* Codes / dates stored as `9(n)` DISPLAY (dates `9(8)` = YYYYMMDD).
* Flags: `PIC 9(1)`.

### Dates
* Stored `PIC 9(8)` = `YYYYMMDD`. System date obtained via
  `CALL "DATEUT"` (§6) or `ACCEPT WK-SYSDATE FROM DATE` then century-adjust.

### Function keys (WEBCOBOL end-status ESTS values)
Defined in `WCOMMON` as `ESTS PIC 9(2)`. Standard mapping used across all
on-line programs:
| Key      | ESTS value | Meaning                    |
|----------|-----------|-----------------------------|
| Enter    | `00`      | confirm / next              |
| PF1      | `01`      | help                        |
| PF3      | `03`      | end / return to menu        |
| PF4      | `04`      | clear / cancel current      |
| PF5      | `05`      | previous record             |
| PF6      | `06`      | next record                 |
| PF9      | `09`      | delete                      |
| PF12     | `12`      | back one field/page         |

### Screen colours (WEBCOBOL `COLOR` clause)
Title bar `REVERSE COLOR YELLOW`; labels `COLOR YELLOW`; input fields default;
error line `COLOR RED`; guide/footer `COLOR CYAN`.

---

## 4. Complete data model

> PICs are authoritative. Header records include audit fields
> `*-ADD-DATE 9(8)`, `*-ADD-USER 9(6)`, `*-UPD-DATE 9(8)`, `*-UPD-USER 9(6)`
> and a `*-DEL-FLAG 9(1)` (0=live,1=logically deleted) unless noted.

### 4.1 Customer master — CUSTF / FCUST / prefix CU
Key: `CU-CODE`. Alt: `CU-NAME` (dup), `CU-REGION`+`CU-CODE`.
```
01 CU-REC.
   02 CU-CODE            PIC 9(6).        * customer code (key)
   02 CU-NAME            PIC X(40).
   02 CU-KANA            PIC X(40).       * search name
   02 CU-ZIP             PIC X(8).
   02 CU-ADDR1           PIC X(40).
   02 CU-ADDR2           PIC X(40).
   02 CU-TEL             PIC X(15).
   02 CU-FAX             PIC X(15).
   02 CU-REGION          PIC 9(3).        * -> REGNF
   02 CU-STAFF           PIC 9(4).        * -> STAFF (sales rep)
   02 CU-CLOSE-DAY       PIC 9(2).        * AR closing day (99=end)
   02 CU-PAY-MONTH       PIC 9(1).        * pay month offset
   02 CU-PAY-DAY         PIC 9(2).
   02 CU-PAY-METHOD      PIC 9(1).        * 1 cash 2 transfer 3 bill
   02 CU-TAX-TYPE        PIC 9(1).        * 1 exclusive 2 inclusive 3 exempt
   02 CU-TAX-ROUND       PIC 9(1).        * 1 round 2 floor 3 ceil
   02 CU-CREDIT-LIMIT    PIC S9(11)   COMP-3.
   02 CU-BALANCE         PIC S9(11)   COMP-3.   * current AR balance
   02 CU-PRICE-RANK      PIC 9(1).        * price table rank 1-5
   02 CU-BANK-CODE       PIC 9(4).        * -> BANKF
   02 CU-BANK-ACCT       PIC X(20).
   02 CU-START-DATE      PIC 9(8).
   02 CU-ADD-DATE        PIC 9(8).
   02 CU-ADD-USER        PIC 9(6).
   02 CU-UPD-DATE        PIC 9(8).
   02 CU-UPD-USER        PIC 9(6).
   02 CU-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```

### 4.2 Supplier master — SUPPF / FSUPP / prefix SP
Key `SP-CODE`. Alt `SP-NAME`(dup).
```
01 SP-REC.
   02 SP-CODE            PIC 9(6).
   02 SP-NAME            PIC X(40).
   02 SP-KANA            PIC X(40).
   02 SP-ZIP             PIC X(8).
   02 SP-ADDR1           PIC X(40).
   02 SP-ADDR2           PIC X(40).
   02 SP-TEL             PIC X(15).
   02 SP-FAX             PIC X(15).
   02 SP-CLOSE-DAY       PIC 9(2).
   02 SP-PAY-MONTH       PIC 9(1).
   02 SP-PAY-DAY         PIC 9(2).
   02 SP-PAY-METHOD      PIC 9(1).
   02 SP-TAX-TYPE        PIC 9(1).
   02 SP-BALANCE         PIC S9(11)   COMP-3.   * current AP balance
   02 SP-BANK-CODE       PIC 9(4).
   02 SP-BANK-ACCT       PIC X(20).
   02 SP-ADD-DATE        PIC 9(8).
   02 SP-ADD-USER        PIC 9(6).
   02 SP-UPD-DATE        PIC 9(8).
   02 SP-UPD-USER        PIC 9(6).
   02 SP-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```

### 4.3 Product master — PRODF / FPROD / prefix PR
Key `PR-CODE`. Alt `PR-NAME`(dup), `PR-CATEGORY`+`PR-CODE`, `PR-BARCODE`.
```
01 PR-REC.
   02 PR-CODE            PIC 9(8).
   02 PR-NAME            PIC X(40).
   02 PR-KANA            PIC X(40).
   02 PR-SPEC            PIC X(30).       * spec / model
   02 PR-CATEGORY        PIC 9(4).        * -> CATGF
   02 PR-BARCODE         PIC X(13).
   02 PR-UNIT            PIC X(6).        * stocking unit label
   02 PR-STD-COST        PIC S9(9)V9(2) COMP-3.
   02 PR-LAST-COST       PIC S9(9)V9(2) COMP-3.
   02 PR-LIST-PRICE      PIC S9(9)V9(2) COMP-3.   * default sales price
   02 PR-PRICE-TBL OCCURS 5.
      03 PR-RANK-PRICE   PIC S9(9)V9(2) COMP-3.    * price by rank 1-5
   02 PR-TAX-CATEGORY    PIC 9(1).        * 1 standard 2 reduced 3 exempt
   02 PR-SAFETY-STOCK    PIC S9(9)     COMP-3.
   02 PR-REORDER-POINT   PIC S9(9)     COMP-3.
   02 PR-REORDER-QTY     PIC S9(9)     COMP-3.
   02 PR-LEAD-DAYS       PIC 9(3).
   02 PR-DFLT-SUPP       PIC 9(6).        * -> SUPPF
   02 PR-DFLT-WHSE       PIC 9(3).        * -> WHSEF
   02 PR-STOCK-MNG       PIC 9(1).        * 0 no stock mgmt 1 managed
   02 PR-ADD-DATE        PIC 9(8).
   02 PR-ADD-USER        PIC 9(6).
   02 PR-UPD-DATE        PIC 9(8).
   02 PR-UPD-USER        PIC 9(6).
   02 PR-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```

### 4.4 Warehouse master — WHSEF / FWHSE / prefix WH
Key `WH-CODE`.
```
01 WH-REC.
   02 WH-CODE            PIC 9(3).
   02 WH-NAME            PIC X(30).
   02 WH-ZIP             PIC X(8).
   02 WH-ADDR            PIC X(40).
   02 WH-TEL             PIC X(15).
   02 WH-TYPE            PIC 9(1).        * 1 normal 2 transit 3 defective
   02 WH-MANAGER         PIC 9(4).
   02 WH-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```

### 4.5 Staff master — STAFF / FSTAF / prefix SF
Key `SF-CODE`. Alt `SF-DEPT`+`SF-CODE`.
```
01 SF-REC.
   02 SF-CODE            PIC 9(4).
   02 SF-NAME            PIC X(30).
   02 SF-KANA            PIC X(30).
   02 SF-DEPT            PIC 9(4).        * -> DEPTF
   02 SF-TEL             PIC X(15).
   02 SF-EMAIL           PIC X(40).
   02 SF-TITLE           PIC X(20).
   02 SF-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```

### 4.6 Category master — CATGF / FCATG / prefix CT
Key `CT-CODE`.
```
01 CT-REC.
   02 CT-CODE            PIC 9(4).
   02 CT-NAME            PIC X(30).
   02 CT-PARENT          PIC 9(4).        * parent category (0=root)
   02 CT-LEVEL           PIC 9(1).
   02 CT-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```

### 4.7 Customer price master — CPRCF / FCPRC / prefix CP
Key `CP-CUST`+`CP-PROD`. Special contract prices.
```
01 CP-REC.
   02 CP-CUST            PIC 9(6).
   02 CP-PROD            PIC 9(8).
   02 CP-PRICE           PIC S9(9)V9(2) COMP-3.
   02 CP-START-DATE      PIC 9(8).
   02 CP-END-DATE        PIC 9(8).
   02 CP-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(10).
```

### 4.8 Department master — DEPTF / FDEPT / prefix DP
Key `DP-CODE`.
```
01 DP-REC.
   02 DP-CODE            PIC 9(4).
   02 DP-NAME            PIC X(30).
   02 DP-PARENT          PIC 9(4).
   02 DP-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```

### 4.9 Tax master — TAXF / FTAX / prefix TX
Key `TX-CODE`+`TX-START-DATE`.
```
01 TX-REC.
   02 TX-CODE            PIC 9(1).        * tax category 1 std 2 reduced
   02 TX-START-DATE      PIC 9(8).        * effective from
   02 TX-RATE            PIC S9(2)V9(3) COMP-3.  * e.g. 0.100
   02 TX-NAME            PIC X(20).
   02 FILLER             PIC X(10).
```

### 4.10 Bank master — BANKF / FBANK / prefix BK
Key `BK-CODE`.
```
01 BK-REC.
   02 BK-CODE            PIC 9(4).
   02 BK-NAME            PIC X(30).
   02 BK-BRANCH          PIC X(30).
   02 BK-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```

### 4.11 Region master — REGNF / FREGN / prefix RG
Key `RG-CODE`.
```
01 RG-REC.
   02 RG-CODE            PIC 9(3).
   02 RG-NAME            PIC X(30).
   02 RG-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```

### 4.12 User master — USERF / FUSER / prefix US
Key `US-CODE`. Alt `US-LOGIN`.
```
01 US-REC.
   02 US-CODE            PIC 9(6).        * = staff code
   02 US-LOGIN           PIC X(12).
   02 US-PASSWORD        PIC X(16).       * stored hashed/obscured
   02 US-NAME            PIC X(30).
   02 US-ROLE            PIC 9(1).        * 1 admin 2 manager 3 clerk
   02 US-AUTH-MASTER     PIC 9(1).        * 1 allowed
   02 US-AUTH-ORDER      PIC 9(1).
   02 US-AUTH-SALES      PIC 9(1).
   02 US-AUTH-PURCH      PIC 9(1).
   02 US-AUTH-CLOSE      PIC 9(1).
   02 US-LAST-LOGIN      PIC 9(8).
   02 US-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```

### 4.13 Message master — MSGF / FMSG / prefix MG
Key `MG-CODE`. Used by GETMSG.
```
01 MG-REC.
   02 MG-CODE            PIC X(6).        * e.g. "I0001","E0001","W0001"
   02 MG-TEXT            PIC X(60).
   02 FILLER             PIC X(10).
```

### 4.14 System control — SYSCF / FSYSC / prefix SY  (single record key=1)
```
01 SY-REC.
   02 SY-KEY             PIC 9(1).        * always 1
   02 SY-COMPANY-NAME    PIC X(40).
   02 SY-COMPANY-ZIP     PIC X(8).
   02 SY-COMPANY-ADDR    PIC X(40).
   02 SY-COMPANY-TEL     PIC X(15).
   02 SY-FISCAL-START    PIC 9(2).        * fiscal start month
   02 SY-CURR-YM         PIC 9(6).        * current accounting YYYYMM
   02 SY-LAST-DAY-CLOSE  PIC 9(8).        * last daily close date
   02 SY-LAST-MON-CLOSE  PIC 9(6).        * last monthly close YYYYMM
   02 SY-TAX-DFLT-RATE   PIC S9(2)V9(3) COMP-3.
   02 SY-DEC-ROUND       PIC 9(1).
   02 FILLER             PIC X(30).
```

### 4.15 Number control (採番) — NUMCF / FNUMC / prefix NM
Key `NM-KEY`. Used by NUMGEN.
```
01 NM-REC.
   02 NM-KEY             PIC X(8).        * e.g. "ORDER","INVOICE","PO"
   02 NM-PREFIX          PIC X(2).
   02 NM-CURRENT         PIC 9(10).       * last assigned number
   02 NM-WIDTH           PIC 9(2).
   02 FILLER             PIC X(10).
```

### 4.16 Stock balance — STOKF / FSTOK / prefix SK
Key `SK-PROD`+`SK-WHSE`. Alt `SK-WHSE`+`SK-PROD`.
```
01 SK-REC.
   02 SK-PROD            PIC 9(8).
   02 SK-WHSE            PIC 9(3).
   02 SK-ONHAND          PIC S9(9)     COMP-3.   * physical qty
   02 SK-ALLOCATED       PIC S9(9)     COMP-3.   * committed to orders
   02 SK-ON-ORDER        PIC S9(9)     COMP-3.   * on purchase order
   02 SK-AVG-COST        PIC S9(9)V9(2) COMP-3.  * moving average cost
   02 SK-LAST-IN-DATE    PIC 9(8).
   02 SK-LAST-OUT-DATE   PIC 9(8).
   02 SK-YTD-IN          PIC S9(11)    COMP-3.
   02 SK-YTD-OUT         PIC S9(11)    COMP-3.
   02 SK-LOCATION        PIC X(10).       * bin location
   02 FILLER             PIC X(10).
```
Note: **available = SK-ONHAND - SK-ALLOCATED**.

### 4.17 Stock movement history — SMOVF / FSMOV / prefix SM
Key `SM-SEQ` (from NUMGEN "STKMOV"). Alt `SM-PROD`+`SM-DATE`.
```
01 SM-REC.
   02 SM-SEQ             PIC 9(10).
   02 SM-DATE            PIC 9(8).
   02 SM-PROD            PIC 9(8).
   02 SM-WHSE            PIC 9(3).
   02 SM-KIND            PIC 9(2).   * 10 sale-out 20 purch-in 30 adjust
   *                                   40 transfer 50 return-in 60 return-out
   02 SM-QTY             PIC S9(9)   COMP-3.   * +in / -out
   02 SM-UNIT-COST       PIC S9(9)V9(2) COMP-3.
   02 SM-BAL-AFTER       PIC S9(9)   COMP-3.
   02 SM-REF-TYPE        PIC 9(2).   * source doc type
   02 SM-REF-NO          PIC 9(10).  * source doc no
   02 SM-USER            PIC 9(6).
   02 FILLER             PIC X(10).
```

### 4.18 Sales order — header ORDHF/FORDH/OH, detail ORDDF/FORDD/OD
Header key `OH-NO`. Alt `OH-CUST`+`OH-DATE`, `OH-DATE`+`OH-NO`.
```
01 OH-REC.
   02 OH-NO              PIC 9(10).       * order number (NUMGEN "ORDER")
   02 OH-DATE            PIC 9(8).        * order date
   02 OH-CUST            PIC 9(6).
   02 OH-STAFF           PIC 9(4).
   02 OH-WHSE            PIC 9(3).        * default ship-from
   02 OH-DUE-DATE        PIC 9(8).        * requested delivery
   02 OH-CUST-PO         PIC X(20).       * customer's PO reference
   02 OH-TAX-TYPE        PIC 9(1).
   02 OH-AMOUNT          PIC S9(11)   COMP-3.   * net amount
   02 OH-TAX-AMOUNT      PIC S9(11)   COMP-3.
   02 OH-TOTAL           PIC S9(11)   COMP-3.
   02 OH-STATUS          PIC 9(1).  * 0 entered 1 allocated 2 part-ship
   *                                  3 shipped 4 invoiced 9 cancelled
   02 OH-LINES           PIC 9(3).        * detail line count
   02 OH-REMARK          PIC X(40).
   02 OH-ADD-DATE        PIC 9(8).
   02 OH-ADD-USER        PIC 9(6).
   02 OH-UPD-DATE        PIC 9(8).
   02 OH-UPD-USER        PIC 9(6).
   02 OH-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```
Detail key `OD-NO`+`OD-LINE`.
```
01 OD-REC.
   02 OD-NO              PIC 9(10).
   02 OD-LINE            PIC 9(3).
   02 OD-PROD            PIC 9(8).
   02 OD-WHSE            PIC 9(3).
   02 OD-QTY             PIC S9(9)     COMP-3.
   02 OD-UNIT-PRICE      PIC S9(9)V9(2) COMP-3.
   02 OD-AMOUNT          PIC S9(11)    COMP-3.
   02 OD-TAX-CATEGORY    PIC 9(1).
   02 OD-SHIPPED-QTY     PIC S9(9)     COMP-3.
   02 OD-ALLOC-QTY       PIC S9(9)     COMP-3.
   02 OD-DUE-DATE        PIC 9(8).
   02 OD-STATUS          PIC 9(1).
   02 OD-REMARK          PIC X(30).
   02 FILLER             PIC X(10).
```

### 4.19 Shipment — header SHPHF/FSHPH/XH, detail SHPDF/FSHPD/XD
Header key `XH-NO` (NUMGEN "SHIP"). Alt `XH-ORDER`, `XH-DATE`+`XH-NO`.
```
01 XH-REC.
   02 XH-NO              PIC 9(10).
   02 XH-DATE            PIC 9(8).        * ship date
   02 XH-ORDER           PIC 9(10).       * source order
   02 XH-CUST            PIC 9(6).
   02 XH-WHSE            PIC 9(3).
   02 XH-STAFF           PIC 9(4).
   02 XH-STATUS          PIC 9(1).   * 0 picked 1 shipped 2 invoiced 9 cancel
   02 XH-LINES           PIC 9(3).
   02 XH-REMARK          PIC X(40).
   02 XH-ADD-DATE        PIC 9(8).
   02 XH-ADD-USER        PIC 9(6).
   02 XH-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```
Detail key `XD-NO`+`XD-LINE`.
```
01 XD-REC.
   02 XD-NO              PIC 9(10).
   02 XD-LINE            PIC 9(3).
   02 XD-ORDER           PIC 9(10).
   02 XD-ORDER-LINE      PIC 9(3).
   02 XD-PROD            PIC 9(8).
   02 XD-WHSE            PIC 9(3).
   02 XD-QTY             PIC S9(9)     COMP-3.
   02 XD-UNIT-PRICE      PIC S9(9)V9(2) COMP-3.
   02 XD-AMOUNT          PIC S9(11)    COMP-3.
   02 XD-UNIT-COST       PIC S9(9)V9(2) COMP-3.
   02 FILLER             PIC X(10).
```

### 4.20 Sales / invoice — header INVHF/FINVH/IH, detail INVDF/FINVD/ID
Header key `IH-NO` (NUMGEN "INVOICE"). Alt `IH-CUST`+`IH-DATE`, `IH-DATE`+`IH-NO`.
```
01 IH-REC.
   02 IH-NO              PIC 9(10).
   02 IH-DATE            PIC 9(8).        * sales date
   02 IH-CUST            PIC 9(6).
   02 IH-STAFF           PIC 9(4).
   02 IH-SHIP-NO         PIC 9(10).       * source shipment (0 if direct)
   02 IH-CLOSE-YM        PIC 9(6).        * AR closing period
   02 IH-TAX-TYPE        PIC 9(1).
   02 IH-AMOUNT          PIC S9(11)    COMP-3.
   02 IH-TAX-AMOUNT      PIC S9(11)    COMP-3.
   02 IH-TOTAL           PIC S9(11)    COMP-3.
   02 IH-COST-TOTAL      PIC S9(11)    COMP-3.
   02 IH-STATUS          PIC 9(1).   * 0 entered 1 posted 2 closed 9 cancelled
   02 IH-KIND            PIC 9(1).   * 1 sale 2 return
   02 IH-LINES           PIC 9(3).
   02 IH-REMARK          PIC X(40).
   02 IH-ADD-DATE        PIC 9(8).
   02 IH-ADD-USER        PIC 9(6).
   02 IH-UPD-DATE        PIC 9(8).
   02 IH-UPD-USER        PIC 9(6).
   02 IH-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```
Detail key `ID-NO`+`ID-LINE`.
```
01 ID-REC.
   02 ID-NO              PIC 9(10).
   02 ID-LINE            PIC 9(3).
   02 ID-PROD            PIC 9(8).
   02 ID-WHSE            PIC 9(3).
   02 ID-QTY             PIC S9(9)     COMP-3.
   02 ID-UNIT-PRICE      PIC S9(9)V9(2) COMP-3.
   02 ID-AMOUNT          PIC S9(11)    COMP-3.
   02 ID-UNIT-COST       PIC S9(9)V9(2) COMP-3.
   02 ID-COST-AMOUNT     PIC S9(11)    COMP-3.
   02 ID-TAX-CATEGORY    PIC 9(1).
   02 ID-REMARK          PIC X(30).
   02 FILLER             PIC X(10).
```

### 4.21 Purchase order — header POHF/FPOH/PH, detail PODF/FPOD/PD
Header key `PH-NO` (NUMGEN "PO"). Alt `PH-SUPP`+`PH-DATE`.
```
01 PH-REC.
   02 PH-NO              PIC 9(10).
   02 PH-DATE            PIC 9(8).
   02 PH-SUPP            PIC 9(6).
   02 PH-WHSE            PIC 9(3).        * receive-into
   02 PH-STAFF           PIC 9(4).
   02 PH-DUE-DATE        PIC 9(8).
   02 PH-TAX-TYPE        PIC 9(1).
   02 PH-AMOUNT          PIC S9(11)    COMP-3.
   02 PH-TAX-AMOUNT      PIC S9(11)    COMP-3.
   02 PH-TOTAL           PIC S9(11)    COMP-3.
   02 PH-STATUS          PIC 9(1).  * 0 entered 1 part-recv 2 received
   *                                  3 invoiced 9 cancelled
   02 PH-LINES           PIC 9(3).
   02 PH-REMARK          PIC X(40).
   02 PH-ADD-DATE        PIC 9(8).
   02 PH-ADD-USER        PIC 9(6).
   02 PH-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```
Detail key `PD-NO`+`PD-LINE`.
```
01 PD-REC.
   02 PD-NO              PIC 9(10).
   02 PD-LINE            PIC 9(3).
   02 PD-PROD            PIC 9(8).
   02 PD-WHSE            PIC 9(3).
   02 PD-QTY             PIC S9(9)     COMP-3.
   02 PD-UNIT-COST       PIC S9(9)V9(2) COMP-3.
   02 PD-AMOUNT          PIC S9(11)    COMP-3.
   02 PD-RECV-QTY        PIC S9(9)     COMP-3.
   02 PD-DUE-DATE        PIC 9(8).
   02 PD-STATUS          PIC 9(1).
   02 FILLER             PIC X(10).
```

### 4.22 Receiving — header RCVHF/FRCVH/RH, detail RCVDF/FRCVD/RD
Header key `RH-NO` (NUMGEN "RECV"). Alt `RH-PO`, `RH-DATE`+`RH-NO`.
```
01 RH-REC.
   02 RH-NO              PIC 9(10).
   02 RH-DATE            PIC 9(8).
   02 RH-PO              PIC 9(10).
   02 RH-SUPP            PIC 9(6).
   02 RH-WHSE            PIC 9(3).
   02 RH-STATUS          PIC 9(1).   * 0 received 1 invoiced 9 cancelled
   02 RH-LINES           PIC 9(3).
   02 RH-REMARK          PIC X(40).
   02 RH-ADD-DATE        PIC 9(8).
   02 RH-ADD-USER        PIC 9(6).
   02 RH-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```
Detail key `RD-NO`+`RD-LINE`.
```
01 RD-REC.
   02 RD-NO              PIC 9(10).
   02 RD-LINE            PIC 9(3).
   02 RD-PO              PIC 9(10).
   02 RD-PO-LINE         PIC 9(3).
   02 RD-PROD            PIC 9(8).
   02 RD-WHSE            PIC 9(3).
   02 RD-QTY             PIC S9(9)     COMP-3.
   02 RD-UNIT-COST       PIC S9(9)V9(2) COMP-3.
   02 RD-AMOUNT          PIC S9(11)    COMP-3.
   02 FILLER             PIC X(10).
```

### 4.23 Purchase (仕入) — header PURHF/FPURH/VH, detail PURDF/FPURD/VD
Header key `VH-NO` (NUMGEN "PURCH"). Alt `VH-SUPP`+`VH-DATE`.
```
01 VH-REC.
   02 VH-NO              PIC 9(10).
   02 VH-DATE            PIC 9(8).
   02 VH-SUPP            PIC 9(6).
   02 VH-RECV-NO         PIC 9(10).
   02 VH-CLOSE-YM        PIC 9(6).
   02 VH-TAX-TYPE        PIC 9(1).
   02 VH-AMOUNT          PIC S9(11)    COMP-3.
   02 VH-TAX-AMOUNT      PIC S9(11)    COMP-3.
   02 VH-TOTAL           PIC S9(11)    COMP-3.
   02 VH-STATUS          PIC 9(1).   * 0 entered 1 posted 2 closed 9 cancel
   02 VH-KIND            PIC 9(1).   * 1 purchase 2 return
   02 VH-LINES           PIC 9(3).
   02 VH-REMARK          PIC X(40).
   02 VH-ADD-DATE        PIC 9(8).
   02 VH-ADD-USER        PIC 9(6).
   02 VH-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(20).
```
Detail key `VD-NO`+`VD-LINE`.
```
01 VD-REC.
   02 VD-NO              PIC 9(10).
   02 VD-LINE            PIC 9(3).
   02 VD-PROD            PIC 9(8).
   02 VD-WHSE            PIC 9(3).
   02 VD-QTY             PIC S9(9)     COMP-3.
   02 VD-UNIT-COST       PIC S9(9)V9(2) COMP-3.
   02 VD-AMOUNT          PIC S9(11)    COMP-3.
   02 VD-TAX-CATEGORY    PIC 9(1).
   02 FILLER             PIC X(10).
```

### 4.24 AR ledger — ARLF / FARL / prefix AL
Key `AL-SEQ` (NUMGEN "ARLDG"). Alt `AL-CUST`+`AL-DATE`, `AL-CUST`+`AL-CLOSE-YM`.
```
01 AL-REC.
   02 AL-SEQ             PIC 9(10).
   02 AL-CUST            PIC 9(6).
   02 AL-DATE            PIC 9(8).
   02 AL-CLOSE-YM        PIC 9(6).
   02 AL-KIND            PIC 9(1).   * 1 sale 2 receipt 3 return 4 adjust
   02 AL-REF-TYPE        PIC 9(2).
   02 AL-REF-NO          PIC 9(10).
   02 AL-DEBIT           PIC S9(11)  COMP-3.   * increases AR (sales)
   02 AL-CREDIT          PIC S9(11)  COMP-3.   * decreases AR (receipt)
   02 AL-BALANCE         PIC S9(11)  COMP-3.   * running balance
   02 AL-REMARK          PIC X(30).
   02 AL-USER            PIC 9(6).
   02 FILLER             PIC X(10).
```

### 4.25 AP ledger — APLF / FAPL / prefix PL
Key `PL-SEQ` (NUMGEN "APLDG"). Alt `PL-SUPP`+`PL-DATE`.
```
01 PL-REC.
   02 PL-SEQ             PIC 9(10).
   02 PL-SUPP            PIC 9(6).
   02 PL-DATE            PIC 9(8).
   02 PL-CLOSE-YM        PIC 9(6).
   02 PL-KIND            PIC 9(1).   * 1 purchase 2 payment 3 return 4 adjust
   02 PL-REF-TYPE        PIC 9(2).
   02 PL-REF-NO          PIC 9(10).
   02 PL-DEBIT           PIC S9(11)  COMP-3.   * decreases AP (payment)
   02 PL-CREDIT          PIC S9(11)  COMP-3.   * increases AP (purchase)
   02 PL-BALANCE         PIC S9(11)  COMP-3.
   02 PL-REMARK          PIC X(30).
   02 PL-USER            PIC 9(6).
   02 FILLER             PIC X(10).
```

### 4.26 Cash receipt — RCPTF / FRCPT / prefix RE
Key `RE-NO` (NUMGEN "RECEIPT"). Alt `RE-CUST`+`RE-DATE`.
```
01 RE-REC.
   02 RE-NO              PIC 9(10).
   02 RE-DATE            PIC 9(8).
   02 RE-CUST            PIC 9(6).
   02 RE-METHOD          PIC 9(1).   * 1 cash 2 transfer 3 bill 4 offset
   02 RE-AMOUNT          PIC S9(11)  COMP-3.
   02 RE-BANK-CODE       PIC 9(4).
   02 RE-CLOSE-YM        PIC 9(6).
   02 RE-STATUS          PIC 9(1).
   02 RE-REMARK          PIC X(30).
   02 RE-ADD-DATE        PIC 9(8).
   02 RE-ADD-USER        PIC 9(6).
   02 RE-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(10).
```

### 4.27 Payment — PAYF / FPAY / prefix PY
Key `PY-NO` (NUMGEN "PAYMENT"). Alt `PY-SUPP`+`PY-DATE`.
```
01 PY-REC.
   02 PY-NO              PIC 9(10).
   02 PY-DATE            PIC 9(8).
   02 PY-SUPP            PIC 9(6).
   02 PY-METHOD          PIC 9(1).
   02 PY-AMOUNT          PIC S9(11)  COMP-3.
   02 PY-BANK-CODE       PIC 9(4).
   02 PY-CLOSE-YM        PIC 9(6).
   02 PY-STATUS          PIC 9(1).
   02 PY-REMARK          PIC X(30).
   02 PY-ADD-DATE        PIC 9(8).
   02 PY-ADD-USER        PIC 9(6).
   02 PY-DEL-FLAG        PIC 9(1).
   02 FILLER             PIC X(10).
```

---

## 5. Standard program skeleton (on-line master/transaction)

```
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN  UNTIL  END-FLG = 1.
           PERFORM TERM-RTN.
           STOP RUN.
       ...
       INIT-RTN SECTION.   * open files, get sys date, login banner
       MAIN-RTN SECTION.   * display screen, ACCEPT, dispatch on ESTS
       TERM-RTN SECTION.   * close files
       READ-xxx / WRITE-xxx / REWRITE-xxx / DELETE-xxx SECTIONs
       ABEND-RTN SECTION.  * fill KABEND, CALL "ABORTX", STOP RUN with 255
```

`ABEND-RTN` fills the `KABEND` structure (see `KLINK`) and `CALL "ABORTX"
USING KABEND`. Set `COMPLETION-CODE` (return code) to 255 on abend, 0 on
normal end.

Every program `COPY WCOMMON` (working common: FSTS, ESTS, switches, sys date/
time, work counters), `COPY WMSG` (message work area), and the screen commons it
needs (`GHEAD`, `GFUNC`).

---

## 6. Common subroutines (sub/) & linkage (KLINK copybook)

All linkage layouts live in copybook `KLINK`. Signatures:

### NUMGEN — assign next document number
`CALL "NUMGEN" USING KNUM.`
```
01 KNUM.
   02 KNUM-KEY      PIC X(8).     * in: e.g. "ORDER"
   02 KNUM-NUMBER   PIC 9(10).    * out: assigned number
   02 KNUM-STATUS   PIC X(2).     * out: "00" ok
```

### DATEUT — date utilities
`CALL "DATEUT" USING KDATE.`
```
01 KDATE.
   02 KD-FUNC       PIC X(4).   * "TODY" today, "ADDD" add days,
   *                             "DIFF" day diff, "VALD" validate,
   *                             "YOBI" weekday, "EOM " end of month
   02 KD-DATE1      PIC 9(8).   * in/out YYYYMMDD
   02 KD-DATE2      PIC 9(8).   * in/out
   02 KD-DAYS       PIC S9(7).  * in/out day count
   02 KD-WEEKDAY    PIC 9(1).   * out 0=Sun..6=Sat
   02 KD-STATUS     PIC X(2).   * out "00" ok "99" invalid
```

### GETMSG — fetch a message text by code from MSGF
`CALL "GETMSG" USING KMSG.`
```
01 KMSG.
   02 KM-CODE       PIC X(6).    * in
   02 KM-TEXT       PIC X(60).   * out
   02 KM-STATUS     PIC X(2).    * out
```

### TAXCAL — compute tax
`CALL "TAXCAL" USING KTAX.`
```
01 KTAX.
   02 KT-CATEGORY   PIC 9(1).       * in: tax category
   02 KT-TAX-TYPE   PIC 9(1).       * in: 1 excl 2 incl 3 exempt
   02 KT-ROUND      PIC 9(1).       * in: 1 round 2 floor 3 ceil
   02 KT-DATE       PIC 9(8).       * in: effective date
   02 KT-AMOUNT     PIC S9(11)      COMP-3.  * in: net (excl) or gross (incl)
   02 KT-TAX        PIC S9(11)      COMP-3.  * out: tax amount
   02 KT-NET        PIC S9(11)      COMP-3.  * out: net amount
   02 KT-GROSS      PIC S9(11)      COMP-3.  * out: gross amount
   02 KT-RATE       PIC S9(2)V9(3)  COMP-3.  * out: rate applied
   02 KT-STATUS     PIC X(2).
```

### CHKLOG — validate login / return operator context
`CALL "CHKLOG" USING KLOGIN.`
```
01 KLOGIN.
   02 KL-LOGIN      PIC X(12).   * in
   02 KL-PASSWORD   PIC X(16).   * in
   02 KL-USER-CODE  PIC 9(6).    * out
   02 KL-USER-NAME  PIC X(30).   * out
   02 KL-ROLE       PIC 9(1).    * out
   02 KL-AUTH       PIC X(5).    * out flags: master/order/sales/purch/close
   02 KL-STATUS     PIC X(2).    * out "00" ok "99" denied
```

### ABORTX — log abend & display fatal message
`CALL "ABORTX" USING KABEND.`
```
01 KABEND.
   02 KA-PROGID     PIC X(6).
   02 KA-FILE       PIC X(8).
   02 KA-FSTS       PIC X(2).
   02 KA-MSGCODE    PIC X(6).
   02 KA-DETAIL     PIC X(40).
```

`KLINK` copybook contains ALL of KNUM, KDATE, KMSG, KTAX, KLOGIN, KABEND.
A caller `COPY KLINK` in WORKING-STORAGE and passes the relevant sub-structure.

---

## 7. Program inventory & ownership (subagent assignment)

Foundation (written centrally): MENU00, NUMGEN, DATEUT, GETMSG, TAXCAL, CHKLOG,
ABORTX, INITDB (file creator/loader), MS0010 (golden master ref), OE0010
(golden transaction ref).

* **Agent MASTER-A**: MS0020 supplier, MS0030 product, MS0040 warehouse,
  MS0050 staff, MS0060 category.
* **Agent MASTER-B**: MS0070 customer-price, MS0080 department, MS0090 tax,
  MS0100 bank, MS0110 region, MS0120 user.
* **Agent ORDER-SALES**: OE0020 order inquiry/list, OE0030 order allocation,
  SH0010 shipping entry, SL0010 sales entry, SL0020 sales inquiry,
  SL0030 sales return.
* **Agent PURCHASE**: PU0010 PO entry, PU0020 PO inquiry, RC0010 receiving,
  PU0030 purchase entry, PU0040 purchase return.
* **Agent INVENTORY-ARAP**: IV0010 stock inquiry, IV0020 stock adjust,
  IV0030 stocktaking, IV0040 movement inquiry, AR0010 receipt entry,
  AR0020 AR inquiry, AP0010 payment entry, AP0020 AP inquiry.
* **Agent REPORTS**: RP0010 customer list, RP0020 product list, RP0030 sales
  journal, RP0040 sales by customer, RP0050 sales by product, RP0060 inventory
  list, RP0070 AR aging, RP0080 AP balance, RP0090 order backlog,
  RP0100 purchase journal.
* **Agent BATCH**: BT0010 daily close, BT0020 monthly close, BT0030 stock
  monthly update, BT0040 AR update, BT0050 AP update, BT0060 purge/archive,
  BT0070 fiscal year close, BT0080 reindex/rebuild.

Report programs write text to `reports/<PROGID>.TXT` (line sequential, 132 col).
Batch programs are console/line-mode (no SCREEN SECTION) driven by parameters
accepted from the console.
