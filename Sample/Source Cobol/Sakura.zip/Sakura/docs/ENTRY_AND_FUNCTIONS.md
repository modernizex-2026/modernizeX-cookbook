# SAKURA-SMS — Entry Application & Functions

Complete guide to the entry program and every function in the SAKURA Sales
Management System. 68 programs (36 on-line screen + 25 batch/report + 7 called
subroutines) + 72 copybooks. Data layer = NEC DBLink → SQL Server (`ASSIGN … -RDB`).

---

## 1. How to run (order matters)

| Step | Program | When | Purpose |
|------|---------|------|---------|
| 1 | `build\build.bat` | once / after code change | Compile all programs (NEC COBOL85 Pro `cbl.exe`). |
| 2 | **`INITDB`** | **once**, before first use | Creates the 33 files and loads starter master data + opening stock. Runs standalone (console), then `STOP RUN`. |
| 3 | **`MENU00`** | **every session** | The entry application. Sign on, then navigate the menus. |

Batch jobs (`BT*`) may be run from the menu **or** standalone on a schedule.

### Sample sign-on accounts (loaded by INITDB)
| Login  | Password  | Role          | Authorities (master/order/sales/purch/close) |
|--------|-----------|---------------|-----------------------------------------------|
| admin  | admin123  | administrator | 1 / 1 / 1 / 1 / 1  (all, incl. closing)       |
| yamada | pass1001  | manager       | 1 / 1 / 1 / 0 / 1                              |
| suzuki | pass1002  | clerk         | 0 / 1 / 1 / 0 / 0                              |

---

## 2. The entry application — `MENU00`

`MENU00` (in `menu/MENU00.cob`) is the single entry point. It:

1. **Signs the operator on** — prompts Login ID + Password, calls the `CHKLOG`
   subroutine which validates against the **User master (USERF)** and returns the
   operator code, name, role and 5 authority flags. Up to **3 attempts**; PF3 quits.
2. **Displays a two-level menu** (main menu → subsystem submenu).
3. **Launches the chosen program with a static `CALL`** — every selection maps to
   `CALL "<PROGID>"` in the `CALL-PROG` section.
4. **Returns to the menu** — each business program ends with `EXIT PROGRAM`, so
   control comes back to `MENU00` and the menu is shown again. (`INITDB` and
   `MENU00` themselves use `STOP RUN`; only `MENU00`'s sign-off ends the session.)
5. **Enforces authority** — e.g. the Batch/Closing menu requires the *close*
   authority flag; otherwise it shows "Not authorised for batch/closing".

```
INITDB  (run once → creates DB + sample data)
   │
MENU00  ── CHKLOG sign-on ──► main menu ──► submenu ──► CALL "<PROGID>"
   ▲                                                        │
   └──────────────── EXIT PROGRAM (return to menu) ─────────┘
```

### Function keys (screen end-status `ESTS`, 2-char string)
| Key   | ESTS  | Meaning                       |
|-------|-------|-------------------------------|
| Enter | `00`  | confirm / next                |
| PF1   | `01`  | help                          |
| PF3   | `03`  | end / back to previous menu   |
| PF4   | `04`  | clear / cancel current entry  |
| PF5   | `05`  | previous record               |
| PF6   | `06`  | next record                   |
| PF9   | `09`  | delete                        |
| PF12  | `12`  | back one field / page         |

---

## 3. Menu tree

```
MAIN MENU (MENU00)
 1. Master Maintenance ─────► [Master submenu]
 2. Order / Sales ──────────► [Order/Sales submenu]
 3. Purchasing ─────────────► [Purchasing submenu]
 4. Inventory ──────────────► [Inventory / AR / AP submenu]
 5. Receivable / Payable ───► [Inventory / AR / AP submenu]   (same submenu)
 6. Reports ────────────────► [Reports submenu]
 7. Batch / Closing ────────► [Batch submenu]   (needs 'close' authority)
 0. Sign off
```

| Master submenu | Order / Sales submenu | Purchasing submenu |
|---|---|---|
| 1 Customer → MS0010 | 1 Order Entry → OE0010 | 1 PO Entry → PU0010 |
| 2 Supplier → MS0020 | 2 Order Inquiry → OE0020 | 2 PO Inquiry → PU0020 |
| 3 Product → MS0030 | 3 Order Allocation → OE0030 | 3 Receiving → RC0010 |
| 4 Warehouse → MS0040 | 4 Shipping → SH0010 | 4 Purchase Entry → PU0030 |
| 5 Staff → MS0050 | 5 Sales Entry → SL0010 | 5 Purchase Return → PU0040 |
| 6 Category → MS0060 | 6 Sales Inquiry → SL0020 | 0 Back |
| 7 Cust Price → MS0070 | 7 Sales Return → SL0030 | |
| 8 Department → MS0080 | 8 Order Maintenance → OE0040 | |
| 9 Tax Rate → MS0090 | 9 Sales Credit Note → SL0040 | |
| 10 Bank → MS0100 | 10 Order Ack Print → OE0050 | |
| 11 Region → MS0110 | 0 Back | |
| 12 User → MS0120 | | |
| 0 Back | | |

| Inventory / AR / AP submenu | Reports submenu | Batch / Closing submenu |
|---|---|---|
| 1 Stock Inquiry → IV0010 | 1 Customer List → RP0010 | 1 Daily Close → BT0010 |
| 2 Stock Adjustment → IV0020 | 2 Product List → RP0020 | 2 Monthly Close → BT0020 |
| 3 Stocktaking → IV0030 | 3 Sales Journal → RP0030 | 3 Stock Monthly Update → BT0030 |
| 4 Movement Inquiry → IV0040 | 4 Sales by Customer → RP0040 | 4 AR Balance Update → BT0040 |
| 5 Cash Receipt → AR0010 | 5 Sales by Product → RP0050 | 5 AP Balance Update → BT0050 |
| 6 AR Inquiry → AR0020 | 6 Inventory List → RP0060 | 6 Purge / Archive → BT0060 |
| 7 Payment → AP0010 | 7 AR Aging → RP0070 | 7 Fiscal Year Close → BT0070 |
| 8 AP Inquiry → AP0020 | 8 AP Balance → RP0080 | 8 Reindex / Rebuild → BT0080 |
| 9 Warehouse Transfer → IV0050 | 9 Order Backlog → RP0090 | 9 Integrity Check → BT0090 |
| 0 Back | 10 Purchase Journal → RP0100 | 0 Back |
| | 11 Reorder Suggestion → RP0110 | |
| | 12 Sales Rep Perf → RP0120 | |
| | 13 Customer Statement → RP0130 | |
| | 14 Dead Stock → RP0140 | |
| | 0 Back | |

---

## 4. Functions in detail

### 4.1 Master maintenance (screen — add / change / delete / inquire)
| ID | Function | What it does |
|----|----------|--------------|
| MS0010 | Customer master | Maintain customers; validates region/staff/bank; credit limit, closing day, payment & tax terms, price rank. |
| MS0020 | Supplier master | Maintain suppliers; validates bank; payment/tax terms, AP balance. |
| MS0030 | Product master | Maintain products; validates category/default supplier/warehouse; 5 rank prices, costs, reorder point/qty, lead days, stock-managed flag. |
| MS0040 | Warehouse master | Maintain warehouses; validates manager (staff). |
| MS0050 | Staff master | Maintain sales reps; validates department. |
| MS0060 | Category master | Maintain product categories; self-referencing parent. |
| MS0070 | Customer price master | Contract price per customer×product with effective dates. |
| MS0080 | Department master | Maintain departments; self-referencing parent. |
| MS0090 | Tax rate master | Tax category × effective date → rate (used by TAXCAL). |
| MS0100 | Bank master | Banks & branches. |
| MS0110 | Region master | Sales regions. |
| MS0120 | User master | Login, password, role and the 5 authority flags. |

### 4.2 Order & Sales (screen)
| ID | Function | What it does |
|----|----------|--------------|
| OE0010 | Sales order entry | Header + detail lines; auto price (contract → rank → list), stock check, tax (TAXCAL), order number (NUMGEN "ORDER"); allocates stock. |
| OE0020 | Order inquiry / list | Browse orders by number or customer+date; header + lines + shipped/allocated qty. |
| OE0030 | Order allocation | Allocate available stock to open order lines; updates SK-ALLOCATED / OD-ALLOC-QTY; sets order status. |
| OE0040 | Order maintenance | Change / add / delete lines or cancel an unshipped order; re-allocates stock delta; recomputes totals; credit-limit warning (CREDIT). |
| OE0050 | Order ack / picking list | **Batch print** of an order-number range to `reports/OE0050.TXT`. |
| SH0010 | Shipping entry | Create shipment from an order; decrement on-hand & allocated; log stock movement (kind 10); update shipped qty & order status; assign ship no (NUMGEN "SHIP"). |
| SL0010 | Sales / invoice entry | Invoice from a shipment or direct; cost from moving-avg; tax; post AR ledger (debit) + update customer balance; invoice no (NUMGEN "INVOICE"/"ARLDG"). |
| SL0020 | Sales inquiry | Browse invoices; header + lines with cost / margin. |
| SL0030 | Sales return | Negative invoice (kind 2); increase stock; AR credit; reduce customer balance. |
| SL0040 | Sales credit note | Standalone credit against a source invoice; increase stock; AR credit. |

### 4.3 Purchasing (screen)
| ID | Function | What it does |
|----|----------|--------------|
| PU0010 | Purchase order entry | PO header + lines; validate supplier/product; tax; PO no (NUMGEN "PO"); increase on-order. |
| PU0020 | PO inquiry | Browse POs by number or supplier+date; lines with received qty. |
| RC0010 | Goods receiving | Receive against a PO; increase on-hand, reduce on-order; **moving-average cost**; movement (kind 20); recv no (NUMGEN "RECV"). |
| PU0030 | Purchase entry | Book a purchase from a receiving; tax; post AP ledger (credit) + increase supplier balance; purch no (NUMGEN "PURCH"/"APLDG"). |
| PU0040 | Purchase return | Negative purchase (kind 2); decrease stock; AP debit. |

### 4.4 Inventory (screen)
| ID | Function | What it does |
|----|----------|--------------|
| IV0010 | Stock inquiry | On-hand / allocated / available / on-order / avg cost / location by product×warehouse. |
| IV0020 | Stock adjustment | Signed adjustment with reason; updates on-hand; movement (kind 30). |
| IV0030 | Stocktaking | Enter physical count per product; compute difference; post adjustment. |
| IV0040 | Movement inquiry | Browse stock-movement history by product+date. |
| IV0050 | Warehouse transfer | Move stock between warehouses; two movements (kind 40, out+in). |

### 4.5 Receivable / Payable (screen)
| ID | Function | What it does |
|----|----------|--------------|
| AR0010 | Cash receipt entry | Receipt from a customer; post AR ledger (credit); reduce customer balance; receipt no (NUMGEN "RECEIPT"/"ARLDG"). |
| AR0020 | AR inquiry / aging | Customer balance + aging buckets (0-30/31-60/61-90/90+) via DATEUT. |
| AP0010 | Payment entry | Payment to a supplier; post AP ledger (debit); reduce supplier balance; payment no (NUMGEN "PAYMENT"/"APLDG"). |
| AP0020 | AP inquiry | Supplier balance + recent ledger lines. |

### 4.6 Reports (batch → 132-col text in `reports/<ID>.TXT`)
| ID | Report |
|----|--------|
| RP0010 | Customer master list |
| RP0020 | Product master list |
| RP0030 | Sales journal (invoice register) |
| RP0040 | Sales summary by customer |
| RP0050 | Sales summary by product |
| RP0060 | Inventory valuation list |
| RP0070 | AR aging |
| RP0080 | AP balance list |
| RP0090 | Sales order backlog |
| RP0100 | Purchase journal |
| RP0110 | Reorder suggestion |
| RP0120 | Sales-rep performance |
| RP0130 | Customer statement of account |
| RP0140 | Dead / slow-moving stock |

### 4.7 Batch / Closing (console — needs *close* authority)
| ID | Job | What it does |
|----|-----|--------------|
| BT0010 | Daily close | Post the day's invoices; advance last-daily-close date. |
| BT0020 | Monthly close | Stamp close-YM on posted docs; roll AR/AP; advance current period. |
| BT0030 | Stock monthly update | Valuation + YTD carry-forward / housekeeping. |
| BT0040 | AR balance rebuild | Recompute customer balances from the AR ledger. |
| BT0050 | AP balance rebuild | Recompute supplier balances from the AP ledger. |
| BT0060 | Purge / archive | Remove logically-deleted masters + old processed transactions (after confirm). |
| BT0070 | Fiscal year close | Reset YTD figures; advance fiscal year. |
| BT0080 | Reindex / rebuild | Reorg copy of a master, skipping deleted rows. |
| BT0090 | Integrity check | Scan for orphan details / missing masters / negative stock; report exceptions. |

### 4.8 Initialisation
| ID | What it does |
|----|--------------|
| INITDB | Creates all 33 indexed files and loads the sample master data + opening stock. Run once before `MENU00`. |

### 4.9 Common subroutines (called by the programs above)
| Sub | Purpose |
|-----|---------|
| NUMGEN | Assign the next document number for a series (採番). |
| DATEUT | Date utilities: today / validate / add days / diff / end-of-month / weekday. |
| GETMSG | Fetch a message text by code. |
| TAXCAL | Consumption-tax lookup + net/tax/gross split. |
| CHKLOG | Login + authority validation. |
| ABORTX | Fatal-error logger (`reports/ABEND.LOG`). |
| CREDIT | Customer credit-limit check. |

---

## 5. Typical end-to-end flow

```
MS0010  register a customer          MS0030  register a product
   └────────────────────┬───────────────────────┘
OE0010  enter a sales order  (auto price, allocate stock, tax)
OE0030  allocate remaining stock (if needed)
SH0010  ship            (stock ↓, movement logged, order status → shipped)
SL0010  invoice         (AR posted, customer balance ↑, cost captured)
AR0010  receive payment (AR posted, customer balance ↓)
RP0030 / RP0070  print sales journal / AR aging
BT0010  daily close  →  BT0020 monthly close  (roll AR/AP, advance period)
```

Purchasing mirror: `PU0010` PO → `RC0010` receive (avg-cost) → `PU0030` purchase
(AP posted) → `AP0010` pay → `RP0100`/`RP0080` → monthly close.

---

## 6. Notes
* Every business program returns to `MENU00` (`EXIT PROGRAM`); `INITDB` and
  `MENU00` use `STOP RUN`.
* Master maintenance follows one pattern (MS0010 is the reference): key in a code
  → if found, change/PF9-delete; if not, add.
* Full field-level data model is in `docs/SPEC.md`; the SQL Server schema is in
  `sql/`; per-program line counts in `docs/PROGRAMS.md`.
* All 68 programs compile clean on NEC COBOL85 Pro — see `README.md` §8 and
  `sh tools/compile_all.sh`.
