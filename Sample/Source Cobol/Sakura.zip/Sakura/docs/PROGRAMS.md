# SAKURA-SMS - Program Inventory

Auto-generated from source. 68 programs, 30502 program source lines (copybooks add 1,069 more; grand total 31,571).

Split: 36 on-line/screen, 25 batch/report/console, 7 subroutines.


## On-line / screen programs (36)

| ID | LOC | Title |
|----|----:|-------|
| AP0010 | 410 | Payment entry |
| AP0020 | 305 | AP inquiry |
| AR0010 | 411 | Cash receipt entry |
| AR0020 | 363 | AR inquiry / aging |
| IV0010 | 357 | Stock balance inquiry |
| IV0020 | 405 | Stock adjustment |
| IV0030 | 524 | Stocktaking (physical count) |
| IV0040 | 333 | Stock movement inquiry |
| IV0050 | 509 | Inter-warehouse stock transfer |
| MENU00 | 415 | sign-on and main menu |
| MS0010 | 389 | Customer master maintenance |
| MS0020 | 365 | Supplier master maintenance |
| MS0030 | 474 | Product master maintenance |
| MS0040 | 312 | Warehouse master maintenance |
| MS0050 | 312 | Staff master maintenance |
| MS0060 | 322 | Category master maintenance |
| MS0070 | 379 | Customer price master maintenance |
| MS0080 | 301 | Department master maintenance |
| MS0090 | 283 | Tax rate master maintenance |
| MS0100 | 253 | Bank master maintenance |
| MS0110 | 250 | Region master maintenance |
| MS0120 | 388 | User master maintenance |
| OE0010 | 548 | Sales order entry |
| OE0020 | 722 | Sales order inquiry / list |
| OE0030 | 757 | Sales order stock allocation |
| OE0040 | 1252 | Sales order maintenance |
| PU0010 | 535 | Purchase order entry |
| PU0020 | 430 | Purchase order inquiry |
| PU0030 | 661 | Purchase entry (booking a purchase) |
| PU0040 | 725 | Purchase return entry |
| RC0010 | 797 | Goods receiving entry |
| SH0010 | 1049 | Shipping entry (picking / despatch) |
| SL0010 | 1155 | Sales / invoice entry |
| SL0020 | 689 | Sales / invoice inquiry |
| SL0030 | 1097 | Sales return entry |
| SL0040 | 1033 | Sales credit note |

## Batch / report / console programs (25)

| ID | LOC | Title |
|----|----:|-------|
| BT0010 | 369 | daily close (sales posting) |
| BT0020 | 666 | monthly close |
| BT0030 | 350 | stock monthly update / valuation |
| BT0040 | 331 | accounts-receivable balance rebuild |
| BT0050 | 331 | accounts-payable balance rebuild |
| BT0060 | 437 | purge / archive |
| BT0070 | 391 | fiscal-year close |
| BT0080 | 272 | reindex / rebuild (reorg) |
| BT0090 | 622 | data integrity check |
| INITDB | 667 | database initialiser / sample loader |
| OE0050 | 465 | Order acknowledgement / picking list |
| RP0010 | 323 | Customer master list |
| RP0020 | 287 | Product master list |
| RP0030 | 416 | Sales journal (invoice register) |
| RP0040 | 342 | Sales summary by customer |
| RP0050 | 392 | Sales summary by product |
| RP0060 | 338 | Inventory valuation list |
| RP0070 | 345 | Accounts-receivable aging |
| RP0080 | 296 | Accounts-payable balance list |
| RP0090 | 408 | Sales order backlog |
| RP0100 | 414 | Purchase journal (purchase register) |
| RP0110 | 393 | Reorder suggestion report |
| RP0120 | 449 | Sales-rep performance report |
| RP0130 | 471 | Customer statement of account |
| RP0140 | 465 | Dead / slow-moving stock report |

## Common subroutines (7)

| ID | LOC | Title |
|----|----:|-------|
| ABORTX | 63 | fatal-error logger |
| CHKLOG | 76 | login / authority validator |
| CREDIT | 87 | customer credit-limit check |
| DATEUT | 247 | date utility (YYYYMMDD) |
| GETMSG | 48 | message-text retriever |
| NUMGEN | 81 | next document-number assigner (採番) |
| TAXCAL | 150 | consumption-tax calculator |
