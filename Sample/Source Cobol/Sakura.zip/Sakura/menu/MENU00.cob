       IDENTIFICATION DIVISION.
       PROGRAM-ID. MENU00.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : MENU00  -  sign-on and main menu                 *
      *  FUNCTION : validates the operator with CHKLOG then presents *
      *             a two-level menu and dynamically CALLs the       *
      *             selected program.                                *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-CHOICE               PIC 9(2)  VALUE 0.
       01  WK-GROUP                PIC 9(2)  VALUE 0.
       01  WK-CALL                 PIC X(6)  VALUE SPACE.
       01  WK-LOGIN-TRY            PIC 9(1)  VALUE 0.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GMSG.
       01  DS-LOGIN.
           02  LINE 8.
             03  COLUMN 20 VALUE "Login ID :" COLOR YELLOW.
             03  COLUMN 32 PIC X(12) USING KL-LOGIN.
           02  LINE 10.
             03  COLUMN 20 VALUE "Password :" COLOR YELLOW.
             03  COLUMN 32 PIC X(16) USING KL-PASSWORD.
       01  DS-MAIN.
           02  LINE 4  COLUMN 6  VALUE "MAIN MENU" COLOR CYAN.
           02  LINE 6  COLUMN 8  VALUE " 1. Master Maintenance".
           02  LINE 7  COLUMN 8  VALUE " 2. Order / Sales".
           02  LINE 8  COLUMN 8  VALUE " 3. Purchasing".
           02  LINE 9  COLUMN 8  VALUE " 4. Inventory".
           02  LINE 10 COLUMN 8  VALUE " 5. Receivable / Payable".
           02  LINE 11 COLUMN 8  VALUE " 6. Reports".
           02  LINE 12 COLUMN 8  VALUE " 7. Batch / Closing".
           02  LINE 14 COLUMN 8  VALUE " 0. Sign off".
           02  LINE 16.
             03  COLUMN 8  VALUE "Select :" COLOR YELLOW.
             03  COLUMN 18 PIC 9(2) USING WK-CHOICE.
       01  DS-MENU-MST.
           02  LINE 4  COLUMN 6  VALUE "MASTER MAINTENANCE" COLOR CYAN.
           02  LINE 6  COLUMN 8  VALUE " 1. Customer".
           02  LINE 6  COLUMN 40 VALUE " 7. Customer Price".
           02  LINE 7  COLUMN 8  VALUE " 2. Supplier".
           02  LINE 7  COLUMN 40 VALUE " 8. Department".
           02  LINE 8  COLUMN 8  VALUE " 3. Product".
           02  LINE 8  COLUMN 40 VALUE " 9. Tax Rate".
           02  LINE 9  COLUMN 8  VALUE " 4. Warehouse".
           02  LINE 9  COLUMN 40 VALUE "10. Bank".
           02  LINE 10 COLUMN 8  VALUE " 5. Staff".
           02  LINE 10 COLUMN 40 VALUE "11. Region".
           02  LINE 11 COLUMN 8  VALUE " 6. Category".
           02  LINE 11 COLUMN 40 VALUE "12. User".
           02  LINE 14 COLUMN 8  VALUE " 0. Back".
           02  LINE 16.
             03  COLUMN 8  VALUE "Select :" COLOR YELLOW.
             03  COLUMN 18 PIC 9(2) USING WK-CHOICE.
       01  DS-MENU-ORD.
           02  LINE 4  COLUMN 6  VALUE "ORDER / SALES" COLOR CYAN.
           02  LINE 6  COLUMN 8  VALUE " 1. Order Entry".
           02  LINE 7  COLUMN 8  VALUE " 2. Order Inquiry".
           02  LINE 8  COLUMN 8  VALUE " 3. Order Allocation".
           02  LINE 9  COLUMN 8  VALUE " 4. Shipping".
           02  LINE 10 COLUMN 8  VALUE " 5. Sales Entry".
           02  LINE 11 COLUMN 8  VALUE " 6. Sales Inquiry".
           02  LINE 12 COLUMN 8  VALUE " 7. Sales Return".
           02  LINE 6  COLUMN 34 VALUE " 8. Order Maintenance".
           02  LINE 7  COLUMN 34 VALUE " 9. Sales Credit Note".
           02  LINE 8  COLUMN 34 VALUE "10. Order Ack Print".
           02  LINE 14 COLUMN 8  VALUE " 0. Back".
           02  LINE 16.
             03  COLUMN 8  VALUE "Select :" COLOR YELLOW.
             03  COLUMN 18 PIC 9(2) USING WK-CHOICE.
       01  DS-MENU-PUR.
           02  LINE 4  COLUMN 6  VALUE "PURCHASING" COLOR CYAN.
           02  LINE 6  COLUMN 8  VALUE " 1. Purchase Order Entry".
           02  LINE 7  COLUMN 8  VALUE " 2. Purchase Order Inquiry".
           02  LINE 8  COLUMN 8  VALUE " 3. Receiving".
           02  LINE 9  COLUMN 8  VALUE " 4. Purchase Entry".
           02  LINE 10 COLUMN 8  VALUE " 5. Purchase Return".
           02  LINE 14 COLUMN 8  VALUE " 0. Back".
           02  LINE 16.
             03  COLUMN 8  VALUE "Select :" COLOR YELLOW.
             03  COLUMN 18 PIC 9(2) USING WK-CHOICE.
       01  DS-MENU-INV.
           02  LINE 4  COLUMN 6  VALUE "INVENTORY / AR / AP" COLOR CYAN.
           02  LINE 6  COLUMN 8  VALUE " 1. Stock Inquiry".
           02  LINE 7  COLUMN 8  VALUE " 2. Stock Adjustment".
           02  LINE 8  COLUMN 8  VALUE " 3. Stocktaking".
           02  LINE 9  COLUMN 8  VALUE " 4. Movement Inquiry".
           02  LINE 10 COLUMN 8  VALUE " 5. Cash Receipt Entry".
           02  LINE 11 COLUMN 8  VALUE " 6. AR Inquiry".
           02  LINE 12 COLUMN 8  VALUE " 7. Payment Entry".
           02  LINE 13 COLUMN 8  VALUE " 8. AP Inquiry".
           02  LINE 6  COLUMN 36 VALUE " 9. Warehouse Transfer".
           02  LINE 14 COLUMN 8  VALUE " 0. Back".
           02  LINE 16.
             03  COLUMN 8  VALUE "Select :" COLOR YELLOW.
             03  COLUMN 18 PIC 9(2) USING WK-CHOICE.
       01  DS-MENU-RPT.
           02  LINE 4  COLUMN 6  VALUE "REPORTS" COLOR CYAN.
           02  LINE 6  COLUMN 8  VALUE " 1. Customer List".
           02  LINE 6  COLUMN 40 VALUE " 7. AR Aging".
           02  LINE 7  COLUMN 8  VALUE " 2. Product List".
           02  LINE 7  COLUMN 40 VALUE " 8. AP Balance".
           02  LINE 8  COLUMN 8  VALUE " 3. Sales Journal".
           02  LINE 8  COLUMN 40 VALUE " 9. Order Backlog".
           02  LINE 9  COLUMN 8  VALUE " 4. Sales by Customer".
           02  LINE 9  COLUMN 40 VALUE "10. Purchase Journal".
           02  LINE 10 COLUMN 8  VALUE " 5. Sales by Product".
           02  LINE 11 COLUMN 8  VALUE " 6. Inventory List".
           02  LINE 10 COLUMN 40 VALUE "11. Reorder Suggestion".
           02  LINE 11 COLUMN 40 VALUE "12. Sales Rep Perf".
           02  LINE 12 COLUMN 8  VALUE "13. Customer Statement".
           02  LINE 12 COLUMN 40 VALUE "14. Dead Stock".
           02  LINE 14 COLUMN 8  VALUE " 0. Back".
           02  LINE 16.
             03  COLUMN 8  VALUE "Select :" COLOR YELLOW.
             03  COLUMN 18 PIC 9(2) USING WK-CHOICE.
       01  DS-MENU-BAT.
           02  LINE 4  COLUMN 6  VALUE "BATCH / CLOSING" COLOR CYAN.
           02  LINE 6  COLUMN 8  VALUE " 1. Daily Close".
           02  LINE 7  COLUMN 8  VALUE " 2. Monthly Close".
           02  LINE 8  COLUMN 8  VALUE " 3. Stock Monthly Update".
           02  LINE 9  COLUMN 8  VALUE " 4. AR Balance Update".
           02  LINE 10 COLUMN 8  VALUE " 5. AP Balance Update".
           02  LINE 11 COLUMN 8  VALUE " 6. Purge / Archive".
           02  LINE 12 COLUMN 8  VALUE " 7. Fiscal Year Close".
           02  LINE 13 COLUMN 8  VALUE " 8. Reindex / Rebuild".
           02  LINE 6  COLUMN 36 VALUE " 9. Integrity Check".
           02  LINE 14 COLUMN 8  VALUE " 0. Back".
           02  LINE 16.
             03  COLUMN 8  VALUE "Select :" COLOR YELLOW.
             03  COLUMN 18 PIC 9(2) USING WK-CHOICE.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM SIGN-ON.
           IF NOT END-YES
               PERFORM MENU-LOOP UNTIL END-YES
           END-IF.
           PERFORM SIGN-OFF.
           STOP RUN.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "MENU00"           TO WK-PROGID.
           MOVE "SAKURA Sales Management System"  TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       SIGN-ON SECTION.
       SON-010.
           MOVE 0                  TO WK-LOGIN-TRY.
       SON-020.
           ADD 1                   TO WK-LOGIN-TRY.
           MOVE SPACE              TO KL-LOGIN KL-PASSWORD.
           DISPLAY DS-HEADER.
           MOVE "Enter login - PF3 to quit" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-LOGIN.
           ACCEPT  DS-LOGIN.
           IF ESTS = "03"
               SET END-YES TO TRUE
               GO TO SON-999
           END-IF.
           CALL "CHKLOG" USING KLOGIN.
           IF KL-STATUS = "00"
               MOVE KL-USER-CODE   TO WK-USER-CODE
               MOVE KL-USER-NAME   TO WK-USER-NAME
               MOVE KL-ROLE        TO WK-USER-ROLE
               MOVE KL-AUTH        TO WK-USER-AUTH
               GO TO SON-999
           END-IF.
           MOVE "Invalid login or password" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           IF WK-LOGIN-TRY >= 3
               MOVE "Too many attempts - exiting" TO WK-MSG-LINE
               DISPLAY DS-MSG
               SET END-YES TO TRUE
               GO TO SON-999
           END-IF.
           GO TO SON-020.
       SON-999.
           EXIT.
      *----------------------------------------------------------------
       MENU-LOOP SECTION.
       MLOOP-010.
           MOVE 0                  TO WK-CHOICE.
           DISPLAY DS-HEADER.
           MOVE WK-USER-NAME       TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-MAIN.
           ACCEPT  DS-MAIN.
           IF ESTS = "03"
               SET END-YES TO TRUE
               GO TO MLOOP-999
           END-IF.
           EVALUATE WK-CHOICE
               WHEN 0  SET END-YES TO TRUE
               WHEN 1  PERFORM SUB-MST
               WHEN 2  PERFORM SUB-ORD
               WHEN 3  PERFORM SUB-PUR
               WHEN 4  PERFORM SUB-INV
               WHEN 5  PERFORM SUB-INV
               WHEN 6  PERFORM SUB-RPT
               WHEN 7  PERFORM SUB-BAT
               WHEN OTHER
                   MOVE "Invalid selection" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MLOOP-999.
           EXIT.
      *----------------------------------------------------------------
       SUB-MST SECTION.
       SMST-010.
           MOVE 0                  TO WK-CHOICE.
           DISPLAY DS-HEADER.
           DISPLAY DS-MENU-MST.
           ACCEPT  DS-MENU-MST.
           IF ESTS = "03" OR WK-CHOICE = 0
               GO TO SMST-999
           END-IF.
           EVALUATE WK-CHOICE
               WHEN 1  MOVE "MS0010" TO WK-CALL
               WHEN 2  MOVE "MS0020" TO WK-CALL
               WHEN 3  MOVE "MS0030" TO WK-CALL
               WHEN 4  MOVE "MS0040" TO WK-CALL
               WHEN 5  MOVE "MS0050" TO WK-CALL
               WHEN 6  MOVE "MS0060" TO WK-CALL
               WHEN 7  MOVE "MS0070" TO WK-CALL
               WHEN 8  MOVE "MS0080" TO WK-CALL
               WHEN 9  MOVE "MS0090" TO WK-CALL
               WHEN 10 MOVE "MS0100" TO WK-CALL
               WHEN 11 MOVE "MS0110" TO WK-CALL
               WHEN 12 MOVE "MS0120" TO WK-CALL
               WHEN OTHER MOVE SPACE TO WK-CALL
           END-EVALUATE.
           PERFORM CALL-PROG.
           GO TO SMST-010.
       SMST-999.
           EXIT.
      *----------------------------------------------------------------
       SUB-ORD SECTION.
       SORD-010.
           MOVE 0                  TO WK-CHOICE.
           DISPLAY DS-HEADER.
           DISPLAY DS-MENU-ORD.
           ACCEPT  DS-MENU-ORD.
           IF ESTS = "03" OR WK-CHOICE = 0
               GO TO SORD-999
           END-IF.
           EVALUATE WK-CHOICE
               WHEN 1  MOVE "OE0010" TO WK-CALL
               WHEN 2  MOVE "OE0020" TO WK-CALL
               WHEN 3  MOVE "OE0030" TO WK-CALL
               WHEN 4  MOVE "SH0010" TO WK-CALL
               WHEN 5  MOVE "SL0010" TO WK-CALL
               WHEN 6  MOVE "SL0020" TO WK-CALL
               WHEN 7  MOVE "SL0030" TO WK-CALL
               WHEN 8  MOVE "OE0040" TO WK-CALL
               WHEN 9  MOVE "SL0040" TO WK-CALL
               WHEN 10 MOVE "OE0050" TO WK-CALL
               WHEN OTHER MOVE SPACE TO WK-CALL
           END-EVALUATE.
           PERFORM CALL-PROG.
           GO TO SORD-010.
       SORD-999.
           EXIT.
      *----------------------------------------------------------------
       SUB-PUR SECTION.
       SPUR-010.
           MOVE 0                  TO WK-CHOICE.
           DISPLAY DS-HEADER.
           DISPLAY DS-MENU-PUR.
           ACCEPT  DS-MENU-PUR.
           IF ESTS = "03" OR WK-CHOICE = 0
               GO TO SPUR-999
           END-IF.
           EVALUATE WK-CHOICE
               WHEN 1  MOVE "PU0010" TO WK-CALL
               WHEN 2  MOVE "PU0020" TO WK-CALL
               WHEN 3  MOVE "RC0010" TO WK-CALL
               WHEN 4  MOVE "PU0030" TO WK-CALL
               WHEN 5  MOVE "PU0040" TO WK-CALL
               WHEN OTHER MOVE SPACE TO WK-CALL
           END-EVALUATE.
           PERFORM CALL-PROG.
           GO TO SPUR-010.
       SPUR-999.
           EXIT.
      *----------------------------------------------------------------
       SUB-INV SECTION.
       SINV-010.
           MOVE 0                  TO WK-CHOICE.
           DISPLAY DS-HEADER.
           DISPLAY DS-MENU-INV.
           ACCEPT  DS-MENU-INV.
           IF ESTS = "03" OR WK-CHOICE = 0
               GO TO SINV-999
           END-IF.
           EVALUATE WK-CHOICE
               WHEN 1  MOVE "IV0010" TO WK-CALL
               WHEN 2  MOVE "IV0020" TO WK-CALL
               WHEN 3  MOVE "IV0030" TO WK-CALL
               WHEN 4  MOVE "IV0040" TO WK-CALL
               WHEN 5  MOVE "AR0010" TO WK-CALL
               WHEN 6  MOVE "AR0020" TO WK-CALL
               WHEN 7  MOVE "AP0010" TO WK-CALL
               WHEN 8  MOVE "AP0020" TO WK-CALL
               WHEN 9  MOVE "IV0050" TO WK-CALL
               WHEN OTHER MOVE SPACE TO WK-CALL
           END-EVALUATE.
           PERFORM CALL-PROG.
           GO TO SINV-010.
       SINV-999.
           EXIT.
      *----------------------------------------------------------------
       SUB-RPT SECTION.
       SRPT-010.
           MOVE 0                  TO WK-CHOICE.
           DISPLAY DS-HEADER.
           DISPLAY DS-MENU-RPT.
           ACCEPT  DS-MENU-RPT.
           IF ESTS = "03" OR WK-CHOICE = 0
               GO TO SRPT-999
           END-IF.
           EVALUATE WK-CHOICE
               WHEN 1  MOVE "RP0010" TO WK-CALL
               WHEN 2  MOVE "RP0020" TO WK-CALL
               WHEN 3  MOVE "RP0030" TO WK-CALL
               WHEN 4  MOVE "RP0040" TO WK-CALL
               WHEN 5  MOVE "RP0050" TO WK-CALL
               WHEN 6  MOVE "RP0060" TO WK-CALL
               WHEN 7  MOVE "RP0070" TO WK-CALL
               WHEN 8  MOVE "RP0080" TO WK-CALL
               WHEN 9  MOVE "RP0090" TO WK-CALL
               WHEN 10 MOVE "RP0100" TO WK-CALL
               WHEN 11 MOVE "RP0110" TO WK-CALL
               WHEN 12 MOVE "RP0120" TO WK-CALL
               WHEN 13 MOVE "RP0130" TO WK-CALL
               WHEN 14 MOVE "RP0140" TO WK-CALL
               WHEN OTHER MOVE SPACE TO WK-CALL
           END-EVALUATE.
           PERFORM CALL-PROG.
           GO TO SRPT-010.
       SRPT-999.
           EXIT.
      *----------------------------------------------------------------
       SUB-BAT SECTION.
       SBAT-010.
           IF WK-USER-AUTH (5:1) NOT = "1"
               MOVE "Not authorised for batch/closing" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO SBAT-999
           END-IF.
           MOVE 0                  TO WK-CHOICE.
           DISPLAY DS-HEADER.
           DISPLAY DS-MENU-BAT.
           ACCEPT  DS-MENU-BAT.
           IF ESTS = "03" OR WK-CHOICE = 0
               GO TO SBAT-999
           END-IF.
           EVALUATE WK-CHOICE
               WHEN 1  MOVE "BT0010" TO WK-CALL
               WHEN 2  MOVE "BT0020" TO WK-CALL
               WHEN 3  MOVE "BT0030" TO WK-CALL
               WHEN 4  MOVE "BT0040" TO WK-CALL
               WHEN 5  MOVE "BT0050" TO WK-CALL
               WHEN 6  MOVE "BT0060" TO WK-CALL
               WHEN 7  MOVE "BT0070" TO WK-CALL
               WHEN 8  MOVE "BT0080" TO WK-CALL
               WHEN 9  MOVE "BT0090" TO WK-CALL
               WHEN OTHER MOVE SPACE TO WK-CALL
           END-EVALUATE.
           PERFORM CALL-PROG.
           GO TO SBAT-010.
       SBAT-999.
           EXIT.
      *----------------------------------------------------------------
       CALL-PROG SECTION.
       CPRG-010.
           IF WK-CALL = SPACE
               MOVE "Invalid selection" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO CPRG-999
           END-IF.
           EVALUATE WK-CALL
               WHEN "MS0010" CALL "MS0010"
               WHEN "MS0020" CALL "MS0020"
               WHEN "MS0030" CALL "MS0030"
               WHEN "MS0040" CALL "MS0040"
               WHEN "MS0050" CALL "MS0050"
               WHEN "MS0060" CALL "MS0060"
               WHEN "MS0070" CALL "MS0070"
               WHEN "MS0080" CALL "MS0080"
               WHEN "MS0090" CALL "MS0090"
               WHEN "MS0100" CALL "MS0100"
               WHEN "MS0110" CALL "MS0110"
               WHEN "MS0120" CALL "MS0120"
               WHEN "OE0010" CALL "OE0010"
               WHEN "OE0020" CALL "OE0020"
               WHEN "OE0030" CALL "OE0030"
               WHEN "OE0040" CALL "OE0040"
               WHEN "OE0050" CALL "OE0050"
               WHEN "SH0010" CALL "SH0010"
               WHEN "SL0010" CALL "SL0010"
               WHEN "SL0020" CALL "SL0020"
               WHEN "SL0030" CALL "SL0030"
               WHEN "SL0040" CALL "SL0040"
               WHEN "PU0010" CALL "PU0010"
               WHEN "PU0020" CALL "PU0020"
               WHEN "PU0030" CALL "PU0030"
               WHEN "PU0040" CALL "PU0040"
               WHEN "RC0010" CALL "RC0010"
               WHEN "IV0010" CALL "IV0010"
               WHEN "IV0020" CALL "IV0020"
               WHEN "IV0030" CALL "IV0030"
               WHEN "IV0040" CALL "IV0040"
               WHEN "IV0050" CALL "IV0050"
               WHEN "AR0010" CALL "AR0010"
               WHEN "AR0020" CALL "AR0020"
               WHEN "AP0010" CALL "AP0010"
               WHEN "AP0020" CALL "AP0020"
               WHEN "RP0010" CALL "RP0010"
               WHEN "RP0020" CALL "RP0020"
               WHEN "RP0030" CALL "RP0030"
               WHEN "RP0040" CALL "RP0040"
               WHEN "RP0050" CALL "RP0050"
               WHEN "RP0060" CALL "RP0060"
               WHEN "RP0070" CALL "RP0070"
               WHEN "RP0080" CALL "RP0080"
               WHEN "RP0090" CALL "RP0090"
               WHEN "RP0100" CALL "RP0100"
               WHEN "RP0110" CALL "RP0110"
               WHEN "RP0120" CALL "RP0120"
               WHEN "RP0130" CALL "RP0130"
               WHEN "RP0140" CALL "RP0140"
               WHEN "BT0010" CALL "BT0010"
               WHEN "BT0020" CALL "BT0020"
               WHEN "BT0030" CALL "BT0030"
               WHEN "BT0040" CALL "BT0040"
               WHEN "BT0050" CALL "BT0050"
               WHEN "BT0060" CALL "BT0060"
               WHEN "BT0070" CALL "BT0070"
               WHEN "BT0080" CALL "BT0080"
               WHEN "BT0090" CALL "BT0090"
               WHEN OTHER
                   MOVE "Program not available yet" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       CPRG-999.
           EXIT.
      *----------------------------------------------------------------
       SIGN-OFF SECTION.
       SOFF-010.
           DISPLAY DS-HEADER.
           MOVE "Signed off - thank you" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       SOFF-999.
           EXIT.
