       IDENTIFICATION DIVISION.
       PROGRAM-ID. NUMGEN.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : NUMGEN  -  next document-number assigner (採番)   *
      *  FUNCTION : reads NUMCF by key, increments and returns the   *
      *             next sequential number for the requested series. *
      *  CALL     : CALL "NUMGEN" USING KNUM.                        *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SNUMC.
       DATA DIVISION.
       FILE SECTION.
           COPY FNUMC.
       WORKING-STORAGE SECTION.
       01  FSTS                    PIC X(2)  VALUE "00".
       LINKAGE SECTION.
       01  KNUM.
           02  KNUM-KEY            PIC X(8).
           02  KNUM-NUMBER         PIC 9(10).
           02  KNUM-STATUS         PIC X(2).
       PROCEDURE DIVISION USING KNUM.
       MAIN SECTION.
       MAIN-000.
           MOVE "00"               TO KNUM-STATUS.
           PERFORM OPEN-FILE.
           IF FSTS NOT = "00"
               MOVE "99"           TO KNUM-STATUS
               CLOSE NUMCF
               EXIT PROGRAM
           END-IF.
           PERFORM ASSIGN-NUMBER.
           CLOSE NUMCF.
           EXIT PROGRAM.
      *-----------------------------------------------------------------
       OPEN-FILE SECTION.
       OPEN-010.
           OPEN I-O NUMCF.
           IF FSTS = "35" OR FSTS = "30"
      *        file does not exist yet - create an empty one
               OPEN OUTPUT NUMCF
               CLOSE NUMCF
               OPEN I-O NUMCF
           END-IF.
       OPEN-999.
           EXIT.
      *-----------------------------------------------------------------
       ASSIGN-NUMBER SECTION.
       ASSIGN-010.
           MOVE KNUM-KEY           TO NM-KEY.
           READ NUMCF
               INVALID KEY
                   PERFORM CREATE-SERIES
               NOT INVALID KEY
                   ADD 1           TO NM-CURRENT
                   REWRITE NM-REC
                       INVALID KEY
                           MOVE "99" TO KNUM-STATUS
                   END-REWRITE
                   MOVE NM-CURRENT TO KNUM-NUMBER
           END-READ.
       ASSIGN-999.
           EXIT.
      *-----------------------------------------------------------------
       CREATE-SERIES SECTION.
       CREATE-010.
           INITIALIZE NM-REC.
           MOVE KNUM-KEY           TO NM-KEY.
           MOVE SPACE              TO NM-PREFIX.
           MOVE 10                 TO NM-WIDTH.
           MOVE 1                  TO NM-CURRENT.
           WRITE NM-REC
               INVALID KEY
                   MOVE "99"       TO KNUM-STATUS
           END-WRITE.
           MOVE NM-CURRENT         TO KNUM-NUMBER.
       CREATE-999.
           EXIT.
