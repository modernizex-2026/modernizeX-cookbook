       IDENTIFICATION DIVISION.
       PROGRAM-ID. ABORTX.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : ABORTX  -  fatal-error logger                    *
      *  FUNCTION : appends an abend record to reports/ABEND.LOG and *
      *             echoes it to the console.                        *
      *  CALL     : CALL "ABORTX" USING KABEND.                      *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT LOGF ASSIGN TO LOGF-MSD
                  ORGANIZATION LINE SEQUENTIAL
                  FILE STATUS FSTS.
       DATA DIVISION.
       FILE SECTION.
       FD  LOGF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "ABEND.LOG".
       01  LOG-REC                 PIC X(120).
       WORKING-STORAGE SECTION.
       01  FSTS                    PIC X(2)  VALUE "00".
       01  WK-LINE.
           02  FILLER              PIC X(6)  VALUE "ABEND ".
           02  WL-PROGID           PIC X(6).
           02  FILLER              PIC X(2)  VALUE " F".
           02  WL-FILE             PIC X(8).
           02  FILLER              PIC X(2)  VALUE " S".
           02  WL-FSTS             PIC X(2).
           02  FILLER              PIC X(2)  VALUE " M".
           02  WL-MSGCODE          PIC X(6).
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WL-DETAIL           PIC X(40).
       LINKAGE SECTION.
       01  KABEND.
           02  KA-PROGID           PIC X(6).
           02  KA-FILE             PIC X(8).
           02  KA-FSTS             PIC X(2).
           02  KA-MSGCODE          PIC X(6).
           02  KA-DETAIL           PIC X(40).
       PROCEDURE DIVISION USING KABEND.
       MAIN SECTION.
       MAIN-000.
           MOVE KA-PROGID          TO WL-PROGID.
           MOVE KA-FILE            TO WL-FILE.
           MOVE KA-FSTS            TO WL-FSTS.
           MOVE KA-MSGCODE         TO WL-MSGCODE.
           MOVE KA-DETAIL          TO WL-DETAIL.
           DISPLAY "*** SAKURA-SMS ABEND ***".
           DISPLAY WK-LINE.
           OPEN EXTEND LOGF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT LOGF
           END-IF.
           IF FSTS = "00"
               MOVE WK-LINE        TO LOG-REC
               WRITE LOG-REC
               CLOSE LOGF
           END-IF.
           EXIT PROGRAM.
