       IDENTIFICATION DIVISION.
       PROGRAM-ID. CREDIT.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : CREDIT  -  customer credit-limit check           *
      *  FUNCTION : given a customer code and an additional amount,   *
      *             read CUSTF and report whether the customer's      *
      *             current balance plus the additional amount would  *
      *             exceed the customer credit limit.  A limit of     *
      *             zero is treated as "no limit" (never exceeded).   *
      *  CALL     : CALL "CREDIT" USING KCRED.                       *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SCUST.
       DATA DIVISION.
       FILE SECTION.
           COPY FCUST.
       WORKING-STORAGE SECTION.
       01  FSTS                    PIC X(2)  VALUE "00".
       LINKAGE SECTION.
       01  KCRED.
           02  KC-CUST             PIC 9(6).
           02  KC-AMOUNT           PIC S9(11) COMP-3.
           02  KC-LIMIT            PIC S9(11) COMP-3.
           02  KC-BALANCE          PIC S9(11) COMP-3.
           02  KC-NEWBAL           PIC S9(11) COMP-3.
           02  KC-EXCEED           PIC 9(1).
           02  KC-STATUS           PIC X(2).
      *----------------------------------------------------------------
       PROCEDURE DIVISION USING KCRED.
       MAIN SECTION.
       MAIN-000.
           MOVE "00"               TO KC-STATUS.
           MOVE 0                  TO KC-EXCEED.
           MOVE 0                  TO KC-LIMIT KC-BALANCE KC-NEWBAL.
           PERFORM OPEN-FILE.
           IF FSTS NOT = "00"
               MOVE "99"           TO KC-STATUS
               PERFORM CLOSE-FILE
               EXIT PROGRAM
           END-IF.
           PERFORM CHECK-CREDIT.
           PERFORM CLOSE-FILE.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       OPEN-FILE SECTION.
       OPEN-010.
           OPEN INPUT CUSTF.
           IF FSTS = "35" OR FSTS = "30"
      *        no customer file yet - nothing to check against
               OPEN OUTPUT CUSTF
               CLOSE CUSTF
               OPEN INPUT CUSTF
           END-IF.
       OPEN-999.
           EXIT.
      *----------------------------------------------------------------
       CLOSE-FILE SECTION.
       CLOSE-010.
           CLOSE CUSTF.
       CLOSE-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-CREDIT SECTION.
       CHK-010.
           MOVE KC-CUST            TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "99"       TO KC-STATUS
                   GO TO CHK-999
           END-READ.
           MOVE CU-CREDIT-LIMIT    TO KC-LIMIT.
           MOVE CU-BALANCE         TO KC-BALANCE.
           COMPUTE KC-NEWBAL = CU-BALANCE + KC-AMOUNT.
           IF KC-LIMIT > 0 AND KC-NEWBAL > KC-LIMIT
               MOVE 1              TO KC-EXCEED
           ELSE
               MOVE 0              TO KC-EXCEED
           END-IF.
       CHK-999.
           EXIT.
