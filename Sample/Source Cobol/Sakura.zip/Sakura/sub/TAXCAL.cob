       IDENTIFICATION DIVISION.
       PROGRAM-ID. TAXCAL.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : TAXCAL  -  consumption-tax calculator            *
      *  FUNCTION : looks up the effective rate for a tax category   *
      *             from TAXF, then splits net / tax / gross by the  *
      *             requested tax type and rounding rule.            *
      *  CALL     : CALL "TAXCAL" USING KTAX.                        *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY STAX.
       DATA DIVISION.
       FILE SECTION.
           COPY FTAX.
       WORKING-STORAGE SECTION.
       01  FSTS                    PIC X(2)  VALUE "00".
       01  WK-RATE                 PIC S9(2)V9(3) VALUE 0.
       01  WK-FOUND                PIC 9(1)  VALUE 0.
       01  WK-RAW                  PIC S9(13)V9(5) VALUE 0.
       01  WK-INT                  PIC S9(13)     VALUE 0.
       01  WK-FRAC                 PIC S9(13)V9(5) VALUE 0.
       LINKAGE SECTION.
       01  KTAX.
           02  KT-CATEGORY         PIC 9(1).
           02  KT-TAX-TYPE         PIC 9(1).
           02  KT-ROUND            PIC 9(1).
           02  KT-DATE             PIC 9(8).
           02  KT-AMOUNT           PIC S9(11)     COMP-3.
           02  KT-TAX              PIC S9(11)     COMP-3.
           02  KT-NET              PIC S9(11)     COMP-3.
           02  KT-GROSS            PIC S9(11)     COMP-3.
           02  KT-RATE             PIC S9(2)V9(3) COMP-3.
           02  KT-STATUS           PIC X(2).
       PROCEDURE DIVISION USING KTAX.
       MAIN SECTION.
       MAIN-000.
           MOVE "00"               TO KT-STATUS.
           MOVE 0                  TO KT-TAX  KT-NET  KT-GROSS.
      *    exempt category => no tax, net = gross = amount
           IF KT-CATEGORY = 3 OR KT-TAX-TYPE = 3
               MOVE KT-AMOUNT      TO KT-NET  KT-GROSS
               MOVE 0              TO KT-RATE
               EXIT PROGRAM
           END-IF.
           PERFORM FIND-RATE.
           MOVE WK-RATE            TO KT-RATE.
           PERFORM COMPUTE-TAX.
           EXIT PROGRAM.
      *-----------------------------------------------------------------
       FIND-RATE SECTION.
       FIND-010.
           MOVE 0                  TO WK-FOUND.
           MOVE 0                  TO WK-RATE.
           OPEN INPUT TAXF.
           IF FSTS NOT = "00"
               PERFORM DEFAULT-RATE
               GO TO FIND-999
           END-IF.
           MOVE KT-CATEGORY        TO TX-CODE.
           MOVE 0                  TO TX-START-DATE.
           START TAXF KEY IS NOT LESS THAN TX-CODE TX-START-DATE
               INVALID KEY
                   CONTINUE
           END-START.
           IF FSTS = "00"
               PERFORM SCAN-RATES
           END-IF.
           CLOSE TAXF.
           IF WK-FOUND = 0
               PERFORM DEFAULT-RATE
           END-IF.
       FIND-999.
           EXIT.
      *-----------------------------------------------------------------
       SCAN-RATES SECTION.
       SCAN-010.
           READ TAXF NEXT
               AT END
                   GO TO SCAN-999
           END-READ.
           IF TX-CODE NOT = KT-CATEGORY
               GO TO SCAN-999
           END-IF.
           IF TX-START-DATE <= KT-DATE
               MOVE TX-RATE        TO WK-RATE
               MOVE 1              TO WK-FOUND
           END-IF.
           GO TO SCAN-010.
       SCAN-999.
           EXIT.
      *-----------------------------------------------------------------
       DEFAULT-RATE SECTION.
       DEF-010.
      *    fallback statutory defaults if the tax master is unavailable
           IF KT-CATEGORY = 2
               MOVE 0.080          TO WK-RATE
           ELSE
               MOVE 0.100          TO WK-RATE
           END-IF.
       DEF-999.
           EXIT.
      *-----------------------------------------------------------------
       COMPUTE-TAX SECTION.
       CT-010.
           IF KT-TAX-TYPE = 2
      *        tax-inclusive : back out the tax from the gross amount
               MOVE KT-AMOUNT      TO KT-GROSS
               COMPUTE WK-RAW = KT-GROSS * WK-RATE / (1 + WK-RATE)
               PERFORM APPLY-ROUND
               MOVE WK-INT         TO KT-TAX
               COMPUTE KT-NET = KT-GROSS - KT-TAX
           ELSE
      *        tax-exclusive : add tax on top of the net amount
               MOVE KT-AMOUNT      TO KT-NET
               COMPUTE WK-RAW = KT-NET * WK-RATE
               PERFORM APPLY-ROUND
               MOVE WK-INT         TO KT-TAX
               COMPUTE KT-GROSS = KT-NET + KT-TAX
           END-IF.
       CT-999.
           EXIT.
      *-----------------------------------------------------------------
       APPLY-ROUND SECTION.
       AR-010.
           COMPUTE WK-INT  = WK-RAW.
           COMPUTE WK-FRAC = WK-RAW - WK-INT.
           EVALUATE KT-ROUND
               WHEN 2
      *            floor : already truncated toward zero
                   CONTINUE
               WHEN 3
      *            ceil : bump up if any fraction remained
                   IF WK-FRAC > 0
                       ADD 1       TO WK-INT
                   END-IF
               WHEN OTHER
      *            round half up
                   IF WK-FRAC >= 0.5
                       ADD 1       TO WK-INT
                   END-IF
           END-EVALUATE.
       AR-999.
           EXIT.
