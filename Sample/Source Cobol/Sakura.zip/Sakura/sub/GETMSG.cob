       IDENTIFICATION DIVISION.
       PROGRAM-ID. GETMSG.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : GETMSG  -  message-text retriever                *
      *  FUNCTION : returns the text for a message code from MSGF.   *
      *             If not found, returns the code itself.           *
      *  CALL     : CALL "GETMSG" USING KMSG.                        *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SMSG.
       DATA DIVISION.
       FILE SECTION.
           COPY FMSG.
       WORKING-STORAGE SECTION.
       01  FSTS                    PIC X(2)  VALUE "00".
       LINKAGE SECTION.
       01  KMSG.
           02  KM-CODE             PIC X(6).
           02  KM-TEXT             PIC X(60).
           02  KM-STATUS           PIC X(2).
       PROCEDURE DIVISION USING KMSG.
       MAIN SECTION.
       MAIN-000.
           MOVE "00"               TO KM-STATUS.
           MOVE SPACE              TO KM-TEXT.
           OPEN INPUT MSGF.
           IF FSTS NOT = "00"
               MOVE KM-CODE        TO KM-TEXT
               MOVE "99"           TO KM-STATUS
               EXIT PROGRAM
           END-IF.
           MOVE KM-CODE            TO MG-CODE.
           READ MSGF
               INVALID KEY
                   MOVE KM-CODE    TO KM-TEXT
                   MOVE "01"       TO KM-STATUS
               NOT INVALID KEY
                   MOVE MG-TEXT    TO KM-TEXT
           END-READ.
           CLOSE MSGF.
           EXIT PROGRAM.
