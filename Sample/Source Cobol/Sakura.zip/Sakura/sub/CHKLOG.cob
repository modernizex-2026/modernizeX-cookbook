       IDENTIFICATION DIVISION.
       PROGRAM-ID. CHKLOG.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : CHKLOG  -  login / authority validator           *
      *  FUNCTION : validates login + password against USERF and     *
      *             returns operator code, name, role and authority. *
      *  CALL     : CALL "CHKLOG" USING KLOGIN.                      *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SUSER.
       DATA DIVISION.
       FILE SECTION.
           COPY FUSER.
       WORKING-STORAGE SECTION.
       01  FSTS                    PIC X(2)  VALUE "00".
       01  WK-AUTH                 PIC X(5)  VALUE SPACE.
       LINKAGE SECTION.
       01  KLOGIN.
           02  KL-LOGIN            PIC X(12).
           02  KL-PASSWORD         PIC X(16).
           02  KL-USER-CODE        PIC 9(6).
           02  KL-USER-NAME        PIC X(30).
           02  KL-ROLE             PIC 9(1).
           02  KL-AUTH             PIC X(5).
           02  KL-STATUS           PIC X(2).
       PROCEDURE DIVISION USING KLOGIN.
       MAIN SECTION.
       MAIN-000.
           MOVE "00"               TO KL-STATUS.
           MOVE 0                  TO KL-USER-CODE.
           MOVE SPACE              TO KL-USER-NAME.
           MOVE 0                  TO KL-ROLE.
           MOVE SPACE              TO KL-AUTH.
           OPEN INPUT USERF.
           IF FSTS NOT = "00"
               MOVE "99"           TO KL-STATUS
               EXIT PROGRAM
           END-IF.
           MOVE KL-LOGIN           TO US-LOGIN.
           READ USERF KEY IS US-LOGIN
               INVALID KEY
                   MOVE "99"       TO KL-STATUS
               NOT INVALID KEY
                   PERFORM CHECK-USER
           END-READ.
           CLOSE USERF.
           EXIT PROGRAM.
      *-----------------------------------------------------------------
       CHECK-USER SECTION.
       CHECK-010.
           IF US-DEL-FLAG = 1
               MOVE "99"           TO KL-STATUS
               GO TO CHECK-999
           END-IF.
           IF US-PASSWORD NOT = KL-PASSWORD
               MOVE "99"           TO KL-STATUS
               GO TO CHECK-999
           END-IF.
           MOVE US-CODE            TO KL-USER-CODE.
           MOVE US-NAME            TO KL-USER-NAME.
           MOVE US-ROLE            TO KL-ROLE.
           MOVE US-AUTH-MASTER     TO WK-AUTH(1:1).
           MOVE US-AUTH-ORDER      TO WK-AUTH(2:1).
           MOVE US-AUTH-SALES      TO WK-AUTH(3:1).
           MOVE US-AUTH-PURCH      TO WK-AUTH(4:1).
           MOVE US-AUTH-CLOSE      TO WK-AUTH(5:1).
           MOVE WK-AUTH            TO KL-AUTH.
       CHECK-999.
           EXIT.
