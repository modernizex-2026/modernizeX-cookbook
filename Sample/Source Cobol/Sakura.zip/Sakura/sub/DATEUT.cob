       IDENTIFICATION DIVISION.
       PROGRAM-ID. DATEUT.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : DATEUT  -  date utility (YYYYMMDD)               *
      *  FUNCTION : TODY today / VALD validate / ADDD add days /     *
      *             DIFF day difference / EOM end-of-month /         *
      *             YOBI weekday (0=Sun..6=Sat).                     *
      *  METHOD   : conversion to/from a serial day number using the *
      *             days-from-civil integer algorithm.               *
      *  CALL     : CALL "DATEUT" USING KDATE.                       *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WK-Y                    PIC S9(9)  VALUE 0.
       01  WK-M                    PIC S9(9)  VALUE 0.
       01  WK-D                    PIC S9(9)  VALUE 0.
       01  WK-Y2                   PIC S9(9)  VALUE 0.
       01  WK-ERA                  PIC S9(9)  VALUE 0.
       01  WK-YOE                  PIC S9(9)  VALUE 0.
       01  WK-MP                   PIC S9(9)  VALUE 0.
       01  WK-DOY                  PIC S9(9)  VALUE 0.
       01  WK-DOE                  PIC S9(9)  VALUE 0.
       01  WK-SER                  PIC S9(9)  VALUE 0.
       01  WK-SER2                 PIC S9(9)  VALUE 0.
       01  WK-Z                    PIC S9(9)  VALUE 0.
       01  WK-TMP                  PIC S9(9)  VALUE 0.
       01  WK-DIM                  PIC 9(2)   VALUE 0.
       01  WK-6                    PIC 9(6)   VALUE 0.
       01  WK-YY                   PIC 9(2)   VALUE 0.
       01  WK-LEAP                 PIC 9(1)   VALUE 0.
       LINKAGE SECTION.
       01  KDATE.
           02  KD-FUNC             PIC X(4).
           02  KD-DATE1            PIC 9(8).
           02  KD-DATE2            PIC 9(8).
           02  KD-DAYS             PIC S9(7).
           02  KD-WEEKDAY          PIC 9(1).
           02  KD-STATUS           PIC X(2).
       PROCEDURE DIVISION USING KDATE.
       MAIN SECTION.
       MAIN-000.
           MOVE "00"               TO KD-STATUS.
           EVALUATE KD-FUNC
               WHEN "TODY"         PERFORM FN-TODAY
               WHEN "VALD"         PERFORM FN-VALIDATE
               WHEN "ADDD"         PERFORM FN-ADDDAYS
               WHEN "DIFF"         PERFORM FN-DIFF
               WHEN "EOM "         PERFORM FN-EOM
               WHEN "EOM"          PERFORM FN-EOM
               WHEN "YOBI"         PERFORM FN-WEEKDAY
               WHEN OTHER          MOVE "99" TO KD-STATUS
           END-EVALUATE.
           EXIT PROGRAM.
      *-----------------------------------------------------------------
       FN-TODAY SECTION.
       FN-TODAY-010.
           ACCEPT WK-6 FROM DATE.
           COMPUTE WK-YY = WK-6 / 10000.
           COMPUTE WK-M  = (WK-6 - WK-YY * 10000) / 100.
           COMPUTE WK-D  =  WK-6 - (WK-6 / 100) * 100.
           IF WK-YY < 80
               COMPUTE WK-Y = 2000 + WK-YY
           ELSE
               COMPUTE WK-Y = 1900 + WK-YY
           END-IF.
           PERFORM BUILD-DATE1.
           PERFORM TO-SERIAL.
           PERFORM CALC-WEEKDAY.
       FN-TODAY-999.
           EXIT.
      *-----------------------------------------------------------------
       FN-VALIDATE SECTION.
       FN-VALIDATE-010.
           PERFORM PARSE-DATE1.
           IF WK-Y < 1900 OR WK-Y > 2999
               MOVE "99" TO KD-STATUS
               GO TO FN-VALIDATE-999
           END-IF.
           IF WK-M < 1 OR WK-M > 12
               MOVE "99" TO KD-STATUS
               GO TO FN-VALIDATE-999
           END-IF.
           PERFORM DAYS-IN-MONTH.
           IF WK-D < 1 OR WK-D > WK-DIM
               MOVE "99" TO KD-STATUS
           END-IF.
       FN-VALIDATE-999.
           EXIT.
      *-----------------------------------------------------------------
       FN-ADDDAYS SECTION.
       FN-ADDDAYS-010.
           PERFORM PARSE-DATE1.
           PERFORM TO-SERIAL.
           ADD KD-DAYS TO WK-SER.
           PERFORM FROM-SERIAL.
           PERFORM BUILD-DATE1.
       FN-ADDDAYS-999.
           EXIT.
      *-----------------------------------------------------------------
       FN-DIFF SECTION.
       FN-DIFF-010.
           PERFORM PARSE-DATE1.
           PERFORM TO-SERIAL.
           MOVE WK-SER             TO WK-SER2.
           MOVE KD-DATE2           TO KD-DATE1.
           PERFORM PARSE-DATE1.
           PERFORM TO-SERIAL.
           COMPUTE KD-DAYS = WK-SER - WK-SER2.
       FN-DIFF-999.
           EXIT.
      *-----------------------------------------------------------------
       FN-EOM SECTION.
       FN-EOM-010.
           PERFORM PARSE-DATE1.
           MOVE 1                  TO WK-D.
           ADD 1                   TO WK-M.
           IF WK-M > 12
               MOVE 1              TO WK-M
               ADD 1               TO WK-Y
           END-IF.
           PERFORM BUILD-DATE1.
           PERFORM PARSE-DATE1.
           PERFORM TO-SERIAL.
           SUBTRACT 1              FROM WK-SER.
           PERFORM FROM-SERIAL.
           PERFORM BUILD-DATE1.
       FN-EOM-999.
           EXIT.
      *-----------------------------------------------------------------
       FN-WEEKDAY SECTION.
       FN-WEEKDAY-010.
           PERFORM PARSE-DATE1.
           PERFORM TO-SERIAL.
           PERFORM CALC-WEEKDAY.
       FN-WEEKDAY-999.
           EXIT.
      *-----------------------------------------------------------------
       PARSE-DATE1 SECTION.
       PARSE-010.
           COMPUTE WK-Y = KD-DATE1 / 10000.
           COMPUTE WK-M = (KD-DATE1 - WK-Y * 10000) / 100.
           COMPUTE WK-D =  KD-DATE1 - WK-Y * 10000 - WK-M * 100.
       PARSE-999.
           EXIT.
      *-----------------------------------------------------------------
       BUILD-DATE1 SECTION.
       BUILD-010.
           COMPUTE KD-DATE1 = WK-Y * 10000 + WK-M * 100 + WK-D.
       BUILD-999.
           EXIT.
      *-----------------------------------------------------------------
       TO-SERIAL SECTION.
       TOSER-010.
           MOVE WK-Y               TO WK-Y2.
           IF WK-M <= 2
               SUBTRACT 1          FROM WK-Y2
           END-IF.
           COMPUTE WK-ERA = WK-Y2 / 400.
           COMPUTE WK-YOE = WK-Y2 - WK-ERA * 400.
           IF WK-M > 2
               COMPUTE WK-MP = WK-M - 3
           ELSE
               COMPUTE WK-MP = WK-M + 9
           END-IF.
           COMPUTE WK-DOY = (153 * WK-MP + 2) / 5 + WK-D - 1.
           COMPUTE WK-DOE = WK-YOE * 365 + WK-YOE / 4
                          - WK-YOE / 100 + WK-DOY.
           COMPUTE WK-SER = WK-ERA * 146097 + WK-DOE - 719468.
       TOSER-999.
           EXIT.
      *-----------------------------------------------------------------
       FROM-SERIAL SECTION.
       FRSER-010.
           COMPUTE WK-Z   = WK-SER + 719468.
           COMPUTE WK-ERA = WK-Z / 146097.
           COMPUTE WK-DOE = WK-Z - WK-ERA * 146097.
           COMPUTE WK-YOE = (WK-DOE - WK-DOE / 1460
                          + WK-DOE / 36524 - WK-DOE / 146096) / 365.
           COMPUTE WK-Y   = WK-YOE + WK-ERA * 400.
           COMPUTE WK-DOY = WK-DOE
                          - (365 * WK-YOE + WK-YOE / 4 - WK-YOE / 100).
           COMPUTE WK-MP  = (5 * WK-DOY + 2) / 153.
           COMPUTE WK-D   = WK-DOY - (153 * WK-MP + 2) / 5 + 1.
           IF WK-MP < 10
               COMPUTE WK-M = WK-MP + 3
           ELSE
               COMPUTE WK-M = WK-MP - 9
           END-IF.
           IF WK-M <= 2
               ADD 1               TO WK-Y
           END-IF.
       FRSER-999.
           EXIT.
      *-----------------------------------------------------------------
       CALC-WEEKDAY SECTION.
       CWD-010.
           COMPUTE WK-TMP = WK-SER + 4.
           COMPUTE WK-TMP = WK-TMP - (WK-TMP / 7) * 7.
           IF WK-TMP < 0
               ADD 7               TO WK-TMP
           END-IF.
           MOVE WK-TMP             TO KD-WEEKDAY.
       CWD-999.
           EXIT.
      *-----------------------------------------------------------------
       DAYS-IN-MONTH SECTION.
       DIM-010.
           MOVE 0                  TO WK-LEAP.
           COMPUTE WK-TMP = WK-Y - (WK-Y / 4) * 4.
           IF WK-TMP = 0
               MOVE 1              TO WK-LEAP
           END-IF.
           COMPUTE WK-TMP = WK-Y - (WK-Y / 100) * 100.
           IF WK-TMP = 0
               MOVE 0              TO WK-LEAP
           END-IF.
           COMPUTE WK-TMP = WK-Y - (WK-Y / 400) * 400.
           IF WK-TMP = 0
               MOVE 1              TO WK-LEAP
           END-IF.
           EVALUATE WK-M
               WHEN 1  MOVE 31 TO WK-DIM
               WHEN 2  IF WK-LEAP = 1
                           MOVE 29 TO WK-DIM
                       ELSE
                           MOVE 28 TO WK-DIM
                       END-IF
               WHEN 3  MOVE 31 TO WK-DIM
               WHEN 4  MOVE 30 TO WK-DIM
               WHEN 5  MOVE 31 TO WK-DIM
               WHEN 6  MOVE 30 TO WK-DIM
               WHEN 7  MOVE 31 TO WK-DIM
               WHEN 8  MOVE 31 TO WK-DIM
               WHEN 9  MOVE 30 TO WK-DIM
               WHEN 10 MOVE 31 TO WK-DIM
               WHEN 11 MOVE 30 TO WK-DIM
               WHEN 12 MOVE 31 TO WK-DIM
               WHEN OTHER MOVE 0 TO WK-DIM
           END-EVALUATE.
       DIM-999.
           EXIT.
