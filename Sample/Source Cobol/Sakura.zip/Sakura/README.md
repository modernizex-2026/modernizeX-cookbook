# SAKURA Sales Management System (SAKURA-SMS)

An **original** wholesale / distribution **sales management system** written from
scratch in **NEC COBOL85 / WEBCOBOL** (fixed-format, indexed/ISAM files, WEBCOBOL
`SCREEN SECTION` on-line programs). It implements the standard sales-management
business domain — masters, sales orders, shipping, invoicing, purchasing,
receiving, inventory, accounts receivable/payable, reporting and period closing.

> **Originality / copyright.** This codebase is original work. It reproduces only
> the *ideas* of a sales-management system (which are not copyrightable) — the
> data model, program structure, screen layouts, identifiers and comments are all
> newly authored. No third-party source was copied, transformed or obfuscated.

> 📘 **New here? Read [`docs/ENTRY_AND_FUNCTIONS.md`](docs/ENTRY_AND_FUNCTIONS.md)** —
> how the entry app (`MENU00`) works, the full menu tree, and every one of the 68
> functions. Run order: `build\build.bat` → `INITDB` (once) → `MENU00`.

---

## 1. Layout

```
SAKURA-SMS/
├─ copy/     copybooks: F* (FD layouts), S* (SELECT), W*/G*/K* (common)
├─ sub/      common subroutines (NUMGEN, DATEUT, GETMSG, TAXCAL, CHKLOG, ABORTX)
├─ main/     master, transaction, report and batch programs + INITDB
├─ menu/     MENU00 sign-on and menu launcher
├─ data/     ISAM data files (*.DAT) created at run time by INITDB
├─ reports/  report output (*.TXT) and the abend log
├─ build/    build scripts (build.bat / build.sh)
├─ tools/    gen_copybooks.py (copybook generator), check_cobol.py (static check)
└─ docs/     SPEC.md (authoritative data model), FILE_INDEX.txt
```

`docs/SPEC.md` is the single source of truth: every file layout, field, key,
naming convention and common-subroutine linkage is defined there.

## 2. Naming conventions

* Program IDs `<SS><NNNN>` — `MS` master, `OE` order, `SH` ship, `SL` sales,
  `PU` purchase, `RC` receiving, `IV` inventory, `AR`/`AP` receivable/payable,
  `RP` report, `BT` batch.
* Copybooks — `F<name>` FD+record, `S<name>` SELECT, `W*`/`G*`/`K*` common
  working / screen / linkage blocks.
* Every indexed file has both an `F` and an `S` copybook (33 files → 66).

## 3. Data model (33 indexed files)

Masters: customer, supplier, product, warehouse, staff, category, customer
price, department, tax, bank, region, user, message, system-control,
number-control. Balances: stock, stock-movement. Transactions: sales order
(hdr/dtl), shipment (hdr/dtl), invoice (hdr/dtl), purchase order (hdr/dtl),
receiving (hdr/dtl), purchase (hdr/dtl), AR ledger, AP ledger, cash receipt,
payment. Full field-level layouts are in `docs/SPEC.md` §4 and `docs/FILE_INDEX.txt`.

## 4. Common subroutines (`sub/`)

| Sub    | Purpose                                             |
|--------|-----------------------------------------------------|
| NUMGEN | assign the next document number for a series (採番)  |
| DATEUT | date utilities (today/validate/add/diff/EOM/weekday)|
| GETMSG | fetch message text by code from the message master  |
| TAXCAL | consumption-tax lookup + net/tax/gross split        |
| CHKLOG | login + authority validation against the user master|
| ABORTX | fatal-error logger (writes reports/ABEND.LOG)       |

Linkage layouts for all of them are in copybook `KLINK`.

## 5. Build

Edit the compiler driver and copy-library path at the top of
`build/build.bat` (Windows) or `build/build.sh`, then from the project root:

```
build\build.bat
```

It compiles `sub/`, then `main/`, then `menu/`. The `COPY` library path must
point at `copy/`.

> The on-line programs use WEBCOBOL Ver2.0 `SCREEN SECTION` extensions
> (`CLEAR SCREEN`, `END STATUS`, `COLOR`, `REVERSE`, `USING/FROM`, windows) and
> therefore require the NEC COBOL85 / WEBCOBOL toolchain (`cbl85pro`). The
> non-screen layer (`sub/`, `INITDB`, `RP*` reports, `BT*` batch) is standard
> fixed-format COBOL. See §8 for a portability note.

## 6. Run

1. **Initialise the database** (once): run `INITDB`. It creates every `data/*.DAT`
   indexed file and loads starter master data + opening stock.
2. **Start the system**: run `MENU00`. Sign on, then navigate the menus; MENU00
   dynamically `CALL`s the selected program.

### Sample logins (loaded by INITDB)

| Login  | Password  | Role          | Notes                     |
|--------|-----------|---------------|---------------------------|
| admin  | admin123  | administrator | all authorities incl close|
| yamada | pass1001  | manager       | master/order/sales/close  |
| suzuki | pass1002  | clerk         | order/sales               |

### Sample data
5 customers (100001-100005), 4 suppliers (200001-200004), 8 products
(10000001-10000008), 4 warehouses, staff, regions, categories, banks, 2 tax
rates (10% / 8%), opening stock at warehouse 1, and a couple of contract prices.

## 7. Typical demo flow

`MS0010` add/inspect a customer → `OE0010` enter a sales order (auto price, stock
allocation, tax) → `OE0030` allocate → `SH0010` ship (stock decremented, movement
logged) → `SL0010` invoice (AR posted, customer balance updated) →
`AR0010` receipt → `RP0030` sales journal / `RP0070` AR aging →
`BT0010` daily close / `BT0020` monthly close.

## 8. Compilation status (verified) & NEC dialect

**All 68 programs compile clean (0 fatal errors) on NEC COBOL85 Pro Ver8.5
(`cbl.exe`)** — subroutines as subprograms, batch/reports with `/Ccon`, screen
programs with `/Cweb`, copy library `/I copy`.  Reproduce with `build\build.bat`
or `sh tools/compile_all.sh` (writes `build/compile.log`).

The data layer targets **DBLink → SQL Server** (`ASSIGN … -RDB`), which is why
numeric and composite record keys are used freely; see `sql/` for the matching
schema. NEC dialect rules the code obeys (learned from the compiler and applied
across the tree):

* Fixed format, cols 1-6 blank, indicator col 7, Area A/B at 8/12, ≤ col 72, ASCII.
* Subprograms end with `EXIT PROGRAM` (not `GOBACK`); mains use `STOP RUN`.
* `ASSIGN TO <file>-RDB` + `FD … VALUE OF IDENTIFICATION "<file>"` (no path literals).
* Every indexed `READ/WRITE/REWRITE/DELETE/START` has an `INVALID KEY`/`AT END`.
* `COMPLETION-CODE` (not `RETURN-CODE`) for exit codes.
* `SCREEN SECTION` begins with `SD … END STATUS IS ESTS.`; `ESTS` is defined by
  that clause (never re-declared); `CLEAR SCREEN` is a `02` entry; every screen
  item carries a `LINE`.
* Static pass `tools/check_cobol.py` (column width, `COPY` resolution,
  `PROGRAM-ID`, LOC) and `tools/analyze.py` (PERFORM/GO TO targets, undefined
  names) both report 0 problems.

**ISAM fallback (`-MSD`).** `python tools/gen_copybooks.py --isam` emits `-MSD`
(local indexed) copybooks. Note: NEC local ISAM additionally requires *single,
alphanumeric* record keys, so a `-MSD` build needs the keys reworked (group /
`PIC X`) — the verified, compiling build is the DBLink (`-RDB`) one above.
