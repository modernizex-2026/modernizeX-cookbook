       IDENTIFICATION DIVISION.
       PROGRAM-ID. PU0010.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : PU0010  -  Purchase order entry                  *
      *  FUNCTION : enter a purchase order header and its detail     *
      *             lines.  The supplier is validated against SUPPF  *
      *             and each product against PRODF; the unit cost     *
      *             defaults from the product last cost / standard    *
      *             cost when left blank; tax is computed by TAXCAL;  *
      *             the PO number is assigned by NUMGEN "PO"; the     *
      *             ordered quantity is added to STOKF SK-ON-ORDER.   *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SPOH.
           COPY SPOD.
           COPY SSUPP.
           COPY SPROD.
           COPY SSTOK.
       I-O-CONTROL.
           APPLY SHARED-MODE ON POHF
           APPLY SHARED-MODE ON PODF
           APPLY SHARED-MODE ON STOKF.
       DATA DIVISION.
       FILE SECTION.
           COPY FPOH.
           COPY FPOD.
           COPY FSUPP.
           COPY FPROD.
           COPY FSTOK.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
      *----- control switches for header / detail phases ---------------
       01  WK-FLAGS2.
           02  HDR-OK              PIC 9(1)  VALUE 0.
             88  HDR-YES                     VALUE 1.
           02  DTL-DONE            PIC 9(1)  VALUE 0.
             88  DTL-END                     VALUE 1.
      *----- header display work fields --------------------------------
       01  WK-HDR-DISP.
           02  WK-SUPP-NAME        PIC X(40) VALUE SPACE.
           02  WK-PO-NO-D          PIC 9(10) VALUE 0.
      *----- current detail line being entered -------------------------
       01  WK-DET.
           02  WK-D-PROD           PIC 9(8)  VALUE 0.
           02  WK-D-WHSE           PIC 9(3)  VALUE 0.
           02  WK-D-QTY            PIC S9(9) VALUE 0.
           02  WK-D-COST           PIC S9(9)V9(2) VALUE 0.
           02  WK-D-AMT            PIC S9(11)     VALUE 0.
           02  WK-D-NAME           PIC X(40) VALUE SPACE.
           02  WK-D-STKMNG         PIC 9(1)  VALUE 0.
      *----- running totals for the order ------------------------------
       01  WK-TOTALS.
           02  WK-NET-TOTAL        PIC S9(13) VALUE 0.
           02  WK-TAX-TOTAL        PIC S9(13) VALUE 0.
           02  WK-GRS-TOTAL        PIC S9(13) VALUE 0.
      *----- detail line buffer table ----------------------------------
       01  WK-LINE-TABLE.
           02  WK-LCNT             PIC 9(3)  VALUE 0.
           02  WK-LINE OCCURS 200 INDEXED BY LX.
             03  WL-PROD           PIC 9(8).
             03  WL-WHSE           PIC 9(3).
             03  WL-QTY            PIC S9(9).
             03  WL-COST           PIC S9(9)V9(2).
             03  WL-AMOUNT         PIC S9(11).
             03  WL-STKMNG         PIC 9(1).
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-HEAD.
           02  LINE 3.
             03  COLUMN 2  VALUE "PO No      :" COLOR YELLOW.
             03  COLUMN 16 PIC ZZZZZZZZZ9 FROM WK-PO-NO-D COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "PO Date    :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING PH-DATE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Supplier   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(6) USING PH-SUPP.
             03  COLUMN 24 PIC X(40) FROM WK-SUPP-NAME COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE "Warehouse  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(3) USING PH-WHSE.
           02  LINE 7.
             03  COLUMN 2  VALUE "Buyer/Staff:" COLOR YELLOW.
             03  COLUMN 16 PIC 9(4) USING PH-STAFF.
           02  LINE 8.
             03  COLUMN 2  VALUE "Due Date   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING PH-DUE-DATE.
           02  LINE 9.
             03  COLUMN 2  VALUE "Tax Type   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(1) USING PH-TAX-TYPE.
             03  COLUMN 20 VALUE "1:excl 2:incl 3:exempt" COLOR CYAN.
           02  LINE 10.
             03  COLUMN 2  VALUE "Remark     :" COLOR YELLOW.
             03  COLUMN 16 PIC X(40) USING PH-REMARK.
       01  DS-DETAIL.
           02  LINE 12 COLUMN 2 VALUE "--- Detail line entry ---"
                              COLOR CYAN.
           02  LINE 13.
             03  COLUMN 2  VALUE "Product    :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING WK-D-PROD.
             03  COLUMN 26 PIC X(40) FROM WK-D-NAME COLOR WHITE.
           02  LINE 14.
             03  COLUMN 2  VALUE "Warehouse  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(3) USING WK-D-WHSE.
           02  LINE 15.
             03  COLUMN 2  VALUE "Quantity   :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(9) USING WK-D-QTY.
           02  LINE 16.
             03  COLUMN 2  VALUE "Unit Cost  :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(9)V9(2) USING WK-D-COST.
       01  DS-STATUS.
           02  LINE 19.
             03  COLUMN 2  VALUE "Lines :" COLOR YELLOW.
             03  COLUMN 10 PIC ZZ9 FROM WK-LCNT COLOR WHITE.
             03  COLUMN 20 VALUE "Net Total :" COLOR YELLOW.
             03  COLUMN 32 PIC ---,---,---,--9 FROM WK-NET-TOTAL
                              COLOR WHITE.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Save PO ? (Y/N) :" COLOR YELLOW.
           02  LINE 21 COLUMN 24 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PO-LOOP UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "PU0010"           TO WK-PROGID.
           MOVE "Purchase Order Entry"             TO WK-TITLE.
           MOVE "ENTER=Next  PF3=End/Finish  PF4=Clear line"
                                   TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           PERFORM OPEN-IO-POH.
           PERFORM OPEN-IO-POD.
           OPEN I-O   STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT SUPPF.
           OPEN INPUT PRODF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-POH SECTION.
       OIPH-010.
           OPEN I-O POHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT POHF
               CLOSE POHF
               OPEN I-O POHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "POHF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIPH-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-POD SECTION.
       OIPD-010.
           OPEN I-O PODF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PODF
               CLOSE PODF
               OPEN I-O PODF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "PODF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIPD-999.
           EXIT.
      *----------------------------------------------------------------
      *  Main data-entry cycle : one purchase order per iteration.
      *----------------------------------------------------------------
       PO-LOOP SECTION.
       PLOOP-010.
           PERFORM CLEAR-PO.
           PERFORM ENTER-HEADER.
           IF END-YES
               GO TO PLOOP-999
           END-IF.
           IF NOT HDR-YES
               GO TO PLOOP-999
           END-IF.
           PERFORM DETAIL-LOOP UNTIL DTL-END.
           IF WK-LCNT > 0
               PERFORM CONFIRM-SAVE
           ELSE
               MOVE "No lines entered - PO discarded"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       PLOOP-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-PO SECTION.
       CLRP-010.
           INITIALIZE PH-REC.
           INITIALIZE WK-DET.
           MOVE 0                  TO WK-LCNT.
           MOVE 0                  TO WK-NET-TOTAL WK-TAX-TOTAL.
           MOVE 0                  TO WK-GRS-TOTAL.
           MOVE 0                  TO HDR-OK DTL-DONE.
           MOVE 0                  TO WK-PO-NO-D.
           MOVE SPACE              TO WK-SUPP-NAME WK-CONFIRM.
           MOVE WK-SYSDATE         TO PH-DATE  PH-DUE-DATE.
           MOVE 1                  TO PH-TAX-TYPE.
       CLRP-999.
           EXIT.
      *----------------------------------------------------------------
       ENTER-HEADER SECTION.
       EHDR-010.
           MOVE 0                  TO HDR-OK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter PO header - PF3 to quit" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-HEAD.
           ACCEPT  DS-HEAD.
           IF ESTS = "03"
               IF PH-SUPP = 0
                   SET END-YES TO TRUE
               END-IF
               GO TO EHDR-999
           END-IF.
           PERFORM VALIDATE-HEADER.
       EHDR-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-HEADER SECTION.
       VHDR-010.
           IF PH-SUPP = 0
               MOVE "Supplier code required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO VHDR-999
           END-IF.
           MOVE PH-SUPP            TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE "Supplier not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO VHDR-999
           END-READ.
           IF SP-DEL-FLAG = 1
               MOVE "Supplier is deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO VHDR-999
           END-IF.
           MOVE SP-NAME            TO WK-SUPP-NAME.
           IF PH-TAX-TYPE = 0
               MOVE SP-TAX-TYPE    TO PH-TAX-TYPE
           END-IF.
           IF PH-TAX-TYPE = 0
               MOVE 1              TO PH-TAX-TYPE
           END-IF.
           MOVE 1                  TO HDR-OK.
           DISPLAY DS-HEAD.
           MOVE "Header OK - enter detail lines" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       VHDR-999.
           EXIT.
      *----------------------------------------------------------------
       DETAIL-LOOP SECTION.
       DLOOP-010.
           PERFORM CLEAR-DETAIL.
           MOVE PH-WHSE            TO WK-D-WHSE.
           DISPLAY DS-DETAIL.
           DISPLAY DS-STATUS.
           ACCEPT  DS-DETAIL.
           EVALUATE ESTS
               WHEN "03"
                   SET DTL-END TO TRUE
               WHEN "04"
                   MOVE "Line cleared" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               WHEN "00"
                   PERFORM PROCESS-DETAIL
               WHEN OTHER
                   MOVE "Invalid key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       DLOOP-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-DETAIL SECTION.
       CLRD-010.
           MOVE 0                  TO WK-D-PROD WK-D-WHSE WK-D-QTY.
           MOVE 0                  TO WK-D-COST WK-D-AMT WK-D-STKMNG.
           MOVE SPACE              TO WK-D-NAME.
       CLRD-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-DETAIL SECTION.
       PDET-010.
           IF WK-D-PROD = 0
               MOVE "Product code required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           MOVE WK-D-PROD          TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "Product not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PDET-999
           END-READ.
           IF PR-DEL-FLAG = 1
               MOVE "Product is deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           MOVE PR-NAME            TO WK-D-NAME.
           MOVE PR-STOCK-MNG       TO WK-D-STKMNG.
           IF WK-D-WHSE = 0
               MOVE PR-DFLT-WHSE   TO WK-D-WHSE
           END-IF.
           IF WK-D-WHSE = 0
               MOVE "Warehouse required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           IF WK-D-QTY <= 0
               MOVE "Quantity must be positive" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           IF WK-D-COST <= 0
               PERFORM RESOLVE-COST
           END-IF.
           IF WK-D-COST <= 0
               MOVE "Unit cost required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           COMPUTE WK-D-AMT ROUNDED = WK-D-QTY * WK-D-COST.
           PERFORM ADD-LINE.
       PDET-999.
           EXIT.
      *----------------------------------------------------------------
      *  Unit cost defaulting : last cost first, then standard cost.
      *----------------------------------------------------------------
       RESOLVE-COST SECTION.
       RCST-010.
           IF PR-LAST-COST > 0
               MOVE PR-LAST-COST   TO WK-D-COST
           ELSE
               MOVE PR-STD-COST    TO WK-D-COST
           END-IF.
       RCST-999.
           EXIT.
      *----------------------------------------------------------------
       ADD-LINE SECTION.
       ADDL-010.
           IF WK-LCNT >= 200
               MOVE "Maximum 200 lines reached" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO ADDL-999
           END-IF.
           ADD 1                   TO WK-LCNT.
           SET LX                  TO WK-LCNT.
           MOVE WK-D-PROD          TO WL-PROD (LX).
           MOVE WK-D-WHSE          TO WL-WHSE (LX).
           MOVE WK-D-QTY           TO WL-QTY  (LX).
           MOVE WK-D-COST          TO WL-COST (LX).
           MOVE WK-D-AMT           TO WL-AMOUNT(LX).
           MOVE WK-D-STKMNG        TO WL-STKMNG(LX).
           ADD  WK-D-AMT           TO WK-NET-TOTAL.
           DISPLAY DS-STATUS.
           MOVE "Line added"       TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       ADDL-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-SAVE SECTION.
       CSAV-010.
           MOVE SPACE              TO WK-CONFIRM.
           PERFORM COMPUTE-TAX-TOTAL.
           DISPLAY DS-STATUS.
           MOVE "Review totals then confirm" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               PERFORM SAVE-PO
           ELSE
               MOVE "PO discarded" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CSAV-999.
           EXIT.
      *----------------------------------------------------------------
       COMPUTE-TAX-TOTAL SECTION.
       CTT-010.
           MOVE 1                  TO KT-CATEGORY.
           MOVE PH-TAX-TYPE        TO KT-TAX-TYPE.
           MOVE 1                  TO KT-ROUND.
           MOVE PH-DATE            TO KT-DATE.
           MOVE WK-NET-TOTAL       TO KT-AMOUNT.
           CALL "TAXCAL" USING KTAX.
           IF KT-STATUS = "00"
               MOVE KT-NET         TO WK-NET-TOTAL
               MOVE KT-TAX         TO WK-TAX-TOTAL
               MOVE KT-GROSS       TO WK-GRS-TOTAL
           ELSE
               MOVE 0              TO WK-TAX-TOTAL
               MOVE WK-NET-TOTAL   TO WK-GRS-TOTAL
           END-IF.
       CTT-999.
           EXIT.
      *----------------------------------------------------------------
       SAVE-PO SECTION.
       SPO-010.
           MOVE "PO"               TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Number assignment failed" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO SPO-999
           END-IF.
           MOVE KNUM-NUMBER        TO PH-NO  WK-PO-NO-D.
           MOVE WK-NET-TOTAL       TO PH-AMOUNT.
           MOVE WK-TAX-TOTAL       TO PH-TAX-AMOUNT.
           MOVE WK-GRS-TOTAL       TO PH-TOTAL.
           MOVE 0                  TO PH-STATUS.
           MOVE WK-LCNT            TO PH-LINES.
           MOVE WK-SYSDATE         TO PH-ADD-DATE.
           MOVE WK-USER-CODE       TO PH-ADD-USER.
           MOVE 0                  TO PH-DEL-FLAG.
           WRITE PH-REC
               INVALID KEY
                   MOVE "Header write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO SPO-999
           END-WRITE.
           PERFORM WRITE-DETAILS.
           MOVE "PO saved"         TO WK-MSG-LINE.
           DISPLAY DS-STATUS.
           DISPLAY DS-MSG.
       SPO-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-DETAILS SECTION.
       WDET-010.
           PERFORM VARYING LX FROM 1 BY 1 UNTIL LX > WK-LCNT
               INITIALIZE PD-REC
               MOVE PH-NO          TO PD-NO
               SET WK-IDX TO LX
               MOVE WK-IDX TO PD-LINE
               MOVE WL-PROD  (LX)  TO PD-PROD
               MOVE WL-WHSE  (LX)  TO PD-WHSE
               MOVE WL-QTY   (LX)  TO PD-QTY
               MOVE WL-COST  (LX)  TO PD-UNIT-COST
               MOVE WL-AMOUNT(LX)  TO PD-AMOUNT
               MOVE 0              TO PD-RECV-QTY
               MOVE PH-DUE-DATE    TO PD-DUE-DATE
               MOVE 0              TO PD-STATUS
               WRITE PD-REC
                   INVALID KEY
                       CONTINUE
               END-WRITE
               PERFORM UPDATE-ONORDER
           END-PERFORM.
       WDET-999.
           EXIT.
      *----------------------------------------------------------------
      *  Add the ordered quantity to the on-order stock bucket.
      *----------------------------------------------------------------
       UPDATE-ONORDER SECTION.
       UONO-010.
           IF WL-STKMNG (LX) = 0
               GO TO UONO-999
           END-IF.
           MOVE WL-PROD (LX)       TO SK-PROD.
           MOVE WL-WHSE (LX)       TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   INITIALIZE SK-REC
                   MOVE WL-PROD (LX) TO SK-PROD
                   MOVE WL-WHSE (LX) TO SK-WHSE
                   MOVE WL-QTY  (LX) TO SK-ON-ORDER
                   WRITE SK-REC
                       INVALID KEY CONTINUE
                   END-WRITE
               NOT INVALID KEY
                   ADD WL-QTY (LX) TO SK-ON-ORDER
                   REWRITE SK-REC
                       INVALID KEY CONTINUE
                   END-REWRITE
           END-READ.
       UONO-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE POHF PODF STOKF SUPPF PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "PU0010"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
