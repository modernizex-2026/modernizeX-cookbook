       IDENTIFICATION DIVISION.
       PROGRAM-ID. OE0030.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : OE0030  -  Sales order stock allocation          *
      *  FUNCTION : select an entered / partly-allocated sales order *
      *             and reserve stock for it.  For every order line  *
      *             the stock balance record (product + warehouse)   *
      *             is read; the quantity still required (ordered     *
      *             less already shipped and already allocated) is    *
      *             compared with the free quantity (on-hand less     *
      *             allocated) and the smaller of the two is added to *
      *             both SK-ALLOCATED and OD-ALLOC-QTY.  When any     *
      *             line is (partly) allocated the order status is    *
      *             advanced to 1 (allocated).  The per-line result   *
      *             including any shortage is displayed.             *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SORDH.
           COPY SORDD.
           COPY SSTOK.
           COPY SCUST.
           COPY SPROD.
       I-O-CONTROL.
           APPLY SHARED-MODE ON ORDHF
           APPLY SHARED-MODE ON ORDDF
           APPLY SHARED-MODE ON STOKF.
       DATA DIVISION.
       FILE SECTION.
           COPY FORDH.
           COPY FORDD.
           COPY FSTOK.
           COPY FCUST.
           COPY FPROD.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
      *----- control ---------------------------------------------------
       01  WK-CTL.
           02  WK-SEL-NO           PIC 9(10) VALUE 0.
           02  WK-CUR-NO           PIC 9(10) VALUE 0.
           02  WK-PGSIZE           PIC 9(3)  VALUE 13.
           02  WK-PAGE-TOP         PIC 9(3)  VALUE 1.
           02  WK-PAGE-NO          PIC 9(3)  VALUE 0.
           02  WK-PAGE-CNT         PIC 9(3)  VALUE 0.
           02  WK-REVIEW-END       PIC 9(1)  VALUE 0.
             88  REVIEW-END-YES              VALUE 1.
           02  WK-ALLOC-DONE       PIC 9(1)  VALUE 0.
           02  WK-DUMMY            PIC X(1)  VALUE SPACE.
      *----- per-line work --------------------------------------------
       01  WK-LINE-WORK.
           02  WK-WANT             PIC S9(9) VALUE 0.
           02  WK-ALREADY          PIC S9(9) VALUE 0.
           02  WK-NEED             PIC S9(9) VALUE 0.
           02  WK-AVAIL            PIC S9(9) VALUE 0.
           02  WK-GIVE             PIC S9(9) VALUE 0.
           02  WK-TOT-ALLOC        PIC S9(11) VALUE 0.
           02  WK-TOT-SHORT        PIC S9(11) VALUE 0.
      *----- header display -------------------------------------------
       01  WK-HDR-DISP.
           02  WK-CUST-NAME        PIC X(40) VALUE SPACE.
           02  WK-PROD-NAME        PIC X(40) VALUE SPACE.
           02  WK-STAT-TEXT        PIC X(12) VALUE SPACE.
      *----- detail buffer + window -----------------------------------
       01  WK-DTL-TABLE.
           02  WK-DCNT             PIC 9(3)  VALUE 0.
           02  WK-DROW OCCURS 200.
             03  DR-LINE           PIC 9(3).
             03  DR-PROD           PIC 9(8).
             03  DR-WHSE           PIC 9(3).
             03  DR-NAME           PIC X(14).
             03  DR-STKMNG         PIC 9(1).
             03  DR-ORD            PIC S9(9).
             03  DR-AVAIL          PIC S9(9).
             03  DR-ALLOC          PIC S9(9).
             03  DR-SHORT          PIC S9(9).
       01  WK-WIN.
           02  WW-ROW OCCURS 13.
             03  WW-LINE           PIC ZZ9.
             03  WW-PROD           PIC 9(8).
             03  WW-NAME           PIC X(14).
             03  WW-ORD            PIC ---,--9.
             03  WW-AVAIL          PIC ---,--9.
             03  WW-ALLOC          PIC ---,--9.
             03  WW-SHORT          PIC ---,--9.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 5.
             03  COLUMN 2  VALUE "Order No :" COLOR YELLOW.
             03  COLUMN 14 PIC 9(10) USING WK-SEL-NO.
       01  DS-ORDER.
           02  LINE 3.
             03  COLUMN 2  VALUE "Order#:" COLOR YELLOW.
             03  COLUMN 10 PIC ZZZZZZZZZ9 FROM OH-NO COLOR WHITE.
             03  COLUMN 24 VALUE "Date:" COLOR YELLOW.
             03  COLUMN 30 PIC 9(8) FROM OH-DATE COLOR WHITE.
             03  COLUMN 42 VALUE "Status:" COLOR YELLOW.
             03  COLUMN 50 PIC X(12) FROM WK-STAT-TEXT COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "Cust  :" COLOR YELLOW.
             03  COLUMN 10 PIC 9(6) FROM OH-CUST COLOR WHITE.
             03  COLUMN 18 PIC X(34) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Whse :" COLOR YELLOW.
             03  COLUMN 9  PIC 9(3) FROM OH-WHSE COLOR WHITE.
             03  COLUMN 16 VALUE "Lines:" COLOR YELLOW.
             03  COLUMN 23 PIC ZZ9 FROM WK-DCNT COLOR WHITE.
             03  COLUMN 30 VALUE "TotAlloc:" COLOR YELLOW.
             03  COLUMN 40 PIC ---,---,--9 FROM WK-TOT-ALLOC.
             03  COLUMN 54 VALUE "Short:" COLOR YELLOW.
             03  COLUMN 61 PIC ---,---,--9 FROM WK-TOT-SHORT.
           02  LINE 6.
             03  COLUMN 2  VALUE
                 "Ln Product   Name          Order  Avail  Alloc"
                              COLOR CYAN.
             03  COLUMN 54 VALUE "Short" COLOR CYAN.
           02  LINE 7.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (1).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (1).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (1).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (1).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (1).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (1).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (1).
           02  LINE 8.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (2).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (2).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (2).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (2).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (2).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (2).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (2).
           02  LINE 9.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (3).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (3).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (3).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (3).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (3).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (3).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (3).
           02  LINE 10.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (4).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (4).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (4).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (4).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (4).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (4).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (4).
           02  LINE 11.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (5).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (5).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (5).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (5).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (5).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (5).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (5).
           02  LINE 12.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (6).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (6).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (6).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (6).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (6).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (6).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (6).
           02  LINE 13.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (7).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (7).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (7).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (7).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (7).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (7).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (7).
           02  LINE 14.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (8).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (8).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (8).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (8).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (8).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (8).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (8).
           02  LINE 15.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (9).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (9).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (9).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (9).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (9).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (9).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (9).
           02  LINE 16.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (10).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (10).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (10).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (10).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (10).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (10).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (10).
           02  LINE 17.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (11).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (11).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (11).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (11).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (11).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (11).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (11).
           02  LINE 18.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (12).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (12).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (12).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (12).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (12).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (12).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (12).
           02  LINE 19.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (13).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (13).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (13).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (13).
             03  COLUMN 38 PIC ---,--9 FROM WW-AVAIL (13).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (13).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHORT (13).
       01  DS-PAGE.
           02  LINE 20.
             03  COLUMN 2  VALUE "Page:" COLOR YELLOW.
             03  COLUMN 8  PIC ZZ9 FROM WK-PAGE-NO COLOR WHITE.
             03  COLUMN 11 VALUE "/" COLOR WHITE.
             03  COLUMN 12 PIC ZZ9 FROM WK-PAGE-CNT COLOR WHITE.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Allocate stock ? (Y/N) :"
                              COLOR YELLOW.
           02  LINE 21 COLUMN 28 PIC X(1) USING WK-CONFIRM.
       01  DS-BROWSE.
           02  LINE 20 COLUMN 40 VALUE "PFkey:" COLOR CYAN.
           02  LINE 20 COLUMN 47 PIC X(1) USING WK-DUMMY.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "OE0030"           TO WK-PROGID.
           MOVE "Sales Order Allocation"           TO WK-TITLE.
           MOVE "ENTER=Read  PF3=End"              TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           OPEN I-O   ORDHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ORDHF
               CLOSE ORDHF
               OPEN I-O ORDHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ORDHF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O   ORDDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ORDDF
               CLOSE ORDDF
               OPEN I-O ORDDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ORDDF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O   STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT CUSTF.
           OPEN INPUT PRODF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAINR-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter the order number to allocate"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-ORDER
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAINR-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLRW-010.
           MOVE 0                  TO WK-SEL-NO WK-CUR-NO.
           MOVE 0                  TO WK-DCNT WK-ALLOC-DONE.
           MOVE 0                  TO WK-TOT-ALLOC WK-TOT-SHORT.
           MOVE 1                  TO WK-PAGE-TOP.
           MOVE SPACE              TO WK-CUST-NAME WK-CONFIRM.
       CLRW-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-ORDER SECTION.
       PORD-010.
           IF WK-SEL-NO = 0
               MOVE "Order number must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PORD-999
           END-IF.
           MOVE WK-SEL-NO          TO OH-NO.
           READ ORDHF
               INVALID KEY
                   MOVE "Order not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PORD-999
           END-READ.
           IF OH-DEL-FLAG = 1
               MOVE "Order is deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PORD-999
           END-IF.
           IF OH-STATUS NOT = 0 AND OH-STATUS NOT = 1
               MOVE "Order cannot be allocated in its status"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PORD-999
           END-IF.
           MOVE OH-NO              TO WK-CUR-NO.
           PERFORM LOOKUP-CUSTOMER.
           PERFORM SET-STATUS-TEXT.
           PERFORM PREVIEW-DETAILS.
           IF WK-DCNT = 0
               MOVE "Order has no detail lines" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PORD-999
           END-IF.
           PERFORM CALC-PAGES.
           MOVE 1                  TO WK-PAGE-TOP.
           PERFORM BUILD-WINDOW.
           PERFORM PAINT-ORDER.
           PERFORM ASK-CONFIRM.
       PORD-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-CUSTOMER SECTION.
       LKC-010.
           MOVE SPACE              TO WK-CUST-NAME.
           MOVE OH-CUST            TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "??? unknown customer" TO WK-CUST-NAME
               NOT INVALID KEY
                   MOVE CU-NAME    TO WK-CUST-NAME
           END-READ.
       LKC-999.
           EXIT.
      *----------------------------------------------------------------
       SET-STATUS-TEXT SECTION.
       SST-010.
           EVALUATE OH-STATUS
               WHEN 0
                   MOVE "Entered"     TO WK-STAT-TEXT
               WHEN 1
                   MOVE "Allocated"   TO WK-STAT-TEXT
               WHEN 2
                   MOVE "Part-ship"   TO WK-STAT-TEXT
               WHEN 3
                   MOVE "Shipped"     TO WK-STAT-TEXT
               WHEN 4
                   MOVE "Invoiced"    TO WK-STAT-TEXT
               WHEN 9
                   MOVE "Cancelled"   TO WK-STAT-TEXT
               WHEN OTHER
                   MOVE "Unknown"     TO WK-STAT-TEXT
           END-EVALUATE.
       SST-999.
           EXIT.
      *----------------------------------------------------------------
       PREVIEW-DETAILS SECTION.
      *    load order lines and compute the current allocation picture
       PVD-010.
           MOVE 0                  TO WK-DCNT.
           MOVE 0                  TO WK-TOT-ALLOC WK-TOT-SHORT.
           MOVE WK-CUR-NO          TO OD-NO.
           MOVE 0                  TO OD-LINE.
           START ORDDF KEY IS NOT LESS THAN OD-NO
               INVALID KEY
                   GO TO PVD-999
           END-START.
       PVD-020.
           READ ORDDF NEXT
               AT END
                   GO TO PVD-999
           END-READ.
           IF OD-NO NOT = WK-CUR-NO
               GO TO PVD-999
           END-IF.
           IF WK-DCNT >= 200
               GO TO PVD-999
           END-IF.
           ADD 1                   TO WK-DCNT.
           MOVE OD-LINE            TO DR-LINE  (WK-DCNT).
           MOVE OD-PROD            TO DR-PROD  (WK-DCNT).
           MOVE OD-WHSE            TO DR-WHSE  (WK-DCNT).
           PERFORM LOOKUP-PRODUCT.
           MOVE WK-PROD-NAME       TO DR-NAME  (WK-DCNT).
           COMPUTE WK-WANT = OD-QTY - OD-SHIPPED-QTY.
           IF WK-WANT < 0
               MOVE 0              TO WK-WANT
           END-IF.
           MOVE WK-WANT            TO DR-ORD   (WK-DCNT).
           MOVE OD-ALLOC-QTY       TO DR-ALLOC (WK-DCNT).
           PERFORM READ-STOCK-AVAIL.
           MOVE WK-AVAIL           TO DR-AVAIL (WK-DCNT).
           COMPUTE WK-NEED = WK-WANT - OD-ALLOC-QTY.
           IF WK-NEED < 0
               MOVE 0              TO WK-NEED
           END-IF.
           MOVE WK-NEED            TO DR-SHORT (WK-DCNT).
           GO TO PVD-020.
       PVD-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-PRODUCT SECTION.
       LKP-010.
           MOVE SPACE              TO WK-PROD-NAME.
           MOVE 1                  TO WK-IDX.
           MOVE OD-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "??"       TO WK-PROD-NAME
                   MOVE 1          TO WK-IDX
               NOT INVALID KEY
                   MOVE PR-NAME    TO WK-PROD-NAME
                   MOVE PR-STOCK-MNG TO WK-IDX
           END-READ.
           MOVE WK-IDX             TO DR-STKMNG (WK-DCNT).
       LKP-999.
           EXIT.
      *----------------------------------------------------------------
       READ-STOCK-AVAIL SECTION.
      *    free quantity = on-hand - already allocated
       RSA-010.
           MOVE 0                  TO WK-AVAIL.
           IF DR-STKMNG (WK-DCNT) = 0
               MOVE WK-WANT        TO WK-AVAIL
               GO TO RSA-999
           END-IF.
           MOVE OD-PROD            TO SK-PROD.
           MOVE OD-WHSE            TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   MOVE 0          TO WK-AVAIL
               NOT INVALID KEY
                   COMPUTE WK-AVAIL = SK-ONHAND - SK-ALLOCATED
           END-READ.
           IF WK-AVAIL < 0
               MOVE 0              TO WK-AVAIL
           END-IF.
       RSA-999.
           EXIT.
      *----------------------------------------------------------------
       ASK-CONFIRM SECTION.
       ASKC-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Confirm allocation (Y) or PF3 to cancel"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF ESTS = "03"
               MOVE "Allocation cancelled" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO ASKC-999
           END-IF.
           IF CONFIRM-YES
               PERFORM DO-ALLOCATE
               PERFORM REVIEW-LOOP
           ELSE
               MOVE "Allocation cancelled" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       ASKC-999.
           EXIT.
      *----------------------------------------------------------------
       DO-ALLOCATE SECTION.
      *    walk the order lines again and commit the reservation
       DOA-010.
           MOVE 0                  TO WK-TOT-ALLOC WK-TOT-SHORT.
           MOVE WK-CUR-NO          TO OD-NO.
           MOVE 0                  TO OD-LINE.
           MOVE 0                  TO WK-IDX.
           START ORDDF KEY IS NOT LESS THAN OD-NO
               INVALID KEY
                   GO TO DOA-900
           END-START.
       DOA-020.
           READ ORDDF NEXT
               AT END
                   GO TO DOA-900
           END-READ.
           IF OD-NO NOT = WK-CUR-NO
               GO TO DOA-900
           END-IF.
           ADD 1                   TO WK-IDX.
           IF WK-IDX > WK-DCNT
               GO TO DOA-900
           END-IF.
           PERFORM ALLOCATE-ONE-LINE.
           GO TO DOA-020.
       DOA-900.
           MOVE 1                  TO OH-STATUS.
           MOVE WK-SYSDATE         TO OH-UPD-DATE.
           MOVE WK-USER-CODE       TO OH-UPD-USER.
           REWRITE OH-REC
               INVALID KEY
                   MOVE "Order header update failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
           PERFORM SET-STATUS-TEXT.
           MOVE 1                  TO WK-ALLOC-DONE.
           MOVE 1                  TO WK-PAGE-TOP.
           PERFORM BUILD-WINDOW.
           PERFORM PAINT-ORDER.
           MOVE "Allocation complete" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       DOA-999.
           EXIT.
      *----------------------------------------------------------------
       ALLOCATE-ONE-LINE SECTION.
      *    reserve stock for the ORDDF record currently in the buffer
       AOL-010.
           COMPUTE WK-WANT = OD-QTY - OD-SHIPPED-QTY.
           IF WK-WANT < 0
               MOVE 0              TO WK-WANT
           END-IF.
           COMPUTE WK-NEED = WK-WANT - OD-ALLOC-QTY.
           IF WK-NEED <= 0
               MOVE 0              TO WK-GIVE
               PERFORM AOL-RECORD
               GO TO AOL-999
           END-IF.
           IF DR-STKMNG (WK-IDX) = 0
      *        non-stock item : allocate the full outstanding qty
               MOVE WK-NEED        TO WK-GIVE
               ADD  WK-GIVE        TO OD-ALLOC-QTY
               PERFORM REWRITE-ORDD
               PERFORM AOL-RECORD
               GO TO AOL-999
           END-IF.
           MOVE OD-PROD            TO SK-PROD.
           MOVE OD-WHSE            TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   MOVE 0          TO WK-GIVE
                   PERFORM AOL-RECORD
                   GO TO AOL-999
           END-READ.
           COMPUTE WK-AVAIL = SK-ONHAND - SK-ALLOCATED.
           IF WK-AVAIL < 0
               MOVE 0              TO WK-AVAIL
           END-IF.
           IF WK-AVAIL >= WK-NEED
               MOVE WK-NEED        TO WK-GIVE
           ELSE
               MOVE WK-AVAIL       TO WK-GIVE
           END-IF.
           IF WK-GIVE > 0
               ADD WK-GIVE         TO SK-ALLOCATED
               REWRITE SK-REC
                   INVALID KEY
                       MOVE "Stock update failed" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-REWRITE
               ADD WK-GIVE         TO OD-ALLOC-QTY
               PERFORM REWRITE-ORDD
           END-IF.
           PERFORM AOL-RECORD.
       AOL-999.
           EXIT.
      *----------------------------------------------------------------
       REWRITE-ORDD SECTION.
       ROD-010.
           IF WK-WANT <= OD-ALLOC-QTY
               MOVE 1              TO OD-STATUS
           END-IF.
           REWRITE OD-REC
               INVALID KEY
                   MOVE "Line update failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
       ROD-999.
           EXIT.
      *----------------------------------------------------------------
       AOL-RECORD SECTION.
      *    fill the display table entry with the committed result
       AOR-010.
           COMPUTE WK-NEED = WK-WANT - OD-ALLOC-QTY.
           IF WK-NEED < 0
               MOVE 0              TO WK-NEED
           END-IF.
           MOVE WK-WANT            TO DR-ORD   (WK-IDX).
           MOVE OD-ALLOC-QTY       TO DR-ALLOC (WK-IDX).
           MOVE WK-NEED            TO DR-SHORT (WK-IDX).
           ADD  OD-ALLOC-QTY       TO WK-TOT-ALLOC.
           ADD  WK-NEED            TO WK-TOT-SHORT.
       AOR-999.
           EXIT.
      *----------------------------------------------------------------
       CALC-PAGES SECTION.
       CLP-010.
           IF WK-DCNT = 0
               MOVE 1              TO WK-PAGE-CNT
           ELSE
               COMPUTE WK-PAGE-CNT =
                   (WK-DCNT + WK-PGSIZE - 1) / WK-PGSIZE
           END-IF.
       CLP-999.
           EXIT.
      *----------------------------------------------------------------
       BUILD-WINDOW SECTION.
       BW-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1
                   UNTIL WK-IDX > WK-PGSIZE
               COMPUTE WK-IDX2 = WK-PAGE-TOP + WK-IDX - 1
               IF WK-IDX2 <= WK-DCNT AND WK-IDX2 >= 1
                   MOVE DR-LINE  (WK-IDX2) TO WW-LINE  (WK-IDX)
                   MOVE DR-PROD  (WK-IDX2) TO WW-PROD  (WK-IDX)
                   MOVE DR-NAME  (WK-IDX2) TO WW-NAME  (WK-IDX)
                   MOVE DR-ORD   (WK-IDX2) TO WW-ORD   (WK-IDX)
                   MOVE DR-AVAIL (WK-IDX2) TO WW-AVAIL (WK-IDX)
                   MOVE DR-ALLOC (WK-IDX2) TO WW-ALLOC (WK-IDX)
                   MOVE DR-SHORT (WK-IDX2) TO WW-SHORT (WK-IDX)
               ELSE
                   MOVE ZERO       TO WW-LINE  (WK-IDX)
                   MOVE ZERO       TO WW-PROD  (WK-IDX)
                   MOVE SPACE      TO WW-NAME  (WK-IDX)
                   MOVE ZERO       TO WW-ORD   (WK-IDX)
                   MOVE ZERO       TO WW-AVAIL (WK-IDX)
                   MOVE ZERO       TO WW-ALLOC (WK-IDX)
                   MOVE ZERO       TO WW-SHORT (WK-IDX)
               END-IF
           END-PERFORM.
           COMPUTE WK-PAGE-NO =
               (WK-PAGE-TOP + WK-PGSIZE - 1) / WK-PGSIZE.
       BW-999.
           EXIT.
      *----------------------------------------------------------------
       PAINT-ORDER SECTION.
       PO-010.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           DISPLAY DS-ORDER.
           DISPLAY DS-PAGE.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       REVIEW-LOOP SECTION.
      *    let the operator page through the allocation result
       RL-010.
           MOVE 0                  TO WK-REVIEW-END.
           MOVE "PF6=NextPage PF12=PrevPage PF3=Done"
                                   TO WK-FKEY-LINE.
           PERFORM UNTIL REVIEW-END-YES
               DISPLAY DS-FOOTER
               DISPLAY DS-BROWSE
               ACCEPT  DS-BROWSE
               EVALUATE ESTS
                   WHEN "03"
                       SET REVIEW-END-YES TO TRUE
                   WHEN "06"
                       PERFORM PAGE-DOWN
                   WHEN "12"
                       PERFORM PAGE-UP
                   WHEN OTHER
                       CONTINUE
               END-EVALUATE
           END-PERFORM.
           MOVE "ENTER=Read  PF3=End" TO WK-FKEY-LINE.
       RL-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-DOWN SECTION.
       PD-010.
           IF WK-PAGE-TOP + WK-PGSIZE > WK-DCNT
               GO TO PD-999
           END-IF.
           ADD WK-PGSIZE           TO WK-PAGE-TOP.
           PERFORM BUILD-WINDOW.
           PERFORM PAINT-ORDER.
       PD-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-UP SECTION.
       PU-010.
           IF WK-PAGE-TOP <= 1
               GO TO PU-999
           END-IF.
           IF WK-PAGE-TOP > WK-PGSIZE
               SUBTRACT WK-PGSIZE  FROM WK-PAGE-TOP
           ELSE
               MOVE 1              TO WK-PAGE-TOP
           END-IF.
           PERFORM BUILD-WINDOW.
           PERFORM PAINT-ORDER.
       PU-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE ORDHF ORDDF STOKF CUSTF PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "OE0030"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
