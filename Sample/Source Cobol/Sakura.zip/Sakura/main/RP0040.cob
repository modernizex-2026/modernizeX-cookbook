       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0040.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0040  -  Sales summary by customer             *
      *  FUNCTION : aggregate invoice header net / tax / total by    *
      *             customer for a sales-date range (read INVHF in   *
      *             customer order via alternate key, control break  *
      *             on customer).  Show customer name, invoice count *
      *             and amounts, plus grand totals.  132-column.     *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SINVH.
           COPY SCUST.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FINVH.
           COPY FCUST.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0040.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
           02  WK-FIRST            PIC 9(1)  VALUE 1.
       01  WK-PARM.
           02  WK-IN-FROM          PIC X(8)  VALUE SPACE.
           02  WK-IN-TO            PIC X(8)  VALUE SPACE.
           02  WK-DATE-FROM        PIC 9(8)  VALUE 0.
           02  WK-DATE-TO          PIC 9(8)  VALUE 99999999.
       01  WK-CUR.
           02  WK-CUR-CUST         PIC 9(6)  VALUE 0.
           02  WK-CUR-NET          PIC S9(15) COMP-3 VALUE 0.
           02  WK-CUR-TAX          PIC S9(15) COMP-3 VALUE 0.
           02  WK-CUR-TOT          PIC S9(15) COMP-3 VALUE 0.
           02  WK-CUR-CNT          PIC 9(7)  VALUE 0.
       01  WK-TOTALS.
           02  WK-G-NET            PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-TAX            PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-TOT            PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-CNT            PIC 9(7)  VALUE 0.
           02  WK-CUST-CNT         PIC 9(7)  VALUE 0.
       01  WK-CUST-NAME            PIC X(34) VALUE SPACE.
       01  WK-COMPANY              PIC X(40) VALUE SPACE.
       01  RPT-RULE               PIC X(120) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RH-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "CUST".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(34) VALUE "CUSTOMER NAME".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(7)  VALUE "   #INV".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "           NET".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "           TAX".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "         TOTAL".
       01  RD-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RC-CODE            PIC 9(6).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RC-NAME            PIC X(34).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RC-COUNT           PIC ZZZ,ZZ9.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RC-NET             PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RC-TAX             PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RC-TOT             PIC ---,---,---,--9.
       01  RT-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(42) VALUE "GRAND TOTAL".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RT-COUNT           PIC ZZZ,ZZ9.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RT-NET             PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RT-TAX             PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RT-TOT             PIC ---,---,---,--9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PARM-RTN.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0040"           TO WK-PROGID.
           MOVE "SALES SUMMARY BY CUSTOMER"     TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT INVHF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "INVHF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT CUSTF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PARM-RTN SECTION.
       PARM-010.
           DISPLAY "RP0040 - Sales summary by customer".
           DISPLAY "From sales date YYYYMMDD (blank=earliest): ".
           ACCEPT  WK-IN-FROM FROM CONSOLE.
           DISPLAY "To   sales date YYYYMMDD (blank=latest  ): ".
           ACCEPT  WK-IN-TO   FROM CONSOLE.
           IF WK-IN-FROM NUMERIC AND WK-IN-FROM NOT = SPACE
               MOVE WK-IN-FROM     TO WK-DATE-FROM
           ELSE
               MOVE 0              TO WK-DATE-FROM
           END-IF.
           IF WK-IN-TO NUMERIC AND WK-IN-TO NOT = SPACE
               MOVE WK-IN-TO       TO WK-DATE-TO
           ELSE
               MOVE 99999999       TO WK-DATE-TO
           END-IF.
       PARM-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRINT-010.
           MOVE 0                  TO WK-G-CNT.
           MOVE 99                 TO WK-LINE.
           IF NOT MAIN-EOF
               MOVE 0              TO IH-CUST
               MOVE 0              TO IH-DATE
               START INVHF KEY NOT < IH-CUST
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-NEXT UNTIL MAIN-EOF.
           IF WK-FIRST = 0
               PERFORM FLUSH-CUST
           END-IF.
           PERFORM PRINT-GRAND.
       PRINT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-NEXT SECTION.
       RN-010.
           READ INVHF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   PERFORM PROCESS-ONE
           END-READ.
       RN-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-ONE SECTION.
       PO-010.
           IF WK-FIRST = 1
               MOVE IH-CUST        TO WK-CUR-CUST
               PERFORM RESET-ACCUM
               MOVE 0              TO WK-FIRST
           ELSE
               IF IH-CUST NOT = WK-CUR-CUST
                   PERFORM FLUSH-CUST
                   MOVE IH-CUST    TO WK-CUR-CUST
                   PERFORM RESET-ACCUM
               END-IF
           END-IF.
           IF IH-DEL-FLAG NOT = 1 AND IH-STATUS NOT = 9
              AND IH-DATE NOT < WK-DATE-FROM
              AND IH-DATE NOT > WK-DATE-TO
               ADD IH-AMOUNT       TO WK-CUR-NET
               ADD IH-TAX-AMOUNT   TO WK-CUR-TAX
               ADD IH-TOTAL        TO WK-CUR-TOT
               ADD 1               TO WK-CUR-CNT
           END-IF.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       RESET-ACCUM SECTION.
       RA-010.
           MOVE 0                  TO WK-CUR-NET WK-CUR-TAX WK-CUR-TOT.
           MOVE 0                  TO WK-CUR-CNT.
       RA-999.
           EXIT.
      *----------------------------------------------------------------
       FLUSH-CUST SECTION.
       FC-010.
           IF WK-CUR-CNT = 0
               GO TO FC-999
           END-IF.
           PERFORM CHECK-PAGE.
           MOVE SPACE              TO WK-CUST-NAME.
           MOVE WK-CUR-CUST        TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "(unknown)" TO WK-CUST-NAME
               NOT INVALID KEY
                   MOVE CU-NAME     TO WK-CUST-NAME
           END-READ.
           MOVE WK-CUR-CUST        TO RC-CODE.
           MOVE WK-CUST-NAME       TO RC-NAME.
           MOVE WK-CUR-CNT         TO RC-COUNT.
           MOVE WK-CUR-NET         TO RC-NET.
           MOVE WK-CUR-TAX         TO RC-TAX.
           MOVE WK-CUR-TOT         TO RC-TOT.
           MOVE RD-LINE            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           ADD WK-CUR-NET          TO WK-G-NET.
           ADD WK-CUR-TAX          TO WK-G-TAX.
           ADD WK-CUR-TOT          TO WK-G-TOT.
           ADD WK-CUR-CNT          TO WK-G-CNT.
           ADD 1                   TO WK-CUST-CNT.
       FC-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           STRING "PERIOD " WK-DATE-FROM " - " WK-DATE-TO
               DELIMITED BY SIZE INTO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE RH-LINE            TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE 6                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-GRAND SECTION.
       PG-010.
           IF WK-G-CNT = 0
               PERFORM CHECK-PAGE
               MOVE "*** NO SALES IN THE SELECTED PERIOD ***"
                                   TO REP-REC
               WRITE REP-REC
               GO TO PG-999
           END-IF.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-G-CNT           TO RT-COUNT.
           MOVE WK-G-NET           TO RT-NET.
           MOVE WK-G-TAX           TO RT-TAX.
           MOVE WK-G-TOT           TO RT-TOT.
           MOVE RT-LINE            TO REP-REC.
           WRITE REP-REC.
       PG-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE INVHF CUSTF REPF.
           DISPLAY "RP0040 complete.  Customers = " WK-CUST-CNT
               "  Invoices = " WK-G-CNT.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0040"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
