       IDENTIFICATION DIVISION.
       PROGRAM-ID. MS0020.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : MS0020  -  Supplier master maintenance           *
      *  FUNCTION : add / change / delete / inquire supplier master. *
      *             Enter a supplier code; if it exists the record   *
      *             is shown for change or delete, otherwise a new   *
      *             record is entered.  The bank code is validated    *
      *             against the bank master and its name displayed.  *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SSUPP.
           COPY SBANK.
       I-O-CONTROL.
           APPLY SHARED-MODE ON SUPPF.
       DATA DIVISION.
       FILE SECTION.
           COPY FSUPP.
           COPY FBANK.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-LOOKUP.
           02  WK-BANK-NAME       PIC X(30) VALUE SPACE.
       01  WK-SAVE-CODE           PIC 9(6)  VALUE 0.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4 COLUMN 2  VALUE "Supplier Code :" COLOR YELLOW.
           02  SC-KEY LINE 4 COLUMN 20 PIC 9(6) USING SP-CODE.
       01  DS-BODY.
           02  LINE 6.
             03  COLUMN 2  VALUE "Name          :" COLOR YELLOW.
             03  COLUMN 20 PIC X(40) USING SP-NAME.
           02  LINE 7.
             03  COLUMN 2  VALUE "Search Name   :" COLOR YELLOW.
             03  COLUMN 20 PIC X(40) USING SP-KANA.
           02  LINE 8.
             03  COLUMN 2  VALUE "Post Code     :" COLOR YELLOW.
             03  COLUMN 20 PIC X(8)  USING SP-ZIP.
           02  LINE 9.
             03  COLUMN 2  VALUE "Address 1     :" COLOR YELLOW.
             03  COLUMN 20 PIC X(40) USING SP-ADDR1.
           02  LINE 10.
             03  COLUMN 2  VALUE "Address 2     :" COLOR YELLOW.
             03  COLUMN 20 PIC X(40) USING SP-ADDR2.
           02  LINE 11.
             03  COLUMN 2  VALUE "Telephone     :" COLOR YELLOW.
             03  COLUMN 20 PIC X(15) USING SP-TEL.
           02  LINE 12.
             03  COLUMN 2  VALUE "Facsimile     :" COLOR YELLOW.
             03  COLUMN 20 PIC X(15) USING SP-FAX.
           02  LINE 13.
             03  COLUMN 2  VALUE "Closing Day   :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(2)  USING SP-CLOSE-DAY.
             03  COLUMN 24 VALUE "(99=month end)" COLOR CYAN.
           02  LINE 14.
             03  COLUMN 2  VALUE "Pay Month     :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING SP-PAY-MONTH.
             03  COLUMN 24 VALUE "0:same 1:next 2:+2" COLOR CYAN.
           02  LINE 15.
             03  COLUMN 2  VALUE "Pay Day       :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(2)  USING SP-PAY-DAY.
             03  COLUMN 24 VALUE "(99=month end)" COLOR CYAN.
           02  LINE 16.
             03  COLUMN 2  VALUE "Pay Method    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING SP-PAY-METHOD.
             03  COLUMN 24 VALUE "1:cash 2:transfer 3:bill" COLOR CYAN.
           02  LINE 17.
             03  COLUMN 2  VALUE "Tax Type      :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING SP-TAX-TYPE.
             03  COLUMN 24 VALUE "1:excl 2:incl 3:exempt" COLOR CYAN.
           02  LINE 18.
             03  COLUMN 2  VALUE "AP Balance    :" COLOR YELLOW.
             03  COLUMN 20 PIC S9(11) FROM SP-BALANCE COLOR WHITE.
           02  LINE 19.
             03  COLUMN 2  VALUE "Bank Code     :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(4)  USING SP-BANK-CODE.
             03  COLUMN 26 PIC X(30) FROM WK-BANK-NAME COLOR WHITE.
           02  LINE 20.
             03  COLUMN 2  VALUE "Bank Account  :" COLOR YELLOW.
             03  COLUMN 20 PIC X(20) USING SP-BANK-ACCT.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Confirm (Y/N) :" COLOR YELLOW.
           02  SC-CONF LINE 21 COLUMN 20 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "MS0020"           TO WK-PROGID.
           MOVE "Supplier Master Maintenance"    TO WK-TITLE.
           MOVE "ENTER=Read  PF9=Delete  PF3=End" TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           OPEN I-O    SUPPF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SUPPF
               CLOSE SUPPF
               OPEN I-O SUPPF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SUPPF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT  BANKF.
           IF FSTS NOT = "00"
               MOVE "BANKF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-RTN-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE SPACE              TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-KEY
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-RTN-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLEAR-010.
           INITIALIZE SP-REC.
           MOVE SPACE              TO WK-BANK-NAME.
           MOVE SPACE              TO WK-CONFIRM.
       CLEAR-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-KEY SECTION.
       PKEY-010.
           IF SP-CODE = 0
               MOVE "Supplier code must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
           MOVE SP-CODE            TO WK-SAVE-CODE.
           READ SUPPF
               INVALID KEY
                   PERFORM SETUP-ADD
               NOT INVALID KEY
                   PERFORM SETUP-CHANGE
           END-READ.
           PERFORM EDIT-RECORD.
       PKEY-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-ADD SECTION.
       SADD-010.
           SET MODE-ADD TO TRUE.
           INITIALIZE SP-REC.
           MOVE WK-SAVE-CODE       TO SP-CODE.
           MOVE "New supplier - enter details" TO WK-MSG-LINE.
       SADD-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-CHANGE SECTION.
       SCHG-010.
           IF SP-DEL-FLAG = 1
               SET MODE-ADD TO TRUE
               MOVE "Deleted supplier - re-registering" TO WK-MSG-LINE
           ELSE
               SET MODE-CHG TO TRUE
               MOVE "Existing supplier - change or PF9 delete"
                                   TO WK-MSG-LINE
           END-IF.
           PERFORM LOOKUP-NAMES.
       SCHG-999.
           EXIT.
      *----------------------------------------------------------------
       EDIT-RECORD SECTION.
       EDIT-010.
           DISPLAY DS-MSG.
           DISPLAY DS-BODY.
           ACCEPT  DS-BODY.
           EVALUATE ESTS
               WHEN "03"
                   CONTINUE
               WHEN "04"
                   MOVE "Cancelled" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               WHEN "09"
                   IF MODE-CHG
                       PERFORM DELETE-RECORD
                   ELSE
                       MOVE "Nothing to delete" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   END-IF
               WHEN "00"
                   PERFORM VALIDATE-BODY
                   IF NOT ERR-YES
                       PERFORM SAVE-RECORD
                   END-IF
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       EDIT-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-BODY SECTION.
       VAL-010.
           MOVE 0                  TO ERR-FLG.
           IF SP-NAME = SPACE
               MOVE "Name is required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF SP-CLOSE-DAY NOT = 99
             IF SP-CLOSE-DAY < 1 OR SP-CLOSE-DAY > 31
               MOVE "Closing day must be 1-31 or 99" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
             END-IF
           END-IF.
           IF SP-PAY-DAY NOT = 99
             IF SP-PAY-DAY < 1 OR SP-PAY-DAY > 31
               MOVE "Pay day must be 1-31 or 99" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
             END-IF
           END-IF.
           IF SP-PAY-METHOD < 1 OR SP-PAY-METHOD > 3
               MOVE "Pay method must be 1-3" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF SP-TAX-TYPE < 1 OR SP-TAX-TYPE > 3
               MOVE "Tax type must be 1-3" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF SP-BANK-CODE NOT = 0
               MOVE SP-BANK-CODE   TO BK-CODE
               READ BANKF
                   INVALID KEY
                       MOVE "Bank code not found" TO WK-MSG-LINE
                       SET ERR-YES TO TRUE
                       GO TO VAL-999
                   NOT INVALID KEY
                       MOVE BK-NAME TO WK-BANK-NAME
               END-READ
           END-IF.
       VAL-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       SAVE-RECORD SECTION.
       SAVE-010.
           MOVE WK-SYSDATE         TO SP-UPD-DATE.
           MOVE WK-USER-CODE       TO SP-UPD-USER.
           MOVE 0                  TO SP-DEL-FLAG.
           IF MODE-ADD
               MOVE WK-SYSDATE     TO SP-ADD-DATE
               MOVE WK-USER-CODE   TO SP-ADD-USER
               WRITE SP-REC
                   INVALID KEY
                       MOVE "Write failed - duplicate" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Supplier added" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-WRITE
           ELSE
               REWRITE SP-REC
                   INVALID KEY
                       MOVE "Update failed" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Supplier updated" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-REWRITE
           END-IF.
       SAVE-999.
           EXIT.
      *----------------------------------------------------------------
       DELETE-RECORD SECTION.
       DEL-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Press Y then ENTER to delete" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               MOVE 1              TO SP-DEL-FLAG
               MOVE WK-SYSDATE     TO SP-UPD-DATE
               MOVE WK-USER-CODE   TO SP-UPD-USER
               REWRITE SP-REC
                   INVALID KEY
                       MOVE "Delete failed" TO WK-MSG-LINE
                   NOT INVALID KEY
                       MOVE "Supplier deleted" TO WK-MSG-LINE
               END-REWRITE
           ELSE
               MOVE "Delete cancelled" TO WK-MSG-LINE
           END-IF.
           DISPLAY DS-MSG.
       DEL-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-NAMES SECTION.
       LOOK-010.
           MOVE SPACE              TO WK-BANK-NAME.
           IF SP-BANK-CODE NOT = 0
               MOVE SP-BANK-CODE   TO BK-CODE
               READ BANKF
                   INVALID KEY
                       MOVE "??? unknown bank" TO WK-BANK-NAME
                   NOT INVALID KEY
                       MOVE BK-NAME TO WK-BANK-NAME
               END-READ
           END-IF.
       LOOK-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE SUPPF BANKF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "MS0020"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
