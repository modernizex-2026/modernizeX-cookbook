       IDENTIFICATION DIVISION.
       PROGRAM-ID. BT0020.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : BT0020  -  monthly close                         *
      *  FUNCTION : closes an accounting month (YYYYMM).  For posted *
      *             but un-closed sales invoices and purchases dated *
      *             within the month it stamps the closing period    *
      *             (IH-CLOSE-YM / VH-CLOSE-YM) and moves the status *
      *             to closed (2).  It then rolls the AR and AP      *
      *             ledger closing periods (AL-CLOSE-YM/PL-CLOSE-YM) *
      *             and captures each account's period-end balance.  *
      *             Finally it advances SYSCF: last monthly close    *
      *             and current accounting month (next month, via    *
      *             DATEUT).  Console / batch (no screen section).    *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SSYSC.
           COPY SINVH.
           COPY SPURH.
           COPY SARL.
           COPY SAPL.
       DATA DIVISION.
       FILE SECTION.
           COPY FSYSC.
           COPY FINVH.
           COPY FPURH.
           COPY FARL.
           COPY FAPL.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- run parameters --------------------------------------------
       01  WK-PARM.
           02  WK-IN-LINE          PIC X(10) VALUE SPACE.
           02  WK-TGT-YM           PIC 9(6)  VALUE 0.
           02  WK-DFLT-YM          PIC 9(6)  VALUE 0.
           02  WK-NEXT-YM          PIC 9(6)  VALUE 0.
           02  WK-PER-START        PIC 9(8)  VALUE 0.
           02  WK-PER-END          PIC 9(8)  VALUE 0.
      *----- sales invoice totals --------------------------------------
       01  WK-INV-TOT.
           02  WK-INV-READ         PIC 9(7)  VALUE 0.
           02  WK-INV-CLOSE        PIC 9(7)  VALUE 0.
           02  WK-INV-SKIP         PIC 9(7)  VALUE 0.
           02  WK-INV-AMT          PIC S9(13) VALUE 0.
           02  WK-INV-TAX          PIC S9(13) VALUE 0.
      *----- purchase totals -------------------------------------------
       01  WK-PUR-TOT.
           02  WK-PUR-READ         PIC 9(7)  VALUE 0.
           02  WK-PUR-CLOSE        PIC 9(7)  VALUE 0.
           02  WK-PUR-SKIP         PIC 9(7)  VALUE 0.
           02  WK-PUR-AMT          PIC S9(13) VALUE 0.
           02  WK-PUR-TAX          PIC S9(13) VALUE 0.
      *----- AR ledger totals ------------------------------------------
       01  WK-AR-TOT.
           02  WK-AR-READ          PIC 9(7)  VALUE 0.
           02  WK-AR-STAMP         PIC 9(7)  VALUE 0.
           02  WK-AR-CUST          PIC 9(7)  VALUE 0.
           02  WK-AR-DEBIT         PIC S9(13) VALUE 0.
           02  WK-AR-CREDIT        PIC S9(13) VALUE 0.
           02  WK-AR-CLOSEBAL      PIC S9(13) VALUE 0.
      *----- AP ledger totals ------------------------------------------
       01  WK-AP-TOT.
           02  WK-AP-READ          PIC 9(7)  VALUE 0.
           02  WK-AP-STAMP         PIC 9(7)  VALUE 0.
           02  WK-AP-SUPP          PIC 9(7)  VALUE 0.
           02  WK-AP-DEBIT         PIC S9(13) VALUE 0.
           02  WK-AP-CREDIT        PIC S9(13) VALUE 0.
           02  WK-AP-CLOSEBAL      PIC S9(13) VALUE 0.
      *----- control-break work ----------------------------------------
       01  WK-BREAK.
           02  WK-PREV-CUST        PIC 9(6)  VALUE 0.
           02  WK-PREV-SUPP        PIC 9(6)  VALUE 0.
           02  WK-CUST-BAL         PIC S9(11) VALUE 0.
           02  WK-SUPP-BAL         PIC S9(11) VALUE 0.
           02  WK-FIRST-FLG        PIC 9(1)  VALUE 0.
      *----- display edit work -----------------------------------------
       01  WK-DISP.
           02  WK-E-CNT            PIC Z,ZZZ,ZZ9.
           02  WK-E-AMT            PIC Z,ZZZ,ZZZ,ZZZ,ZZ9-.
           02  WK-E-YM             PIC 9999/99.
           02  WK-E-DATE           PIC 9999/99/99.
      *----- misc flags ------------------------------------------------
       01  WK-FLAGS.
           02  WK-ABORT-FLG        PIC 9(1)  VALUE 0.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           IF WK-ABORT-FLG = 0
               PERFORM CLOSE-INVOICES
               PERFORM CLOSE-PURCHASES
               PERFORM ROLL-AR
               PERFORM ROLL-AP
               PERFORM UPDATE-SYSCF
               PERFORM PRINT-SUMMARY
           END-IF.
           PERFORM TERM-RTN.
           MOVE 0                  TO COMPLETION-CODE.
           EXIT PROGRAM.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
      *  INIT                                                          *
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "BT0020"           TO WK-PROGID.
           DISPLAY " ".
           DISPLAY "==============================================".
           DISPLAY " SAKURA-SMS  BT0020  -  MONTHLY CLOSE".
           DISPLAY "==============================================".
           PERFORM GET-TODAY.
           PERFORM OPEN-FILES.
           PERFORM READ-SYSCF.
           MOVE SY-CURR-YM         TO WK-DFLT-YM.
           PERFORM ACCEPT-TARGET.
           IF WK-ABORT-FLG = 0
               PERFORM CALC-PERIOD
               PERFORM CONFIRM-RUN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       GET-TODAY SECTION.
       GTOD-010.
           MOVE "TODY"             TO KD-FUNC.
           MOVE 0                  TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE  WK-SYSYMD.
       GTOD-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPEN-010.
           PERFORM OPEN-SYSCF.
           PERFORM OPEN-INVHF.
           PERFORM OPEN-PURHF.
           PERFORM OPEN-ARLF.
           PERFORM OPEN-APLF.
       OPEN-999.
           EXIT.
       OPEN-SYSCF SECTION.
       OSYS-010.
           OPEN I-O SYSCF.
           IF FSTS NOT = "00"
               MOVE "SYSCF"        TO KA-FILE
               MOVE "Open SYSCF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OSYS-999.
           EXIT.
       OPEN-INVHF SECTION.
       OINV-010.
           OPEN I-O INVHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT INVHF
               CLOSE INVHF
               OPEN I-O INVHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "INVHF"        TO KA-FILE
               MOVE "Open INVHF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OINV-999.
           EXIT.
       OPEN-PURHF SECTION.
       OPUR-010.
           OPEN I-O PURHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PURHF
               CLOSE PURHF
               OPEN I-O PURHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "PURHF"        TO KA-FILE
               MOVE "Open PURHF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OPUR-999.
           EXIT.
       OPEN-ARLF SECTION.
       OARL-010.
           OPEN I-O ARLF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ARLF
               CLOSE ARLF
               OPEN I-O ARLF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ARLF"         TO KA-FILE
               MOVE "Open ARLF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OARL-999.
           EXIT.
       OPEN-APLF SECTION.
       OAPL-010.
           OPEN I-O APLF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT APLF
               CLOSE APLF
               OPEN I-O APLF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "APLF"         TO KA-FILE
               MOVE "Open APLF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OAPL-999.
           EXIT.
      *----------------------------------------------------------------
       READ-SYSCF SECTION.
       RSYS-010.
           MOVE 1                  TO SY-KEY.
           READ SYSCF
               INVALID KEY
                   MOVE "SYSCF"    TO KA-FILE
                   MOVE "System control record missing" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-READ.
       RSYS-999.
           EXIT.
      *----------------------------------------------------------------
       ACCEPT-TARGET SECTION.
       ATGT-010.
           MOVE WK-DFLT-YM         TO WK-E-YM.
           DISPLAY " ".
           DISPLAY " Current accounting month : " SY-CURR-YM.
           DISPLAY " Last monthly close       : " SY-LAST-MON-CLOSE.
           DISPLAY " Enter month to close YYYYMM".
           DISPLAY "   (blank = " WK-E-YM ") : " WITH NO ADVANCING.
           MOVE SPACE              TO WK-IN-LINE.
           ACCEPT WK-IN-LINE FROM CONSOLE.
           IF WK-IN-LINE = SPACE
               MOVE WK-DFLT-YM     TO WK-TGT-YM
           ELSE
               IF WK-IN-LINE(1:6) NUMERIC
                   MOVE WK-IN-LINE(1:6) TO WK-TGT-YM
               ELSE
                   DISPLAY " ** invalid month - run cancelled."
                   MOVE 1          TO WK-ABORT-FLG
                   GO TO ATGT-999
               END-IF
           END-IF.
           PERFORM VALIDATE-YM.
       ATGT-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-YM SECTION.
       VYM-010.
           MOVE 0                  TO WK-IDX.
           COMPUTE WK-IDX = WK-TGT-YM - (WK-TGT-YM / 100) * 100.
           IF WK-IDX < 1 OR WK-IDX > 12
               DISPLAY " ** month part must be 01-12."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       VYM-999.
           EXIT.
      *----------------------------------------------------------------
      *  CALC-PERIOD : derive first/last day + next month via DATEUT   *
      *----------------------------------------------------------------
       CALC-PERIOD SECTION.
       CPER-010.
           COMPUTE WK-PER-START = WK-TGT-YM * 100 + 1.
           MOVE "EOM "             TO KD-FUNC.
           MOVE WK-PER-START       TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           IF KD-STATUS NOT = "00"
               MOVE "SYSCF"        TO KA-FILE
               MOVE "EOM calc failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           MOVE KD-DATE1           TO WK-PER-END.
      *    advance to first day of the following month
           MOVE "ADDD"             TO KD-FUNC.
           MOVE WK-PER-END         TO KD-DATE1.
           MOVE 1                  TO KD-DAYS.
           CALL "DATEUT" USING KDATE.
           COMPUTE WK-NEXT-YM = KD-DATE1 / 100.
       CPER-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-RUN SECTION.
       CONF-010.
           MOVE WK-TGT-YM          TO WK-E-YM.
           MOVE WK-PER-START       TO WK-E-DATE.
           DISPLAY " ".
           DISPLAY " Close month " WK-E-YM " ("
               WK-PER-START " - " WK-PER-END ")".
           MOVE WK-NEXT-YM         TO WK-E-YM.
           DISPLAY " New current month will be " WK-E-YM.
           DISPLAY " Proceed ? (Y/N) : " WITH NO ADVANCING.
           MOVE SPACE              TO WK-CONFIRM.
           ACCEPT WK-CONFIRM FROM CONSOLE.
           IF NOT CONFIRM-YES
               DISPLAY " ** cancelled by operator."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       CONF-999.
           EXIT.
      *----------------------------------------------------------------
      *  CLOSE-INVOICES : stamp CLOSE-YM on posted sales invoices      *
      *----------------------------------------------------------------
       CLOSE-INVOICES SECTION.
       CINV-010.
           DISPLAY " ".
           DISPLAY " Closing sales invoices ...".
           MOVE 0                  TO EOF-FLG.
           MOVE WK-PER-START       TO IH-DATE.
           MOVE 0                  TO IH-NO.
           START INVHF KEY NOT LESS THAN IH-DATE
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM CINV-NEXT UNTIL EOF-YES.
       CINV-999.
           EXIT.
       CINV-NEXT SECTION.
       CINX-010.
           READ INVHF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO CINX-999
           END-READ.
           IF IH-DATE > WK-PER-END
               SET EOF-YES         TO TRUE
               GO TO CINX-999
           END-IF.
           ADD 1                   TO WK-INV-READ.
           IF IH-STATUS = 1 AND IH-CLOSE-YM = 0
               MOVE WK-TGT-YM      TO IH-CLOSE-YM
               MOVE 2              TO IH-STATUS
               MOVE WK-SYSDATE     TO IH-UPD-DATE
               MOVE WK-USER-CODE   TO IH-UPD-USER
               REWRITE IH-REC
                   INVALID KEY
                       MOVE "INVHF" TO KA-FILE
                       MOVE "REWRITE INVHF failed" TO KA-DETAIL
                       PERFORM ABEND-RTN
               END-REWRITE
               ADD 1               TO WK-INV-CLOSE
               IF IH-KIND = 2
                   SUBTRACT IH-AMOUNT     FROM WK-INV-AMT
                   SUBTRACT IH-TAX-AMOUNT FROM WK-INV-TAX
               ELSE
                   ADD IH-AMOUNT          TO WK-INV-AMT
                   ADD IH-TAX-AMOUNT      TO WK-INV-TAX
               END-IF
           ELSE
               ADD 1               TO WK-INV-SKIP
           END-IF.
       CINX-999.
           EXIT.
      *----------------------------------------------------------------
      *  CLOSE-PURCHASES : stamp CLOSE-YM on posted purchases          *
      *  (PURHF has no date key -> full sequential scan with filter)   *
      *----------------------------------------------------------------
       CLOSE-PURCHASES SECTION.
       CPUR-010.
           DISPLAY " Closing purchases ...".
           MOVE 0                  TO EOF-FLG.
           MOVE 0                  TO VH-NO.
           START PURHF KEY NOT LESS THAN VH-NO
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM CPUR-NEXT UNTIL EOF-YES.
       CPUR-999.
           EXIT.
       CPUR-NEXT SECTION.
       CPUX-010.
           READ PURHF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO CPUX-999
           END-READ.
           IF VH-DATE < WK-PER-START OR VH-DATE > WK-PER-END
               GO TO CPUX-999
           END-IF.
           ADD 1                   TO WK-PUR-READ.
           IF VH-STATUS = 1 AND VH-CLOSE-YM = 0
               MOVE WK-TGT-YM      TO VH-CLOSE-YM
               MOVE 2              TO VH-STATUS
               REWRITE VH-REC
                   INVALID KEY
                       MOVE "PURHF" TO KA-FILE
                       MOVE "REWRITE PURHF failed" TO KA-DETAIL
                       PERFORM ABEND-RTN
               END-REWRITE
               ADD 1               TO WK-PUR-CLOSE
               IF VH-KIND = 2
                   SUBTRACT VH-AMOUNT     FROM WK-PUR-AMT
                   SUBTRACT VH-TAX-AMOUNT FROM WK-PUR-TAX
               ELSE
                   ADD VH-AMOUNT          TO WK-PUR-AMT
                   ADD VH-TAX-AMOUNT      TO WK-PUR-TAX
               END-IF
           ELSE
               ADD 1               TO WK-PUR-SKIP
           END-IF.
       CPUX-999.
           EXIT.
      *----------------------------------------------------------------
      *  ROLL-AR : stamp CLOSE-YM on period AR entries, capture the    *
      *  period-end balance of each customer (control break on cust)   *
      *----------------------------------------------------------------
       ROLL-AR SECTION.
       RAR-010.
           DISPLAY " Rolling AR ledger ...".
           MOVE 0                  TO EOF-FLG.
           MOVE 1                  TO WK-FIRST-FLG.
           MOVE 0                  TO WK-PREV-CUST.
           MOVE 0                  TO WK-CUST-BAL.
           MOVE 0                  TO AL-CUST.
           MOVE 0                  TO AL-DATE.
           START ARLF KEY NOT LESS THAN AL-CUST
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM RAR-NEXT UNTIL EOF-YES.
      *    finalise the last customer group
           IF WK-FIRST-FLG = 0
               PERFORM AR-BREAK
           END-IF.
       RAR-999.
           EXIT.
       RAR-NEXT SECTION.
       RARX-010.
           READ ARLF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO RARX-999
           END-READ.
           IF WK-FIRST-FLG = 1
               MOVE 0              TO WK-FIRST-FLG
               MOVE AL-CUST        TO WK-PREV-CUST
               MOVE 0              TO WK-CUST-BAL
           END-IF.
           IF AL-CUST NOT = WK-PREV-CUST
               PERFORM AR-BREAK
               MOVE AL-CUST        TO WK-PREV-CUST
               MOVE 0              TO WK-CUST-BAL
           END-IF.
           ADD 1                   TO WK-AR-READ.
      *    running balance already stored on the entry -> closing bal
           MOVE AL-BALANCE         TO WK-CUST-BAL.
           IF AL-DATE NOT < WK-PER-START AND AL-DATE NOT > WK-PER-END
               ADD AL-DEBIT        TO WK-AR-DEBIT
               ADD AL-CREDIT       TO WK-AR-CREDIT
               IF AL-CLOSE-YM = 0
                   MOVE WK-TGT-YM  TO AL-CLOSE-YM
                   REWRITE AL-REC
                       INVALID KEY
                           MOVE "ARLF" TO KA-FILE
                           MOVE "REWRITE ARLF failed" TO KA-DETAIL
                           PERFORM ABEND-RTN
                   END-REWRITE
                   ADD 1           TO WK-AR-STAMP
               END-IF
           END-IF.
       RARX-999.
           EXIT.
       AR-BREAK SECTION.
       ARBK-010.
           ADD 1                   TO WK-AR-CUST.
           ADD WK-CUST-BAL         TO WK-AR-CLOSEBAL.
       ARBK-999.
           EXIT.
      *----------------------------------------------------------------
      *  ROLL-AP : same as ROLL-AR for the AP ledger / suppliers       *
      *----------------------------------------------------------------
       ROLL-AP SECTION.
       RAP-010.
           DISPLAY " Rolling AP ledger ...".
           MOVE 0                  TO EOF-FLG.
           MOVE 1                  TO WK-FIRST-FLG.
           MOVE 0                  TO WK-PREV-SUPP.
           MOVE 0                  TO WK-SUPP-BAL.
           MOVE 0                  TO PL-SUPP.
           MOVE 0                  TO PL-DATE.
           START APLF KEY NOT LESS THAN PL-SUPP
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM RAP-NEXT UNTIL EOF-YES.
           IF WK-FIRST-FLG = 0
               PERFORM AP-BREAK
           END-IF.
       RAP-999.
           EXIT.
       RAP-NEXT SECTION.
       RAPX-010.
           READ APLF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO RAPX-999
           END-READ.
           IF WK-FIRST-FLG = 1
               MOVE 0              TO WK-FIRST-FLG
               MOVE PL-SUPP        TO WK-PREV-SUPP
               MOVE 0              TO WK-SUPP-BAL
           END-IF.
           IF PL-SUPP NOT = WK-PREV-SUPP
               PERFORM AP-BREAK
               MOVE PL-SUPP        TO WK-PREV-SUPP
               MOVE 0              TO WK-SUPP-BAL
           END-IF.
           ADD 1                   TO WK-AP-READ.
           MOVE PL-BALANCE         TO WK-SUPP-BAL.
           IF PL-DATE NOT < WK-PER-START AND PL-DATE NOT > WK-PER-END
               ADD PL-DEBIT        TO WK-AP-DEBIT
               ADD PL-CREDIT       TO WK-AP-CREDIT
               IF PL-CLOSE-YM = 0
                   MOVE WK-TGT-YM  TO PL-CLOSE-YM
                   REWRITE PL-REC
                       INVALID KEY
                           MOVE "APLF" TO KA-FILE
                           MOVE "REWRITE APLF failed" TO KA-DETAIL
                           PERFORM ABEND-RTN
                   END-REWRITE
                   ADD 1           TO WK-AP-STAMP
               END-IF
           END-IF.
       RAPX-999.
           EXIT.
       AP-BREAK SECTION.
       APBK-010.
           ADD 1                   TO WK-AP-SUPP.
           ADD WK-SUPP-BAL         TO WK-AP-CLOSEBAL.
       APBK-999.
           EXIT.
      *----------------------------------------------------------------
      *  UPDATE-SYSCF : record close + advance current month           *
      *----------------------------------------------------------------
       UPDATE-SYSCF SECTION.
       USYS-010.
           MOVE 1                  TO SY-KEY.
           READ SYSCF
               INVALID KEY
                   MOVE "SYSCF"    TO KA-FILE
                   MOVE "Re-read SYSCF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-READ.
           MOVE WK-TGT-YM          TO SY-LAST-MON-CLOSE.
           MOVE WK-NEXT-YM         TO SY-CURR-YM.
           REWRITE SY-REC
               INVALID KEY
                   MOVE "SYSCF"    TO KA-FILE
                   MOVE "REWRITE SYSCF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-REWRITE.
       USYS-999.
           EXIT.
      *----------------------------------------------------------------
      *  PRINT-SUMMARY                                                 *
      *----------------------------------------------------------------
       PRINT-SUMMARY SECTION.
       PSUM-010.
           MOVE WK-TGT-YM          TO WK-E-YM.
           DISPLAY " ".
           DISPLAY "----------------------------------------------".
           DISPLAY " MONTHLY CLOSE SUMMARY  month " WK-E-YM.
           DISPLAY "----------------------------------------------".
           PERFORM PSUM-INV.
           PERFORM PSUM-PUR.
           PERFORM PSUM-AR.
           PERFORM PSUM-AP.
           MOVE WK-NEXT-YM         TO WK-E-YM.
           DISPLAY "----------------------------------------------".
           DISPLAY " New current month : " WK-E-YM.
           DISPLAY " BT0020 completed normally.".
       PSUM-999.
           EXIT.
       PSUM-INV SECTION.
       PSIN-010.
           MOVE WK-INV-READ        TO WK-E-CNT.
           DISPLAY " Invoices scanned  : " WK-E-CNT.
           MOVE WK-INV-CLOSE       TO WK-E-CNT.
           DISPLAY " Invoices closed   : " WK-E-CNT.
           MOVE WK-INV-AMT         TO WK-E-AMT.
           DISPLAY " Sales net amount  : " WK-E-AMT.
           MOVE WK-INV-TAX         TO WK-E-AMT.
           DISPLAY " Sales tax amount  : " WK-E-AMT.
       PSIN-999.
           EXIT.
       PSUM-PUR SECTION.
       PSPU-010.
           MOVE WK-PUR-READ        TO WK-E-CNT.
           DISPLAY " Purchases scanned : " WK-E-CNT.
           MOVE WK-PUR-CLOSE       TO WK-E-CNT.
           DISPLAY " Purchases closed  : " WK-E-CNT.
           MOVE WK-PUR-AMT         TO WK-E-AMT.
           DISPLAY " Purch net amount  : " WK-E-AMT.
           MOVE WK-PUR-TAX         TO WK-E-AMT.
           DISPLAY " Purch tax amount  : " WK-E-AMT.
       PSPU-999.
           EXIT.
       PSUM-AR SECTION.
       PSAR-010.
           MOVE WK-AR-READ         TO WK-E-CNT.
           DISPLAY " AR entries read   : " WK-E-CNT.
           MOVE WK-AR-STAMP        TO WK-E-CNT.
           DISPLAY " AR entries closed : " WK-E-CNT.
           MOVE WK-AR-CUST         TO WK-E-CNT.
           DISPLAY " AR customers      : " WK-E-CNT.
           MOVE WK-AR-DEBIT        TO WK-E-AMT.
           DISPLAY " AR debit total    : " WK-E-AMT.
           MOVE WK-AR-CREDIT       TO WK-E-AMT.
           DISPLAY " AR credit total   : " WK-E-AMT.
           MOVE WK-AR-CLOSEBAL     TO WK-E-AMT.
           DISPLAY " AR closing bal    : " WK-E-AMT.
       PSAR-999.
           EXIT.
       PSUM-AP SECTION.
       PSAP-010.
           MOVE WK-AP-READ         TO WK-E-CNT.
           DISPLAY " AP entries read   : " WK-E-CNT.
           MOVE WK-AP-STAMP        TO WK-E-CNT.
           DISPLAY " AP entries closed : " WK-E-CNT.
           MOVE WK-AP-SUPP         TO WK-E-CNT.
           DISPLAY " AP suppliers      : " WK-E-CNT.
           MOVE WK-AP-DEBIT        TO WK-E-AMT.
           DISPLAY " AP debit total    : " WK-E-AMT.
           MOVE WK-AP-CREDIT       TO WK-E-AMT.
           DISPLAY " AP credit total   : " WK-E-AMT.
           MOVE WK-AP-CLOSEBAL     TO WK-E-AMT.
           DISPLAY " AP closing bal    : " WK-E-AMT.
       PSAP-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE SYSCF.
           CLOSE INVHF.
           CLOSE PURHF.
           CLOSE ARLF.
           CLOSE APLF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABND-010.
           MOVE "BT0020"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EBATCH"           TO KA-MSGCODE.
           CALL "ABORTX" USING KABEND.
           CLOSE SYSCF.
           CLOSE INVHF.
           CLOSE PURHF.
           CLOSE ARLF.
           CLOSE APLF.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABND-999.
           EXIT.
