       IDENTIFICATION DIVISION.
       PROGRAM-ID. PU0040.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : PU0040  -  Purchase return entry                 *
      *  FUNCTION : return previously purchased goods to a supplier. *
      *             The supplier is validated and return lines are   *
      *             entered (product / warehouse / quantity / cost). *
      *             A purchase document (PURHF, VH-KIND=2) and its   *
      *             detail (PURDF) are written with NEGATIVE          *
      *             quantities and amounts using NUMGEN "PURCH".      *
      *             Stock on-hand is DECREASED and a return-out       *
      *             movement (SMOVF SM-KIND=60, negative qty) is      *
      *             written with NUMGEN "STKMOV".  The AP ledger is  *
      *             DEBITED (APLF, PL-KIND=3, PL-DEBIT) and the      *
      *             supplier balance (SP-BALANCE) is reduced.        *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SPURH.
           COPY SPURD.
           COPY SAPL.
           COPY SSTOK.
           COPY SSMOV.
           COPY SSUPP.
           COPY SPROD.
       I-O-CONTROL.
           APPLY SHARED-MODE ON PURHF
           APPLY SHARED-MODE ON PURDF
           APPLY SHARED-MODE ON APLF
           APPLY SHARED-MODE ON STOKF
           APPLY SHARED-MODE ON SMOVF
           APPLY SHARED-MODE ON SUPPF.
       DATA DIVISION.
       FILE SECTION.
           COPY FPURH.
           COPY FPURD.
           COPY FAPL.
           COPY FSTOK.
           COPY FSMOV.
           COPY FSUPP.
           COPY FPROD.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
      *----- control switches ------------------------------------------
       01  WK-FLAGS2.
           02  HDR-OK              PIC 9(1)  VALUE 0.
             88  HDR-YES                     VALUE 1.
           02  DTL-DONE            PIC 9(1)  VALUE 0.
             88  DTL-END                     VALUE 1.
      *----- header display work ---------------------------------------
       01  WK-HDR-DISP.
           02  WK-SUPP-NAME        PIC X(40) VALUE SPACE.
           02  WK-VH-NO-D          PIC 9(10) VALUE 0.
           02  WK-NEW-BAL          PIC S9(11) VALUE 0.
      *----- current detail line ---------------------------------------
       01  WK-DET.
           02  WK-D-PROD           PIC 9(8)  VALUE 0.
           02  WK-D-WHSE           PIC 9(3)  VALUE 0.
           02  WK-D-QTY            PIC S9(9) VALUE 0.
           02  WK-D-COST           PIC S9(9)V9(2) VALUE 0.
           02  WK-D-AMT            PIC S9(11)     VALUE 0.
           02  WK-D-NAME           PIC X(40) VALUE SPACE.
           02  WK-D-TAXCAT         PIC 9(1)  VALUE 1.
           02  WK-D-STKMNG         PIC 9(1)  VALUE 0.
           02  WK-D-AVAIL          PIC S9(9) VALUE 0.
      *----- running totals (positive magnitudes) ----------------------
       01  WK-TOTALS.
           02  WK-NET-TOTAL        PIC S9(13) VALUE 0.
           02  WK-TAX-TOTAL        PIC S9(13) VALUE 0.
           02  WK-GRS-TOTAL        PIC S9(13) VALUE 0.
      *----- return line buffer table ----------------------------------
       01  WK-LINE-TABLE.
           02  WK-LCNT             PIC 9(3)  VALUE 0.
           02  WK-LINE OCCURS 200 INDEXED BY LX.
             03  WL-PROD           PIC 9(8).
             03  WL-WHSE           PIC 9(3).
             03  WL-QTY            PIC S9(9).
             03  WL-COST           PIC S9(9)V9(2).
             03  WL-AMOUNT         PIC S9(11).
             03  WL-TAXCAT         PIC 9(1).
             03  WL-STKMNG         PIC 9(1).
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-HEAD.
           02  LINE 3.
             03  COLUMN 2  VALUE "Return No  :" COLOR YELLOW.
             03  COLUMN 16 PIC ZZZZZZZZZ9 FROM WK-VH-NO-D COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "Return Date:" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING VH-DATE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Supplier   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(6) USING VH-SUPP.
             03  COLUMN 24 PIC X(40) FROM WK-SUPP-NAME COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE "Tax Type   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(1) USING VH-TAX-TYPE.
             03  COLUMN 20 VALUE "1:excl 2:incl 3:exempt" COLOR CYAN.
           02  LINE 7.
             03  COLUMN 2  VALUE "Remark     :" COLOR YELLOW.
             03  COLUMN 16 PIC X(40) USING VH-REMARK.
       01  DS-DETAIL.
           02  LINE 12 COLUMN 2 VALUE "--- Return line entry ---"
                              COLOR CYAN.
           02  LINE 13.
             03  COLUMN 2  VALUE "Product    :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING WK-D-PROD.
             03  COLUMN 26 PIC X(40) FROM WK-D-NAME COLOR WHITE.
           02  LINE 14.
             03  COLUMN 2  VALUE "Warehouse  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(3) USING WK-D-WHSE.
           02  LINE 15.
             03  COLUMN 2  VALUE "Return Qty :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(9) USING WK-D-QTY.
           02  LINE 16.
             03  COLUMN 2  VALUE "Unit Cost  :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(9)V9(2) USING WK-D-COST.
       01  DS-STATUS.
           02  LINE 19.
             03  COLUMN 2  VALUE "Lines :" COLOR YELLOW.
             03  COLUMN 10 PIC ZZ9 FROM WK-LCNT COLOR WHITE.
             03  COLUMN 20 VALUE "Return Net:" COLOR YELLOW.
             03  COLUMN 32 PIC ---,---,---,--9 FROM WK-NET-TOTAL
                              COLOR WHITE.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Post return ? (Y/N) :"
                              COLOR YELLOW.
           02  LINE 21 COLUMN 24 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM RETURN-LOOP UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "PU0040"           TO WK-PROGID.
           MOVE "Purchase Return Entry"            TO WK-TITLE.
           MOVE "ENTER=Next  PF3=End/Finish  PF4=Clear line"
                                   TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           COMPUTE WK-SYS-YM = WK-SYSDATE / 100.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           PERFORM OPEN-IO-FILE-PURH.
           PERFORM OPEN-IO-FILE-PURD.
           PERFORM OPEN-IO-FILE-APL.
           PERFORM OPEN-IO-FILE-STOK.
           PERFORM OPEN-IO-FILE-SMOV.
           PERFORM OPEN-IO-FILE-SUPP.
           OPEN INPUT PRODF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-PURH SECTION.
       OFVH-010.
           OPEN I-O PURHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PURHF
               CLOSE PURHF
               OPEN I-O PURHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "PURHF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFVH-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-PURD SECTION.
       OFVD-010.
           OPEN I-O PURDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PURDF
               CLOSE PURDF
               OPEN I-O PURDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "PURDF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFVD-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-APL SECTION.
       OFPL-010.
           OPEN I-O APLF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT APLF
               CLOSE APLF
               OPEN I-O APLF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "APLF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFPL-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-STOK SECTION.
       OFSK-010.
           OPEN I-O STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFSK-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-SMOV SECTION.
       OFSM-010.
           OPEN I-O SMOVF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SMOVF
               CLOSE SMOVF
               OPEN I-O SMOVF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SMOVF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFSM-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-SUPP SECTION.
       OFSP-010.
           OPEN I-O SUPPF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SUPPF
               CLOSE SUPPF
               OPEN I-O SUPPF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SUPPF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFSP-999.
           EXIT.
      *----------------------------------------------------------------
       RETURN-LOOP SECTION.
       RLOOP-010.
           PERFORM CLEAR-RETURN.
           PERFORM ENTER-HEADER.
           IF END-YES
               GO TO RLOOP-999
           END-IF.
           IF NOT HDR-YES
               GO TO RLOOP-999
           END-IF.
           PERFORM DETAIL-LOOP UNTIL DTL-END.
           IF WK-LCNT > 0
               PERFORM CONFIRM-SAVE
           ELSE
               MOVE "No lines entered - return discarded"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       RLOOP-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-RETURN SECTION.
       CLRR-010.
           INITIALIZE VH-REC.
           INITIALIZE WK-DET.
           MOVE 0                  TO WK-LCNT.
           MOVE 0                  TO WK-NET-TOTAL WK-TAX-TOTAL.
           MOVE 0                  TO WK-GRS-TOTAL WK-NEW-BAL.
           MOVE 0                  TO HDR-OK DTL-DONE.
           MOVE 0                  TO WK-VH-NO-D.
           MOVE SPACE              TO WK-SUPP-NAME WK-CONFIRM.
           MOVE WK-SYSDATE         TO VH-DATE.
           MOVE 1                  TO VH-TAX-TYPE.
       CLRR-999.
           EXIT.
      *----------------------------------------------------------------
       ENTER-HEADER SECTION.
       EHDR-010.
           MOVE 0                  TO HDR-OK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter return header - PF3 to quit" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-HEAD.
           ACCEPT  DS-HEAD.
           IF ESTS = "03"
               IF VH-SUPP = 0
                   SET END-YES TO TRUE
               END-IF
               GO TO EHDR-999
           END-IF.
           PERFORM VALIDATE-HEADER.
       EHDR-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-HEADER SECTION.
       VHDR-010.
           IF VH-SUPP = 0
               MOVE "Supplier code required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO VHDR-999
           END-IF.
           MOVE VH-SUPP            TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE "Supplier not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO VHDR-999
           END-READ.
           IF SP-DEL-FLAG = 1
               MOVE "Supplier is deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO VHDR-999
           END-IF.
           MOVE SP-NAME            TO WK-SUPP-NAME.
           IF VH-TAX-TYPE = 0
               MOVE SP-TAX-TYPE    TO VH-TAX-TYPE
           END-IF.
           IF VH-TAX-TYPE = 0
               MOVE 1              TO VH-TAX-TYPE
           END-IF.
           MOVE 1                  TO HDR-OK.
           DISPLAY DS-HEAD.
           MOVE "Header OK - enter return lines" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       VHDR-999.
           EXIT.
      *----------------------------------------------------------------
       DETAIL-LOOP SECTION.
       DLOOP-010.
           PERFORM CLEAR-DETAIL.
           DISPLAY DS-DETAIL.
           DISPLAY DS-STATUS.
           ACCEPT  DS-DETAIL.
           EVALUATE ESTS
               WHEN "03"
                   SET DTL-END TO TRUE
               WHEN "04"
                   MOVE "Line cleared" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               WHEN "00"
                   PERFORM PROCESS-DETAIL
               WHEN OTHER
                   MOVE "Invalid key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       DLOOP-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-DETAIL SECTION.
       CLRD-010.
           MOVE 0                  TO WK-D-PROD WK-D-WHSE WK-D-QTY.
           MOVE 0                  TO WK-D-COST WK-D-AMT WK-D-AVAIL.
           MOVE 0                  TO WK-D-STKMNG.
           MOVE 1                  TO WK-D-TAXCAT.
           MOVE SPACE              TO WK-D-NAME.
       CLRD-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-DETAIL SECTION.
       PDET-010.
           IF WK-D-PROD = 0
               MOVE "Product code required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           MOVE WK-D-PROD          TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "Product not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PDET-999
           END-READ.
           IF PR-DEL-FLAG = 1
               MOVE "Product is deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           MOVE PR-NAME            TO WK-D-NAME.
           MOVE PR-TAX-CATEGORY    TO WK-D-TAXCAT.
           MOVE PR-STOCK-MNG       TO WK-D-STKMNG.
           IF WK-D-WHSE = 0
               MOVE PR-DFLT-WHSE   TO WK-D-WHSE
           END-IF.
           IF WK-D-WHSE = 0
               MOVE "Warehouse required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           IF WK-D-QTY <= 0
               MOVE "Return qty must be positive" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           IF WK-D-COST <= 0
               PERFORM RESOLVE-COST
           END-IF.
           IF WK-D-COST <= 0
               MOVE "Unit cost required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           COMPUTE WK-D-AMT ROUNDED = WK-D-QTY * WK-D-COST.
           PERFORM CHECK-STOCK.
           PERFORM ADD-LINE.
       PDET-999.
           EXIT.
      *----------------------------------------------------------------
      *  Cost defaulting : moving-average from stock, else product.
      *----------------------------------------------------------------
       RESOLVE-COST SECTION.
       RCST-010.
           MOVE WK-D-PROD          TO SK-PROD.
           MOVE WK-D-WHSE          TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   MOVE 0          TO WK-D-COST
               NOT INVALID KEY
                   IF SK-AVG-COST > 0
                       MOVE SK-AVG-COST TO WK-D-COST
                   END-IF
           END-READ.
           IF WK-D-COST <= 0
               IF PR-LAST-COST > 0
                   MOVE PR-LAST-COST TO WK-D-COST
               ELSE
                   MOVE PR-STD-COST TO WK-D-COST
               END-IF
           END-IF.
       RCST-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-STOCK SECTION.
       CSTK-010.
           IF WK-D-STKMNG = 0
               GO TO CSTK-999
           END-IF.
           MOVE WK-D-PROD          TO SK-PROD.
           MOVE WK-D-WHSE          TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   MOVE 0          TO WK-D-AVAIL
               NOT INVALID KEY
                   MOVE SK-ONHAND  TO WK-D-AVAIL
           END-READ.
           IF WK-D-QTY > WK-D-AVAIL
               MOVE "Warning: return qty exceeds on-hand stock"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CSTK-999.
           EXIT.
      *----------------------------------------------------------------
       ADD-LINE SECTION.
       ADDL-010.
           IF WK-LCNT >= 200
               MOVE "Maximum 200 lines reached" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO ADDL-999
           END-IF.
           ADD 1                   TO WK-LCNT.
           SET LX                  TO WK-LCNT.
           MOVE WK-D-PROD          TO WL-PROD (LX).
           MOVE WK-D-WHSE          TO WL-WHSE (LX).
           MOVE WK-D-QTY           TO WL-QTY  (LX).
           MOVE WK-D-COST          TO WL-COST (LX).
           MOVE WK-D-AMT           TO WL-AMOUNT(LX).
           MOVE WK-D-TAXCAT        TO WL-TAXCAT(LX).
           MOVE WK-D-STKMNG        TO WL-STKMNG(LX).
           ADD  WK-D-AMT           TO WK-NET-TOTAL.
           DISPLAY DS-STATUS.
           MOVE "Line added"       TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       ADDL-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-SAVE SECTION.
       CSAV-010.
           MOVE SPACE              TO WK-CONFIRM.
           PERFORM COMPUTE-TAX-TOTAL.
           DISPLAY DS-STATUS.
           MOVE "Review totals then confirm return" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               PERFORM SAVE-RETURN
           ELSE
               MOVE "Return discarded" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CSAV-999.
           EXIT.
      *----------------------------------------------------------------
       COMPUTE-TAX-TOTAL SECTION.
       CTT-010.
           MOVE 1                  TO KT-CATEGORY.
           MOVE VH-TAX-TYPE        TO KT-TAX-TYPE.
           MOVE 1                  TO KT-ROUND.
           MOVE VH-DATE            TO KT-DATE.
           MOVE WK-NET-TOTAL       TO KT-AMOUNT.
           CALL "TAXCAL" USING KTAX.
           IF KT-STATUS = "00"
               MOVE KT-NET         TO WK-NET-TOTAL
               MOVE KT-TAX         TO WK-TAX-TOTAL
               MOVE KT-GROSS       TO WK-GRS-TOTAL
           ELSE
               MOVE 0              TO WK-TAX-TOTAL
               MOVE WK-NET-TOTAL   TO WK-GRS-TOTAL
           END-IF.
       CTT-999.
           EXIT.
      *----------------------------------------------------------------
      *  Write the return header (negative amounts) then post lines.
      *----------------------------------------------------------------
       SAVE-RETURN SECTION.
       SRT-010.
           MOVE "PURCH"            TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Number assignment failed" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO SRT-999
           END-IF.
           MOVE KNUM-NUMBER        TO VH-NO  WK-VH-NO-D.
           MOVE VH-SUPP            TO VH-SUPP.
           MOVE 0                  TO VH-RECV-NO.
           COMPUTE VH-CLOSE-YM = VH-DATE / 100.
           COMPUTE VH-AMOUNT     = 0 - WK-NET-TOTAL.
           COMPUTE VH-TAX-AMOUNT = 0 - WK-TAX-TOTAL.
           COMPUTE VH-TOTAL      = 0 - WK-GRS-TOTAL.
           MOVE 0                  TO VH-STATUS.
           MOVE 2                  TO VH-KIND.
           MOVE WK-LCNT            TO VH-LINES.
           MOVE WK-SYSDATE         TO VH-ADD-DATE.
           MOVE WK-USER-CODE       TO VH-ADD-USER.
           MOVE 0                  TO VH-DEL-FLAG.
           WRITE VH-REC
               INVALID KEY
                   MOVE "Header write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO SRT-999
           END-WRITE.
           PERFORM WRITE-DETAILS.
           PERFORM POST-AP.
           MOVE "Purchase return posted" TO WK-MSG-LINE.
           DISPLAY DS-STATUS.
           DISPLAY DS-MSG.
       SRT-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-DETAILS SECTION.
       WDET-010.
           PERFORM VARYING LX FROM 1 BY 1 UNTIL LX > WK-LCNT
               INITIALIZE VD-REC
               MOVE VH-NO          TO VD-NO
               SET WK-IDX TO LX
               MOVE WK-IDX TO VD-LINE
               MOVE WL-PROD  (LX)  TO VD-PROD
               MOVE WL-WHSE  (LX)  TO VD-WHSE
               COMPUTE VD-QTY    = 0 - WL-QTY (LX)
               MOVE WL-COST  (LX)  TO VD-UNIT-COST
               COMPUTE VD-AMOUNT = 0 - WL-AMOUNT (LX)
               MOVE WL-TAXCAT(LX)  TO VD-TAX-CATEGORY
               WRITE VD-REC
                   INVALID KEY
                       CONTINUE
               END-WRITE
               IF WL-STKMNG (LX) = 1
                   PERFORM DECREASE-STOCK
                   PERFORM WRITE-MOVEMENT
               END-IF
           END-PERFORM.
       WDET-999.
           EXIT.
      *----------------------------------------------------------------
      *  Reduce on-hand stock for the returned quantity.
      *----------------------------------------------------------------
       DECREASE-STOCK SECTION.
       DST-010.
           MOVE WL-PROD (LX)       TO SK-PROD.
           MOVE WL-WHSE (LX)       TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   INITIALIZE SK-REC
                   MOVE WL-PROD (LX) TO SK-PROD
                   MOVE WL-WHSE (LX) TO SK-WHSE
                   COMPUTE SK-ONHAND = 0 - WL-QTY (LX)
                   MOVE WL-COST (LX) TO SK-AVG-COST
                   MOVE VH-DATE    TO SK-LAST-OUT-DATE
                   MOVE WL-QTY (LX) TO SK-YTD-OUT
                   WRITE SK-REC
                       INVALID KEY CONTINUE
                   END-WRITE
               NOT INVALID KEY
                   SUBTRACT WL-QTY (LX) FROM SK-ONHAND
                   MOVE VH-DATE    TO SK-LAST-OUT-DATE
                   ADD WL-QTY (LX) TO SK-YTD-OUT
                   REWRITE SK-REC
                       INVALID KEY CONTINUE
                   END-REWRITE
           END-READ.
       DST-999.
           EXIT.
      *----------------------------------------------------------------
      *  Write a return-out stock movement (SM-KIND=60, negative qty).
      *----------------------------------------------------------------
       WRITE-MOVEMENT SECTION.
       WMV-010.
           MOVE "STKMOV"           TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               GO TO WMV-999
           END-IF.
           INITIALIZE SM-REC.
           MOVE KNUM-NUMBER        TO SM-SEQ.
           MOVE VH-DATE            TO SM-DATE.
           MOVE WL-PROD (LX)       TO SM-PROD.
           MOVE WL-WHSE (LX)       TO SM-WHSE.
           MOVE 60                 TO SM-KIND.
           COMPUTE SM-QTY = 0 - WL-QTY (LX).
           MOVE WL-COST (LX)       TO SM-UNIT-COST.
           MOVE SK-ONHAND          TO SM-BAL-AFTER.
           MOVE 23                 TO SM-REF-TYPE.
           MOVE VH-NO              TO SM-REF-NO.
           MOVE WK-USER-CODE       TO SM-USER.
           WRITE SM-REC
               INVALID KEY
                   CONTINUE
           END-WRITE.
       WMV-999.
           EXIT.
      *----------------------------------------------------------------
      *  Debit the AP ledger and reduce the supplier balance.
      *----------------------------------------------------------------
       POST-AP SECTION.
       PAP-010.
           MOVE "APLDG"            TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "AP ledger number assignment failed" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PAP-999
           END-IF.
           MOVE VH-SUPP            TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE 0          TO SP-BALANCE
           END-READ.
           COMPUTE WK-NEW-BAL = SP-BALANCE - WK-GRS-TOTAL.
           INITIALIZE PL-REC.
           MOVE KNUM-NUMBER        TO PL-SEQ.
           MOVE VH-SUPP            TO PL-SUPP.
           MOVE VH-DATE            TO PL-DATE.
           MOVE VH-CLOSE-YM        TO PL-CLOSE-YM.
           MOVE 3                  TO PL-KIND.
           MOVE 23                 TO PL-REF-TYPE.
           MOVE VH-NO              TO PL-REF-NO.
           MOVE WK-GRS-TOTAL       TO PL-DEBIT.
           MOVE 0                  TO PL-CREDIT.
           MOVE WK-NEW-BAL         TO PL-BALANCE.
           MOVE "Purchase return"  TO PL-REMARK.
           MOVE WK-USER-CODE       TO PL-USER.
           WRITE PL-REC
               INVALID KEY
                   MOVE "AP ledger write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
           PERFORM UPDATE-SUPP-BAL.
       PAP-999.
           EXIT.
      *----------------------------------------------------------------
       UPDATE-SUPP-BAL SECTION.
       USB-010.
           MOVE VH-SUPP            TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   GO TO USB-999
           END-READ.
           MOVE WK-NEW-BAL         TO SP-BALANCE.
           MOVE WK-SYSDATE         TO SP-UPD-DATE.
           MOVE WK-USER-CODE       TO SP-UPD-USER.
           REWRITE SP-REC
               INVALID KEY
                   CONTINUE
           END-REWRITE.
       USB-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE PURHF PURDF APLF STOKF SMOVF SUPPF PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "PU0040"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
