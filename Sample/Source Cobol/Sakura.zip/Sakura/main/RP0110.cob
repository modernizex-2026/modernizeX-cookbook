       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0110.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0110  -  Reorder suggestion report             *
      *  FUNCTION : walk the product master (stock-managed items),   *
      *             total on-hand and on-order across every          *
      *             warehouse from the stock-balance file, and where *
      *             the projected quantity (on-hand + on-order) has  *
      *             fallen to or below the reorder point, print a    *
      *             suggested purchase of the reorder quantity with  *
      *             the default supplier name and lead-time days.    *
      *             Grand totals of suggested items and suggested    *
      *             purchase value (reorder qty * standard cost).    *
      *             132-column line-sequential batch text report.    *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SPROD.
           COPY SSTOK.
           COPY SSUPP.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FPROD.
           COPY FSTOK.
           COPY FSUPP.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0110.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- control flags ---------------------------------------------
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
           02  WK-STK-EOF          PIC 9(1)  VALUE 0.
             88  STK-EOF                     VALUE 1.
      *----- console parameters ----------------------------------------
       01  WK-PARM.
           02  WK-IN-SUPP          PIC X(8)  VALUE SPACE.
           02  WK-SUPP-FILTER      PIC 9(6)  VALUE 0.
      *----- per-product accumulators ----------------------------------
       01  WK-STOCK.
           02  WK-ONHAND-SUM       PIC S9(11) VALUE 0.
           02  WK-ONORDER-SUM      PIC S9(11) VALUE 0.
           02  WK-PROJECTED        PIC S9(11) VALUE 0.
       01  WK-SUG-VALUE            PIC S9(15) COMP-3 VALUE 0.
       01  WK-SUPP-NAME            PIC X(20) VALUE SPACE.
       01  WK-COMPANY              PIC X(40) VALUE SPACE.
      *----- counters / grand totals -----------------------------------
       01  WK-COUNTS.
           02  WK-SCAN-CNT         PIC 9(7)  VALUE 0.
           02  WK-SUG-CNT          PIC 9(7)  VALUE 0.
       01  WK-TOTALS.
           02  WK-G-ITEMS          PIC 9(7)  VALUE 0.
           02  WK-G-QTY            PIC S9(13) COMP-3 VALUE 0.
           02  WK-G-VALUE          PIC S9(15) COMP-3 VALUE 0.
      *----- report layout ---------------------------------------------
       01  RPT-RULE               PIC X(126) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RC-HEAD.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(8)  VALUE "PRODUCT".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(22) VALUE "PRODUCT NAME".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(12) VALUE "     ON-HAND".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(12) VALUE "    ON-ORDER".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(12) VALUE "    RE-POINT".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(12) VALUE " SUGGEST-QTY".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(15) VALUE "    ORDER-VALUE".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(4)  VALUE "LEAD".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(20) VALUE "SUPPLIER".
       01  RD-LINE.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-PROD   PIC 9(8).
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-NAME   PIC X(22).
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-ONHAND PIC ----,---,--9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-ONORD  PIC ----,---,--9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-RPOINT PIC ----,---,--9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-SUGQTY PIC ----,---,--9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-VALUE  PIC ---,---,---,--9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-LEAD   PIC ZZZ9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-SUPP   PIC X(20).
       01  RT-LINE.
           02  FILLER    PIC X(21) VALUE " GRAND TOTAL ITEMS : ".
           02  RT-ITEMS  PIC ZZ,ZZ9.
           02  FILLER    PIC X(16) VALUE "   SUGGEST-QTY :".
           02  RT-QTY    PIC ---,---,---,--9.
           02  FILLER    PIC X(16) VALUE "   ORDER-VALUE :".
           02  RT-VALUE  PIC ---,---,---,--9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PARM-RTN.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0110"           TO WK-PROGID.
           MOVE "REORDER SUGGESTION REPORT"     TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT PRODF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "PRODF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT STOKF.
           OPEN INPUT SUPPF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PARM-RTN SECTION.
       PARM-010.
           DISPLAY "RP0110 - Reorder suggestion report".
           DISPLAY "Default-supplier filter code (blank=all): ".
           ACCEPT  WK-IN-SUPP FROM CONSOLE.
           IF WK-IN-SUPP NUMERIC AND WK-IN-SUPP NOT = SPACE
               MOVE WK-IN-SUPP     TO WK-SUPP-FILTER
           ELSE
               MOVE 0              TO WK-SUPP-FILTER
           END-IF.
       PARM-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRINT-010.
           MOVE 0                  TO WK-SCAN-CNT WK-SUG-CNT.
           MOVE 99                 TO WK-LINE.
           IF NOT MAIN-EOF
               MOVE 0              TO PR-CODE
               START PRODF KEY NOT < PR-CODE
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-PROD UNTIL MAIN-EOF.
           PERFORM PRINT-GRAND.
       PRINT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-PROD SECTION.
       RDP-010.
           READ PRODF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   PERFORM PROCESS-PROD
           END-READ.
       RDP-999.
           EXIT.
      *----------------------------------------------------------------
      *  PROCESS-PROD : filter one product, total its stock and, if    *
      *  below the reorder point, print a reorder suggestion line
      *----------------------------------------------------------------
       PROCESS-PROD SECTION.
       PP-010.
           ADD 1                   TO WK-SCAN-CNT.
           IF PR-DEL-FLAG = 1
               GO TO PP-999
           END-IF.
           IF PR-STOCK-MNG NOT = 1
               GO TO PP-999
           END-IF.
           IF WK-SUPP-FILTER NOT = 0
               IF PR-DFLT-SUPP NOT = WK-SUPP-FILTER
                   GO TO PP-999
               END-IF
           END-IF.
           PERFORM SUM-STOCK.
           COMPUTE WK-PROJECTED = WK-ONHAND-SUM + WK-ONORDER-SUM.
           IF WK-PROJECTED > PR-REORDER-POINT
               GO TO PP-999
           END-IF.
           PERFORM PRINT-ONE.
       PP-999.
           EXIT.
      *----------------------------------------------------------------
      *  SUM-STOCK : total SK-ONHAND / SK-ON-ORDER for this product
      *  across all warehouses (primary key SK-PROD + SK-WHSE)
      *----------------------------------------------------------------
       SUM-STOCK SECTION.
       SS-010.
           MOVE 0                  TO WK-ONHAND-SUM.
           MOVE 0                  TO WK-ONORDER-SUM.
           MOVE 0                  TO WK-STK-EOF.
           MOVE PR-CODE            TO SK-PROD.
           MOVE 0                  TO SK-WHSE.
           START STOKF KEY NOT < SK-PROD
               INVALID KEY
                   MOVE 1          TO WK-STK-EOF
           END-START.
           PERFORM SS-READ UNTIL STK-EOF.
       SS-999.
           EXIT.
       SS-READ SECTION.
       SSR-010.
           READ STOKF NEXT
               AT END
                   MOVE 1          TO WK-STK-EOF
               NOT AT END
                   IF SK-PROD NOT = PR-CODE
                       MOVE 1      TO WK-STK-EOF
                   ELSE
                       ADD SK-ONHAND    TO WK-ONHAND-SUM
                       ADD SK-ON-ORDER  TO WK-ONORDER-SUM
                   END-IF
           END-READ.
       SSR-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-ONE SECTION.
       PO-010.
           PERFORM CHECK-PAGE.
           PERFORM LOOKUP-SUPP.
           COMPUTE WK-SUG-VALUE ROUNDED =
               PR-REORDER-QTY * PR-STD-COST.
           MOVE PR-CODE            TO RL-PROD.
           MOVE PR-NAME            TO RL-NAME.
           MOVE WK-ONHAND-SUM      TO RL-ONHAND.
           MOVE WK-ONORDER-SUM     TO RL-ONORD.
           MOVE PR-REORDER-POINT   TO RL-RPOINT.
           MOVE PR-REORDER-QTY     TO RL-SUGQTY.
           MOVE WK-SUG-VALUE       TO RL-VALUE.
           MOVE PR-LEAD-DAYS       TO RL-LEAD.
           MOVE WK-SUPP-NAME       TO RL-SUPP.
           MOVE RD-LINE            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           ADD 1                   TO WK-SUG-CNT.
           ADD 1                   TO WK-G-ITEMS.
           ADD PR-REORDER-QTY      TO WK-G-QTY.
           ADD WK-SUG-VALUE        TO WK-G-VALUE.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-SUPP SECTION.
       LKS-010.
           MOVE SPACE              TO WK-SUPP-NAME.
           IF PR-DFLT-SUPP = 0
               MOVE "(no default supplier)" TO WK-SUPP-NAME
               GO TO LKS-999
           END-IF.
           MOVE PR-DFLT-SUPP       TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE "(unknown supplier)" TO WK-SUPP-NAME
               NOT INVALID KEY
                   MOVE SP-NAME     TO WK-SUPP-NAME
           END-READ.
       LKS-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           IF WK-SUPP-FILTER = 0
               MOVE "SUPPLIER: ALL" TO H2-INFO
           ELSE
               STRING "SUPPLIER: " WK-SUPP-FILTER
                   DELIMITED BY SIZE INTO H2-INFO
           END-IF.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE RC-HEAD            TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE 6                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-GRAND SECTION.
       PG-010.
           IF WK-SUG-CNT = 0
               PERFORM CHECK-PAGE
               MOVE "*** NO REORDER SUGGESTIONS ***" TO REP-REC
               WRITE REP-REC
               GO TO PG-999
           END-IF.
           PERFORM CHECK-PAGE.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-G-ITEMS         TO RT-ITEMS.
           MOVE WK-G-QTY           TO RT-QTY.
           MOVE WK-G-VALUE         TO RT-VALUE.
           MOVE RT-LINE            TO REP-REC.
           WRITE REP-REC.
       PG-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE PRODF STOKF SUPPF REPF.
           DISPLAY "RP0110 complete.  Products scanned = " WK-SCAN-CNT.
           DISPLAY "         Reorder suggestions        = " WK-SUG-CNT.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0110"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
