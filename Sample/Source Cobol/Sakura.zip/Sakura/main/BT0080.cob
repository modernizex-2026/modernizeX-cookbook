       IDENTIFICATION DIVISION.
       PROGRAM-ID. BT0080.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : BT0080  -  reindex / rebuild (reorg)              *
      *  FUNCTION : simulates an off-line reorganisation of a master  *
      *             file.  It reads the live (non deleted) records of *
      *             CUSTF and PRODF in key order and copies each one  *
      *             to a fresh sequential reorg file (data/*.RGN),    *
      *             dropping logically-deleted rows.  This reclaims   *
      *             the space of deleted records and rewrites the      *
      *             file compactly.  Reports records copied and rows  *
      *             skipped (deleted) for each master.                *
      *             Console / batch (no screen section).               *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SCUST.
           COPY SPROD.
      *----- reorg output files (compact sequential copies) ------------
           SELECT  CUSTN        ASSIGN  TO  CUSTN-MSD
                   ORGANIZATION      SEQUENTIAL
                   ACCESS MODE       SEQUENTIAL
                   FILE STATUS       FSTS.
           SELECT  PRODN        ASSIGN  TO  PRODN-MSD
                   ORGANIZATION      SEQUENTIAL
                   ACCESS MODE       SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FCUST.
           COPY FPROD.
       FD  CUSTN
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "CUSTF.RGN".
       01  NC-REC                  PIC X(313).
       FD  PRODN
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "PRODF.RGN".
       01  NP-REC                  PIC X(267).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- counters --------------------------------------------------
       01  WK-TOTALS.
           02  WK-CU-READ          PIC 9(7)  VALUE 0.
           02  WK-CU-COPY          PIC 9(7)  VALUE 0.
           02  WK-CU-SKIP          PIC 9(7)  VALUE 0.
           02  WK-PR-READ          PIC 9(7)  VALUE 0.
           02  WK-PR-COPY          PIC 9(7)  VALUE 0.
           02  WK-PR-SKIP          PIC 9(7)  VALUE 0.
      *----- display edit work -----------------------------------------
       01  WK-DISP.
           02  WK-E-CNT            PIC Z,ZZZ,ZZ9.
      *----- flags -----------------------------------------------------
       01  WK-FLAGS.
           02  WK-ABORT-FLG        PIC 9(1)  VALUE 0.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           IF WK-ABORT-FLG = 0
               PERFORM REORG-CUST
               PERFORM REORG-PROD
               PERFORM PRINT-SUMMARY
           END-IF.
           PERFORM TERM-RTN.
           MOVE 0                  TO COMPLETION-CODE.
           EXIT PROGRAM.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "BT0080"           TO WK-PROGID.
           DISPLAY " ".
           DISPLAY "==============================================".
           DISPLAY " SAKURA-SMS  BT0080  -  REINDEX / REBUILD".
           DISPLAY "==============================================".
           PERFORM GET-TODAY.
           PERFORM CONFIRM-RUN.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       GET-TODAY SECTION.
       GTOD-010.
           MOVE "TODY"             TO KD-FUNC.
           MOVE 0                  TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE  WK-SYSYMD.
       GTOD-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-RUN SECTION.
       CONF-010.
           DISPLAY " ".
           DISPLAY " Reorganise CUSTF and PRODF into fresh".
           DISPLAY " compact copies (data/CUSTF.RGN, PRODF.RGN),".
           DISPLAY " dropping logically-deleted rows.".
           DISPLAY " Proceed ? (Y/N) : " WITH NO ADVANCING.
           MOVE SPACE              TO WK-CONFIRM.
           ACCEPT WK-CONFIRM FROM CONSOLE.
           IF NOT CONFIRM-YES
               DISPLAY " ** cancelled by operator."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       CONF-999.
           EXIT.
      *----------------------------------------------------------------
      *  REORG-CUST : copy live customers to the reorg file            *
      *----------------------------------------------------------------
       REORG-CUST SECTION.
       RCU-010.
           DISPLAY " ".
           DISPLAY " Reorganising CUSTF ...".
           OPEN INPUT  CUSTF.
           IF FSTS NOT = "00"
               MOVE "CUSTF"        TO KA-FILE
               MOVE "Open CUSTF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN OUTPUT CUSTN.
           IF FSTS NOT = "00"
               MOVE "CUSTN"        TO KA-FILE
               MOVE "Open reorg CUSTF.RGN failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           MOVE 0                  TO EOF-FLG.
           MOVE 0                  TO CU-CODE.
           START CUSTF KEY NOT LESS THAN CU-CODE
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM RCU-NEXT UNTIL EOF-YES.
           CLOSE CUSTF.
           CLOSE CUSTN.
       RCU-999.
           EXIT.
       RCU-NEXT SECTION.
       RCUX-010.
           READ CUSTF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO RCUX-999
           END-READ.
           IF FSTS NOT = "00" AND FSTS NOT = "02"
               MOVE "CUSTF"        TO KA-FILE
               MOVE "READ NEXT CUSTF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           ADD 1                   TO WK-CU-READ.
           IF CU-DEL-FLAG = 1
               ADD 1               TO WK-CU-SKIP
           ELSE
               MOVE CU-REC         TO NC-REC
               WRITE NC-REC
               IF FSTS = "00"
                   ADD 1           TO WK-CU-COPY
               ELSE
                   MOVE "CUSTN"    TO KA-FILE
                   MOVE "WRITE reorg CUSTF.RGN failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
               END-IF
           END-IF.
       RCUX-999.
           EXIT.
      *----------------------------------------------------------------
      *  REORG-PROD : copy live products to the reorg file             *
      *----------------------------------------------------------------
       REORG-PROD SECTION.
       RPR-010.
           DISPLAY " Reorganising PRODF ...".
           OPEN INPUT  PRODF.
           IF FSTS NOT = "00"
               MOVE "PRODF"        TO KA-FILE
               MOVE "Open PRODF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN OUTPUT PRODN.
           IF FSTS NOT = "00"
               MOVE "PRODN"        TO KA-FILE
               MOVE "Open reorg PRODF.RGN failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           MOVE 0                  TO EOF-FLG.
           MOVE 0                  TO PR-CODE.
           START PRODF KEY NOT LESS THAN PR-CODE
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM RPR-NEXT UNTIL EOF-YES.
           CLOSE PRODF.
           CLOSE PRODN.
       RPR-999.
           EXIT.
       RPR-NEXT SECTION.
       RPRX-010.
           READ PRODF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO RPRX-999
           END-READ.
           IF FSTS NOT = "00" AND FSTS NOT = "02"
               MOVE "PRODF"        TO KA-FILE
               MOVE "READ NEXT PRODF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           ADD 1                   TO WK-PR-READ.
           IF PR-DEL-FLAG = 1
               ADD 1               TO WK-PR-SKIP
           ELSE
               MOVE PR-REC         TO NP-REC
               WRITE NP-REC
               IF FSTS = "00"
                   ADD 1           TO WK-PR-COPY
               ELSE
                   MOVE "PRODN"    TO KA-FILE
                   MOVE "WRITE reorg PRODF.RGN failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
               END-IF
           END-IF.
       RPRX-999.
           EXIT.
      *----------------------------------------------------------------
      *  PRINT-SUMMARY                                                 *
      *----------------------------------------------------------------
       PRINT-SUMMARY SECTION.
       PSUM-010.
           DISPLAY " ".
           DISPLAY "----------------------------------------------".
           DISPLAY " REINDEX / REBUILD SUMMARY".
           DISPLAY "----------------------------------------------".
           MOVE WK-CU-READ         TO WK-E-CNT.
           DISPLAY " CUSTF read        : " WK-E-CNT.
           MOVE WK-CU-COPY         TO WK-E-CNT.
           DISPLAY " CUSTF copied      : " WK-E-CNT.
           MOVE WK-CU-SKIP         TO WK-E-CNT.
           DISPLAY " CUSTF skipped/del : " WK-E-CNT.
           MOVE WK-PR-READ         TO WK-E-CNT.
           DISPLAY " PRODF read        : " WK-E-CNT.
           MOVE WK-PR-COPY         TO WK-E-CNT.
           DISPLAY " PRODF copied      : " WK-E-CNT.
           MOVE WK-PR-SKIP         TO WK-E-CNT.
           DISPLAY " PRODF skipped/del : " WK-E-CNT.
           DISPLAY "----------------------------------------------".
           DISPLAY " Reorg files written to data/*.RGN".
           DISPLAY " BT0080 completed normally.".
       PSUM-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           DISPLAY " ".
           DISPLAY " BT0080 end.".
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABND-010.
           MOVE "BT0080"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EBATCH"           TO KA-MSGCODE.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABND-999.
           EXIT.
