       IDENTIFICATION DIVISION.
       PROGRAM-ID. OE0050.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : OE0050  -  Order acknowledgement / picking list  *
      *  FUNCTION : batch print of sales-order acknowledgements for  *
      *             an operator-supplied order-number range.  For    *
      *             every ORDHF whose number falls in the range the  *
      *             program prints a header block (order number,     *
      *             date, due date, customer code and name from      *
      *             CUSTF, sales rep, warehouse, PO reference and     *
      *             status) followed by its ORDDF lines showing the  *
      *             product code and name (PRODF), ordered quantity, *
      *             unit price, line amount and the outstanding       *
      *             quantity (ordered - shipped).  An order total     *
      *             and a run grand total are printed.  Output is a   *
      *             132-column line-sequential text file with page    *
      *             headers.  Console / batch (no SCREEN SECTION).    *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SORDH.
           COPY SORDD.
           COPY SCUST.
           COPY SPROD.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FORDH.
           COPY FORDD.
           COPY FCUST.
           COPY FPROD.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "OE0050.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- flags -----------------------------------------------------
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
           02  WK-DTL-EOF          PIC 9(1)  VALUE 0.
             88  DTL-EOF                     VALUE 1.
      *----- run parameters --------------------------------------------
       01  WK-PARM.
           02  WK-IN-FROM          PIC X(10) VALUE SPACE.
           02  WK-IN-TO            PIC X(10) VALUE SPACE.
           02  WK-ORD-FROM         PIC 9(10) VALUE 0.
           02  WK-ORD-TO           PIC 9(10) VALUE 9999999999.
      *----- work ------------------------------------------------------
       01  WK-WORK2.
           02  WK-CUST-NAME        PIC X(30) VALUE SPACE.
           02  WK-PROD-NAME        PIC X(26) VALUE SPACE.
           02  WK-STAT-TXT         PIC X(10) VALUE SPACE.
           02  WK-COMPANY          PIC X(40) VALUE SPACE.
           02  WK-OUTSTAND         PIC S9(9) VALUE 0.
      *----- counters --------------------------------------------------
       01  WK-COUNTS.
           02  WK-ORD-CNT          PIC 9(7)  VALUE 0.
           02  WK-LIN-CNT          PIC 9(7)  VALUE 0.
      *----- totals ----------------------------------------------------
       01  WK-TOTALS.
           02  WK-ORD-NET          PIC S9(13) COMP-3 VALUE 0.
           02  WK-G-NET            PIC S9(15) COMP-3 VALUE 0.
      *----- report line images ---------------------------------------
       01  RPT-RULE               PIC X(120) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(9)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RD-ORD1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(7)  VALUE "ORDER# ".
           02  O1-NO              PIC 9(10).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "DATE ".
           02  O1-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(5)  VALUE "DUE ".
           02  O1-DUE             PIC 9999/99/99.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(8)  VALUE "STATUS ".
           02  O1-STAT            PIC X(10).
       01  RD-ORD2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(7)  VALUE "CUST   ".
           02  O2-CUST            PIC 9(6).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  O2-CNAME           PIC X(30).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "REP ".
           02  O2-STAFF           PIC 9(4).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "WHSE ".
           02  O2-WHSE            PIC 9(3).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(4)  VALUE "PO ".
           02  O2-PO              PIC X(20).
       01  RD-COLH.
           02  FILLER             PIC X(6)  VALUE SPACE.
           02  FILLER             PIC X(5)  VALUE "LINE ".
           02  FILLER             PIC X(9)  VALUE "PRODUCT  ".
           02  FILLER             PIC X(27) VALUE "NAME".
           02  FILLER             PIC X(13) VALUE "       QTY".
           02  FILLER             PIC X(15) VALUE "       PRICE".
           02  FILLER             PIC X(17) VALUE "        AMOUNT".
           02  FILLER             PIC X(12) VALUE "     OUTST".
       01  RD-DTL.
           02  FILLER             PIC X(6)  VALUE SPACE.
           02  FILLER             PIC X(5)  VALUE SPACE.
           02  D-LINE             PIC 9(3).
           02  FILLER             PIC X(3)  VALUE SPACE.
           02  D-PROD             PIC 9(8).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  D-NAME             PIC X(26).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  D-QTY              PIC ----,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  D-PRICE            PIC ---,---,--9.99.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  D-AMT              PIC ----,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  D-OUT              PIC ----,---,--9.
       01  RD-OTOT.
           02  FILLER             PIC X(6)  VALUE SPACE.
           02  FILLER             PIC X(40) VALUE
               "ORDER TOTAL (NET)".
           02  OT-NET             PIC ----,---,---,--9.
       01  RD-GRAND.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(45) VALUE
               "GRAND TOTAL (NET)".
           02  GT-NET             PIC ----,---,---,--9.
           02  FILLER             PIC X(6)  VALUE "  ORD ".
           02  GT-ORD             PIC ZZZ,ZZ9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PARM-RTN.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "OE0050"           TO WK-PROGID.
           MOVE "ORDER ACKNOWLEDGEMENT / PICKING LIST" TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT ORDHF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "ORDHF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT ORDDF.
           OPEN INPUT CUSTF.
           OPEN INPUT PRODF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PARM-RTN SECTION.
       PARM-010.
           DISPLAY "OE0050 - Order acknowledgement / picking list".
           DISPLAY "From order number (blank = lowest) : ".
           ACCEPT  WK-IN-FROM FROM CONSOLE.
           DISPLAY "To   order number (blank = highest): ".
           ACCEPT  WK-IN-TO   FROM CONSOLE.
           IF WK-IN-FROM NUMERIC AND WK-IN-FROM NOT = SPACE
               MOVE WK-IN-FROM     TO WK-ORD-FROM
           ELSE
               MOVE 0              TO WK-ORD-FROM
           END-IF.
           IF WK-IN-TO NUMERIC AND WK-IN-TO NOT = SPACE
               MOVE WK-IN-TO       TO WK-ORD-TO
           ELSE
               MOVE 9999999999     TO WK-ORD-TO
           END-IF.
       PARM-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRT-010.
           MOVE 0                  TO WK-ORD-CNT WK-LIN-CNT.
           MOVE 99                 TO WK-LINE.
           IF NOT MAIN-EOF
               MOVE WK-ORD-FROM    TO OH-NO
               START ORDHF KEY IS NOT LESS THAN OH-NO
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-HDR UNTIL MAIN-EOF.
           PERFORM PRINT-GRAND.
       PRT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-HDR SECTION.
       RH-010.
           READ ORDHF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   IF OH-NO > WK-ORD-TO
                       MOVE 1      TO WK-MAIN-EOF
                   ELSE
                       PERFORM PROCESS-ORDER
                   END-IF
           END-READ.
       RH-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-ORDER SECTION.
       PO-010.
           IF OH-DEL-FLAG = 1
               GO TO PO-999
           END-IF.
           PERFORM CHECK-PAGE-HDR.
           PERFORM LOOKUP-CUST.
           PERFORM SET-STAT-TXT.
           MOVE 0                  TO WK-ORD-NET.
           MOVE OH-NO              TO O1-NO.
           MOVE OH-DATE            TO O1-DATE.
           MOVE OH-DUE-DATE        TO O1-DUE.
           MOVE WK-STAT-TXT        TO O1-STAT.
           MOVE RD-ORD1            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE OH-CUST            TO O2-CUST.
           MOVE WK-CUST-NAME       TO O2-CNAME.
           MOVE OH-STAFF           TO O2-STAFF.
           MOVE OH-WHSE            TO O2-WHSE.
           MOVE OH-CUST-PO         TO O2-PO.
           MOVE RD-ORD2            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE RD-COLH            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           ADD 1                   TO WK-ORD-CNT.
           PERFORM PRINT-DETAILS.
           PERFORM PRINT-ORDER-TOTAL.
           ADD WK-ORD-NET          TO WK-G-NET.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-DETAILS SECTION.
       PD-010.
           MOVE 0                  TO WK-DTL-EOF.
           MOVE OH-NO              TO OD-NO.
           MOVE 0                  TO OD-LINE.
           START ORDDF KEY IS NOT LESS THAN OD-NO
               INVALID KEY
                   MOVE 1          TO WK-DTL-EOF
           END-START.
           PERFORM READ-DTL UNTIL DTL-EOF.
       PD-999.
           EXIT.
      *----------------------------------------------------------------
       READ-DTL SECTION.
       RD-010.
           READ ORDDF NEXT
               AT END
                   MOVE 1          TO WK-DTL-EOF
               NOT AT END
                   IF OD-NO NOT = OH-NO
                       MOVE 1      TO WK-DTL-EOF
                   ELSE
                       PERFORM PRINT-ONE-DTL
                   END-IF
           END-READ.
       RD-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-ONE-DTL SECTION.
       POD-010.
           PERFORM CHECK-PAGE.
           PERFORM LOOKUP-PROD.
           COMPUTE WK-OUTSTAND = OD-QTY - OD-SHIPPED-QTY.
           MOVE OD-LINE           TO D-LINE.
           MOVE OD-PROD           TO D-PROD.
           MOVE WK-PROD-NAME      TO D-NAME.
           MOVE OD-QTY            TO D-QTY.
           MOVE OD-UNIT-PRICE     TO D-PRICE.
           MOVE OD-AMOUNT         TO D-AMT.
           MOVE WK-OUTSTAND       TO D-OUT.
           MOVE RD-DTL            TO REP-REC.
           WRITE REP-REC.
           ADD 1                  TO WK-LINE.
           ADD 1                  TO WK-LIN-CNT.
           ADD OD-AMOUNT          TO WK-ORD-NET.
       POD-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-ORDER-TOTAL SECTION.
       POT-010.
           PERFORM CHECK-PAGE.
           MOVE WK-ORD-NET        TO OT-NET.
           MOVE RD-OTOT           TO REP-REC.
           WRITE REP-REC.
           ADD 1                  TO WK-LINE.
           MOVE SPACE             TO REP-REC.
           WRITE REP-REC.
           ADD 1                  TO WK-LINE.
       POT-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-CUST SECTION.
       LKC-010.
           MOVE SPACE             TO WK-CUST-NAME.
           MOVE OH-CUST           TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "(unknown)" TO WK-CUST-NAME
               NOT INVALID KEY
                   MOVE CU-NAME     TO WK-CUST-NAME
           END-READ.
       LKC-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-PROD SECTION.
       LKP-010.
           MOVE SPACE             TO WK-PROD-NAME.
           MOVE OD-PROD           TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "(unknown)" TO WK-PROD-NAME
               NOT INVALID KEY
                   MOVE PR-NAME     TO WK-PROD-NAME
           END-READ.
       LKP-999.
           EXIT.
      *----------------------------------------------------------------
       SET-STAT-TXT SECTION.
       SST-010.
           EVALUATE OH-STATUS
               WHEN 0   MOVE "Entered"   TO WK-STAT-TXT
               WHEN 1   MOVE "Allocated" TO WK-STAT-TXT
               WHEN 2   MOVE "Part-ship" TO WK-STAT-TXT
               WHEN 3   MOVE "Shipped"   TO WK-STAT-TXT
               WHEN 4   MOVE "Invoiced"  TO WK-STAT-TXT
               WHEN 9   MOVE "Cancelled" TO WK-STAT-TXT
               WHEN OTHER MOVE "?"       TO WK-STAT-TXT
           END-EVALUATE.
       SST-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE-HDR SECTION.
       CPH-010.
           IF WK-LINE >= 50
               PERFORM PAGE-HEAD
           END-IF.
       CPH-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           STRING "ORDER RANGE " WK-ORD-FROM " - " WK-ORD-TO
               DELIMITED BY SIZE INTO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE 5                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-GRAND SECTION.
       PG-010.
           IF WK-ORD-CNT = 0
               PERFORM CHECK-PAGE-HDR
               MOVE "*** NO ORDERS IN THE SELECTED RANGE ***"
                                   TO REP-REC
               WRITE REP-REC
               GO TO PG-999
           END-IF.
           PERFORM CHECK-PAGE.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-G-NET           TO GT-NET.
           MOVE WK-ORD-CNT         TO GT-ORD.
           MOVE RD-GRAND           TO REP-REC.
           WRITE REP-REC.
       PG-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE ORDHF ORDDF CUSTF PRODF REPF.
           DISPLAY "OE0050 complete.  Orders = " WK-ORD-CNT
               "  Lines = " WK-LIN-CNT.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "OE0050"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
