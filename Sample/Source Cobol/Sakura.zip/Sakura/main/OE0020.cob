       IDENTIFICATION DIVISION.
       PROGRAM-ID. OE0020.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : OE0020  -  Sales order inquiry / list            *
      *  FUNCTION : read-only browse of the sales order file.  An    *
      *             order can be located directly by its order       *
      *             number, or the first order for a customer can be *
      *             found from the customer + date alternate key      *
      *             using START and READ NEXT.  For the selected      *
      *             order the header is displayed together with the  *
      *             customer name and every detail line (product,     *
      *             quantity, price, amount, shipped and allocated    *
      *             quantities).  PF5 / PF6 step to the previous or   *
      *             next order; ENTER / PF12 page the detail lines.   *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SORDH.
           COPY SORDD.
           COPY SCUST.
           COPY SPROD.
       DATA DIVISION.
       FILE SECTION.
           COPY FORDH.
           COPY FORDD.
           COPY FCUST.
           COPY FPROD.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
      *----- inquiry control ------------------------------------------
       01  WK-SRCH.
           02  WK-SEL-NO           PIC 9(10) VALUE 0.
           02  WK-SEL-CUST         PIC 9(6)  VALUE 0.
           02  WK-SEL-DATE         PIC 9(8)  VALUE 0.
           02  WK-MODE             PIC 9(1)  VALUE 0.
             88  MODE-BY-NO                  VALUE 1.
             88  MODE-BY-CUST                VALUE 2.
           02  WK-CUR-NO           PIC 9(10) VALUE 0.
           02  WK-PGSIZE           PIC 9(3)  VALUE 13.
           02  WK-PAGE-TOP         PIC 9(3)  VALUE 1.
           02  WK-BROWSE-END       PIC 9(1)  VALUE 0.
             88  BROWSE-END-YES              VALUE 1.
           02  WK-DUMMY            PIC X(1)  VALUE SPACE.
      *----- header display work --------------------------------------
       01  WK-HDR-DISP.
           02  WK-CUST-NAME        PIC X(40) VALUE SPACE.
           02  WK-PROD-NAME        PIC X(40) VALUE SPACE.
           02  WK-STAT-TEXT        PIC X(12) VALUE SPACE.
           02  WK-PAGE-NO          PIC 9(3)  VALUE 0.
           02  WK-PAGE-CNT         PIC 9(3)  VALUE 0.
      *----- history stack (for previous-order navigation) ------------
       01  WK-HIST-AREA.
           02  WK-HCNT             PIC 9(3)  VALUE 0.
           02  WK-HPOS             PIC 9(3)  VALUE 0.
           02  WK-HIST OCCURS 100.
             03  WH-NO             PIC 9(10).
      *----- detail line buffer + display window ----------------------
       01  WK-DTL-TABLE.
           02  WK-DCNT             PIC 9(3)  VALUE 0.
           02  WK-DROW OCCURS 200.
             03  DR-LINE           PIC 9(3).
             03  DR-PROD           PIC 9(8).
             03  DR-NAME           PIC X(14).
             03  DR-QTY            PIC S9(9).
             03  DR-PRICE          PIC S9(9)V9(2).
             03  DR-AMT            PIC S9(11).
             03  DR-SHIP           PIC S9(9).
             03  DR-ALLOC          PIC S9(9).
       01  WK-WIN.
           02  WW-ROW OCCURS 13.
             03  WW-LINE           PIC ZZ9.
             03  WW-PROD           PIC 9(8).
             03  WW-NAME           PIC X(14).
             03  WW-QTY            PIC ---,--9.
             03  WW-PRICE          PIC ---,--9.99.
             03  WW-AMT            PIC ----,---,--9.
             03  WW-SHIP           PIC ---,--9.
             03  WW-ALLOC          PIC ---,--9.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4.
             03  COLUMN 2  VALUE "Order No   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(10) USING WK-SEL-NO.
           02  LINE 5 COLUMN 6 VALUE "- or -" COLOR CYAN.
           02  LINE 6.
             03  COLUMN 2  VALUE "Customer   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(6) USING WK-SEL-CUST.
             03  COLUMN 24 PIC X(40) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 7.
             03  COLUMN 2  VALUE "From Date  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING WK-SEL-DATE.
       01  DS-ORDER.
           02  LINE 3.
             03  COLUMN 2  VALUE "Order#:" COLOR YELLOW.
             03  COLUMN 10 PIC ZZZZZZZZZ9 FROM OH-NO COLOR WHITE.
             03  COLUMN 24 VALUE "Date:" COLOR YELLOW.
             03  COLUMN 30 PIC 9(8) FROM OH-DATE COLOR WHITE.
             03  COLUMN 42 VALUE "Status:" COLOR YELLOW.
             03  COLUMN 50 PIC X(12) FROM WK-STAT-TEXT COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "Cust  :" COLOR YELLOW.
             03  COLUMN 10 PIC 9(6) FROM OH-CUST COLOR WHITE.
             03  COLUMN 18 PIC X(34) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Staff :" COLOR YELLOW.
             03  COLUMN 10 PIC 9(4) FROM OH-STAFF COLOR WHITE.
             03  COLUMN 18 VALUE "Whse:" COLOR YELLOW.
             03  COLUMN 24 PIC 9(3) FROM OH-WHSE COLOR WHITE.
             03  COLUMN 30 VALUE "Due:" COLOR YELLOW.
             03  COLUMN 35 PIC 9(8) FROM OH-DUE-DATE COLOR WHITE.
             03  COLUMN 48 VALUE "PO:" COLOR YELLOW.
             03  COLUMN 52 PIC X(20) FROM OH-CUST-PO COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE "Net :" COLOR YELLOW.
             03  COLUMN 8  PIC ---,---,---,--9 FROM OH-AMOUNT.
             03  COLUMN 24 VALUE "Tax :" COLOR YELLOW.
             03  COLUMN 30 PIC ---,---,--9 FROM OH-TAX-AMOUNT.
             03  COLUMN 44 VALUE "Total :" COLOR YELLOW.
             03  COLUMN 52 PIC ---,---,---,--9 FROM OH-TOTAL.
           02  LINE 7.
             03  COLUMN 2  VALUE
                 "Ln Product   Name             Qty     Price"
                              COLOR CYAN.
             03  COLUMN 49 VALUE "Amount     Shp    Alc" COLOR CYAN.
           02  LINE 8.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (1).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (1).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (1).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (1).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (1).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (1).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (1).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (1).
           02  LINE 9.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (2).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (2).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (2).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (2).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (2).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (2).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (2).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (2).
           02  LINE 10.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (3).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (3).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (3).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (3).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (3).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (3).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (3).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (3).
           02  LINE 11.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (4).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (4).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (4).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (4).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (4).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (4).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (4).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (4).
           02  LINE 12.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (5).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (5).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (5).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (5).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (5).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (5).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (5).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (5).
           02  LINE 13.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (6).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (6).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (6).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (6).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (6).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (6).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (6).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (6).
           02  LINE 14.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (7).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (7).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (7).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (7).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (7).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (7).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (7).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (7).
           02  LINE 15.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (8).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (8).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (8).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (8).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (8).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (8).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (8).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (8).
           02  LINE 16.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (9).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (9).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (9).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (9).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (9).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (9).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (9).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (9).
           02  LINE 17.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (10).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (10).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (10).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (10).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (10).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (10).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (10).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (10).
           02  LINE 18.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (11).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (11).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (11).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (11).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (11).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (11).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (11).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (11).
           02  LINE 19.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (12).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (12).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (12).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (12).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (12).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (12).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (12).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (12).
           02  LINE 20.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (13).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (13).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (13).
             03  COLUMN 30 PIC ---,--9 FROM WW-QTY (13).
             03  COLUMN 38 PIC ---,--9.99 FROM WW-PRICE (13).
             03  COLUMN 49 PIC ----,---,--9 FROM WW-AMT (13).
             03  COLUMN 62 PIC ---,--9 FROM WW-SHIP (13).
             03  COLUMN 70 PIC ---,--9 FROM WW-ALLOC (13).
       01  DS-STATUS.
           02  LINE 21.
             03  COLUMN 2  VALUE "Lines:" COLOR YELLOW.
             03  COLUMN 9  PIC ZZ9 FROM WK-DCNT COLOR WHITE.
             03  COLUMN 16 VALUE "Page:" COLOR YELLOW.
             03  COLUMN 22 PIC ZZ9 FROM WK-PAGE-NO COLOR WHITE.
             03  COLUMN 26 VALUE "/" COLOR WHITE.
             03  COLUMN 27 PIC ZZ9 FROM WK-PAGE-CNT COLOR WHITE.
       01  DS-BROWSE.
           02  LINE 21 COLUMN 40 VALUE "PFkey:" COLOR CYAN.
           02  LINE 21 COLUMN 47 PIC X(1) USING WK-DUMMY.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "OE0020"           TO WK-PROGID.
           MOVE "Sales Order Inquiry"               TO WK-TITLE.
           MOVE "ENTER=NextPage PF12=PrevPage PF5/6=Prev/Next PF3=End"
                                   TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           OPEN INPUT ORDHF.
           IF FSTS NOT = "00"
               MOVE "ORDHF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT ORDDF.
           IF FSTS NOT = "00"
               MOVE "ORDDF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT CUSTF.
           IF FSTS NOT = "00"
               MOVE "CUSTF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT PRODF.
           IF FSTS NOT = "00"
               MOVE "PRODF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAINR-010.
           PERFORM CLEAR-SEARCH.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter order number or customer, then ENTER"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-KEY
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAINR-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-SEARCH SECTION.
       CLRS-010.
           MOVE 0                  TO WK-SEL-NO WK-SEL-CUST WK-SEL-DATE.
           MOVE 0                  TO WK-MODE WK-CUR-NO.
           MOVE 0                  TO WK-HCNT WK-HPOS.
           MOVE SPACE              TO WK-CUST-NAME.
       CLRS-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-KEY SECTION.
       PKEY-010.
           IF WK-SEL-NO NOT = 0
               PERFORM FIND-BY-NUMBER
           ELSE
               IF WK-SEL-CUST NOT = 0
                   PERFORM FIND-BY-CUSTOMER
               ELSE
                   MOVE "Enter an order number or a customer code"
                                   TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PKEY-999
               END-IF
           END-IF.
           IF FOUND-YES
               PERFORM INIT-HISTORY
               PERFORM SHOW-ORDER
               PERFORM BROWSE-LOOP
           END-IF.
       PKEY-999.
           EXIT.
      *----------------------------------------------------------------
       FIND-BY-NUMBER SECTION.
       FBN-010.
           MOVE 0                  TO FOUND-FLG.
           SET MODE-BY-NO TO TRUE.
           MOVE WK-SEL-NO          TO OH-NO.
           READ ORDHF
               INVALID KEY
                   MOVE "Order number not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO FBN-999
           END-READ.
           IF OH-DEL-FLAG = 1
               MOVE "Order is cancelled / deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO FBN-999
           END-IF.
           SET FOUND-YES TO TRUE.
       FBN-999.
           EXIT.
      *----------------------------------------------------------------
       FIND-BY-CUSTOMER SECTION.
       FBC-010.
           MOVE 0                  TO FOUND-FLG.
           SET MODE-BY-CUST TO TRUE.
           MOVE WK-SEL-CUST        TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "Customer not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO FBC-999
           END-READ.
           MOVE CU-NAME            TO WK-CUST-NAME.
           MOVE WK-SEL-CUST        TO OH-CUST.
           MOVE WK-SEL-DATE        TO OH-DATE.
           START ORDHF KEY IS NOT LESS THAN OH-CUST
               INVALID KEY
                   MOVE "No orders for this customer" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO FBC-999
           END-START.
           PERFORM READ-NEXT-LIVE.
           IF EOF-YES OR OH-CUST NOT = WK-SEL-CUST
               MOVE "No orders for this customer" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO FBC-999
           END-IF.
           SET FOUND-YES TO TRUE.
       FBC-999.
           EXIT.
      *----------------------------------------------------------------
       READ-NEXT-LIVE SECTION.
      *    read forward skipping logically deleted orders
       RNL-010.
           MOVE 0                  TO EOF-FLG FOUND-FLG.
           PERFORM UNTIL FOUND-YES OR EOF-YES
               READ ORDHF NEXT
                   AT END
                       SET EOF-YES TO TRUE
                   NOT AT END
                       IF OH-DEL-FLAG = 0
                           SET FOUND-YES TO TRUE
                       END-IF
               END-READ
           END-PERFORM.
       RNL-999.
           EXIT.
      *----------------------------------------------------------------
       SHOW-ORDER SECTION.
       SHOW-010.
           MOVE OH-NO              TO WK-CUR-NO.
           PERFORM LOOKUP-CUSTOMER.
           PERFORM SET-STATUS-TEXT.
           PERFORM LOAD-DETAILS.
           MOVE 1                  TO WK-PAGE-TOP.
           PERFORM CALC-PAGES.
           PERFORM BUILD-WINDOW.
           PERFORM PAINT-ORDER.
       SHOW-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-CUSTOMER SECTION.
       LKC-010.
           MOVE SPACE              TO WK-CUST-NAME.
           MOVE OH-CUST            TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "??? unknown customer" TO WK-CUST-NAME
               NOT INVALID KEY
                   MOVE CU-NAME    TO WK-CUST-NAME
           END-READ.
       LKC-999.
           EXIT.
      *----------------------------------------------------------------
       SET-STATUS-TEXT SECTION.
       SST-010.
           EVALUATE OH-STATUS
               WHEN 0
                   MOVE "Entered"     TO WK-STAT-TEXT
               WHEN 1
                   MOVE "Allocated"   TO WK-STAT-TEXT
               WHEN 2
                   MOVE "Part-ship"   TO WK-STAT-TEXT
               WHEN 3
                   MOVE "Shipped"     TO WK-STAT-TEXT
               WHEN 4
                   MOVE "Invoiced"    TO WK-STAT-TEXT
               WHEN 9
                   MOVE "Cancelled"   TO WK-STAT-TEXT
               WHEN OTHER
                   MOVE "Unknown"     TO WK-STAT-TEXT
           END-EVALUATE.
       SST-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-DETAILS SECTION.
      *    read every ORDDF line belonging to the current order
       LDD-010.
           MOVE 0                  TO WK-DCNT.
           MOVE WK-CUR-NO          TO OD-NO.
           MOVE 0                  TO OD-LINE.
           START ORDDF KEY IS NOT LESS THAN OD-NO
               INVALID KEY
                   GO TO LDD-999
           END-START.
       LDD-020.
           READ ORDDF NEXT
               AT END
                   GO TO LDD-999
           END-READ.
           IF OD-NO NOT = WK-CUR-NO
               GO TO LDD-999
           END-IF.
           IF WK-DCNT >= 200
               GO TO LDD-999
           END-IF.
           ADD 1                   TO WK-DCNT.
           MOVE OD-LINE            TO DR-LINE  (WK-DCNT).
           MOVE OD-PROD            TO DR-PROD  (WK-DCNT).
           PERFORM LOOKUP-PRODUCT.
           MOVE WK-PROD-NAME       TO DR-NAME  (WK-DCNT).
           MOVE OD-QTY             TO DR-QTY   (WK-DCNT).
           MOVE OD-UNIT-PRICE      TO DR-PRICE (WK-DCNT).
           MOVE OD-AMOUNT          TO DR-AMT   (WK-DCNT).
           MOVE OD-SHIPPED-QTY     TO DR-SHIP  (WK-DCNT).
           MOVE OD-ALLOC-QTY       TO DR-ALLOC (WK-DCNT).
           GO TO LDD-020.
       LDD-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-PRODUCT SECTION.
      *    resolve the product name for the current ORDDF line
       LKP-010.
           MOVE SPACE              TO WK-PROD-NAME.
           MOVE OD-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "??"       TO WK-PROD-NAME
               NOT INVALID KEY
                   MOVE PR-NAME    TO WK-PROD-NAME
           END-READ.
       LKP-999.
           EXIT.
      *----------------------------------------------------------------
       CALC-PAGES SECTION.
       CLP-010.
           IF WK-DCNT = 0
               MOVE 1              TO WK-PAGE-CNT
           ELSE
               COMPUTE WK-PAGE-CNT =
                   (WK-DCNT + WK-PGSIZE - 1) / WK-PGSIZE
           END-IF.
       CLP-999.
           EXIT.
      *----------------------------------------------------------------
       BUILD-WINDOW SECTION.
      *    copy the visible page of detail rows into the display window
       BW-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1
                   UNTIL WK-IDX > WK-PGSIZE
               COMPUTE WK-IDX2 = WK-PAGE-TOP + WK-IDX - 1
               IF WK-IDX2 <= WK-DCNT AND WK-IDX2 >= 1
                   MOVE DR-LINE  (WK-IDX2) TO WW-LINE  (WK-IDX)
                   MOVE DR-PROD  (WK-IDX2) TO WW-PROD  (WK-IDX)
                   MOVE DR-NAME  (WK-IDX2) TO WW-NAME  (WK-IDX)
                   MOVE DR-QTY   (WK-IDX2) TO WW-QTY   (WK-IDX)
                   MOVE DR-PRICE (WK-IDX2) TO WW-PRICE (WK-IDX)
                   MOVE DR-AMT   (WK-IDX2) TO WW-AMT   (WK-IDX)
                   MOVE DR-SHIP  (WK-IDX2) TO WW-SHIP  (WK-IDX)
                   MOVE DR-ALLOC (WK-IDX2) TO WW-ALLOC (WK-IDX)
               ELSE
                   MOVE ZERO       TO WW-LINE  (WK-IDX)
                   MOVE ZERO       TO WW-PROD  (WK-IDX)
                   MOVE SPACE      TO WW-NAME  (WK-IDX)
                   MOVE ZERO       TO WW-QTY   (WK-IDX)
                   MOVE ZERO       TO WW-PRICE (WK-IDX)
                   MOVE ZERO       TO WW-AMT   (WK-IDX)
                   MOVE ZERO       TO WW-SHIP  (WK-IDX)
                   MOVE ZERO       TO WW-ALLOC (WK-IDX)
               END-IF
           END-PERFORM.
           COMPUTE WK-PAGE-NO =
               (WK-PAGE-TOP + WK-PGSIZE - 1) / WK-PGSIZE.
       BW-999.
           EXIT.
      *----------------------------------------------------------------
       PAINT-ORDER SECTION.
       PO-010.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           DISPLAY DS-ORDER.
           DISPLAY DS-STATUS.
           MOVE SPACE              TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       BROWSE-LOOP SECTION.
       BL-010.
           MOVE 0                  TO WK-BROWSE-END.
           PERFORM UNTIL BROWSE-END-YES
               DISPLAY DS-BROWSE
               ACCEPT  DS-BROWSE
               EVALUATE ESTS
                   WHEN "03"
                       SET BROWSE-END-YES TO TRUE
                   WHEN "06"
                       PERFORM NEXT-ORDER
                   WHEN "05"
                       PERFORM PREV-ORDER
                   WHEN "00"
                       PERFORM PAGE-DOWN
                   WHEN "12"
                       PERFORM PAGE-UP
                   WHEN OTHER
                       MOVE "PF5/6 order  ENTER/PF12 page  PF3 back"
                                   TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-EVALUATE
           END-PERFORM.
       BL-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-DOWN SECTION.
       PD-010.
           IF WK-PAGE-TOP + WK-PGSIZE > WK-DCNT
               MOVE "Already at last page - PF6 for next order"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PD-999
           END-IF.
           ADD WK-PGSIZE           TO WK-PAGE-TOP.
           PERFORM BUILD-WINDOW.
           PERFORM PAINT-ORDER.
       PD-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-UP SECTION.
       PU-010.
           IF WK-PAGE-TOP <= 1
               MOVE "Already at first page" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PU-999
           END-IF.
           IF WK-PAGE-TOP > WK-PGSIZE
               SUBTRACT WK-PGSIZE  FROM WK-PAGE-TOP
           ELSE
               MOVE 1              TO WK-PAGE-TOP
           END-IF.
           PERFORM BUILD-WINDOW.
           PERFORM PAINT-ORDER.
       PU-999.
           EXIT.
      *----------------------------------------------------------------
       INIT-HISTORY SECTION.
       INHI-010.
           MOVE 1                  TO WK-HCNT WK-HPOS.
           MOVE OH-NO              TO WH-NO (1).
       INHI-999.
           EXIT.
      *----------------------------------------------------------------
       PUSH-HISTORY SECTION.
      *    record the newly shown order so PF5 can return to it
       PH-010.
           IF WK-HPOS < 100
               ADD 1               TO WK-HPOS
               MOVE WK-HPOS        TO WK-HCNT
               MOVE OH-NO          TO WH-NO (WK-HPOS)
           END-IF.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       NEXT-ORDER SECTION.
      *    reposition on the current key, then read forward to the
      *    next live order and display it
       NO-010.
           MOVE WK-CUR-NO          TO OH-NO.
           READ ORDHF
               INVALID KEY
                   MOVE "Cannot reposition on current order"
                                   TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO NO-999
           END-READ.
           PERFORM READ-NEXT-LIVE.
           IF EOF-YES
               MOVE "No further orders" TO WK-MSG-LINE
               MOVE WK-CUR-NO      TO OH-NO
               READ ORDHF
                   INVALID KEY
                       CONTINUE
               END-READ
               DISPLAY DS-MSG
               GO TO NO-999
           END-IF.
           PERFORM SHOW-ORDER.
           PERFORM PUSH-HISTORY.
       NO-999.
           EXIT.
      *----------------------------------------------------------------
       PREV-ORDER SECTION.
      *    step back through the visited-order history stack
       PRO-010.
           IF WK-HPOS <= 1
               MOVE "No previous order in this browse"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PRO-999
           END-IF.
           SUBTRACT 1              FROM WK-HPOS.
           MOVE WH-NO (WK-HPOS)    TO OH-NO.
           READ ORDHF
               INVALID KEY
                   MOVE "Previous order no longer available"
                                   TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PRO-999
           END-READ.
           PERFORM SHOW-ORDER.
       PRO-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE ORDHF ORDDF CUSTF PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "OE0020"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
