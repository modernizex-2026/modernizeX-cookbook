       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0070.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0070  -  Accounts-receivable aging             *
      *  FUNCTION : read AR ledger (ARLF) in customer order and age  *
      *             each movement (debit - credit) into buckets      *
      *             0-30 / 31-60 / 61-90 / over-90 days by comparing *
      *             AL-DATE with today (DATEUT DIFF).  Per-customer   *
      *             balance and bucket totals plus grand totals.     *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SARL.
           COPY SCUST.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FARL.
           COPY FCUST.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0070.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
           02  WK-FIRST            PIC 9(1)  VALUE 1.
       01  WK-AGE                  PIC S9(7) VALUE 0.
       01  WK-NET                  PIC S9(13) COMP-3 VALUE 0.
       01  WK-CUST-NAME            PIC X(22) VALUE SPACE.
       01  WK-CUR.
           02  WK-CUR-CUST         PIC 9(6)  VALUE 0.
           02  WK-CUR-B0           PIC S9(15) COMP-3 VALUE 0.
           02  WK-CUR-B1           PIC S9(15) COMP-3 VALUE 0.
           02  WK-CUR-B2           PIC S9(15) COMP-3 VALUE 0.
           02  WK-CUR-B3           PIC S9(15) COMP-3 VALUE 0.
           02  WK-CUR-CNT          PIC 9(7)  VALUE 0.
       01  WK-CUR-BAL             PIC S9(15) COMP-3 VALUE 0.
       01  WK-TOTALS.
           02  WK-G-B0             PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-B1             PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-B2             PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-B3             PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-BAL            PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-CNT            PIC 9(7)  VALUE 0.
       01  WK-COMPANY              PIC X(40) VALUE SPACE.
       01  RPT-RULE               PIC X(120) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "AS OF    : ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RH-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "CUST".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(22) VALUE "CUSTOMER NAME".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "         0 - 30".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "        31 - 60".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "        61 - 90".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "        OVER 90".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "        BALANCE".
       01  RD-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RA-CODE            PIC 9(6).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RA-NAME            PIC X(22).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RA-B0              PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RA-B1              PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RA-B2              PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RA-B3              PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RA-TOT             PIC ---,---,---,--9.
       01  RT-LINE.
           02  FILLER             PIC X(31) VALUE " GRAND TOTAL".
           02  RT-B0              PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RT-B1              PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RT-B2              PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RT-B3              PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RT-TOT             PIC ---,---,---,--9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0070"           TO WK-PROGID.
           MOVE "ACCOUNTS RECEIVABLE AGING"     TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT ARLF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "ARLF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT CUSTF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRINT-010.
           MOVE 0                  TO WK-G-CNT.
           MOVE 99                 TO WK-LINE.
           IF NOT MAIN-EOF
               MOVE 0              TO AL-CUST
               MOVE 0              TO AL-DATE
               START ARLF KEY NOT < AL-CUST
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-NEXT UNTIL MAIN-EOF.
           IF WK-FIRST = 0
               PERFORM FLUSH-CUST
           END-IF.
           PERFORM PRINT-GRAND.
       PRINT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-NEXT SECTION.
       RN-010.
           READ ARLF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   PERFORM PROCESS-ONE
           END-READ.
       RN-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-ONE SECTION.
       PO-010.
           IF WK-FIRST = 1
               MOVE AL-CUST        TO WK-CUR-CUST
               PERFORM RESET-ACCUM
               MOVE 0              TO WK-FIRST
           ELSE
               IF AL-CUST NOT = WK-CUR-CUST
                   PERFORM FLUSH-CUST
                   MOVE AL-CUST    TO WK-CUR-CUST
                   PERFORM RESET-ACCUM
               END-IF
           END-IF.
           PERFORM AGE-ONE.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       AGE-ONE SECTION.
       AG-010.
           MOVE "DIFF"             TO KD-FUNC.
           MOVE AL-DATE            TO KD-DATE1.
           MOVE WK-SYSDATE         TO KD-DATE2.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DAYS            TO WK-AGE.
           COMPUTE WK-NET = AL-DEBIT - AL-CREDIT.
           EVALUATE TRUE
               WHEN WK-AGE <= 30
                   ADD WK-NET      TO WK-CUR-B0
               WHEN WK-AGE <= 60
                   ADD WK-NET      TO WK-CUR-B1
               WHEN WK-AGE <= 90
                   ADD WK-NET      TO WK-CUR-B2
               WHEN OTHER
                   ADD WK-NET      TO WK-CUR-B3
           END-EVALUATE.
           ADD 1                   TO WK-CUR-CNT.
       AG-999.
           EXIT.
      *----------------------------------------------------------------
       RESET-ACCUM SECTION.
       RA-010.
           MOVE 0                  TO WK-CUR-B0 WK-CUR-B1.
           MOVE 0                  TO WK-CUR-B2 WK-CUR-B3.
           MOVE 0                  TO WK-CUR-CNT.
       RA-999.
           EXIT.
      *----------------------------------------------------------------
       FLUSH-CUST SECTION.
       FC-010.
           IF WK-CUR-CNT = 0
               GO TO FC-999
           END-IF.
           COMPUTE WK-CUR-BAL =
               WK-CUR-B0 + WK-CUR-B1 + WK-CUR-B2 + WK-CUR-B3.
           IF WK-CUR-BAL = 0
               GO TO FC-999
           END-IF.
           PERFORM CHECK-PAGE.
           MOVE SPACE              TO WK-CUST-NAME.
           MOVE WK-CUR-CUST        TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "(unknown)" TO WK-CUST-NAME
               NOT INVALID KEY
                   MOVE CU-NAME     TO WK-CUST-NAME
           END-READ.
           MOVE WK-CUR-CUST        TO RA-CODE.
           MOVE WK-CUST-NAME       TO RA-NAME.
           MOVE WK-CUR-B0          TO RA-B0.
           MOVE WK-CUR-B1          TO RA-B1.
           MOVE WK-CUR-B2          TO RA-B2.
           MOVE WK-CUR-B3          TO RA-B3.
           MOVE WK-CUR-BAL         TO RA-TOT.
           MOVE RD-LINE            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           ADD WK-CUR-B0           TO WK-G-B0.
           ADD WK-CUR-B1           TO WK-G-B1.
           ADD WK-CUR-B2           TO WK-G-B2.
           ADD WK-CUR-B3           TO WK-G-B3.
           ADD WK-CUR-BAL          TO WK-G-BAL.
           ADD 1                   TO WK-G-CNT.
       FC-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE RH-LINE            TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE 6                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-GRAND SECTION.
       PG-010.
           IF WK-G-CNT = 0
               PERFORM CHECK-PAGE
               MOVE "*** NO OUTSTANDING RECEIVABLES ***" TO REP-REC
               WRITE REP-REC
               GO TO PG-999
           END-IF.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-G-B0            TO RT-B0.
           MOVE WK-G-B1            TO RT-B1.
           MOVE WK-G-B2            TO RT-B2.
           MOVE WK-G-B3            TO RT-B3.
           MOVE WK-G-BAL           TO RT-TOT.
           MOVE RT-LINE            TO REP-REC.
           WRITE REP-REC.
       PG-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE ARLF CUSTF REPF.
           DISPLAY "RP0070 complete.  Customers aged = " WK-G-CNT.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0070"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
