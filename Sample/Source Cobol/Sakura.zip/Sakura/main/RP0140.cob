       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0140.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0140  -  Dead / slow-moving stock report       *
      *  FUNCTION : read stock balances in warehouse order (alt key  *
      *             SK-WHSE + SK-PROD) and for every row that still  *
      *             holds on-hand quantity compute the days since    *
      *             the last issue (SK-LAST-OUT-DATE vs today via     *
      *             DATEUT DIFF).  Items with no movement in more    *
      *             than 90 days are flagged SLOW and more than 180  *
      *             days DEAD.  Shows product name, on-hand, average *
      *             cost, stock value, last-out date and days idle.  *
      *             Warehouse control-break subtotals plus a grand   *
      *             total of idle value.  132-column batch text.     *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SSTOK.
           COPY SPROD.
           COPY SWHSE.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FSTOK.
           COPY FPROD.
           COPY FWHSE.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0140.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- control flags ---------------------------------------------
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
           02  WK-FIRST            PIC 9(1)  VALUE 1.
      *----- item work -------------------------------------------------
       01  WK-DAYS               PIC S9(7) VALUE 0.
       01  WK-VALUE              PIC S9(15) COMP-3 VALUE 0.
       01  WK-FLAG-TXT           PIC X(4)  VALUE SPACE.
       01  WK-PROD-NAME          PIC X(22) VALUE SPACE.
       01  WK-WH-NAME            PIC X(30) VALUE SPACE.
       01  WK-CUR-WHSE           PIC 9(3)  VALUE 0.
       01  WK-COMPANY            PIC X(40) VALUE SPACE.
      *----- per-warehouse accumulators --------------------------------
       01  WK-WH.
           02  WK-WH-ITEMS        PIC 9(7)  VALUE 0.
           02  WK-WH-IDLE-CNT     PIC 9(7)  VALUE 0.
           02  WK-WH-VALUE        PIC S9(15) COMP-3 VALUE 0.
           02  WK-WH-IDLE-VALUE   PIC S9(15) COMP-3 VALUE 0.
      *----- grand totals ----------------------------------------------
       01  WK-TOTALS.
           02  WK-G-ITEMS         PIC 9(7)  VALUE 0.
           02  WK-G-IDLE-CNT      PIC 9(7)  VALUE 0.
           02  WK-G-VALUE         PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-IDLE-VALUE    PIC S9(15) COMP-3 VALUE 0.
      *----- report layout ---------------------------------------------
       01  RPT-RULE               PIC X(110) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RD-WHSE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(11) VALUE "WAREHOUSE: ".
           02  WHH-CODE           PIC 9(3).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  WHH-NAME           PIC X(30).
       01  RC-HEAD.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(8)  VALUE "PRODUCT".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(22) VALUE "PRODUCT NAME".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(12) VALUE "     ON-HAND".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(14) VALUE "      AVG-COST".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(15) VALUE "    STOCK-VALUE".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(10) VALUE "  LAST-OUT".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(6)  VALUE "  DAYS".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(4)  VALUE "FLAG".
       01  RD-LINE.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-PROD    PIC 9(8).
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-NAME    PIC X(22).
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-ONHAND  PIC ----,---,--9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-AVGCOST PIC ---,---,--9.99.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-VALUE   PIC ---,---,---,--9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-LASTOUT PIC 9999/99/99.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-DAYS    PIC ZZZZZ9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-FLAG    PIC X(4).
       01  RD-SUB.
           02  FILLER    PIC X(20) VALUE "   WHSE SUBTOTAL   :".
           02  FILLER    PIC X(8)  VALUE " ITEMS=".
           02  ST-ITEMS  PIC ZZ,ZZ9.
           02  FILLER    PIC X(7)  VALUE " IDLE=".
           02  ST-IDLE   PIC ZZ,ZZ9.
           02  FILLER    PIC X(8)  VALUE " VALUE=".
           02  ST-VALUE  PIC ---,---,---,--9.
           02  FILLER    PIC X(11) VALUE " IDLE-VAL=".
           02  ST-IDLEVAL PIC ---,---,---,--9.
       01  RD-GRAND.
           02  FILLER    PIC X(20) VALUE " GRAND TOTAL       :".
           02  FILLER    PIC X(8)  VALUE " ITEMS=".
           02  GT-ITEMS  PIC ZZ,ZZ9.
           02  FILLER    PIC X(7)  VALUE " IDLE=".
           02  GT-IDLE   PIC ZZ,ZZ9.
           02  FILLER    PIC X(8)  VALUE " VALUE=".
           02  GT-VALUE  PIC ---,---,---,--9.
           02  FILLER    PIC X(11) VALUE " IDLE-VAL=".
           02  GT-IDLEVAL PIC ---,---,---,--9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0140"           TO WK-PROGID.
           MOVE "DEAD / SLOW-MOVING STOCK"      TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT STOKF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "STOKF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT PRODF.
           OPEN INPUT WHSEF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRINT-010.
           MOVE 99                 TO WK-LINE.
           MOVE 1                  TO WK-FIRST.
           IF NOT MAIN-EOF
               MOVE 0              TO SK-WHSE
               MOVE 0              TO SK-PROD
               START STOKF KEY NOT < SK-WHSE
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-STOK UNTIL MAIN-EOF.
           IF WK-FIRST = 0
               PERFORM FLUSH-WH
           END-IF.
           PERFORM PRINT-GRAND.
       PRINT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-STOK SECTION.
       RS-010.
           READ STOKF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   PERFORM PROCESS-ONE
           END-READ.
       RS-999.
           EXIT.
      *----------------------------------------------------------------
      *  PROCESS-ONE : handle one stock row (skip empty), control break
      *----------------------------------------------------------------
       PROCESS-ONE SECTION.
       PO-010.
           IF SK-ONHAND <= 0
               GO TO PO-999
           END-IF.
           IF WK-FIRST = 1
               MOVE SK-WHSE        TO WK-CUR-WHSE
               PERFORM RESET-WH
               PERFORM START-WHSE
               MOVE 0              TO WK-FIRST
           ELSE
               IF SK-WHSE NOT = WK-CUR-WHSE
                   PERFORM FLUSH-WH
                   MOVE SK-WHSE    TO WK-CUR-WHSE
                   PERFORM RESET-WH
                   PERFORM START-WHSE
               END-IF
           END-IF.
           PERFORM CALC-ITEM.
           PERFORM PRINT-ITEM.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       START-WHSE SECTION.
       SW-010.
           PERFORM LOOKUP-WHSE.
           PERFORM PAGE-ONLY.
           PERFORM PRINT-WH-HEAD.
       SW-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-WH-HEAD SECTION.
       PWH-010.
           MOVE WK-CUR-WHSE        TO WHH-CODE.
           MOVE WK-WH-NAME         TO WHH-NAME.
           MOVE RD-WHSE            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE RC-HEAD            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
       PWH-999.
           EXIT.
      *----------------------------------------------------------------
      *  CALC-ITEM : days idle, stock value and dead/slow flag
      *----------------------------------------------------------------
       CALC-ITEM SECTION.
       CI-010.
           IF SK-LAST-OUT-DATE = 0
               MOVE 99999          TO WK-DAYS
           ELSE
               MOVE "DIFF"         TO KD-FUNC
               MOVE SK-LAST-OUT-DATE TO KD-DATE1
               MOVE WK-SYSDATE     TO KD-DATE2
               CALL "DATEUT" USING KDATE
               IF KD-STATUS = "00"
                   MOVE KD-DAYS    TO WK-DAYS
               ELSE
                   MOVE 99999      TO WK-DAYS
               END-IF
           END-IF.
           IF WK-DAYS < 0
               MOVE 0              TO WK-DAYS
           END-IF.
           COMPUTE WK-VALUE ROUNDED = SK-ONHAND * SK-AVG-COST.
           EVALUATE TRUE
               WHEN WK-DAYS > 180
                   MOVE "DEAD"     TO WK-FLAG-TXT
               WHEN WK-DAYS > 90
                   MOVE "SLOW"     TO WK-FLAG-TXT
               WHEN OTHER
                   MOVE "OK"       TO WK-FLAG-TXT
           END-EVALUATE.
       CI-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-ITEM SECTION.
       PI-010.
           PERFORM CHECK-PAGE.
           PERFORM LOOKUP-PROD.
           MOVE SK-PROD            TO RL-PROD.
           MOVE WK-PROD-NAME       TO RL-NAME.
           MOVE SK-ONHAND          TO RL-ONHAND.
           MOVE SK-AVG-COST        TO RL-AVGCOST.
           MOVE WK-VALUE           TO RL-VALUE.
           MOVE SK-LAST-OUT-DATE   TO RL-LASTOUT.
           IF WK-DAYS > 99999
               MOVE 99999          TO RL-DAYS
           ELSE
               MOVE WK-DAYS        TO RL-DAYS
           END-IF.
           MOVE WK-FLAG-TXT        TO RL-FLAG.
           MOVE RD-LINE            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           ADD 1                   TO WK-WH-ITEMS.
           ADD 1                   TO WK-G-ITEMS.
           ADD WK-VALUE            TO WK-WH-VALUE.
           ADD WK-VALUE            TO WK-G-VALUE.
           IF WK-DAYS > 90
               ADD 1               TO WK-WH-IDLE-CNT
               ADD 1               TO WK-G-IDLE-CNT
               ADD WK-VALUE        TO WK-WH-IDLE-VALUE
               ADD WK-VALUE        TO WK-G-IDLE-VALUE
           END-IF.
       PI-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-PROD SECTION.
       LKP-010.
           MOVE SPACE              TO WK-PROD-NAME.
           MOVE SK-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "(unknown product)" TO WK-PROD-NAME
               NOT INVALID KEY
                   MOVE PR-NAME     TO WK-PROD-NAME
           END-READ.
       LKP-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-WHSE SECTION.
       LKW-010.
           MOVE SPACE              TO WK-WH-NAME.
           MOVE WK-CUR-WHSE        TO WH-CODE.
           READ WHSEF
               INVALID KEY
                   MOVE "(unknown warehouse)" TO WK-WH-NAME
               NOT INVALID KEY
                   MOVE WH-NAME     TO WK-WH-NAME
           END-READ.
       LKW-999.
           EXIT.
      *----------------------------------------------------------------
       RESET-WH SECTION.
       RW-010.
           MOVE 0                  TO WK-WH-ITEMS.
           MOVE 0                  TO WK-WH-IDLE-CNT.
           MOVE 0                  TO WK-WH-VALUE.
           MOVE 0                  TO WK-WH-IDLE-VALUE.
       RW-999.
           EXIT.
      *----------------------------------------------------------------
       FLUSH-WH SECTION.
       FW-010.
           PERFORM CHECK-PAGE.
           MOVE WK-WH-ITEMS        TO ST-ITEMS.
           MOVE WK-WH-IDLE-CNT     TO ST-IDLE.
           MOVE WK-WH-VALUE        TO ST-VALUE.
           MOVE WK-WH-IDLE-VALUE   TO ST-IDLEVAL.
           MOVE RD-SUB             TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
       FW-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
               IF WK-FIRST = 0
                   PERFORM PRINT-WH-HEAD
               END-IF
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-ONLY SECTION.
       POY-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       POY-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           MOVE "SLOW > 90 DAYS   DEAD > 180 DAYS" TO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE 4                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-GRAND SECTION.
       PG-010.
           IF WK-G-ITEMS = 0
               PERFORM PAGE-ONLY
               MOVE "*** NO STOCK ON HAND ***" TO REP-REC
               WRITE REP-REC
               GO TO PG-999
           END-IF.
           PERFORM CHECK-PAGE.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-G-ITEMS         TO GT-ITEMS.
           MOVE WK-G-IDLE-CNT      TO GT-IDLE.
           MOVE WK-G-VALUE         TO GT-VALUE.
           MOVE WK-G-IDLE-VALUE    TO GT-IDLEVAL.
           MOVE RD-GRAND           TO REP-REC.
           WRITE REP-REC.
       PG-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE STOKF PRODF WHSEF REPF.
           DISPLAY "RP0140 complete.  Stock rows reported = "
               WK-G-ITEMS.
           DISPLAY "         Idle (>90 days) items         = "
               WK-G-IDLE-CNT.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0140"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
