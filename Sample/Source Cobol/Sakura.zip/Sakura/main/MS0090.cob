       IDENTIFICATION DIVISION.
       PROGRAM-ID. MS0090.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : MS0090  -  Tax rate master maintenance           *
      *  FUNCTION : add / change / delete / inquire tax rates.  The  *
      *             key is composite (tax category code + effective  *
      *             start date).  The start date is validated with   *
      *             DATEUT VALD.  The rate is held as S9(2)V9(3),    *
      *             e.g. 0.100 for a ten percent rate.  Records have *
      *             no delete flag, so PF9 performs a physical       *
      *             delete of the effective-dated entry.             *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY STAX.
       I-O-CONTROL.
           APPLY SHARED-MODE ON TAXF.
       DATA DIVISION.
       FILE SECTION.
           COPY FTAX.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-SAVE-KEY.
           02  WK-SAVE-CODE      PIC 9(1)  VALUE 0.
           02  WK-SAVE-DATE      PIC 9(8)  VALUE 0.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4.
             03  COLUMN 2  VALUE "Tax Category  :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING TX-CODE.
             03  COLUMN 24 VALUE "1:standard 2:reduced 3:exempt"
                            COLOR CYAN.
           02  LINE 5.
             03  COLUMN 2  VALUE "Start Date    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(8)  USING TX-START-DATE.
             03  COLUMN 30 VALUE "YYYYMMDD" COLOR CYAN.
       01  DS-BODY.
           02  LINE 7.
             03  COLUMN 2  VALUE "Tax Rate      :" COLOR YELLOW.
             03  COLUMN 20 PIC S9(2)V9(3) USING TX-RATE.
             03  COLUMN 30 VALUE "e.g. 0.100 = 10 percent" COLOR CYAN.
           02  LINE 8.
             03  COLUMN 2  VALUE "Rate Name     :" COLOR YELLOW.
             03  COLUMN 20 PIC X(20) USING TX-NAME.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Confirm (Y/N) :" COLOR YELLOW.
           02  SC-CONF LINE 21 COLUMN 20 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "MS0090"           TO WK-PROGID.
           MOVE "Tax Rate Master Maintenance"  TO WK-TITLE.
           MOVE "ENTER=Read  PF9=Delete  PF3=End" TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           OPEN I-O    TAXF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT TAXF
               CLOSE TAXF
               OPEN I-O TAXF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "TAXF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-RTN-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE SPACE              TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-KEY
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-RTN-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLEAR-010.
           INITIALIZE TX-REC.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE 0                  TO WK-SAVE-CODE WK-SAVE-DATE.
       CLEAR-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-KEY SECTION.
       PKEY-010.
           IF TX-CODE = 0
               MOVE "Tax category must be 1 to 9" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
           IF TX-START-DATE = 0
               MOVE "Start date is required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
           MOVE "VALD"             TO KD-FUNC.
           MOVE TX-START-DATE      TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           IF KD-STATUS NOT = "00"
               MOVE "Start date is invalid" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
           MOVE TX-CODE            TO WK-SAVE-CODE.
           MOVE TX-START-DATE      TO WK-SAVE-DATE.
           READ TAXF
               INVALID KEY
                   PERFORM SETUP-ADD
               NOT INVALID KEY
                   PERFORM SETUP-CHANGE
           END-READ.
           PERFORM EDIT-RECORD.
       PKEY-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-ADD SECTION.
       SADD-010.
           SET MODE-ADD TO TRUE.
           INITIALIZE TX-REC.
           MOVE WK-SAVE-CODE       TO TX-CODE.
           MOVE WK-SAVE-DATE       TO TX-START-DATE.
           MOVE "New tax rate - enter details" TO WK-MSG-LINE.
       SADD-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-CHANGE SECTION.
       SCHG-010.
           SET MODE-CHG TO TRUE.
           MOVE "Existing tax rate - change or PF9 delete"
                                   TO WK-MSG-LINE.
       SCHG-999.
           EXIT.
      *----------------------------------------------------------------
       EDIT-RECORD SECTION.
       EDIT-010.
           DISPLAY DS-MSG.
           DISPLAY DS-BODY.
           ACCEPT  DS-BODY.
           EVALUATE ESTS
               WHEN "03"
                   CONTINUE
               WHEN "04"
                   MOVE "Cancelled" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               WHEN "09"
                   IF MODE-CHG
                       PERFORM DELETE-RECORD
                   ELSE
                       MOVE "Nothing to delete" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   END-IF
               WHEN "00"
                   PERFORM VALIDATE-BODY
                   IF NOT ERR-YES
                       PERFORM SAVE-RECORD
                   END-IF
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       EDIT-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-BODY SECTION.
       VAL-010.
           MOVE 0                  TO ERR-FLG.
           IF TX-RATE < 0
               MOVE "Rate cannot be negative" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF TX-RATE >= 1
               MOVE "Rate must be a fraction below 1.000" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF TX-NAME = SPACE
               MOVE "Rate name is required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
           END-IF.
       VAL-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       SAVE-RECORD SECTION.
       SAVE-010.
           IF MODE-ADD
               WRITE TX-REC
                   INVALID KEY
                       MOVE "Write failed - duplicate" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Tax rate added" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-WRITE
           ELSE
               REWRITE TX-REC
                   INVALID KEY
                       MOVE "Update failed" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Tax rate updated" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-REWRITE
           END-IF.
       SAVE-999.
           EXIT.
      *----------------------------------------------------------------
       DELETE-RECORD SECTION.
       DEL-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Press Y then ENTER to delete" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               DELETE TAXF
                   INVALID KEY
                       MOVE "Delete failed" TO WK-MSG-LINE
                   NOT INVALID KEY
                       MOVE "Tax rate deleted" TO WK-MSG-LINE
               END-DELETE
           ELSE
               MOVE "Delete cancelled" TO WK-MSG-LINE
           END-IF.
           DISPLAY DS-MSG.
       DEL-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE TAXF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "MS0090"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
