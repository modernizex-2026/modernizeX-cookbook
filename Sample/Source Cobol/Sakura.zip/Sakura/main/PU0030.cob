       IDENTIFICATION DIVISION.
       PROGRAM-ID. PU0030.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : PU0030  -  Purchase entry (booking a purchase)   *
      *  FUNCTION : turn a completed goods-receiving into a purchase *
      *             (accounts-payable) transaction.  The receiving   *
      *             is recalled by number; its lines become purchase *
      *             detail lines.  Tax is computed by TAXCAL from    *
      *             VH-TAX-TYPE.  A purchase header (PURHF, VH-KIND  *
      *             =1) and detail (PURDF) are written with the      *
      *             number from NUMGEN "PURCH".  An AP ledger entry  *
      *             (APLF, PL-KIND=1) is posted with PL-CREDIT equal *
      *             to the gross total and a running PL-BALANCE, and  *
      *             the supplier balance (SP-BALANCE) is increased.  *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SRCVH.
           COPY SRCVD.
           COPY SPURH.
           COPY SPURD.
           COPY SAPL.
           COPY SSUPP.
           COPY SPROD.
       I-O-CONTROL.
           APPLY SHARED-MODE ON RCVHF
           APPLY SHARED-MODE ON PURHF
           APPLY SHARED-MODE ON PURDF
           APPLY SHARED-MODE ON APLF
           APPLY SHARED-MODE ON SUPPF.
       DATA DIVISION.
       FILE SECTION.
           COPY FRCVH.
           COPY FRCVD.
           COPY FPURH.
           COPY FPURD.
           COPY FAPL.
           COPY FSUPP.
           COPY FPROD.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
      *----- control switches ------------------------------------------
       01  WK-FLAGS2.
           02  RCV-OK              PIC 9(1)  VALUE 0.
             88  RCV-YES                     VALUE 1.
           02  WK-MORE-FLG         PIC 9(1)  VALUE 0.
      *----- key / header work -----------------------------------------
       01  WK-KEYS.
           02  WK-RECV-KEY         PIC 9(10) VALUE 0.
           02  WK-VH-NO-D          PIC 9(10) VALUE 0.
           02  WK-SUPP-NAME        PIC X(40) VALUE SPACE.
           02  WK-NEW-BAL          PIC S9(11) VALUE 0.
      *----- running totals --------------------------------------------
       01  WK-TOTALS.
           02  WK-NET-TOTAL        PIC S9(13) VALUE 0.
           02  WK-TAX-TOTAL        PIC S9(13) VALUE 0.
           02  WK-GRS-TOTAL        PIC S9(13) VALUE 0.
      *----- one formatted review row ----------------------------------
       01  WK-ROW-BUF.
           02  RB-PROD             PIC 9(8).
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  RB-NAME             PIC X(16).
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  RB-QTY              PIC ---,---,--9.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  RB-COST             PIC ---,--9.99.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  RB-AMT              PIC ---,---,---,--9.
      *----- review row table (9 rows shown) ---------------------------
       01  WK-RTAB.
           02  WR-ROW OCCURS 9.
             03  WR-BUF            PIC X(66).
      *----- purchase detail line table --------------------------------
       01  WK-LINE-TABLE.
           02  WK-LCNT             PIC 9(3)  VALUE 0.
           02  WK-VLINE OCCURS 200.
             03  WL-PROD           PIC 9(8).
             03  WL-WHSE           PIC 9(3).
             03  WL-QTY            PIC S9(9).
             03  WL-COST           PIC S9(9)V9(2).
             03  WL-AMT            PIC S9(11).
             03  WL-TAXCAT         PIC 9(1).
             03  WL-NAME           PIC X(40).
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4.
             03  COLUMN 2  VALUE "Receiving No :" COLOR YELLOW.
             03  COLUMN 18 PIC 9(10) USING WK-RECV-KEY.
       01  DS-RINFO.
           02  LINE 3.
             03  COLUMN 2  VALUE "Recv No   :" COLOR YELLOW.
             03  COLUMN 14 PIC ZZZZZZZZZ9 FROM RH-NO COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "From PO   :" COLOR YELLOW.
             03  COLUMN 14 PIC ZZZZZZZZZ9 FROM RH-PO COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Supplier  :" COLOR YELLOW.
             03  COLUMN 14 PIC 9(6) FROM RH-SUPP COLOR WHITE.
             03  COLUMN 22 PIC X(40) FROM WK-SUPP-NAME COLOR WHITE.
       01  DS-VHEAD.
           02  LINE 6.
             03  COLUMN 2  VALUE "Purch Date:" COLOR YELLOW.
             03  COLUMN 14 PIC 9(8) USING VH-DATE.
           02  LINE 7.
             03  COLUMN 2  VALUE "Tax Type  :" COLOR YELLOW.
             03  COLUMN 14 PIC 9(1) USING VH-TAX-TYPE.
             03  COLUMN 18 VALUE "1:excl 2:incl 3:exempt" COLOR CYAN.
       01  DS-COLHDR.
           02  LINE 9 COLUMN 2 VALUE
               "Product  Name                 Qty      Cost"
               COLOR CYAN.
       01  DS-ROWS.
           02  LINE 10 COLUMN 2 PIC X(66) FROM WR-BUF (1) COLOR WHITE.
           02  LINE 11 COLUMN 2 PIC X(66) FROM WR-BUF (2) COLOR WHITE.
           02  LINE 12 COLUMN 2 PIC X(66) FROM WR-BUF (3) COLOR WHITE.
           02  LINE 13 COLUMN 2 PIC X(66) FROM WR-BUF (4) COLOR WHITE.
           02  LINE 14 COLUMN 2 PIC X(66) FROM WR-BUF (5) COLOR WHITE.
           02  LINE 15 COLUMN 2 PIC X(66) FROM WR-BUF (6) COLOR WHITE.
           02  LINE 16 COLUMN 2 PIC X(66) FROM WR-BUF (7) COLOR WHITE.
           02  LINE 17 COLUMN 2 PIC X(66) FROM WR-BUF (8) COLOR WHITE.
           02  LINE 18 COLUMN 2 PIC X(66) FROM WR-BUF (9) COLOR WHITE.
       01  DS-TOTAL.
           02  LINE 19.
             03  COLUMN 2  VALUE "Net :" COLOR YELLOW.
             03  COLUMN 8  PIC ---,---,---,--9 FROM WK-NET-TOTAL
                              COLOR WHITE.
             03  COLUMN 28 VALUE "Tax :" COLOR YELLOW.
             03  COLUMN 34 PIC ---,---,---,--9 FROM WK-TAX-TOTAL
                              COLOR WHITE.
             03  COLUMN 54 VALUE "Tot :" COLOR YELLOW.
             03  COLUMN 60 PIC ---,---,---,--9 FROM WK-GRS-TOTAL
                              COLOR WHITE.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Book purchase ? (Y/N) :"
                              COLOR YELLOW.
           02  LINE 21 COLUMN 28 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "PU0030"           TO WK-PROGID.
           MOVE "Purchase Entry"                   TO WK-TITLE.
           MOVE "ENTER=Next  PF3=End" TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           COMPUTE WK-SYS-YM = WK-SYSDATE / 100.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           PERFORM OPEN-IO-FILE-RCVH.
           PERFORM OPEN-IO-FILE-PURH.
           PERFORM OPEN-IO-FILE-PURD.
           PERFORM OPEN-IO-FILE-APL.
           PERFORM OPEN-IO-FILE-SUPP.
           OPEN INPUT RCVDF.
           OPEN INPUT PRODF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-RCVH SECTION.
       OFRH-010.
           OPEN I-O RCVHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT RCVHF
               CLOSE RCVHF
               OPEN I-O RCVHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "RCVHF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFRH-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-PURH SECTION.
       OFVH-010.
           OPEN I-O PURHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PURHF
               CLOSE PURHF
               OPEN I-O PURHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "PURHF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFVH-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-PURD SECTION.
       OFVD-010.
           OPEN I-O PURDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PURDF
               CLOSE PURDF
               OPEN I-O PURDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "PURDF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFVD-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-APL SECTION.
       OFPL-010.
           OPEN I-O APLF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT APLF
               CLOSE APLF
               OPEN I-O APLF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "APLF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFPL-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-SUPP SECTION.
       OFSP-010.
           OPEN I-O SUPPF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SUPPF
               CLOSE SUPPF
               OPEN I-O SUPPF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SUPPF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFSP-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-010.
           PERFORM CLEAR-PUR.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter the receiving number to book as purchase"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-RECV
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-PUR SECTION.
       CLRP-010.
           INITIALIZE VH-REC.
           MOVE 0                  TO WK-RECV-KEY WK-VH-NO-D.
           MOVE 0                  TO WK-LCNT.
           MOVE 0                  TO WK-NET-TOTAL WK-TAX-TOTAL.
           MOVE 0                  TO WK-GRS-TOTAL WK-NEW-BAL.
           MOVE 0                  TO RCV-OK WK-MORE-FLG.
           MOVE SPACE              TO WK-SUPP-NAME WK-CONFIRM.
           MOVE WK-SYSDATE         TO VH-DATE.
           MOVE 1                  TO VH-TAX-TYPE.
       CLRP-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-RECV SECTION.
       PRC-010.
           IF WK-RECV-KEY = 0
               MOVE "Receiving number required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PRC-999
           END-IF.
           MOVE WK-RECV-KEY        TO RH-NO.
           READ RCVHF
               INVALID KEY
                   MOVE "Receiving not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PRC-999
           END-READ.
           IF RH-DEL-FLAG = 1
               MOVE "Receiving is deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PRC-999
           END-IF.
           IF RH-STATUS = 9
               MOVE "Receiving is cancelled" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PRC-999
           END-IF.
           IF RH-STATUS = 1
               MOVE "Receiving already booked" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PRC-999
           END-IF.
           PERFORM LOOKUP-SUPP-NAME.
           PERFORM LOAD-RCV-LINES.
           IF WK-LCNT = 0
               MOVE "No detail lines on this receiving" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PRC-999
           END-IF.
           MOVE 1                  TO RCV-OK.
           PERFORM SETUP-HEADER.
           PERFORM ACCEPT-VHEAD.
           IF NOT RCV-YES
               GO TO PRC-999
           END-IF.
           PERFORM COMPUTE-TAX-TOTAL.
           PERFORM CONFIRM-SAVE.
       PRC-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-SUPP-NAME SECTION.
       LSN-010.
           MOVE SPACE              TO WK-SUPP-NAME.
           MOVE RH-SUPP            TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE "??? unknown supplier" TO WK-SUPP-NAME
               NOT INVALID KEY
                   MOVE SP-NAME    TO WK-SUPP-NAME
                   IF SP-TAX-TYPE NOT = 0
                       MOVE SP-TAX-TYPE TO VH-TAX-TYPE
                   END-IF
           END-READ.
       LSN-999.
           EXIT.
      *----------------------------------------------------------------
      *  Copy the receiving detail lines into the purchase table.
      *----------------------------------------------------------------
       LOAD-RCV-LINES SECTION.
       LRL-010.
           MOVE 0                  TO WK-LCNT.
           MOVE 0                  TO WK-NET-TOTAL.
           MOVE RH-NO              TO RD-NO.
           MOVE 0                  TO RD-LINE.
           START RCVDF KEY IS NOT < RD-NO
               INVALID KEY
                   GO TO LRL-999
           END-START.
           MOVE 0                  TO EOF-FLG.
           PERFORM UNTIL EOF-YES
               READ RCVDF NEXT
                   AT END
                       SET EOF-YES TO TRUE
                   NOT AT END
                       IF RD-NO NOT = RH-NO
                           SET EOF-YES TO TRUE
                       ELSE
                           PERFORM ADD-PUR-LINE
                       END-IF
               END-READ
           END-PERFORM.
       LRL-999.
           EXIT.
      *----------------------------------------------------------------
       ADD-PUR-LINE SECTION.
       APL2-010.
           IF WK-LCNT >= 200
               GO TO APL2-999
           END-IF.
           IF RD-QTY = 0
               GO TO APL2-999
           END-IF.
           ADD 1                   TO WK-LCNT.
           MOVE RD-PROD            TO WL-PROD (WK-LCNT).
           MOVE RD-WHSE            TO WL-WHSE (WK-LCNT).
           MOVE RD-QTY             TO WL-QTY  (WK-LCNT).
           MOVE RD-UNIT-COST       TO WL-COST (WK-LCNT).
           MOVE RD-AMOUNT          TO WL-AMT  (WK-LCNT).
           ADD  RD-AMOUNT          TO WK-NET-TOTAL.
           PERFORM LOOKUP-PROD.
       APL2-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-PROD SECTION.
       LKP-010.
           MOVE SPACE              TO WL-NAME (WK-LCNT).
           MOVE 1                  TO WL-TAXCAT (WK-LCNT).
           MOVE RD-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "??? unknown product" TO WL-NAME (WK-LCNT)
               NOT INVALID KEY
                   MOVE PR-NAME    TO WL-NAME   (WK-LCNT)
                   MOVE PR-TAX-CATEGORY TO WL-TAXCAT (WK-LCNT)
           END-READ.
       LKP-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-HEADER SECTION.
       SHD-010.
           IF VH-TAX-TYPE = 0
               MOVE 1              TO VH-TAX-TYPE
           END-IF.
           MOVE WK-SYSDATE         TO VH-DATE.
       SHD-999.
           EXIT.
      *----------------------------------------------------------------
       ACCEPT-VHEAD SECTION.
       AVH-010.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           DISPLAY DS-RINFO.
           PERFORM LOAD-REVIEW.
           DISPLAY DS-COLHDR.
           DISPLAY DS-ROWS.
           MOVE "Enter purchase date / tax type - PF3 cancel"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-VHEAD.
           ACCEPT  DS-VHEAD.
           IF ESTS = "03"
               MOVE 0              TO RCV-OK
               MOVE "Cancelled"    TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       AVH-999.
           EXIT.
      *----------------------------------------------------------------
      *  Format up to 9 purchase lines into the review row table.
      *----------------------------------------------------------------
       LOAD-REVIEW SECTION.
       LRV-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > 9
               MOVE SPACE          TO WR-BUF (WK-IDX)
           END-PERFORM.
           MOVE 0                  TO WK-MORE-FLG.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-LCNT
               IF WK-IDX > 9
                   MOVE 1          TO WK-MORE-FLG
               ELSE
                   MOVE WL-PROD (WK-IDX) TO RB-PROD
                   MOVE WL-NAME (WK-IDX) TO RB-NAME
                   MOVE WL-QTY  (WK-IDX) TO RB-QTY
                   MOVE WL-COST (WK-IDX) TO RB-COST
                   MOVE WL-AMT  (WK-IDX) TO RB-AMT
                   MOVE WK-ROW-BUF TO WR-BUF (WK-IDX)
               END-IF
           END-PERFORM.
       LRV-999.
           EXIT.
      *----------------------------------------------------------------
       COMPUTE-TAX-TOTAL SECTION.
       CTT-010.
           MOVE 1                  TO KT-CATEGORY.
           MOVE VH-TAX-TYPE        TO KT-TAX-TYPE.
           MOVE 1                  TO KT-ROUND.
           MOVE VH-DATE            TO KT-DATE.
           MOVE WK-NET-TOTAL       TO KT-AMOUNT.
           CALL "TAXCAL" USING KTAX.
           IF KT-STATUS = "00"
               MOVE KT-NET         TO WK-NET-TOTAL
               MOVE KT-TAX         TO WK-TAX-TOTAL
               MOVE KT-GROSS       TO WK-GRS-TOTAL
           ELSE
               MOVE 0              TO WK-TAX-TOTAL
               MOVE WK-NET-TOTAL   TO WK-GRS-TOTAL
           END-IF.
       CTT-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-SAVE SECTION.
       CSAV-010.
           MOVE SPACE              TO WK-CONFIRM.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           DISPLAY DS-RINFO.
           PERFORM LOAD-REVIEW.
           DISPLAY DS-COLHDR.
           DISPLAY DS-ROWS.
           DISPLAY DS-TOTAL.
           MOVE "Confirm to book the purchase" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               PERFORM SAVE-PURCHASE
           ELSE
               MOVE "Purchase discarded" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CSAV-999.
           EXIT.
      *----------------------------------------------------------------
      *  Write purchase header + detail, post AP, update supplier.
      *----------------------------------------------------------------
       SAVE-PURCHASE SECTION.
       SPU-010.
           MOVE "PURCH"            TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Purchase number assignment failed" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO SPU-999
           END-IF.
           MOVE KNUM-NUMBER        TO VH-NO  WK-VH-NO-D.
           MOVE RH-SUPP            TO VH-SUPP.
           MOVE RH-NO              TO VH-RECV-NO.
           COMPUTE VH-CLOSE-YM = VH-DATE / 100.
           MOVE WK-NET-TOTAL       TO VH-AMOUNT.
           MOVE WK-TAX-TOTAL       TO VH-TAX-AMOUNT.
           MOVE WK-GRS-TOTAL       TO VH-TOTAL.
           MOVE 0                  TO VH-STATUS.
           MOVE 1                  TO VH-KIND.
           MOVE WK-LCNT            TO VH-LINES.
           MOVE SPACE              TO VH-REMARK.
           MOVE WK-SYSDATE         TO VH-ADD-DATE.
           MOVE WK-USER-CODE       TO VH-ADD-USER.
           MOVE 0                  TO VH-DEL-FLAG.
           WRITE VH-REC
               INVALID KEY
                   MOVE "Purchase header write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO SPU-999
           END-WRITE.
           PERFORM WRITE-PUR-DETAILS.
           PERFORM POST-AP.
           PERFORM MARK-RECV-BOOKED.
           MOVE "Purchase booked"  TO WK-MSG-LINE.
           DISPLAY DS-TOTAL.
           DISPLAY DS-MSG.
       SPU-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-PUR-DETAILS SECTION.
       WPD-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-LCNT
               INITIALIZE VD-REC
               MOVE VH-NO          TO VD-NO
               MOVE WK-IDX         TO VD-LINE
               MOVE WL-PROD (WK-IDX) TO VD-PROD
               MOVE WL-WHSE (WK-IDX) TO VD-WHSE
               MOVE WL-QTY  (WK-IDX) TO VD-QTY
               MOVE WL-COST (WK-IDX) TO VD-UNIT-COST
               MOVE WL-AMT  (WK-IDX) TO VD-AMOUNT
               MOVE WL-TAXCAT (WK-IDX) TO VD-TAX-CATEGORY
               WRITE VD-REC
                   INVALID KEY
                       CONTINUE
               END-WRITE
           END-PERFORM.
       WPD-999.
           EXIT.
      *----------------------------------------------------------------
      *  Post the AP ledger entry and roll the supplier balance.
      *----------------------------------------------------------------
       POST-AP SECTION.
       PAP-010.
           MOVE "APLDG"            TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "AP ledger number assignment failed" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PAP-999
           END-IF.
           MOVE RH-SUPP            TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE 0          TO SP-BALANCE
           END-READ.
           COMPUTE WK-NEW-BAL = SP-BALANCE + WK-GRS-TOTAL.
           INITIALIZE PL-REC.
           MOVE KNUM-NUMBER        TO PL-SEQ.
           MOVE RH-SUPP            TO PL-SUPP.
           MOVE VH-DATE            TO PL-DATE.
           MOVE VH-CLOSE-YM        TO PL-CLOSE-YM.
           MOVE 1                  TO PL-KIND.
           MOVE 23                 TO PL-REF-TYPE.
           MOVE VH-NO              TO PL-REF-NO.
           MOVE 0                  TO PL-DEBIT.
           MOVE WK-GRS-TOTAL       TO PL-CREDIT.
           MOVE WK-NEW-BAL         TO PL-BALANCE.
           MOVE "Purchase"         TO PL-REMARK.
           MOVE WK-USER-CODE       TO PL-USER.
           WRITE PL-REC
               INVALID KEY
                   MOVE "AP ledger write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
           PERFORM UPDATE-SUPP-BAL.
       PAP-999.
           EXIT.
      *----------------------------------------------------------------
       UPDATE-SUPP-BAL SECTION.
       USB-010.
           MOVE RH-SUPP            TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   GO TO USB-999
           END-READ.
           MOVE WK-NEW-BAL         TO SP-BALANCE.
           MOVE WK-SYSDATE         TO SP-UPD-DATE.
           MOVE WK-USER-CODE       TO SP-UPD-USER.
           REWRITE SP-REC
               INVALID KEY
                   CONTINUE
           END-REWRITE.
       USB-999.
           EXIT.
      *----------------------------------------------------------------
       MARK-RECV-BOOKED SECTION.
       MRB-010.
           MOVE WK-RECV-KEY        TO RH-NO.
           READ RCVHF
               INVALID KEY
                   GO TO MRB-999
           END-READ.
           MOVE 1                  TO RH-STATUS.
           REWRITE RH-REC
               INVALID KEY
                   CONTINUE
           END-REWRITE.
       MRB-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE RCVHF RCVDF PURHF PURDF APLF SUPPF PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "PU0030"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
