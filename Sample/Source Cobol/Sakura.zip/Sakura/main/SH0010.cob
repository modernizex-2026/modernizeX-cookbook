       IDENTIFICATION DIVISION.
       PROGRAM-ID. SH0010.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : SH0010  -  Shipping entry (picking / despatch)   *
      *  FUNCTION : create a shipment (SHPHF / SHPDF) from an        *
      *             allocated or partly-shipped sales order.  A ship *
      *             number is assigned by NUMGEN "SHIP".  For every  *
      *             order line the proposed shipping quantity is the *
      *             smaller of the allocated quantity and the still- *
      *             outstanding quantity; the operator may adjust it *
      *             line by line.  On confirmation the shipment is   *
      *             written, on-hand and allocated stock are reduced,*
      *             a stock movement (kind 10 sale-out, negative     *
      *             quantity, sequence from NUMGEN "STKMOV") is      *
      *             logged, and the order line shipped quantity and  *
      *             the order status (2 part / 3 shipped) updated.   *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SORDH.
           COPY SORDD.
           COPY SSHPH.
           COPY SSHPD.
           COPY SSTOK.
           COPY SSMOV.
           COPY SCUST.
           COPY SPROD.
       I-O-CONTROL.
           APPLY SHARED-MODE ON ORDHF
           APPLY SHARED-MODE ON ORDDF
           APPLY SHARED-MODE ON SHPHF
           APPLY SHARED-MODE ON SHPDF
           APPLY SHARED-MODE ON STOKF
           APPLY SHARED-MODE ON SMOVF.
       DATA DIVISION.
       FILE SECTION.
           COPY FORDH.
           COPY FORDD.
           COPY FSHPH.
           COPY FSHPD.
           COPY FSTOK.
           COPY FSMOV.
           COPY FCUST.
           COPY FPROD.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
      *----- control ---------------------------------------------------
       01  WK-CTL.
           02  WK-SEL-NO           PIC 9(10) VALUE 0.
           02  WK-ORDER-NO         PIC 9(10) VALUE 0.
           02  WK-SHIP-NO          PIC 9(10) VALUE 0.
           02  WK-PGSIZE           PIC 9(3)  VALUE 13.
           02  WK-PAGE-TOP         PIC 9(3)  VALUE 1.
           02  WK-PAGE-NO          PIC 9(3)  VALUE 0.
           02  WK-PAGE-CNT         PIC 9(3)  VALUE 0.
           02  WK-SHIP-END         PIC 9(1)  VALUE 0.
             88  SHIP-END-YES                VALUE 1.
           02  WK-XLINE            PIC 9(3)  VALUE 0.
           02  WK-SHIP-CNT         PIC 9(3)  VALUE 0.
           02  WK-COMPLETE         PIC 9(1)  VALUE 0.
      *----- edit fields ----------------------------------------------
       01  WK-EDIT-FLDS.
           02  WK-EDIT-LN          PIC 9(3)  VALUE 0.
           02  WK-EDIT-QTY         PIC S9(9) VALUE 0.
      *----- per-line work --------------------------------------------
       01  WK-LINE-WORK.
           02  WK-REMAIN           PIC S9(9)  VALUE 0.
           02  WK-CAP              PIC S9(9)  VALUE 0.
           02  WK-SHIPQ            PIC S9(9)  VALUE 0.
           02  WK-STK-FOUND        PIC 9(1)   VALUE 0.
           02  WK-COST             PIC S9(9)V9(2) VALUE 0.
           02  WK-TOT-SHIP         PIC S9(11) VALUE 0.
           02  WK-TOT-AMT          PIC S9(13) VALUE 0.
      *----- header display -------------------------------------------
       01  WK-HDR-DISP.
           02  WK-CUST-NAME        PIC X(40) VALUE SPACE.
           02  WK-PROD-NAME        PIC X(40) VALUE SPACE.
           02  WK-STAT-TEXT        PIC X(12) VALUE SPACE.
      *----- detail buffer + window -----------------------------------
       01  WK-DTL-TABLE.
           02  WK-DCNT             PIC 9(3)  VALUE 0.
           02  WK-DROW OCCURS 200.
             03  DR-LINE           PIC 9(3).
             03  DR-PROD           PIC 9(8).
             03  DR-WHSE           PIC 9(3).
             03  DR-NAME           PIC X(14).
             03  DR-STKMNG         PIC 9(1).
             03  DR-ORD            PIC S9(9).
             03  DR-SHIPPED        PIC S9(9).
             03  DR-ALLOC          PIC S9(9).
             03  DR-SHIP           PIC S9(9).
             03  DR-PRICE          PIC S9(9)V9(2).
       01  WK-WIN.
           02  WW-ROW OCCURS 13.
             03  WW-LINE           PIC ZZ9.
             03  WW-PROD           PIC 9(8).
             03  WW-NAME           PIC X(14).
             03  WW-ORD            PIC ---,--9.
             03  WW-SHIPPED        PIC ---,--9.
             03  WW-ALLOC          PIC ---,--9.
             03  WW-SHIP           PIC ---,--9.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 5.
             03  COLUMN 2  VALUE "Order No :" COLOR YELLOW.
             03  COLUMN 14 PIC 9(10) USING WK-SEL-NO.
       01  DS-ORDER.
           02  LINE 3.
             03  COLUMN 2  VALUE "Order#:" COLOR YELLOW.
             03  COLUMN 10 PIC ZZZZZZZZZ9 FROM OH-NO COLOR WHITE.
             03  COLUMN 24 VALUE "Date:" COLOR YELLOW.
             03  COLUMN 30 PIC 9(8) FROM OH-DATE COLOR WHITE.
             03  COLUMN 42 VALUE "Status:" COLOR YELLOW.
             03  COLUMN 50 PIC X(12) FROM WK-STAT-TEXT COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "Cust  :" COLOR YELLOW.
             03  COLUMN 10 PIC 9(6) FROM OH-CUST COLOR WHITE.
             03  COLUMN 18 PIC X(34) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Whse :" COLOR YELLOW.
             03  COLUMN 9  PIC 9(3) FROM OH-WHSE COLOR WHITE.
             03  COLUMN 16 VALUE "Staff:" COLOR YELLOW.
             03  COLUMN 23 PIC 9(4) FROM OH-STAFF COLOR WHITE.
             03  COLUMN 30 VALUE "Due:" COLOR YELLOW.
             03  COLUMN 35 PIC 9(8) FROM OH-DUE-DATE COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE
                 "Ln Product   Name          Ord   Shpd  Aloc  Ship"
                              COLOR CYAN.
           02  LINE 7.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (1).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (1).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (1).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (1).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (1).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (1).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (1).
           02  LINE 8.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (2).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (2).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (2).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (2).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (2).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (2).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (2).
           02  LINE 9.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (3).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (3).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (3).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (3).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (3).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (3).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (3).
           02  LINE 10.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (4).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (4).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (4).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (4).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (4).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (4).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (4).
           02  LINE 11.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (5).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (5).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (5).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (5).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (5).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (5).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (5).
           02  LINE 12.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (6).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (6).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (6).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (6).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (6).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (6).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (6).
           02  LINE 13.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (7).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (7).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (7).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (7).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (7).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (7).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (7).
           02  LINE 14.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (8).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (8).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (8).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (8).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (8).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (8).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (8).
           02  LINE 15.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (9).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (9).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (9).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (9).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (9).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (9).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (9).
           02  LINE 16.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (10).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (10).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (10).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (10).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (10).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (10).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (10).
           02  LINE 17.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (11).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (11).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (11).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (11).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (11).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (11).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (11).
           02  LINE 18.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (12).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (12).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (12).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (12).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (12).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (12).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (12).
           02  LINE 19.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (13).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (13).
             03  COLUMN 15 PIC X(14) FROM WW-NAME (13).
             03  COLUMN 30 PIC ---,--9 FROM WW-ORD (13).
             03  COLUMN 38 PIC ---,--9 FROM WW-SHIPPED (13).
             03  COLUMN 46 PIC ---,--9 FROM WW-ALLOC (13).
             03  COLUMN 54 PIC ---,--9 FROM WW-SHIP (13).
       01  DS-STATUS.
           02  LINE 20.
             03  COLUMN 2  VALUE "Lines:" COLOR YELLOW.
             03  COLUMN 9  PIC ZZ9 FROM WK-DCNT COLOR WHITE.
             03  COLUMN 16 VALUE "TotShip:" COLOR YELLOW.
             03  COLUMN 25 PIC ---,---,--9 FROM WK-TOT-SHIP COLOR WHITE.
             03  COLUMN 42 VALUE "Page:" COLOR YELLOW.
             03  COLUMN 48 PIC ZZ9 FROM WK-PAGE-NO COLOR WHITE.
             03  COLUMN 51 VALUE "/" COLOR WHITE.
             03  COLUMN 52 PIC ZZ9 FROM WK-PAGE-CNT COLOR WHITE.
       01  DS-EDIT.
           02  LINE 21.
             03  COLUMN 2  VALUE "Chg Ln:" COLOR YELLOW.
             03  COLUMN 10 PIC 9(3) USING WK-EDIT-LN.
             03  COLUMN 16 VALUE "Ship:" COLOR YELLOW.
             03  COLUMN 22 PIC S9(9) USING WK-EDIT-QTY.
             03  COLUMN 40 VALUE "ENTER=set PF3=done" COLOR CYAN.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Confirm shipment ? (Y/N) :"
                              COLOR YELLOW.
           02  LINE 21 COLUMN 30 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "SH0010"           TO WK-PROGID.
           MOVE "Shipping Entry"                    TO WK-TITLE.
           MOVE "ENTER=Read  PF3=End"               TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           PERFORM OPEN-IO-ORDH.
           PERFORM OPEN-IO-ORDD.
           PERFORM OPEN-IO-SHPH.
           PERFORM OPEN-IO-SHPD.
           PERFORM OPEN-IO-STOK.
           PERFORM OPEN-IO-SMOV.
           OPEN INPUT CUSTF.
           OPEN INPUT PRODF.
       OPENF-999.
           EXIT.
       OPEN-IO-ORDH SECTION.
       OIOH-010.
           OPEN I-O ORDHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ORDHF
               CLOSE ORDHF
               OPEN I-O ORDHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ORDHF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIOH-999.
           EXIT.
       OPEN-IO-ORDD SECTION.
       OIOD-010.
           OPEN I-O ORDDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ORDDF
               CLOSE ORDDF
               OPEN I-O ORDDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ORDDF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIOD-999.
           EXIT.
       OPEN-IO-SHPH SECTION.
       OISH-010.
           OPEN I-O SHPHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SHPHF
               CLOSE SHPHF
               OPEN I-O SHPHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SHPHF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OISH-999.
           EXIT.
       OPEN-IO-SHPD SECTION.
       OISD-010.
           OPEN I-O SHPDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SHPDF
               CLOSE SHPDF
               OPEN I-O SHPDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SHPDF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OISD-999.
           EXIT.
       OPEN-IO-STOK SECTION.
       OIST-010.
           OPEN I-O STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIST-999.
           EXIT.
       OPEN-IO-SMOV SECTION.
       OISM-010.
           OPEN I-O SMOVF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SMOVF
               CLOSE SMOVF
               OPEN I-O SMOVF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SMOVF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OISM-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAINR-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter the order number to ship" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-ORDER
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAINR-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLRW-010.
           MOVE 0                  TO WK-SEL-NO WK-ORDER-NO WK-SHIP-NO.
           MOVE 0                  TO WK-DCNT WK-TOT-SHIP WK-TOT-AMT.
           MOVE 1                  TO WK-PAGE-TOP.
           MOVE 0                  TO WK-EDIT-LN WK-EDIT-QTY.
           MOVE SPACE              TO WK-CUST-NAME WK-CONFIRM.
       CLRW-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-ORDER SECTION.
       PORD-010.
           IF WK-SEL-NO = 0
               MOVE "Order number must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PORD-999
           END-IF.
           MOVE WK-SEL-NO          TO OH-NO.
           READ ORDHF
               INVALID KEY
                   MOVE "Order not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PORD-999
           END-READ.
           IF OH-DEL-FLAG = 1
               MOVE "Order is deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PORD-999
           END-IF.
           IF OH-STATUS = 0
               MOVE "Order is not allocated yet - run OE0030"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PORD-999
           END-IF.
           IF OH-STATUS NOT = 1 AND OH-STATUS NOT = 2
               MOVE "Order cannot be shipped in its status"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PORD-999
           END-IF.
           MOVE OH-NO              TO WK-ORDER-NO.
           PERFORM LOOKUP-CUSTOMER.
           PERFORM SET-STATUS-TEXT.
           PERFORM LOAD-ORDER-LINES.
           IF WK-DCNT = 0
               MOVE "Order has no detail lines" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PORD-999
           END-IF.
           PERFORM RECALC-TOTAL.
           PERFORM CALC-PAGES.
           MOVE 1                  TO WK-PAGE-TOP.
           PERFORM BUILD-WINDOW.
           PERFORM SHIP-LOOP.
       PORD-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-CUSTOMER SECTION.
       LKC-010.
           MOVE SPACE              TO WK-CUST-NAME.
           MOVE OH-CUST            TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "??? unknown customer" TO WK-CUST-NAME
               NOT INVALID KEY
                   MOVE CU-NAME    TO WK-CUST-NAME
           END-READ.
       LKC-999.
           EXIT.
      *----------------------------------------------------------------
       SET-STATUS-TEXT SECTION.
       SST-010.
           EVALUATE OH-STATUS
               WHEN 0
                   MOVE "Entered"     TO WK-STAT-TEXT
               WHEN 1
                   MOVE "Allocated"   TO WK-STAT-TEXT
               WHEN 2
                   MOVE "Part-ship"   TO WK-STAT-TEXT
               WHEN 3
                   MOVE "Shipped"     TO WK-STAT-TEXT
               WHEN 4
                   MOVE "Invoiced"    TO WK-STAT-TEXT
               WHEN 9
                   MOVE "Cancelled"   TO WK-STAT-TEXT
               WHEN OTHER
                   MOVE "Unknown"     TO WK-STAT-TEXT
           END-EVALUATE.
       SST-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-ORDER-LINES SECTION.
      *    read the order lines and propose a shipping quantity
       LOL-010.
           MOVE 0                  TO WK-DCNT.
           MOVE WK-ORDER-NO        TO OD-NO.
           MOVE 0                  TO OD-LINE.
           START ORDDF KEY IS NOT LESS THAN OD-NO
               INVALID KEY
                   GO TO LOL-999
           END-START.
       LOL-020.
           READ ORDDF NEXT
               AT END
                   GO TO LOL-999
           END-READ.
           IF OD-NO NOT = WK-ORDER-NO
               GO TO LOL-999
           END-IF.
           IF WK-DCNT >= 200
               GO TO LOL-999
           END-IF.
           ADD 1                   TO WK-DCNT.
           MOVE OD-LINE            TO DR-LINE   (WK-DCNT).
           MOVE OD-PROD            TO DR-PROD   (WK-DCNT).
           MOVE OD-WHSE            TO DR-WHSE   (WK-DCNT).
           MOVE OD-QTY             TO DR-ORD    (WK-DCNT).
           MOVE OD-SHIPPED-QTY     TO DR-SHIPPED(WK-DCNT).
           MOVE OD-ALLOC-QTY       TO DR-ALLOC  (WK-DCNT).
           MOVE OD-UNIT-PRICE      TO DR-PRICE  (WK-DCNT).
           PERFORM LOOKUP-PRODUCT.
           MOVE WK-PROD-NAME       TO DR-NAME   (WK-DCNT).
           PERFORM PROPOSE-SHIP.
           MOVE WK-SHIPQ           TO DR-SHIP   (WK-DCNT).
           GO TO LOL-020.
       LOL-999.
           EXIT.
      *----------------------------------------------------------------
       PROPOSE-SHIP SECTION.
      *    default ship = min( allocated , ordered - already shipped )
       PRS-010.
           COMPUTE WK-REMAIN = OD-QTY - OD-SHIPPED-QTY.
           IF WK-REMAIN < 0
               MOVE 0              TO WK-REMAIN
           END-IF.
           IF OD-ALLOC-QTY < WK-REMAIN
               MOVE OD-ALLOC-QTY   TO WK-SHIPQ
           ELSE
               MOVE WK-REMAIN      TO WK-SHIPQ
           END-IF.
           IF WK-SHIPQ < 0
               MOVE 0              TO WK-SHIPQ
           END-IF.
       PRS-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-PRODUCT SECTION.
       LKP-010.
           MOVE SPACE              TO WK-PROD-NAME.
           MOVE 1                  TO WK-IDX.
           MOVE OD-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "??"       TO WK-PROD-NAME
                   MOVE 1          TO WK-IDX
               NOT INVALID KEY
                   MOVE PR-NAME    TO WK-PROD-NAME
                   MOVE PR-STOCK-MNG TO WK-IDX
           END-READ.
           MOVE WK-IDX             TO DR-STKMNG (WK-DCNT).
       LKP-999.
           EXIT.
      *----------------------------------------------------------------
       RECALC-TOTAL SECTION.
       RCT-010.
           MOVE 0                  TO WK-TOT-SHIP.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-DCNT
               ADD DR-SHIP (WK-IDX) TO WK-TOT-SHIP
           END-PERFORM.
       RCT-999.
           EXIT.
      *----------------------------------------------------------------
       SHIP-LOOP SECTION.
      *    review / adjust the shipping quantities before posting
       SL-010.
           MOVE 0                  TO WK-SHIP-END.
           MOVE "ENTER=set  PF4=zero-all  PF6/PF12=page  PF3=post"
                                   TO WK-FKEY-LINE.
           PERFORM UNTIL SHIP-END-YES
               PERFORM PAINT-ORDER
               MOVE "Adjust ship qty by line, PF3 to post"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               MOVE 0              TO WK-EDIT-LN
               MOVE 0              TO WK-EDIT-QTY
               DISPLAY DS-EDIT
               ACCEPT  DS-EDIT
               EVALUATE ESTS
                   WHEN "03"
                       SET SHIP-END-YES TO TRUE
                   WHEN "04"
                       PERFORM ZERO-ALL
                   WHEN "06"
                       PERFORM PAGE-DOWN
                   WHEN "12"
                       PERFORM PAGE-UP
                   WHEN "00"
                       PERFORM APPLY-EDIT
                   WHEN OTHER
                       MOVE "Invalid key" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-EVALUATE
           END-PERFORM.
           MOVE "ENTER=Read  PF3=End" TO WK-FKEY-LINE.
           IF WK-TOT-SHIP <= 0
               MOVE "Nothing to ship - shipment discarded"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
           ELSE
               PERFORM CONFIRM-SHIP
           END-IF.
       SL-999.
           EXIT.
      *----------------------------------------------------------------
       ZERO-ALL SECTION.
       ZA-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-DCNT
               MOVE 0              TO DR-SHIP (WK-IDX)
           END-PERFORM.
           PERFORM RECALC-TOTAL.
           PERFORM BUILD-WINDOW.
       ZA-999.
           EXIT.
      *----------------------------------------------------------------
       APPLY-EDIT SECTION.
      *    change the ship quantity of the line the operator named
       AE-010.
           IF WK-EDIT-LN = 0
               MOVE "Enter a line number to change" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO AE-999
           END-IF.
           MOVE 0                  TO FOUND-FLG.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-DCNT
               IF DR-LINE (WK-IDX) = WK-EDIT-LN
                   SET FOUND-YES TO TRUE
                   MOVE WK-IDX     TO WK-IDX2
               END-IF
           END-PERFORM.
           IF NOT FOUND-YES
               MOVE "Line number not found" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO AE-999
           END-IF.
           IF WK-EDIT-QTY < 0
               MOVE "Quantity cannot be negative" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO AE-999
           END-IF.
           COMPUTE WK-REMAIN =
               DR-ORD (WK-IDX2) - DR-SHIPPED (WK-IDX2).
           IF WK-REMAIN < 0
               MOVE 0              TO WK-REMAIN
           END-IF.
           MOVE WK-REMAIN          TO WK-CAP.
           IF DR-STKMNG (WK-IDX2) = 1
               IF DR-ALLOC (WK-IDX2) < WK-CAP
                   MOVE DR-ALLOC (WK-IDX2) TO WK-CAP
               END-IF
           END-IF.
           IF WK-EDIT-QTY > WK-CAP
               MOVE WK-CAP         TO DR-SHIP (WK-IDX2)
               MOVE "Quantity capped to allocated / outstanding"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
           ELSE
               MOVE WK-EDIT-QTY    TO DR-SHIP (WK-IDX2)
               MOVE "Line updated" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
           PERFORM RECALC-TOTAL.
           PERFORM BUILD-WINDOW.
       AE-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-SHIP SECTION.
       CS-010.
           MOVE SPACE              TO WK-CONFIRM.
           PERFORM PAINT-ORDER.
           MOVE "Confirm shipment (Y) or PF3 to cancel"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF ESTS = "03"
               MOVE "Shipment cancelled" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO CS-999
           END-IF.
           IF CONFIRM-YES
               PERFORM POST-SHIPMENT
           ELSE
               MOVE "Shipment cancelled" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CS-999.
           EXIT.
      *----------------------------------------------------------------
       POST-SHIPMENT SECTION.
      *    assign a ship number, write the header, then every line
       PS-010.
           MOVE "SHIP"             TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Ship number assignment failed" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PS-999
           END-IF.
           MOVE KNUM-NUMBER        TO WK-SHIP-NO.
           PERFORM WRITE-SHIP-HEADER.
           MOVE 0                  TO WK-XLINE.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-DCNT
               IF DR-SHIP (WK-IDX) > 0
                   PERFORM SHIP-ONE-LINE
               END-IF
           END-PERFORM.
           MOVE WK-XLINE           TO WK-SHIP-CNT.
           PERFORM FINISH-SHIP-HEADER.
           PERFORM UPDATE-ORDER-STATUS.
           MOVE SPACE              TO WK-MSG-LINE.
           STRING "Shipment " DELIMITED SIZE
                  WK-SHIP-NO       DELIMITED SIZE
                  " created - "    DELIMITED SIZE
                  WK-SHIP-CNT      DELIMITED SIZE
                  " line(s)"       DELIMITED SIZE
                  INTO WK-MSG-LINE.
           DISPLAY DS-MSG.
       PS-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-SHIP-HEADER SECTION.
      *    write a provisional header; line count filled in later
       WSH-010.
           INITIALIZE XH-REC.
           MOVE WK-SHIP-NO         TO XH-NO.
           MOVE WK-SYSDATE         TO XH-DATE.
           MOVE WK-ORDER-NO        TO XH-ORDER.
           MOVE OH-CUST            TO XH-CUST.
           MOVE OH-WHSE            TO XH-WHSE.
           MOVE OH-STAFF           TO XH-STAFF.
           MOVE 1                  TO XH-STATUS.
           MOVE 0                  TO XH-LINES.
           MOVE OH-REMARK          TO XH-REMARK.
           MOVE WK-SYSDATE         TO XH-ADD-DATE.
           MOVE WK-USER-CODE       TO XH-ADD-USER.
           MOVE 0                  TO XH-DEL-FLAG.
           WRITE XH-REC
               INVALID KEY
                   MOVE "Shipment header write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       WSH-999.
           EXIT.
      *----------------------------------------------------------------
       FINISH-SHIP-HEADER SECTION.
       FSH-010.
           MOVE WK-SHIP-NO         TO XH-NO.
           READ SHPHF
               INVALID KEY
                   GO TO FSH-999
           END-READ.
           MOVE WK-SHIP-CNT        TO XH-LINES.
           REWRITE XH-REC
               INVALID KEY
                   CONTINUE
           END-REWRITE.
       FSH-999.
           EXIT.
      *----------------------------------------------------------------
       SHIP-ONE-LINE SECTION.
      *    ship a single order line : SHPDF + stock + movement + order
       SOL-010.
           MOVE DR-SHIP (WK-IDX)   TO WK-SHIPQ.
           MOVE 0                  TO WK-COST.
           PERFORM UPDATE-STOCK.
           ADD 1                   TO WK-XLINE.
           PERFORM WRITE-SHIP-DETAIL.
           PERFORM WRITE-MOVEMENT.
           PERFORM UPDATE-ORDER-LINE.
           COMPUTE WK-TOT-AMT =
               WK-TOT-AMT + (WK-SHIPQ * DR-PRICE (WK-IDX)).
       SOL-999.
           EXIT.
      *----------------------------------------------------------------
       UPDATE-STOCK SECTION.
      *    reduce on-hand and allocated; capture average cost
       US-010.
           MOVE 0                  TO WK-STK-FOUND.
           IF DR-STKMNG (WK-IDX) = 0
               GO TO US-999
           END-IF.
           MOVE DR-PROD (WK-IDX)   TO SK-PROD.
           MOVE DR-WHSE (WK-IDX)   TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   MOVE 0          TO WK-COST
                   GO TO US-999
           END-READ.
           MOVE 1                  TO WK-STK-FOUND.
           MOVE SK-AVG-COST        TO WK-COST.
           SUBTRACT WK-SHIPQ       FROM SK-ONHAND.
           SUBTRACT WK-SHIPQ       FROM SK-ALLOCATED.
           IF SK-ALLOCATED < 0
               MOVE 0              TO SK-ALLOCATED
           END-IF.
           MOVE WK-SYSDATE         TO SK-LAST-OUT-DATE.
           ADD WK-SHIPQ            TO SK-YTD-OUT.
           REWRITE SK-REC
               INVALID KEY
                   MOVE "Stock update failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
       US-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-SHIP-DETAIL SECTION.
       WSD-010.
           INITIALIZE XD-REC.
           MOVE WK-SHIP-NO         TO XD-NO.
           MOVE WK-XLINE           TO XD-LINE.
           MOVE WK-ORDER-NO        TO XD-ORDER.
           MOVE DR-LINE (WK-IDX)   TO XD-ORDER-LINE.
           MOVE DR-PROD (WK-IDX)   TO XD-PROD.
           MOVE DR-WHSE (WK-IDX)   TO XD-WHSE.
           MOVE WK-SHIPQ           TO XD-QTY.
           MOVE DR-PRICE (WK-IDX)  TO XD-UNIT-PRICE.
           COMPUTE XD-AMOUNT = WK-SHIPQ * DR-PRICE (WK-IDX).
           MOVE WK-COST            TO XD-UNIT-COST.
           WRITE XD-REC
               INVALID KEY
                   MOVE "Shipment line write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       WSD-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-MOVEMENT SECTION.
      *    log a sale-out movement (kind 10, negative quantity)
       WM-010.
           IF DR-STKMNG (WK-IDX) = 0 OR WK-STK-FOUND = 0
               GO TO WM-999
           END-IF.
           MOVE "STKMOV"           TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Movement number assignment failed"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO WM-999
           END-IF.
           INITIALIZE SM-REC.
           MOVE KNUM-NUMBER        TO SM-SEQ.
           MOVE WK-SYSDATE         TO SM-DATE.
           MOVE DR-PROD (WK-IDX)   TO SM-PROD.
           MOVE DR-WHSE (WK-IDX)   TO SM-WHSE.
           MOVE 10                 TO SM-KIND.
           COMPUTE SM-QTY = 0 - WK-SHIPQ.
           MOVE WK-COST            TO SM-UNIT-COST.
           MOVE SK-ONHAND          TO SM-BAL-AFTER.
           MOVE 2                  TO SM-REF-TYPE.
           MOVE WK-SHIP-NO         TO SM-REF-NO.
           MOVE WK-USER-CODE       TO SM-USER.
           WRITE SM-REC
               INVALID KEY
                   MOVE "Movement write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       WM-999.
           EXIT.
      *----------------------------------------------------------------
       UPDATE-ORDER-LINE SECTION.
      *    add shipped qty and release the matching allocation
       UOL-010.
           MOVE WK-ORDER-NO        TO OD-NO.
           MOVE DR-LINE (WK-IDX)   TO OD-LINE.
           READ ORDDF
               INVALID KEY
                   GO TO UOL-999
           END-READ.
           ADD WK-SHIPQ            TO OD-SHIPPED-QTY.
           SUBTRACT WK-SHIPQ       FROM OD-ALLOC-QTY.
           IF OD-ALLOC-QTY < 0
               MOVE 0              TO OD-ALLOC-QTY
           END-IF.
           IF OD-SHIPPED-QTY >= OD-QTY
               MOVE 3              TO OD-STATUS
           ELSE
               MOVE 2              TO OD-STATUS
           END-IF.
           MOVE OD-SHIPPED-QTY     TO DR-SHIPPED (WK-IDX).
           MOVE OD-ALLOC-QTY       TO DR-ALLOC (WK-IDX).
           REWRITE OD-REC
               INVALID KEY
                   MOVE "Order line update failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
       UOL-999.
           EXIT.
      *----------------------------------------------------------------
       UPDATE-ORDER-STATUS SECTION.
      *    fully shipped -> 3, otherwise part-ship -> 2
       UOS-010.
           PERFORM CHECK-COMPLETE.
           MOVE WK-ORDER-NO        TO OH-NO.
           READ ORDHF
               INVALID KEY
                   GO TO UOS-999
           END-READ.
           IF WK-COMPLETE = 1
               MOVE 3              TO OH-STATUS
           ELSE
               MOVE 2              TO OH-STATUS
           END-IF.
           MOVE WK-SYSDATE         TO OH-UPD-DATE.
           MOVE WK-USER-CODE       TO OH-UPD-USER.
           REWRITE OH-REC
               INVALID KEY
                   MOVE "Order status update failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
           PERFORM SET-STATUS-TEXT.
       UOS-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-COMPLETE SECTION.
      *    scan the order lines : complete only if none outstanding
       CC-010.
           MOVE 1                  TO WK-COMPLETE.
           MOVE WK-ORDER-NO        TO OD-NO.
           MOVE 0                  TO OD-LINE.
           START ORDDF KEY IS NOT LESS THAN OD-NO
               INVALID KEY
                   GO TO CC-999
           END-START.
       CC-020.
           READ ORDDF NEXT
               AT END
                   GO TO CC-999
           END-READ.
           IF OD-NO NOT = WK-ORDER-NO
               GO TO CC-999
           END-IF.
           IF OD-SHIPPED-QTY < OD-QTY
               MOVE 0              TO WK-COMPLETE
               GO TO CC-999
           END-IF.
           GO TO CC-020.
       CC-999.
           EXIT.
      *----------------------------------------------------------------
       CALC-PAGES SECTION.
       CLP-010.
           IF WK-DCNT = 0
               MOVE 1              TO WK-PAGE-CNT
           ELSE
               COMPUTE WK-PAGE-CNT =
                   (WK-DCNT + WK-PGSIZE - 1) / WK-PGSIZE
           END-IF.
       CLP-999.
           EXIT.
      *----------------------------------------------------------------
       BUILD-WINDOW SECTION.
       BW-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1
                   UNTIL WK-IDX > WK-PGSIZE
               COMPUTE WK-IDX2 = WK-PAGE-TOP + WK-IDX - 1
               IF WK-IDX2 <= WK-DCNT AND WK-IDX2 >= 1
                   MOVE DR-LINE   (WK-IDX2) TO WW-LINE   (WK-IDX)
                   MOVE DR-PROD   (WK-IDX2) TO WW-PROD   (WK-IDX)
                   MOVE DR-NAME   (WK-IDX2) TO WW-NAME   (WK-IDX)
                   MOVE DR-ORD    (WK-IDX2) TO WW-ORD    (WK-IDX)
                   MOVE DR-SHIPPED(WK-IDX2) TO WW-SHIPPED(WK-IDX)
                   MOVE DR-ALLOC  (WK-IDX2) TO WW-ALLOC  (WK-IDX)
                   MOVE DR-SHIP   (WK-IDX2) TO WW-SHIP   (WK-IDX)
               ELSE
                   MOVE ZERO       TO WW-LINE   (WK-IDX)
                   MOVE ZERO       TO WW-PROD   (WK-IDX)
                   MOVE SPACE      TO WW-NAME   (WK-IDX)
                   MOVE ZERO       TO WW-ORD    (WK-IDX)
                   MOVE ZERO       TO WW-SHIPPED(WK-IDX)
                   MOVE ZERO       TO WW-ALLOC  (WK-IDX)
                   MOVE ZERO       TO WW-SHIP   (WK-IDX)
               END-IF
           END-PERFORM.
           COMPUTE WK-PAGE-NO =
               (WK-PAGE-TOP + WK-PGSIZE - 1) / WK-PGSIZE.
       BW-999.
           EXIT.
      *----------------------------------------------------------------
       PAINT-ORDER SECTION.
       PO-010.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           DISPLAY DS-ORDER.
           DISPLAY DS-STATUS.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-DOWN SECTION.
       PD-010.
           IF WK-PAGE-TOP + WK-PGSIZE > WK-DCNT
               MOVE "Already at last page" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PD-999
           END-IF.
           ADD WK-PGSIZE           TO WK-PAGE-TOP.
           PERFORM BUILD-WINDOW.
       PD-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-UP SECTION.
       PU-010.
           IF WK-PAGE-TOP <= 1
               MOVE "Already at first page" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PU-999
           END-IF.
           IF WK-PAGE-TOP > WK-PGSIZE
               SUBTRACT WK-PGSIZE  FROM WK-PAGE-TOP
           ELSE
               MOVE 1              TO WK-PAGE-TOP
           END-IF.
           PERFORM BUILD-WINDOW.
       PU-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE ORDHF ORDDF SHPHF SHPDF STOKF SMOVF CUSTF PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "SH0010"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
