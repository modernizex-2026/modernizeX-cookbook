       IDENTIFICATION DIVISION.
       PROGRAM-ID. SL0030.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : SL0030  -  Sales return entry                    *
      *  FUNCTION : record a customer sales return as a negative     *
      *             invoice (INVHF / INVDF, IH-KIND = 2).  The       *
      *             quantities and amounts are stored negative.      *
      *             Returned goods are put back into stock : on-hand *
      *             is increased and a return-in movement (SM-KIND   *
      *             50, positive quantity, sequence from NUMGEN      *
      *             "STKMOV") is logged.  The AR ledger receives a   *
      *             credit (kind 3) via NUMGEN "ARLDG" and the       *
      *             customer balance is decreased by the return      *
      *             total.  The invoice number is assigned by        *
      *             NUMGEN "INVOICE".                                 *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SINVH.
           COPY SINVD.
           COPY SSTOK.
           COPY SSMOV.
           COPY SCUST.
           COPY SPROD.
           COPY SCPRC.
           COPY SARL.
       I-O-CONTROL.
           APPLY SHARED-MODE ON INVHF
           APPLY SHARED-MODE ON INVDF
           APPLY SHARED-MODE ON STOKF
           APPLY SHARED-MODE ON SMOVF
           APPLY SHARED-MODE ON CUSTF
           APPLY SHARED-MODE ON ARLF.
       DATA DIVISION.
       FILE SECTION.
           COPY FINVH.
           COPY FINVD.
           COPY FSTOK.
           COPY FSMOV.
           COPY FCUST.
           COPY FPROD.
           COPY FCPRC.
           COPY FARL.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
      *----- control ---------------------------------------------------
       01  WK-CTL.
           02  WK-SEL-CUST         PIC 9(6)  VALUE 0.
           02  WK-ORIG-INV         PIC 9(10) VALUE 0.
           02  WK-INV-NO           PIC 9(10) VALUE 0.
           02  WK-PGSIZE           PIC 9(3)  VALUE 12.
           02  WK-PAGE-TOP         PIC 9(3)  VALUE 1.
           02  WK-PAGE-NO          PIC 9(3)  VALUE 0.
           02  WK-PAGE-CNT         PIC 9(3)  VALUE 0.
           02  WK-DTL-DONE         PIC 9(1)  VALUE 0.
             88  DTL-END                     VALUE 1.
           02  WK-REVIEW-END       PIC 9(1)  VALUE 0.
             88  REVIEW-END-YES              VALUE 1.
           02  WK-DUMMY            PIC X(1)  VALUE SPACE.
      *----- detail entry work ----------------------------------------
       01  WK-DET.
           02  WK-D-PROD           PIC 9(8)  VALUE 0.
           02  WK-D-WHSE           PIC 9(3)  VALUE 0.
           02  WK-D-QTY            PIC S9(9) VALUE 0.
           02  WK-D-PRICE          PIC S9(9)V9(2) VALUE 0.
           02  WK-D-COST           PIC S9(9)V9(2) VALUE 0.
           02  WK-D-AMT            PIC S9(11) VALUE 0.
           02  WK-D-COSTAMT        PIC S9(11) VALUE 0.
           02  WK-D-NAME           PIC X(40) VALUE SPACE.
           02  WK-D-TAXCAT         PIC 9(1)  VALUE 1.
      *----- totals (positive magnitude) ------------------------------
       01  WK-TOTALS.
           02  WK-NET-TOTAL        PIC S9(13) VALUE 0.
           02  WK-TAX-TOTAL        PIC S9(13) VALUE 0.
           02  WK-GRS-TOTAL        PIC S9(13) VALUE 0.
           02  WK-COST-TOTAL       PIC S9(13) VALUE 0.
      *----- post work ------------------------------------------------
       01  WK-POST.
           02  WK-NEWBAL           PIC S9(9)  VALUE 0.
           02  WK-STK-FOUND        PIC 9(1)   VALUE 0.
           02  WK-LINE-QTY         PIC S9(9)  VALUE 0.
           02  WK-LINE-COST        PIC S9(9)V9(2) VALUE 0.
      *----- close-period calc ----------------------------------------
       01  WK-CALC.
           02  WK-YM               PIC 9(6)  VALUE 0.
           02  WK-DAY              PIC 9(2)  VALUE 0.
           02  WK-YYYY             PIC 9(4)  VALUE 0.
           02  WK-MM               PIC 9(2)  VALUE 0.
           02  WK-CLOSE-YM         PIC 9(6)  VALUE 0.
      *----- header / display -----------------------------------------
       01  WK-HDR-DISP.
           02  WK-CUST-NAME        PIC X(40) VALUE SPACE.
           02  WK-STAFF-IN         PIC 9(4)  VALUE 0.
           02  WK-TAXTYPE-IN       PIC 9(1)  VALUE 0.
      *----- detail buffer + window -----------------------------------
       01  WK-DTL-TABLE.
           02  WK-DCNT             PIC 9(3)  VALUE 0.
           02  WK-DROW OCCURS 200.
             03  DR-PROD           PIC 9(8).
             03  DR-WHSE           PIC 9(3).
             03  DR-NAME           PIC X(16).
             03  DR-QTY            PIC S9(9).
             03  DR-PRICE          PIC S9(9)V9(2).
             03  DR-AMT            PIC S9(11).
             03  DR-COST           PIC S9(9)V9(2).
             03  DR-COSTAMT        PIC S9(11).
             03  DR-TAXCAT         PIC 9(1).
             03  DR-STKMNG         PIC 9(1).
       01  WK-WIN.
           02  WW-ROW OCCURS 12.
             03  WW-PROD           PIC 9(8).
             03  WW-NAME           PIC X(16).
             03  WW-QTY            PIC ---,--9.
             03  WW-PRICE          PIC ---,--9.99.
             03  WW-AMT            PIC ----,---,--9.
             03  WW-COSTAMT        PIC ----,---,--9.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4.
             03  COLUMN 2  VALUE "Customer   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(6) USING WK-SEL-CUST.
             03  COLUMN 24 PIC X(40) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Orig Inv# :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(10) USING WK-ORIG-INV.
             03  COLUMN 28 VALUE "(reference, optional)" COLOR CYAN.
       01  DS-DHEAD.
           02  LINE 4.
             03  COLUMN 2  VALUE "Customer   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(6) FROM WK-SEL-CUST COLOR WHITE.
             03  COLUMN 24 PIC X(40) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Sales Rep  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(4) USING WK-STAFF-IN.
           02  LINE 6.
             03  COLUMN 2  VALUE "Tax Type   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(1) USING WK-TAXTYPE-IN.
             03  COLUMN 20 VALUE "1:excl 2:incl 3:exempt" COLOR CYAN.
       01  DS-DETAIL.
           02  LINE 12 COLUMN 2 VALUE "--- Return line entry ---"
                              COLOR CYAN.
           02  LINE 13.
             03  COLUMN 2  VALUE "Product    :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING WK-D-PROD.
             03  COLUMN 26 PIC X(40) FROM WK-D-NAME COLOR WHITE.
           02  LINE 14.
             03  COLUMN 2  VALUE "Warehouse  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(3) USING WK-D-WHSE.
           02  LINE 15.
             03  COLUMN 2  VALUE "Return Qty :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(9) USING WK-D-QTY.
           02  LINE 16.
             03  COLUMN 2  VALUE "Unit Price :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(9)V9(2) USING WK-D-PRICE.
       01  DS-ESTAT.
           02  LINE 19.
             03  COLUMN 2  VALUE "Lines :" COLOR YELLOW.
             03  COLUMN 10 PIC ZZ9 FROM WK-DCNT COLOR WHITE.
             03  COLUMN 20 VALUE "Return Net :" COLOR YELLOW.
             03  COLUMN 33 PIC ---,---,---,--9 FROM WK-NET-TOTAL
                              COLOR WHITE.
       01  DS-INV.
           02  LINE 3.
             03  COLUMN 2  VALUE "Return#:" COLOR YELLOW.
             03  COLUMN 11 PIC ZZZZZZZZZ9 FROM WK-INV-NO COLOR WHITE.
             03  COLUMN 25 VALUE "Date:" COLOR YELLOW.
             03  COLUMN 31 PIC 9(8) FROM WK-SYSDATE COLOR WHITE.
             03  COLUMN 44 VALUE "RETURN" REVERSE COLOR RED.
           02  LINE 4.
             03  COLUMN 2  VALUE "Cust :" COLOR YELLOW.
             03  COLUMN 9  PIC 9(6) FROM WK-SEL-CUST COLOR WHITE.
             03  COLUMN 17 PIC X(34) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Tax  :" COLOR YELLOW.
             03  COLUMN 9  PIC 9(1) FROM WK-TAXTYPE-IN COLOR WHITE.
             03  COLUMN 14 VALUE "Staff:" COLOR YELLOW.
             03  COLUMN 21 PIC 9(4) FROM WK-STAFF-IN COLOR WHITE.
             03  COLUMN 30 VALUE "OrigInv:" COLOR YELLOW.
             03  COLUMN 39 PIC ZZZZZZZZZ9 FROM WK-ORIG-INV COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE
                 "Product  Name             Qty     Price"
                              COLOR CYAN.
             03  COLUMN 47 VALUE "Amount       Cost" COLOR CYAN.
           02  LINE 7.
             03  COLUMN 2  PIC 9(8) FROM WW-PROD (1).
             03  COLUMN 11 PIC X(16) FROM WW-NAME (1).
             03  COLUMN 28 PIC ---,--9 FROM WW-QTY (1).
             03  COLUMN 36 PIC ---,--9.99 FROM WW-PRICE (1).
             03  COLUMN 47 PIC ----,---,--9 FROM WW-AMT (1).
             03  COLUMN 60 PIC ----,---,--9 FROM WW-COSTAMT (1).
           02  LINE 8.
             03  COLUMN 2  PIC 9(8) FROM WW-PROD (2).
             03  COLUMN 11 PIC X(16) FROM WW-NAME (2).
             03  COLUMN 28 PIC ---,--9 FROM WW-QTY (2).
             03  COLUMN 36 PIC ---,--9.99 FROM WW-PRICE (2).
             03  COLUMN 47 PIC ----,---,--9 FROM WW-AMT (2).
             03  COLUMN 60 PIC ----,---,--9 FROM WW-COSTAMT (2).
           02  LINE 9.
             03  COLUMN 2  PIC 9(8) FROM WW-PROD (3).
             03  COLUMN 11 PIC X(16) FROM WW-NAME (3).
             03  COLUMN 28 PIC ---,--9 FROM WW-QTY (3).
             03  COLUMN 36 PIC ---,--9.99 FROM WW-PRICE (3).
             03  COLUMN 47 PIC ----,---,--9 FROM WW-AMT (3).
             03  COLUMN 60 PIC ----,---,--9 FROM WW-COSTAMT (3).
           02  LINE 10.
             03  COLUMN 2  PIC 9(8) FROM WW-PROD (4).
             03  COLUMN 11 PIC X(16) FROM WW-NAME (4).
             03  COLUMN 28 PIC ---,--9 FROM WW-QTY (4).
             03  COLUMN 36 PIC ---,--9.99 FROM WW-PRICE (4).
             03  COLUMN 47 PIC ----,---,--9 FROM WW-AMT (4).
             03  COLUMN 60 PIC ----,---,--9 FROM WW-COSTAMT (4).
           02  LINE 11.
             03  COLUMN 2  PIC 9(8) FROM WW-PROD (5).
             03  COLUMN 11 PIC X(16) FROM WW-NAME (5).
             03  COLUMN 28 PIC ---,--9 FROM WW-QTY (5).
             03  COLUMN 36 PIC ---,--9.99 FROM WW-PRICE (5).
             03  COLUMN 47 PIC ----,---,--9 FROM WW-AMT (5).
             03  COLUMN 60 PIC ----,---,--9 FROM WW-COSTAMT (5).
           02  LINE 12.
             03  COLUMN 2  PIC 9(8) FROM WW-PROD (6).
             03  COLUMN 11 PIC X(16) FROM WW-NAME (6).
             03  COLUMN 28 PIC ---,--9 FROM WW-QTY (6).
             03  COLUMN 36 PIC ---,--9.99 FROM WW-PRICE (6).
             03  COLUMN 47 PIC ----,---,--9 FROM WW-AMT (6).
             03  COLUMN 60 PIC ----,---,--9 FROM WW-COSTAMT (6).
           02  LINE 13.
             03  COLUMN 2  PIC 9(8) FROM WW-PROD (7).
             03  COLUMN 11 PIC X(16) FROM WW-NAME (7).
             03  COLUMN 28 PIC ---,--9 FROM WW-QTY (7).
             03  COLUMN 36 PIC ---,--9.99 FROM WW-PRICE (7).
             03  COLUMN 47 PIC ----,---,--9 FROM WW-AMT (7).
             03  COLUMN 60 PIC ----,---,--9 FROM WW-COSTAMT (7).
           02  LINE 14.
             03  COLUMN 2  PIC 9(8) FROM WW-PROD (8).
             03  COLUMN 11 PIC X(16) FROM WW-NAME (8).
             03  COLUMN 28 PIC ---,--9 FROM WW-QTY (8).
             03  COLUMN 36 PIC ---,--9.99 FROM WW-PRICE (8).
             03  COLUMN 47 PIC ----,---,--9 FROM WW-AMT (8).
             03  COLUMN 60 PIC ----,---,--9 FROM WW-COSTAMT (8).
           02  LINE 15.
             03  COLUMN 2  PIC 9(8) FROM WW-PROD (9).
             03  COLUMN 11 PIC X(16) FROM WW-NAME (9).
             03  COLUMN 28 PIC ---,--9 FROM WW-QTY (9).
             03  COLUMN 36 PIC ---,--9.99 FROM WW-PRICE (9).
             03  COLUMN 47 PIC ----,---,--9 FROM WW-AMT (9).
             03  COLUMN 60 PIC ----,---,--9 FROM WW-COSTAMT (9).
           02  LINE 16.
             03  COLUMN 2  PIC 9(8) FROM WW-PROD (10).
             03  COLUMN 11 PIC X(16) FROM WW-NAME (10).
             03  COLUMN 28 PIC ---,--9 FROM WW-QTY (10).
             03  COLUMN 36 PIC ---,--9.99 FROM WW-PRICE (10).
             03  COLUMN 47 PIC ----,---,--9 FROM WW-AMT (10).
             03  COLUMN 60 PIC ----,---,--9 FROM WW-COSTAMT (10).
           02  LINE 17.
             03  COLUMN 2  PIC 9(8) FROM WW-PROD (11).
             03  COLUMN 11 PIC X(16) FROM WW-NAME (11).
             03  COLUMN 28 PIC ---,--9 FROM WW-QTY (11).
             03  COLUMN 36 PIC ---,--9.99 FROM WW-PRICE (11).
             03  COLUMN 47 PIC ----,---,--9 FROM WW-AMT (11).
             03  COLUMN 60 PIC ----,---,--9 FROM WW-COSTAMT (11).
           02  LINE 18.
             03  COLUMN 2  PIC 9(8) FROM WW-PROD (12).
             03  COLUMN 11 PIC X(16) FROM WW-NAME (12).
             03  COLUMN 28 PIC ---,--9 FROM WW-QTY (12).
             03  COLUMN 36 PIC ---,--9.99 FROM WW-PRICE (12).
             03  COLUMN 47 PIC ----,---,--9 FROM WW-AMT (12).
             03  COLUMN 60 PIC ----,---,--9 FROM WW-COSTAMT (12).
       01  DS-TOTAL.
           02  LINE 19.
             03  COLUMN 2  VALUE "Net:" COLOR YELLOW.
             03  COLUMN 7  PIC ---,---,---,--9 FROM WK-NET-TOTAL.
             03  COLUMN 24 VALUE "Tax:" COLOR YELLOW.
             03  COLUMN 29 PIC ---,---,--9 FROM WK-TAX-TOTAL.
             03  COLUMN 43 VALUE "Total:" COLOR YELLOW.
             03  COLUMN 50 PIC ---,---,---,--9 FROM WK-GRS-TOTAL.
           02  LINE 20.
             03  COLUMN 2  VALUE "Cost:" COLOR YELLOW.
             03  COLUMN 8  PIC ---,---,---,--9 FROM WK-COST-TOTAL.
             03  COLUMN 24 VALUE "Page:" COLOR YELLOW.
             03  COLUMN 30 PIC ZZ9 FROM WK-PAGE-NO COLOR WHITE.
             03  COLUMN 33 VALUE "/" COLOR WHITE.
             03  COLUMN 34 PIC ZZ9 FROM WK-PAGE-CNT COLOR WHITE.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Post return ? (Y/N) :"
                              COLOR YELLOW.
           02  LINE 21 COLUMN 25 PIC X(1) USING WK-CONFIRM.
       01  DS-BROWSE.
           02  LINE 20 COLUMN 44 VALUE "PFkey:" COLOR CYAN.
           02  LINE 20 COLUMN 51 PIC X(1) USING WK-DUMMY.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "SL0030"           TO WK-PROGID.
           MOVE "Sales Return Entry"               TO WK-TITLE.
           MOVE "ENTER=Next  PF3=End"              TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           PERFORM OPEN-IO-INVH.
           PERFORM OPEN-IO-INVD.
           PERFORM OPEN-IO-STOK.
           PERFORM OPEN-IO-SMOV.
           PERFORM OPEN-IO-CUST.
           PERFORM OPEN-IO-ARL.
           OPEN INPUT PRODF.
           OPEN INPUT CPRCF.
       OPENF-999.
           EXIT.
       OPEN-IO-INVH SECTION.
       OIIH-010.
           OPEN I-O INVHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT INVHF
               CLOSE INVHF
               OPEN I-O INVHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "INVHF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIIH-999.
           EXIT.
       OPEN-IO-INVD SECTION.
       OIID-010.
           OPEN I-O INVDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT INVDF
               CLOSE INVDF
               OPEN I-O INVDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "INVDF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIID-999.
           EXIT.
       OPEN-IO-STOK SECTION.
       OIST-010.
           OPEN I-O STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIST-999.
           EXIT.
       OPEN-IO-SMOV SECTION.
       OISM-010.
           OPEN I-O SMOVF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SMOVF
               CLOSE SMOVF
               OPEN I-O SMOVF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SMOVF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OISM-999.
           EXIT.
       OPEN-IO-CUST SECTION.
       OICU-010.
           OPEN I-O CUSTF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT CUSTF
               CLOSE CUSTF
               OPEN I-O CUSTF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "CUSTF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OICU-999.
           EXIT.
       OPEN-IO-ARL SECTION.
       OIAR-010.
           OPEN I-O ARLF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ARLF
               CLOSE ARLF
               OPEN I-O ARLF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ARLF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIAR-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAINR-010.
           PERFORM CLEAR-RETURN.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter the customer code for the return"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-RETURN
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAINR-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-RETURN SECTION.
       CLRR-010.
           MOVE 0                  TO WK-SEL-CUST WK-ORIG-INV.
           MOVE 0                  TO WK-INV-NO WK-DCNT.
           MOVE 0                  TO WK-NET-TOTAL WK-TAX-TOTAL.
           MOVE 0                  TO WK-GRS-TOTAL WK-COST-TOTAL.
           MOVE 0                  TO WK-STAFF-IN WK-TAXTYPE-IN.
           MOVE 1                  TO WK-PAGE-TOP.
           MOVE SPACE              TO WK-CUST-NAME WK-CONFIRM.
       CLRR-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-RETURN SECTION.
       PRT-010.
           IF WK-SEL-CUST = 0
               MOVE "Customer code required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PRT-999
           END-IF.
           PERFORM READ-CUSTOMER.
           IF NOT FOUND-YES
               DISPLAY DS-MSG
               GO TO PRT-999
           END-IF.
           MOVE CU-STAFF           TO WK-STAFF-IN.
           MOVE CU-TAX-TYPE        TO WK-TAXTYPE-IN.
           PERFORM ENTER-HEADER.
           IF ERR-YES
               GO TO PRT-999
           END-IF.
           PERFORM DETAIL-ENTRY-LOOP.
           IF WK-DCNT = 0
               MOVE "No lines entered - return discarded"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PRT-999
           END-IF.
           PERFORM COMPUTE-TOTALS.
           PERFORM REVIEW-AND-POST.
       PRT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-CUSTOMER SECTION.
       RC-010.
           MOVE 0                  TO FOUND-FLG.
           MOVE SPACE              TO WK-CUST-NAME.
           MOVE WK-SEL-CUST        TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "Customer not found" TO WK-MSG-LINE
                   GO TO RC-999
           END-READ.
           IF CU-DEL-FLAG = 1
               MOVE "Customer is deleted" TO WK-MSG-LINE
               GO TO RC-999
           END-IF.
           MOVE CU-NAME            TO WK-CUST-NAME.
           SET FOUND-YES TO TRUE.
       RC-999.
           EXIT.
      *----------------------------------------------------------------
       ENTER-HEADER SECTION.
       EH-010.
           MOVE 0                  TO ERR-FLG.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter return header - PF3 to cancel" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-DHEAD.
           ACCEPT  DS-DHEAD.
           IF ESTS = "03"
               SET ERR-YES TO TRUE
               GO TO EH-999
           END-IF.
           IF WK-TAXTYPE-IN = 0
               MOVE CU-TAX-TYPE    TO WK-TAXTYPE-IN
           END-IF.
           IF WK-TAXTYPE-IN < 1 OR WK-TAXTYPE-IN > 3
               MOVE "Tax type must be 1, 2 or 3" TO WK-MSG-LINE
               DISPLAY DS-MSG
               SET ERR-YES TO TRUE
           END-IF.
       EH-999.
           EXIT.
      *----------------------------------------------------------------
       DETAIL-ENTRY-LOOP SECTION.
       DEL-010.
           MOVE 0                  TO WK-DTL-DONE.
           PERFORM UNTIL DTL-END
               PERFORM CLEAR-DETAIL
               DISPLAY DS-DETAIL
               DISPLAY DS-ESTAT
               ACCEPT  DS-DETAIL
               EVALUATE ESTS
                   WHEN "03"
                       SET DTL-END TO TRUE
                   WHEN "04"
                       MOVE "Line cleared" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   WHEN "00"
                       PERFORM PROCESS-DETAIL
                   WHEN OTHER
                       MOVE "Invalid key" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-EVALUATE
           END-PERFORM.
       DEL-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-DETAIL SECTION.
       CLRD-010.
           MOVE 0                  TO WK-D-PROD WK-D-WHSE WK-D-QTY.
           MOVE 0                  TO WK-D-PRICE WK-D-AMT WK-D-COST.
           MOVE 0                  TO WK-D-COSTAMT.
           MOVE 1                  TO WK-D-TAXCAT.
           MOVE SPACE              TO WK-D-NAME.
       CLRD-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-DETAIL SECTION.
       PDET-010.
           IF WK-D-PROD = 0
               MOVE "Product code required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           PERFORM LOOKUP-PRODUCT.
           IF NOT FOUND-YES
               MOVE "Product not found" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           IF WK-D-WHSE = 0
               MOVE PR-DFLT-WHSE   TO WK-D-WHSE
           END-IF.
           IF WK-D-QTY <= 0
               MOVE "Return qty must be positive" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           IF WK-D-PRICE <= 0
               PERFORM RESOLVE-PRICE
           END-IF.
           PERFORM RESOLVE-COST.
           COMPUTE WK-D-AMT = WK-D-QTY * WK-D-PRICE.
           COMPUTE WK-D-COSTAMT = WK-D-QTY * WK-D-COST.
           PERFORM ADD-LINE.
       PDET-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-PRODUCT SECTION.
       LKP-010.
           MOVE 0                  TO FOUND-FLG.
           MOVE SPACE              TO WK-D-NAME.
           MOVE 1                  TO WK-D-TAXCAT.
           MOVE WK-D-PROD          TO PR-CODE.
           READ PRODF
               INVALID KEY
                   GO TO LKP-999
           END-READ.
           IF PR-DEL-FLAG = 1
               GO TO LKP-999
           END-IF.
           MOVE PR-NAME            TO WK-D-NAME.
           MOVE PR-TAX-CATEGORY    TO WK-D-TAXCAT.
           SET FOUND-YES TO TRUE.
       LKP-999.
           EXIT.
      *----------------------------------------------------------------
       RESOLVE-PRICE SECTION.
       RPRC-010.
           MOVE WK-SEL-CUST        TO CP-CUST.
           MOVE WK-D-PROD          TO CP-PROD.
           READ CPRCF
               INVALID KEY
                   PERFORM RANK-PRICE
               NOT INVALID KEY
                   IF CP-DEL-FLAG = 0
                     AND CP-START-DATE <= WK-SYSDATE
                     AND (CP-END-DATE = 0 OR CP-END-DATE >= WK-SYSDATE)
                       MOVE CP-PRICE TO WK-D-PRICE
                   ELSE
                       PERFORM RANK-PRICE
                   END-IF
           END-READ.
       RPRC-999.
           EXIT.
       RANK-PRICE SECTION.
       RANK-010.
           IF CU-PRICE-RANK >= 1 AND CU-PRICE-RANK <= 5
               MOVE PR-RANK-PRICE (CU-PRICE-RANK) TO WK-D-PRICE
           END-IF.
           IF WK-D-PRICE <= 0
               MOVE PR-LIST-PRICE  TO WK-D-PRICE
           END-IF.
       RANK-999.
           EXIT.
      *----------------------------------------------------------------
       RESOLVE-COST SECTION.
       RCST-010.
           MOVE 0                  TO WK-D-COST.
           MOVE WK-D-PROD          TO SK-PROD.
           MOVE WK-D-WHSE          TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   MOVE 0          TO WK-D-COST
               NOT INVALID KEY
                   MOVE SK-AVG-COST TO WK-D-COST
           END-READ.
           IF WK-D-COST <= 0
               MOVE WK-D-PROD      TO PR-CODE
               READ PRODF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE PR-STD-COST TO WK-D-COST
               END-READ
           END-IF.
       RCST-999.
           EXIT.
      *----------------------------------------------------------------
       ADD-LINE SECTION.
       ADDL-010.
           IF WK-DCNT >= 200
               MOVE "Maximum 200 lines reached" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO ADDL-999
           END-IF.
           ADD 1                   TO WK-DCNT.
           MOVE WK-D-PROD          TO DR-PROD    (WK-DCNT).
           MOVE WK-D-WHSE          TO DR-WHSE    (WK-DCNT).
           MOVE WK-D-NAME          TO DR-NAME    (WK-DCNT).
           MOVE WK-D-QTY           TO DR-QTY     (WK-DCNT).
           MOVE WK-D-PRICE         TO DR-PRICE   (WK-DCNT).
           MOVE WK-D-AMT           TO DR-AMT     (WK-DCNT).
           MOVE WK-D-COST          TO DR-COST    (WK-DCNT).
           MOVE WK-D-COSTAMT       TO DR-COSTAMT (WK-DCNT).
           MOVE WK-D-TAXCAT        TO DR-TAXCAT  (WK-DCNT).
           MOVE PR-STOCK-MNG       TO DR-STKMNG  (WK-DCNT).
           ADD  WK-D-AMT           TO WK-NET-TOTAL.
           MOVE "Line added"       TO WK-MSG-LINE.
           DISPLAY DS-ESTAT.
           DISPLAY DS-MSG.
       ADDL-999.
           EXIT.
      *----------------------------------------------------------------
       COMPUTE-TOTALS SECTION.
       CT-010.
           MOVE 0                  TO WK-NET-TOTAL WK-COST-TOTAL.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-DCNT
               ADD DR-AMT     (WK-IDX) TO WK-NET-TOTAL
               ADD DR-COSTAMT (WK-IDX) TO WK-COST-TOTAL
           END-PERFORM.
           MOVE 1                  TO KT-CATEGORY.
           MOVE WK-TAXTYPE-IN      TO KT-TAX-TYPE.
           MOVE CU-TAX-ROUND       TO KT-ROUND.
           IF KT-ROUND = 0
               MOVE 1              TO KT-ROUND
           END-IF.
           MOVE WK-SYSDATE         TO KT-DATE.
           MOVE WK-NET-TOTAL       TO KT-AMOUNT.
           CALL "TAXCAL" USING KTAX.
           MOVE KT-NET             TO WK-NET-TOTAL.
           MOVE KT-TAX             TO WK-TAX-TOTAL.
           MOVE KT-GROSS           TO WK-GRS-TOTAL.
       CT-999.
           EXIT.
      *----------------------------------------------------------------
       REVIEW-AND-POST SECTION.
       RAP-010.
           PERFORM CALC-PAGES.
           MOVE 1                  TO WK-PAGE-TOP.
           PERFORM BUILD-WINDOW.
           PERFORM REVIEW-LOOP.
           IF REVIEW-END-YES
               PERFORM ASK-CONFIRM
           END-IF.
       RAP-999.
           EXIT.
      *----------------------------------------------------------------
       REVIEW-LOOP SECTION.
       RVL-010.
           MOVE 0                  TO WK-REVIEW-END.
           MOVE "PF6/PF12=page  ENTER=confirm  PF3=cancel"
                                   TO WK-FKEY-LINE.
           PERFORM UNTIL REVIEW-END-YES OR END-YES
               PERFORM PAINT-RETURN
               DISPLAY DS-BROWSE
               ACCEPT  DS-BROWSE
               EVALUATE ESTS
                   WHEN "03"
                       MOVE "Return cancelled" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                       GO TO RVL-020
                   WHEN "00"
                       SET REVIEW-END-YES TO TRUE
                   WHEN "06"
                       PERFORM PAGE-DOWN
                   WHEN "12"
                       PERFORM PAGE-UP
                   WHEN OTHER
                       CONTINUE
               END-EVALUATE
           END-PERFORM.
       RVL-020.
           MOVE "ENTER=Next  PF3=End" TO WK-FKEY-LINE.
       RVL-999.
           EXIT.
      *----------------------------------------------------------------
       ASK-CONFIRM SECTION.
       AC-010.
           MOVE SPACE              TO WK-CONFIRM.
           PERFORM PAINT-RETURN.
           MOVE "Confirm to post the return" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               PERFORM POST-RETURN
           ELSE
               MOVE "Return discarded" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       AC-999.
           EXIT.
      *----------------------------------------------------------------
       POST-RETURN SECTION.
       POSR-010.
           MOVE "INVOICE"          TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Return number assignment failed" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO POSR-999
           END-IF.
           MOVE KNUM-NUMBER        TO WK-INV-NO.
           PERFORM CALC-CLOSE-YM.
           PERFORM WRITE-RET-HEADER.
           PERFORM WRITE-RET-DETAILS.
           PERFORM POST-AR-LEDGER.
           PERFORM UPDATE-CUST-BALANCE.
           MOVE SPACE              TO WK-MSG-LINE.
           STRING "Return "        DELIMITED SIZE
                  WK-INV-NO        DELIMITED SIZE
                  " posted"        DELIMITED SIZE
                  INTO WK-MSG-LINE.
           DISPLAY DS-MSG.
       POSR-999.
           EXIT.
      *----------------------------------------------------------------
       CALC-CLOSE-YM SECTION.
       CCY-010.
           COMPUTE WK-YM  = WK-SYSDATE / 100.
           COMPUTE WK-DAY = WK-SYSDATE - (WK-YM * 100).
           MOVE WK-YM              TO WK-CLOSE-YM.
           IF CU-CLOSE-DAY > 0 AND CU-CLOSE-DAY < 99
               IF WK-DAY > CU-CLOSE-DAY
                   COMPUTE WK-YYYY = WK-YM / 100
                   COMPUTE WK-MM   = WK-YM - (WK-YYYY * 100)
                   ADD 1           TO WK-MM
                   IF WK-MM > 12
                       MOVE 1      TO WK-MM
                       ADD 1       TO WK-YYYY
                   END-IF
                   COMPUTE WK-CLOSE-YM = (WK-YYYY * 100) + WK-MM
               END-IF
           END-IF.
       CCY-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-RET-HEADER SECTION.
      *    amounts are stored as negative values for a return
       WRH-010.
           INITIALIZE IH-REC.
           MOVE WK-INV-NO          TO IH-NO.
           MOVE WK-SYSDATE         TO IH-DATE.
           MOVE WK-SEL-CUST        TO IH-CUST.
           MOVE WK-STAFF-IN        TO IH-STAFF.
           MOVE 0                  TO IH-SHIP-NO.
           MOVE WK-CLOSE-YM        TO IH-CLOSE-YM.
           MOVE WK-TAXTYPE-IN      TO IH-TAX-TYPE.
           COMPUTE IH-AMOUNT     = 0 - WK-NET-TOTAL.
           COMPUTE IH-TAX-AMOUNT = 0 - WK-TAX-TOTAL.
           COMPUTE IH-TOTAL      = 0 - WK-GRS-TOTAL.
           COMPUTE IH-COST-TOTAL = 0 - WK-COST-TOTAL.
           MOVE 1                  TO IH-STATUS.
           MOVE 2                  TO IH-KIND.
           MOVE WK-DCNT            TO IH-LINES.
           MOVE SPACE              TO IH-REMARK.
           IF WK-ORIG-INV NOT = 0
               STRING "Return ref inv " DELIMITED SIZE
                      WK-ORIG-INV       DELIMITED SIZE
                      INTO IH-REMARK
           END-IF.
           MOVE WK-SYSDATE         TO IH-ADD-DATE IH-UPD-DATE.
           MOVE WK-USER-CODE       TO IH-ADD-USER IH-UPD-USER.
           MOVE 0                  TO IH-DEL-FLAG.
           WRITE IH-REC
               INVALID KEY
                   MOVE "Return header write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       WRH-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-RET-DETAILS SECTION.
      *    write each negative line, then put the goods back in stock
       WRD-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-DCNT
               INITIALIZE ID-REC
               MOVE WK-INV-NO          TO ID-NO
               MOVE WK-IDX             TO ID-LINE
               MOVE DR-PROD    (WK-IDX) TO ID-PROD
               MOVE DR-WHSE    (WK-IDX) TO ID-WHSE
               COMPUTE ID-QTY = 0 - DR-QTY (WK-IDX)
               MOVE DR-PRICE   (WK-IDX) TO ID-UNIT-PRICE
               COMPUTE ID-AMOUNT = 0 - DR-AMT (WK-IDX)
               MOVE DR-COST    (WK-IDX) TO ID-UNIT-COST
               COMPUTE ID-COST-AMOUNT = 0 - DR-COSTAMT (WK-IDX)
               MOVE DR-TAXCAT  (WK-IDX) TO ID-TAX-CATEGORY
               MOVE SPACE              TO ID-REMARK
               WRITE ID-REC
                   INVALID KEY
                       CONTINUE
               END-WRITE
               PERFORM INCREASE-STOCK
               PERFORM WRITE-MOVEMENT
           END-PERFORM.
       WRD-999.
           EXIT.
      *----------------------------------------------------------------
       INCREASE-STOCK SECTION.
      *    add the returned quantity back to on-hand (positive)
       IS-010.
           MOVE 0                  TO WK-STK-FOUND.
           MOVE DR-QTY (WK-IDX)    TO WK-LINE-QTY.
           MOVE DR-COST (WK-IDX)   TO WK-LINE-COST.
           IF DR-STKMNG (WK-IDX) = 0
               GO TO IS-999
           END-IF.
           MOVE DR-PROD (WK-IDX)   TO SK-PROD.
           MOVE DR-WHSE (WK-IDX)   TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   PERFORM CREATE-STOCK
                   GO TO IS-999
           END-READ.
           MOVE 1                  TO WK-STK-FOUND.
           ADD WK-LINE-QTY         TO SK-ONHAND.
           ADD WK-LINE-QTY         TO SK-YTD-IN.
           MOVE WK-SYSDATE         TO SK-LAST-IN-DATE.
           MOVE SK-ONHAND          TO WK-NEWBAL.
           REWRITE SK-REC
               INVALID KEY
                   MOVE "Stock update failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
       IS-999.
           EXIT.
      *----------------------------------------------------------------
       CREATE-STOCK SECTION.
       CRS-010.
           INITIALIZE SK-REC.
           MOVE DR-PROD (WK-IDX)   TO SK-PROD.
           MOVE DR-WHSE (WK-IDX)   TO SK-WHSE.
           MOVE WK-LINE-QTY        TO SK-ONHAND.
           MOVE 0                  TO SK-ALLOCATED.
           MOVE 0                  TO SK-ON-ORDER.
           MOVE WK-LINE-COST       TO SK-AVG-COST.
           MOVE WK-SYSDATE         TO SK-LAST-IN-DATE.
           MOVE WK-LINE-QTY        TO SK-YTD-IN.
           MOVE WK-LINE-QTY        TO WK-NEWBAL.
           WRITE SK-REC
               INVALID KEY
                   MOVE "Stock create failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               NOT INVALID KEY
                   MOVE 1          TO WK-STK-FOUND
           END-WRITE.
       CRS-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-MOVEMENT SECTION.
      *    log a return-in movement (kind 50, positive quantity)
       WM-010.
           IF DR-STKMNG (WK-IDX) = 0 OR WK-STK-FOUND = 0
               GO TO WM-999
           END-IF.
           MOVE "STKMOV"           TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Movement number assignment failed"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO WM-999
           END-IF.
           INITIALIZE SM-REC.
           MOVE KNUM-NUMBER        TO SM-SEQ.
           MOVE WK-SYSDATE         TO SM-DATE.
           MOVE DR-PROD (WK-IDX)   TO SM-PROD.
           MOVE DR-WHSE (WK-IDX)   TO SM-WHSE.
           MOVE 50                 TO SM-KIND.
           MOVE WK-LINE-QTY        TO SM-QTY.
           MOVE WK-LINE-COST       TO SM-UNIT-COST.
           MOVE WK-NEWBAL          TO SM-BAL-AFTER.
           MOVE 3                  TO SM-REF-TYPE.
           MOVE WK-INV-NO          TO SM-REF-NO.
           MOVE WK-USER-CODE       TO SM-USER.
           WRITE SM-REC
               INVALID KEY
                   MOVE "Movement write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       WM-999.
           EXIT.
      *----------------------------------------------------------------
       POST-AR-LEDGER SECTION.
      *    AR ledger : kind 3 return, credit = total, running balance
       PAL-010.
           MOVE "ARLDG"            TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "AR ledger number assignment failed"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PAL-999
           END-IF.
           INITIALIZE AL-REC.
           MOVE KNUM-NUMBER        TO AL-SEQ.
           MOVE WK-SEL-CUST        TO AL-CUST.
           MOVE WK-SYSDATE         TO AL-DATE.
           MOVE WK-CLOSE-YM        TO AL-CLOSE-YM.
           MOVE 3                  TO AL-KIND.
           MOVE 3                  TO AL-REF-TYPE.
           MOVE WK-INV-NO          TO AL-REF-NO.
           MOVE 0                  TO AL-DEBIT.
           MOVE WK-GRS-TOTAL       TO AL-CREDIT.
           COMPUTE AL-BALANCE = CU-BALANCE - WK-GRS-TOTAL.
           MOVE "Sales return"     TO AL-REMARK.
           MOVE WK-USER-CODE       TO AL-USER.
           WRITE AL-REC
               INVALID KEY
                   MOVE "AR ledger write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       PAL-999.
           EXIT.
      *----------------------------------------------------------------
       UPDATE-CUST-BALANCE SECTION.
       UCB-010.
           MOVE WK-SEL-CUST        TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   GO TO UCB-999
           END-READ.
           SUBTRACT WK-GRS-TOTAL   FROM CU-BALANCE.
           MOVE WK-SYSDATE         TO CU-UPD-DATE.
           MOVE WK-USER-CODE       TO CU-UPD-USER.
           REWRITE CU-REC
               INVALID KEY
                   MOVE "Customer balance update failed"
                                   TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
       UCB-999.
           EXIT.
      *----------------------------------------------------------------
       CALC-PAGES SECTION.
       CLP-010.
           IF WK-DCNT = 0
               MOVE 1              TO WK-PAGE-CNT
           ELSE
               COMPUTE WK-PAGE-CNT =
                   (WK-DCNT + WK-PGSIZE - 1) / WK-PGSIZE
           END-IF.
       CLP-999.
           EXIT.
      *----------------------------------------------------------------
       BUILD-WINDOW SECTION.
       BW-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1
                   UNTIL WK-IDX > WK-PGSIZE
               COMPUTE WK-IDX2 = WK-PAGE-TOP + WK-IDX - 1
               IF WK-IDX2 <= WK-DCNT AND WK-IDX2 >= 1
                   MOVE DR-PROD    (WK-IDX2) TO WW-PROD    (WK-IDX)
                   MOVE DR-NAME    (WK-IDX2) TO WW-NAME    (WK-IDX)
                   MOVE DR-QTY     (WK-IDX2) TO WW-QTY     (WK-IDX)
                   MOVE DR-PRICE   (WK-IDX2) TO WW-PRICE   (WK-IDX)
                   MOVE DR-AMT     (WK-IDX2) TO WW-AMT     (WK-IDX)
                   MOVE DR-COSTAMT (WK-IDX2) TO WW-COSTAMT (WK-IDX)
               ELSE
                   MOVE ZERO       TO WW-PROD    (WK-IDX)
                   MOVE SPACE      TO WW-NAME    (WK-IDX)
                   MOVE ZERO       TO WW-QTY     (WK-IDX)
                   MOVE ZERO       TO WW-PRICE   (WK-IDX)
                   MOVE ZERO       TO WW-AMT     (WK-IDX)
                   MOVE ZERO       TO WW-COSTAMT (WK-IDX)
               END-IF
           END-PERFORM.
           COMPUTE WK-PAGE-NO =
               (WK-PAGE-TOP + WK-PGSIZE - 1) / WK-PGSIZE.
       BW-999.
           EXIT.
      *----------------------------------------------------------------
       PAINT-RETURN SECTION.
       PRN-010.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           DISPLAY DS-INV.
           DISPLAY DS-TOTAL.
       PRN-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-DOWN SECTION.
       PD-010.
           IF WK-PAGE-TOP + WK-PGSIZE > WK-DCNT
               GO TO PD-999
           END-IF.
           ADD WK-PGSIZE           TO WK-PAGE-TOP.
           PERFORM BUILD-WINDOW.
       PD-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-UP SECTION.
       PU-010.
           IF WK-PAGE-TOP <= 1
               GO TO PU-999
           END-IF.
           IF WK-PAGE-TOP > WK-PGSIZE
               SUBTRACT WK-PGSIZE  FROM WK-PAGE-TOP
           ELSE
               MOVE 1              TO WK-PAGE-TOP
           END-IF.
           PERFORM BUILD-WINDOW.
       PU-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE INVHF INVDF STOKF SMOVF CUSTF ARLF.
           CLOSE PRODF CPRCF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "SL0030"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
