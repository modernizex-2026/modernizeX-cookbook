       IDENTIFICATION DIVISION.
       PROGRAM-ID. SL0040.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : SL0040  -  Sales credit note                     *
      *  FUNCTION : raise a credit note against an original sales     *
      *             invoice.  The source invoice (INVHF / INVDF) is  *
      *             recalled by IH-NO; the operator picks the lines  *
      *             and the quantities to credit (never more than    *
      *             the quantity originally invoiced).  A new invoice *
      *             (INVHF / INVDF, IH-KIND = 2) is created with a    *
      *             fresh number from NUMGEN "INVOICE" and negative   *
      *             quantities / amounts.  The credited goods are     *
      *             returned to stock : SK-ONHAND is increased and a  *
      *             return-in movement (SM-KIND 50, positive qty,     *
      *             NUMGEN "STKMOV") is logged.  The AR ledger        *
      *             receives a credit (AL-KIND 3, AL-CREDIT, running  *
      *             AL-BALANCE, AL-SEQ from NUMGEN "ARLDG") and the   *
      *             customer balance is decreased by the credit       *
      *             total.                                            *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SINVH.
           COPY SINVD.
           COPY SSTOK.
           COPY SSMOV.
           COPY SCUST.
           COPY SPROD.
           COPY SARL.
       I-O-CONTROL.
           APPLY SHARED-MODE ON INVHF
           APPLY SHARED-MODE ON INVDF
           APPLY SHARED-MODE ON STOKF
           APPLY SHARED-MODE ON SMOVF
           APPLY SHARED-MODE ON CUSTF
           APPLY SHARED-MODE ON ARLF.
       DATA DIVISION.
       FILE SECTION.
           COPY FINVH.
           COPY FINVD.
           COPY FSTOK.
           COPY FSMOV.
           COPY FCUST.
           COPY FPROD.
           COPY FARL.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
      *----- control ---------------------------------------------------
       01  WK-CTL.
           02  WK-ORIG-INV         PIC 9(10) VALUE 0.
           02  WK-SEL-CUST         PIC 9(6)  VALUE 0.
           02  WK-INV-NO           PIC 9(10) VALUE 0.
           02  WK-STAFF-IN         PIC 9(4)  VALUE 0.
           02  WK-TAXTYPE-IN       PIC 9(1)  VALUE 0.
           02  WK-PGSIZE           PIC 9(3)  VALUE 10.
           02  WK-PAGE-TOP         PIC 9(3)  VALUE 1.
           02  WK-PAGE-NO          PIC 9(3)  VALUE 0.
           02  WK-PAGE-CNT         PIC 9(3)  VALUE 0.
           02  WK-PICK-END         PIC 9(1)  VALUE 0.
             88  PICK-END                    VALUE 1.
           02  WK-CR-LINES         PIC 9(3)  VALUE 0.
           02  WK-PICK-LINE        PIC 9(3)  VALUE 0.
           02  WK-PICK-QTY         PIC S9(9) VALUE 0.
           02  WK-CLOSE-YM         PIC 9(6)  VALUE 0.
      *----- close-period calc ----------------------------------------
       01  WK-CALC.
           02  WK-YM               PIC 9(6)  VALUE 0.
           02  WK-DAY              PIC 9(2)  VALUE 0.
           02  WK-YYYY             PIC 9(4)  VALUE 0.
           02  WK-MM               PIC 9(2)  VALUE 0.
      *----- header lookup / display ----------------------------------
       01  WK-HDR-DISP.
           02  WK-CUST-NAME        PIC X(40) VALUE SPACE.
           02  WK-D-NAME           PIC X(40) VALUE SPACE.
           02  WK-D-TAXCAT         PIC 9(1)  VALUE 1.
           02  WK-D-STKMNG         PIC 9(1)  VALUE 0.
      *----- totals (positive magnitude) ------------------------------
       01  WK-TOTALS.
           02  WK-NET-TOTAL        PIC S9(13) VALUE 0.
           02  WK-TAX-TOTAL        PIC S9(13) VALUE 0.
           02  WK-GRS-TOTAL        PIC S9(13) VALUE 0.
           02  WK-COST-TOTAL       PIC S9(13) VALUE 0.
      *----- post work ------------------------------------------------
       01  WK-POST.
           02  WK-NEWBAL           PIC S9(9)  VALUE 0.
           02  WK-STK-FOUND        PIC 9(1)   VALUE 0.
           02  WK-LINE-QTY         PIC S9(9)  VALUE 0.
           02  WK-LINE-COST        PIC S9(9)V9(2) VALUE 0.
           02  WK-OUT-LINE         PIC 9(3)   VALUE 0.
      *----- source invoice line buffer -------------------------------
       01  WK-SRC-TABLE.
           02  WK-SCNT             PIC 9(3)  VALUE 0.
           02  WK-SROW OCCURS 200.
             03  SR-LINE           PIC 9(3).
             03  SR-PROD           PIC 9(8).
             03  SR-WHSE           PIC 9(3).
             03  SR-NAME           PIC X(16).
             03  SR-OQTY           PIC S9(9).
             03  SR-CR-QTY         PIC S9(9).
             03  SR-PRICE          PIC S9(9)V9(2).
             03  SR-COST           PIC S9(9)V9(2).
             03  SR-TAXCAT         PIC 9(1).
             03  SR-STKMNG         PIC 9(1).
      *----- browse window --------------------------------------------
       01  WK-WIN.
           02  WW-ROW OCCURS 10.
             03  WW-LINE           PIC ZZ9.
             03  WW-PROD           PIC 9(8).
             03  WW-NAME           PIC X(16).
             03  WW-OQTY           PIC ---,--9.
             03  WW-CQTY           PIC ---,--9.
             03  WW-PRICE          PIC ---,--9.99.
             03  WW-AMT            PIC ----,---,--9.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 5.
             03  COLUMN 2  VALUE "Original Invoice# :" COLOR YELLOW.
             03  COLUMN 22 PIC 9(10) USING WK-ORIG-INV.
       01  DS-INFO.
           02  LINE 3.
             03  COLUMN 2  VALUE "Credit vs Invoice#:" COLOR YELLOW.
             03  COLUMN 22 PIC ZZZZZZZZZ9 FROM WK-ORIG-INV
                              COLOR WHITE.
             03  COLUMN 44 VALUE "CREDIT" REVERSE COLOR RED.
           02  LINE 4.
             03  COLUMN 2  VALUE "Cust :" COLOR YELLOW.
             03  COLUMN 9  PIC 9(6) FROM WK-SEL-CUST COLOR WHITE.
             03  COLUMN 17 PIC X(34) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Tax  :" COLOR YELLOW.
             03  COLUMN 9  PIC 9(1) FROM WK-TAXTYPE-IN COLOR WHITE.
             03  COLUMN 14 VALUE "Staff:" COLOR YELLOW.
             03  COLUMN 21 PIC 9(4) FROM WK-STAFF-IN COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE "Ln" COLOR CYAN.
             03  COLUMN 6  VALUE "Product" COLOR CYAN.
             03  COLUMN 15 VALUE "Name" COLOR CYAN.
             03  COLUMN 33 VALUE "OrigQ" COLOR CYAN.
             03  COLUMN 41 VALUE "CrdQ" COLOR CYAN.
             03  COLUMN 50 VALUE "Price" COLOR CYAN.
             03  COLUMN 61 VALUE "Amount" COLOR CYAN.
       01  DS-LIST.
           02  LINE 7.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (1).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (1).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (1).
             03  COLUMN 32 PIC ---,--9 FROM WW-OQTY (1).
             03  COLUMN 40 PIC ---,--9 FROM WW-CQTY (1).
             03  COLUMN 48 PIC ---,--9.99 FROM WW-PRICE (1).
             03  COLUMN 59 PIC ----,---,--9 FROM WW-AMT (1).
           02  LINE 8.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (2).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (2).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (2).
             03  COLUMN 32 PIC ---,--9 FROM WW-OQTY (2).
             03  COLUMN 40 PIC ---,--9 FROM WW-CQTY (2).
             03  COLUMN 48 PIC ---,--9.99 FROM WW-PRICE (2).
             03  COLUMN 59 PIC ----,---,--9 FROM WW-AMT (2).
           02  LINE 9.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (3).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (3).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (3).
             03  COLUMN 32 PIC ---,--9 FROM WW-OQTY (3).
             03  COLUMN 40 PIC ---,--9 FROM WW-CQTY (3).
             03  COLUMN 48 PIC ---,--9.99 FROM WW-PRICE (3).
             03  COLUMN 59 PIC ----,---,--9 FROM WW-AMT (3).
           02  LINE 10.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (4).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (4).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (4).
             03  COLUMN 32 PIC ---,--9 FROM WW-OQTY (4).
             03  COLUMN 40 PIC ---,--9 FROM WW-CQTY (4).
             03  COLUMN 48 PIC ---,--9.99 FROM WW-PRICE (4).
             03  COLUMN 59 PIC ----,---,--9 FROM WW-AMT (4).
           02  LINE 11.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (5).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (5).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (5).
             03  COLUMN 32 PIC ---,--9 FROM WW-OQTY (5).
             03  COLUMN 40 PIC ---,--9 FROM WW-CQTY (5).
             03  COLUMN 48 PIC ---,--9.99 FROM WW-PRICE (5).
             03  COLUMN 59 PIC ----,---,--9 FROM WW-AMT (5).
           02  LINE 12.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (6).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (6).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (6).
             03  COLUMN 32 PIC ---,--9 FROM WW-OQTY (6).
             03  COLUMN 40 PIC ---,--9 FROM WW-CQTY (6).
             03  COLUMN 48 PIC ---,--9.99 FROM WW-PRICE (6).
             03  COLUMN 59 PIC ----,---,--9 FROM WW-AMT (6).
           02  LINE 13.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (7).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (7).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (7).
             03  COLUMN 32 PIC ---,--9 FROM WW-OQTY (7).
             03  COLUMN 40 PIC ---,--9 FROM WW-CQTY (7).
             03  COLUMN 48 PIC ---,--9.99 FROM WW-PRICE (7).
             03  COLUMN 59 PIC ----,---,--9 FROM WW-AMT (7).
           02  LINE 14.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (8).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (8).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (8).
             03  COLUMN 32 PIC ---,--9 FROM WW-OQTY (8).
             03  COLUMN 40 PIC ---,--9 FROM WW-CQTY (8).
             03  COLUMN 48 PIC ---,--9.99 FROM WW-PRICE (8).
             03  COLUMN 59 PIC ----,---,--9 FROM WW-AMT (8).
           02  LINE 15.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (9).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (9).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (9).
             03  COLUMN 32 PIC ---,--9 FROM WW-OQTY (9).
             03  COLUMN 40 PIC ---,--9 FROM WW-CQTY (9).
             03  COLUMN 48 PIC ---,--9.99 FROM WW-PRICE (9).
             03  COLUMN 59 PIC ----,---,--9 FROM WW-AMT (9).
           02  LINE 16.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (10).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (10).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (10).
             03  COLUMN 32 PIC ---,--9 FROM WW-OQTY (10).
             03  COLUMN 40 PIC ---,--9 FROM WW-CQTY (10).
             03  COLUMN 48 PIC ---,--9.99 FROM WW-PRICE (10).
             03  COLUMN 59 PIC ----,---,--9 FROM WW-AMT (10).
       01  DS-PSTAT.
           02  LINE 17.
             03  COLUMN 2  VALUE "Lines:" COLOR YELLOW.
             03  COLUMN 9  PIC ZZ9 FROM WK-CR-LINES COLOR WHITE.
             03  COLUMN 15 VALUE "Net:" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,---,--9 FROM WK-NET-TOTAL
                              COLOR WHITE.
             03  COLUMN 40 VALUE "Total:" COLOR YELLOW.
             03  COLUMN 47 PIC ---,---,---,--9 FROM WK-GRS-TOTAL
                              COLOR WHITE.
           02  LINE 18.
             03  COLUMN 2  VALUE "New Credit#:" COLOR YELLOW.
             03  COLUMN 15 PIC ZZZZZZZZZ9 FROM WK-INV-NO COLOR WHITE.
             03  COLUMN 40 VALUE "Page:" COLOR YELLOW.
             03  COLUMN 46 PIC ZZ9 FROM WK-PAGE-NO COLOR WHITE.
             03  COLUMN 49 VALUE "/" COLOR WHITE.
             03  COLUMN 50 PIC ZZ9 FROM WK-PAGE-CNT COLOR WHITE.
       01  DS-PICK.
           02  LINE 19.
             03  COLUMN 2  VALUE "Line:" COLOR YELLOW.
             03  COLUMN 8  PIC 9(3) USING WK-PICK-LINE.
             03  COLUMN 13 VALUE "Credit Qty:" COLOR YELLOW.
             03  COLUMN 25 PIC S9(9) USING WK-PICK-QTY.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Post credit note ? (Y/N):"
                              COLOR YELLOW.
           02  SC-CONF LINE 21 COLUMN 28 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "SL0040"           TO WK-PROGID.
           MOVE "Sales Credit Note"                TO WK-TITLE.
           MOVE "ENTER=Read  PF3=End"              TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           PERFORM OPEN-IO-INVH.
           PERFORM OPEN-IO-INVD.
           PERFORM OPEN-IO-STOK.
           PERFORM OPEN-IO-SMOV.
           PERFORM OPEN-IO-CUST.
           PERFORM OPEN-IO-ARL.
           OPEN INPUT PRODF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PRODF
               CLOSE PRODF
               OPEN INPUT PRODF
           END-IF.
       OPENF-999.
           EXIT.
       OPEN-IO-INVH SECTION.
       OIIH-010.
           OPEN I-O INVHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT INVHF
               CLOSE INVHF
               OPEN I-O INVHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "INVHF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIIH-999.
           EXIT.
       OPEN-IO-INVD SECTION.
       OIID-010.
           OPEN I-O INVDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT INVDF
               CLOSE INVDF
               OPEN I-O INVDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "INVDF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIID-999.
           EXIT.
       OPEN-IO-STOK SECTION.
       OIST-010.
           OPEN I-O STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIST-999.
           EXIT.
       OPEN-IO-SMOV SECTION.
       OISM-010.
           OPEN I-O SMOVF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SMOVF
               CLOSE SMOVF
               OPEN I-O SMOVF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SMOVF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OISM-999.
           EXIT.
       OPEN-IO-CUST SECTION.
       OICU-010.
           OPEN I-O CUSTF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT CUSTF
               CLOSE CUSTF
               OPEN I-O CUSTF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "CUSTF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OICU-999.
           EXIT.
       OPEN-IO-ARL SECTION.
       OIAR-010.
           OPEN I-O ARLF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ARLF
               CLOSE ARLF
               OPEN I-O ARLF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ARLF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIAR-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAINR-010.
           PERFORM CLEAR-CREDIT.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter the original invoice number to credit"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-CREDIT
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAINR-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-CREDIT SECTION.
       CLRC-010.
           MOVE 0                  TO WK-ORIG-INV WK-SEL-CUST.
           MOVE 0                  TO WK-INV-NO WK-SCNT WK-CR-LINES.
           MOVE 0                  TO WK-NET-TOTAL WK-TAX-TOTAL.
           MOVE 0                  TO WK-GRS-TOTAL WK-COST-TOTAL.
           MOVE 0                  TO WK-STAFF-IN WK-TAXTYPE-IN.
           MOVE 1                  TO WK-PAGE-TOP.
           MOVE SPACE              TO WK-CUST-NAME WK-CONFIRM.
       CLRC-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-CREDIT SECTION.
       PC-010.
           IF WK-ORIG-INV = 0
               MOVE "Invoice number required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PC-999
           END-IF.
           PERFORM READ-SOURCE-INVOICE.
           IF ERR-YES
               GO TO PC-999
           END-IF.
           PERFORM READ-CUSTOMER.
           IF NOT FOUND-YES
               DISPLAY DS-MSG
               GO TO PC-999
           END-IF.
           PERFORM LOAD-SOURCE-LINES.
           IF WK-SCNT = 0
               MOVE "Source invoice has no lines" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PC-999
           END-IF.
           PERFORM PICK-LOOP.
           PERFORM COMPUTE-TOTALS.
           IF WK-CR-LINES = 0
               MOVE "No quantities picked - credit discarded"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PC-999
           END-IF.
           PERFORM ASK-CONFIRM.
       PC-999.
           EXIT.
      *----------------------------------------------------------------
       READ-SOURCE-INVOICE SECTION.
       RSI-010.
           MOVE 0                  TO ERR-FLG.
           MOVE WK-ORIG-INV        TO IH-NO.
           READ INVHF
               INVALID KEY
                   MOVE "Original invoice not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   DISPLAY DS-MSG
                   GO TO RSI-999
           END-READ.
           IF IH-DEL-FLAG = 1
               MOVE "Original invoice is deleted" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               DISPLAY DS-MSG
               GO TO RSI-999
           END-IF.
           IF IH-KIND NOT = 1
               MOVE "Source is not a sale - cannot credit"
                                   TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               DISPLAY DS-MSG
               GO TO RSI-999
           END-IF.
           IF IH-STATUS = 9
               MOVE "Original invoice is cancelled" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               DISPLAY DS-MSG
               GO TO RSI-999
           END-IF.
           MOVE IH-CUST            TO WK-SEL-CUST.
           MOVE IH-STAFF           TO WK-STAFF-IN.
           MOVE IH-TAX-TYPE        TO WK-TAXTYPE-IN.
       RSI-999.
           EXIT.
      *----------------------------------------------------------------
       READ-CUSTOMER SECTION.
       RC-010.
           MOVE 0                  TO FOUND-FLG.
           MOVE SPACE              TO WK-CUST-NAME.
           MOVE WK-SEL-CUST        TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "Customer of invoice not found" TO WK-MSG-LINE
                   GO TO RC-999
           END-READ.
           MOVE CU-NAME            TO WK-CUST-NAME.
           IF WK-TAXTYPE-IN < 1 OR WK-TAXTYPE-IN > 3
               MOVE CU-TAX-TYPE    TO WK-TAXTYPE-IN
           END-IF.
           SET FOUND-YES TO TRUE.
       RC-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-SOURCE-LINES SECTION.
      *    load the source invoice detail lines into the buffer
       LSL-010.
           MOVE 0                  TO WK-SCNT.
           MOVE WK-ORIG-INV        TO ID-NO.
           MOVE 0                  TO ID-LINE.
           START INVDF KEY IS NOT LESS THAN ID-NO
               INVALID KEY
                   GO TO LSL-999
           END-START.
       LSL-020.
           READ INVDF NEXT
               AT END
                   GO TO LSL-999
           END-READ.
           IF ID-NO NOT = WK-ORIG-INV
               GO TO LSL-999
           END-IF.
           IF WK-SCNT >= 200
               GO TO LSL-999
           END-IF.
           ADD 1                   TO WK-SCNT.
           MOVE ID-LINE            TO SR-LINE  (WK-SCNT).
           MOVE ID-PROD            TO SR-PROD  (WK-SCNT).
           MOVE ID-WHSE            TO SR-WHSE  (WK-SCNT).
           IF ID-QTY < 0
               COMPUTE SR-OQTY (WK-SCNT) = 0 - ID-QTY
           ELSE
               MOVE ID-QTY         TO SR-OQTY  (WK-SCNT)
           END-IF.
           MOVE 0                  TO SR-CR-QTY (WK-SCNT).
           MOVE ID-UNIT-PRICE      TO SR-PRICE (WK-SCNT).
           MOVE ID-UNIT-COST       TO SR-COST  (WK-SCNT).
           MOVE ID-TAX-CATEGORY    TO SR-TAXCAT (WK-SCNT).
           MOVE ID-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "(unknown)" TO SR-NAME (WK-SCNT)
                   MOVE 0           TO SR-STKMNG (WK-SCNT)
               NOT INVALID KEY
                   MOVE PR-NAME     TO SR-NAME (WK-SCNT)
                   MOVE PR-STOCK-MNG TO SR-STKMNG (WK-SCNT)
           END-READ.
           GO TO LSL-020.
       LSL-999.
           EXIT.
      *----------------------------------------------------------------
       PICK-LOOP SECTION.
       PKL-010.
           MOVE 0                  TO WK-PICK-END.
           MOVE 1                  TO WK-PAGE-TOP.
           MOVE "ENTER=Set  PF4=ClrLine  PF6/PF12=Page  PF3=Done"
                                   TO WK-FKEY-LINE.
           PERFORM COUNT-CR.
           PERFORM COMPUTE-TOTALS.
           PERFORM CALC-PAGES.
           PERFORM BUILD-WINDOW.
           MOVE "Pick a line and its credit quantity" TO WK-MSG-LINE.
           PERFORM UNTIL PICK-END OR END-YES
               PERFORM PAINT-PICK
               MOVE 0              TO WK-PICK-LINE WK-PICK-QTY
               DISPLAY DS-PICK
               ACCEPT  DS-PICK
               EVALUATE ESTS
                   WHEN "03"
                       SET PICK-END TO TRUE
                   WHEN "06"
                       PERFORM PAGE-DOWN
                   WHEN "12"
                       PERFORM PAGE-UP
                   WHEN "04"
                       PERFORM CLEAR-PICK-LINE
                   WHEN "00"
                       PERFORM SET-PICK-QTY
                   WHEN OTHER
                       MOVE "Invalid function key" TO WK-MSG-LINE
               END-EVALUATE
               PERFORM COUNT-CR
               PERFORM COMPUTE-TOTALS
               PERFORM BUILD-WINDOW
           END-PERFORM.
           MOVE "ENTER=Read  PF3=End" TO WK-FKEY-LINE.
       PKL-999.
           EXIT.
      *----------------------------------------------------------------
       SET-PICK-QTY SECTION.
       SPQ-010.
           IF WK-PICK-LINE = 0 OR WK-PICK-LINE > WK-SCNT
               MOVE "Enter a valid source line number" TO WK-MSG-LINE
               GO TO SPQ-999
           END-IF.
           MOVE WK-PICK-LINE       TO WK-IDX.
           IF WK-PICK-QTY <= 0
               MOVE "Credit qty must be positive" TO WK-MSG-LINE
               GO TO SPQ-999
           END-IF.
           IF WK-PICK-QTY > SR-OQTY (WK-IDX)
               MOVE "Credit qty exceeds invoiced qty" TO WK-MSG-LINE
               GO TO SPQ-999
           END-IF.
           MOVE WK-PICK-QTY        TO SR-CR-QTY (WK-IDX).
           MOVE "Credit quantity set" TO WK-MSG-LINE.
       SPQ-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-PICK-LINE SECTION.
       CPL-010.
           IF WK-PICK-LINE = 0 OR WK-PICK-LINE > WK-SCNT
               MOVE "Enter a valid source line number" TO WK-MSG-LINE
               GO TO CPL-999
           END-IF.
           MOVE WK-PICK-LINE       TO WK-IDX.
           MOVE 0                  TO SR-CR-QTY (WK-IDX).
           MOVE "Credit quantity cleared" TO WK-MSG-LINE.
       CPL-999.
           EXIT.
      *----------------------------------------------------------------
       COUNT-CR SECTION.
       CCR-010.
           MOVE 0                  TO WK-CR-LINES.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-SCNT
               IF SR-CR-QTY (WK-IDX) > 0
                   ADD 1           TO WK-CR-LINES
               END-IF
           END-PERFORM.
       CCR-999.
           EXIT.
      *----------------------------------------------------------------
       COMPUTE-TOTALS SECTION.
      *    sum the picked lines then compute tax with TAXCAL
       CT-010.
           MOVE 0                  TO WK-NET-TOTAL WK-COST-TOTAL.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-SCNT
               IF SR-CR-QTY (WK-IDX) > 0
                   COMPUTE WK-NET-TOTAL = WK-NET-TOTAL +
                       (SR-CR-QTY (WK-IDX) * SR-PRICE (WK-IDX))
                   COMPUTE WK-COST-TOTAL = WK-COST-TOTAL +
                       (SR-CR-QTY (WK-IDX) * SR-COST (WK-IDX))
               END-IF
           END-PERFORM.
           MOVE 1                  TO KT-CATEGORY.
           MOVE WK-TAXTYPE-IN      TO KT-TAX-TYPE.
           IF KT-TAX-TYPE < 1 OR KT-TAX-TYPE > 3
               MOVE 1              TO KT-TAX-TYPE
           END-IF.
           MOVE CU-TAX-ROUND       TO KT-ROUND.
           IF KT-ROUND = 0
               MOVE 1              TO KT-ROUND
           END-IF.
           MOVE WK-SYSDATE         TO KT-DATE.
           MOVE WK-NET-TOTAL       TO KT-AMOUNT.
           CALL "TAXCAL" USING KTAX.
           MOVE KT-NET             TO WK-NET-TOTAL.
           MOVE KT-TAX             TO WK-TAX-TOTAL.
           MOVE KT-GROSS           TO WK-GRS-TOTAL.
       CT-999.
           EXIT.
      *----------------------------------------------------------------
       ASK-CONFIRM SECTION.
       AC-010.
           MOVE SPACE              TO WK-CONFIRM.
           PERFORM CALC-PAGES.
           PERFORM BUILD-WINDOW.
           PERFORM PAINT-PICK.
           MOVE "Confirm to post the credit note" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               PERFORM POST-CREDIT
           ELSE
               MOVE "Credit note discarded" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       AC-999.
           EXIT.
      *----------------------------------------------------------------
       POST-CREDIT SECTION.
       PST-010.
           MOVE "INVOICE"          TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Credit number assignment failed" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PST-999
           END-IF.
           MOVE KNUM-NUMBER        TO WK-INV-NO.
           PERFORM CALC-CLOSE-YM.
           PERFORM WRITE-CN-HEADER.
           PERFORM WRITE-CN-DETAILS.
           PERFORM POST-AR-LEDGER.
           PERFORM UPDATE-CUST-BALANCE.
           MOVE SPACE              TO WK-MSG-LINE.
           STRING "Credit note "   DELIMITED SIZE
                  WK-INV-NO         DELIMITED SIZE
                  " posted"         DELIMITED SIZE
                  INTO WK-MSG-LINE.
           DISPLAY DS-MSG.
       PST-999.
           EXIT.
      *----------------------------------------------------------------
       CALC-CLOSE-YM SECTION.
      *    period = credit month, rolled past the customer closing day
       CCY-010.
           COMPUTE WK-YM  = WK-SYSDATE / 100.
           COMPUTE WK-DAY = WK-SYSDATE - (WK-YM * 100).
           MOVE WK-YM              TO WK-CLOSE-YM.
           IF CU-CLOSE-DAY > 0 AND CU-CLOSE-DAY < 99
               IF WK-DAY > CU-CLOSE-DAY
                   COMPUTE WK-YYYY = WK-YM / 100
                   COMPUTE WK-MM   = WK-YM - (WK-YYYY * 100)
                   ADD 1           TO WK-MM
                   IF WK-MM > 12
                       MOVE 1      TO WK-MM
                       ADD 1       TO WK-YYYY
                   END-IF
                   COMPUTE WK-CLOSE-YM = (WK-YYYY * 100) + WK-MM
               END-IF
           END-IF.
       CCY-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-CN-HEADER SECTION.
      *    amounts stored negative for a credit note (kind 2)
       WCH-010.
           INITIALIZE IH-REC.
           MOVE WK-INV-NO          TO IH-NO.
           MOVE WK-SYSDATE         TO IH-DATE.
           MOVE WK-SEL-CUST        TO IH-CUST.
           MOVE WK-STAFF-IN        TO IH-STAFF.
           MOVE 0                  TO IH-SHIP-NO.
           MOVE WK-CLOSE-YM        TO IH-CLOSE-YM.
           MOVE WK-TAXTYPE-IN      TO IH-TAX-TYPE.
           COMPUTE IH-AMOUNT     = 0 - WK-NET-TOTAL.
           COMPUTE IH-TAX-AMOUNT = 0 - WK-TAX-TOTAL.
           COMPUTE IH-TOTAL      = 0 - WK-GRS-TOTAL.
           COMPUTE IH-COST-TOTAL = 0 - WK-COST-TOTAL.
           MOVE 1                  TO IH-STATUS.
           MOVE 2                  TO IH-KIND.
           MOVE WK-CR-LINES        TO IH-LINES.
           MOVE SPACE              TO IH-REMARK.
           STRING "Credit vs invoice " DELIMITED SIZE
                  WK-ORIG-INV          DELIMITED SIZE
                  INTO IH-REMARK.
           MOVE WK-SYSDATE         TO IH-ADD-DATE IH-UPD-DATE.
           MOVE WK-USER-CODE       TO IH-ADD-USER IH-UPD-USER.
           MOVE 0                  TO IH-DEL-FLAG.
           WRITE IH-REC
               INVALID KEY
                   MOVE "Credit header write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       WCH-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-CN-DETAILS SECTION.
      *    write a negative line for each picked source line and
      *    return the goods to stock
       WCD-010.
           MOVE 0                  TO WK-OUT-LINE.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-SCNT
               IF SR-CR-QTY (WK-IDX) > 0
                   PERFORM WRITE-ONE-CN-DETAIL
               END-IF
           END-PERFORM.
       WCD-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-ONE-CN-DETAIL SECTION.
       WOC-010.
           ADD 1                   TO WK-OUT-LINE.
           INITIALIZE ID-REC.
           MOVE WK-INV-NO          TO ID-NO.
           MOVE WK-OUT-LINE        TO ID-LINE.
           MOVE SR-PROD  (WK-IDX)  TO ID-PROD.
           MOVE SR-WHSE  (WK-IDX)  TO ID-WHSE.
           COMPUTE ID-QTY = 0 - SR-CR-QTY (WK-IDX).
           MOVE SR-PRICE (WK-IDX)  TO ID-UNIT-PRICE.
           COMPUTE ID-AMOUNT =
               0 - (SR-CR-QTY (WK-IDX) * SR-PRICE (WK-IDX)).
           MOVE SR-COST  (WK-IDX)  TO ID-UNIT-COST.
           COMPUTE ID-COST-AMOUNT =
               0 - (SR-CR-QTY (WK-IDX) * SR-COST (WK-IDX)).
           MOVE SR-TAXCAT (WK-IDX) TO ID-TAX-CATEGORY.
           MOVE SPACE              TO ID-REMARK.
           WRITE ID-REC
               INVALID KEY
                   CONTINUE
           END-WRITE.
           PERFORM INCREASE-STOCK.
           PERFORM WRITE-MOVEMENT.
       WOC-999.
           EXIT.
      *----------------------------------------------------------------
       INCREASE-STOCK SECTION.
      *    add the credited quantity back to on-hand (positive)
       IS-010.
           MOVE 0                  TO WK-STK-FOUND.
           MOVE SR-CR-QTY (WK-IDX) TO WK-LINE-QTY.
           MOVE SR-COST   (WK-IDX) TO WK-LINE-COST.
           IF SR-STKMNG (WK-IDX) = 0
               GO TO IS-999
           END-IF.
           MOVE SR-PROD (WK-IDX)   TO SK-PROD.
           MOVE SR-WHSE (WK-IDX)   TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   PERFORM CREATE-STOCK
                   GO TO IS-999
           END-READ.
           MOVE 1                  TO WK-STK-FOUND.
           ADD WK-LINE-QTY         TO SK-ONHAND.
           ADD WK-LINE-QTY         TO SK-YTD-IN.
           MOVE WK-SYSDATE         TO SK-LAST-IN-DATE.
           MOVE SK-ONHAND          TO WK-NEWBAL.
           REWRITE SK-REC
               INVALID KEY
                   MOVE "Stock update failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
       IS-999.
           EXIT.
      *----------------------------------------------------------------
       CREATE-STOCK SECTION.
       CRS-010.
           INITIALIZE SK-REC.
           MOVE SR-PROD (WK-IDX)   TO SK-PROD.
           MOVE SR-WHSE (WK-IDX)   TO SK-WHSE.
           MOVE WK-LINE-QTY        TO SK-ONHAND.
           MOVE 0                  TO SK-ALLOCATED.
           MOVE 0                  TO SK-ON-ORDER.
           MOVE WK-LINE-COST       TO SK-AVG-COST.
           MOVE WK-SYSDATE         TO SK-LAST-IN-DATE.
           MOVE WK-LINE-QTY        TO SK-YTD-IN.
           MOVE WK-LINE-QTY        TO WK-NEWBAL.
           WRITE SK-REC
               INVALID KEY
                   MOVE "Stock create failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               NOT INVALID KEY
                   MOVE 1          TO WK-STK-FOUND
           END-WRITE.
       CRS-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-MOVEMENT SECTION.
      *    log a return-in movement (kind 50, positive quantity)
       WM-010.
           IF SR-STKMNG (WK-IDX) = 0 OR WK-STK-FOUND = 0
               GO TO WM-999
           END-IF.
           MOVE "STKMOV"           TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Movement number assignment failed"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO WM-999
           END-IF.
           INITIALIZE SM-REC.
           MOVE KNUM-NUMBER        TO SM-SEQ.
           MOVE WK-SYSDATE         TO SM-DATE.
           MOVE SR-PROD (WK-IDX)   TO SM-PROD.
           MOVE SR-WHSE (WK-IDX)   TO SM-WHSE.
           MOVE 50                 TO SM-KIND.
           MOVE WK-LINE-QTY        TO SM-QTY.
           MOVE WK-LINE-COST       TO SM-UNIT-COST.
           MOVE WK-NEWBAL          TO SM-BAL-AFTER.
           MOVE 3                  TO SM-REF-TYPE.
           MOVE WK-INV-NO          TO SM-REF-NO.
           MOVE WK-USER-CODE       TO SM-USER.
           WRITE SM-REC
               INVALID KEY
                   MOVE "Movement write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       WM-999.
           EXIT.
      *----------------------------------------------------------------
       POST-AR-LEDGER SECTION.
      *    AR ledger : kind 3 credit, credit = total, running balance
       PAL-010.
           MOVE "ARLDG"            TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "AR ledger number assignment failed"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PAL-999
           END-IF.
           INITIALIZE AL-REC.
           MOVE KNUM-NUMBER        TO AL-SEQ.
           MOVE WK-SEL-CUST        TO AL-CUST.
           MOVE WK-SYSDATE         TO AL-DATE.
           MOVE WK-CLOSE-YM        TO AL-CLOSE-YM.
           MOVE 3                  TO AL-KIND.
           MOVE 3                  TO AL-REF-TYPE.
           MOVE WK-INV-NO          TO AL-REF-NO.
           MOVE 0                  TO AL-DEBIT.
           MOVE WK-GRS-TOTAL       TO AL-CREDIT.
           COMPUTE AL-BALANCE = CU-BALANCE - WK-GRS-TOTAL.
           MOVE "Sales credit note" TO AL-REMARK.
           MOVE WK-USER-CODE       TO AL-USER.
           WRITE AL-REC
               INVALID KEY
                   MOVE "AR ledger write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       PAL-999.
           EXIT.
      *----------------------------------------------------------------
       UPDATE-CUST-BALANCE SECTION.
       UCB-010.
           MOVE WK-SEL-CUST        TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   GO TO UCB-999
           END-READ.
           SUBTRACT WK-GRS-TOTAL   FROM CU-BALANCE.
           MOVE WK-SYSDATE         TO CU-UPD-DATE.
           MOVE WK-USER-CODE       TO CU-UPD-USER.
           REWRITE CU-REC
               INVALID KEY
                   MOVE "Customer balance update failed"
                                   TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
       UCB-999.
           EXIT.
      *----------------------------------------------------------------
       CALC-PAGES SECTION.
       CLP-010.
           IF WK-SCNT = 0
               MOVE 1              TO WK-PAGE-CNT
           ELSE
               COMPUTE WK-PAGE-CNT =
                   (WK-SCNT + WK-PGSIZE - 1) / WK-PGSIZE
           END-IF.
           IF WK-PAGE-TOP > WK-SCNT
               MOVE 1              TO WK-PAGE-TOP
           END-IF.
       CLP-999.
           EXIT.
      *----------------------------------------------------------------
       BUILD-WINDOW SECTION.
       BLW-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1
                   UNTIL WK-IDX > WK-PGSIZE
               COMPUTE WK-IDX2 = WK-PAGE-TOP + WK-IDX - 1
               IF WK-IDX2 <= WK-SCNT AND WK-IDX2 >= 1
                   MOVE WK-IDX2         TO WW-LINE (WK-IDX)
                   MOVE SR-PROD (WK-IDX2) TO WW-PROD (WK-IDX)
                   MOVE SR-NAME (WK-IDX2) TO WW-NAME (WK-IDX)
                   MOVE SR-OQTY (WK-IDX2) TO WW-OQTY (WK-IDX)
                   MOVE SR-CR-QTY (WK-IDX2) TO WW-CQTY (WK-IDX)
                   MOVE SR-PRICE (WK-IDX2) TO WW-PRICE (WK-IDX)
                   COMPUTE WW-AMT (WK-IDX) =
                       SR-CR-QTY (WK-IDX2) * SR-PRICE (WK-IDX2)
               ELSE
                   MOVE 0          TO WW-LINE (WK-IDX)
                   MOVE 0          TO WW-PROD (WK-IDX)
                   MOVE SPACE      TO WW-NAME (WK-IDX)
                   MOVE 0          TO WW-OQTY (WK-IDX)
                   MOVE 0          TO WW-CQTY (WK-IDX)
                   MOVE 0          TO WW-PRICE (WK-IDX)
                   MOVE 0          TO WW-AMT (WK-IDX)
               END-IF
           END-PERFORM.
           COMPUTE WK-PAGE-NO =
               (WK-PAGE-TOP + WK-PGSIZE - 1) / WK-PGSIZE.
       BLW-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-DOWN SECTION.
       PGD-010.
           IF WK-PAGE-TOP + WK-PGSIZE > WK-SCNT
               MOVE "Last page" TO WK-MSG-LINE
               GO TO PGD-999
           END-IF.
           ADD WK-PGSIZE           TO WK-PAGE-TOP.
           MOVE SPACE              TO WK-MSG-LINE.
       PGD-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-UP SECTION.
       PGU-010.
           IF WK-PAGE-TOP <= 1
               MOVE "First page" TO WK-MSG-LINE
               GO TO PGU-999
           END-IF.
           IF WK-PAGE-TOP > WK-PGSIZE
               SUBTRACT WK-PGSIZE  FROM WK-PAGE-TOP
           ELSE
               MOVE 1              TO WK-PAGE-TOP
           END-IF.
           MOVE SPACE              TO WK-MSG-LINE.
       PGU-999.
           EXIT.
      *----------------------------------------------------------------
       PAINT-PICK SECTION.
       PNT-010.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           DISPLAY DS-INFO.
           DISPLAY DS-LIST.
           DISPLAY DS-PSTAT.
           DISPLAY DS-MSG.
       PNT-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE INVHF INVDF STOKF SMOVF CUSTF ARLF.
           CLOSE PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "SL0040"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
