       IDENTIFICATION DIVISION.
       PROGRAM-ID. INITDB.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : INITDB  -  database initialiser / sample loader   *
      *  FUNCTION : creates every indexed file and loads a starter   *
      *             set of master data plus opening stock so the     *
      *             system can be demonstrated immediately.          *
      *             Run once before first use (console / batch).     *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SSYSC.
           COPY SNUMC.
           COPY STAX.
           COPY SREGN.
           COPY SDEPT.
           COPY SCATG.
           COPY SBANK.
           COPY SWHSE.
           COPY SSTAF.
           COPY SUSER.
           COPY SCUST.
           COPY SSUPP.
           COPY SPROD.
           COPY SCPRC.
           COPY SSTOK.
           COPY SMSG.
           COPY SORDH.
           COPY SORDD.
           COPY SSHPH.
           COPY SSHPD.
           COPY SINVH.
           COPY SINVD.
           COPY SPOH.
           COPY SPOD.
           COPY SRCVH.
           COPY SRCVD.
           COPY SPURH.
           COPY SPURD.
           COPY SARL.
           COPY SAPL.
           COPY SRCPT.
           COPY SPAY.
           COPY SSMOV.
       DATA DIVISION.
       FILE SECTION.
           COPY FSYSC.
           COPY FNUMC.
           COPY FTAX.
           COPY FREGN.
           COPY FDEPT.
           COPY FCATG.
           COPY FBANK.
           COPY FWHSE.
           COPY FSTAF.
           COPY FUSER.
           COPY FCUST.
           COPY FSUPP.
           COPY FPROD.
           COPY FCPRC.
           COPY FSTOK.
           COPY FMSG.
           COPY FORDH.
           COPY FORDD.
           COPY FSHPH.
           COPY FSHPD.
           COPY FINVH.
           COPY FINVD.
           COPY FPOH.
           COPY FPOD.
           COPY FRCVH.
           COPY FRCVD.
           COPY FPURH.
           COPY FPURD.
           COPY FARL.
           COPY FAPL.
           COPY FRCPT.
           COPY FPAY.
           COPY FSMOV.
       WORKING-STORAGE SECTION.
       01  FSTS                    PIC X(2)  VALUE "00".
       01  WK-I                    PIC 9(3)  VALUE 0.
       01  WK-CNT                  PIC 9(5)  VALUE 0.
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           DISPLAY "SAKURA-SMS  INITDB - creating files ...".
           PERFORM CREATE-EMPTY-FILES.
           PERFORM LOAD-SYSTEM.
           PERFORM LOAD-NUMBERS.
           PERFORM LOAD-TAX.
           PERFORM LOAD-REGION.
           PERFORM LOAD-DEPT.
           PERFORM LOAD-CATEGORY.
           PERFORM LOAD-BANK.
           PERFORM LOAD-WAREHOUSE.
           PERFORM LOAD-STAFF.
           PERFORM LOAD-USER.
           PERFORM LOAD-CUSTOMER.
           PERFORM LOAD-SUPPLIER.
           PERFORM LOAD-PRODUCT.
           PERFORM LOAD-CPRICE.
           PERFORM LOAD-STOCK.
           PERFORM LOAD-MESSAGE.
           DISPLAY "SAKURA-SMS  INITDB - complete.".
           STOP RUN.
      *----------------------------------------------------------------
       CREATE-EMPTY-FILES SECTION.
       CEF-010.
      *    transaction files start empty; create then close them
           OPEN OUTPUT ORDHF.  CLOSE ORDHF.
           OPEN OUTPUT ORDDF.  CLOSE ORDDF.
           OPEN OUTPUT SHPHF.  CLOSE SHPHF.
           OPEN OUTPUT SHPDF.  CLOSE SHPDF.
           OPEN OUTPUT INVHF.  CLOSE INVHF.
           OPEN OUTPUT INVDF.  CLOSE INVDF.
           OPEN OUTPUT POHF.   CLOSE POHF.
           OPEN OUTPUT PODF.   CLOSE PODF.
           OPEN OUTPUT RCVHF.  CLOSE RCVHF.
           OPEN OUTPUT RCVDF.  CLOSE RCVDF.
           OPEN OUTPUT PURHF.  CLOSE PURHF.
           OPEN OUTPUT PURDF.  CLOSE PURDF.
           OPEN OUTPUT ARLF.   CLOSE ARLF.
           OPEN OUTPUT APLF.   CLOSE APLF.
           OPEN OUTPUT RCPTF.  CLOSE RCPTF.
           OPEN OUTPUT PAYF.   CLOSE PAYF.
           OPEN OUTPUT SMOVF.  CLOSE SMOVF.
       CEF-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-SYSTEM SECTION.
       LSYS-010.
           OPEN OUTPUT SYSCF.
           INITIALIZE SY-REC.
           MOVE 1                  TO SY-KEY.
           MOVE "SAKURA Trading Co., Ltd."  TO SY-COMPANY-NAME.
           MOVE "100-0001"         TO SY-COMPANY-ZIP.
           MOVE "1-1-1 Chiyoda, Chiyoda-ku, Tokyo"
                                   TO SY-COMPANY-ADDR.
           MOVE "03-1234-5678"     TO SY-COMPANY-TEL.
           MOVE 4                  TO SY-FISCAL-START.
           MOVE 202607             TO SY-CURR-YM.
           MOVE 20260630           TO SY-LAST-DAY-CLOSE.
           MOVE 202606             TO SY-LAST-MON-CLOSE.
           MOVE 0.100              TO SY-TAX-DFLT-RATE.
           MOVE 1                  TO SY-DEC-ROUND.
           WRITE SY-REC INVALID KEY CONTINUE END-WRITE.
           CLOSE SYSCF.
       LSYS-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-NUMBERS SECTION.
       LNUM-010.
           OPEN OUTPUT NUMCF.
           PERFORM WRITE-NUM.
           CLOSE NUMCF.
       LNUM-999.
           EXIT.
      *    (numbers are also auto-created by NUMGEN on first use)
       WRITE-NUM SECTION.
       WNUM-010.
           INITIALIZE NM-REC.
           MOVE "ORDER"            TO NM-KEY.
           MOVE "SO"               TO NM-PREFIX.
           MOVE 10                 TO NM-WIDTH.
           MOVE 0                  TO NM-CURRENT.
           WRITE NM-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE NM-REC.
           MOVE "INVOICE"          TO NM-KEY.
           MOVE "IV"               TO NM-PREFIX.
           MOVE 10                 TO NM-WIDTH.
           MOVE 0                  TO NM-CURRENT.
           WRITE NM-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE NM-REC.
           MOVE "SHIP"             TO NM-KEY.
           MOVE "SH"               TO NM-PREFIX.
           MOVE 10                 TO NM-WIDTH.
           MOVE 0                  TO NM-CURRENT.
           WRITE NM-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE NM-REC.
           MOVE "PO"               TO NM-KEY.
           MOVE "PO"               TO NM-PREFIX.
           MOVE 10                 TO NM-WIDTH.
           MOVE 0                  TO NM-CURRENT.
           WRITE NM-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE NM-REC.
           MOVE "RECV"             TO NM-KEY.
           MOVE "RC"               TO NM-PREFIX.
           MOVE 10                 TO NM-WIDTH.
           MOVE 0                  TO NM-CURRENT.
           WRITE NM-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE NM-REC.
           MOVE "PURCH"            TO NM-KEY.
           MOVE "PU"               TO NM-PREFIX.
           MOVE 10                 TO NM-WIDTH.
           MOVE 0                  TO NM-CURRENT.
           WRITE NM-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE NM-REC.
           MOVE "RECEIPT"          TO NM-KEY.
           MOVE "RE"               TO NM-PREFIX.
           MOVE 10                 TO NM-WIDTH.
           MOVE 0                  TO NM-CURRENT.
           WRITE NM-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE NM-REC.
           MOVE "PAYMENT"          TO NM-KEY.
           MOVE "PY"               TO NM-PREFIX.
           MOVE 10                 TO NM-WIDTH.
           MOVE 0                  TO NM-CURRENT.
           WRITE NM-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE NM-REC.
           MOVE "ARLDG"            TO NM-KEY.
           MOVE "AL"               TO NM-PREFIX.
           MOVE 10                 TO NM-WIDTH.
           MOVE 0                  TO NM-CURRENT.
           WRITE NM-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE NM-REC.
           MOVE "APLDG"            TO NM-KEY.
           MOVE "PL"               TO NM-PREFIX.
           MOVE 10                 TO NM-WIDTH.
           MOVE 0                  TO NM-CURRENT.
           WRITE NM-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE NM-REC.
           MOVE "STKMOV"           TO NM-KEY.
           MOVE "SM"               TO NM-PREFIX.
           MOVE 10                 TO NM-WIDTH.
           MOVE 0                  TO NM-CURRENT.
           WRITE NM-REC INVALID KEY CONTINUE END-WRITE.
       WNUM-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-TAX SECTION.
       LTAX-010.
           OPEN OUTPUT TAXF.
           INITIALIZE TX-REC.
           MOVE 1                  TO TX-CODE.
           MOVE 20191001           TO TX-START-DATE.
           MOVE 0.100              TO TX-RATE.
           MOVE "Standard 10%"     TO TX-NAME.
           WRITE TX-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE TX-REC.
           MOVE 2                  TO TX-CODE.
           MOVE 20191001           TO TX-START-DATE.
           MOVE 0.080              TO TX-RATE.
           MOVE "Reduced 8%"       TO TX-NAME.
           WRITE TX-REC INVALID KEY CONTINUE END-WRITE.
           CLOSE TAXF.
       LTAX-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-REGION SECTION.
       LRGN-010.
           OPEN OUTPUT REGNF.
           PERFORM WRITE-REGION.
           CLOSE REGNF.
       LRGN-999.
           EXIT.
       WRITE-REGION SECTION.
       WRGN-010.
           INITIALIZE RG-REC.
           MOVE 1 TO RG-CODE.  MOVE "Kanto (Tokyo)"  TO RG-NAME.
           WRITE RG-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE RG-REC.
           MOVE 2 TO RG-CODE.  MOVE "Kansai (Osaka)" TO RG-NAME.
           WRITE RG-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE RG-REC.
           MOVE 3 TO RG-CODE.  MOVE "Chubu (Nagoya)" TO RG-NAME.
           WRITE RG-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE RG-REC.
           MOVE 4 TO RG-CODE.  MOVE "Kyushu (Fukuoka)" TO RG-NAME.
           WRITE RG-REC INVALID KEY CONTINUE END-WRITE.
       WRGN-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-DEPT SECTION.
       LDPT-010.
           OPEN OUTPUT DEPTF.
           INITIALIZE DP-REC.
           MOVE 1000 TO DP-CODE.  MOVE "Sales Division" TO DP-NAME.
           WRITE DP-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE DP-REC.
           MOVE 2000 TO DP-CODE.  MOVE "Purchasing"     TO DP-NAME.
           WRITE DP-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE DP-REC.
           MOVE 9000 TO DP-CODE.  MOVE "Administration"  TO DP-NAME.
           WRITE DP-REC INVALID KEY CONTINUE END-WRITE.
           CLOSE DEPTF.
       LDPT-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-CATEGORY SECTION.
       LCAT-010.
           OPEN OUTPUT CATGF.
           INITIALIZE CT-REC.
           MOVE 100 TO CT-CODE.  MOVE "Stationery"      TO CT-NAME.
           MOVE 1 TO CT-LEVEL.
           WRITE CT-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE CT-REC.
           MOVE 200 TO CT-CODE.  MOVE "Office Equipment" TO CT-NAME.
           MOVE 1 TO CT-LEVEL.
           WRITE CT-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE CT-REC.
           MOVE 300 TO CT-CODE.  MOVE "Furniture"       TO CT-NAME.
           MOVE 1 TO CT-LEVEL.
           WRITE CT-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE CT-REC.
           MOVE 400 TO CT-CODE.  MOVE "Consumables"     TO CT-NAME.
           MOVE 1 TO CT-LEVEL.
           WRITE CT-REC INVALID KEY CONTINUE END-WRITE.
           CLOSE CATGF.
       LCAT-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-BANK SECTION.
       LBNK-010.
           OPEN OUTPUT BANKF.
           INITIALIZE BK-REC.
           MOVE 1 TO BK-CODE.  MOVE "MUFG Bank" TO BK-NAME.
           MOVE "Marunouchi" TO BK-BRANCH.
           WRITE BK-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE BK-REC.
           MOVE 2 TO BK-CODE.  MOVE "SMBC" TO BK-NAME.
           MOVE "Otemachi" TO BK-BRANCH.
           WRITE BK-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE BK-REC.
           MOVE 3 TO BK-CODE.  MOVE "Mizuho Bank" TO BK-NAME.
           MOVE "Nihonbashi" TO BK-BRANCH.
           WRITE BK-REC INVALID KEY CONTINUE END-WRITE.
           CLOSE BANKF.
       LBNK-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-WAREHOUSE SECTION.
       LWHS-010.
           OPEN OUTPUT WHSEF.
           INITIALIZE WH-REC.
           MOVE 1 TO WH-CODE.  MOVE "Main Warehouse" TO WH-NAME.
           MOVE 1 TO WH-TYPE.
           MOVE 1001 TO WH-MANAGER.
           WRITE WH-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE WH-REC.
           MOVE 2 TO WH-CODE.  MOVE "East Warehouse" TO WH-NAME.
           MOVE 1 TO WH-TYPE.
           MOVE 1002 TO WH-MANAGER.
           WRITE WH-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE WH-REC.
           MOVE 3 TO WH-CODE.  MOVE "Returns Warehouse" TO WH-NAME.
           MOVE 3 TO WH-TYPE.
           MOVE 1001 TO WH-MANAGER.
           WRITE WH-REC INVALID KEY CONTINUE END-WRITE.
           CLOSE WHSEF.
       LWHS-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-STAFF SECTION.
       LSTF-010.
           OPEN OUTPUT STAFF.
           INITIALIZE SF-REC.
           MOVE 1001 TO SF-CODE.  MOVE "Taro Yamada" TO SF-NAME.
           MOVE 1000 TO SF-DEPT.  MOVE "Manager" TO SF-TITLE.
           WRITE SF-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE SF-REC.
           MOVE 1002 TO SF-CODE.  MOVE "Hanako Suzuki" TO SF-NAME.
           MOVE 1000 TO SF-DEPT.  MOVE "Sales Rep" TO SF-TITLE.
           WRITE SF-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE SF-REC.
           MOVE 1003 TO SF-CODE.  MOVE "Ichiro Tanaka" TO SF-NAME.
           MOVE 1000 TO SF-DEPT.  MOVE "Sales Rep" TO SF-TITLE.
           WRITE SF-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE SF-REC.
           MOVE 2001 TO SF-CODE.  MOVE "Kenji Sato" TO SF-NAME.
           MOVE 2000 TO SF-DEPT.  MOVE "Buyer" TO SF-TITLE.
           WRITE SF-REC INVALID KEY CONTINUE END-WRITE.
           CLOSE STAFF.
       LSTF-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-USER SECTION.
       LUSR-010.
           OPEN OUTPUT USERF.
           INITIALIZE US-REC.
           MOVE 9999 TO US-CODE.  MOVE "admin" TO US-LOGIN.
           MOVE "admin123" TO US-PASSWORD.
           MOVE "Administrator" TO US-NAME.
           MOVE 1 TO US-ROLE.
           MOVE 1 TO US-AUTH-MASTER US-AUTH-ORDER US-AUTH-SALES.
           MOVE 1 TO US-AUTH-PURCH US-AUTH-CLOSE.
           WRITE US-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE US-REC.
           MOVE 1001 TO US-CODE.  MOVE "yamada" TO US-LOGIN.
           MOVE "pass1001" TO US-PASSWORD.
           MOVE "Taro Yamada" TO US-NAME.
           MOVE 2 TO US-ROLE.
           MOVE 1 TO US-AUTH-MASTER US-AUTH-ORDER US-AUTH-SALES.
           MOVE 0 TO US-AUTH-PURCH.  MOVE 1 TO US-AUTH-CLOSE.
           WRITE US-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE US-REC.
           MOVE 1002 TO US-CODE.  MOVE "suzuki" TO US-LOGIN.
           MOVE "pass1002" TO US-PASSWORD.
           MOVE "Hanako Suzuki" TO US-NAME.
           MOVE 3 TO US-ROLE.
           MOVE 1 TO US-AUTH-ORDER US-AUTH-SALES.
           WRITE US-REC INVALID KEY CONTINUE END-WRITE.
           CLOSE USERF.
       LUSR-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-CUSTOMER SECTION.
       LCUS-010.
           OPEN OUTPUT CUSTF.
           PERFORM WRITE-ONE-CUSTOMER.
           CLOSE CUSTF.
       LCUS-999.
           EXIT.
       WRITE-ONE-CUSTOMER SECTION.
       WCUS-010.
           INITIALIZE CU-REC.
           MOVE 100001 TO CU-CODE.
           MOVE "Fuji Office Supplies" TO CU-NAME.
           MOVE "FUJI OFFICE" TO CU-KANA.  MOVE 1 TO CU-REGION.
           MOVE 1002 TO CU-STAFF.  MOVE 20 TO CU-CLOSE-DAY.
           MOVE 2 TO CU-PAY-METHOD.  MOVE 1 TO CU-TAX-TYPE.
           MOVE 1 TO CU-TAX-ROUND.  MOVE 3000000 TO CU-CREDIT-LIMIT.
           MOVE 2 TO CU-PRICE-RANK.  MOVE 1 TO CU-BANK-CODE.
           MOVE 20240401 TO CU-START-DATE.
           WRITE CU-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE CU-REC.
           MOVE 100002 TO CU-CODE.  MOVE "Sakura Stationers" TO CU-NAME.
           MOVE "SAKURA STAT" TO CU-KANA.  MOVE 2 TO CU-REGION.
           MOVE 1003 TO CU-STAFF.  MOVE 99 TO CU-CLOSE-DAY.
           MOVE 3 TO CU-PAY-METHOD.  MOVE 1 TO CU-TAX-TYPE.
           MOVE 1 TO CU-TAX-ROUND.  MOVE 5000000 TO CU-CREDIT-LIMIT.
           MOVE 1 TO CU-PRICE-RANK.  MOVE 2 TO CU-BANK-CODE.
           MOVE 20230601 TO CU-START-DATE.
           WRITE CU-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE CU-REC.
           MOVE 100003 TO CU-CODE.  MOVE "Nagoya Trading" TO CU-NAME.
           MOVE "NAGOYA TRD" TO CU-KANA.  MOVE 3 TO CU-REGION.
           MOVE 1002 TO CU-STAFF.  MOVE 25 TO CU-CLOSE-DAY.
           MOVE 2 TO CU-PAY-METHOD.  MOVE 2 TO CU-TAX-TYPE.
           MOVE 1 TO CU-TAX-ROUND.  MOVE 2000000 TO CU-CREDIT-LIMIT.
           MOVE 3 TO CU-PRICE-RANK.  MOVE 3 TO CU-BANK-CODE.
           MOVE 20250101 TO CU-START-DATE.
           WRITE CU-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE CU-REC.
           MOVE 100004 TO CU-CODE.
           MOVE "Kyushu Distributors" TO CU-NAME.
           MOVE "KYUSHU DIST" TO CU-KANA.  MOVE 4 TO CU-REGION.
           MOVE 1003 TO CU-STAFF.  MOVE 20 TO CU-CLOSE-DAY.
           MOVE 2 TO CU-PAY-METHOD.  MOVE 1 TO CU-TAX-TYPE.
           MOVE 1 TO CU-TAX-ROUND.  MOVE 4000000 TO CU-CREDIT-LIMIT.
           MOVE 2 TO CU-PRICE-RANK.  MOVE 1 TO CU-BANK-CODE.
           MOVE 20240901 TO CU-START-DATE.
           WRITE CU-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE CU-REC.
           MOVE 100005 TO CU-CODE.  MOVE "Tokyo Mega Mart" TO CU-NAME.
           MOVE "TOKYO MEGA" TO CU-KANA.  MOVE 1 TO CU-REGION.
           MOVE 1001 TO CU-STAFF.  MOVE 31 TO CU-CLOSE-DAY.
           MOVE 2 TO CU-PAY-METHOD.  MOVE 1 TO CU-TAX-TYPE.
           MOVE 1 TO CU-TAX-ROUND.  MOVE 9000000 TO CU-CREDIT-LIMIT.
           MOVE 1 TO CU-PRICE-RANK.  MOVE 1 TO CU-BANK-CODE.
           MOVE 20220401 TO CU-START-DATE.
           WRITE CU-REC INVALID KEY CONTINUE END-WRITE.
       WCUS-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-SUPPLIER SECTION.
       LSUP-010.
           OPEN OUTPUT SUPPF.
           INITIALIZE SP-REC.
           MOVE 200001 TO SP-CODE.  MOVE "Kokuyo Supply" TO SP-NAME.
           MOVE 20 TO SP-CLOSE-DAY.  MOVE 2 TO SP-PAY-METHOD.
           MOVE 1 TO SP-TAX-TYPE.
           MOVE 1 TO SP-BANK-CODE.
           WRITE SP-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE SP-REC.
           MOVE 200002 TO SP-CODE.  MOVE "Pilot Wholesale" TO SP-NAME.
           MOVE 99 TO SP-CLOSE-DAY.  MOVE 2 TO SP-PAY-METHOD.
           MOVE 1 TO SP-TAX-TYPE.
           MOVE 2 TO SP-BANK-CODE.
           WRITE SP-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE SP-REC.
           MOVE 200003 TO SP-CODE.  MOVE "Okamura Furniture" TO SP-NAME.
           MOVE 25 TO SP-CLOSE-DAY.  MOVE 3 TO SP-PAY-METHOD.
           MOVE 1 TO SP-TAX-TYPE.
           MOVE 3 TO SP-BANK-CODE.
           WRITE SP-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE SP-REC.
           MOVE 200004 TO SP-CODE.
           MOVE "General Consumables" TO SP-NAME.
           MOVE 20 TO SP-CLOSE-DAY.  MOVE 2 TO SP-PAY-METHOD.
           MOVE 1 TO SP-TAX-TYPE.
           MOVE 1 TO SP-BANK-CODE.
           WRITE SP-REC INVALID KEY CONTINUE END-WRITE.
           CLOSE SUPPF.
       LSUP-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-PRODUCT SECTION.
       LPRD-010.
           OPEN OUTPUT PRODF.
           PERFORM WRITE-PRODUCTS.
           CLOSE PRODF.
       LPRD-999.
           EXIT.
       WRITE-PRODUCTS SECTION.
       WPRD-010.
           INITIALIZE PR-REC.
           MOVE 10000001 TO PR-CODE.
           MOVE "Ballpoint Pen Black" TO PR-NAME.
           MOVE 100 TO PR-CATEGORY.  MOVE "PCS" TO PR-UNIT.
           MOVE 60.00 TO PR-STD-COST.  MOVE 60.00 TO PR-LAST-COST.
           MOVE 120.00 TO PR-LIST-PRICE.
           MOVE 110.00 TO PR-RANK-PRICE (1).
           MOVE 112.00 TO PR-RANK-PRICE (2).
           MOVE 115.00 TO PR-RANK-PRICE (3).
           MOVE 118.00 TO PR-RANK-PRICE (4).
           MOVE 120.00 TO PR-RANK-PRICE (5).
           MOVE 1 TO PR-TAX-CATEGORY.  MOVE 100 TO PR-SAFETY-STOCK.
           MOVE 200 TO PR-REORDER-POINT.  MOVE 500 TO PR-REORDER-QTY.
           MOVE 200001 TO PR-DFLT-SUPP.  MOVE 1 TO PR-DFLT-WHSE.
           MOVE 1 TO PR-STOCK-MNG.
           WRITE PR-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE PR-REC.
           MOVE 10000002 TO PR-CODE.
           MOVE "Notebook A4 100p" TO PR-NAME.
           MOVE 100 TO PR-CATEGORY.  MOVE "PCS" TO PR-UNIT.
           MOVE 130.00 TO PR-STD-COST.  MOVE 130.00 TO PR-LAST-COST.
           MOVE 250.00 TO PR-LIST-PRICE.
           MOVE 230.00 TO PR-RANK-PRICE (1).
           MOVE 235.00 TO PR-RANK-PRICE (2).
           MOVE 240.00 TO PR-RANK-PRICE (3).
           MOVE 245.00 TO PR-RANK-PRICE (4).
           MOVE 250.00 TO PR-RANK-PRICE (5).
           MOVE 1 TO PR-TAX-CATEGORY.  MOVE 80 TO PR-SAFETY-STOCK.
           MOVE 150 TO PR-REORDER-POINT.  MOVE 400 TO PR-REORDER-QTY.
           MOVE 200001 TO PR-DFLT-SUPP.  MOVE 1 TO PR-DFLT-WHSE.
           MOVE 1 TO PR-STOCK-MNG.
           WRITE PR-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE PR-REC.
           MOVE 10000003 TO PR-CODE.
           MOVE "Stapler Heavy Duty" TO PR-NAME.
           MOVE 200 TO PR-CATEGORY.  MOVE "PCS" TO PR-UNIT.
           MOVE 480.00 TO PR-STD-COST.  MOVE 480.00 TO PR-LAST-COST.
           MOVE 900.00 TO PR-LIST-PRICE.
           MOVE 850.00 TO PR-RANK-PRICE (1).
           MOVE 860.00 TO PR-RANK-PRICE (2).
           MOVE 870.00 TO PR-RANK-PRICE (3).
           MOVE 885.00 TO PR-RANK-PRICE (4).
           MOVE 900.00 TO PR-RANK-PRICE (5).
           MOVE 1 TO PR-TAX-CATEGORY.  MOVE 30 TO PR-SAFETY-STOCK.
           MOVE 60 TO PR-REORDER-POINT.  MOVE 120 TO PR-REORDER-QTY.
           MOVE 200001 TO PR-DFLT-SUPP.  MOVE 1 TO PR-DFLT-WHSE.
           MOVE 1 TO PR-STOCK-MNG.
           WRITE PR-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE PR-REC.
           MOVE 10000004 TO PR-CODE.
           MOVE "Office Chair Mesh" TO PR-NAME.
           MOVE 300 TO PR-CATEGORY.  MOVE "PCS" TO PR-UNIT.
           MOVE 8000.00 TO PR-STD-COST.  MOVE 8000.00 TO PR-LAST-COST.
           MOVE 15800.00 TO PR-LIST-PRICE.
           MOVE 14800.00 TO PR-RANK-PRICE (1).
           MOVE 15000.00 TO PR-RANK-PRICE (2).
           MOVE 15200.00 TO PR-RANK-PRICE (3).
           MOVE 15500.00 TO PR-RANK-PRICE (4).
           MOVE 15800.00 TO PR-RANK-PRICE (5).
           MOVE 1 TO PR-TAX-CATEGORY.  MOVE 10 TO PR-SAFETY-STOCK.
           MOVE 20 TO PR-REORDER-POINT.  MOVE 40 TO PR-REORDER-QTY.
           MOVE 200003 TO PR-DFLT-SUPP.  MOVE 1 TO PR-DFLT-WHSE.
           MOVE 1 TO PR-STOCK-MNG.
           WRITE PR-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE PR-REC.
           MOVE 10000005 TO PR-CODE.
           MOVE "Copy Paper A4 500" TO PR-NAME.
           MOVE 400 TO PR-CATEGORY.  MOVE "REAM" TO PR-UNIT.
           MOVE 320.00 TO PR-STD-COST.  MOVE 320.00 TO PR-LAST-COST.
           MOVE 550.00 TO PR-LIST-PRICE.
           MOVE 500.00 TO PR-RANK-PRICE (1).
           MOVE 510.00 TO PR-RANK-PRICE (2).
           MOVE 520.00 TO PR-RANK-PRICE (3).
           MOVE 535.00 TO PR-RANK-PRICE (4).
           MOVE 550.00 TO PR-RANK-PRICE (5).
           MOVE 1 TO PR-TAX-CATEGORY.  MOVE 200 TO PR-SAFETY-STOCK.
           MOVE 400 TO PR-REORDER-POINT.  MOVE 1000 TO PR-REORDER-QTY.
           MOVE 200004 TO PR-DFLT-SUPP.  MOVE 1 TO PR-DFLT-WHSE.
           MOVE 1 TO PR-STOCK-MNG.
           WRITE PR-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE PR-REC.
           MOVE 10000006 TO PR-CODE.
           MOVE "Whiteboard Marker" TO PR-NAME.
           MOVE 100 TO PR-CATEGORY.  MOVE "PCS" TO PR-UNIT.
           MOVE 70.00 TO PR-STD-COST.  MOVE 70.00 TO PR-LAST-COST.
           MOVE 150.00 TO PR-LIST-PRICE.
           MOVE 140.00 TO PR-RANK-PRICE (1).
           MOVE 142.00 TO PR-RANK-PRICE (2).
           MOVE 145.00 TO PR-RANK-PRICE (3).
           MOVE 148.00 TO PR-RANK-PRICE (4).
           MOVE 150.00 TO PR-RANK-PRICE (5).
           MOVE 1 TO PR-TAX-CATEGORY.  MOVE 120 TO PR-SAFETY-STOCK.
           MOVE 250 TO PR-REORDER-POINT.  MOVE 500 TO PR-REORDER-QTY.
           MOVE 200001 TO PR-DFLT-SUPP.  MOVE 1 TO PR-DFLT-WHSE.
           MOVE 1 TO PR-STOCK-MNG.
           WRITE PR-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE PR-REC.
           MOVE 10000007 TO PR-CODE.  MOVE "Desk Organizer" TO PR-NAME.
           MOVE 200 TO PR-CATEGORY.  MOVE "PCS" TO PR-UNIT.
           MOVE 600.00 TO PR-STD-COST.  MOVE 600.00 TO PR-LAST-COST.
           MOVE 1200.00 TO PR-LIST-PRICE.
           MOVE 1100.00 TO PR-RANK-PRICE (1).
           MOVE 1120.00 TO PR-RANK-PRICE (2).
           MOVE 1150.00 TO PR-RANK-PRICE (3).
           MOVE 1180.00 TO PR-RANK-PRICE (4).
           MOVE 1200.00 TO PR-RANK-PRICE (5).
           MOVE 1 TO PR-TAX-CATEGORY.  MOVE 40 TO PR-SAFETY-STOCK.
           MOVE 80 TO PR-REORDER-POINT.  MOVE 160 TO PR-REORDER-QTY.
           MOVE 200003 TO PR-DFLT-SUPP.  MOVE 1 TO PR-DFLT-WHSE.
           MOVE 1 TO PR-STOCK-MNG.
           WRITE PR-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE PR-REC.
           MOVE 10000008 TO PR-CODE.
           MOVE "Filing Cabinet 3D" TO PR-NAME.
           MOVE 300 TO PR-CATEGORY.  MOVE "PCS" TO PR-UNIT.
           MOVE 12000.00 TO PR-STD-COST.  MOVE 12000.00 TO PR-LAST-COST.
           MOVE 23000.00 TO PR-LIST-PRICE.
           MOVE 21500.00 TO PR-RANK-PRICE (1).
           MOVE 21800.00 TO PR-RANK-PRICE (2).
           MOVE 22200.00 TO PR-RANK-PRICE (3).
           MOVE 22600.00 TO PR-RANK-PRICE (4).
           MOVE 23000.00 TO PR-RANK-PRICE (5).
           MOVE 1 TO PR-TAX-CATEGORY.  MOVE 8 TO PR-SAFETY-STOCK.
           MOVE 15 TO PR-REORDER-POINT.  MOVE 30 TO PR-REORDER-QTY.
           MOVE 200003 TO PR-DFLT-SUPP.  MOVE 1 TO PR-DFLT-WHSE.
           MOVE 1 TO PR-STOCK-MNG.
           WRITE PR-REC INVALID KEY CONTINUE END-WRITE.
       WPRD-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-CPRICE SECTION.
       LCPR-010.
           OPEN OUTPUT CPRCF.
           INITIALIZE CP-REC.
           MOVE 100005 TO CP-CUST.  MOVE 10000005 TO CP-PROD.
           MOVE 480.00 TO CP-PRICE.  MOVE 20250101 TO CP-START-DATE.
           MOVE 20251231 TO CP-END-DATE.
           WRITE CP-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE CP-REC.
           MOVE 100002 TO CP-CUST.  MOVE 10000001 TO CP-PROD.
           MOVE 105.00 TO CP-PRICE.  MOVE 20250101 TO CP-START-DATE.
           MOVE 0 TO CP-END-DATE.
           WRITE CP-REC INVALID KEY CONTINUE END-WRITE.
           CLOSE CPRCF.
       LCPR-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-STOCK SECTION.
       LSTK-010.
           OPEN OUTPUT STOKF.
           PERFORM VARYING WK-I FROM 1 BY 1 UNTIL WK-I > 8
               INITIALIZE SK-REC
               COMPUTE SK-PROD = 10000000 + WK-I
               MOVE 1              TO SK-WHSE
               COMPUTE SK-ONHAND  = 1000 - WK-I * 50
               MOVE 0              TO SK-ALLOCATED
               MOVE 0              TO SK-ON-ORDER
               MOVE "A-01"         TO SK-LOCATION
               WRITE SK-REC
                   INVALID KEY CONTINUE
               END-WRITE
           END-PERFORM.
           CLOSE STOKF.
       LSTK-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-MESSAGE SECTION.
       LMSG-010.
           OPEN OUTPUT MSGF.
           INITIALIZE MG-REC.
           MOVE "I0001" TO MG-CODE.
           MOVE "Processing completed" TO MG-TEXT.
           WRITE MG-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE MG-REC.
           MOVE "E0001" TO MG-CODE.  MOVE "Record not found" TO MG-TEXT.
           WRITE MG-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE MG-REC.
           MOVE "E0002" TO MG-CODE.  MOVE "Duplicate key" TO MG-TEXT.
           WRITE MG-REC INVALID KEY CONTINUE END-WRITE.
           INITIALIZE MG-REC.
           MOVE "W0001" TO MG-CODE.  MOVE "Stock shortage" TO MG-TEXT.
           WRITE MG-REC INVALID KEY CONTINUE END-WRITE.
           CLOSE MSGF.
       LMSG-999.
           EXIT.
