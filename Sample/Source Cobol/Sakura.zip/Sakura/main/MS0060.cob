       IDENTIFICATION DIVISION.
       PROGRAM-ID. MS0060.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : MS0060  -  Category master maintenance           *
      *  FUNCTION : add / change / delete / inquire category master. *
      *             Enter a category code; if it exists the record   *
      *             is shown for change or delete, otherwise a new   *
      *             record is entered.  The parent category is a     *
      *             self-reference into the same file; when non-zero *
      *             it is validated (and must not be itself) and its *
      *             name displayed.  The record area is saved and    *
      *             restored around the parent read.                 *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SCATG.
       I-O-CONTROL.
           APPLY SHARED-MODE ON CATGF.
       DATA DIVISION.
       FILE SECTION.
           COPY FCATG.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-LOOKUP.
           02  WK-PARENT-NAME     PIC X(30) VALUE SPACE.
       01  WK-SAVE-CODE           PIC 9(4)  VALUE 0.
       01  WK-SAVE-CTREC          PIC X(60) VALUE SPACE.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4 COLUMN 2  VALUE "Category Code :" COLOR YELLOW.
           02  SC-KEY LINE 4 COLUMN 20 PIC 9(4) USING CT-CODE.
       01  DS-BODY.
           02  LINE 6.
             03  COLUMN 2  VALUE "Name          :" COLOR YELLOW.
             03  COLUMN 20 PIC X(30) USING CT-NAME.
           02  LINE 7.
             03  COLUMN 2  VALUE "Parent Code   :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(4)  USING CT-PARENT.
             03  COLUMN 26 PIC X(30) FROM WK-PARENT-NAME COLOR WHITE.
           02  LINE 8.
             03  COLUMN 2  VALUE "Level         :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING CT-LEVEL.
             03  COLUMN 24 VALUE "0=root  1-9 depth" COLOR CYAN.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Confirm (Y/N) :" COLOR YELLOW.
           02  SC-CONF LINE 21 COLUMN 20 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "MS0060"           TO WK-PROGID.
           MOVE "Category Master Maintenance"    TO WK-TITLE.
           MOVE "ENTER=Read  PF9=Delete  PF3=End" TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           OPEN I-O    CATGF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT CATGF
               CLOSE CATGF
               OPEN I-O CATGF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "CATGF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-RTN-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE SPACE              TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-KEY
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-RTN-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLEAR-010.
           INITIALIZE CT-REC.
           MOVE SPACE              TO WK-PARENT-NAME.
           MOVE SPACE              TO WK-CONFIRM.
       CLEAR-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-KEY SECTION.
       PKEY-010.
           IF CT-CODE = 0
               MOVE "Category code must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
           MOVE CT-CODE            TO WK-SAVE-CODE.
           READ CATGF
               INVALID KEY
                   PERFORM SETUP-ADD
               NOT INVALID KEY
                   PERFORM SETUP-CHANGE
           END-READ.
           PERFORM EDIT-RECORD.
       PKEY-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-ADD SECTION.
       SADD-010.
           SET MODE-ADD TO TRUE.
           INITIALIZE CT-REC.
           MOVE WK-SAVE-CODE       TO CT-CODE.
           MOVE 1                  TO CT-LEVEL.
           MOVE "New category - enter details" TO WK-MSG-LINE.
       SADD-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-CHANGE SECTION.
       SCHG-010.
           IF CT-DEL-FLAG = 1
               SET MODE-ADD TO TRUE
               MOVE "Deleted category - re-registering" TO WK-MSG-LINE
           ELSE
               SET MODE-CHG TO TRUE
               MOVE "Existing category - change or PF9 delete"
                                   TO WK-MSG-LINE
           END-IF.
           PERFORM LOOKUP-NAMES.
       SCHG-999.
           EXIT.
      *----------------------------------------------------------------
       EDIT-RECORD SECTION.
       EDIT-010.
           DISPLAY DS-MSG.
           DISPLAY DS-BODY.
           ACCEPT  DS-BODY.
           EVALUATE ESTS
               WHEN "03"
                   CONTINUE
               WHEN "04"
                   MOVE "Cancelled" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               WHEN "09"
                   IF MODE-CHG
                       PERFORM DELETE-RECORD
                   ELSE
                       MOVE "Nothing to delete" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   END-IF
               WHEN "00"
                   PERFORM VALIDATE-BODY
                   IF NOT ERR-YES
                       PERFORM SAVE-RECORD
                   END-IF
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       EDIT-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-BODY SECTION.
       VAL-010.
           MOVE 0                  TO ERR-FLG.
           IF CT-NAME = SPACE
               MOVE "Name is required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           PERFORM CHK-PARENT.
       VAL-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
      *  CHK-PARENT : validate the self-referencing parent category.
      *  The edited CT-REC is saved before, and restored after, the
      *  parent read so the read does not clobber it.
      *----------------------------------------------------------------
       CHK-PARENT SECTION.
       CHKP-010.
           IF CT-PARENT = 0
               GO TO CHKP-999
           END-IF.
           IF CT-PARENT = CT-CODE
               MOVE "Parent cannot be itself" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO CHKP-999
           END-IF.
           MOVE CT-REC             TO WK-SAVE-CTREC.
           MOVE CT-PARENT          TO CT-CODE.
           READ CATGF
               INVALID KEY
                   MOVE "Parent category not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
               NOT INVALID KEY
                   IF CT-DEL-FLAG = 1
                       MOVE "Parent category is deleted"
                                   TO WK-MSG-LINE
                       SET ERR-YES TO TRUE
                   ELSE
                       MOVE CT-NAME TO WK-PARENT-NAME
                   END-IF
           END-READ.
           MOVE WK-SAVE-CTREC      TO CT-REC.
       CHKP-999.
           EXIT.
      *----------------------------------------------------------------
       SAVE-RECORD SECTION.
       SAVE-010.
           MOVE 0                  TO CT-DEL-FLAG.
           IF MODE-ADD
               WRITE CT-REC
                   INVALID KEY
                       MOVE "Write failed - duplicate" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Category added" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-WRITE
           ELSE
               REWRITE CT-REC
                   INVALID KEY
                       MOVE "Update failed" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Category updated" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-REWRITE
           END-IF.
       SAVE-999.
           EXIT.
      *----------------------------------------------------------------
       DELETE-RECORD SECTION.
       DEL-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Press Y then ENTER to delete" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               MOVE 1              TO CT-DEL-FLAG
               REWRITE CT-REC
                   INVALID KEY
                       MOVE "Delete failed" TO WK-MSG-LINE
                   NOT INVALID KEY
                       MOVE "Category deleted" TO WK-MSG-LINE
               END-REWRITE
           ELSE
               MOVE "Delete cancelled" TO WK-MSG-LINE
           END-IF.
           DISPLAY DS-MSG.
       DEL-999.
           EXIT.
      *----------------------------------------------------------------
      *  LOOKUP-NAMES : fetch the parent category name for display.
      *  Uses the same save / restore technique as CHK-PARENT.
      *----------------------------------------------------------------
       LOOKUP-NAMES SECTION.
       LOOK-010.
           MOVE SPACE              TO WK-PARENT-NAME.
           IF CT-PARENT = 0
               GO TO LOOK-999
           END-IF.
           MOVE CT-REC             TO WK-SAVE-CTREC.
           MOVE CT-PARENT          TO CT-CODE.
           READ CATGF
               INVALID KEY
                   MOVE "??? unknown parent" TO WK-PARENT-NAME
               NOT INVALID KEY
                   MOVE CT-NAME    TO WK-PARENT-NAME
           END-READ.
           MOVE WK-SAVE-CTREC      TO CT-REC.
       LOOK-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE CATGF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "MS0060"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
