       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0050.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0050  -  Sales summary by product              *
      *  FUNCTION : aggregate invoice detail (INVDF) quantity and    *
      *             amount by product for a sales-date range.  The   *
      *             date filter is taken from the parent invoice     *
      *             header (INVHF).  Results collected in a work     *
      *             table, sorted by product code, product name      *
      *             resolved from PRODF, with a grand total.         *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SINVH.
           COPY SINVD.
           COPY SPROD.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FINVH.
           COPY FINVD.
           COPY FPROD.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0050.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
           02  WK-DTL-EOF          PIC 9(1)  VALUE 0.
             88  DTL-EOF                     VALUE 1.
           02  WK-FOUND            PIC 9(1)  VALUE 0.
             88  IS-FOUND                    VALUE 1.
       01  WK-PARM.
           02  WK-IN-FROM          PIC X(8)  VALUE SPACE.
           02  WK-IN-TO            PIC X(8)  VALUE SPACE.
           02  WK-DATE-FROM        PIC 9(8)  VALUE 0.
           02  WK-DATE-TO          PIC 9(8)  VALUE 99999999.
       01  WK-SUBS.
           02  WK-SI               PIC 9(5)  VALUE 0.
           02  WK-SJ               PIC 9(5)  VALUE 0.
           02  WK-SMIN             PIC 9(5)  VALUE 0.
       01  WK-PN                   PIC 9(5)  VALUE 0.
       01  WK-PTAB.
           02  WK-PENT OCCURS 2000.
             03  WK-P-CODE         PIC 9(8).
             03  WK-P-QTY          PIC S9(13) COMP-3.
             03  WK-P-AMT          PIC S9(15) COMP-3.
       01  WK-TMP-ENT.
           02  WK-T-CODE           PIC 9(8).
           02  WK-T-QTY            PIC S9(13) COMP-3.
           02  WK-T-AMT            PIC S9(15) COMP-3.
       01  WK-TOTALS.
           02  WK-G-QTY            PIC S9(13) COMP-3 VALUE 0.
           02  WK-G-AMT            PIC S9(15) COMP-3 VALUE 0.
       01  WK-PROD-NAME            PIC X(40) VALUE SPACE.
       01  WK-COMPANY              PIC X(40) VALUE SPACE.
       01  RPT-RULE               PIC X(120) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RH-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(8)  VALUE "PRODUCT".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(40) VALUE "PRODUCT NAME".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(16) VALUE "        QUANTITY".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(19) VALUE "             AMOUNT".
       01  RD-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RP-CODE            PIC 9(8).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RP-NAME            PIC X(40).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RP-QTY             PIC ----,---,---,--9.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RP-AMT             PIC ---,---,---,---,--9.
       01  RT-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(51) VALUE "GRAND TOTAL".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RT-QTY             PIC ----,---,---,--9.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RT-AMT             PIC ---,---,---,---,--9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PARM-RTN.
           PERFORM ACCUM-RTN.
           PERFORM SORT-TAB.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0050"           TO WK-PROGID.
           MOVE "SALES SUMMARY BY PRODUCT"      TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT INVHF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "INVHF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT INVDF.
           OPEN INPUT PRODF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PARM-RTN SECTION.
       PARM-010.
           DISPLAY "RP0050 - Sales summary by product".
           DISPLAY "From sales date YYYYMMDD (blank=earliest): ".
           ACCEPT  WK-IN-FROM FROM CONSOLE.
           DISPLAY "To   sales date YYYYMMDD (blank=latest  ): ".
           ACCEPT  WK-IN-TO   FROM CONSOLE.
           IF WK-IN-FROM NUMERIC AND WK-IN-FROM NOT = SPACE
               MOVE WK-IN-FROM     TO WK-DATE-FROM
           ELSE
               MOVE 0              TO WK-DATE-FROM
           END-IF.
           IF WK-IN-TO NUMERIC AND WK-IN-TO NOT = SPACE
               MOVE WK-IN-TO       TO WK-DATE-TO
           ELSE
               MOVE 99999999       TO WK-DATE-TO
           END-IF.
       PARM-999.
           EXIT.
      *----------------------------------------------------------------
       ACCUM-RTN SECTION.
       AC-010.
           MOVE 0                  TO WK-PN.
           IF NOT MAIN-EOF
               MOVE 0              TO IH-NO
               START INVHF KEY NOT < IH-NO
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-HDR UNTIL MAIN-EOF.
       AC-999.
           EXIT.
      *----------------------------------------------------------------
       READ-HDR SECTION.
       RH-010.
           READ INVHF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   PERFORM CHECK-HDR
           END-READ.
       RH-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-HDR SECTION.
       CH-010.
           IF IH-DEL-FLAG = 1 OR IH-STATUS = 9
               GO TO CH-999
           END-IF.
           IF IH-DATE < WK-DATE-FROM OR IH-DATE > WK-DATE-TO
               GO TO CH-999
           END-IF.
           PERFORM SCAN-DETAILS.
       CH-999.
           EXIT.
      *----------------------------------------------------------------
       SCAN-DETAILS SECTION.
       SD-010.
           MOVE 0                  TO WK-DTL-EOF.
           MOVE IH-NO              TO ID-NO.
           MOVE 0                  TO ID-LINE.
           START INVDF KEY NOT < ID-NO
               INVALID KEY
                   MOVE 1          TO WK-DTL-EOF
           END-START.
           PERFORM READ-DTL UNTIL DTL-EOF.
       SD-999.
           EXIT.
      *----------------------------------------------------------------
       READ-DTL SECTION.
       RD-010.
           READ INVDF NEXT
               AT END
                   MOVE 1          TO WK-DTL-EOF
               NOT AT END
                   IF ID-NO NOT = IH-NO
                       MOVE 1      TO WK-DTL-EOF
                   ELSE
                       PERFORM ADD-DETAIL
                   END-IF
           END-READ.
       RD-999.
           EXIT.
      *----------------------------------------------------------------
       ADD-DETAIL SECTION.
       AD-010.
           MOVE 0                  TO WK-FOUND.
           PERFORM VARYING WK-SI FROM 1 BY 1
               UNTIL WK-SI > WK-PN OR IS-FOUND
               IF WK-P-CODE(WK-SI) = ID-PROD
                   SET IS-FOUND TO TRUE
                   ADD ID-QTY    TO WK-P-QTY(WK-SI)
                   ADD ID-AMOUNT TO WK-P-AMT(WK-SI)
               END-IF
           END-PERFORM.
           IF NOT IS-FOUND
               IF WK-PN < 2000
                   ADD 1           TO WK-PN
                   MOVE ID-PROD    TO WK-P-CODE(WK-PN)
                   MOVE ID-QTY     TO WK-P-QTY(WK-PN)
                   MOVE ID-AMOUNT  TO WK-P-AMT(WK-PN)
               END-IF
           END-IF.
       AD-999.
           EXIT.
      *----------------------------------------------------------------
       SORT-TAB SECTION.
       ST-010.
           IF WK-PN < 2
               GO TO ST-999
           END-IF.
           PERFORM VARYING WK-SI FROM 1 BY 1 UNTIL WK-SI >= WK-PN
               MOVE WK-SI          TO WK-SMIN
               COMPUTE WK-SJ = WK-SI + 1
               PERFORM UNTIL WK-SJ > WK-PN
                   IF WK-P-CODE(WK-SJ) < WK-P-CODE(WK-SMIN)
                       MOVE WK-SJ  TO WK-SMIN
                   END-IF
                   ADD 1           TO WK-SJ
               END-PERFORM
               IF WK-SMIN NOT = WK-SI
                   MOVE WK-PENT(WK-SI)   TO WK-TMP-ENT
                   MOVE WK-PENT(WK-SMIN) TO WK-PENT(WK-SI)
                   MOVE WK-TMP-ENT       TO WK-PENT(WK-SMIN)
               END-IF
           END-PERFORM.
       ST-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PR-010.
           MOVE 99                 TO WK-LINE.
           IF WK-PN = 0
               PERFORM PAGE-HEAD
               MOVE "*** NO SALES IN THE SELECTED PERIOD ***"
                                   TO REP-REC
               WRITE REP-REC
               GO TO PR-999
           END-IF.
           PERFORM VARYING WK-SI FROM 1 BY 1 UNTIL WK-SI > WK-PN
               PERFORM PRINT-ONE
           END-PERFORM.
           PERFORM PRINT-GRAND.
       PR-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-ONE SECTION.
       P1-010.
           PERFORM CHECK-PAGE.
           MOVE SPACE              TO WK-PROD-NAME.
           MOVE WK-P-CODE(WK-SI)   TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "(unknown)" TO WK-PROD-NAME
               NOT INVALID KEY
                   MOVE PR-NAME     TO WK-PROD-NAME
           END-READ.
           MOVE WK-P-CODE(WK-SI)   TO RP-CODE.
           MOVE WK-PROD-NAME       TO RP-NAME.
           MOVE WK-P-QTY(WK-SI)    TO RP-QTY.
           MOVE WK-P-AMT(WK-SI)    TO RP-AMT.
           MOVE RD-LINE            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           ADD WK-P-QTY(WK-SI)     TO WK-G-QTY.
           ADD WK-P-AMT(WK-SI)     TO WK-G-AMT.
       P1-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           STRING "PERIOD " WK-DATE-FROM " - " WK-DATE-TO
               DELIMITED BY SIZE INTO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE RH-LINE            TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE 6                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-GRAND SECTION.
       PG-010.
           PERFORM CHECK-PAGE.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-G-QTY           TO RT-QTY.
           MOVE WK-G-AMT           TO RT-AMT.
           MOVE RT-LINE            TO REP-REC.
           WRITE REP-REC.
       PG-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE INVHF INVDF PRODF REPF.
           DISPLAY "RP0050 complete.  Products = " WK-PN.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0050"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
