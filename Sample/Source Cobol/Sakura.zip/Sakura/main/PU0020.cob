       IDENTIFICATION DIVISION.
       PROGRAM-ID. PU0020.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : PU0020  -  Purchase order inquiry                *
      *  FUNCTION : read-only browse of purchase orders.  A PO can   *
      *             be recalled directly by its number, or the file  *
      *             can be walked by supplier (+ optional from-date) *
      *             using the PH-SUPP/PH-DATE alternate key.  The    *
      *             header is shown with the supplier name and each  *
      *             PODF line is listed with its ordered and         *
      *             received quantities.  No file is updated.        *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SPOH.
           COPY SPOD.
           COPY SSUPP.
           COPY SPROD.
       DATA DIVISION.
       FILE SECTION.
           COPY FPOH.
           COPY FPOD.
           COPY FSUPP.
           COPY FPROD.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
      *----- search key entered by the operator ------------------------
       01  WK-SEARCH.
           02  WK-SRCH-NO          PIC 9(10) VALUE 0.
           02  WK-SRCH-SUPP        PIC 9(6)  VALUE 0.
           02  WK-SRCH-DATE        PIC 9(8)  VALUE 0.
      *----- browse control --------------------------------------------
       01  WK-CTRL.
           02  WK-MODE             PIC 9(1)  VALUE 0.
             88  MODE-BY-NO                  VALUE 1.
             88  MODE-BY-SUPP                VALUE 2.
           02  WK-VIEW-DONE        PIC 9(1)  VALUE 0.
           02  WK-NAV              PIC X(1)  VALUE SPACE.
           02  WK-ROW-CNT          PIC 9(3)  VALUE 0.
           02  WK-MORE-FLG         PIC 9(1)  VALUE 0.
      *----- header display work ---------------------------------------
       01  WK-DISP.
           02  WK-SUPP-NAME        PIC X(40) VALUE SPACE.
           02  WK-STAT-TEXT        PIC X(12) VALUE SPACE.
      *----- saved header (for restore when browse hits the end) -------
       01  WK-SAVE-REC             PIC X(150) VALUE SPACE.
      *----- one formatted detail row ----------------------------------
       01  WK-ROW-BUF.
           02  RB-LINE             PIC ZZ9.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  RB-PROD             PIC 9(8).
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  RB-NAME             PIC X(16).
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  RB-QTY              PIC ---,---,--9.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  RB-RECV             PIC ---,---,--9.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  RB-AMT              PIC ---,---,---,--9.
      *----- detail row table shown on screen (9 rows) -----------------
       01  WK-RTAB.
           02  WR-ROW OCCURS 9.
             03  WR-BUF            PIC X(69).
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-SEARCH.
           02  LINE 4.
             03  COLUMN 2  VALUE "PO Number   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(10) USING WK-SRCH-NO.
           02  LINE 6 COLUMN 2 VALUE "--- or search by supplier ---"
                              COLOR CYAN.
           02  LINE 7.
             03  COLUMN 2  VALUE "Supplier    :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(6) USING WK-SRCH-SUPP.
           02  LINE 8.
             03  COLUMN 2  VALUE "From Date   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING WK-SRCH-DATE.
       01  DS-HDRVIEW.
           02  LINE 3.
             03  COLUMN 2  VALUE "PO No     :" COLOR YELLOW.
             03  COLUMN 14 PIC ZZZZZZZZZ9 FROM PH-NO COLOR WHITE.
             03  COLUMN 40 VALUE "Status:" COLOR YELLOW.
             03  COLUMN 48 PIC X(12) FROM WK-STAT-TEXT COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "Date      :" COLOR YELLOW.
             03  COLUMN 14 PIC 9999B99B99 FROM PH-DATE COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Supplier  :" COLOR YELLOW.
             03  COLUMN 14 PIC 9(6) FROM PH-SUPP COLOR WHITE.
             03  COLUMN 22 PIC X(40) FROM WK-SUPP-NAME COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE "Warehouse :" COLOR YELLOW.
             03  COLUMN 14 PIC 9(3) FROM PH-WHSE COLOR WHITE.
           02  LINE 7.
             03  COLUMN 2  VALUE "Buyer     :" COLOR YELLOW.
             03  COLUMN 14 PIC 9(4) FROM PH-STAFF COLOR WHITE.
           02  LINE 8.
             03  COLUMN 2  VALUE "Due Date  :" COLOR YELLOW.
             03  COLUMN 14 PIC 9999B99B99 FROM PH-DUE-DATE COLOR WHITE.
           02  LINE 9.
             03  COLUMN 2  VALUE "Net :" COLOR YELLOW.
             03  COLUMN 8  PIC ---,---,---,--9 FROM PH-AMOUNT
                              COLOR WHITE.
             03  COLUMN 28 VALUE "Tax :" COLOR YELLOW.
             03  COLUMN 34 PIC ---,---,---,--9 FROM PH-TAX-AMOUNT
                              COLOR WHITE.
             03  COLUMN 54 VALUE "Tot :" COLOR YELLOW.
             03  COLUMN 60 PIC ---,---,---,--9 FROM PH-TOTAL
                              COLOR WHITE.
       01  DS-COLHDR.
           02  LINE 11 COLUMN 2 VALUE
               "Ln  Product  Name              Ordered   Received"
               COLOR CYAN.
       01  DS-ROWS.
           02  LINE 12 COLUMN 2 PIC X(69) FROM WR-BUF (1) COLOR WHITE.
           02  LINE 13 COLUMN 2 PIC X(69) FROM WR-BUF (2) COLOR WHITE.
           02  LINE 14 COLUMN 2 PIC X(69) FROM WR-BUF (3) COLOR WHITE.
           02  LINE 15 COLUMN 2 PIC X(69) FROM WR-BUF (4) COLOR WHITE.
           02  LINE 16 COLUMN 2 PIC X(69) FROM WR-BUF (5) COLOR WHITE.
           02  LINE 17 COLUMN 2 PIC X(69) FROM WR-BUF (6) COLOR WHITE.
           02  LINE 18 COLUMN 2 PIC X(69) FROM WR-BUF (7) COLOR WHITE.
           02  LINE 19 COLUMN 2 PIC X(69) FROM WR-BUF (8) COLOR WHITE.
           02  LINE 20 COLUMN 2 PIC X(69) FROM WR-BUF (9) COLOR WHITE.
       01  DS-NAV.
           02  LINE 21 COLUMN 2 VALUE "PF6=Next  PF3=Back :"
               COLOR CYAN.
           02  LINE 21 COLUMN 24 PIC X(1) USING WK-NAV.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "PU0020"           TO WK-PROGID.
           MOVE "Purchase Order Inquiry"           TO WK-TITLE.
           MOVE "ENTER=Search  PF3=End" TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           OPEN INPUT POHF.
           IF FSTS NOT = "00"
               MOVE "POHF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT PODF.
           IF FSTS NOT = "00"
               MOVE "PODF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT SUPPF.
           OPEN INPUT PRODF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-010.
           PERFORM CLEAR-SEARCH.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter a PO number, or a supplier to browse"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-SEARCH.
           ACCEPT  DS-SEARCH.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM DO-SEARCH
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-SEARCH SECTION.
       CLRS-010.
           MOVE 0                  TO WK-SRCH-NO.
           MOVE 0                  TO WK-SRCH-SUPP.
           MOVE 0                  TO WK-SRCH-DATE.
           MOVE 0                  TO WK-MODE.
       CLRS-999.
           EXIT.
      *----------------------------------------------------------------
       DO-SEARCH SECTION.
       DSR-010.
           IF WK-SRCH-NO NOT = 0
               SET MODE-BY-NO TO TRUE
               MOVE WK-SRCH-NO     TO PH-NO
               READ POHF
                   INVALID KEY
                       MOVE "PO number not found" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       PERFORM VIEW-LOOP
               END-READ
               GO TO DSR-999
           END-IF.
           IF WK-SRCH-SUPP NOT = 0
               SET MODE-BY-SUPP TO TRUE
               PERFORM SEARCH-BY-SUPP
               GO TO DSR-999
           END-IF.
           MOVE "Enter a PO number or a supplier code" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       DSR-999.
           EXIT.
      *----------------------------------------------------------------
       SEARCH-BY-SUPP SECTION.
       SBS-010.
           MOVE WK-SRCH-SUPP       TO PH-SUPP.
           MOVE WK-SRCH-DATE       TO PH-DATE.
           START POHF KEY IS NOT < PH-SUPP
               INVALID KEY
                   MOVE "No PO found for supplier" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO SBS-999
           END-START.
           PERFORM READ-NEXT-SUPP.
           IF FOUND-YES
               PERFORM VIEW-LOOP
           ELSE
               MOVE "No PO found for supplier" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       SBS-999.
           EXIT.
      *----------------------------------------------------------------
      *  Advance to the next PO for the requested supplier that also
      *  satisfies the optional from-date filter.  Sets FOUND-YES.
      *----------------------------------------------------------------
       READ-NEXT-SUPP SECTION.
       RNS-010.
           MOVE 0                  TO FOUND-FLG.
           MOVE 0                  TO EOF-FLG.
           PERFORM UNTIL FOUND-YES OR EOF-YES
               READ POHF NEXT
                   AT END
                       SET EOF-YES TO TRUE
                   NOT AT END
                       IF PH-SUPP NOT = WK-SRCH-SUPP
                           SET EOF-YES TO TRUE
                       ELSE
                           IF WK-SRCH-DATE = 0
                               SET FOUND-YES TO TRUE
                           ELSE
                               IF PH-DATE >= WK-SRCH-DATE
                                   SET FOUND-YES TO TRUE
                               END-IF
                           END-IF
                       END-IF
               END-READ
           END-PERFORM.
       RNS-999.
           EXIT.
      *----------------------------------------------------------------
      *  Display current PO and let the operator page forward.
      *----------------------------------------------------------------
       VIEW-LOOP SECTION.
       VL-010.
           MOVE 0                  TO WK-VIEW-DONE.
           PERFORM UNTIL WK-VIEW-DONE = 1
               PERFORM SHOW-CURRENT
               ACCEPT DS-NAV
               EVALUATE ESTS
                   WHEN "03"
                       MOVE 1 TO WK-VIEW-DONE
                   WHEN "06"
                       PERFORM PAGE-NEXT
                   WHEN OTHER
                       MOVE "PF6=Next  PF3=Back" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-EVALUATE
           END-PERFORM.
       VL-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-NEXT SECTION.
       PGN-010.
           IF MODE-BY-NO
               MOVE "Single PO - PF3 to go back" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PGN-999
           END-IF.
           MOVE PH-REC             TO WK-SAVE-REC.
           PERFORM READ-NEXT-SUPP.
           IF NOT FOUND-YES
               MOVE WK-SAVE-REC    TO PH-REC
               MOVE "No more POs for this supplier" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       PGN-999.
           EXIT.
      *----------------------------------------------------------------
       SHOW-CURRENT SECTION.
       SC-010.
           PERFORM LOOKUP-SUPP-NAME.
           PERFORM SET-STATUS-TEXT.
           PERFORM LOAD-LINES.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           DISPLAY DS-HDRVIEW.
           DISPLAY DS-COLHDR.
           DISPLAY DS-ROWS.
           IF WK-MORE-FLG = 1
               MOVE "More lines exist - only first 9 shown"
                                   TO WK-MSG-LINE
           ELSE
               MOVE SPACE          TO WK-MSG-LINE
           END-IF.
           DISPLAY DS-MSG.
       SC-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-SUPP-NAME SECTION.
       LSN-010.
           MOVE SPACE              TO WK-SUPP-NAME.
           MOVE PH-SUPP            TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE "??? unknown supplier" TO WK-SUPP-NAME
               NOT INVALID KEY
                   MOVE SP-NAME    TO WK-SUPP-NAME
           END-READ.
       LSN-999.
           EXIT.
      *----------------------------------------------------------------
       SET-STATUS-TEXT SECTION.
       SST-010.
           EVALUATE PH-STATUS
               WHEN 0 MOVE "Entered"    TO WK-STAT-TEXT
               WHEN 1 MOVE "Part-recv"  TO WK-STAT-TEXT
               WHEN 2 MOVE "Received"   TO WK-STAT-TEXT
               WHEN 3 MOVE "Invoiced"   TO WK-STAT-TEXT
               WHEN 9 MOVE "Cancelled"  TO WK-STAT-TEXT
               WHEN OTHER MOVE "?"      TO WK-STAT-TEXT
           END-EVALUATE.
       SST-999.
           EXIT.
      *----------------------------------------------------------------
      *  Read up to 9 detail lines for the current PO and format them.
      *----------------------------------------------------------------
       LOAD-LINES SECTION.
       LL-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > 9
               MOVE SPACE          TO WR-BUF (WK-IDX)
           END-PERFORM.
           MOVE 0                  TO WK-ROW-CNT.
           MOVE 0                  TO WK-MORE-FLG.
           MOVE PH-NO              TO PD-NO.
           MOVE 0                  TO PD-LINE.
           START PODF KEY IS NOT < PD-NO
               INVALID KEY
                   GO TO LL-999
           END-START.
           MOVE 0                  TO EOF-FLG.
           PERFORM UNTIL EOF-YES
               READ PODF NEXT
                   AT END
                       SET EOF-YES TO TRUE
                   NOT AT END
                       IF PD-NO NOT = PH-NO
                           SET EOF-YES TO TRUE
                       ELSE
                           IF WK-ROW-CNT >= 9
                               MOVE 1 TO WK-MORE-FLG
                               SET EOF-YES TO TRUE
                           ELSE
                               PERFORM FORMAT-ROW
                           END-IF
                       END-IF
               END-READ
           END-PERFORM.
       LL-999.
           EXIT.
      *----------------------------------------------------------------
       FORMAT-ROW SECTION.
       FR-010.
           MOVE SPACE              TO RB-NAME.
           MOVE PD-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "??? unknown"  TO RB-NAME
               NOT INVALID KEY
                   MOVE PR-NAME    TO RB-NAME
           END-READ.
           MOVE PD-LINE            TO RB-LINE.
           MOVE PD-PROD            TO RB-PROD.
           MOVE PD-QTY             TO RB-QTY.
           MOVE PD-RECV-QTY        TO RB-RECV.
           MOVE PD-AMOUNT          TO RB-AMT.
           ADD  1                  TO WK-ROW-CNT.
           MOVE WK-ROW-BUF         TO WR-BUF (WK-ROW-CNT).
       FR-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE POHF PODF SUPPF PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "PU0020"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
