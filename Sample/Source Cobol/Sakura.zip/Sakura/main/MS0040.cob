       IDENTIFICATION DIVISION.
       PROGRAM-ID. MS0040.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : MS0040  -  Warehouse master maintenance          *
      *  FUNCTION : add / change / delete / inquire warehouse master.*
      *             Enter a warehouse code; if it exists the record  *
      *             is shown for change or delete, otherwise a new   *
      *             record is entered.  The manager (staff) code is  *
      *             validated against the staff master and its name  *
      *             displayed.                                       *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SWHSE.
           COPY SSTAF.
       I-O-CONTROL.
           APPLY SHARED-MODE ON WHSEF.
       DATA DIVISION.
       FILE SECTION.
           COPY FWHSE.
           COPY FSTAF.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-LOOKUP.
           02  WK-MGR-NAME        PIC X(30) VALUE SPACE.
       01  WK-SAVE-CODE           PIC 9(3)  VALUE 0.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4 COLUMN 2  VALUE "Warehouse Code:" COLOR YELLOW.
           02  SC-KEY LINE 4 COLUMN 20 PIC 9(3) USING WH-CODE.
       01  DS-BODY.
           02  LINE 6.
             03  COLUMN 2  VALUE "Name          :" COLOR YELLOW.
             03  COLUMN 20 PIC X(30) USING WH-NAME.
           02  LINE 7.
             03  COLUMN 2  VALUE "Post Code     :" COLOR YELLOW.
             03  COLUMN 20 PIC X(8)  USING WH-ZIP.
           02  LINE 8.
             03  COLUMN 2  VALUE "Address       :" COLOR YELLOW.
             03  COLUMN 20 PIC X(40) USING WH-ADDR.
           02  LINE 9.
             03  COLUMN 2  VALUE "Telephone     :" COLOR YELLOW.
             03  COLUMN 20 PIC X(15) USING WH-TEL.
           02  LINE 10.
             03  COLUMN 2  VALUE "Type          :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING WH-TYPE.
             03  COLUMN 24 VALUE "1:normal 2:transit 3:defect"
                 COLOR CYAN.
           02  LINE 11.
             03  COLUMN 2  VALUE "Manager       :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(4)  USING WH-MANAGER.
             03  COLUMN 26 PIC X(30) FROM WK-MGR-NAME COLOR WHITE.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Confirm (Y/N) :" COLOR YELLOW.
           02  SC-CONF LINE 21 COLUMN 20 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "MS0040"           TO WK-PROGID.
           MOVE "Warehouse Master Maintenance"   TO WK-TITLE.
           MOVE "ENTER=Read  PF9=Delete  PF3=End" TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           OPEN I-O    WHSEF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT WHSEF
               CLOSE WHSEF
               OPEN I-O WHSEF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "WHSEF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT  STAFF.
           IF FSTS NOT = "00"
               MOVE "STAFF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-RTN-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE SPACE              TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-KEY
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-RTN-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLEAR-010.
           INITIALIZE WH-REC.
           MOVE SPACE              TO WK-MGR-NAME.
           MOVE SPACE              TO WK-CONFIRM.
       CLEAR-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-KEY SECTION.
       PKEY-010.
           IF WH-CODE = 0
               MOVE "Warehouse code must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
           MOVE WH-CODE            TO WK-SAVE-CODE.
           READ WHSEF
               INVALID KEY
                   PERFORM SETUP-ADD
               NOT INVALID KEY
                   PERFORM SETUP-CHANGE
           END-READ.
           PERFORM EDIT-RECORD.
       PKEY-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-ADD SECTION.
       SADD-010.
           SET MODE-ADD TO TRUE.
           INITIALIZE WH-REC.
           MOVE WK-SAVE-CODE       TO WH-CODE.
           MOVE 1                  TO WH-TYPE.
           MOVE "New warehouse - enter details" TO WK-MSG-LINE.
       SADD-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-CHANGE SECTION.
       SCHG-010.
           IF WH-DEL-FLAG = 1
               SET MODE-ADD TO TRUE
               MOVE "Deleted warehouse - re-registering" TO WK-MSG-LINE
           ELSE
               SET MODE-CHG TO TRUE
               MOVE "Existing warehouse - change or PF9 delete"
                                   TO WK-MSG-LINE
           END-IF.
           PERFORM LOOKUP-NAMES.
       SCHG-999.
           EXIT.
      *----------------------------------------------------------------
       EDIT-RECORD SECTION.
       EDIT-010.
           DISPLAY DS-MSG.
           DISPLAY DS-BODY.
           ACCEPT  DS-BODY.
           EVALUATE ESTS
               WHEN "03"
                   CONTINUE
               WHEN "04"
                   MOVE "Cancelled" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               WHEN "09"
                   IF MODE-CHG
                       PERFORM DELETE-RECORD
                   ELSE
                       MOVE "Nothing to delete" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   END-IF
               WHEN "00"
                   PERFORM VALIDATE-BODY
                   IF NOT ERR-YES
                       PERFORM SAVE-RECORD
                   END-IF
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       EDIT-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-BODY SECTION.
       VAL-010.
           MOVE 0                  TO ERR-FLG.
           IF WH-NAME = SPACE
               MOVE "Name is required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF WH-TYPE < 1 OR WH-TYPE > 3
               MOVE "Type must be 1-3" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF WH-MANAGER NOT = 0
               MOVE WH-MANAGER     TO SF-CODE
               READ STAFF
                   INVALID KEY
                       MOVE "Manager code not found" TO WK-MSG-LINE
                       SET ERR-YES TO TRUE
                       GO TO VAL-999
                   NOT INVALID KEY
                       MOVE SF-NAME TO WK-MGR-NAME
               END-READ
           END-IF.
       VAL-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       SAVE-RECORD SECTION.
       SAVE-010.
           MOVE 0                  TO WH-DEL-FLAG.
           IF MODE-ADD
               WRITE WH-REC
                   INVALID KEY
                       MOVE "Write failed - duplicate" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Warehouse added" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-WRITE
           ELSE
               REWRITE WH-REC
                   INVALID KEY
                       MOVE "Update failed" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Warehouse updated" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-REWRITE
           END-IF.
       SAVE-999.
           EXIT.
      *----------------------------------------------------------------
       DELETE-RECORD SECTION.
       DEL-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Press Y then ENTER to delete" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               MOVE 1              TO WH-DEL-FLAG
               REWRITE WH-REC
                   INVALID KEY
                       MOVE "Delete failed" TO WK-MSG-LINE
                   NOT INVALID KEY
                       MOVE "Warehouse deleted" TO WK-MSG-LINE
               END-REWRITE
           ELSE
               MOVE "Delete cancelled" TO WK-MSG-LINE
           END-IF.
           DISPLAY DS-MSG.
       DEL-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-NAMES SECTION.
       LOOK-010.
           MOVE SPACE              TO WK-MGR-NAME.
           IF WH-MANAGER NOT = 0
               MOVE WH-MANAGER     TO SF-CODE
               READ STAFF
                   INVALID KEY
                       MOVE "??? unknown manager" TO WK-MGR-NAME
                   NOT INVALID KEY
                       MOVE SF-NAME TO WK-MGR-NAME
               END-READ
           END-IF.
       LOOK-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE WHSEF STAFF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "MS0040"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
