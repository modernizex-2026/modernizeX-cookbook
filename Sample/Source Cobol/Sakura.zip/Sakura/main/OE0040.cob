       IDENTIFICATION DIVISION.
       PROGRAM-ID. OE0040.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : OE0040  -  Sales order maintenance               *
      *  FUNCTION : recall an existing sales order (ORDHF) by number *
      *             and maintain it while it has not yet shipped     *
      *             (OH-STATUS 0 entered or 1 allocated).  The       *
      *             operator may change header fields, add / change  *
      *             / delete detail lines (ORDDF) and cancel the     *
      *             whole order (OH-STATUS = 9).  When the quantity  *
      *             of an allocated line changes, the committed       *
      *             stock (STOKF SK-ALLOCATED) and OD-ALLOC-QTY are  *
      *             adjusted by the delta.  On save the header       *
      *             amount / tax (TAXCAL) / total / line count are   *
      *             recomputed.  Changes are refused once the order  *
      *             has shipped, been invoiced or is cancelled.  A   *
      *             credit-limit check (CREDIT) warns the operator   *
      *             when the revised total would exceed the limit.   *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SORDH.
           COPY SORDD.
           COPY SSTOK.
           COPY SCUST.
           COPY SPROD.
       I-O-CONTROL.
           APPLY SHARED-MODE ON ORDHF
           APPLY SHARED-MODE ON ORDDF
           APPLY SHARED-MODE ON STOKF.
       DATA DIVISION.
       FILE SECTION.
           COPY FORDH.
           COPY FORDD.
           COPY FSTOK.
           COPY FCUST.
           COPY FPROD.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
      *----- control ---------------------------------------------------
       01  WK-CTL.
           02  WK-SEL-ORD          PIC 9(10) VALUE 0.
           02  WK-CMD              PIC X(1)  VALUE SPACE.
           02  WK-CMD-ARG          PIC 9(3)  VALUE 0.
           02  WK-NEXT-LINE        PIC 9(3)  VALUE 1.
           02  WK-ORIG-TOTAL       PIC S9(13) VALUE 0.
           02  WK-PGSIZE           PIC 9(3)  VALUE 10.
           02  WK-PAGE-TOP         PIC 9(3)  VALUE 1.
           02  WK-PAGE-NO          PIC 9(3)  VALUE 0.
           02  WK-PAGE-CNT         PIC 9(3)  VALUE 0.
           02  WK-MAINT-END        PIC 9(1)  VALUE 0.
             88  MAINT-END                   VALUE 1.
           02  WK-CANCEL-FLG       PIC 9(1)  VALUE 0.
           02  WK-ALLOCATED        PIC 9(1)  VALUE 0.
           02  WK-DIRTY            PIC 9(1)  VALUE 0.
      *----- allocation-adjust work -----------------------------------
       01  WK-AP.
           02  WK-AP-PROD          PIC 9(8)  VALUE 0.
           02  WK-AP-WHSE          PIC 9(3)  VALUE 0.
           02  WK-AP-DELTA         PIC S9(9) VALUE 0.
           02  WK-AP-TARGET        PIC S9(9) VALUE 0.
      *----- header lookup / display ----------------------------------
       01  WK-HDR-DISP.
           02  WK-CUST-NAME        PIC X(40) VALUE SPACE.
           02  WK-STAT-TXT         PIC X(10) VALUE SPACE.
      *----- detail entry work (add / change) -------------------------
       01  WK-DET.
           02  WK-D-PROD           PIC 9(8)  VALUE 0.
           02  WK-D-WHSE           PIC 9(3)  VALUE 0.
           02  WK-D-QTY            PIC S9(9) VALUE 0.
           02  WK-D-PRICE          PIC S9(9)V9(2) VALUE 0.
           02  WK-D-AMT            PIC S9(11) VALUE 0.
           02  WK-D-NAME           PIC X(40) VALUE SPACE.
           02  WK-D-TAXCAT         PIC 9(1)  VALUE 1.
           02  WK-D-STKMNG         PIC 9(1)  VALUE 0.
           02  WK-D-AVAIL          PIC S9(9) VALUE 0.
      *----- totals ----------------------------------------------------
       01  WK-TOTALS.
           02  WK-NET-TOTAL        PIC S9(13) VALUE 0.
           02  WK-TAX-TOTAL        PIC S9(13) VALUE 0.
           02  WK-GRS-TOTAL        PIC S9(13) VALUE 0.
      *----- live detail buffer ---------------------------------------
       01  WK-DTL-TABLE.
           02  WK-DCNT             PIC 9(3)  VALUE 0.
           02  WK-DROW OCCURS 200.
             03  DR-LINE           PIC 9(3).
             03  DR-PROD           PIC 9(8).
             03  DR-WHSE           PIC 9(3).
             03  DR-NAME           PIC X(16).
             03  DR-QTY            PIC S9(9).
             03  DR-PRICE          PIC S9(9)V9(2).
             03  DR-AMT            PIC S9(11).
             03  DR-TAXCAT         PIC 9(1).
             03  DR-ALLOC          PIC S9(9).
             03  DR-STKMNG         PIC 9(1).
             03  DR-STATUS         PIC 9(1).
             03  DR-NEW            PIC 9(1).
      *----- deferred delete list -------------------------------------
       01  WK-DEL-TABLE.
           02  WK-DELCNT           PIC 9(3)  VALUE 0.
           02  WK-DELROW OCCURS 200.
             03  DL-LINE           PIC 9(3).
             03  DL-PROD           PIC 9(8).
             03  DL-WHSE           PIC 9(3).
             03  DL-ALLOC          PIC S9(9).
             03  DL-STKMNG         PIC 9(1).
      *----- browse window --------------------------------------------
       01  WK-WIN.
           02  WW-ROW OCCURS 10.
             03  WW-LINE           PIC ZZ9.
             03  WW-PROD           PIC 9(8).
             03  WW-NAME           PIC X(16).
             03  WW-QTY            PIC ---,--9.
             03  WW-PRICE          PIC ---,--9.99.
             03  WW-AMT            PIC ----,---,--9.
             03  WW-ALLOC          PIC ---,--9.
           COPY KLINK.
      *----- CREDIT sub linkage (inline) ------------------------------
       01  KCRED.
           02  KC-CUST             PIC 9(6)  VALUE 0.
           02  KC-AMOUNT           PIC S9(11) COMP-3 VALUE 0.
           02  KC-LIMIT            PIC S9(11) COMP-3 VALUE 0.
           02  KC-BALANCE          PIC S9(11) COMP-3 VALUE 0.
           02  KC-NEWBAL           PIC S9(11) COMP-3 VALUE 0.
           02  KC-EXCEED           PIC 9(1)  VALUE 0.
           02  KC-STATUS           PIC X(2)  VALUE "00".
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4.
             03  COLUMN 2  VALUE "Order Number :" COLOR YELLOW.
             03  COLUMN 18 PIC 9(10) USING WK-SEL-ORD.
       01  DS-INFO.
           02  LINE 3.
             03  COLUMN 2  VALUE "Order#:" COLOR YELLOW.
             03  COLUMN 10 PIC ZZZZZZZZZ9 FROM OH-NO COLOR WHITE.
             03  COLUMN 24 VALUE "Date:" COLOR YELLOW.
             03  COLUMN 30 PIC 9999/99/99 FROM OH-DATE COLOR WHITE.
             03  COLUMN 44 VALUE "Status:" COLOR YELLOW.
             03  COLUMN 52 PIC X(10) FROM WK-STAT-TXT COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "Cust :" COLOR YELLOW.
             03  COLUMN 10 PIC 9(6) FROM OH-CUST COLOR WHITE.
             03  COLUMN 18 PIC X(34) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Staff:" COLOR YELLOW.
             03  COLUMN 10 PIC 9(4) FROM OH-STAFF COLOR WHITE.
             03  COLUMN 18 VALUE "Whse:" COLOR YELLOW.
             03  COLUMN 24 PIC 9(3) FROM OH-WHSE COLOR WHITE.
             03  COLUMN 32 VALUE "Due:" COLOR YELLOW.
             03  COLUMN 37 PIC 9999/99/99 FROM OH-DUE-DATE
                              COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE "Ln" COLOR CYAN.
             03  COLUMN 6  VALUE "Product" COLOR CYAN.
             03  COLUMN 15 VALUE "Name" COLOR CYAN.
             03  COLUMN 34 VALUE "Qty" COLOR CYAN.
             03  COLUMN 43 VALUE "Price" COLOR CYAN.
             03  COLUMN 53 VALUE "Amount" COLOR CYAN.
             03  COLUMN 65 VALUE "Alloc" COLOR CYAN.
       01  DS-LIST.
           02  LINE 7.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (1).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (1).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (1).
             03  COLUMN 32 PIC ---,--9 FROM WW-QTY (1).
             03  COLUMN 41 PIC ---,--9.99 FROM WW-PRICE (1).
             03  COLUMN 51 PIC ----,---,--9 FROM WW-AMT (1).
             03  COLUMN 64 PIC ---,--9 FROM WW-ALLOC (1).
           02  LINE 8.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (2).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (2).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (2).
             03  COLUMN 32 PIC ---,--9 FROM WW-QTY (2).
             03  COLUMN 41 PIC ---,--9.99 FROM WW-PRICE (2).
             03  COLUMN 51 PIC ----,---,--9 FROM WW-AMT (2).
             03  COLUMN 64 PIC ---,--9 FROM WW-ALLOC (2).
           02  LINE 9.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (3).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (3).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (3).
             03  COLUMN 32 PIC ---,--9 FROM WW-QTY (3).
             03  COLUMN 41 PIC ---,--9.99 FROM WW-PRICE (3).
             03  COLUMN 51 PIC ----,---,--9 FROM WW-AMT (3).
             03  COLUMN 64 PIC ---,--9 FROM WW-ALLOC (3).
           02  LINE 10.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (4).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (4).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (4).
             03  COLUMN 32 PIC ---,--9 FROM WW-QTY (4).
             03  COLUMN 41 PIC ---,--9.99 FROM WW-PRICE (4).
             03  COLUMN 51 PIC ----,---,--9 FROM WW-AMT (4).
             03  COLUMN 64 PIC ---,--9 FROM WW-ALLOC (4).
           02  LINE 11.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (5).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (5).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (5).
             03  COLUMN 32 PIC ---,--9 FROM WW-QTY (5).
             03  COLUMN 41 PIC ---,--9.99 FROM WW-PRICE (5).
             03  COLUMN 51 PIC ----,---,--9 FROM WW-AMT (5).
             03  COLUMN 64 PIC ---,--9 FROM WW-ALLOC (5).
           02  LINE 12.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (6).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (6).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (6).
             03  COLUMN 32 PIC ---,--9 FROM WW-QTY (6).
             03  COLUMN 41 PIC ---,--9.99 FROM WW-PRICE (6).
             03  COLUMN 51 PIC ----,---,--9 FROM WW-AMT (6).
             03  COLUMN 64 PIC ---,--9 FROM WW-ALLOC (6).
           02  LINE 13.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (7).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (7).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (7).
             03  COLUMN 32 PIC ---,--9 FROM WW-QTY (7).
             03  COLUMN 41 PIC ---,--9.99 FROM WW-PRICE (7).
             03  COLUMN 51 PIC ----,---,--9 FROM WW-AMT (7).
             03  COLUMN 64 PIC ---,--9 FROM WW-ALLOC (7).
           02  LINE 14.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (8).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (8).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (8).
             03  COLUMN 32 PIC ---,--9 FROM WW-QTY (8).
             03  COLUMN 41 PIC ---,--9.99 FROM WW-PRICE (8).
             03  COLUMN 51 PIC ----,---,--9 FROM WW-AMT (8).
             03  COLUMN 64 PIC ---,--9 FROM WW-ALLOC (8).
           02  LINE 15.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (9).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (9).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (9).
             03  COLUMN 32 PIC ---,--9 FROM WW-QTY (9).
             03  COLUMN 41 PIC ---,--9.99 FROM WW-PRICE (9).
             03  COLUMN 51 PIC ----,---,--9 FROM WW-AMT (9).
             03  COLUMN 64 PIC ---,--9 FROM WW-ALLOC (9).
           02  LINE 16.
             03  COLUMN 2  PIC ZZ9 FROM WW-LINE (10).
             03  COLUMN 6  PIC 9(8) FROM WW-PROD (10).
             03  COLUMN 15 PIC X(16) FROM WW-NAME (10).
             03  COLUMN 32 PIC ---,--9 FROM WW-QTY (10).
             03  COLUMN 41 PIC ---,--9.99 FROM WW-PRICE (10).
             03  COLUMN 51 PIC ----,---,--9 FROM WW-AMT (10).
             03  COLUMN 64 PIC ---,--9 FROM WW-ALLOC (10).
       01  DS-TOTAL.
           02  LINE 17.
             03  COLUMN 2  VALUE "Net:" COLOR YELLOW.
             03  COLUMN 7  PIC ---,---,---,--9 FROM WK-NET-TOTAL
                              COLOR WHITE.
             03  COLUMN 24 VALUE "Tax:" COLOR YELLOW.
             03  COLUMN 29 PIC ---,---,--9 FROM WK-TAX-TOTAL
                              COLOR WHITE.
             03  COLUMN 43 VALUE "Total:" COLOR YELLOW.
             03  COLUMN 50 PIC ---,---,---,--9 FROM WK-GRS-TOTAL
                              COLOR WHITE.
           02  LINE 18.
             03  COLUMN 2  VALUE "Lines:" COLOR YELLOW.
             03  COLUMN 9  PIC ZZ9 FROM WK-DCNT COLOR WHITE.
             03  COLUMN 20 VALUE "Page:" COLOR YELLOW.
             03  COLUMN 26 PIC ZZ9 FROM WK-PAGE-NO COLOR WHITE.
             03  COLUMN 29 VALUE "/" COLOR WHITE.
             03  COLUMN 30 PIC ZZ9 FROM WK-PAGE-CNT COLOR WHITE.
       01  DS-CMD.
           02  LINE 19.
             03  COLUMN 2  VALUE "Cmd:" COLOR YELLOW.
             03  COLUMN 7  PIC X(1) USING WK-CMD.
             03  COLUMN 10 VALUE "Line:" COLOR YELLOW.
             03  COLUMN 16 PIC 9(3) USING WK-CMD-ARG.
             03  COLUMN 22 VALUE
                 "A=Add C=Chg D=Del H=Hdr X=Cxl S=Save" COLOR CYAN.
       01  DS-HDR.
           02  LINE 4.
             03  COLUMN 2  VALUE "Order Date :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING OH-DATE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Customer   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(6) USING OH-CUST.
             03  COLUMN 24 PIC X(40) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE "Sales Rep  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(4) USING OH-STAFF.
           02  LINE 7.
             03  COLUMN 2  VALUE "Warehouse  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(3) USING OH-WHSE.
           02  LINE 8.
             03  COLUMN 2  VALUE "Due Date   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING OH-DUE-DATE.
           02  LINE 9.
             03  COLUMN 2  VALUE "Customer PO:" COLOR YELLOW.
             03  COLUMN 16 PIC X(20) USING OH-CUST-PO.
           02  LINE 10.
             03  COLUMN 2  VALUE "Tax Type   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(1) USING OH-TAX-TYPE.
             03  COLUMN 20 VALUE "1:excl 2:incl 3:exempt" COLOR CYAN.
           02  LINE 11.
             03  COLUMN 2  VALUE "Remark     :" COLOR YELLOW.
             03  COLUMN 16 PIC X(40) USING OH-REMARK.
       01  DS-DETAIL.
           02  LINE 12 COLUMN 2 VALUE "--- Add detail line ---"
                              COLOR CYAN.
           02  LINE 13.
             03  COLUMN 2  VALUE "Product    :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING WK-D-PROD.
             03  COLUMN 26 PIC X(40) FROM WK-D-NAME COLOR WHITE.
           02  LINE 14.
             03  COLUMN 2  VALUE "Warehouse  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(3) USING WK-D-WHSE.
           02  LINE 15.
             03  COLUMN 2  VALUE "Quantity   :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(9) USING WK-D-QTY.
           02  LINE 16.
             03  COLUMN 2  VALUE "Unit Price :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(9)V9(2) USING WK-D-PRICE.
       01  DS-CHGLINE.
           02  LINE 12 COLUMN 2 VALUE "--- Change detail line ---"
                              COLOR CYAN.
           02  LINE 13.
             03  COLUMN 2  VALUE "Line       :" COLOR YELLOW.
             03  COLUMN 16 PIC ZZ9 FROM WK-CMD-ARG COLOR WHITE.
           02  LINE 14.
             03  COLUMN 2  VALUE "Product    :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) FROM WK-D-PROD COLOR WHITE.
             03  COLUMN 26 PIC X(40) FROM WK-D-NAME COLOR WHITE.
           02  LINE 15.
             03  COLUMN 2  VALUE "Warehouse  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(3) FROM WK-D-WHSE COLOR WHITE.
           02  LINE 16.
             03  COLUMN 2  VALUE "Quantity   :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(9) USING WK-D-QTY.
           02  LINE 17.
             03  COLUMN 2  VALUE "Unit Price :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(9)V9(2) USING WK-D-PRICE.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Confirm (Y/N):" COLOR YELLOW.
           02  SC-CONF LINE 21 COLUMN 17 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "OE0040"           TO WK-PROGID.
           MOVE "Sales Order Maintenance"          TO WK-TITLE.
           MOVE "ENTER=Read  PF3=End"              TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           PERFORM OPEN-IO-ORDH.
           PERFORM OPEN-IO-ORDD.
           PERFORM OPEN-IO-STOK.
           OPEN INPUT CUSTF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT CUSTF
               CLOSE CUSTF
               OPEN INPUT CUSTF
           END-IF.
           OPEN INPUT PRODF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PRODF
               CLOSE PRODF
               OPEN INPUT PRODF
           END-IF.
       OPENF-999.
           EXIT.
       OPEN-IO-ORDH SECTION.
       OIOH-010.
           OPEN I-O ORDHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ORDHF
               CLOSE ORDHF
               OPEN I-O ORDHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ORDHF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIOH-999.
           EXIT.
       OPEN-IO-ORDD SECTION.
       OIOD-010.
           OPEN I-O ORDDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ORDDF
               CLOSE ORDDF
               OPEN I-O ORDDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ORDDF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIOD-999.
           EXIT.
       OPEN-IO-STOK SECTION.
       OIST-010.
           OPEN I-O STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIST-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAINR-010.
           PERFORM CLEAR-ORDER.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter the order number to maintain"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM RECALL-ORDER
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAINR-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-ORDER SECTION.
       CLRO-010.
           INITIALIZE OH-REC.
           MOVE 0                  TO WK-SEL-ORD WK-DCNT WK-DELCNT.
           MOVE 0                  TO WK-NET-TOTAL WK-TAX-TOTAL.
           MOVE 0                  TO WK-GRS-TOTAL WK-ORIG-TOTAL.
           MOVE 0                  TO WK-CANCEL-FLG WK-ALLOCATED.
           MOVE 0                  TO WK-DIRTY WK-NEXT-LINE.
           MOVE 1                  TO WK-PAGE-TOP.
           MOVE SPACE              TO WK-CUST-NAME WK-STAT-TXT.
           MOVE SPACE              TO WK-CMD WK-CONFIRM.
           MOVE 0                  TO WK-CMD-ARG.
       CLRO-999.
           EXIT.
      *----------------------------------------------------------------
       RECALL-ORDER SECTION.
       RCL-010.
           IF WK-SEL-ORD = 0
               MOVE "Order number required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO RCL-999
           END-IF.
           MOVE WK-SEL-ORD         TO OH-NO.
           READ ORDHF
               INVALID KEY
                   MOVE "Order not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO RCL-999
           END-READ.
           IF OH-DEL-FLAG = 1
               MOVE "Order is deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO RCL-999
           END-IF.
           IF OH-STATUS NOT = 0 AND OH-STATUS NOT = 1
               PERFORM SET-STAT-TXT
               MOVE SPACE          TO WK-MSG-LINE
               STRING "Order status " DELIMITED SIZE
                      WK-STAT-TXT     DELIMITED SIZE
                      " - cannot change" DELIMITED SIZE
                      INTO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO RCL-999
           END-IF.
           MOVE OH-TOTAL           TO WK-ORIG-TOTAL.
           IF OH-STATUS = 1
               MOVE 1              TO WK-ALLOCATED
           ELSE
               MOVE 0              TO WK-ALLOCATED
           END-IF.
           PERFORM LOOKUP-CUST.
           PERFORM SET-STAT-TXT.
           PERFORM LOAD-DETAILS.
           PERFORM COMPUTE-TOTALS.
           PERFORM MAINTAIN-ORDER.
       RCL-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-CUST SECTION.
       LKC-010.
           MOVE SPACE              TO WK-CUST-NAME.
           MOVE OH-CUST            TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "(unknown customer)" TO WK-CUST-NAME
               NOT INVALID KEY
                   MOVE CU-NAME     TO WK-CUST-NAME
           END-READ.
       LKC-999.
           EXIT.
      *----------------------------------------------------------------
       SET-STAT-TXT SECTION.
       SST-010.
           EVALUATE OH-STATUS
               WHEN 0   MOVE "Entered"   TO WK-STAT-TXT
               WHEN 1   MOVE "Allocated" TO WK-STAT-TXT
               WHEN 2   MOVE "Part-ship" TO WK-STAT-TXT
               WHEN 3   MOVE "Shipped"   TO WK-STAT-TXT
               WHEN 4   MOVE "Invoiced"  TO WK-STAT-TXT
               WHEN 9   MOVE "Cancelled" TO WK-STAT-TXT
               WHEN OTHER MOVE "?"       TO WK-STAT-TXT
           END-EVALUATE.
       SST-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-DETAILS SECTION.
      *    read the order detail lines into the live buffer
       LDT-010.
           MOVE 0                  TO WK-DCNT WK-DELCNT.
           MOVE 1                  TO WK-NEXT-LINE.
           MOVE WK-SEL-ORD         TO OD-NO.
           MOVE 0                  TO OD-LINE.
           START ORDDF KEY IS NOT LESS THAN OD-NO
               INVALID KEY
                   GO TO LDT-999
           END-START.
       LDT-020.
           READ ORDDF NEXT
               AT END
                   GO TO LDT-999
           END-READ.
           IF OD-NO NOT = WK-SEL-ORD
               GO TO LDT-999
           END-IF.
           IF WK-DCNT >= 200
               GO TO LDT-999
           END-IF.
           ADD 1                   TO WK-DCNT.
           MOVE OD-LINE            TO DR-LINE   (WK-DCNT).
           MOVE OD-PROD            TO DR-PROD   (WK-DCNT).
           MOVE OD-WHSE            TO DR-WHSE   (WK-DCNT).
           MOVE OD-QTY             TO DR-QTY    (WK-DCNT).
           MOVE OD-UNIT-PRICE      TO DR-PRICE  (WK-DCNT).
           MOVE OD-AMOUNT          TO DR-AMT    (WK-DCNT).
           MOVE OD-TAX-CATEGORY    TO DR-TAXCAT (WK-DCNT).
           MOVE OD-ALLOC-QTY       TO DR-ALLOC  (WK-DCNT).
           MOVE OD-STATUS          TO DR-STATUS (WK-DCNT).
           MOVE 0                  TO DR-NEW    (WK-DCNT).
           IF OD-LINE >= WK-NEXT-LINE
               COMPUTE WK-NEXT-LINE = OD-LINE + 1
           END-IF.
           MOVE OD-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "(unknown)" TO DR-NAME (WK-DCNT)
                   MOVE 0           TO DR-STKMNG (WK-DCNT)
               NOT INVALID KEY
                   MOVE PR-NAME     TO DR-NAME (WK-DCNT)
                   MOVE PR-STOCK-MNG TO DR-STKMNG (WK-DCNT)
           END-READ.
           GO TO LDT-020.
       LDT-999.
           EXIT.
      *----------------------------------------------------------------
       MAINTAIN-ORDER SECTION.
       MNT-010.
           MOVE 0                  TO WK-MAINT-END.
           MOVE 1                  TO WK-PAGE-TOP.
           MOVE "ENTER=Cmd  PF6/PF12=Page  PF3=Quit"
                                   TO WK-FKEY-LINE.
           PERFORM CALC-PAGES.
           PERFORM BUILD-WINDOW.
           MOVE "Order loaded - enter a command" TO WK-MSG-LINE.
           PERFORM UNTIL MAINT-END OR END-YES
               PERFORM PAINT-MAINT
               MOVE SPACE          TO WK-CMD
               MOVE 0              TO WK-CMD-ARG
               DISPLAY DS-CMD
               ACCEPT  DS-CMD
               EVALUATE ESTS
                   WHEN "03"
                       PERFORM QUIT-CHECK
                   WHEN "06"
                       PERFORM PAGE-DOWN
                   WHEN "12"
                       PERFORM PAGE-UP
                   WHEN "00"
                       PERFORM DISPATCH-CMD
                   WHEN OTHER
                       MOVE "Invalid function key" TO WK-MSG-LINE
               END-EVALUATE
           END-PERFORM.
           MOVE "ENTER=Read  PF3=End" TO WK-FKEY-LINE.
       MNT-999.
           EXIT.
      *----------------------------------------------------------------
       DISPATCH-CMD SECTION.
       DSP-010.
           EVALUATE WK-CMD
               WHEN "A"
               WHEN "a"
                   PERFORM ADD-LINE-RTN
               WHEN "C"
               WHEN "c"
                   PERFORM CHANGE-LINE-RTN
               WHEN "D"
               WHEN "d"
                   PERFORM DELETE-LINE-RTN
               WHEN "H"
               WHEN "h"
                   PERFORM CHANGE-HEADER-RTN
               WHEN "X"
               WHEN "x"
                   PERFORM CANCEL-ORDER-RTN
               WHEN "S"
               WHEN "s"
                   PERFORM SAVE-CMD
               WHEN OTHER
                   MOVE "Enter A C D H X or S" TO WK-MSG-LINE
           END-EVALUATE.
           PERFORM COMPUTE-TOTALS.
           PERFORM CALC-PAGES.
           PERFORM BUILD-WINDOW.
       DSP-999.
           EXIT.
      *----------------------------------------------------------------
       QUIT-CHECK SECTION.
       QC-010.
           IF WK-DIRTY = 0
               SET MAINT-END TO TRUE
               MOVE "No changes - order unchanged" TO WK-MSG-LINE
               GO TO QC-999
           END-IF.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Discard unsaved changes ? (Y/N)" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               SET MAINT-END TO TRUE
               MOVE "Changes discarded" TO WK-MSG-LINE
           ELSE
               MOVE "Continue editing" TO WK-MSG-LINE
           END-IF.
       QC-999.
           EXIT.
      *----------------------------------------------------------------
       ADD-LINE-RTN SECTION.
       ADL-010.
           IF WK-DCNT >= 200
               MOVE "Maximum 200 lines reached" TO WK-MSG-LINE
               GO TO ADL-999
           END-IF.
           MOVE 0                  TO WK-D-PROD WK-D-WHSE WK-D-QTY.
           MOVE 0                  TO WK-D-PRICE WK-D-AMT WK-D-AVAIL.
           MOVE 1                  TO WK-D-TAXCAT.
           MOVE 0                  TO WK-D-STKMNG.
           MOVE OH-WHSE            TO WK-D-WHSE.
           MOVE SPACE              TO WK-D-NAME.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter the new line - PF3 to abandon" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-DETAIL.
           ACCEPT  DS-DETAIL.
           IF ESTS = "03"
               MOVE "Add abandoned" TO WK-MSG-LINE
               GO TO ADL-999
           END-IF.
           PERFORM VALIDATE-NEW-LINE.
           IF ERR-YES
               GO TO ADL-999
           END-IF.
           ADD 1                   TO WK-DCNT.
           MOVE 0                  TO DR-LINE   (WK-DCNT).
           MOVE WK-D-PROD          TO DR-PROD   (WK-DCNT).
           MOVE WK-D-WHSE          TO DR-WHSE   (WK-DCNT).
           MOVE WK-D-NAME          TO DR-NAME   (WK-DCNT).
           MOVE WK-D-QTY           TO DR-QTY    (WK-DCNT).
           MOVE WK-D-PRICE         TO DR-PRICE  (WK-DCNT).
           MOVE WK-D-AMT           TO DR-AMT    (WK-DCNT).
           MOVE WK-D-TAXCAT        TO DR-TAXCAT (WK-DCNT).
           MOVE 0                  TO DR-ALLOC  (WK-DCNT).
           MOVE WK-D-STKMNG        TO DR-STKMNG (WK-DCNT).
           MOVE 0                  TO DR-STATUS (WK-DCNT).
           MOVE 1                  TO DR-NEW    (WK-DCNT).
           MOVE 1                  TO WK-DIRTY.
           MOVE "Line added"       TO WK-MSG-LINE.
       ADL-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-NEW-LINE SECTION.
       VNL-010.
           MOVE 0                  TO ERR-FLG.
           IF WK-D-PROD = 0
               MOVE "Product code required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VNL-999
           END-IF.
           MOVE WK-D-PROD          TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "Product not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VNL-999
           END-READ.
           IF PR-DEL-FLAG = 1
               MOVE "Product is deleted" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VNL-999
           END-IF.
           MOVE PR-NAME            TO WK-D-NAME.
           MOVE PR-TAX-CATEGORY    TO WK-D-TAXCAT.
           MOVE PR-STOCK-MNG       TO WK-D-STKMNG.
           IF WK-D-WHSE = 0
               MOVE PR-DFLT-WHSE   TO WK-D-WHSE
           END-IF.
           IF WK-D-QTY <= 0
               MOVE "Quantity must be positive" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VNL-999
           END-IF.
           IF WK-D-PRICE <= 0
               PERFORM RESOLVE-PRICE
           END-IF.
           COMPUTE WK-D-AMT = WK-D-QTY * WK-D-PRICE.
       VNL-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       RESOLVE-PRICE SECTION.
      *    rank price then list price (CUSTF already read for order)
       RPR-010.
           MOVE 0                  TO WK-D-PRICE.
           IF CU-PRICE-RANK >= 1 AND CU-PRICE-RANK <= 5
               MOVE PR-RANK-PRICE (CU-PRICE-RANK) TO WK-D-PRICE
           END-IF.
           IF WK-D-PRICE <= 0
               MOVE PR-LIST-PRICE  TO WK-D-PRICE
           END-IF.
       RPR-999.
           EXIT.
      *----------------------------------------------------------------
       CHANGE-LINE-RTN SECTION.
       CHL-010.
           IF WK-CMD-ARG = 0 OR WK-CMD-ARG > WK-DCNT
               MOVE "Enter a valid line number" TO WK-MSG-LINE
               GO TO CHL-999
           END-IF.
           MOVE WK-CMD-ARG         TO WK-IDX.
           MOVE DR-PROD (WK-IDX)   TO WK-D-PROD.
           MOVE DR-WHSE (WK-IDX)   TO WK-D-WHSE.
           MOVE DR-NAME (WK-IDX)   TO WK-D-NAME.
           MOVE DR-QTY  (WK-IDX)   TO WK-D-QTY.
           MOVE DR-PRICE(WK-IDX)   TO WK-D-PRICE.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Change quantity / price - PF3 to abandon"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CHGLINE.
           ACCEPT  DS-CHGLINE.
           IF ESTS = "03"
               MOVE "Change abandoned" TO WK-MSG-LINE
               GO TO CHL-999
           END-IF.
           IF WK-D-QTY <= 0
               MOVE "Quantity must be positive" TO WK-MSG-LINE
               GO TO CHL-999
           END-IF.
           IF WK-D-PRICE < 0
               MOVE "Price cannot be negative" TO WK-MSG-LINE
               GO TO CHL-999
           END-IF.
           MOVE WK-D-QTY           TO DR-QTY   (WK-IDX).
           MOVE WK-D-PRICE         TO DR-PRICE (WK-IDX).
           COMPUTE DR-AMT (WK-IDX) = WK-D-QTY * WK-D-PRICE.
           MOVE 1                  TO WK-DIRTY.
           MOVE "Line changed"     TO WK-MSG-LINE.
       CHL-999.
           EXIT.
      *----------------------------------------------------------------
       DELETE-LINE-RTN SECTION.
       DLL-010.
           IF WK-CMD-ARG = 0 OR WK-CMD-ARG > WK-DCNT
               MOVE "Enter a valid line number" TO WK-MSG-LINE
               GO TO DLL-999
           END-IF.
           MOVE WK-CMD-ARG         TO WK-IDX.
           IF DR-NEW (WK-IDX) = 0
      *        existing line - remember it for physical delete
               ADD 1               TO WK-DELCNT
               MOVE DR-LINE  (WK-IDX) TO DL-LINE   (WK-DELCNT)
               MOVE DR-PROD  (WK-IDX) TO DL-PROD   (WK-DELCNT)
               MOVE DR-WHSE  (WK-IDX) TO DL-WHSE   (WK-DELCNT)
               MOVE DR-ALLOC (WK-IDX) TO DL-ALLOC  (WK-DELCNT)
               MOVE DR-STKMNG(WK-IDX) TO DL-STKMNG (WK-DELCNT)
           END-IF.
           PERFORM COMPRESS-TABLE.
           MOVE 1                  TO WK-DIRTY.
           MOVE "Line deleted"     TO WK-MSG-LINE.
       DLL-999.
           EXIT.
      *----------------------------------------------------------------
       COMPRESS-TABLE SECTION.
      *    remove row WK-IDX by shifting the rows above it down
       CMP-010.
           PERFORM VARYING WK-IDX2 FROM WK-IDX BY 1
                   UNTIL WK-IDX2 >= WK-DCNT
               COMPUTE WK-CNT = WK-IDX2 + 1
               MOVE DR-LINE   (WK-CNT) TO DR-LINE   (WK-IDX2)
               MOVE DR-PROD   (WK-CNT) TO DR-PROD   (WK-IDX2)
               MOVE DR-WHSE   (WK-CNT) TO DR-WHSE   (WK-IDX2)
               MOVE DR-NAME   (WK-CNT) TO DR-NAME   (WK-IDX2)
               MOVE DR-QTY    (WK-CNT) TO DR-QTY    (WK-IDX2)
               MOVE DR-PRICE  (WK-CNT) TO DR-PRICE  (WK-IDX2)
               MOVE DR-AMT    (WK-CNT) TO DR-AMT    (WK-IDX2)
               MOVE DR-TAXCAT (WK-CNT) TO DR-TAXCAT (WK-IDX2)
               MOVE DR-ALLOC  (WK-CNT) TO DR-ALLOC  (WK-IDX2)
               MOVE DR-STKMNG (WK-CNT) TO DR-STKMNG (WK-IDX2)
               MOVE DR-STATUS (WK-CNT) TO DR-STATUS (WK-IDX2)
               MOVE DR-NEW    (WK-CNT) TO DR-NEW    (WK-IDX2)
           END-PERFORM.
           IF WK-DCNT > 0
               SUBTRACT 1          FROM WK-DCNT
           END-IF.
       CMP-999.
           EXIT.
      *----------------------------------------------------------------
       CHANGE-HEADER-RTN SECTION.
       CHH-010.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Change header fields - PF3 to abandon"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-HDR.
           ACCEPT  DS-HDR.
           IF ESTS = "03"
               MOVE "Header change abandoned" TO WK-MSG-LINE
               PERFORM LOOKUP-CUST
               GO TO CHH-999
           END-IF.
           PERFORM VALIDATE-HEADER.
           IF ERR-YES
               GO TO CHH-999
           END-IF.
           MOVE 1                  TO WK-DIRTY.
           MOVE "Header changed"   TO WK-MSG-LINE.
       CHH-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-HEADER SECTION.
       VHD-010.
           MOVE 0                  TO ERR-FLG.
           IF OH-CUST = 0
               MOVE "Customer code required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VHD-999
           END-IF.
           MOVE OH-CUST            TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "Customer not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VHD-999
           END-READ.
           IF CU-DEL-FLAG = 1
               MOVE "Customer is deleted" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VHD-999
           END-IF.
           MOVE CU-NAME            TO WK-CUST-NAME.
           IF OH-TAX-TYPE < 1 OR OH-TAX-TYPE > 3
               MOVE "Tax type must be 1, 2 or 3" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
           END-IF.
       VHD-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       CANCEL-ORDER-RTN SECTION.
       CXO-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Cancel the WHOLE order ? (Y/N)" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF NOT CONFIRM-YES
               MOVE "Cancel not confirmed" TO WK-MSG-LINE
               GO TO CXO-999
           END-IF.
           MOVE 1                  TO WK-CANCEL-FLG.
           MOVE 1                  TO WK-DIRTY.
           PERFORM SAVE-ORDER.
           IF WK-CANCEL-FLG = 1
               SET MAINT-END TO TRUE
           END-IF.
       CXO-999.
           EXIT.
      *----------------------------------------------------------------
       SAVE-CMD SECTION.
       SVC-010.
           IF WK-DIRTY = 0
               MOVE "Nothing changed - nothing to save"
                                   TO WK-MSG-LINE
               GO TO SVC-999
           END-IF.
           IF WK-DCNT = 0
               MOVE "No lines - use X to cancel the order"
                                   TO WK-MSG-LINE
               GO TO SVC-999
           END-IF.
           MOVE 0                  TO WK-CANCEL-FLG.
           MOVE SPACE              TO WK-CONFIRM.
           PERFORM COMPUTE-TOTALS.
           MOVE "Save the changes ? (Y/N)" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               PERFORM SAVE-ORDER
               SET MAINT-END TO TRUE
           ELSE
               MOVE "Save cancelled" TO WK-MSG-LINE
           END-IF.
       SVC-999.
           EXIT.
      *----------------------------------------------------------------
       SAVE-ORDER SECTION.
       SVO-010.
           PERFORM COMPUTE-TOTALS.
           PERFORM CREDIT-CHECK.
      *    release stock of the deleted existing lines
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-DELCNT
               IF DL-STKMNG (WK-IDX) = 1 AND DL-ALLOC (WK-IDX) NOT = 0
                   MOVE DL-PROD (WK-IDX)  TO WK-AP-PROD
                   MOVE DL-WHSE (WK-IDX)  TO WK-AP-WHSE
                   COMPUTE WK-AP-DELTA = 0 - DL-ALLOC (WK-IDX)
                   PERFORM ADJUST-ALLOC
               END-IF
               PERFORM DELETE-ONE-DETAIL
           END-PERFORM.
           MOVE 0                  TO WK-DELCNT.
      *    write / rewrite the live lines and adjust allocations
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-DCNT
               PERFORM SAVE-ONE-DETAIL
           END-PERFORM.
           PERFORM REWRITE-HEADER.
           IF WK-CANCEL-FLG = 1
               MOVE "Order cancelled" TO WK-MSG-LINE
           ELSE
               MOVE "Order saved"     TO WK-MSG-LINE
           END-IF.
           MOVE 0                  TO WK-DIRTY.
       SVO-999.
           EXIT.
      *----------------------------------------------------------------
       SAVE-ONE-DETAIL SECTION.
      *    compute the wanted allocation, apply the delta, then write
       SOD-010.
           IF WK-CANCEL-FLG = 1
               MOVE 0              TO WK-AP-TARGET
           ELSE
               IF WK-ALLOCATED = 1 AND DR-STKMNG (WK-IDX) = 1
                   MOVE DR-QTY (WK-IDX) TO WK-AP-TARGET
               ELSE
                   MOVE DR-ALLOC (WK-IDX) TO WK-AP-TARGET
               END-IF
           END-IF.
           IF DR-STKMNG (WK-IDX) = 1
               COMPUTE WK-AP-DELTA =
                   WK-AP-TARGET - DR-ALLOC (WK-IDX)
               IF WK-AP-DELTA NOT = 0
                   MOVE DR-PROD (WK-IDX) TO WK-AP-PROD
                   MOVE DR-WHSE (WK-IDX) TO WK-AP-WHSE
                   PERFORM ADJUST-ALLOC
               END-IF
           END-IF.
           MOVE WK-AP-TARGET       TO DR-ALLOC (WK-IDX).
           PERFORM BUILD-OD-REC.
           IF DR-NEW (WK-IDX) = 1
               MOVE WK-NEXT-LINE   TO OD-LINE
               MOVE WK-NEXT-LINE   TO DR-LINE (WK-IDX)
               ADD 1               TO WK-NEXT-LINE
               MOVE 0              TO DR-NEW (WK-IDX)
               WRITE OD-REC
                   INVALID KEY
                       MOVE "Detail line write failed" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-WRITE
           ELSE
               REWRITE OD-REC
                   INVALID KEY
                       WRITE OD-REC
                           INVALID KEY
                               MOVE "Detail rewrite failed"
                                   TO WK-MSG-LINE
                               DISPLAY DS-MSG
                       END-WRITE
               END-REWRITE
           END-IF.
       SOD-999.
           EXIT.
      *----------------------------------------------------------------
       BUILD-OD-REC SECTION.
       BOD-010.
           INITIALIZE OD-REC.
           MOVE WK-SEL-ORD         TO OD-NO.
           MOVE DR-LINE   (WK-IDX) TO OD-LINE.
           MOVE DR-PROD   (WK-IDX) TO OD-PROD.
           MOVE DR-WHSE   (WK-IDX) TO OD-WHSE.
           MOVE DR-QTY    (WK-IDX) TO OD-QTY.
           MOVE DR-PRICE  (WK-IDX) TO OD-UNIT-PRICE.
           MOVE DR-AMT    (WK-IDX) TO OD-AMOUNT.
           MOVE DR-TAXCAT (WK-IDX) TO OD-TAX-CATEGORY.
           MOVE 0                  TO OD-SHIPPED-QTY.
           MOVE DR-ALLOC  (WK-IDX) TO OD-ALLOC-QTY.
           MOVE OH-DUE-DATE        TO OD-DUE-DATE.
           IF WK-CANCEL-FLG = 1
               MOVE 9              TO OD-STATUS
           ELSE
               MOVE DR-STATUS (WK-IDX) TO OD-STATUS
           END-IF.
           MOVE SPACE              TO OD-REMARK.
       BOD-999.
           EXIT.
      *----------------------------------------------------------------
       DELETE-ONE-DETAIL SECTION.
       DOD-010.
           MOVE WK-SEL-ORD         TO OD-NO.
           MOVE DL-LINE (WK-IDX)   TO OD-LINE.
           DELETE ORDDF
               INVALID KEY
                   CONTINUE
           END-DELETE.
       DOD-999.
           EXIT.
      *----------------------------------------------------------------
       ADJUST-ALLOC SECTION.
      *    apply WK-AP-DELTA to SK-ALLOCATED of WK-AP-PROD / WK-AP-WHSE
       AJA-010.
           IF WK-AP-DELTA = 0
               GO TO AJA-999
           END-IF.
           MOVE WK-AP-PROD         TO SK-PROD.
           MOVE WK-AP-WHSE         TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   IF WK-AP-DELTA > 0
                       INITIALIZE SK-REC
                       MOVE WK-AP-PROD TO SK-PROD
                       MOVE WK-AP-WHSE TO SK-WHSE
                       MOVE WK-AP-DELTA TO SK-ALLOCATED
                       WRITE SK-REC
                           INVALID KEY
                               CONTINUE
                       END-WRITE
                   END-IF
                   GO TO AJA-999
           END-READ.
           ADD WK-AP-DELTA         TO SK-ALLOCATED.
           IF SK-ALLOCATED < 0
               MOVE 0              TO SK-ALLOCATED
           END-IF.
           REWRITE SK-REC
               INVALID KEY
                   CONTINUE
           END-REWRITE.
       AJA-999.
           EXIT.
      *----------------------------------------------------------------
       REWRITE-HEADER SECTION.
       RWH-010.
           MOVE WK-SEL-ORD         TO OH-NO.
           MOVE WK-NET-TOTAL       TO OH-AMOUNT.
           MOVE WK-TAX-TOTAL       TO OH-TAX-AMOUNT.
           MOVE WK-GRS-TOTAL       TO OH-TOTAL.
           MOVE WK-DCNT            TO OH-LINES.
           IF WK-CANCEL-FLG = 1
               MOVE 9              TO OH-STATUS
           END-IF.
           MOVE WK-SYSDATE         TO OH-UPD-DATE.
           MOVE WK-USER-CODE       TO OH-UPD-USER.
           REWRITE OH-REC
               INVALID KEY
                   MOVE "Header rewrite failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
       RWH-999.
           EXIT.
      *----------------------------------------------------------------
       CREDIT-CHECK SECTION.
      *    warn if the revised total pushes the customer over limit
       CRC-010.
           IF WK-CANCEL-FLG = 1
               GO TO CRC-999
           END-IF.
           MOVE OH-CUST            TO KC-CUST.
           COMPUTE KC-AMOUNT = WK-GRS-TOTAL - WK-ORIG-TOTAL.
           CALL "CREDIT" USING KCRED.
           IF KC-STATUS = "00" AND KC-EXCEED = 1
               MOVE "Warning: customer credit limit exceeded"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CRC-999.
           EXIT.
      *----------------------------------------------------------------
       COMPUTE-TOTALS SECTION.
       CTT-010.
           MOVE 0                  TO WK-NET-TOTAL.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-DCNT
               ADD DR-AMT (WK-IDX) TO WK-NET-TOTAL
           END-PERFORM.
           MOVE 1                  TO KT-CATEGORY.
           MOVE OH-TAX-TYPE        TO KT-TAX-TYPE.
           IF KT-TAX-TYPE < 1 OR KT-TAX-TYPE > 3
               MOVE 1              TO KT-TAX-TYPE
           END-IF.
           MOVE CU-TAX-ROUND       TO KT-ROUND.
           IF KT-ROUND = 0
               MOVE 1              TO KT-ROUND
           END-IF.
           MOVE OH-DATE            TO KT-DATE.
           MOVE WK-NET-TOTAL       TO KT-AMOUNT.
           CALL "TAXCAL" USING KTAX.
           MOVE KT-NET             TO WK-NET-TOTAL.
           MOVE KT-TAX             TO WK-TAX-TOTAL.
           MOVE KT-GROSS           TO WK-GRS-TOTAL.
       CTT-999.
           EXIT.
      *----------------------------------------------------------------
       CALC-PAGES SECTION.
       CLP-010.
           IF WK-DCNT = 0
               MOVE 1              TO WK-PAGE-CNT
           ELSE
               COMPUTE WK-PAGE-CNT =
                   (WK-DCNT + WK-PGSIZE - 1) / WK-PGSIZE
           END-IF.
           IF WK-PAGE-TOP > WK-DCNT
               MOVE 1              TO WK-PAGE-TOP
           END-IF.
       CLP-999.
           EXIT.
      *----------------------------------------------------------------
       BUILD-WINDOW SECTION.
       BLW-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1
                   UNTIL WK-IDX > WK-PGSIZE
               COMPUTE WK-IDX2 = WK-PAGE-TOP + WK-IDX - 1
               IF WK-IDX2 <= WK-DCNT AND WK-IDX2 >= 1
                   MOVE WK-IDX2         TO WW-LINE  (WK-IDX)
                   MOVE DR-PROD (WK-IDX2) TO WW-PROD (WK-IDX)
                   MOVE DR-NAME (WK-IDX2) TO WW-NAME (WK-IDX)
                   MOVE DR-QTY  (WK-IDX2) TO WW-QTY  (WK-IDX)
                   MOVE DR-PRICE(WK-IDX2) TO WW-PRICE(WK-IDX)
                   MOVE DR-AMT  (WK-IDX2) TO WW-AMT  (WK-IDX)
                   MOVE DR-ALLOC(WK-IDX2) TO WW-ALLOC(WK-IDX)
               ELSE
                   MOVE 0          TO WW-LINE  (WK-IDX)
                   MOVE 0          TO WW-PROD  (WK-IDX)
                   MOVE SPACE      TO WW-NAME  (WK-IDX)
                   MOVE 0          TO WW-QTY   (WK-IDX)
                   MOVE 0          TO WW-PRICE (WK-IDX)
                   MOVE 0          TO WW-AMT   (WK-IDX)
                   MOVE 0          TO WW-ALLOC (WK-IDX)
               END-IF
           END-PERFORM.
           COMPUTE WK-PAGE-NO =
               (WK-PAGE-TOP + WK-PGSIZE - 1) / WK-PGSIZE.
       BLW-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-DOWN SECTION.
       PGD-010.
           IF WK-PAGE-TOP + WK-PGSIZE > WK-DCNT
               MOVE "Last page" TO WK-MSG-LINE
               GO TO PGD-999
           END-IF.
           ADD WK-PGSIZE           TO WK-PAGE-TOP.
           PERFORM BUILD-WINDOW.
           MOVE SPACE              TO WK-MSG-LINE.
       PGD-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-UP SECTION.
       PGU-010.
           IF WK-PAGE-TOP <= 1
               MOVE "First page" TO WK-MSG-LINE
               GO TO PGU-999
           END-IF.
           IF WK-PAGE-TOP > WK-PGSIZE
               SUBTRACT WK-PGSIZE  FROM WK-PAGE-TOP
           ELSE
               MOVE 1              TO WK-PAGE-TOP
           END-IF.
           PERFORM BUILD-WINDOW.
           MOVE SPACE              TO WK-MSG-LINE.
       PGU-999.
           EXIT.
      *----------------------------------------------------------------
       PAINT-MAINT SECTION.
       PNT-010.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           DISPLAY DS-INFO.
           DISPLAY DS-LIST.
           DISPLAY DS-TOTAL.
           DISPLAY DS-MSG.
       PNT-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE ORDHF ORDDF STOKF CUSTF PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "OE0040"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
