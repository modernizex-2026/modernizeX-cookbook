       IDENTIFICATION DIVISION.
       PROGRAM-ID. AR0010.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : AR0010  -  Cash receipt entry                     *
      *  FUNCTION : record a cash receipt from a customer.  The       *
      *             customer and (for transfer/bill) the bank are     *
      *             validated, the receipt number is assigned by      *
      *             NUMGEN, a receipt record is written to RCPTF, an  *
      *             AR ledger line of kind 2 (receipt) is posted to   *
      *             ARLF with the receipt in AL-CREDIT and a running   *
      *             balance, and the amount is subtracted from the    *
      *             customer's AR balance.                            *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SRCPT.
           COPY SARL.
           COPY SCUST.
           COPY SBANK.
       I-O-CONTROL.
           APPLY SHARED-MODE ON RCPTF
           APPLY SHARED-MODE ON ARLF
           APPLY SHARED-MODE ON CUSTF.
       DATA DIVISION.
       FILE SECTION.
           COPY FRCPT.
           COPY FARL.
           COPY FCUST.
           COPY FBANK.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-RCPT.
           02  WK-CUST-NAME        PIC X(40) VALUE SPACE.
           02  WK-BANK-NAME        PIC X(30) VALUE SPACE.
           02  WK-CUR-BAL          PIC S9(11) VALUE 0.
           02  WK-NEW-BAL          PIC S9(11) VALUE 0.
           02  WK-RE-NO-D          PIC 9(10) VALUE 0.
           02  WK-CLOSE-YM         PIC 9(6)  VALUE 0.
           02  WK-SESS-CNT         PIC 9(5)  VALUE 0.
           02  WK-SESS-AMT         PIC S9(11) VALUE 0.
       01  WK-FLAGS.
           02  HDR-OK              PIC 9(1)  VALUE 0.
             88  HDR-YES                     VALUE 1.
       01  WK-CONST.
           02  WK-REF-RCPT         PIC 9(2)  VALUE 26.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-HEAD.
           02  LINE 3.
             03  COLUMN 2  VALUE "Receipt No :" COLOR YELLOW.
             03  COLUMN 16 PIC ZZZZZZZZZ9 FROM WK-RE-NO-D COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "Date       :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING RE-DATE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Customer   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(6) USING RE-CUST.
             03  COLUMN 24 PIC X(40) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE "AR Balance :" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-CUR-BAL
                              COLOR WHITE.
           02  LINE 7.
             03  COLUMN 2  VALUE "Method     :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(1) USING RE-METHOD.
             03  COLUMN 20 VALUE "1:cash 2:transfer 3:bill 4:offset"
                              COLOR CYAN.
           02  LINE 8.
             03  COLUMN 2  VALUE "Amount     :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(11) USING RE-AMOUNT.
           02  LINE 9.
             03  COLUMN 2  VALUE "Bank Code  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(4) USING RE-BANK-CODE.
             03  COLUMN 24 PIC X(30) FROM WK-BANK-NAME COLOR WHITE.
           02  LINE 10.
             03  COLUMN 2  VALUE "Remark     :" COLOR YELLOW.
             03  COLUMN 16 PIC X(30) USING RE-REMARK.
           02  LINE 11.
             03  COLUMN 2  VALUE "Session cnt:" COLOR CYAN.
             03  COLUMN 16 PIC ZZZZ9 FROM WK-SESS-CNT.
             03  COLUMN 24 VALUE "amt:" COLOR CYAN.
             03  COLUMN 29 PIC ---,---,---,--9 FROM WK-SESS-AMT.
       01  DS-CONFIRM.
           02  LINE 12.
             03  COLUMN 2  VALUE "New Balance:" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-NEW-BAL
                              COLOR WHITE.
           02  LINE 14 COLUMN 2 VALUE "Save receipt Y/N:" COLOR YELLOW.
           02  SC-CONF LINE 14 COLUMN 20 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM RCPT-LOOP UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "AR0010"           TO WK-PROGID.
           MOVE "Cash Receipt Entry"              TO WK-TITLE.
           MOVE "ENTER=Confirm  PF3=End  PF4=Clear"
                                   TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           OPEN I-O   RCPTF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT RCPTF
               CLOSE RCPTF
               OPEN I-O RCPTF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "RCPTF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O   ARLF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ARLF
               CLOSE ARLF
               OPEN I-O ARLF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ARLF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O   CUSTF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT CUSTF
               CLOSE CUSTF
               OPEN I-O CUSTF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "CUSTF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT BANKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT BANKF
               CLOSE BANKF
               OPEN INPUT BANKF
           END-IF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       RCPT-LOOP SECTION.
       RLUP-010.
           PERFORM CLEAR-RCPT.
           PERFORM ENTER-HEADER.
           IF END-YES
               GO TO RLUP-999
           END-IF.
           IF HDR-YES
               PERFORM CONFIRM-SAVE
           END-IF.
       RLUP-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-RCPT SECTION.
       CLR-010.
           INITIALIZE RE-REC.
           MOVE 0                  TO HDR-OK.
           MOVE 0                  TO WK-CUR-BAL WK-NEW-BAL.
           MOVE 0                  TO WK-RE-NO-D WK-CLOSE-YM.
           MOVE SPACE              TO WK-CUST-NAME WK-BANK-NAME.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE WK-SYSDATE         TO RE-DATE.
           MOVE 1                  TO RE-METHOD.
       CLR-999.
           EXIT.
      *----------------------------------------------------------------
       ENTER-HEADER SECTION.
       EHDR-010.
           MOVE 0                  TO HDR-OK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter receipt details - PF3 to end" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-HEAD.
           ACCEPT  DS-HEAD.
           IF ESTS = "03"
               SET END-YES TO TRUE
               GO TO EHDR-999
           END-IF.
           IF ESTS = "04"
               MOVE "Cleared" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO EHDR-999
           END-IF.
           PERFORM VALIDATE-HEADER.
       EHDR-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-HEADER SECTION.
       VHDR-010.
           MOVE 0                  TO ERR-FLG.
           MOVE "VALD"             TO KD-FUNC.
           MOVE RE-DATE            TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           IF KD-STATUS NOT = "00"
               MOVE "Receipt date is invalid" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VHDR-999
           END-IF.
           IF RE-CUST = 0
               MOVE "Customer code required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VHDR-999
           END-IF.
           MOVE RE-CUST            TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "Customer not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VHDR-999
           END-READ.
           IF CU-DEL-FLAG = 1
               MOVE "Customer is deleted" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VHDR-999
           END-IF.
           MOVE CU-NAME            TO WK-CUST-NAME.
           MOVE CU-BALANCE         TO WK-CUR-BAL.
           IF RE-AMOUNT <= 0
               MOVE "Amount must be positive" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VHDR-999
           END-IF.
           IF RE-METHOD < 1 OR RE-METHOD > 4
               MOVE "Method must be 1 to 4" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VHDR-999
           END-IF.
           PERFORM VALIDATE-BANK.
           IF ERR-YES
               GO TO VHDR-999
           END-IF.
           COMPUTE WK-NEW-BAL = CU-BALANCE - RE-AMOUNT.
           MOVE 1                  TO HDR-OK.
           DISPLAY DS-HEAD.
           MOVE "Details OK - press ENTER to confirm" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       VHDR-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       VALIDATE-BANK SECTION.
       VBNK-010.
           MOVE SPACE              TO WK-BANK-NAME.
           IF RE-BANK-CODE = 0
               IF RE-METHOD = 2
                   MOVE "Bank code required for transfer"
                                   TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
               END-IF
               GO TO VBNK-999
           END-IF.
           MOVE RE-BANK-CODE       TO BK-CODE.
           READ BANKF
               INVALID KEY
                   MOVE "Bank code not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VBNK-999
           END-READ.
           IF BK-DEL-FLAG = 1
               MOVE "Bank is deleted" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VBNK-999
           END-IF.
           MOVE BK-NAME            TO WK-BANK-NAME.
       VBNK-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-SAVE SECTION.
       CSAV-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Confirm to post the receipt" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               PERFORM SAVE-RCPT
           ELSE
               MOVE "Receipt discarded" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CSAV-999.
           EXIT.
      *----------------------------------------------------------------
       SAVE-RCPT SECTION.
       SAV-010.
           MOVE "RECEIPT"          TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Receipt number assignment failed"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO SAV-999
           END-IF.
           MOVE KNUM-NUMBER        TO RE-NO WK-RE-NO-D.
           COMPUTE WK-CLOSE-YM = RE-DATE / 100.
           MOVE WK-CLOSE-YM        TO RE-CLOSE-YM.
           MOVE 0                  TO RE-STATUS RE-DEL-FLAG.
           MOVE WK-SYSDATE         TO RE-ADD-DATE.
           MOVE WK-USER-CODE       TO RE-ADD-USER.
           WRITE RE-REC
               INVALID KEY
                   MOVE "Receipt write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO SAV-999
           END-WRITE.
           PERFORM POST-LEDGER.
           PERFORM UPDATE-CUST-BAL.
           ADD 1                   TO WK-SESS-CNT.
           ADD RE-AMOUNT           TO WK-SESS-AMT.
           MOVE "Receipt posted"   TO WK-MSG-LINE.
           DISPLAY DS-HEAD.
           DISPLAY DS-MSG.
       SAV-999.
           EXIT.
      *----------------------------------------------------------------
       UPDATE-CUST-BAL SECTION.
       UCB-010.
           MOVE RE-CUST            TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "Customer balance update failed"
                                   TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO UCB-999
           END-READ.
           SUBTRACT RE-AMOUNT FROM CU-BALANCE.
           MOVE WK-SYSDATE         TO CU-UPD-DATE.
           MOVE WK-USER-CODE       TO CU-UPD-USER.
           REWRITE CU-REC
               INVALID KEY
                   MOVE "Customer balance update failed"
                                   TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
       UCB-999.
           EXIT.
      *----------------------------------------------------------------
       POST-LEDGER SECTION.
       PLG-010.
           MOVE "ARLDG"            TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Ledger number assignment failed"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PLG-999
           END-IF.
           INITIALIZE AL-REC.
           MOVE KNUM-NUMBER        TO AL-SEQ.
           MOVE RE-CUST            TO AL-CUST.
           MOVE RE-DATE            TO AL-DATE.
           MOVE WK-CLOSE-YM        TO AL-CLOSE-YM.
           MOVE 2                  TO AL-KIND.
           MOVE WK-REF-RCPT        TO AL-REF-TYPE.
           MOVE RE-NO              TO AL-REF-NO.
           MOVE 0                  TO AL-DEBIT.
           MOVE RE-AMOUNT          TO AL-CREDIT.
           MOVE WK-NEW-BAL         TO AL-BALANCE.
           MOVE RE-REMARK          TO AL-REMARK.
           MOVE WK-USER-CODE       TO AL-USER.
           WRITE AL-REC
               INVALID KEY
                   MOVE "Ledger write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       PLG-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE RCPTF ARLF CUSTF BANKF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "AR0010"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
