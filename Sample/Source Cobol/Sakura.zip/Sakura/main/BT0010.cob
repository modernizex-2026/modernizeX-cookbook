       IDENTIFICATION DIVISION.
       PROGRAM-ID. BT0010.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : BT0010  -  daily close (sales posting)           *
      *  FUNCTION : reads the sales-invoice header file for a target *
      *             business date, marks each un-posted document     *
      *             (IH-STATUS 0 -> 1 posted), accumulates the day   *
      *             sales / tax / gross totals, advances the system  *
      *             control last-daily-close date and prints a run   *
      *             summary.  Console / batch (no screen section).    *
      *  RUN      : BT0010  (prompts for target date + confirm).     *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SINVH.
           COPY SSYSC.
       DATA DIVISION.
       FILE SECTION.
           COPY FINVH.
           COPY FSYSC.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- run parameters --------------------------------------------
       01  WK-PARM.
           02  WK-IN-LINE          PIC X(10) VALUE SPACE.
           02  WK-TGT-DATE         PIC 9(8)  VALUE 0.
           02  WK-DFLT-DATE        PIC 9(8)  VALUE 0.
      *----- accumulators ----------------------------------------------
       01  WK-TOTALS.
           02  WK-READ-CNT         PIC 9(7)  VALUE 0.
           02  WK-POST-CNT         PIC 9(7)  VALUE 0.
           02  WK-SKIP-CNT         PIC 9(7)  VALUE 0.
           02  WK-SALE-CNT         PIC 9(7)  VALUE 0.
           02  WK-RTN-CNT          PIC 9(7)  VALUE 0.
           02  WK-SALE-AMT         PIC S9(13) VALUE 0.
           02  WK-TAX-TOT          PIC S9(13) VALUE 0.
           02  WK-GROSS-TOT        PIC S9(13) VALUE 0.
           02  WK-COST-TOT         PIC S9(13) VALUE 0.
      *----- display edit work -----------------------------------------
       01  WK-DISP.
           02  WK-E-DATE           PIC 9999/99/99.
           02  WK-E-CNT            PIC Z,ZZZ,ZZ9.
           02  WK-E-AMT            PIC Z,ZZZ,ZZZ,ZZZ,ZZ9-.
           02  WK-E-NO             PIC ZZZZZZZZZ9.
           02  WK-AVG              PIC S9(13) VALUE 0.
      *----- misc switches ---------------------------------------------
       01  WK-FLAGS.
           02  WK-ABORT-FLG        PIC 9(1)  VALUE 0.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           IF WK-ABORT-FLG = 0
               PERFORM PROCESS-RTN
               PERFORM UPDATE-SYSCF
               PERFORM PRINT-SUMMARY
           END-IF.
           PERFORM TERM-RTN.
           MOVE 0                  TO COMPLETION-CODE.
           EXIT PROGRAM.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
      *  INIT : banner, files, system date, target parameter          *
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "BT0010"           TO WK-PROGID.
           DISPLAY " ".
           DISPLAY "==============================================".
           DISPLAY " SAKURA-SMS  BT0010  -  DAILY CLOSE".
           DISPLAY "==============================================".
           PERFORM GET-TODAY.
           PERFORM OPEN-FILES.
           PERFORM READ-SYSCF.
           DISPLAY " Company : " SY-COMPANY-NAME.
      *    default target date = day after last daily close
           MOVE "ADDD"             TO KD-FUNC.
           MOVE SY-LAST-DAY-CLOSE  TO KD-DATE1.
           MOVE 1                  TO KD-DAYS.
           CALL "DATEUT" USING KDATE.
           IF KD-STATUS = "00"
               MOVE KD-DATE1       TO WK-DFLT-DATE
           ELSE
               MOVE WK-SYSDATE     TO WK-DFLT-DATE
           END-IF.
           PERFORM ACCEPT-TARGET.
           IF WK-ABORT-FLG = 0
               PERFORM CONFIRM-RUN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       GET-TODAY SECTION.
       GTOD-010.
           MOVE "TODY"             TO KD-FUNC.
           MOVE 0                  TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE  WK-SYSYMD.
           COMPUTE WK-SYS-YM = KD-DATE1 / 100.
       GTOD-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPEN-010.
           OPEN I-O    INVHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT INVHF
               CLOSE INVHF
               OPEN I-O INVHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "INVHF"        TO KA-FILE
               MOVE "Open INVHF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O    SYSCF.
           IF FSTS NOT = "00"
               MOVE "SYSCF"        TO KA-FILE
               MOVE "Open SYSCF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OPEN-999.
           EXIT.
      *----------------------------------------------------------------
       READ-SYSCF SECTION.
       RSYS-010.
           MOVE 1                  TO SY-KEY.
           READ SYSCF
               INVALID KEY
                   MOVE "SYSCF"    TO KA-FILE
                   MOVE "System control record missing" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-READ.
       RSYS-999.
           EXIT.
      *----------------------------------------------------------------
       ACCEPT-TARGET SECTION.
       ATGT-010.
           MOVE WK-DFLT-DATE       TO WK-E-DATE.
           DISPLAY " ".
           DISPLAY " Last daily close was : "
               SY-LAST-DAY-CLOSE.
           DISPLAY " Enter target date YYYYMMDD".
           DISPLAY "   (blank = " WK-E-DATE ") : " WITH NO ADVANCING.
           MOVE SPACE              TO WK-IN-LINE.
           ACCEPT WK-IN-LINE FROM CONSOLE.
           IF WK-IN-LINE = SPACE
               MOVE WK-DFLT-DATE   TO WK-TGT-DATE
           ELSE
               IF WK-IN-LINE(1:8) NUMERIC
                   MOVE WK-IN-LINE(1:8) TO WK-TGT-DATE
               ELSE
                   DISPLAY " ** invalid date - run cancelled."
                   MOVE 1          TO WK-ABORT-FLG
                   GO TO ATGT-999
               END-IF
           END-IF.
      *    validate the date via DATEUT
           MOVE "VALD"             TO KD-FUNC.
           MOVE WK-TGT-DATE        TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           IF KD-STATUS NOT = "00"
               DISPLAY " ** date is not a valid calendar date."
               MOVE 1              TO WK-ABORT-FLG
               GO TO ATGT-999
           END-IF.
      *    a daily close must not run for a future business date
           IF WK-TGT-DATE > WK-SYSDATE
               DISPLAY " ** target date is in the future - blocked."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       ATGT-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-RUN SECTION.
       CONF-010.
           MOVE WK-TGT-DATE        TO WK-E-DATE.
           DISPLAY " ".
           DISPLAY " Post all entered invoices dated " WK-E-DATE.
           DISPLAY " Proceed ? (Y/N) : " WITH NO ADVANCING.
           MOVE SPACE              TO WK-CONFIRM.
           ACCEPT WK-CONFIRM FROM CONSOLE.
           IF NOT CONFIRM-YES
               DISPLAY " ** cancelled by operator."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       CONF-999.
           EXIT.
      *----------------------------------------------------------------
      *  PROCESS : scan invoices for the target date via IH-DATE key  *
      *----------------------------------------------------------------
       PROCESS-RTN SECTION.
       PROC-010.
           DISPLAY " ".
           DISPLAY " Posting ...".
           MOVE 0                  TO EOF-FLG.
           MOVE WK-TGT-DATE        TO IH-DATE.
           MOVE 0                  TO IH-NO.
           START INVHF KEY NOT LESS THAN IH-DATE
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           IF FSTS NOT = "00" AND FSTS NOT = "23"
                            AND FSTS NOT = "10"
               MOVE "INVHF"        TO KA-FILE
               MOVE "START INVHF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           PERFORM READ-NEXT-INV UNTIL EOF-YES.
       PROC-999.
           EXIT.
      *----------------------------------------------------------------
       READ-NEXT-INV SECTION.
       RNXT-010.
           READ INVHF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO RNXT-999
           END-READ.
           IF FSTS NOT = "00" AND FSTS NOT = "02"
               MOVE "INVHF"        TO KA-FILE
               MOVE "READ NEXT INVHF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           IF IH-DATE = WK-TGT-DATE
               PERFORM POST-ONE
           ELSE
               SET EOF-YES         TO TRUE
           END-IF.
       RNXT-999.
           EXIT.
      *----------------------------------------------------------------
       POST-ONE SECTION.
       POST-010.
           ADD 1                   TO WK-READ-CNT.
      *    only "entered" (status 0) documents are posted
           IF IH-STATUS = 0
               PERFORM ACCUM-TOTALS
               MOVE 1              TO IH-STATUS
               MOVE WK-SYSDATE     TO IH-UPD-DATE
               MOVE WK-USER-CODE   TO IH-UPD-USER
               REWRITE IH-REC
                   INVALID KEY
                       MOVE "INVHF" TO KA-FILE
                       MOVE "REWRITE INVHF failed" TO KA-DETAIL
                       PERFORM ABEND-RTN
               END-REWRITE
               IF FSTS = "00"
                   ADD 1           TO WK-POST-CNT
                   MOVE IH-NO      TO WK-E-NO
                   MOVE IH-TOTAL   TO WK-E-AMT
                   DISPLAY "   posted inv " WK-E-NO " total " WK-E-AMT
               END-IF
           ELSE
               ADD 1               TO WK-SKIP-CNT
           END-IF.
       POST-999.
           EXIT.
      *----------------------------------------------------------------
       ACCUM-TOTALS SECTION.
       ACCU-010.
      *    a return document (kind 2) reverses the day figures
           IF IH-KIND = 2
               SUBTRACT IH-AMOUNT      FROM WK-SALE-AMT
               SUBTRACT IH-TAX-AMOUNT  FROM WK-TAX-TOT
               SUBTRACT IH-TOTAL       FROM WK-GROSS-TOT
               SUBTRACT IH-COST-TOTAL  FROM WK-COST-TOT
               ADD 1                   TO WK-RTN-CNT
           ELSE
               ADD IH-AMOUNT           TO WK-SALE-AMT
               ADD IH-TAX-AMOUNT       TO WK-TAX-TOT
               ADD IH-TOTAL            TO WK-GROSS-TOT
               ADD IH-COST-TOTAL       TO WK-COST-TOT
               ADD 1                   TO WK-SALE-CNT
           END-IF.
       ACCU-999.
           EXIT.
      *----------------------------------------------------------------
      *  UPDATE-SYSCF : advance the last daily-close date             *
      *----------------------------------------------------------------
       UPDATE-SYSCF SECTION.
       USYS-010.
           MOVE 1                  TO SY-KEY.
           READ SYSCF
               INVALID KEY
                   MOVE "SYSCF"    TO KA-FILE
                   MOVE "Re-read SYSCF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-READ.
           MOVE WK-TGT-DATE        TO SY-LAST-DAY-CLOSE.
           REWRITE SY-REC
               INVALID KEY
                   MOVE "SYSCF"    TO KA-FILE
                   MOVE "REWRITE SYSCF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-REWRITE.
       USYS-999.
           EXIT.
      *----------------------------------------------------------------
      *  PRINT-SUMMARY : console run report                           *
      *----------------------------------------------------------------
       PRINT-SUMMARY SECTION.
       PSUM-010.
           MOVE WK-TGT-DATE        TO WK-E-DATE.
           DISPLAY " ".
           DISPLAY "----------------------------------------------".
           DISPLAY " DAILY CLOSE SUMMARY".
           DISPLAY "----------------------------------------------".
           DISPLAY " Target date       : " WK-E-DATE.
           MOVE WK-READ-CNT        TO WK-E-CNT.
           DISPLAY " Invoices read     : " WK-E-CNT.
           MOVE WK-POST-CNT        TO WK-E-CNT.
           DISPLAY " Invoices posted   : " WK-E-CNT.
           MOVE WK-SKIP-CNT        TO WK-E-CNT.
           DISPLAY " Already/skipped   : " WK-E-CNT.
           MOVE WK-SALE-CNT        TO WK-E-CNT.
           DISPLAY " Sale documents    : " WK-E-CNT.
           MOVE WK-RTN-CNT         TO WK-E-CNT.
           DISPLAY " Return documents  : " WK-E-CNT.
           MOVE WK-SALE-AMT        TO WK-E-AMT.
           DISPLAY " Net sales amount  : " WK-E-AMT.
           MOVE WK-TAX-TOT         TO WK-E-AMT.
           DISPLAY " Tax amount        : " WK-E-AMT.
           MOVE WK-GROSS-TOT       TO WK-E-AMT.
           DISPLAY " Gross amount      : " WK-E-AMT.
           MOVE WK-COST-TOT        TO WK-E-AMT.
           DISPLAY " Cost of sales     : " WK-E-AMT.
      *    average gross per posted document (manual divide, guard /0)
           IF WK-POST-CNT > 0
               COMPUTE WK-AVG = WK-GROSS-TOT / WK-POST-CNT
               MOVE WK-AVG         TO WK-E-AMT
               DISPLAY " Avg gross / doc   : " WK-E-AMT
           END-IF.
           DISPLAY "----------------------------------------------".
           DISPLAY " BT0010 completed normally.".
       PSUM-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE INVHF.
           CLOSE SYSCF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
      *  ABEND-RTN : log fatal error via ABORTX and stop with rc 255  *
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABND-010.
           MOVE "BT0010"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EBATCH"           TO KA-MSGCODE.
           CALL "ABORTX" USING KABEND.
           CLOSE INVHF.
           CLOSE SYSCF.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABND-999.
           EXIT.
