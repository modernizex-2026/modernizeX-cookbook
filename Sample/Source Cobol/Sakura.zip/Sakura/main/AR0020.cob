       IDENTIFICATION DIVISION.
       PROGRAM-ID. AR0020.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : AR0020  -  AR inquiry / aging                     *
      *  FUNCTION : for one customer, scan the AR ledger by the       *
      *             AL-CUST alternate key, show the current balance   *
      *             and age the outstanding amount into 0-30 / 31-60  *
      *             / 61-90 / over-90 day buckets (line age = today   *
      *             minus AL-DATE via DATEUT DIFF).  The most recent  *
      *             ledger lines are also listed.  Read-only inquiry. *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SARL.
           COPY SCUST.
       DATA DIVISION.
       FILE SECTION.
           COPY FARL.
           COPY FCUST.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-INQ.
           02  WK-KEY-CUST         PIC 9(6)  VALUE 0.
           02  WK-CUST-NAME        PIC X(40) VALUE SPACE.
           02  WK-CUR-BAL          PIC S9(11) VALUE 0.
           02  WK-DAYS             PIC S9(7) VALUE 0.
           02  WK-NET              PIC S9(11) VALUE 0.
           02  WK-LCNT             PIC 9(4)  VALUE 0.
           02  WK-ROW              PIC 9(2)  VALUE 0.
           02  WK-START            PIC 9(4)  VALUE 0.
           02  WK-KIND-LBL         PIC X(6)  VALUE SPACE.
           02  WK-TOT-DR           PIC S9(13) VALUE 0.
           02  WK-TOT-CR           PIC S9(13) VALUE 0.
           02  WK-CR-LIMIT         PIC S9(11) VALUE 0.
           02  WK-OVER             PIC X(10) VALUE SPACE.
       01  WK-BUCKETS.
           02  WK-B030             PIC S9(11) VALUE 0.
           02  WK-B060             PIC S9(11) VALUE 0.
           02  WK-B090             PIC S9(11) VALUE 0.
           02  WK-B90P             PIC S9(11) VALUE 0.
       01  WK-FLAGS.
           02  EOF-CUST            PIC 9(1)  VALUE 0.
             88  CUST-EOF                    VALUE 1.
       01  WK-DL.
           02  WK-DL-DATE          PIC 9999/99/99.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-DL-KIND          PIC X(6).
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-DL-DR            PIC ---,---,---,--9.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-DL-CR            PIC ---,---,---,--9.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-DL-BAL           PIC ---,---,---,--9.
       01  WK-LINE-TABLE.
           02  WK-ALL OCCURS 500 TIMES PIC X(78).
       01  WK-LIST-TABLE.
           02  WK-LIST OCCURS 8 TIMES PIC X(78).
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 5.
             03  COLUMN 2  VALUE "Customer Code:" COLOR YELLOW.
             03  COLUMN 20 PIC 9(6) USING WK-KEY-CUST.
       01  DS-AGE.
           02  LINE 3.
             03  COLUMN 2  VALUE "Customer :" COLOR YELLOW.
             03  COLUMN 13 PIC 9(6) FROM WK-KEY-CUST COLOR WHITE.
             03  COLUMN 22 PIC X(40) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "AR Balance :" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-CUR-BAL
                              COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Credit Lim :" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-CR-LIMIT.
             03  COLUMN 34 PIC X(10) FROM WK-OVER COLOR WHITE.
           02  LINE 6 COLUMN 2 VALUE "----- Aging -----" COLOR CYAN.
           02  LINE 7.
             03  COLUMN 2  VALUE "0 - 30 days:" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-B030
                              COLOR WHITE.
           02  LINE 8.
             03  COLUMN 2  VALUE "31 - 60 day:" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-B060
                              COLOR WHITE.
           02  LINE 9.
             03  COLUMN 2  VALUE "61 - 90 day:" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-B090
                              COLOR WHITE.
           02  LINE 10.
             03  COLUMN 2  VALUE "Over 90 day:" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-B90P
                              COLOR WHITE.
           02  LINE 11.
             03  COLUMN 2  VALUE "Debit/Cred :" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-TOT-DR.
             03  COLUMN 34 PIC ---,---,---,--9 FROM WK-TOT-CR.
           02  LINE 12 COLUMN 2 VALUE "Recent ledger lines:"
                              COLOR CYAN.
           02  LINE 13 COLUMN 2
               VALUE "Date        Kind      Debit         Credit"
               COLOR CYAN.
           02  LINE 14 COLUMN 2 PIC X(78) FROM WK-LIST (1) COLOR WHITE.
           02  LINE 15 COLUMN 2 PIC X(78) FROM WK-LIST (2) COLOR WHITE.
           02  LINE 16 COLUMN 2 PIC X(78) FROM WK-LIST (3) COLOR WHITE.
           02  LINE 17 COLUMN 2 PIC X(78) FROM WK-LIST (4) COLOR WHITE.
           02  LINE 18 COLUMN 2 PIC X(78) FROM WK-LIST (5) COLOR WHITE.
           02  LINE 19 COLUMN 2 PIC X(78) FROM WK-LIST (6) COLOR WHITE.
           02  LINE 20 COLUMN 2 PIC X(78) FROM WK-LIST (7) COLOR WHITE.
           02  LINE 21 COLUMN 2 PIC X(78) FROM WK-LIST (8) COLOR WHITE.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "AR0020"           TO WK-PROGID.
           MOVE "AR Inquiry / Aging"              TO WK-TITLE.
           MOVE "ENTER=Inquire  PF3=End"          TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           OPEN INPUT ARLF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ARLF
               CLOSE ARLF
               OPEN INPUT ARLF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ARLF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT CUSTF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT CUSTF
               CLOSE CUSTF
               OPEN INPUT CUSTF
           END-IF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-010.
           PERFORM GET-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-CUST
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       GET-KEY SECTION.
       GKEY-010.
           MOVE 0                  TO WK-KEY-CUST.
           MOVE SPACE              TO WK-CUST-NAME.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter customer code then ENTER" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
       GKEY-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-CUST SECTION.
       PC-010.
           IF WK-KEY-CUST = 0
               MOVE "Customer code must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PC-999
           END-IF.
           MOVE WK-KEY-CUST        TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "Customer not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PC-999
           END-READ.
           MOVE CU-NAME            TO WK-CUST-NAME.
           MOVE CU-BALANCE         TO WK-CUR-BAL.
           MOVE CU-CREDIT-LIMIT    TO WK-CR-LIMIT.
           IF CU-CREDIT-LIMIT > 0 AND CU-BALANCE > CU-CREDIT-LIMIT
               MOVE "OVER LIMIT"   TO WK-OVER
           ELSE
               MOVE "OK"           TO WK-OVER
           END-IF.
           PERFORM SCAN-LEDGER.
           PERFORM SHOW-RESULT.
       PC-999.
           EXIT.
      *----------------------------------------------------------------
       SCAN-LEDGER SECTION.
       SL-010.
           MOVE 0                  TO WK-B030 WK-B060 WK-B090 WK-B90P.
           MOVE 0                  TO WK-TOT-DR WK-TOT-CR.
           MOVE 0                  TO WK-LCNT EOF-CUST.
           MOVE WK-KEY-CUST        TO AL-CUST.
           MOVE 0                  TO AL-DATE.
           START ARLF KEY IS >= AL-CUST
               INVALID KEY
                   SET CUST-EOF TO TRUE
           END-START.
           PERFORM UNTIL CUST-EOF
               READ ARLF NEXT
                   AT END
                       SET CUST-EOF TO TRUE
               END-READ
               IF NOT CUST-EOF
                   IF AL-CUST NOT = WK-KEY-CUST
                       SET CUST-EOF TO TRUE
                   ELSE
                       PERFORM PROCESS-LINE
                   END-IF
               END-IF
           END-PERFORM.
       SL-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-LINE SECTION.
       PLN-010.
           ADD AL-DEBIT            TO WK-TOT-DR.
           ADD AL-CREDIT           TO WK-TOT-CR.
           PERFORM AGE-LINE.
           IF WK-LCNT < 500
               ADD 1               TO WK-LCNT
               PERFORM FORMAT-LINE
               MOVE WK-DL          TO WK-ALL (WK-LCNT)
           END-IF.
       PLN-999.
           EXIT.
      *----------------------------------------------------------------
       AGE-LINE SECTION.
       AGL-010.
           COMPUTE WK-NET = AL-DEBIT - AL-CREDIT.
           MOVE "DIFF"             TO KD-FUNC.
           MOVE AL-DATE            TO KD-DATE1.
           MOVE WK-SYSDATE         TO KD-DATE2.
           MOVE 0                  TO KD-DAYS.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DAYS            TO WK-DAYS.
           IF WK-DAYS < 0
               MOVE 0              TO WK-DAYS
           END-IF.
           EVALUATE TRUE
               WHEN WK-DAYS <= 30
                   ADD WK-NET      TO WK-B030
               WHEN WK-DAYS <= 60
                   ADD WK-NET      TO WK-B060
               WHEN WK-DAYS <= 90
                   ADD WK-NET      TO WK-B090
               WHEN OTHER
                   ADD WK-NET      TO WK-B90P
           END-EVALUATE.
       AGL-999.
           EXIT.
      *----------------------------------------------------------------
       FORMAT-LINE SECTION.
       FMT-010.
           PERFORM KIND-LABEL.
           MOVE AL-DATE            TO WK-DL-DATE.
           MOVE WK-KIND-LBL        TO WK-DL-KIND.
           MOVE AL-DEBIT           TO WK-DL-DR.
           MOVE AL-CREDIT          TO WK-DL-CR.
           MOVE AL-BALANCE         TO WK-DL-BAL.
       FMT-999.
           EXIT.
      *----------------------------------------------------------------
       KIND-LABEL SECTION.
       KLB-010.
           EVALUATE AL-KIND
               WHEN 1
                   MOVE "Sale  " TO WK-KIND-LBL
               WHEN 2
                   MOVE "Recpt " TO WK-KIND-LBL
               WHEN 3
                   MOVE "Retn  " TO WK-KIND-LBL
               WHEN 4
                   MOVE "Adjust" TO WK-KIND-LBL
               WHEN OTHER
                   MOVE "Other " TO WK-KIND-LBL
           END-EVALUATE.
       KLB-999.
           EXIT.
      *----------------------------------------------------------------
       SHOW-RESULT SECTION.
       SR-010.
           PERFORM LOAD-RECENT.
           MOVE "Ledger scanned - press any key" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-AGE.
           ACCEPT  DS-AGE.
           IF ESTS = "03"
               SET END-YES TO TRUE
           END-IF.
       SR-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-RECENT SECTION.
       LR-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > 8
               MOVE SPACE          TO WK-LIST (WK-IDX)
           END-PERFORM.
           IF WK-LCNT = 0
               GO TO LR-999
           END-IF.
           IF WK-LCNT <= 8
               MOVE 1              TO WK-START
           ELSE
               COMPUTE WK-START = WK-LCNT - 7
           END-IF.
           MOVE 0                  TO WK-ROW.
           PERFORM VARYING WK-IDX FROM WK-START BY 1
                   UNTIL WK-IDX > WK-LCNT
               ADD 1               TO WK-ROW
               MOVE WK-ALL (WK-IDX) TO WK-LIST (WK-ROW)
           END-PERFORM.
       LR-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE ARLF CUSTF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "AR0020"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
