       IDENTIFICATION DIVISION.
       PROGRAM-ID. RC0010.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RC0010  -  Goods receiving entry                 *
      *  FUNCTION : receive goods against an open purchase order.    *
      *             The PO is recalled by number; every outstanding  *
      *             line (ordered minus already received) is offered *
      *             for receipt.  On confirmation a receiving header *
      *             (RCVHF) and its detail (RCVDF) are created with  *
      *             the number from NUMGEN "RECV".  For each line    *
      *             the on-hand stock is increased, on-order is      *
      *             decreased, the moving-average cost is recomputed *
      *             and a purchase-in movement (SMOVF SM-KIND=20) is *
      *             written with NUMGEN "STKMOV".  The PO detail     *
      *             received quantity and the PO status (1 part /    *
      *             2 fully received) are updated.                   *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SPOH.
           COPY SPOD.
           COPY SRCVH.
           COPY SRCVD.
           COPY SSTOK.
           COPY SSMOV.
           COPY SSUPP.
           COPY SPROD.
       I-O-CONTROL.
           APPLY SHARED-MODE ON POHF
           APPLY SHARED-MODE ON PODF
           APPLY SHARED-MODE ON RCVHF
           APPLY SHARED-MODE ON RCVDF
           APPLY SHARED-MODE ON STOKF
           APPLY SHARED-MODE ON SMOVF.
       DATA DIVISION.
       FILE SECTION.
           COPY FPOH.
           COPY FPOD.
           COPY FRCVH.
           COPY FRCVD.
           COPY FSTOK.
           COPY FSMOV.
           COPY FSUPP.
           COPY FPROD.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
      *----- control switches ------------------------------------------
       01  WK-FLAGS2.
           02  PO-OK               PIC 9(1)  VALUE 0.
             88  PO-YES                      VALUE 1.
           02  WK-ENTRY-DONE       PIC 9(1)  VALUE 0.
           02  WK-OUT-FLG          PIC 9(1)  VALUE 0.
      *----- key / header work -----------------------------------------
       01  WK-KEYS.
           02  WK-PO-KEY           PIC 9(10) VALUE 0.
           02  WK-RH-NO-D          PIC 9(10) VALUE 0.
           02  WK-SUPP-NAME        PIC X(40) VALUE SPACE.
      *----- receiving-line work counters ------------------------------
       01  WK-COUNTERS.
           02  WK-CURLINE          PIC 9(3)  VALUE 0.
           02  WK-RECV-CNT         PIC 9(3)  VALUE 0.
           02  WK-RD-LINE          PIC 9(3)  VALUE 0.
           02  WK-NEW-STATUS       PIC 9(1)  VALUE 0.
           02  WK-NEW-ONHAND       PIC S9(9) VALUE 0.
           02  WK-AVG-NUM          PIC S9(13)V9(2) VALUE 0.
           02  WK-RECV-DATE        PIC 9(8)  VALUE 0.
      *----- current line display / entry fields -----------------------
       01  WK-LDISP.
           02  WK-L-POS            PIC 9(3)  VALUE 0.
           02  WK-L-POLINE         PIC 9(3)  VALUE 0.
           02  WK-L-PROD           PIC 9(8)  VALUE 0.
           02  WK-L-NAME           PIC X(40) VALUE SPACE.
           02  WK-L-ORD            PIC S9(9) VALUE 0.
           02  WK-L-PRECV          PIC S9(9) VALUE 0.
           02  WK-L-OUT            PIC S9(9) VALUE 0.
           02  WK-L-COST           PIC S9(9)V9(2) VALUE 0.
           02  WK-D-RECV           PIC S9(9) VALUE 0.
      *----- outstanding PO line table ---------------------------------
       01  WK-LINE-TABLE.
           02  WK-LCNT             PIC 9(3)  VALUE 0.
           02  WK-RLINE OCCURS 200.
             03  WL-POLINE         PIC 9(3).
             03  WL-PROD           PIC 9(8).
             03  WL-WHSE           PIC 9(3).
             03  WL-NAME           PIC X(40).
             03  WL-ORD            PIC S9(9).
             03  WL-PRECV          PIC S9(9).
             03  WL-OUT            PIC S9(9).
             03  WL-COST           PIC S9(9)V9(2).
             03  WL-RECV           PIC S9(9).
             03  WL-STKMNG         PIC 9(1).
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4.
             03  COLUMN 2  VALUE "PO Number  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(10) USING WK-PO-KEY.
       01  DS-PINFO.
           02  LINE 3.
             03  COLUMN 2  VALUE "PO No     :" COLOR YELLOW.
             03  COLUMN 14 PIC ZZZZZZZZZ9 FROM PH-NO COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "Supplier  :" COLOR YELLOW.
             03  COLUMN 14 PIC 9(6) FROM PH-SUPP COLOR WHITE.
             03  COLUMN 22 PIC X(40) FROM WK-SUPP-NAME COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Warehouse :" COLOR YELLOW.
             03  COLUMN 14 PIC 9(3) FROM PH-WHSE COLOR WHITE.
       01  DS-RDATE.
           02  LINE 6.
             03  COLUMN 2  VALUE "Recv Date :" COLOR YELLOW.
             03  COLUMN 14 PIC 9(8) USING RH-DATE.
       01  DS-LINE.
           02  LINE 8.
             03  COLUMN 2  VALUE "Item      :" COLOR YELLOW.
             03  COLUMN 14 PIC ZZ9 FROM WK-L-POS COLOR WHITE.
             03  COLUMN 18 VALUE "of" COLOR YELLOW.
             03  COLUMN 21 PIC ZZ9 FROM WK-LCNT COLOR WHITE.
             03  COLUMN 30 VALUE "PO line:" COLOR YELLOW.
             03  COLUMN 39 PIC ZZ9 FROM WK-L-POLINE COLOR WHITE.
           02  LINE 9.
             03  COLUMN 2  VALUE "Product   :" COLOR YELLOW.
             03  COLUMN 14 PIC 9(8) FROM WK-L-PROD COLOR WHITE.
             03  COLUMN 24 PIC X(40) FROM WK-L-NAME COLOR WHITE.
           02  LINE 10.
             03  COLUMN 2  VALUE "Ordered   :" COLOR YELLOW.
             03  COLUMN 14 PIC ----,---,--9 FROM WK-L-ORD COLOR WHITE.
           02  LINE 11.
             03  COLUMN 2  VALUE "Already   :" COLOR YELLOW.
             03  COLUMN 14 PIC ----,---,--9 FROM WK-L-PRECV COLOR WHITE.
           02  LINE 12.
             03  COLUMN 2  VALUE "Outstandng:" COLOR YELLOW.
             03  COLUMN 14 PIC ----,---,--9 FROM WK-L-OUT COLOR WHITE.
           02  LINE 13.
             03  COLUMN 2  VALUE "Unit Cost :" COLOR YELLOW.
             03  COLUMN 14 PIC ---,--9.99 FROM WK-L-COST COLOR WHITE.
           02  LINE 14.
             03  COLUMN 2  VALUE "Receive   :" COLOR YELLOW.
             03  COLUMN 14 PIC S9(9) USING WK-D-RECV.
       01  DS-CONFIRM.
           02  LINE 19.
             03  COLUMN 2  VALUE "Lines to receive :" COLOR YELLOW.
             03  COLUMN 22 PIC ZZ9 FROM WK-RECV-CNT COLOR WHITE.
           02  LINE 20.
             03  COLUMN 2  VALUE "Post receiving ? (Y/N) :"
                              COLOR YELLOW.
             03  COLUMN 28 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RC0010"           TO WK-PROGID.
           MOVE "Goods Receiving Entry"            TO WK-TITLE.
           MOVE "ENTER=Accept  PF4=Skip line  PF3=End" TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           PERFORM OPEN-IO-FILE-POH.
           PERFORM OPEN-IO-FILE-POD.
           PERFORM OPEN-IO-FILE-RCVH.
           PERFORM OPEN-IO-FILE-RCVD.
           PERFORM OPEN-IO-FILE-STOK.
           PERFORM OPEN-IO-FILE-SMOV.
           OPEN INPUT SUPPF.
           OPEN INPUT PRODF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-POH SECTION.
       OFPH-010.
           OPEN I-O POHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT POHF
               CLOSE POHF
               OPEN I-O POHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "POHF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFPH-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-POD SECTION.
       OFPD-010.
           OPEN I-O PODF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PODF
               CLOSE PODF
               OPEN I-O PODF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "PODF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFPD-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-RCVH SECTION.
       OFRH-010.
           OPEN I-O RCVHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT RCVHF
               CLOSE RCVHF
               OPEN I-O RCVHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "RCVHF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFRH-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-RCVD SECTION.
       OFRD-010.
           OPEN I-O RCVDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT RCVDF
               CLOSE RCVDF
               OPEN I-O RCVDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "RCVDF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFRD-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-STOK SECTION.
       OFSK-010.
           OPEN I-O STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFSK-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-IO-FILE-SMOV SECTION.
       OFSM-010.
           OPEN I-O SMOVF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SMOVF
               CLOSE SMOVF
               OPEN I-O SMOVF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SMOVF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OFSM-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-010.
           PERFORM CLEAR-RECV.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter the purchase order number to receive"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-PO
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-RECV SECTION.
       CLRR-010.
           MOVE 0                  TO WK-PO-KEY WK-RH-NO-D.
           MOVE 0                  TO WK-LCNT WK-RECV-CNT.
           MOVE 0                  TO PO-OK WK-ENTRY-DONE.
           MOVE SPACE              TO WK-SUPP-NAME WK-CONFIRM.
           MOVE WK-SYSDATE         TO RH-DATE.
       CLRR-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-PO SECTION.
       PPO-010.
           IF WK-PO-KEY = 0
               MOVE "PO number required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PPO-999
           END-IF.
           MOVE WK-PO-KEY          TO PH-NO.
           READ POHF
               INVALID KEY
                   MOVE "PO not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PPO-999
           END-READ.
           IF PH-DEL-FLAG = 1
               MOVE "PO is deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PPO-999
           END-IF.
           IF PH-STATUS = 9
               MOVE "PO is cancelled" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PPO-999
           END-IF.
           IF PH-STATUS = 2 OR PH-STATUS = 3
               MOVE "PO already fully received" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PPO-999
           END-IF.
           PERFORM LOOKUP-SUPP-NAME.
           PERFORM LOAD-PO-LINES.
           IF WK-LCNT = 0
               MOVE "No outstanding lines on this PO" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PPO-999
           END-IF.
           MOVE 1                  TO PO-OK.
           PERFORM ACCEPT-RHEADER.
           IF NOT PO-YES
               GO TO PPO-999
           END-IF.
           PERFORM ENTER-RECV-LINES.
           PERFORM COUNT-RECV-LINES.
           IF WK-RECV-CNT > 0
               PERFORM CONFIRM-SAVE
           ELSE
               MOVE "Nothing received - discarded" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       PPO-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-SUPP-NAME SECTION.
       LSN-010.
           MOVE SPACE              TO WK-SUPP-NAME.
           MOVE PH-SUPP            TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE "??? unknown supplier" TO WK-SUPP-NAME
               NOT INVALID KEY
                   MOVE SP-NAME    TO WK-SUPP-NAME
           END-READ.
       LSN-999.
           EXIT.
      *----------------------------------------------------------------
      *  Build a table of PO lines that still have quantity to come.
      *----------------------------------------------------------------
       LOAD-PO-LINES SECTION.
       LPL-010.
           MOVE 0                  TO WK-LCNT.
           MOVE PH-NO              TO PD-NO.
           MOVE 0                  TO PD-LINE.
           START PODF KEY IS NOT < PD-NO
               INVALID KEY
                   GO TO LPL-999
           END-START.
           MOVE 0                  TO EOF-FLG.
           PERFORM UNTIL EOF-YES
               READ PODF NEXT
                   AT END
                       SET EOF-YES TO TRUE
                   NOT AT END
                       IF PD-NO NOT = PH-NO
                           SET EOF-YES TO TRUE
                       ELSE
                           PERFORM ADD-OUTSTANDING
                       END-IF
               END-READ
           END-PERFORM.
       LPL-999.
           EXIT.
      *----------------------------------------------------------------
       ADD-OUTSTANDING SECTION.
       AOS-010.
           IF PD-STATUS = 9
               GO TO AOS-999
           END-IF.
           IF PD-RECV-QTY >= PD-QTY
               GO TO AOS-999
           END-IF.
           IF WK-LCNT >= 200
               GO TO AOS-999
           END-IF.
           ADD 1                   TO WK-LCNT.
           MOVE PD-LINE            TO WL-POLINE (WK-LCNT).
           MOVE PD-PROD            TO WL-PROD   (WK-LCNT).
           MOVE PD-WHSE            TO WL-WHSE   (WK-LCNT).
           MOVE PD-QTY             TO WL-ORD    (WK-LCNT).
           MOVE PD-RECV-QTY        TO WL-PRECV  (WK-LCNT).
           COMPUTE WL-OUT (WK-LCNT) = PD-QTY - PD-RECV-QTY.
           MOVE PD-UNIT-COST       TO WL-COST   (WK-LCNT).
           MOVE WL-OUT (WK-LCNT)   TO WL-RECV   (WK-LCNT).
           PERFORM LOOKUP-PROD-NAME.
       AOS-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-PROD-NAME SECTION.
       LPN-010.
           MOVE SPACE              TO WL-NAME (WK-LCNT).
           MOVE 0                  TO WL-STKMNG (WK-LCNT).
           MOVE PD-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "??? unknown product" TO WL-NAME (WK-LCNT)
               NOT INVALID KEY
                   MOVE PR-NAME    TO WL-NAME   (WK-LCNT)
                   MOVE PR-STOCK-MNG TO WL-STKMNG (WK-LCNT)
           END-READ.
       LPN-999.
           EXIT.
      *----------------------------------------------------------------
       ACCEPT-RHEADER SECTION.
       ARH-010.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           DISPLAY DS-PINFO.
           MOVE "Confirm receiving date - PF3 to cancel"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-RDATE.
           ACCEPT  DS-RDATE.
           IF ESTS = "03"
               MOVE 0              TO PO-OK
               MOVE "Cancelled"    TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       ARH-999.
           EXIT.
      *----------------------------------------------------------------
      *  Present each outstanding line and capture the received qty.
      *----------------------------------------------------------------
       ENTER-RECV-LINES SECTION.
       ERL-010.
           MOVE 1                  TO WK-CURLINE.
           MOVE 0                  TO WK-ENTRY-DONE.
           PERFORM UNTIL WK-ENTRY-DONE = 1 OR WK-CURLINE > WK-LCNT
               PERFORM SHOW-RECV-LINE
               ACCEPT DS-LINE
               EVALUATE ESTS
                   WHEN "03"
                       MOVE 1 TO WK-ENTRY-DONE
                   WHEN "04"
                       MOVE 0 TO WL-RECV (WK-CURLINE)
                       MOVE "Line skipped" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                       ADD 1 TO WK-CURLINE
                   WHEN "00"
                       PERFORM VALIDATE-RECV-LINE
                       IF NOT ERR-YES
                           ADD 1 TO WK-CURLINE
                       END-IF
                   WHEN OTHER
                       MOVE "Invalid key" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-EVALUATE
           END-PERFORM.
       ERL-999.
           EXIT.
      *----------------------------------------------------------------
       SHOW-RECV-LINE SECTION.
       SRL-010.
           MOVE WK-CURLINE         TO WK-L-POS.
           MOVE WL-POLINE (WK-CURLINE) TO WK-L-POLINE.
           MOVE WL-PROD   (WK-CURLINE) TO WK-L-PROD.
           MOVE WL-NAME   (WK-CURLINE) TO WK-L-NAME.
           MOVE WL-ORD    (WK-CURLINE) TO WK-L-ORD.
           MOVE WL-PRECV  (WK-CURLINE) TO WK-L-PRECV.
           MOVE WL-OUT    (WK-CURLINE) TO WK-L-OUT.
           MOVE WL-COST   (WK-CURLINE) TO WK-L-COST.
           MOVE WL-RECV   (WK-CURLINE) TO WK-D-RECV.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           DISPLAY DS-PINFO.
           DISPLAY DS-LINE.
           MOVE "Enter received qty (0 to skip)" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       SRL-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-RECV-LINE SECTION.
       VRL-010.
           MOVE 0                  TO ERR-FLG.
           IF WK-D-RECV < 0
               MOVE "Received qty cannot be negative" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               DISPLAY DS-MSG
               GO TO VRL-999
           END-IF.
           IF WK-D-RECV > WL-OUT (WK-CURLINE)
               MOVE "Received qty exceeds outstanding" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               DISPLAY DS-MSG
               GO TO VRL-999
           END-IF.
           MOVE WK-D-RECV          TO WL-RECV (WK-CURLINE).
       VRL-999.
           EXIT.
      *----------------------------------------------------------------
       COUNT-RECV-LINES SECTION.
       CRL-010.
           MOVE 0                  TO WK-RECV-CNT.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-LCNT
               IF WL-RECV (WK-IDX) > 0
                   ADD 1 TO WK-RECV-CNT
               END-IF
           END-PERFORM.
       CRL-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-SAVE SECTION.
       CSAV-010.
           MOVE SPACE              TO WK-CONFIRM.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           DISPLAY DS-PINFO.
           DISPLAY DS-CONFIRM.
           MOVE "Confirm to post receiving" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               PERFORM SAVE-RECV
           ELSE
               MOVE "Receiving discarded" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CSAV-999.
           EXIT.
      *----------------------------------------------------------------
      *  Write the receiving header, then post every received line.
      *----------------------------------------------------------------
       SAVE-RECV SECTION.
       SRV-010.
           MOVE "RECV"             TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Receiving number assignment failed" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO SRV-999
           END-IF.
           MOVE RH-DATE            TO WK-RECV-DATE.
           INITIALIZE RH-REC.
           MOVE KNUM-NUMBER        TO RH-NO  WK-RH-NO-D.
           MOVE WK-RECV-DATE       TO RH-DATE.
           MOVE PH-NO              TO RH-PO.
           MOVE PH-SUPP            TO RH-SUPP.
           MOVE PH-WHSE            TO RH-WHSE.
           MOVE 0                  TO RH-STATUS.
           MOVE WK-RECV-CNT        TO RH-LINES.
           MOVE SPACE              TO RH-REMARK.
           MOVE WK-SYSDATE         TO RH-ADD-DATE.
           MOVE WK-USER-CODE       TO RH-ADD-USER.
           MOVE 0                  TO RH-DEL-FLAG.
           WRITE RH-REC
               INVALID KEY
                   MOVE "Receiving header write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO SRV-999
           END-WRITE.
           MOVE 0                  TO WK-RD-LINE.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > WK-LCNT
               IF WL-RECV (WK-IDX) > 0
                   PERFORM POST-ONE-LINE
               END-IF
           END-PERFORM.
           PERFORM UPDATE-PO-STATUS.
           MOVE "Receiving posted"  TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       SRV-999.
           EXIT.
      *----------------------------------------------------------------
       POST-ONE-LINE SECTION.
       POL-010.
           ADD 1                   TO WK-RD-LINE.
           INITIALIZE RD-REC.
           MOVE RH-NO              TO RD-NO.
           MOVE WK-RD-LINE         TO RD-LINE.
           MOVE PH-NO              TO RD-PO.
           MOVE WL-POLINE (WK-IDX) TO RD-PO-LINE.
           MOVE WL-PROD   (WK-IDX) TO RD-PROD.
           MOVE WL-WHSE   (WK-IDX) TO RD-WHSE.
           MOVE WL-RECV   (WK-IDX) TO RD-QTY.
           MOVE WL-COST   (WK-IDX) TO RD-UNIT-COST.
           COMPUTE RD-AMOUNT ROUNDED =
               WL-RECV (WK-IDX) * WL-COST (WK-IDX).
           WRITE RD-REC
               INVALID KEY
                   CONTINUE
           END-WRITE.
           IF WL-STKMNG (WK-IDX) = 1
               PERFORM UPDATE-STOCK-IN
               PERFORM WRITE-MOVEMENT
           END-IF.
           PERFORM UPDATE-PO-LINE.
       POL-999.
           EXIT.
      *----------------------------------------------------------------
      *  Increase on-hand, decrease on-order, recompute average cost.
      *----------------------------------------------------------------
       UPDATE-STOCK-IN SECTION.
       USI-010.
           MOVE WL-PROD (WK-IDX)   TO SK-PROD.
           MOVE WL-WHSE (WK-IDX)   TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   PERFORM CREATE-STOCK
               NOT INVALID KEY
                   PERFORM ADJUST-STOCK
           END-READ.
       USI-999.
           EXIT.
      *----------------------------------------------------------------
       CREATE-STOCK SECTION.
       CST-010.
           INITIALIZE SK-REC.
           MOVE WL-PROD (WK-IDX)   TO SK-PROD.
           MOVE WL-WHSE (WK-IDX)   TO SK-WHSE.
           MOVE WL-RECV (WK-IDX)   TO SK-ONHAND.
           MOVE 0                  TO SK-ALLOCATED.
           COMPUTE SK-ON-ORDER = 0 - WL-RECV (WK-IDX).
           IF SK-ON-ORDER < 0
               MOVE 0              TO SK-ON-ORDER
           END-IF.
           MOVE WL-COST (WK-IDX)   TO SK-AVG-COST.
           MOVE RH-DATE            TO SK-LAST-IN-DATE.
           MOVE WL-RECV (WK-IDX)   TO SK-YTD-IN.
           WRITE SK-REC
               INVALID KEY
                   CONTINUE
           END-WRITE.
       CST-999.
           EXIT.
      *----------------------------------------------------------------
       ADJUST-STOCK SECTION.
       ADJ-010.
           COMPUTE WK-NEW-ONHAND = SK-ONHAND + WL-RECV (WK-IDX).
           IF WK-NEW-ONHAND > 0
               COMPUTE WK-AVG-NUM ROUNDED =
                   (SK-ONHAND * SK-AVG-COST)
                   + (WL-RECV (WK-IDX) * WL-COST (WK-IDX))
               COMPUTE SK-AVG-COST ROUNDED =
                   WK-AVG-NUM / WK-NEW-ONHAND
           END-IF.
           MOVE WK-NEW-ONHAND      TO SK-ONHAND.
           SUBTRACT WL-RECV (WK-IDX) FROM SK-ON-ORDER.
           MOVE RH-DATE            TO SK-LAST-IN-DATE.
           ADD WL-RECV (WK-IDX)    TO SK-YTD-IN.
           REWRITE SK-REC
               INVALID KEY
                   CONTINUE
           END-REWRITE.
       ADJ-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-MOVEMENT SECTION.
       WMV-010.
           MOVE "STKMOV"           TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               GO TO WMV-999
           END-IF.
           INITIALIZE SM-REC.
           MOVE KNUM-NUMBER        TO SM-SEQ.
           MOVE RH-DATE            TO SM-DATE.
           MOVE WL-PROD (WK-IDX)   TO SM-PROD.
           MOVE WL-WHSE (WK-IDX)   TO SM-WHSE.
           MOVE 20                 TO SM-KIND.
           MOVE WL-RECV (WK-IDX)   TO SM-QTY.
           MOVE WL-COST (WK-IDX)   TO SM-UNIT-COST.
           MOVE SK-ONHAND          TO SM-BAL-AFTER.
           MOVE 22                 TO SM-REF-TYPE.
           MOVE RH-NO              TO SM-REF-NO.
           MOVE WK-USER-CODE       TO SM-USER.
           WRITE SM-REC
               INVALID KEY
                   CONTINUE
           END-WRITE.
       WMV-999.
           EXIT.
      *----------------------------------------------------------------
       UPDATE-PO-LINE SECTION.
       UPL-010.
           MOVE PH-NO              TO PD-NO.
           MOVE WL-POLINE (WK-IDX) TO PD-LINE.
           READ PODF
               INVALID KEY
                   GO TO UPL-999
           END-READ.
           ADD WL-RECV (WK-IDX)    TO PD-RECV-QTY.
           IF PD-RECV-QTY >= PD-QTY
               MOVE 2              TO PD-STATUS
           ELSE
               MOVE 1              TO PD-STATUS
           END-IF.
           REWRITE PD-REC
               INVALID KEY
                   CONTINUE
           END-REWRITE.
       UPL-999.
           EXIT.
      *----------------------------------------------------------------
      *  Re-scan the PO detail to set header status 1 part / 2 full.
      *----------------------------------------------------------------
       UPDATE-PO-STATUS SECTION.
       UPS-010.
           MOVE 0                  TO WK-OUT-FLG.
           MOVE PH-NO              TO PD-NO.
           MOVE 0                  TO PD-LINE.
           START PODF KEY IS NOT < PD-NO
               INVALID KEY
                   GO TO UPS-020
           END-START.
           MOVE 0                  TO EOF-FLG.
           PERFORM UNTIL EOF-YES
               READ PODF NEXT
                   AT END
                       SET EOF-YES TO TRUE
                   NOT AT END
                       IF PD-NO NOT = PH-NO
                           SET EOF-YES TO TRUE
                       ELSE
                           IF PD-STATUS NOT = 9
                             AND PD-RECV-QTY < PD-QTY
                               MOVE 1 TO WK-OUT-FLG
                           END-IF
                       END-IF
               END-READ
           END-PERFORM.
       UPS-020.
           IF WK-OUT-FLG = 1
               MOVE 1              TO WK-NEW-STATUS
           ELSE
               MOVE 2              TO WK-NEW-STATUS
           END-IF.
           MOVE WK-PO-KEY          TO PH-NO.
           READ POHF
               INVALID KEY
                   GO TO UPS-999
           END-READ.
           MOVE WK-NEW-STATUS      TO PH-STATUS.
           REWRITE PH-REC
               INVALID KEY
                   CONTINUE
           END-REWRITE.
       UPS-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE POHF PODF RCVHF RCVDF STOKF SMOVF SUPPF PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "RC0010"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
