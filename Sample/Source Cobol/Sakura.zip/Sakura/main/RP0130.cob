       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0130.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0130  -  Customer statement of account         *
      *  FUNCTION : print one statement block per customer for a     *
      *             customer-code range and a sales-date period.     *
      *             For each customer the opening balance (net of     *
      *             all ledger entries dated before the period) is   *
      *             shown, then every AR ledger line in the period    *
      *             in date order (date, kind label, debit, credit,   *
      *             running balance), then the closing balance.       *
      *             Each customer starts on a fresh page.  132-column *
      *             line-sequential batch text report.               *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SCUST.
           COPY SARL.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FCUST.
           COPY FARL.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0130.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- control flags ---------------------------------------------
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
           02  WK-ARL-EOF          PIC 9(1)  VALUE 0.
             88  ARL-EOF                     VALUE 1.
           02  WK-HDR-DONE         PIC 9(1)  VALUE 0.
      *----- console parameters ----------------------------------------
       01  WK-PARM.
           02  WK-IN-CFROM         PIC X(6)  VALUE SPACE.
           02  WK-IN-CTO           PIC X(6)  VALUE SPACE.
           02  WK-IN-DFROM         PIC X(8)  VALUE SPACE.
           02  WK-IN-DTO           PIC X(8)  VALUE SPACE.
           02  WK-CUST-FROM        PIC 9(6)  VALUE 0.
           02  WK-CUST-TO          PIC 9(6)  VALUE 999999.
           02  WK-DATE-FROM        PIC 9(8)  VALUE 0.
           02  WK-DATE-TO          PIC 9(8)  VALUE 99999999.
      *----- per-customer accumulators ---------------------------------
       01  WK-ACC.
           02  WK-OPEN             PIC S9(13) COMP-3 VALUE 0.
           02  WK-RUN              PIC S9(13) COMP-3 VALUE 0.
           02  WK-NET              PIC S9(13) COMP-3 VALUE 0.
       01  WK-LINE-CNT            PIC 9(7)  VALUE 0.
       01  WK-STMT-CNT           PIC 9(7)  VALUE 0.
       01  WK-KIND-TXT           PIC X(10) VALUE SPACE.
       01  WK-COMPANY            PIC X(40) VALUE SPACE.
      *----- report layout ---------------------------------------------
       01  RPT-RULE               PIC X(106) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RD-STMT.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "CUSTOMER: ".
           02  ST-CODE            PIC 9(6).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  ST-NAME            PIC X(40).
       01  RC-HEAD.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(10) VALUE "   DATE".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(10) VALUE "KIND".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(10) VALUE "      REF#".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(24) VALUE "DESCRIPTION".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(15) VALUE "          DEBIT".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(15) VALUE "         CREDIT".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(15) VALUE "        BALANCE".
       01  RD-LINE.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-DATE   PIC 9999/99/99.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-KIND   PIC X(10).
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-REF    PIC ZZZZZZZZZ9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-REMARK PIC X(24).
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-DEBIT  PIC ---,---,---,--9  BLANK WHEN ZERO.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-CREDIT PIC ---,---,---,--9  BLANK WHEN ZERO.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-BAL    PIC ---,---,---,--9.
       01  RD-OPEN.
           02  FILLER    PIC X(91) VALUE " OPENING BALANCE".
           02  OP-BAL    PIC ---,---,---,--9.
       01  RD-CLOSE.
           02  FILLER    PIC X(91) VALUE " CLOSING BALANCE".
           02  CL-BAL    PIC ---,---,---,--9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PARM-RTN.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0130"           TO WK-PROGID.
           MOVE "CUSTOMER STATEMENT"           TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT CUSTF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "CUSTF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT ARLF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PARM-RTN SECTION.
       PARM-010.
           DISPLAY "RP0130 - Customer statement".
           DISPLAY "From customer code (blank=first): ".
           ACCEPT  WK-IN-CFROM FROM CONSOLE.
           DISPLAY "To   customer code (blank=last ): ".
           ACCEPT  WK-IN-CTO   FROM CONSOLE.
           DISPLAY "Period start YYYYMMDD (blank=earliest): ".
           ACCEPT  WK-IN-DFROM FROM CONSOLE.
           DISPLAY "Period end   YYYYMMDD (blank=latest  ): ".
           ACCEPT  WK-IN-DTO   FROM CONSOLE.
           IF WK-IN-CFROM NUMERIC AND WK-IN-CFROM NOT = SPACE
               MOVE WK-IN-CFROM    TO WK-CUST-FROM
           ELSE
               MOVE 0              TO WK-CUST-FROM
           END-IF.
           IF WK-IN-CTO NUMERIC AND WK-IN-CTO NOT = SPACE
               MOVE WK-IN-CTO      TO WK-CUST-TO
           ELSE
               MOVE 999999         TO WK-CUST-TO
           END-IF.
           IF WK-IN-DFROM NUMERIC AND WK-IN-DFROM NOT = SPACE
               MOVE WK-IN-DFROM    TO WK-DATE-FROM
           ELSE
               MOVE 0              TO WK-DATE-FROM
           END-IF.
           IF WK-IN-DTO NUMERIC AND WK-IN-DTO NOT = SPACE
               MOVE WK-IN-DTO      TO WK-DATE-TO
           ELSE
               MOVE 99999999       TO WK-DATE-TO
           END-IF.
       PARM-999.
           EXIT.
      *----------------------------------------------------------------
      *  PRINT : walk customer master in the requested code range
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRINT-010.
           MOVE 99                 TO WK-LINE.
           MOVE 0                  TO WK-STMT-CNT.
           IF NOT MAIN-EOF
               MOVE WK-CUST-FROM   TO CU-CODE
               START CUSTF KEY NOT < CU-CODE
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-CUST UNTIL MAIN-EOF.
           PERFORM PRINT-NONE.
       PRINT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-CUST SECTION.
       RDC-010.
           READ CUSTF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   IF CU-CODE > WK-CUST-TO
                       MOVE 1      TO WK-MAIN-EOF
                   ELSE
                       IF CU-DEL-FLAG NOT = 1
                           PERFORM SCAN-CUST
                       END-IF
                   END-IF
           END-READ.
       RDC-999.
           EXIT.
      *----------------------------------------------------------------
      *  SCAN-CUST : read this customer's ledger in date order, split
      *  into opening (pre-period) and in-period lines
      *----------------------------------------------------------------
       SCAN-CUST SECTION.
       SC-010.
           MOVE 0                  TO WK-OPEN.
           MOVE 0                  TO WK-RUN.
           MOVE 0                  TO WK-HDR-DONE.
           MOVE 0                  TO WK-LINE-CNT.
           MOVE 0                  TO WK-ARL-EOF.
           MOVE CU-CODE            TO AL-CUST.
           MOVE 0                  TO AL-DATE.
           START ARLF KEY NOT < AL-CUST
               INVALID KEY
                   MOVE 1          TO WK-ARL-EOF
           END-START.
           PERFORM SC-READ UNTIL ARL-EOF.
           PERFORM FINISH-CUST.
       SC-999.
           EXIT.
      *----------------------------------------------------------------
       SC-READ SECTION.
       SCR-010.
           READ ARLF NEXT
               AT END
                   MOVE 1          TO WK-ARL-EOF
               NOT AT END
                   IF AL-CUST NOT = CU-CODE
                       MOVE 1      TO WK-ARL-EOF
                   ELSE
                       PERFORM CLASSIFY-LINE
                   END-IF
           END-READ.
       SCR-999.
           EXIT.
      *----------------------------------------------------------------
       CLASSIFY-LINE SECTION.
       CL-010.
           COMPUTE WK-NET = AL-DEBIT - AL-CREDIT.
           IF AL-DATE < WK-DATE-FROM
               ADD WK-NET          TO WK-OPEN
               GO TO CL-999
           END-IF.
           IF AL-DATE > WK-DATE-TO
               MOVE 1              TO WK-ARL-EOF
               GO TO CL-999
           END-IF.
           IF WK-HDR-DONE = 0
               PERFORM OPEN-STATEMENT
           END-IF.
           ADD WK-NET              TO WK-RUN.
           PERFORM PRINT-LEDGER-LINE.
           ADD 1                   TO WK-LINE-CNT.
       CL-999.
           EXIT.
      *----------------------------------------------------------------
      *  OPEN-STATEMENT : begin a customer's statement on a new page
      *----------------------------------------------------------------
       OPEN-STATEMENT SECTION.
       OS-010.
           PERFORM NEW-PAGE.
           MOVE CU-CODE            TO ST-CODE.
           MOVE CU-NAME            TO ST-NAME.
           MOVE RD-STMT            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE RC-HEAD            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE WK-OPEN            TO OP-BAL.
           MOVE RD-OPEN            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE WK-OPEN            TO WK-RUN.
           MOVE 1                  TO WK-HDR-DONE.
       OS-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-LEDGER-LINE SECTION.
       PLL-010.
           PERFORM CHECK-PAGE.
           MOVE AL-DATE            TO RL-DATE.
           PERFORM KIND-LABEL.
           MOVE WK-KIND-TXT        TO RL-KIND.
           MOVE AL-REF-NO          TO RL-REF.
           MOVE AL-REMARK          TO RL-REMARK.
           MOVE AL-DEBIT           TO RL-DEBIT.
           MOVE AL-CREDIT          TO RL-CREDIT.
           MOVE WK-RUN             TO RL-BAL.
           MOVE RD-LINE            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
       PLL-999.
           EXIT.
      *----------------------------------------------------------------
       KIND-LABEL SECTION.
       KL-010.
           EVALUATE AL-KIND
               WHEN 1   MOVE "SALE"    TO WK-KIND-TXT
               WHEN 2   MOVE "RECEIPT" TO WK-KIND-TXT
               WHEN 3   MOVE "RETURN"  TO WK-KIND-TXT
               WHEN 4   MOVE "ADJUST"  TO WK-KIND-TXT
               WHEN OTHER MOVE "OTHER" TO WK-KIND-TXT
           END-EVALUATE.
       KL-999.
           EXIT.
      *----------------------------------------------------------------
      *  FINISH-CUST : print closing balance / handle opening-only
      *----------------------------------------------------------------
       FINISH-CUST SECTION.
       FC-010.
           IF WK-HDR-DONE = 1
               PERFORM CHECK-PAGE
               MOVE RPT-RULE       TO REP-REC
               WRITE REP-REC
               ADD 1               TO WK-LINE
               MOVE WK-RUN         TO CL-BAL
               MOVE RD-CLOSE       TO REP-REC
               WRITE REP-REC
               ADD 1               TO WK-LINE
               ADD 1               TO WK-STMT-CNT
               GO TO FC-999
           END-IF.
           IF WK-OPEN NOT = 0
               PERFORM OPEN-STATEMENT
               MOVE " (no ledger activity in this period)" TO REP-REC
               WRITE REP-REC
               ADD 1               TO WK-LINE
               PERFORM CHECK-PAGE
               MOVE RPT-RULE       TO REP-REC
               WRITE REP-REC
               ADD 1               TO WK-LINE
               MOVE WK-OPEN        TO CL-BAL
               MOVE RD-CLOSE       TO REP-REC
               WRITE REP-REC
               ADD 1               TO WK-LINE
               ADD 1               TO WK-STMT-CNT
           END-IF.
       FC-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
               PERFORM STMT-SUBHEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       NEW-PAGE SECTION.
       NP-010.
           MOVE 99                 TO WK-LINE.
           PERFORM PAGE-HEAD.
       NP-999.
           EXIT.
      *----------------------------------------------------------------
      *  STMT-SUBHEAD : continuation header when a statement overflows
      *----------------------------------------------------------------
       STMT-SUBHEAD SECTION.
       SSH-010.
           MOVE CU-CODE            TO ST-CODE.
           MOVE CU-NAME            TO ST-NAME.
           MOVE RD-STMT            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE RC-HEAD            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
       SSH-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           STRING "PERIOD " WK-DATE-FROM " - " WK-DATE-TO
               DELIMITED BY SIZE INTO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE 4                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-NONE SECTION.
       PN-010.
           IF WK-STMT-CNT = 0
               PERFORM NEW-PAGE
               MOVE "*** NO CUSTOMER STATEMENTS TO PRINT ***"
                                   TO REP-REC
               WRITE REP-REC
           END-IF.
       PN-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE CUSTF ARLF REPF.
           DISPLAY "RP0130 complete.  Statements printed = "
               WK-STMT-CNT.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0130"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
