       IDENTIFICATION DIVISION.
       PROGRAM-ID. IV0020.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : IV0020  -  Stock adjustment                       *
      *  FUNCTION : adjust the on-hand quantity of one product in one *
      *             warehouse.  The current balance is displayed, a   *
      *             signed adjustment quantity (+ increase / -        *
      *             decrease) and a reason are entered, and on         *
      *             confirmation SK-ONHAND is updated and a stock      *
      *             movement of kind 30 (adjust) is written to SMOVF  *
      *             with the sequence number assigned by NUMGEN.      *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SSTOK.
           COPY SSMOV.
           COPY SPROD.
           COPY SWHSE.
       I-O-CONTROL.
           APPLY SHARED-MODE ON STOKF
           APPLY SHARED-MODE ON SMOVF.
       DATA DIVISION.
       FILE SECTION.
           COPY FSTOK.
           COPY FSMOV.
           COPY FPROD.
           COPY FWHSE.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-ADJ.
           02  WK-KEY-PROD         PIC 9(8)  VALUE 0.
           02  WK-KEY-WHSE         PIC 9(3)  VALUE 0.
           02  WK-ADJ-QTY          PIC S9(9) VALUE 0.
           02  WK-NEW-ONHAND       PIC S9(9) VALUE 0.
           02  WK-REASON           PIC X(30) VALUE SPACE.
           02  WK-PR-NAME          PIC X(40) VALUE SPACE.
           02  WK-WH-NAME          PIC X(30) VALUE SPACE.
       01  WK-FLAGS.
           02  STK-FLG             PIC 9(1)  VALUE 0.
             88  STK-NEW                     VALUE 1.
             88  STK-OLD                     VALUE 2.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4.
             03  COLUMN 2  VALUE "Product Code :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(8) USING WK-KEY-PROD.
             03  COLUMN 30 PIC X(40) FROM WK-PR-NAME COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Warehouse    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(3) USING WK-KEY-WHSE.
             03  COLUMN 30 PIC X(30) FROM WK-WH-NAME COLOR WHITE.
       01  DS-ADJ.
           02  LINE 8.
             03  COLUMN 2  VALUE "Current OnHand:" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM SK-ONHAND COLOR WHITE.
           02  LINE 9.
             03  COLUMN 2  VALUE "Allocated    :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM SK-ALLOCATED
                              COLOR WHITE.
           02  LINE 10.
             03  COLUMN 2  VALUE "Avg Cost     :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9.99 FROM SK-AVG-COST
                              COLOR WHITE.
           02  LINE 12.
             03  COLUMN 2  VALUE "Adjustment   :" COLOR YELLOW.
             03  COLUMN 20 PIC S9(9) USING WK-ADJ-QTY.
             03  COLUMN 34 VALUE "(+ add / - remove)" COLOR CYAN.
           02  LINE 13.
             03  COLUMN 2  VALUE "Reason       :" COLOR YELLOW.
             03  COLUMN 20 PIC X(30) USING WK-REASON.
       01  DS-CONFIRM.
           02  LINE 15.
             03  COLUMN 2  VALUE "New OnHand   :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM WK-NEW-ONHAND
                              COLOR WHITE.
           02  LINE 17 COLUMN 2 VALUE "Confirm (Y/N):" COLOR YELLOW.
           02  SC-CONF LINE 17 COLUMN 20 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "IV0020"           TO WK-PROGID.
           MOVE "Stock Adjustment"                TO WK-TITLE.
           MOVE "ENTER=Read  PF3=End  PF4=Clear"  TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           OPEN I-O   STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O   SMOVF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SMOVF
               CLOSE SMOVF
               OPEN I-O SMOVF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SMOVF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT PRODF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PRODF
               CLOSE PRODF
               OPEN INPUT PRODF
           END-IF.
           OPEN INPUT WHSEF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT WHSEF
               CLOSE WHSEF
               OPEN INPUT WHSEF
           END-IF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-010.
           PERFORM GET-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-KEY
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       GET-KEY SECTION.
       GKEY-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter product and warehouse" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
       GKEY-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLRW-010.
           INITIALIZE SK-REC.
           MOVE 0                  TO WK-KEY-PROD WK-KEY-WHSE.
           MOVE 0                  TO WK-ADJ-QTY WK-NEW-ONHAND.
           MOVE SPACE              TO WK-REASON WK-CONFIRM.
           MOVE SPACE              TO WK-PR-NAME WK-WH-NAME.
           MOVE 0                  TO STK-FLG.
       CLRW-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-KEY SECTION.
       PKEY-010.
           IF WK-KEY-PROD = 0
               MOVE "Product code must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
           PERFORM VALIDATE-MASTERS.
           IF ERR-YES
               GO TO PKEY-999
           END-IF.
           PERFORM READ-STOCK.
           PERFORM ENTER-ADJ.
       PKEY-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-MASTERS SECTION.
       VMST-010.
           MOVE 0                  TO ERR-FLG.
           MOVE WK-KEY-PROD        TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "Product not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VMST-999
           END-READ.
           IF PR-DEL-FLAG = 1
               MOVE "Product is deleted" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VMST-999
           END-IF.
           MOVE PR-NAME            TO WK-PR-NAME.
           MOVE WK-KEY-WHSE        TO WH-CODE.
           READ WHSEF
               INVALID KEY
                   MOVE "Warehouse not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VMST-999
           END-READ.
           IF WH-DEL-FLAG = 1
               MOVE "Warehouse is deleted" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VMST-999
           END-IF.
           MOVE WH-NAME            TO WK-WH-NAME.
       VMST-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       READ-STOCK SECTION.
       RSTK-010.
           MOVE WK-KEY-PROD        TO SK-PROD.
           MOVE WK-KEY-WHSE        TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   PERFORM SETUP-NEW-STOCK
               NOT INVALID KEY
                   SET STK-OLD TO TRUE
                   MOVE "Stock found - enter adjustment"
                                   TO WK-MSG-LINE
           END-READ.
       RSTK-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-NEW-STOCK SECTION.
       SNEW-010.
           SET STK-NEW TO TRUE.
           INITIALIZE SK-REC.
           MOVE WK-KEY-PROD        TO SK-PROD.
           MOVE WK-KEY-WHSE        TO SK-WHSE.
           MOVE PR-STD-COST        TO SK-AVG-COST.
           MOVE "No stock record - will be created" TO WK-MSG-LINE.
       SNEW-999.
           EXIT.
      *----------------------------------------------------------------
       ENTER-ADJ SECTION.
       EADJ-010.
           DISPLAY DS-MSG.
           DISPLAY DS-ADJ.
           ACCEPT  DS-ADJ.
           EVALUATE ESTS
               WHEN "03"
                   CONTINUE
               WHEN "04"
                   MOVE "Cancelled" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               WHEN "00"
                   PERFORM VALIDATE-ADJ
                   IF NOT ERR-YES
                       PERFORM CONFIRM-ADJ
                   END-IF
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       EADJ-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-ADJ SECTION.
       VADJ-010.
           MOVE 0                  TO ERR-FLG.
           IF WK-ADJ-QTY = 0
               MOVE "Adjustment quantity must not be zero"
                                   TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VADJ-999
           END-IF.
           COMPUTE WK-NEW-ONHAND = SK-ONHAND + WK-ADJ-QTY.
           IF WK-NEW-ONHAND < 0
               MOVE "Result would be negative - not allowed"
                                   TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VADJ-999
           END-IF.
           IF WK-REASON = SPACE
               MOVE "Reason is required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
           END-IF.
       VADJ-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       CONFIRM-ADJ SECTION.
       CADJ-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Confirm the new on-hand (Y/N)" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               PERFORM POST-ADJ
           ELSE
               MOVE "Adjustment cancelled" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CADJ-999.
           EXIT.
      *----------------------------------------------------------------
       POST-ADJ SECTION.
       PADJ-010.
           MOVE WK-NEW-ONHAND      TO SK-ONHAND.
           IF WK-ADJ-QTY > 0
               MOVE WK-SYSDATE     TO SK-LAST-IN-DATE
               ADD  WK-ADJ-QTY     TO SK-YTD-IN
           ELSE
               MOVE WK-SYSDATE     TO SK-LAST-OUT-DATE
               SUBTRACT WK-ADJ-QTY FROM SK-YTD-OUT
           END-IF.
           IF STK-NEW
               WRITE SK-REC
                   INVALID KEY
                       MOVE "Stock write failed" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                       GO TO PADJ-999
               END-WRITE
           ELSE
               REWRITE SK-REC
                   INVALID KEY
                       MOVE "Stock update failed" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                       GO TO PADJ-999
               END-REWRITE
           END-IF.
           PERFORM WRITE-MOVEMENT.
           MOVE "Adjustment posted"  TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       PADJ-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-MOVEMENT SECTION.
       WMOV-010.
           MOVE "STKMOV"           TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Movement number assignment failed"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO WMOV-999
           END-IF.
           INITIALIZE SM-REC.
           MOVE KNUM-NUMBER        TO SM-SEQ.
           MOVE WK-SYSDATE         TO SM-DATE.
           MOVE SK-PROD            TO SM-PROD.
           MOVE SK-WHSE            TO SM-WHSE.
           MOVE 30                 TO SM-KIND.
           MOVE WK-ADJ-QTY         TO SM-QTY.
           MOVE SK-AVG-COST        TO SM-UNIT-COST.
           MOVE SK-ONHAND          TO SM-BAL-AFTER.
           MOVE 30                 TO SM-REF-TYPE.
           MOVE KNUM-NUMBER        TO SM-REF-NO.
           MOVE WK-USER-CODE       TO SM-USER.
           WRITE SM-REC
               INVALID KEY
                   MOVE "Movement write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       WMOV-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE STOKF SMOVF PRODF WHSEF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "IV0020"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
