       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0100.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0100  -  Purchase journal (purchase register)  *
      *  FUNCTION : list purchases (PURHF) and their detail lines    *
      *             (PURDF) for a purchase-date range.  Print each   *
      *             purchase header, its lines, a per-document       *
      *             subtotal (net/tax/total) and grand totals.       *
      *             132-column batch text report.                    *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SPURH.
           COPY SPURD.
           COPY SSUPP.
           COPY SPROD.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FPURH.
           COPY FPURD.
           COPY FSUPP.
           COPY FPROD.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0100.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
           02  WK-DTL-EOF          PIC 9(1)  VALUE 0.
             88  DTL-EOF                     VALUE 1.
       01  WK-PARM.
           02  WK-IN-FROM          PIC X(8)  VALUE SPACE.
           02  WK-IN-TO            PIC X(8)  VALUE SPACE.
           02  WK-DATE-FROM        PIC 9(8)  VALUE 0.
           02  WK-DATE-TO          PIC 9(8)  VALUE 99999999.
       01  WK-SUPP-NAME            PIC X(30) VALUE SPACE.
       01  WK-PROD-NAME            PIC X(26) VALUE SPACE.
       01  WK-KIND-TXT             PIC X(8)  VALUE SPACE.
       01  WK-COMPANY              PIC X(40) VALUE SPACE.
       01  WK-COUNTS.
           02  WK-PUR-CNT          PIC 9(7)  VALUE 0.
           02  WK-LIN-CNT          PIC 9(7)  VALUE 0.
       01  WK-TOTALS.
           02  WK-G-NET            PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-TAX            PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-TOT            PIC S9(15) COMP-3 VALUE 0.
       01  RPT-RULE               PIC X(120) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RD-PURH.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PUR# ".
           02  VH-NO-E            PIC 9(10).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "DATE ".
           02  VH-DATE-E          PIC 9999/99/99.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "SUPP ".
           02  VH-SUPP-E          PIC 9(6).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  VH-SNAME           PIC X(30).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  VH-KIND-E          PIC X(8).
       01  RD-PURD.
           02  FILLER             PIC X(6)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "LINE ".
           02  VD-LINE-E          PIC 9(3).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PROD ".
           02  VD-PROD-E          PIC 9(8).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  VD-PNAME           PIC X(26).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(4)  VALUE "QTY ".
           02  VD-QTY-E           PIC ----,---,--9.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "COST ".
           02  VD-COST-E          PIC ---,---,--9.99.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(4)  VALUE "AMT ".
           02  VD-AMT-E           PIC ---,---,---,--9.
       01  RD-SUB.
           02  FILLER             PIC X(6)  VALUE SPACE.
           02  FILLER             PIC X(31) VALUE
               "PURCHASE SUBTOTAL NET / TAX / T".
           02  SUB-NET            PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  SUB-TAX            PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  SUB-TOT            PIC ---,---,---,--9.
       01  RD-GRAND.
           02  FILLER             PIC X(6)  VALUE SPACE.
           02  FILLER             PIC X(31) VALUE
               "GRAND TOTAL       NET / TAX / T".
           02  GT-NET             PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  GT-TAX             PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  GT-TOT             PIC ---,---,---,--9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PARM-RTN.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0100"           TO WK-PROGID.
           MOVE "PURCHASE JOURNAL"              TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT PURHF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "PURHF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT PURDF.
           OPEN INPUT SUPPF.
           OPEN INPUT PRODF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PARM-RTN SECTION.
       PARM-010.
           DISPLAY "RP0100 - Purchase journal".
           DISPLAY "From purchase date YYYYMMDD (blank=earliest): ".
           ACCEPT  WK-IN-FROM FROM CONSOLE.
           DISPLAY "To   purchase date YYYYMMDD (blank=latest  ): ".
           ACCEPT  WK-IN-TO   FROM CONSOLE.
           IF WK-IN-FROM NUMERIC AND WK-IN-FROM NOT = SPACE
               MOVE WK-IN-FROM     TO WK-DATE-FROM
           ELSE
               MOVE 0              TO WK-DATE-FROM
           END-IF.
           IF WK-IN-TO NUMERIC AND WK-IN-TO NOT = SPACE
               MOVE WK-IN-TO       TO WK-DATE-TO
           ELSE
               MOVE 99999999       TO WK-DATE-TO
           END-IF.
       PARM-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRINT-010.
           MOVE 0                  TO WK-PUR-CNT WK-LIN-CNT.
           MOVE 99                 TO WK-LINE.
           IF NOT MAIN-EOF
               MOVE 0              TO VH-NO
               START PURHF KEY NOT < VH-NO
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-HDR UNTIL MAIN-EOF.
           PERFORM PRINT-GRAND.
       PRINT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-HDR SECTION.
       RH-010.
           READ PURHF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   PERFORM PROCESS-PURCH
           END-READ.
       RH-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-PURCH SECTION.
       PP-010.
           IF VH-DEL-FLAG = 1 OR VH-STATUS = 9
               GO TO PP-999
           END-IF.
           IF VH-DATE < WK-DATE-FROM OR VH-DATE > WK-DATE-TO
               GO TO PP-999
           END-IF.
           PERFORM CHECK-PAGE-HDR.
           PERFORM LOOKUP-SUPP.
           EVALUATE VH-KIND
               WHEN 2   MOVE "RETURN"  TO WK-KIND-TXT
               WHEN OTHER MOVE "PURCH" TO WK-KIND-TXT
           END-EVALUATE.
           MOVE VH-NO             TO VH-NO-E.
           MOVE VH-DATE           TO VH-DATE-E.
           MOVE VH-SUPP           TO VH-SUPP-E.
           MOVE WK-SUPP-NAME      TO VH-SNAME.
           MOVE WK-KIND-TXT       TO VH-KIND-E.
           MOVE RD-PURH           TO REP-REC.
           WRITE REP-REC.
           ADD 1                  TO WK-LINE.
           ADD 1                  TO WK-PUR-CNT.
           PERFORM PRINT-DETAILS.
           PERFORM PRINT-SUBTOTAL.
           ADD VH-AMOUNT          TO WK-G-NET.
           ADD VH-TAX-AMOUNT      TO WK-G-TAX.
           ADD VH-TOTAL           TO WK-G-TOT.
       PP-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-DETAILS SECTION.
       PD-010.
           MOVE 0                  TO WK-DTL-EOF.
           MOVE VH-NO              TO VD-NO.
           MOVE 0                  TO VD-LINE.
           START PURDF KEY NOT < VD-NO
               INVALID KEY
                   MOVE 1          TO WK-DTL-EOF
           END-START.
           PERFORM READ-DTL UNTIL DTL-EOF.
       PD-999.
           EXIT.
      *----------------------------------------------------------------
       READ-DTL SECTION.
       RDT-010.
           READ PURDF NEXT
               AT END
                   MOVE 1          TO WK-DTL-EOF
               NOT AT END
                   IF VD-NO NOT = VH-NO
                       MOVE 1      TO WK-DTL-EOF
                   ELSE
                       PERFORM PRINT-ONE-DTL
                   END-IF
           END-READ.
       RDT-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-ONE-DTL SECTION.
       POD-010.
           PERFORM CHECK-PAGE.
           PERFORM LOOKUP-PROD.
           MOVE VD-LINE           TO VD-LINE-E.
           MOVE VD-PROD           TO VD-PROD-E.
           MOVE WK-PROD-NAME      TO VD-PNAME.
           MOVE VD-QTY            TO VD-QTY-E.
           MOVE VD-UNIT-COST      TO VD-COST-E.
           MOVE VD-AMOUNT         TO VD-AMT-E.
           MOVE RD-PURD           TO REP-REC.
           WRITE REP-REC.
           ADD 1                  TO WK-LINE.
           ADD 1                  TO WK-LIN-CNT.
       POD-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-SUBTOTAL SECTION.
       PS-010.
           PERFORM CHECK-PAGE.
           MOVE VH-AMOUNT         TO SUB-NET.
           MOVE VH-TAX-AMOUNT     TO SUB-TAX.
           MOVE VH-TOTAL          TO SUB-TOT.
           MOVE RD-SUB            TO REP-REC.
           WRITE REP-REC.
           ADD 1                  TO WK-LINE.
           MOVE SPACE             TO REP-REC.
           WRITE REP-REC.
           ADD 1                  TO WK-LINE.
       PS-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-SUPP SECTION.
       LKS-010.
           MOVE SPACE             TO WK-SUPP-NAME.
           MOVE VH-SUPP           TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE "(unknown)" TO WK-SUPP-NAME
               NOT INVALID KEY
                   MOVE SP-NAME     TO WK-SUPP-NAME
           END-READ.
       LKS-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-PROD SECTION.
       LKP-010.
           MOVE SPACE             TO WK-PROD-NAME.
           MOVE VD-PROD           TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "(unknown)" TO WK-PROD-NAME
               NOT INVALID KEY
                   MOVE PR-NAME     TO WK-PROD-NAME
           END-READ.
       LKP-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE-HDR SECTION.
       CPH-010.
           IF WK-LINE >= 50
               PERFORM PAGE-HEAD
           END-IF.
       CPH-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           STRING "PERIOD " WK-DATE-FROM " - " WK-DATE-TO
               DELIMITED BY SIZE INTO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE 5                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-GRAND SECTION.
       PG-010.
           IF WK-PUR-CNT = 0
               PERFORM CHECK-PAGE-HDR
               MOVE "*** NO PURCHASES IN THE SELECTED PERIOD ***"
                                   TO REP-REC
               WRITE REP-REC
               GO TO PG-999
           END-IF.
           PERFORM CHECK-PAGE.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-G-NET           TO GT-NET.
           MOVE WK-G-TAX           TO GT-TAX.
           MOVE WK-G-TOT           TO GT-TOT.
           MOVE RD-GRAND           TO REP-REC.
           WRITE REP-REC.
       PG-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE PURHF PURDF SUPPF PRODF REPF.
           DISPLAY "RP0100 complete.  Purchases = " WK-PUR-CNT
               "  Lines = " WK-LIN-CNT.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0100"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
