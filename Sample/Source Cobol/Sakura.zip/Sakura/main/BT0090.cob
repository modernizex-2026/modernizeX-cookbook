       IDENTIFICATION DIVISION.
       PROGRAM-ID. BT0090.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : BT0090  -  data integrity check                  *
      *  FUNCTION : batch / console utility that scans the main       *
      *             transaction and stock files for referential and  *
      *             value problems and lists each one as an          *
      *             exception, both on the console and in the text    *
      *             report reports/BT0090.TXT.  Checks performed:     *
      *               (a) order-detail lines whose order header is    *
      *                   missing            (ORDDF -> ORDHF)         *
      *               (b) invoice-detail lines whose invoice header   *
      *                   is missing         (INVDF -> INVHF)         *
      *               (c) stock rows whose product is missing         *
      *                   in the product master (STOKF -> PRODF)      *
      *               (d) stock rows with a negative on-hand qty      *
      *             Category counts and a CLEAN / DIRTY verdict are   *
      *             produced.  COMPLETION-CODE 4 on exceptions.
      *             found, otherwise 0.  No screen section.           *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SORDD.
           COPY SORDH.
           COPY SINVD.
           COPY SINVH.
           COPY SSTOK.
           COPY SPROD.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FORDD.
           COPY FORDH.
           COPY FINVD.
           COPY FINVH.
           COPY FSTOK.
           COPY FPROD.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "BT0090.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- control flags ---------------------------------------------
       01  WK-FLAGS.
           02  WK-ABORT-FLG        PIC 9(1)  VALUE 0.
           02  WK-EOF              PIC 9(1)  VALUE 0.
      *----- record counters -------------------------------------------
       01  WK-COUNTS.
           02  WK-ORDD-CNT         PIC 9(7)  VALUE 0.
           02  WK-INVD-CNT         PIC 9(7)  VALUE 0.
           02  WK-STOK-CNT         PIC 9(7)  VALUE 0.
      *----- exception counters ----------------------------------------
       01  WK-EXC.
           02  WK-EX-ORPH-OD       PIC 9(7)  VALUE 0.
           02  WK-EX-ORPH-ID       PIC 9(7)  VALUE 0.
           02  WK-EX-PROD          PIC 9(7)  VALUE 0.
           02  WK-EX-NEG           PIC 9(7)  VALUE 0.
           02  WK-EX-TOTAL         PIC 9(7)  VALUE 0.
      *----- work / display edits --------------------------------------
       01  WK-MSGTXT             PIC X(50) VALUE SPACE.
       01  WK-EN                 PIC ----,---,--9.
       01  WK-E-CNT              PIC Z,ZZZ,ZZ9.
       01  WK-COMPANY            PIC X(40) VALUE SPACE.
      *----- report layout ---------------------------------------------
       01  RPT-RULE               PIC X(103) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RD-SECT.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  SECT-TXT           PIC X(60).
       01  RD-EX.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  EX-TAG             PIC X(20).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  EX-KEY1LBL         PIC X(6).
           02  EX-KEY1            PIC ZZZZZZZZZ9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  EX-KEY2LBL         PIC X(6).
           02  EX-KEY2            PIC ZZZZZ9.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  EX-MSG             PIC X(50).
       01  RD-CNT.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  SM-LBL             PIC X(45).
           02  SM-VAL             PIC Z,ZZZ,ZZ9.
       01  RD-VERD.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  VERD-TXT           PIC X(60).
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           IF WK-ABORT-FLG = 0
               PERFORM WRITE-REPORT-HEAD
               PERFORM CHECK-ORDD
               PERFORM CHECK-INVD
               PERFORM CHECK-STOK-PROD
               PERFORM CHECK-STOK-NEG
               PERFORM PRINT-SUMMARY
           END-IF.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "BT0090"           TO WK-PROGID.
           DISPLAY " ".
           DISPLAY "==============================================".
           DISPLAY " SAKURA-SMS  BT0090  -  DATA INTEGRITY CHECK".
           DISPLAY "==============================================".
           PERFORM GET-TODAY.
           PERFORM OPEN-FILES.
           PERFORM CONFIRM-RUN.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       GET-TODAY SECTION.
       GTOD-010.
           MOVE "TODY"             TO KD-FUNC.
           MOVE 0                  TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
       GTOD-999.
           EXIT.
      *----------------------------------------------------------------
      *  OPEN-FILES : make sure each input file exists, then open it
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPEN-010.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT ORDDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ORDDF
               CLOSE ORDDF
               OPEN INPUT ORDDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ORDDF"        TO KA-FILE
               MOVE "Open ORDDF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT ORDHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ORDHF
               CLOSE ORDHF
               OPEN INPUT ORDHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ORDHF"        TO KA-FILE
               MOVE "Open ORDHF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT INVDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT INVDF
               CLOSE INVDF
               OPEN INPUT INVDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "INVDF"        TO KA-FILE
               MOVE "Open INVDF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT INVHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT INVHF
               CLOSE INVHF
               OPEN INPUT INVHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "INVHF"        TO KA-FILE
               MOVE "Open INVHF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN INPUT STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF"        TO KA-FILE
               MOVE "Open STOKF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT PRODF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PRODF
               CLOSE PRODF
               OPEN INPUT PRODF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "PRODF"        TO KA-FILE
               MOVE "Open PRODF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               MOVE "Open report file failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OPEN-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-RUN SECTION.
       CONF-010.
           DISPLAY " ".
           DISPLAY " Scan transaction / stock files for integrity".
           DISPLAY " problems (read-only).  Proceed ? (Y/N) [Y] : "
               WITH NO ADVANCING.
           MOVE SPACE              TO WK-CONFIRM.
           ACCEPT WK-CONFIRM FROM CONSOLE.
           IF CONFIRM-NO
               DISPLAY " ** cancelled by operator."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       CONF-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-REPORT-HEAD SECTION.
       WRH-010.
           MOVE 99                 TO WK-LINE.
           PERFORM PAGE-HEAD.
       WRH-999.
           EXIT.
      *----------------------------------------------------------------
      *  (a) ORDDF -> ORDHF orphan check                               *
      *----------------------------------------------------------------
       CHECK-ORDD SECTION.
       COD-010.
           MOVE "(A) ORPHAN ORDER-DETAIL LINES  (ORDDF vs ORDHF)"
                                   TO SECT-TXT.
           PERFORM WRITE-SECTION.
           MOVE 0                  TO WK-EOF.
           MOVE 0                  TO OD-NO.
           MOVE 0                  TO OD-LINE.
           START ORDDF KEY NOT < OD-NO
               INVALID KEY
                   MOVE 1          TO WK-EOF
           END-START.
           PERFORM COD-NEXT UNTIL WK-EOF = 1.
       COD-999.
           EXIT.
       COD-NEXT SECTION.
       CODN-010.
           READ ORDDF NEXT
               AT END
                   MOVE 1          TO WK-EOF
                   GO TO CODN-999
           END-READ.
           IF FSTS NOT = "00" AND FSTS NOT = "02"
               MOVE "ORDDF"        TO KA-FILE
               MOVE "READ NEXT ORDDF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           ADD 1                   TO WK-ORDD-CNT.
           MOVE OD-NO              TO OH-NO.
           READ ORDHF
               INVALID KEY
                   PERFORM REPORT-ORPH-OD
           END-READ.
       CODN-999.
           EXIT.
      *----------------------------------------------------------------
       REPORT-ORPH-OD SECTION.
       ROD-010.
           ADD 1                   TO WK-EX-ORPH-OD.
           ADD 1                   TO WK-EX-TOTAL.
           MOVE "ORPHAN ORDER-DTL"  TO EX-TAG.
           MOVE "DOC#  "           TO EX-KEY1LBL.
           MOVE OD-NO              TO EX-KEY1.
           MOVE "LINE  "           TO EX-KEY2LBL.
           MOVE OD-LINE            TO EX-KEY2.
           MOVE "order header not found in ORDHF" TO EX-MSG.
           PERFORM WRITE-EXCEPTION.
       ROD-999.
           EXIT.
      *----------------------------------------------------------------
      *  (b) INVDF -> INVHF orphan check                               *
      *----------------------------------------------------------------
       CHECK-INVD SECTION.
       CID-010.
           MOVE "(B) ORPHAN INVOICE-DETAIL LINES  (INVDF vs INVHF)"
                                   TO SECT-TXT.
           PERFORM WRITE-SECTION.
           MOVE 0                  TO WK-EOF.
           MOVE 0                  TO ID-NO.
           MOVE 0                  TO ID-LINE.
           START INVDF KEY NOT < ID-NO
               INVALID KEY
                   MOVE 1          TO WK-EOF
           END-START.
           PERFORM CID-NEXT UNTIL WK-EOF = 1.
       CID-999.
           EXIT.
       CID-NEXT SECTION.
       CIDN-010.
           READ INVDF NEXT
               AT END
                   MOVE 1          TO WK-EOF
                   GO TO CIDN-999
           END-READ.
           IF FSTS NOT = "00" AND FSTS NOT = "02"
               MOVE "INVDF"        TO KA-FILE
               MOVE "READ NEXT INVDF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           ADD 1                   TO WK-INVD-CNT.
           MOVE ID-NO              TO IH-NO.
           READ INVHF
               INVALID KEY
                   PERFORM REPORT-ORPH-ID
           END-READ.
       CIDN-999.
           EXIT.
      *----------------------------------------------------------------
       REPORT-ORPH-ID SECTION.
       RID-010.
           ADD 1                   TO WK-EX-ORPH-ID.
           ADD 1                   TO WK-EX-TOTAL.
           MOVE "ORPHAN INV-DTL"    TO EX-TAG.
           MOVE "DOC#  "           TO EX-KEY1LBL.
           MOVE ID-NO             TO EX-KEY1.
           MOVE "LINE  "           TO EX-KEY2LBL.
           MOVE ID-LINE           TO EX-KEY2.
           MOVE "invoice header not found in INVHF" TO EX-MSG.
           PERFORM WRITE-EXCEPTION.
       RID-999.
           EXIT.
      *----------------------------------------------------------------
      *  (c) STOKF -> PRODF missing-product check                      *
      *----------------------------------------------------------------
       CHECK-STOK-PROD SECTION.
       CSP-010.
           MOVE "(C) STOCK ROWS WITH MISSING PRODUCT  (STOKF vs PRODF)"
                                   TO SECT-TXT.
           PERFORM WRITE-SECTION.
           MOVE 0                  TO WK-EOF.
           MOVE 0                  TO SK-PROD.
           MOVE 0                  TO SK-WHSE.
           START STOKF KEY NOT < SK-PROD
               INVALID KEY
                   MOVE 1          TO WK-EOF
           END-START.
           PERFORM CSP-NEXT UNTIL WK-EOF = 1.
       CSP-999.
           EXIT.
       CSP-NEXT SECTION.
       CSPN-010.
           READ STOKF NEXT
               AT END
                   MOVE 1          TO WK-EOF
                   GO TO CSPN-999
           END-READ.
           IF FSTS NOT = "00" AND FSTS NOT = "02"
               MOVE "STOKF"        TO KA-FILE
               MOVE "READ NEXT STOKF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           ADD 1                   TO WK-STOK-CNT.
           MOVE SK-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   PERFORM REPORT-MISS-PROD
           END-READ.
       CSPN-999.
           EXIT.
      *----------------------------------------------------------------
       REPORT-MISS-PROD SECTION.
       RMP-010.
           ADD 1                   TO WK-EX-PROD.
           ADD 1                   TO WK-EX-TOTAL.
           MOVE "MISSING PRODUCT"   TO EX-TAG.
           MOVE "PROD  "           TO EX-KEY1LBL.
           MOVE SK-PROD           TO EX-KEY1.
           MOVE "WHSE  "           TO EX-KEY2LBL.
           MOVE SK-WHSE           TO EX-KEY2.
           MOVE "product code not found in PRODF" TO EX-MSG.
           PERFORM WRITE-EXCEPTION.
       RMP-999.
           EXIT.
      *----------------------------------------------------------------
      *  (d) STOKF negative on-hand check                              *
      *----------------------------------------------------------------
       CHECK-STOK-NEG SECTION.
       CSN-010.
           MOVE "(D) STOCK ROWS WITH NEGATIVE ON-HAND  (STOKF)"
                                   TO SECT-TXT.
           PERFORM WRITE-SECTION.
           MOVE 0                  TO WK-EOF.
           MOVE 0                  TO SK-PROD.
           MOVE 0                  TO SK-WHSE.
           START STOKF KEY NOT < SK-PROD
               INVALID KEY
                   MOVE 1          TO WK-EOF
           END-START.
           PERFORM CSN-NEXT UNTIL WK-EOF = 1.
       CSN-999.
           EXIT.
       CSN-NEXT SECTION.
       CSNN-010.
           READ STOKF NEXT
               AT END
                   MOVE 1          TO WK-EOF
                   GO TO CSNN-999
           END-READ.
           IF FSTS NOT = "00" AND FSTS NOT = "02"
               MOVE "STOKF"        TO KA-FILE
               MOVE "READ NEXT STOKF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           IF SK-ONHAND < 0
               PERFORM REPORT-NEG
           END-IF.
       CSNN-999.
           EXIT.
      *----------------------------------------------------------------
       REPORT-NEG SECTION.
       RNG-010.
           ADD 1                   TO WK-EX-NEG.
           ADD 1                   TO WK-EX-TOTAL.
           MOVE "NEGATIVE ON-HAND"  TO EX-TAG.
           MOVE "PROD  "           TO EX-KEY1LBL.
           MOVE SK-PROD           TO EX-KEY1.
           MOVE "WHSE  "           TO EX-KEY2LBL.
           MOVE SK-WHSE           TO EX-KEY2.
           MOVE SPACE             TO WK-MSGTXT.
           MOVE SK-ONHAND         TO WK-EN.
           STRING "on-hand qty = " WK-EN
               DELIMITED BY SIZE INTO WK-MSGTXT.
           MOVE WK-MSGTXT         TO EX-MSG.
           PERFORM WRITE-EXCEPTION.
       RNG-999.
           EXIT.
      *----------------------------------------------------------------
      *  WRITE-EXCEPTION : one problem to the report file and console
      *----------------------------------------------------------------
       WRITE-EXCEPTION SECTION.
       WEX-010.
           PERFORM CHECK-PAGE.
           MOVE RD-EX              TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           DISPLAY RD-EX.
       WEX-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-SECTION SECTION.
       WS-010.
           PERFORM CHECK-PAGE.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE RD-SECT            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           DISPLAY " ".
           DISPLAY SECT-TXT.
       WS-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE "DATA INTEGRITY CHECK" TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE "BT0090 EXCEPTION REPORT" TO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE 4                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
      *  PRINT-SUMMARY : category counts, verdict, return code
      *----------------------------------------------------------------
       PRINT-SUMMARY SECTION.
       PSUM-010.
           MOVE "(A) orphan order-detail lines   :" TO SM-LBL.
           MOVE WK-EX-ORPH-OD      TO SM-VAL.
           PERFORM WRITE-COUNT.
           MOVE "(B) orphan invoice-detail lines :" TO SM-LBL.
           MOVE WK-EX-ORPH-ID      TO SM-VAL.
           PERFORM WRITE-COUNT.
           MOVE "(C) stock rows missing product  :" TO SM-LBL.
           MOVE WK-EX-PROD         TO SM-VAL.
           PERFORM WRITE-COUNT.
           MOVE "(D) stock rows negative on-hand :" TO SM-LBL.
           MOVE WK-EX-NEG          TO SM-VAL.
           PERFORM WRITE-COUNT.
           MOVE "    TOTAL EXCEPTIONS             :" TO SM-LBL.
           MOVE WK-EX-TOTAL        TO SM-VAL.
           PERFORM WRITE-COUNT.
           PERFORM WRITE-VERDICT.
       PSUM-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-COUNT SECTION.
       WC-010.
           PERFORM CHECK-PAGE.
           MOVE RD-CNT             TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE SM-VAL             TO WK-E-CNT.
           DISPLAY SM-LBL " " WK-E-CNT.
       WC-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-VERDICT SECTION.
       WV-010.
           PERFORM CHECK-PAGE.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           IF WK-EX-TOTAL = 0
               MOVE " VERDICT : CLEAN - no integrity problems found"
                                   TO VERD-TXT
               MOVE 0              TO COMPLETION-CODE
           ELSE
               MOVE " VERDICT : DIRTY - integrity problems detected"
                                   TO VERD-TXT
               MOVE 4              TO COMPLETION-CODE
           END-IF.
           MOVE RD-VERD            TO REP-REC.
           WRITE REP-REC.
           DISPLAY " ".
           DISPLAY VERD-TXT.
       WV-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           IF WK-ABORT-FLG = 0
               PERFORM DISP-STATS
               CLOSE REPF
           END-IF.
           CLOSE ORDDF ORDHF INVDF INVHF STOKF PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       DISP-STATS SECTION.
       DST-010.
           DISPLAY " ".
           DISPLAY "----------------------------------------------".
           DISPLAY " RECORDS SCANNED".
           MOVE WK-ORDD-CNT        TO WK-E-CNT.
           DISPLAY "   order details   : " WK-E-CNT.
           MOVE WK-INVD-CNT        TO WK-E-CNT.
           DISPLAY "   invoice details : " WK-E-CNT.
           MOVE WK-STOK-CNT        TO WK-E-CNT.
           DISPLAY "   stock rows      : " WK-E-CNT.
           DISPLAY "----------------------------------------------".
           DISPLAY " BT0090 completed.  See reports/BT0090.TXT".
       DST-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABND-010.
           MOVE "BT0090"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EBATCH"           TO KA-MSGCODE.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABND-999.
           EXIT.
