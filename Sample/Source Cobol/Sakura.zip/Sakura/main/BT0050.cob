       IDENTIFICATION DIVISION.
       PROGRAM-ID. BT0050.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : BT0050  -  accounts-payable balance rebuild       *
      *  FUNCTION : reads the AP ledger in supplier / date order      *
      *             (alternate key PL-SUPP + PL-DATE), recomputes the *
      *             running balance on every ledger entry             *
      *             (balance = balance + credit - debit) and rewrites *
      *             PL-BALANCE.  At each supplier control-break the    *
      *             final running balance is written back to the      *
      *             supplier master (SUPPF SP-BALANCE).  Use this      *
      *             utility to repair AP balances after an aborted     *
      *             posting run.  Console / batch (no screen section). *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SAPL.
           COPY SSUPP.
       DATA DIVISION.
       FILE SECTION.
           COPY FAPL.
           COPY FSUPP.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- accumulators ----------------------------------------------
       01  WK-TOTALS.
           02  WK-LEDG-CNT         PIC 9(7)  VALUE 0.
           02  WK-SUPP-CNT         PIC 9(7)  VALUE 0.
           02  WK-UPD-CNT          PIC 9(7)  VALUE 0.
           02  WK-NF-CNT           PIC 9(7)  VALUE 0.
           02  WK-ZERO-READ        PIC 9(7)  VALUE 0.
           02  WK-ZERO-CLR         PIC 9(7)  VALUE 0.
           02  WK-NONZERO-CNT      PIC 9(7)  VALUE 0.
           02  WK-DEBIT-TOT        PIC S9(13) VALUE 0.
           02  WK-CREDIT-TOT       PIC S9(13) VALUE 0.
           02  WK-BAL-TOT          PIC S9(13) VALUE 0.
      *----- control break / running balance ---------------------------
       01  WK-CTRL.
           02  WK-RUN-BAL          PIC S9(11) VALUE 0.
           02  WK-PREV-SUPP        PIC 9(6)  VALUE 0.
           02  WK-FIRST-FLG        PIC 9(1)  VALUE 0.
      *----- display edit work -----------------------------------------
       01  WK-DISP.
           02  WK-E-CNT            PIC Z,ZZZ,ZZ9.
           02  WK-E-AMT            PIC Z,ZZZ,ZZZ,ZZZ,ZZ9-.
           02  WK-E-CODE           PIC ZZZZZ9.
      *----- flags -----------------------------------------------------
       01  WK-FLAGS.
           02  WK-ABORT-FLG        PIC 9(1)  VALUE 0.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           IF WK-ABORT-FLG = 0
               PERFORM CLEAR-MASTER
               PERFORM PROCESS-RTN
               PERFORM PRINT-SUMMARY
           END-IF.
           PERFORM TERM-RTN.
           MOVE 0                  TO COMPLETION-CODE.
           EXIT PROGRAM.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "BT0050"           TO WK-PROGID.
           DISPLAY " ".
           DISPLAY "==============================================".
           DISPLAY " SAKURA-SMS  BT0050  -  AP BALANCE REBUILD".
           DISPLAY "==============================================".
           PERFORM GET-TODAY.
           PERFORM OPEN-FILES.
           PERFORM CONFIRM-RUN.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       GET-TODAY SECTION.
       GTOD-010.
           MOVE "TODY"             TO KD-FUNC.
           MOVE 0                  TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE  WK-SYSYMD.
       GTOD-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPEN-010.
           OPEN I-O    APLF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT APLF
               CLOSE APLF
               OPEN I-O APLF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "APLF"         TO KA-FILE
               MOVE "Open APLF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O    SUPPF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SUPPF
               CLOSE SUPPF
               OPEN I-O SUPPF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SUPPF"        TO KA-FILE
               MOVE "Open SUPPF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OPEN-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-RUN SECTION.
       CONF-010.
           DISPLAY " ".
           DISPLAY " Rebuild AP ledger running balances and".
           DISPLAY " supplier master balances from the ledger.".
           DISPLAY " Proceed ? (Y/N) : " WITH NO ADVANCING.
           MOVE SPACE              TO WK-CONFIRM.
           ACCEPT WK-CONFIRM FROM CONSOLE.
           IF NOT CONFIRM-YES
               DISPLAY " ** cancelled by operator."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       CONF-999.
           EXIT.
      *----------------------------------------------------------------
      *  CLEAR-MASTER : zero every supplier balance first so that      *
      *  accounts with no ledger activity are also correctly reset     *
      *----------------------------------------------------------------
       CLEAR-MASTER SECTION.
       CLRM-010.
           DISPLAY " ".
           DISPLAY " Clearing supplier balances ...".
           MOVE 0                  TO EOF-FLG.
           MOVE 0                  TO SP-CODE.
           START SUPPF KEY NOT LESS THAN SP-CODE
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM CLRM-NEXT UNTIL EOF-YES.
       CLRM-999.
           EXIT.
       CLRM-NEXT SECTION.
       CLRX-010.
           READ SUPPF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO CLRX-999
           END-READ.
           ADD 1                   TO WK-ZERO-READ.
           IF SP-BALANCE NOT = 0
               MOVE 0              TO SP-BALANCE
               REWRITE SP-REC
                   INVALID KEY
                       MOVE "SUPPF" TO KA-FILE
                       MOVE "Clear SUPPF balance failed" TO KA-DETAIL
                       PERFORM ABEND-RTN
               END-REWRITE
               ADD 1               TO WK-ZERO-CLR
           END-IF.
       CLRX-999.
           EXIT.
      *----------------------------------------------------------------
      *  PROCESS : walk the ledger in supplier / date order            *
      *----------------------------------------------------------------
       PROCESS-RTN SECTION.
       PROC-010.
           DISPLAY " ".
           DISPLAY " Rebuilding ...".
           MOVE 0                  TO EOF-FLG.
           MOVE 1                  TO WK-FIRST-FLG.
           MOVE 0                  TO WK-PREV-SUPP.
           MOVE 0                  TO WK-RUN-BAL.
           MOVE 0                  TO PL-SUPP.
           MOVE 0                  TO PL-DATE.
           START APLF KEY NOT LESS THAN PL-SUPP
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM PROC-NEXT UNTIL EOF-YES.
      *    write back the last supplier's balance
           IF WK-FIRST-FLG = 0
               PERFORM UPDATE-SUPP
           END-IF.
       PROC-999.
           EXIT.
      *----------------------------------------------------------------
       PROC-NEXT SECTION.
       PNXT-010.
           READ APLF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO PNXT-999
           END-READ.
           IF FSTS NOT = "00" AND FSTS NOT = "02"
               MOVE "APLF"         TO KA-FILE
               MOVE "READ NEXT APLF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           IF WK-FIRST-FLG = 1
               MOVE 0              TO WK-FIRST-FLG
               MOVE PL-SUPP        TO WK-PREV-SUPP
               MOVE 0              TO WK-RUN-BAL
           END-IF.
           IF PL-SUPP NOT = WK-PREV-SUPP
               PERFORM UPDATE-SUPP
               MOVE PL-SUPP        TO WK-PREV-SUPP
               MOVE 0              TO WK-RUN-BAL
           END-IF.
           PERFORM POST-ENTRY.
       PNXT-999.
           EXIT.
      *----------------------------------------------------------------
      *  POST-ENTRY : recompute running balance and rewrite entry      *
      *----------------------------------------------------------------
       POST-ENTRY SECTION.
       PENT-010.
           ADD 1                   TO WK-LEDG-CNT.
      *    AP balance rises with credit (purch) falls with debit (pay)
           ADD PL-CREDIT           TO WK-RUN-BAL.
           SUBTRACT PL-DEBIT       FROM WK-RUN-BAL.
           ADD PL-DEBIT            TO WK-DEBIT-TOT.
           ADD PL-CREDIT           TO WK-CREDIT-TOT.
           MOVE WK-RUN-BAL         TO PL-BALANCE.
           REWRITE PL-REC
               INVALID KEY
                   MOVE "APLF"     TO KA-FILE
                   MOVE "REWRITE APLF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-REWRITE.
       PENT-999.
           EXIT.
      *----------------------------------------------------------------
      *  UPDATE-SUPP : write final running balance to SUPPF            *
      *----------------------------------------------------------------
       UPDATE-SUPP SECTION.
       USUP-010.
           IF WK-PREV-SUPP = 0
               GO TO USUP-999
           END-IF.
           ADD 1                   TO WK-SUPP-CNT.
           ADD WK-RUN-BAL          TO WK-BAL-TOT.
           MOVE WK-PREV-SUPP       TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   ADD 1           TO WK-NF-CNT
                   GO TO USUP-999
           END-READ.
           MOVE WK-RUN-BAL         TO SP-BALANCE.
           MOVE WK-SYSDATE         TO SP-UPD-DATE.
           MOVE WK-USER-CODE       TO SP-UPD-USER.
           REWRITE SP-REC
               INVALID KEY
                   MOVE "SUPPF"    TO KA-FILE
                   MOVE "REWRITE SUPPF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-REWRITE.
           ADD 1                   TO WK-UPD-CNT.
      *    audit line for accounts with an outstanding balance
           IF WK-RUN-BAL NOT = 0
               ADD 1               TO WK-NONZERO-CNT
               MOVE WK-PREV-SUPP   TO WK-E-CODE
               MOVE WK-RUN-BAL     TO WK-E-AMT
               DISPLAY "   supp " WK-E-CODE " balance " WK-E-AMT
           END-IF.
       USUP-999.
           EXIT.
      *----------------------------------------------------------------
      *  PRINT-SUMMARY                                                 *
      *----------------------------------------------------------------
       PRINT-SUMMARY SECTION.
       PSUM-010.
           DISPLAY " ".
           DISPLAY "----------------------------------------------".
           DISPLAY " AP BALANCE REBUILD SUMMARY".
           DISPLAY "----------------------------------------------".
           MOVE WK-ZERO-READ       TO WK-E-CNT.
           DISPLAY " Suppliers cleared : " WK-E-CNT.
           MOVE WK-ZERO-CLR        TO WK-E-CNT.
           DISPLAY "   had prior bal   : " WK-E-CNT.
           MOVE WK-LEDG-CNT        TO WK-E-CNT.
           DISPLAY " Ledger entries    : " WK-E-CNT.
           MOVE WK-SUPP-CNT        TO WK-E-CNT.
           DISPLAY " Suppliers in ledg : " WK-E-CNT.
           MOVE WK-UPD-CNT         TO WK-E-CNT.
           DISPLAY " Masters updated   : " WK-E-CNT.
           MOVE WK-NF-CNT          TO WK-E-CNT.
           DISPLAY " Masters not found : " WK-E-CNT.
           MOVE WK-NONZERO-CNT     TO WK-E-CNT.
           DISPLAY " Outstanding accts : " WK-E-CNT.
           MOVE WK-DEBIT-TOT       TO WK-E-AMT.
           DISPLAY " Total debit       : " WK-E-AMT.
           MOVE WK-CREDIT-TOT      TO WK-E-AMT.
           DISPLAY " Total credit      : " WK-E-AMT.
           MOVE WK-BAL-TOT         TO WK-E-AMT.
           DISPLAY " Sum of balances   : " WK-E-AMT.
           DISPLAY "----------------------------------------------".
           DISPLAY " BT0050 completed normally.".
       PSUM-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE APLF.
           CLOSE SUPPF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABND-010.
           MOVE "BT0050"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EBATCH"           TO KA-MSGCODE.
           CALL "ABORTX" USING KABEND.
           CLOSE APLF.
           CLOSE SUPPF.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABND-999.
           EXIT.
