       IDENTIFICATION DIVISION.
       PROGRAM-ID. IV0030.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : IV0030  -  Stocktaking (physical count)          *
      *  FUNCTION : for one warehouse, walk every stock record and    *
      *             capture the counted physical quantity per         *
      *             product.  The book on-hand and the difference     *
      *             (counted - book) are shown.  On confirmation the  *
      *             on-hand of each item that differs is set to the   *
      *             counted quantity and a kind-30 adjust movement is *
      *             written to SMOVF for the difference.              *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SSTOK.
           COPY SSMOV.
           COPY SPROD.
           COPY SWHSE.
       I-O-CONTROL.
           APPLY SHARED-MODE ON STOKF
           APPLY SHARED-MODE ON SMOVF.
       DATA DIVISION.
       FILE SECTION.
           COPY FSTOK.
           COPY FSMOV.
           COPY FPROD.
           COPY FWHSE.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-STK.
           02  WK-WHSE-IN          PIC 9(3)  VALUE 0.
           02  WK-WH-NAME          PIC X(30) VALUE SPACE.
           02  WK-PR-NAME          PIC X(40) VALUE SPACE.
           02  WK-BOOK             PIC S9(9) VALUE 0.
           02  WK-COUNTED          PIC S9(9) VALUE 0.
           02  WK-DIFF             PIC S9(9) VALUE 0.
           02  WK-TCNT             PIC 9(4)  VALUE 0.
           02  WK-DCNT             PIC 9(4)  VALUE 0.
           02  WK-PCNT             PIC 9(4)  VALUE 0.
           02  WK-SHOW-NO          PIC 9(4)  VALUE 0.
       01  WK-FLAGS.
           02  CNT-FLG             PIC 9(1)  VALUE 0.
             88  CNT-END                     VALUE 1.
           02  REC-FLG             PIC 9(1)  VALUE 0.
             88  REC-YES                     VALUE 1.
       01  WK-CNT-TABLE.
           02  WK-CT OCCURS 500 INDEXED BY CX.
             03  CT-PROD           PIC 9(8).
             03  CT-WHSE           PIC 9(3).
             03  CT-BOOK           PIC S9(9).
             03  CT-COUNTED        PIC S9(9).
             03  CT-DIFF           PIC S9(9).
       01  WK-REVIEW.
           02  WK-RPAGE            PIC 9(4)  VALUE 0.
           02  WK-RSTART           PIC 9(4)  VALUE 0.
           02  WK-RI               PIC 9(4)  VALUE 0.
           02  WK-RROW             PIC 9(2)  VALUE 0.
           02  RVW-FLG             PIC 9(1)  VALUE 0.
             88  RVW-END                     VALUE 1.
       01  WK-CL.
           02  WK-CL-PROD          PIC 9(8).
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-CL-NAME          PIC X(18).
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-CL-BOOK          PIC ---,---,--9.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-CL-CNT           PIC ---,---,--9.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-CL-DIFF          PIC ---,---,--9.
       01  WK-LIST-TABLE.
           02  WK-LIST OCCURS 12 TIMES PIC X(78).
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-WH.
           02  LINE 5.
             03  COLUMN 2  VALUE "Warehouse    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(3) USING WK-WHSE-IN.
             03  COLUMN 30 PIC X(30) FROM WK-WH-NAME COLOR WHITE.
       01  DS-COUNT.
           02  LINE 5.
             03  COLUMN 2  VALUE "Warehouse    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(3) FROM WK-WHSE-IN COLOR WHITE.
             03  COLUMN 30 PIC X(30) FROM WK-WH-NAME COLOR WHITE.
           02  LINE 7.
             03  COLUMN 2  VALUE "Item No      :" COLOR YELLOW.
             03  COLUMN 20 PIC ZZZ9 FROM WK-SHOW-NO COLOR WHITE.
           02  LINE 9.
             03  COLUMN 2  VALUE "Product      :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(8) FROM SK-PROD COLOR WHITE.
             03  COLUMN 30 PIC X(40) FROM WK-PR-NAME COLOR WHITE.
           02  LINE 11.
             03  COLUMN 2  VALUE "Book OnHand  :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM WK-BOOK COLOR WHITE.
           02  LINE 13.
             03  COLUMN 2  VALUE "Counted Qty  :" COLOR YELLOW.
             03  COLUMN 20 PIC S9(9) USING WK-COUNTED.
       01  DS-SUMMARY.
           02  LINE 15.
             03  COLUMN 2  VALUE "Items counted:" COLOR YELLOW.
             03  COLUMN 20 PIC ZZZ9 FROM WK-TCNT COLOR WHITE.
           02  LINE 16.
             03  COLUMN 2  VALUE "With diff    :" COLOR YELLOW.
             03  COLUMN 20 PIC ZZZ9 FROM WK-DCNT COLOR WHITE.
           02  LINE 18 COLUMN 2 VALUE "Post count (Y/N):" COLOR YELLOW.
           02  SC-CONF LINE 18 COLUMN 20 PIC X(1) USING WK-CONFIRM.
       01  DS-REVIEW.
           02  LINE 3.
             03  COLUMN 2  VALUE "Warehouse :" COLOR YELLOW.
             03  COLUMN 14 PIC 9(3) FROM WK-WHSE-IN COLOR WHITE.
             03  COLUMN 20 PIC X(30) FROM WK-WH-NAME COLOR WHITE.
           02  LINE 5 COLUMN 2
               VALUE "Prod    Name            Book      Count     Diff"
               COLOR CYAN.
           02  LINE 7  COLUMN 2 PIC X(78) FROM WK-LIST (1) COLOR WHITE.
           02  LINE 8  COLUMN 2 PIC X(78) FROM WK-LIST (2) COLOR WHITE.
           02  LINE 9  COLUMN 2 PIC X(78) FROM WK-LIST (3) COLOR WHITE.
           02  LINE 10 COLUMN 2 PIC X(78) FROM WK-LIST (4) COLOR WHITE.
           02  LINE 11 COLUMN 2 PIC X(78) FROM WK-LIST (5) COLOR WHITE.
           02  LINE 12 COLUMN 2 PIC X(78) FROM WK-LIST (6) COLOR WHITE.
           02  LINE 13 COLUMN 2 PIC X(78) FROM WK-LIST (7) COLOR WHITE.
           02  LINE 14 COLUMN 2 PIC X(78) FROM WK-LIST (8) COLOR WHITE.
           02  LINE 15 COLUMN 2 PIC X(78) FROM WK-LIST (9) COLOR WHITE.
           02  LINE 16 COLUMN 2 PIC X(78) FROM WK-LIST (10) COLOR WHITE.
           02  LINE 17 COLUMN 2 PIC X(78) FROM WK-LIST (11) COLOR WHITE.
           02  LINE 18 COLUMN 2 PIC X(78) FROM WK-LIST (12) COLOR WHITE.
           02  LINE 20.
             03  COLUMN 2  VALUE "Page :" COLOR YELLOW.
             03  COLUMN 9  PIC ZZZ9 FROM WK-RPAGE COLOR WHITE.
             03  COLUMN 20 VALUE "of items :" COLOR YELLOW.
             03  COLUMN 31 PIC ZZZ9 FROM WK-TCNT COLOR WHITE.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "IV0030"           TO WK-PROGID.
           MOVE "Stocktaking"                     TO WK-TITLE.
           MOVE "ENTER=Save/Next PF3=Finish PF4=Skip"
                                   TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           OPEN I-O   STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O   SMOVF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SMOVF
               CLOSE SMOVF
               OPEN I-O SMOVF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SMOVF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT PRODF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PRODF
               CLOSE PRODF
               OPEN INPUT PRODF
           END-IF.
           OPEN INPUT WHSEF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT WHSEF
               CLOSE WHSEF
               OPEN INPUT WHSEF
           END-IF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-010.
           PERFORM GET-WHSE.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-WHSE
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       GET-WHSE SECTION.
       GWH-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter warehouse to count" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-WH.
           ACCEPT  DS-WH.
       GWH-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLRW-010.
           MOVE 0                  TO WK-WHSE-IN WK-TCNT WK-DCNT.
           MOVE 0                  TO WK-PCNT WK-SHOW-NO.
           MOVE SPACE              TO WK-WH-NAME WK-PR-NAME WK-CONFIRM.
           MOVE 0                  TO CNT-FLG REC-FLG.
       CLRW-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-WHSE SECTION.
       PWH-010.
           MOVE WK-WHSE-IN         TO WH-CODE.
           READ WHSEF
               INVALID KEY
                   MOVE "Warehouse not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PWH-999
           END-READ.
           IF WH-DEL-FLAG = 1
               MOVE "Warehouse is deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PWH-999
           END-IF.
           MOVE WH-NAME            TO WK-WH-NAME.
           PERFORM COUNT-LOOP.
           IF WK-TCNT = 0
               MOVE "No stock records in this warehouse"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PWH-999
           END-IF.
           PERFORM REVIEW-COUNT.
           PERFORM CONFIRM-POST.
       PWH-999.
           EXIT.
      *----------------------------------------------------------------
       REVIEW-COUNT SECTION.
       RVC-010.
           MOVE 0                  TO WK-RPAGE RVW-FLG.
           MOVE 1                  TO WK-RSTART.
           PERFORM UNTIL RVW-END
               PERFORM FILL-RPAGE
               IF WK-RROW = 0
                   SET RVW-END TO TRUE
               ELSE
                   ADD 1           TO WK-RPAGE
                   MOVE "ENTER/PF6=next page  PF3=go to post"
                                   TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   DISPLAY DS-REVIEW
                   ACCEPT  DS-REVIEW
                   EVALUATE ESTS
                       WHEN "03"
                           SET RVW-END TO TRUE
                       WHEN OTHER
                           ADD 12  TO WK-RSTART
                           IF WK-RSTART > WK-TCNT
                               SET RVW-END TO TRUE
                           END-IF
                   END-EVALUATE
               END-IF
           END-PERFORM.
       RVC-999.
           EXIT.
      *----------------------------------------------------------------
       FILL-RPAGE SECTION.
       FRP-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > 12
               MOVE SPACE          TO WK-LIST (WK-IDX)
           END-PERFORM.
           MOVE 0                  TO WK-RROW.
           PERFORM VARYING WK-RI FROM WK-RSTART BY 1
                   UNTIL WK-RI > WK-TCNT OR WK-RROW >= 12
               ADD 1               TO WK-RROW
               PERFORM FMT-REVIEW-LINE
           END-PERFORM.
       FRP-999.
           EXIT.
      *----------------------------------------------------------------
       FMT-REVIEW-LINE SECTION.
       FRL-010.
           SET CX                  TO WK-RI.
           MOVE CT-PROD (CX)       TO WK-CL-PROD.
           MOVE SPACE              TO WK-CL-NAME.
           MOVE CT-PROD (CX)       TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "?"        TO WK-CL-NAME
               NOT INVALID KEY
                   MOVE PR-NAME    TO WK-CL-NAME
           END-READ.
           MOVE CT-BOOK (CX)       TO WK-CL-BOOK.
           MOVE CT-COUNTED (CX)    TO WK-CL-CNT.
           MOVE CT-DIFF (CX)       TO WK-CL-DIFF.
           MOVE WK-CL              TO WK-LIST (WK-RROW).
       FRL-999.
           EXIT.
      *----------------------------------------------------------------
       COUNT-LOOP SECTION.
       CLUP-010.
           MOVE WK-WHSE-IN         TO SK-WHSE.
           MOVE 0                  TO SK-PROD.
           START STOKF KEY IS >= SK-WHSE
               INVALID KEY
                   GO TO CLUP-999
           END-START.
           MOVE 0                  TO CNT-FLG.
           PERFORM UNTIL CNT-END
               PERFORM READ-NEXT-STOCK
               IF NOT REC-YES
                   SET CNT-END TO TRUE
               ELSE
                   IF SK-WHSE NOT = WK-WHSE-IN
                       SET CNT-END TO TRUE
                   ELSE
                       PERFORM COUNT-ONE
                   END-IF
               END-IF
           END-PERFORM.
       CLUP-999.
           EXIT.
      *----------------------------------------------------------------
       READ-NEXT-STOCK SECTION.
       RNS-010.
           MOVE 0                  TO REC-FLG.
           READ STOKF NEXT
               AT END
                   GO TO RNS-999
           END-READ.
           IF FSTS = "00"
               SET REC-YES TO TRUE
           END-IF.
       RNS-999.
           EXIT.
      *----------------------------------------------------------------
       COUNT-ONE SECTION.
       CONE-010.
           IF WK-TCNT >= 500
               MOVE "Maximum 500 items reached - stop"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               SET CNT-END TO TRUE
               GO TO CONE-999
           END-IF.
           MOVE SK-ONHAND          TO WK-BOOK.
           MOVE SK-ONHAND          TO WK-COUNTED.
           PERFORM LOOKUP-PROD.
           ADD 1                   TO WK-SHOW-NO.
           MOVE "ENTER=save count PF4=skip PF3=finish"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-COUNT.
           ACCEPT  DS-COUNT.
           EVALUATE ESTS
               WHEN "03"
                   PERFORM STORE-ITEM
                   SET CNT-END TO TRUE
               WHEN "04"
                   MOVE SK-ONHAND  TO WK-COUNTED
                   PERFORM STORE-ITEM
               WHEN "00"
                   PERFORM STORE-ITEM
               WHEN OTHER
                   MOVE SK-ONHAND  TO WK-COUNTED
                   PERFORM STORE-ITEM
           END-EVALUATE.
       CONE-999.
           EXIT.
      *----------------------------------------------------------------
       STORE-ITEM SECTION.
       STOR-010.
           ADD 1                   TO WK-TCNT.
           SET CX                  TO WK-TCNT.
           MOVE SK-PROD            TO CT-PROD (CX).
           MOVE SK-WHSE            TO CT-WHSE (CX).
           MOVE WK-BOOK            TO CT-BOOK (CX).
           MOVE WK-COUNTED         TO CT-COUNTED (CX).
           COMPUTE WK-DIFF = WK-COUNTED - WK-BOOK.
           MOVE WK-DIFF            TO CT-DIFF (CX).
           IF WK-DIFF NOT = 0
               ADD 1               TO WK-DCNT
           END-IF.
       STOR-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-PROD SECTION.
       LKPR-010.
           MOVE SPACE              TO WK-PR-NAME.
           MOVE SK-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "*** unknown product ***" TO WK-PR-NAME
               NOT INVALID KEY
                   MOVE PR-NAME    TO WK-PR-NAME
           END-READ.
       LKPR-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-POST SECTION.
       CPST-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Review counts then confirm posting" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-SUMMARY.
           ACCEPT  DS-SUMMARY.
           IF CONFIRM-YES
               PERFORM POST-COUNT
           ELSE
               MOVE "Count discarded - not posted" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CPST-999.
           EXIT.
      *----------------------------------------------------------------
       POST-COUNT SECTION.
       PC-010.
           MOVE 0                  TO WK-PCNT.
           PERFORM VARYING CX FROM 1 BY 1 UNTIL CX > WK-TCNT
               IF CT-DIFF (CX) NOT = 0
                   PERFORM POST-ONE
               END-IF
           END-PERFORM.
           MOVE WK-PCNT            TO WK-CNT.
           MOVE "Stocktaking posted" TO WK-MSG-LINE.
           DISPLAY DS-SUMMARY.
           DISPLAY DS-MSG.
       PC-999.
           EXIT.
      *----------------------------------------------------------------
       POST-ONE SECTION.
       PO-010.
           MOVE CT-PROD (CX)       TO SK-PROD.
           MOVE CT-WHSE (CX)       TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   GO TO PO-999
           END-READ.
           MOVE CT-COUNTED (CX)    TO SK-ONHAND.
           IF CT-DIFF (CX) > 0
               MOVE WK-SYSDATE     TO SK-LAST-IN-DATE
               ADD CT-DIFF (CX)    TO SK-YTD-IN
           ELSE
               MOVE WK-SYSDATE     TO SK-LAST-OUT-DATE
               SUBTRACT CT-DIFF (CX) FROM SK-YTD-OUT
           END-IF.
           REWRITE SK-REC
               INVALID KEY
                   GO TO PO-999
           END-REWRITE.
           PERFORM WRITE-MOVEMENT.
           ADD 1                   TO WK-PCNT.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-MOVEMENT SECTION.
       WM-010.
           MOVE "STKMOV"           TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               GO TO WM-999
           END-IF.
           INITIALIZE SM-REC.
           MOVE KNUM-NUMBER        TO SM-SEQ.
           MOVE WK-SYSDATE         TO SM-DATE.
           MOVE CT-PROD (CX)       TO SM-PROD.
           MOVE CT-WHSE (CX)       TO SM-WHSE.
           MOVE 30                 TO SM-KIND.
           MOVE CT-DIFF (CX)       TO SM-QTY.
           MOVE SK-AVG-COST        TO SM-UNIT-COST.
           MOVE SK-ONHAND          TO SM-BAL-AFTER.
           MOVE 30                 TO SM-REF-TYPE.
           MOVE KNUM-NUMBER        TO SM-REF-NO.
           MOVE WK-USER-CODE       TO SM-USER.
           WRITE SM-REC
               INVALID KEY
                   CONTINUE
           END-WRITE.
       WM-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE STOKF SMOVF PRODF WHSEF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "IV0030"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
