       IDENTIFICATION DIVISION.
       PROGRAM-ID. AP0020.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : AP0020  -  AP inquiry                             *
      *  FUNCTION : for one supplier, scan the AP ledger by the       *
      *             PL-SUPP alternate key, show the current AP        *
      *             balance, the total purchases and payments and     *
      *             the most recent ledger lines.  Read-only inquiry. *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SAPL.
           COPY SSUPP.
       DATA DIVISION.
       FILE SECTION.
           COPY FAPL.
           COPY FSUPP.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-INQ.
           02  WK-KEY-SUPP         PIC 9(6)  VALUE 0.
           02  WK-SUPP-NAME        PIC X(40) VALUE SPACE.
           02  WK-CUR-BAL          PIC S9(11) VALUE 0.
           02  WK-TOT-DR           PIC S9(13) VALUE 0.
           02  WK-TOT-CR           PIC S9(13) VALUE 0.
           02  WK-LCNT             PIC 9(4)  VALUE 0.
           02  WK-ROW              PIC 9(2)  VALUE 0.
           02  WK-START            PIC 9(4)  VALUE 0.
           02  WK-KIND-LBL         PIC X(6)  VALUE SPACE.
       01  WK-FLAGS.
           02  EOF-SUPP            PIC 9(1)  VALUE 0.
             88  SUPP-EOF                    VALUE 1.
       01  WK-DL.
           02  WK-DL-DATE          PIC 9999/99/99.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-DL-KIND          PIC X(6).
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-DL-DR            PIC ---,---,---,--9.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-DL-CR            PIC ---,---,---,--9.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-DL-BAL           PIC ---,---,---,--9.
       01  WK-LINE-TABLE.
           02  WK-ALL OCCURS 500 TIMES PIC X(78).
       01  WK-LIST-TABLE.
           02  WK-LIST OCCURS 12 TIMES PIC X(78).
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 5.
             03  COLUMN 2  VALUE "Supplier Code:" COLOR YELLOW.
             03  COLUMN 20 PIC 9(6) USING WK-KEY-SUPP.
       01  DS-VIEW.
           02  LINE 3.
             03  COLUMN 2  VALUE "Supplier :" COLOR YELLOW.
             03  COLUMN 13 PIC 9(6) FROM WK-KEY-SUPP COLOR WHITE.
             03  COLUMN 22 PIC X(40) FROM WK-SUPP-NAME COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "AP Balance :" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-CUR-BAL
                              COLOR WHITE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Tot Paid   :" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-TOT-DR
                              COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE "Tot Purch  :" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-TOT-CR
                              COLOR WHITE.
           02  LINE 7 COLUMN 2 VALUE "Recent ledger lines:" COLOR CYAN.
           02  LINE 8 COLUMN 2
               VALUE "Date        Kind      Debit         Credit"
               COLOR CYAN.
           02  LINE 9  COLUMN 2 PIC X(78) FROM WK-LIST (1) COLOR WHITE.
           02  LINE 10 COLUMN 2 PIC X(78) FROM WK-LIST (2) COLOR WHITE.
           02  LINE 11 COLUMN 2 PIC X(78) FROM WK-LIST (3) COLOR WHITE.
           02  LINE 12 COLUMN 2 PIC X(78) FROM WK-LIST (4) COLOR WHITE.
           02  LINE 13 COLUMN 2 PIC X(78) FROM WK-LIST (5) COLOR WHITE.
           02  LINE 14 COLUMN 2 PIC X(78) FROM WK-LIST (6) COLOR WHITE.
           02  LINE 15 COLUMN 2 PIC X(78) FROM WK-LIST (7) COLOR WHITE.
           02  LINE 16 COLUMN 2 PIC X(78) FROM WK-LIST (8) COLOR WHITE.
           02  LINE 17 COLUMN 2 PIC X(78) FROM WK-LIST (9) COLOR WHITE.
           02  LINE 18 COLUMN 2 PIC X(78) FROM WK-LIST (10) COLOR WHITE.
           02  LINE 19 COLUMN 2 PIC X(78) FROM WK-LIST (11) COLOR WHITE.
           02  LINE 20 COLUMN 2 PIC X(78) FROM WK-LIST (12) COLOR WHITE.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "AP0020"           TO WK-PROGID.
           MOVE "AP Inquiry"                       TO WK-TITLE.
           MOVE "ENTER=Inquire  PF3=End"          TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           OPEN INPUT APLF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT APLF
               CLOSE APLF
               OPEN INPUT APLF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "APLF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT SUPPF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SUPPF
               CLOSE SUPPF
               OPEN INPUT SUPPF
           END-IF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-010.
           PERFORM GET-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-SUPP
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       GET-KEY SECTION.
       GKEY-010.
           MOVE 0                  TO WK-KEY-SUPP.
           MOVE SPACE              TO WK-SUPP-NAME.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter supplier code then ENTER" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
       GKEY-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-SUPP SECTION.
       PS-010.
           IF WK-KEY-SUPP = 0
               MOVE "Supplier code must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PS-999
           END-IF.
           MOVE WK-KEY-SUPP        TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE "Supplier not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PS-999
           END-READ.
           MOVE SP-NAME            TO WK-SUPP-NAME.
           MOVE SP-BALANCE         TO WK-CUR-BAL.
           PERFORM SCAN-LEDGER.
           PERFORM SHOW-RESULT.
       PS-999.
           EXIT.
      *----------------------------------------------------------------
       SCAN-LEDGER SECTION.
       SL-010.
           MOVE 0                  TO WK-TOT-DR WK-TOT-CR.
           MOVE 0                  TO WK-LCNT EOF-SUPP.
           MOVE WK-KEY-SUPP        TO PL-SUPP.
           MOVE 0                  TO PL-DATE.
           START APLF KEY IS >= PL-SUPP
               INVALID KEY
                   SET SUPP-EOF TO TRUE
           END-START.
           PERFORM UNTIL SUPP-EOF
               READ APLF NEXT
                   AT END
                       SET SUPP-EOF TO TRUE
               END-READ
               IF NOT SUPP-EOF
                   IF PL-SUPP NOT = WK-KEY-SUPP
                       SET SUPP-EOF TO TRUE
                   ELSE
                       PERFORM PROCESS-LINE
                   END-IF
               END-IF
           END-PERFORM.
       SL-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-LINE SECTION.
       PLN-010.
           ADD PL-DEBIT            TO WK-TOT-DR.
           ADD PL-CREDIT           TO WK-TOT-CR.
           IF WK-LCNT < 500
               ADD 1               TO WK-LCNT
               PERFORM FORMAT-LINE
               MOVE WK-DL          TO WK-ALL (WK-LCNT)
           END-IF.
       PLN-999.
           EXIT.
      *----------------------------------------------------------------
       FORMAT-LINE SECTION.
       FMT-010.
           PERFORM KIND-LABEL.
           MOVE PL-DATE            TO WK-DL-DATE.
           MOVE WK-KIND-LBL        TO WK-DL-KIND.
           MOVE PL-DEBIT           TO WK-DL-DR.
           MOVE PL-CREDIT          TO WK-DL-CR.
           MOVE PL-BALANCE         TO WK-DL-BAL.
       FMT-999.
           EXIT.
      *----------------------------------------------------------------
       KIND-LABEL SECTION.
       KLB-010.
           EVALUATE PL-KIND
               WHEN 1
                   MOVE "Purch " TO WK-KIND-LBL
               WHEN 2
                   MOVE "Paymnt" TO WK-KIND-LBL
               WHEN 3
                   MOVE "Retn  " TO WK-KIND-LBL
               WHEN 4
                   MOVE "Adjust" TO WK-KIND-LBL
               WHEN OTHER
                   MOVE "Other " TO WK-KIND-LBL
           END-EVALUATE.
       KLB-999.
           EXIT.
      *----------------------------------------------------------------
       SHOW-RESULT SECTION.
       SR-010.
           PERFORM LOAD-RECENT.
           MOVE "Ledger scanned - press any key" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-VIEW.
           ACCEPT  DS-VIEW.
           IF ESTS = "03"
               SET END-YES TO TRUE
           END-IF.
       SR-999.
           EXIT.
      *----------------------------------------------------------------
       LOAD-RECENT SECTION.
       LR-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > 12
               MOVE SPACE          TO WK-LIST (WK-IDX)
           END-PERFORM.
           IF WK-LCNT = 0
               GO TO LR-999
           END-IF.
           IF WK-LCNT <= 12
               MOVE 1              TO WK-START
           ELSE
               COMPUTE WK-START = WK-LCNT - 11
           END-IF.
           MOVE 0                  TO WK-ROW.
           PERFORM VARYING WK-IDX FROM WK-START BY 1
                   UNTIL WK-IDX > WK-LCNT
               ADD 1               TO WK-ROW
               MOVE WK-ALL (WK-IDX) TO WK-LIST (WK-ROW)
           END-PERFORM.
       LR-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE APLF SUPPF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "AP0020"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
