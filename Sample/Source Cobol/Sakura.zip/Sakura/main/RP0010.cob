       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0010.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0010  -  Customer master list                  *
      *  FUNCTION : print all live customers (optionally within a    *
      *             customer-code range) with region name, sales rep *
      *             name, credit limit and current AR balance.       *
      *             Totals of credit limit and balance plus record   *
      *             count.  Batch / line-mode, 132-column text.      *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SCUST.
           COPY SREGN.
           COPY SSTAF.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FCUST.
           COPY FREGN.
           COPY FSTAF.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0010.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- control flags ---------------------------------------------
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
      *----- run parameters --------------------------------------------
       01  WK-PARM.
           02  WK-IN-FROM          PIC X(6)  VALUE SPACE.
           02  WK-IN-TO            PIC X(6)  VALUE SPACE.
           02  WK-CUST-FROM        PIC 9(6)  VALUE 0.
           02  WK-CUST-TO          PIC 9(6)  VALUE 999999.
      *----- lookup work -----------------------------------------------
       01  WK-NAMES.
           02  WK-REGION-NAME      PIC X(30) VALUE SPACE.
           02  WK-STAFF-NAME       PIC X(30) VALUE SPACE.
      *----- accumulators ----------------------------------------------
       01  WK-TOTALS.
           02  WK-TOT-CREDIT       PIC S9(15) COMP-3 VALUE 0.
           02  WK-TOT-BAL          PIC S9(15) COMP-3 VALUE 0.
       01  WK-COMPANY              PIC X(40) VALUE SPACE.
      *----- report line images ----------------------------------------
       01  RPT-RULE               PIC X(120) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RH-CUST.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "CODE".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(30) VALUE "CUSTOMER NAME".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(18) VALUE "REGION".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(18) VALUE "SALES REP".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "   CREDIT LIMIT".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "     BALANCE   ".
       01  RD-CUST.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RC-CODE            PIC 9(6).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RC-NAME            PIC X(30).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RC-REGION          PIC X(18).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RC-STAFF           PIC X(18).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RC-CREDIT          PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RC-BALANCE         PIC ---,---,---,--9.
       01  RT-CUST.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(20) VALUE "GRAND TOTAL".
           02  FILLER             PIC X(56) VALUE SPACE.
           02  RT-CREDIT          PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RT-BALANCE         PIC ---,---,---,--9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PARM-RTN.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0010"           TO WK-PROGID.
           MOVE "CUSTOMER MASTER LIST"          TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT CUSTF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "CUSTF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT REGNF.
           OPEN INPUT STAFF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PARM-RTN SECTION.
       PARM-010.
           DISPLAY "RP0010 - Customer master list".
           DISPLAY "From customer code (blank=first): ".
           ACCEPT  WK-IN-FROM FROM CONSOLE.
           DISPLAY "To   customer code (blank=last ): ".
           ACCEPT  WK-IN-TO   FROM CONSOLE.
           IF WK-IN-FROM NUMERIC AND WK-IN-FROM NOT = SPACE
               MOVE WK-IN-FROM     TO WK-CUST-FROM
           ELSE
               MOVE 0              TO WK-CUST-FROM
           END-IF.
           IF WK-IN-TO NUMERIC AND WK-IN-TO NOT = SPACE
               MOVE WK-IN-TO       TO WK-CUST-TO
           ELSE
               MOVE 999999         TO WK-CUST-TO
           END-IF.
       PARM-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRINT-010.
           MOVE 0                  TO WK-CNT.
           MOVE 99                 TO WK-LINE.
           IF NOT MAIN-EOF
               MOVE WK-CUST-FROM   TO CU-CODE
               START CUSTF KEY NOT < CU-CODE
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-NEXT UNTIL MAIN-EOF.
           PERFORM PRINT-TOTALS.
       PRINT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-NEXT SECTION.
       RN-010.
           READ CUSTF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   IF CU-CODE > WK-CUST-TO
                       MOVE 1      TO WK-MAIN-EOF
                   ELSE
                       PERFORM PROCESS-ONE
                   END-IF
           END-READ.
       RN-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-ONE SECTION.
       PO-010.
           IF CU-DEL-FLAG = 1
               GO TO PO-999
           END-IF.
           PERFORM CHECK-PAGE.
           PERFORM LOOKUP-REGION.
           PERFORM LOOKUP-STAFF.
           MOVE CU-CODE            TO RC-CODE.
           MOVE CU-NAME            TO RC-NAME.
           MOVE WK-REGION-NAME     TO RC-REGION.
           MOVE WK-STAFF-NAME      TO RC-STAFF.
           MOVE CU-CREDIT-LIMIT    TO RC-CREDIT.
           MOVE CU-BALANCE         TO RC-BALANCE.
           MOVE RD-CUST            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           ADD 1                   TO WK-CNT.
           ADD CU-CREDIT-LIMIT     TO WK-TOT-CREDIT.
           ADD CU-BALANCE          TO WK-TOT-BAL.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-REGION SECTION.
       LR-010.
           MOVE SPACE              TO WK-REGION-NAME.
           IF CU-REGION NOT = 0
               MOVE CU-REGION      TO RG-CODE
               READ REGNF
                   INVALID KEY
                       MOVE "(unknown)" TO WK-REGION-NAME
                   NOT INVALID KEY
                       MOVE RG-NAME     TO WK-REGION-NAME
               END-READ
           END-IF.
       LR-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-STAFF SECTION.
       LS-010.
           MOVE SPACE              TO WK-STAFF-NAME.
           IF CU-STAFF NOT = 0
               MOVE CU-STAFF       TO SF-CODE
               READ STAFF
                   INVALID KEY
                       MOVE "(unknown)" TO WK-STAFF-NAME
                   NOT INVALID KEY
                       MOVE SF-NAME     TO WK-STAFF-NAME
               END-READ
           END-IF.
       LS-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE RH-CUST            TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE 6                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-TOTALS SECTION.
       PT-010.
           IF WK-CNT = 0
               PERFORM CHECK-PAGE
               MOVE "*** NO CUSTOMERS SELECTED ***" TO REP-REC
               WRITE REP-REC
               GO TO PT-999
           END-IF.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-TOT-CREDIT      TO RT-CREDIT.
           MOVE WK-TOT-BAL         TO RT-BALANCE.
           MOVE RT-CUST            TO REP-REC.
           WRITE REP-REC.
       PT-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE CUSTF REGNF STAFF REPF.
           DISPLAY "RP0010 complete.  Customers listed = " WK-CNT.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0010"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
