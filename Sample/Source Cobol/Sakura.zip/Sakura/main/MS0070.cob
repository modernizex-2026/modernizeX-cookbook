       IDENTIFICATION DIVISION.
       PROGRAM-ID. MS0070.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : MS0070  -  Customer price master maintenance     *
      *  FUNCTION : add / change / delete / inquire special contract *
      *             prices.  The key is composite (customer code +   *
      *             product code); both are entered on the key       *
      *             screen and validated against the customer and    *
      *             product masters, whose names are then displayed. *
      *             Start / end effective dates are validated via    *
      *             DATEUT VALD.                                      *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SCPRC.
           COPY SCUST.
           COPY SPROD.
       I-O-CONTROL.
           APPLY SHARED-MODE ON CPRCF.
       DATA DIVISION.
       FILE SECTION.
           COPY FCPRC.
           COPY FCUST.
           COPY FPROD.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-LOOKUP.
           02  WK-CUST-NAME       PIC X(40) VALUE SPACE.
           02  WK-PROD-NAME       PIC X(40) VALUE SPACE.
       01  WK-SAVE-KEY.
           02  WK-SAVE-CUST       PIC 9(6)  VALUE 0.
           02  WK-SAVE-PROD       PIC 9(8)  VALUE 0.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4.
             03  COLUMN 2  VALUE "Customer Code :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(6)  USING CP-CUST.
           02  LINE 5.
             03  COLUMN 2  VALUE "Product Code  :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(8)  USING CP-PROD.
       01  DS-BODY.
           02  LINE 6.
             03  COLUMN 2  VALUE "Customer Name :" COLOR YELLOW.
             03  COLUMN 20 PIC X(40) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 7.
             03  COLUMN 2  VALUE "Product Name  :" COLOR YELLOW.
             03  COLUMN 20 PIC X(40) FROM WK-PROD-NAME COLOR WHITE.
           02  LINE 9.
             03  COLUMN 2  VALUE "Contract Price:" COLOR YELLOW.
             03  COLUMN 20 PIC S9(9)V9(2) USING CP-PRICE.
           02  LINE 10.
             03  COLUMN 2  VALUE "Start Date    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(8)  USING CP-START-DATE.
             03  COLUMN 30 VALUE "YYYYMMDD" COLOR CYAN.
           02  LINE 11.
             03  COLUMN 2  VALUE "End Date      :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(8)  USING CP-END-DATE.
             03  COLUMN 30 VALUE "YYYYMMDD  0=open" COLOR CYAN.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Confirm (Y/N) :" COLOR YELLOW.
           02  SC-CONF LINE 21 COLUMN 20 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "MS0070"           TO WK-PROGID.
           MOVE "Customer Price Master Maintenance"  TO WK-TITLE.
           MOVE "ENTER=Read  PF9=Delete  PF3=End" TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           OPEN I-O    CPRCF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT CPRCF
               CLOSE CPRCF
               OPEN I-O CPRCF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "CPRCF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT  CUSTF.
           IF FSTS NOT = "00"
               MOVE "CUSTF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT  PRODF.
           IF FSTS NOT = "00"
               MOVE "PRODF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-RTN-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE SPACE              TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-KEY
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-RTN-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLEAR-010.
           INITIALIZE CP-REC.
           MOVE SPACE              TO WK-CUST-NAME WK-PROD-NAME.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE 0                  TO WK-SAVE-CUST WK-SAVE-PROD.
       CLEAR-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-KEY SECTION.
       PKEY-010.
           IF CP-CUST = 0
               MOVE "Customer code must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
           IF CP-PROD = 0
               MOVE "Product code must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
      *----- validate customer code against customer master -----------
           MOVE CP-CUST            TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "Customer code not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PKEY-999
               NOT INVALID KEY
                   IF CU-DEL-FLAG = 1
                       MOVE "Customer is deleted" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                       GO TO PKEY-999
                   END-IF
                   MOVE CU-NAME    TO WK-CUST-NAME
           END-READ.
      *----- validate product code against product master ------------
           MOVE CP-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "Product code not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PKEY-999
               NOT INVALID KEY
                   IF PR-DEL-FLAG = 1
                       MOVE "Product is deleted" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                       GO TO PKEY-999
                   END-IF
                   MOVE PR-NAME    TO WK-PROD-NAME
           END-READ.
           MOVE CP-CUST            TO WK-SAVE-CUST.
           MOVE CP-PROD            TO WK-SAVE-PROD.
           READ CPRCF
               INVALID KEY
                   PERFORM SETUP-ADD
               NOT INVALID KEY
                   PERFORM SETUP-CHANGE
           END-READ.
           PERFORM EDIT-RECORD.
       PKEY-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-ADD SECTION.
       SADD-010.
           SET MODE-ADD TO TRUE.
           INITIALIZE CP-REC.
           MOVE WK-SAVE-CUST       TO CP-CUST.
           MOVE WK-SAVE-PROD       TO CP-PROD.
           MOVE WK-SYSDATE         TO CP-START-DATE.
           MOVE "New contract price - enter details" TO WK-MSG-LINE.
       SADD-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-CHANGE SECTION.
       SCHG-010.
           IF CP-DEL-FLAG = 1
               SET MODE-ADD TO TRUE
               MOVE "Deleted price - re-registering" TO WK-MSG-LINE
           ELSE
               SET MODE-CHG TO TRUE
               MOVE "Existing price - change or PF9 delete"
                                   TO WK-MSG-LINE
           END-IF.
           PERFORM LOOKUP-NAMES.
       SCHG-999.
           EXIT.
      *----------------------------------------------------------------
       EDIT-RECORD SECTION.
       EDIT-010.
           DISPLAY DS-MSG.
           DISPLAY DS-BODY.
           ACCEPT  DS-BODY.
           EVALUATE ESTS
               WHEN "03"
                   CONTINUE
               WHEN "04"
                   MOVE "Cancelled" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               WHEN "09"
                   IF MODE-CHG
                       PERFORM DELETE-RECORD
                   ELSE
                       MOVE "Nothing to delete" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   END-IF
               WHEN "00"
                   PERFORM VALIDATE-BODY
                   IF NOT ERR-YES
                       PERFORM SAVE-RECORD
                   END-IF
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       EDIT-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-BODY SECTION.
       VAL-010.
           MOVE 0                  TO ERR-FLG.
           IF CP-PRICE < 0
               MOVE "Price cannot be negative" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF CP-START-DATE = 0
               MOVE "Start date is required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           MOVE "VALD"             TO KD-FUNC.
           MOVE CP-START-DATE      TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           IF KD-STATUS NOT = "00"
               MOVE "Start date is invalid" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF CP-END-DATE NOT = 0
               MOVE "VALD"         TO KD-FUNC
               MOVE CP-END-DATE    TO KD-DATE1
               CALL "DATEUT" USING KDATE
               IF KD-STATUS NOT = "00"
                   MOVE "End date is invalid" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VAL-999
               END-IF
               IF CP-END-DATE < CP-START-DATE
                   MOVE "End date is before start date" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VAL-999
               END-IF
           END-IF.
       VAL-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       SAVE-RECORD SECTION.
       SAVE-010.
           MOVE 0                  TO CP-DEL-FLAG.
           IF MODE-ADD
               WRITE CP-REC
                   INVALID KEY
                       MOVE "Write failed - duplicate" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Contract price added" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-WRITE
           ELSE
               REWRITE CP-REC
                   INVALID KEY
                       MOVE "Update failed" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Contract price updated" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-REWRITE
           END-IF.
       SAVE-999.
           EXIT.
      *----------------------------------------------------------------
       DELETE-RECORD SECTION.
       DEL-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Press Y then ENTER to delete" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               MOVE 1              TO CP-DEL-FLAG
               REWRITE CP-REC
                   INVALID KEY
                       MOVE "Delete failed" TO WK-MSG-LINE
                   NOT INVALID KEY
                       MOVE "Contract price deleted" TO WK-MSG-LINE
               END-REWRITE
           ELSE
               MOVE "Delete cancelled" TO WK-MSG-LINE
           END-IF.
           DISPLAY DS-MSG.
       DEL-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-NAMES SECTION.
       LOOK-010.
           MOVE SPACE              TO WK-CUST-NAME.
           MOVE CP-CUST            TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "??? unknown customer" TO WK-CUST-NAME
               NOT INVALID KEY
                   MOVE CU-NAME    TO WK-CUST-NAME
           END-READ.
           MOVE SPACE              TO WK-PROD-NAME.
           MOVE CP-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "??? unknown product" TO WK-PROD-NAME
               NOT INVALID KEY
                   MOVE PR-NAME    TO WK-PROD-NAME
           END-READ.
       LOOK-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE CPRCF CUSTF PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "MS0070"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
