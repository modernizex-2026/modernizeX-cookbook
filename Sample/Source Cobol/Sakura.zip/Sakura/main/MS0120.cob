       IDENTIFICATION DIVISION.
       PROGRAM-ID. MS0120.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : MS0120  -  User master maintenance               *
      *  FUNCTION : add / change / delete / inquire the user master. *
      *             Maintains the login id, obscured password, name, *
      *             role and the five authority flags (master /      *
      *             order / sales / purchase / close).  The password *
      *             field is entered with (no echo).  For     *
      *             non-administrator users the user code must match *
      *             a staff code in the staff master; administrator  *
      *             codes are allowed without a staff record.        *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SUSER.
           COPY SSTAF.
       I-O-CONTROL.
           APPLY SHARED-MODE ON USERF.
       DATA DIVISION.
       FILE SECTION.
           COPY FUSER.
           COPY FSTAF.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-LOOKUP.
           02  WK-STAFF-NAME     PIC X(30) VALUE SPACE.
       01  WK-SAVE-CODE          PIC 9(6)  VALUE 0.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4 COLUMN 2  VALUE "User Code     :" COLOR YELLOW.
           02  SC-KEY LINE 4 COLUMN 20 PIC 9(6) USING US-CODE.
       01  DS-BODY.
           02  LINE 6.
             03  COLUMN 2  VALUE "Login ID      :" COLOR YELLOW.
             03  COLUMN 20 PIC X(12) USING US-LOGIN.
           02  LINE 7.
             03  COLUMN 2  VALUE "Password      :" COLOR YELLOW.
             03  COLUMN 20 PIC X(16) USING US-PASSWORD.
           02  LINE 8.
             03  COLUMN 2  VALUE "User Name     :" COLOR YELLOW.
             03  COLUMN 20 PIC X(30) USING US-NAME.
           02  LINE 9.
             03  COLUMN 2  VALUE "Staff Name    :" COLOR YELLOW.
             03  COLUMN 20 PIC X(30) FROM WK-STAFF-NAME COLOR WHITE.
           02  LINE 10.
             03  COLUMN 2  VALUE "Role          :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING US-ROLE.
             03  COLUMN 24 VALUE "1:admin 2:manager 3:clerk" COLOR CYAN.
           02  LINE 12.
             03  COLUMN 2  VALUE "Auth Master   :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING US-AUTH-MASTER.
             03  COLUMN 24 VALUE "0:no 1:yes" COLOR CYAN.
           02  LINE 13.
             03  COLUMN 2  VALUE "Auth Order    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING US-AUTH-ORDER.
           02  LINE 14.
             03  COLUMN 2  VALUE "Auth Sales    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING US-AUTH-SALES.
           02  LINE 15.
             03  COLUMN 2  VALUE "Auth Purchase :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING US-AUTH-PURCH.
           02  LINE 16.
             03  COLUMN 2  VALUE "Auth Close    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING US-AUTH-CLOSE.
           02  LINE 18.
             03  COLUMN 2  VALUE "Last Login    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9999B99B99 FROM US-LAST-LOGIN
                            COLOR WHITE.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Confirm (Y/N) :" COLOR YELLOW.
           02  SC-CONF LINE 21 COLUMN 20 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "MS0120"           TO WK-PROGID.
           MOVE "User Master Maintenance"  TO WK-TITLE.
           MOVE "ENTER=Read  PF9=Delete  PF3=End" TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           OPEN I-O    USERF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT USERF
               CLOSE USERF
               OPEN I-O USERF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "USERF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT  STAFF.
           IF FSTS NOT = "00"
               MOVE "STAFF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-RTN-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE SPACE              TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-KEY
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-RTN-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLEAR-010.
           INITIALIZE US-REC.
           MOVE SPACE              TO WK-STAFF-NAME.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE 0                  TO WK-SAVE-CODE.
       CLEAR-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-KEY SECTION.
       PKEY-010.
           IF US-CODE = 0
               MOVE "User code must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
           MOVE US-CODE            TO WK-SAVE-CODE.
           READ USERF
               INVALID KEY
                   PERFORM SETUP-ADD
               NOT INVALID KEY
                   PERFORM SETUP-CHANGE
           END-READ.
           PERFORM EDIT-RECORD.
       PKEY-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-ADD SECTION.
       SADD-010.
           SET MODE-ADD TO TRUE.
           INITIALIZE US-REC.
           MOVE WK-SAVE-CODE       TO US-CODE.
           MOVE 3                  TO US-ROLE.
           MOVE "New user - enter details" TO WK-MSG-LINE.
       SADD-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-CHANGE SECTION.
       SCHG-010.
           IF US-DEL-FLAG = 1
               SET MODE-ADD TO TRUE
               MOVE "Deleted user - re-registering" TO WK-MSG-LINE
           ELSE
               SET MODE-CHG TO TRUE
               MOVE "Existing user - change or PF9 delete"
                                   TO WK-MSG-LINE
           END-IF.
           PERFORM LOOKUP-STAFF.
       SCHG-999.
           EXIT.
      *----------------------------------------------------------------
       EDIT-RECORD SECTION.
       EDIT-010.
           DISPLAY DS-MSG.
           DISPLAY DS-BODY.
           ACCEPT  DS-BODY.
           EVALUATE ESTS
               WHEN "03"
                   CONTINUE
               WHEN "04"
                   MOVE "Cancelled" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               WHEN "09"
                   IF MODE-CHG
                       PERFORM DELETE-RECORD
                   ELSE
                       MOVE "Nothing to delete" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   END-IF
               WHEN "00"
                   PERFORM VALIDATE-BODY
                   IF NOT ERR-YES
                       PERFORM SAVE-RECORD
                   END-IF
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       EDIT-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-BODY SECTION.
       VAL-010.
           MOVE 0                  TO ERR-FLG.
           IF US-LOGIN = SPACE
               MOVE "Login ID is required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF US-NAME = SPACE
               MOVE "User name is required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF US-ROLE < 1 OR US-ROLE > 3
               MOVE "Role must be 1 admin 2 manager 3 clerk"
                                   TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           PERFORM VALIDATE-AUTH.
           IF ERR-YES
               GO TO VAL-999
           END-IF.
           PERFORM VALIDATE-STAFF.
       VAL-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       VALIDATE-AUTH SECTION.
       VAUTH-010.
           IF US-AUTH-MASTER > 1
               MOVE "Auth Master must be 0 or 1" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAUTH-999
           END-IF.
           IF US-AUTH-ORDER > 1
               MOVE "Auth Order must be 0 or 1" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAUTH-999
           END-IF.
           IF US-AUTH-SALES > 1
               MOVE "Auth Sales must be 0 or 1" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAUTH-999
           END-IF.
           IF US-AUTH-PURCH > 1
               MOVE "Auth Purchase must be 0 or 1" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAUTH-999
           END-IF.
           IF US-AUTH-CLOSE > 1
               MOVE "Auth Close must be 0 or 1" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
           END-IF.
       VAUTH-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-STAFF SECTION.
       VSTAF-010.
           IF US-ROLE = 1
               GO TO VSTAF-999
           END-IF.
           IF US-CODE > 9999
               MOVE "Non-admin user code must match a staff code"
                                   TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VSTAF-999
           END-IF.
           MOVE US-CODE            TO SF-CODE.
           READ STAFF
               INVALID KEY
                   MOVE "Staff code not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
               NOT INVALID KEY
                   MOVE SF-NAME    TO WK-STAFF-NAME
           END-READ.
       VSTAF-999.
           EXIT.
      *----------------------------------------------------------------
       SAVE-RECORD SECTION.
       SAVE-010.
           MOVE 0                  TO US-DEL-FLAG.
           IF MODE-ADD
               WRITE US-REC
                   INVALID KEY
                       MOVE "Write failed - duplicate code or login"
                                   TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "User added" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-WRITE
           ELSE
               REWRITE US-REC
                   INVALID KEY
                       MOVE "Update failed" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "User updated" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-REWRITE
           END-IF.
       SAVE-999.
           EXIT.
      *----------------------------------------------------------------
       DELETE-RECORD SECTION.
       DEL-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Press Y then ENTER to delete" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               MOVE 1              TO US-DEL-FLAG
               REWRITE US-REC
                   INVALID KEY
                       MOVE "Delete failed" TO WK-MSG-LINE
                   NOT INVALID KEY
                       MOVE "User deleted" TO WK-MSG-LINE
               END-REWRITE
           ELSE
               MOVE "Delete cancelled" TO WK-MSG-LINE
           END-IF.
           DISPLAY DS-MSG.
       DEL-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-STAFF SECTION.
       LOOK-010.
           MOVE SPACE              TO WK-STAFF-NAME.
           IF US-ROLE = 1
               MOVE "(administrator account)" TO WK-STAFF-NAME
               GO TO LOOK-999
           END-IF.
           IF US-CODE > 9999
               MOVE "(non-staff user code)" TO WK-STAFF-NAME
               GO TO LOOK-999
           END-IF.
           MOVE US-CODE            TO SF-CODE.
           READ STAFF
               INVALID KEY
                   MOVE "??? unknown staff" TO WK-STAFF-NAME
               NOT INVALID KEY
                   MOVE SF-NAME    TO WK-STAFF-NAME
           END-READ.
       LOOK-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE USERF STAFF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "MS0120"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
