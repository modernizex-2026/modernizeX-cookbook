       IDENTIFICATION DIVISION.
       PROGRAM-ID. IV0010.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : IV0010  -  Stock balance inquiry                  *
      *  FUNCTION : browse the stock balance file.  A starting        *
      *             product / warehouse and a sort order are entered; *
      *             each matching stock record is displayed one at a  *
      *             time showing on-hand, allocated, available        *
      *             (=on-hand - allocated), on-order, moving average  *
      *             cost and bin location.  The product name is read  *
      *             from the product master and the warehouse name    *
      *             from the warehouse master.  Read-only inquiry.    *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SSTOK.
           COPY SPROD.
           COPY SWHSE.
       DATA DIVISION.
       FILE SECTION.
           COPY FSTOK.
           COPY FPROD.
           COPY FWHSE.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-INQ.
           02  WK-ORDER            PIC 9(1)  VALUE 1.
             88  ORDER-PW                    VALUE 1.
             88  ORDER-WP                    VALUE 2.
           02  WK-KEY-PROD         PIC 9(8)  VALUE 0.
           02  WK-KEY-WHSE         PIC 9(3)  VALUE 0.
           02  WK-PR-NAME          PIC X(40) VALUE SPACE.
           02  WK-WH-NAME          PIC X(30) VALUE SPACE.
           02  WK-AVAIL            PIC S9(9) VALUE 0.
           02  WK-SAFETY           PIC S9(9) VALUE 0.
           02  WK-REORDER          PIC S9(9) VALUE 0.
           02  WK-STAT             PIC X(12) VALUE SPACE.
           02  WK-SEEN             PIC 9(5)  VALUE 0.
       01  WK-FLAGS.
           02  BRW-FLG             PIC 9(1)  VALUE 0.
             88  BRW-END                     VALUE 1.
           02  REC-FLG             PIC 9(1)  VALUE 0.
             88  REC-YES                     VALUE 1.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4.
             03  COLUMN 2  VALUE "Sort Order   :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1) USING WK-ORDER.
             03  COLUMN 24 VALUE "1:Prod/Whse 2:Whse/Prod" COLOR CYAN.
           02  LINE 6.
             03  COLUMN 2  VALUE "Product Code :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(8) USING WK-KEY-PROD.
           02  LINE 7.
             03  COLUMN 2  VALUE "Warehouse    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(3) USING WK-KEY-WHSE.
       01  DS-DETAIL.
           02  LINE 3.
             03  COLUMN 2  VALUE "Record #     :" COLOR YELLOW.
             03  COLUMN 20 PIC ZZZZ9 FROM WK-SEEN COLOR WHITE.
           02  LINE 9.
             03  COLUMN 2  VALUE "Product      :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(8) FROM SK-PROD COLOR WHITE.
             03  COLUMN 30 PIC X(40) FROM WK-PR-NAME COLOR WHITE.
           02  LINE 10.
             03  COLUMN 2  VALUE "Warehouse    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(3) FROM SK-WHSE COLOR WHITE.
             03  COLUMN 30 PIC X(30) FROM WK-WH-NAME COLOR WHITE.
           02  LINE 11.
             03  COLUMN 2  VALUE "Reorder/Safe :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM WK-REORDER COLOR WHITE.
             03  COLUMN 34 PIC ---,---,--9 FROM WK-SAFETY COLOR WHITE.
           02  LINE 12.
             03  COLUMN 2  VALUE "On Hand      :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM SK-ONHAND COLOR WHITE.
           02  LINE 13.
             03  COLUMN 2  VALUE "Allocated    :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM SK-ALLOCATED
                              COLOR WHITE.
           02  LINE 14.
             03  COLUMN 2  VALUE "Available    :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM WK-AVAIL COLOR WHITE.
             03  COLUMN 34 PIC X(12) FROM WK-STAT COLOR WHITE.
           02  LINE 15.
             03  COLUMN 2  VALUE "On Order     :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM SK-ON-ORDER COLOR WHITE.
           02  LINE 16.
             03  COLUMN 2  VALUE "Avg Cost     :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9.99 FROM SK-AVG-COST
                              COLOR WHITE.
           02  LINE 17.
             03  COLUMN 2  VALUE "Location     :" COLOR YELLOW.
             03  COLUMN 20 PIC X(10) FROM SK-LOCATION COLOR WHITE.
           02  LINE 18.
             03  COLUMN 2  VALUE "Last In      :" COLOR YELLOW.
             03  COLUMN 20 PIC 9999/99/99 FROM SK-LAST-IN-DATE
                              COLOR WHITE.
           02  LINE 19.
             03  COLUMN 2  VALUE "Last Out     :" COLOR YELLOW.
             03  COLUMN 20 PIC 9999/99/99 FROM SK-LAST-OUT-DATE
                              COLOR WHITE.
           02  LINE 20.
             03  COLUMN 2  VALUE "YTD In / Out :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,---,--9 FROM SK-YTD-IN
                              COLOR WHITE.
             03  COLUMN 40 PIC ---,---,---,--9 FROM SK-YTD-OUT
                              COLOR WHITE.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "IV0010"           TO WK-PROGID.
           MOVE "Stock Balance Inquiry"          TO WK-TITLE.
           MOVE "ENTER=Search PF6=Next PF4=New PF3=End"
                                   TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           OPEN INPUT STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN INPUT STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT PRODF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PRODF
               CLOSE PRODF
               OPEN INPUT PRODF
           END-IF.
           OPEN INPUT WHSEF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT WHSEF
               CLOSE WHSEF
               OPEN INPUT WHSEF
           END-IF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-010.
           PERFORM GET-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM START-BROWSE
                   IF REC-YES
                       PERFORM BROWSE-LOOP UNTIL BRW-END
                   END-IF
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       GET-KEY SECTION.
       GKEY-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter search key then ENTER" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           IF WK-ORDER NOT = 1 AND WK-ORDER NOT = 2
               MOVE 1              TO WK-ORDER
           END-IF.
       GKEY-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLRW-010.
           MOVE 0                  TO BRW-FLG REC-FLG.
           MOVE SPACE              TO WK-PR-NAME WK-WH-NAME.
           MOVE 0                  TO WK-AVAIL WK-SEEN.
           MOVE 0                  TO WK-SAFETY WK-REORDER.
           MOVE SPACE              TO WK-STAT.
       CLRW-999.
           EXIT.
      *----------------------------------------------------------------
       START-BROWSE SECTION.
       SBRW-010.
           MOVE 0                  TO REC-FLG.
           MOVE WK-KEY-PROD        TO SK-PROD.
           MOVE WK-KEY-WHSE        TO SK-WHSE.
           IF ORDER-PW
               START STOKF KEY IS >= SK-PROD
                   INVALID KEY
                       MOVE "No stock records from that key"
                                   TO WK-MSG-LINE
                       DISPLAY DS-MSG
                       GO TO SBRW-999
               END-START
           ELSE
               START STOKF KEY IS >= SK-WHSE
                   INVALID KEY
                       MOVE "No stock records from that key"
                                   TO WK-MSG-LINE
                       DISPLAY DS-MSG
                       GO TO SBRW-999
               END-START
           END-IF.
           PERFORM READ-NEXT-REC.
           IF NOT REC-YES
               MOVE "No stock records found" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       SBRW-999.
           EXIT.
      *----------------------------------------------------------------
       BROWSE-LOOP SECTION.
       BLUP-010.
           PERFORM SHOW-DETAIL.
           ACCEPT DS-DETAIL.
           EVALUATE ESTS
               WHEN "03"
                   SET BRW-END TO TRUE
               WHEN "04"
                   SET BRW-END TO TRUE
               WHEN "00"
                   PERFORM READ-NEXT-REC
                   IF NOT REC-YES
                       MOVE "End of list - PF3 to re-enter key"
                                   TO WK-MSG-LINE
                       DISPLAY DS-MSG
                       SET BRW-END TO TRUE
                   END-IF
               WHEN "06"
                   PERFORM READ-NEXT-REC
                   IF NOT REC-YES
                       MOVE "End of list - PF3 to re-enter key"
                                   TO WK-MSG-LINE
                       DISPLAY DS-MSG
                       SET BRW-END TO TRUE
                   END-IF
               WHEN OTHER
                   MOVE "ENTER/PF6=next  PF3/PF4=re-key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       BLUP-999.
           EXIT.
      *----------------------------------------------------------------
       READ-NEXT-REC SECTION.
       RNXT-010.
           MOVE 0                  TO REC-FLG.
           READ STOKF NEXT
               AT END
                   GO TO RNXT-999
           END-READ.
           IF FSTS = "00"
               SET REC-YES TO TRUE
               ADD 1               TO WK-SEEN
               COMPUTE WK-AVAIL = SK-ONHAND - SK-ALLOCATED
               PERFORM LOOKUP-PROD
               PERFORM LOOKUP-WHSE
               PERFORM CALC-STATUS
           END-IF.
       RNXT-999.
           EXIT.
      *----------------------------------------------------------------
       CALC-STATUS SECTION.
       CSTA-010.
           EVALUATE TRUE
               WHEN WK-AVAIL < WK-SAFETY
                   MOVE "LOW STOCK"   TO WK-STAT
               WHEN WK-AVAIL <= WK-REORDER
                   MOVE "REORDER"     TO WK-STAT
               WHEN OTHER
                   MOVE "OK"          TO WK-STAT
           END-EVALUATE.
       CSTA-999.
           EXIT.
      *----------------------------------------------------------------
       SHOW-DETAIL SECTION.
       SDET-010.
           MOVE "Record shown - ENTER/PF6 for next" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-DETAIL.
       SDET-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-PROD SECTION.
       LKPR-010.
           MOVE SPACE              TO WK-PR-NAME.
           MOVE 0                  TO WK-SAFETY WK-REORDER.
           MOVE SK-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "*** unknown product ***" TO WK-PR-NAME
               NOT INVALID KEY
                   MOVE PR-NAME         TO WK-PR-NAME
                   MOVE PR-SAFETY-STOCK TO WK-SAFETY
                   MOVE PR-REORDER-POINT TO WK-REORDER
           END-READ.
       LKPR-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-WHSE SECTION.
       LKWH-010.
           MOVE SPACE              TO WK-WH-NAME.
           MOVE SK-WHSE            TO WH-CODE.
           READ WHSEF
               INVALID KEY
                   MOVE "*** unknown warehouse ***" TO WK-WH-NAME
               NOT INVALID KEY
                   MOVE WH-NAME    TO WK-WH-NAME
           END-READ.
       LKWH-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE STOKF PRODF WHSEF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "IV0010"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
