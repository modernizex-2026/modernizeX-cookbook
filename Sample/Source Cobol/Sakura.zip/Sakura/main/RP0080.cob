       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0080.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0080  -  Accounts-payable balance list         *
      *  FUNCTION : read AP ledger (APLF) in supplier order and      *
      *             accumulate debit (payments), credit (purchases)  *
      *             and closing balance (credit - debit) per         *
      *             supplier.  Supplier name from SUPPF.  Grand      *
      *             totals.  132-column batch text report.           *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SAPL.
           COPY SSUPP.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FAPL.
           COPY FSUPP.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0080.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
           02  WK-FIRST            PIC 9(1)  VALUE 1.
       01  WK-SUPP-NAME            PIC X(34) VALUE SPACE.
       01  WK-CUR.
           02  WK-CUR-SUPP         PIC 9(6)  VALUE 0.
           02  WK-CUR-DR           PIC S9(15) COMP-3 VALUE 0.
           02  WK-CUR-CR           PIC S9(15) COMP-3 VALUE 0.
           02  WK-CUR-CNT          PIC 9(7)  VALUE 0.
       01  WK-CUR-BAL             PIC S9(15) COMP-3 VALUE 0.
       01  WK-TOTALS.
           02  WK-G-DR             PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-CR             PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-BAL            PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-CNT            PIC 9(7)  VALUE 0.
       01  WK-COMPANY              PIC X(40) VALUE SPACE.
       01  RPT-RULE               PIC X(120) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "AS OF    : ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RH-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "SUPP".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(34) VALUE "SUPPLIER NAME".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "  PAYMENTS(DR)".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE " PURCHASE(CR)".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "       BALANCE".
       01  RD-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RS-CODE            PIC 9(6).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RS-NAME            PIC X(34).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RS-DR              PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RS-CR              PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RS-BAL             PIC ---,---,---,--9.
       01  RT-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(44) VALUE "GRAND TOTAL".
           02  RT-DR              PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RT-CR              PIC ---,---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RT-BAL             PIC ---,---,---,--9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0080"           TO WK-PROGID.
           MOVE "ACCOUNTS PAYABLE BALANCE"      TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT APLF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "APLF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT SUPPF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRINT-010.
           MOVE 0                  TO WK-G-CNT.
           MOVE 99                 TO WK-LINE.
           IF NOT MAIN-EOF
               MOVE 0              TO PL-SUPP
               MOVE 0              TO PL-DATE
               START APLF KEY NOT < PL-SUPP
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-NEXT UNTIL MAIN-EOF.
           IF WK-FIRST = 0
               PERFORM FLUSH-SUPP
           END-IF.
           PERFORM PRINT-GRAND.
       PRINT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-NEXT SECTION.
       RN-010.
           READ APLF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   PERFORM PROCESS-ONE
           END-READ.
       RN-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-ONE SECTION.
       PO-010.
           IF WK-FIRST = 1
               MOVE PL-SUPP        TO WK-CUR-SUPP
               PERFORM RESET-ACCUM
               MOVE 0              TO WK-FIRST
           ELSE
               IF PL-SUPP NOT = WK-CUR-SUPP
                   PERFORM FLUSH-SUPP
                   MOVE PL-SUPP    TO WK-CUR-SUPP
                   PERFORM RESET-ACCUM
               END-IF
           END-IF.
           ADD PL-DEBIT            TO WK-CUR-DR.
           ADD PL-CREDIT           TO WK-CUR-CR.
           ADD 1                   TO WK-CUR-CNT.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       RESET-ACCUM SECTION.
       RA-010.
           MOVE 0                  TO WK-CUR-DR WK-CUR-CR WK-CUR-CNT.
       RA-999.
           EXIT.
      *----------------------------------------------------------------
       FLUSH-SUPP SECTION.
       FS-010.
           IF WK-CUR-CNT = 0
               GO TO FS-999
           END-IF.
           COMPUTE WK-CUR-BAL = WK-CUR-CR - WK-CUR-DR.
           PERFORM CHECK-PAGE.
           MOVE SPACE              TO WK-SUPP-NAME.
           MOVE WK-CUR-SUPP        TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE "(unknown)" TO WK-SUPP-NAME
               NOT INVALID KEY
                   MOVE SP-NAME     TO WK-SUPP-NAME
           END-READ.
           MOVE WK-CUR-SUPP        TO RS-CODE.
           MOVE WK-SUPP-NAME       TO RS-NAME.
           MOVE WK-CUR-DR          TO RS-DR.
           MOVE WK-CUR-CR          TO RS-CR.
           MOVE WK-CUR-BAL         TO RS-BAL.
           MOVE RD-LINE            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           ADD WK-CUR-DR           TO WK-G-DR.
           ADD WK-CUR-CR           TO WK-G-CR.
           ADD WK-CUR-BAL          TO WK-G-BAL.
           ADD 1                   TO WK-G-CNT.
       FS-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE RH-LINE            TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE 6                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-GRAND SECTION.
       PG-010.
           IF WK-G-CNT = 0
               PERFORM CHECK-PAGE
               MOVE "*** NO PAYABLES ON FILE ***" TO REP-REC
               WRITE REP-REC
               GO TO PG-999
           END-IF.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-G-DR            TO RT-DR.
           MOVE WK-G-CR            TO RT-CR.
           MOVE WK-G-BAL           TO RT-BAL.
           MOVE RT-LINE            TO REP-REC.
           WRITE REP-REC.
       PG-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE APLF SUPPF REPF.
           DISPLAY "RP0080 complete.  Suppliers = " WK-G-CNT.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0080"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
