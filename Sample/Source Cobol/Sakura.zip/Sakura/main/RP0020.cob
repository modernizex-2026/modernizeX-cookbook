       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0020.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0020  -  Product master list                   *
      *  FUNCTION : print all live products (optionally within a     *
      *             product-code range) with category name, unit,    *
      *             standard cost and list price.  Record count.     *
      *             Batch / line-mode, 132-column text report.       *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SPROD.
           COPY SCATG.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FPROD.
           COPY FCATG.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0020.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
       01  WK-PARM.
           02  WK-IN-FROM          PIC X(8)  VALUE SPACE.
           02  WK-IN-TO            PIC X(8)  VALUE SPACE.
           02  WK-PROD-FROM        PIC 9(8)  VALUE 0.
           02  WK-PROD-TO          PIC 9(8)  VALUE 99999999.
       01  WK-CATG-NAME            PIC X(30) VALUE SPACE.
       01  WK-COMPANY              PIC X(40) VALUE SPACE.
       01  RPT-RULE               PIC X(120) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RH-PROD.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(8)  VALUE "CODE".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(30) VALUE "PRODUCT NAME".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(20) VALUE "CATEGORY".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "UNIT".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(14) VALUE "    STD COST".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(14) VALUE "  LIST PRICE".
       01  RD-PROD.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RP-CODE            PIC 9(8).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RP-NAME            PIC X(30).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RP-CATEGORY        PIC X(20).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RP-UNIT            PIC X(6).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RP-COST            PIC ---,---,--9.99.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RP-PRICE           PIC ---,---,--9.99.
       01  RT-PROD.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(20) VALUE "PRODUCTS LISTED".
           02  RT-COUNT           PIC ZZZ,ZZ9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PARM-RTN.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0020"           TO WK-PROGID.
           MOVE "PRODUCT MASTER LIST"           TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT PRODF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "PRODF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT CATGF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PARM-RTN SECTION.
       PARM-010.
           DISPLAY "RP0020 - Product master list".
           DISPLAY "From product code (blank=first): ".
           ACCEPT  WK-IN-FROM FROM CONSOLE.
           DISPLAY "To   product code (blank=last ): ".
           ACCEPT  WK-IN-TO   FROM CONSOLE.
           IF WK-IN-FROM NUMERIC AND WK-IN-FROM NOT = SPACE
               MOVE WK-IN-FROM     TO WK-PROD-FROM
           ELSE
               MOVE 0              TO WK-PROD-FROM
           END-IF.
           IF WK-IN-TO NUMERIC AND WK-IN-TO NOT = SPACE
               MOVE WK-IN-TO       TO WK-PROD-TO
           ELSE
               MOVE 99999999       TO WK-PROD-TO
           END-IF.
       PARM-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRINT-010.
           MOVE 0                  TO WK-CNT.
           MOVE 99                 TO WK-LINE.
           IF NOT MAIN-EOF
               MOVE WK-PROD-FROM   TO PR-CODE
               START PRODF KEY NOT < PR-CODE
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-NEXT UNTIL MAIN-EOF.
           PERFORM PRINT-TOTALS.
       PRINT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-NEXT SECTION.
       RN-010.
           READ PRODF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   IF PR-CODE > WK-PROD-TO
                       MOVE 1      TO WK-MAIN-EOF
                   ELSE
                       PERFORM PROCESS-ONE
                   END-IF
           END-READ.
       RN-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-ONE SECTION.
       PO-010.
           IF PR-DEL-FLAG = 1
               GO TO PO-999
           END-IF.
           PERFORM CHECK-PAGE.
           PERFORM LOOKUP-CATG.
           MOVE PR-CODE            TO RP-CODE.
           MOVE PR-NAME            TO RP-NAME.
           MOVE WK-CATG-NAME       TO RP-CATEGORY.
           MOVE PR-UNIT            TO RP-UNIT.
           MOVE PR-STD-COST        TO RP-COST.
           MOVE PR-LIST-PRICE      TO RP-PRICE.
           MOVE RD-PROD            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           ADD 1                   TO WK-CNT.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-CATG SECTION.
       LC-010.
           MOVE SPACE              TO WK-CATG-NAME.
           IF PR-CATEGORY NOT = 0
               MOVE PR-CATEGORY    TO CT-CODE
               READ CATGF
                   INVALID KEY
                       MOVE "(unknown)" TO WK-CATG-NAME
                   NOT INVALID KEY
                       MOVE CT-NAME     TO WK-CATG-NAME
               END-READ
           END-IF.
       LC-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE RH-PROD            TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE 6                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-TOTALS SECTION.
       PT-010.
           IF WK-CNT = 0
               PERFORM CHECK-PAGE
               MOVE "*** NO PRODUCTS SELECTED ***" TO REP-REC
               WRITE REP-REC
               GO TO PT-999
           END-IF.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-CNT             TO RT-COUNT.
           MOVE RT-PROD            TO REP-REC.
           WRITE REP-REC.
       PT-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE PRODF CATGF REPF.
           DISPLAY "RP0020 complete.  Products listed = " WK-CNT.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0020"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
