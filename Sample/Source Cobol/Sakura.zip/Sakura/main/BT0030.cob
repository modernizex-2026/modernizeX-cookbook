       IDENTIFICATION DIVISION.
       PROGRAM-ID. BT0030.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : BT0030  -  stock monthly update / valuation       *
      *  FUNCTION : sequentially processes the stock-balance file for *
      *             the month-end snapshot.  For every item/warehouse *
      *             row it computes the inventory valuation           *
      *             (onhand * moving-average cost), carries the YTD    *
      *             in/out figures forward (these are only reset at    *
      *             fiscal-year close, BT0070) and performs balance    *
      *             housekeeping: zero-onhand rows have their average  *
      *             cost cleared and any negative allocated / on-order *
      *             quantities are corrected.  Reads through the       *
      *             warehouse alternate key to give per-warehouse      *
      *             valuation subtotals plus a grand total.            *
      *             Console / batch (no screen section).               *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SSTOK.
           COPY SSYSC.
       DATA DIVISION.
       FILE SECTION.
           COPY FSTOK.
           COPY FSYSC.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- accumulators (grand) --------------------------------------
       01  WK-TOTALS.
           02  WK-READ-CNT         PIC 9(7)  VALUE 0.
           02  WK-ADJ-CNT          PIC 9(7)  VALUE 0.
           02  WK-ZERO-CNT         PIC 9(7)  VALUE 0.
           02  WK-NEG-CNT          PIC 9(7)  VALUE 0.
           02  WK-WHSE-CNT         PIC 9(7)  VALUE 0.
           02  WK-ZEROVAL-CNT      PIC 9(7)  VALUE 0.
           02  WK-ONHAND-TOT       PIC S9(13) VALUE 0.
           02  WK-AVAIL-TOT        PIC S9(13) VALUE 0.
           02  WK-VAL-TOT          PIC S9(13)V9(2) VALUE 0.
           02  WK-YTDIN-TOT        PIC S9(13) VALUE 0.
           02  WK-YTDOUT-TOT       PIC S9(13) VALUE 0.
      *----- per-warehouse subtotals -----------------------------------
       01  WK-SUBS.
           02  WK-WH-ITEMS         PIC 9(7)  VALUE 0.
           02  WK-WH-ONHAND        PIC S9(13) VALUE 0.
           02  WK-WH-VAL           PIC S9(13)V9(2) VALUE 0.
      *----- per-item calc / control break -----------------------------
       01  WK-CALC.
           02  WK-ITEM-VAL         PIC S9(13)V9(2) VALUE 0.
           02  WK-AVAIL            PIC S9(9) VALUE 0.
           02  WK-CHG-FLG          PIC 9(1)  VALUE 0.
           02  WK-FIRST-FLG        PIC 9(1)  VALUE 0.
           02  WK-PREV-WHSE        PIC 9(3)  VALUE 0.
      *----- display edit work -----------------------------------------
       01  WK-DISP.
           02  WK-E-CNT            PIC Z,ZZZ,ZZ9.
           02  WK-E-WHSE           PIC ZZ9.
           02  WK-E-QTY            PIC Z,ZZZ,ZZZ,ZZ9-.
           02  WK-E-VAL            PIC Z,ZZZ,ZZZ,ZZZ,ZZ9.99-.
           02  WK-E-YM             PIC 9999/99.
           02  WK-E-PROD           PIC ZZZZZZZ9.
      *----- flags -----------------------------------------------------
       01  WK-FLAGS.
           02  WK-ABORT-FLG        PIC 9(1)  VALUE 0.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           IF WK-ABORT-FLG = 0
               PERFORM PROCESS-RTN
               PERFORM PRINT-SUMMARY
           END-IF.
           PERFORM TERM-RTN.
           MOVE 0                  TO COMPLETION-CODE.
           EXIT PROGRAM.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "BT0030"           TO WK-PROGID.
           DISPLAY " ".
           DISPLAY "==============================================".
           DISPLAY " SAKURA-SMS  BT0030  -  STOCK MONTHLY UPDATE".
           DISPLAY "==============================================".
           PERFORM GET-TODAY.
           PERFORM OPEN-FILES.
           PERFORM READ-SYSCF.
           PERFORM CONFIRM-RUN.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       GET-TODAY SECTION.
       GTOD-010.
           MOVE "TODY"             TO KD-FUNC.
           MOVE 0                  TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE  WK-SYSYMD.
       GTOD-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPEN-010.
           OPEN I-O    STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF"        TO KA-FILE
               MOVE "Open STOKF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT  SYSCF.
           IF FSTS NOT = "00"
               MOVE "SYSCF"        TO KA-FILE
               MOVE "Open SYSCF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OPEN-999.
           EXIT.
      *----------------------------------------------------------------
       READ-SYSCF SECTION.
       RSYS-010.
           MOVE 1                  TO SY-KEY.
           READ SYSCF
               INVALID KEY
                   MOVE "SYSCF"    TO KA-FILE
                   MOVE "System control record missing" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-READ.
       RSYS-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-RUN SECTION.
       CONF-010.
           MOVE SY-CURR-YM         TO WK-E-YM.
           DISPLAY " ".
           DISPLAY " Accounting month : " WK-E-YM.
           DISPLAY " Run stock monthly snapshot / housekeeping ?".
           DISPLAY " Proceed ? (Y/N) : " WITH NO ADVANCING.
           MOVE SPACE              TO WK-CONFIRM.
           ACCEPT WK-CONFIRM FROM CONSOLE.
           IF NOT CONFIRM-YES
               DISPLAY " ** cancelled by operator."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       CONF-999.
           EXIT.
      *----------------------------------------------------------------
      *  PROCESS : read STOKF by warehouse alt key, break on SK-WHSE   *
      *----------------------------------------------------------------
       PROCESS-RTN SECTION.
       PROC-010.
           DISPLAY " ".
           DISPLAY " Processing stock rows ...".
           DISPLAY " ".
           DISPLAY " WHSE      ITEMS         ONHAND"
               "          VALUATION".
           DISPLAY "----------------------------------------------".
           MOVE 0                  TO EOF-FLG.
           MOVE 1                  TO WK-FIRST-FLG.
           MOVE 0                  TO WK-PREV-WHSE.
           PERFORM CLEAR-SUBTOTAL.
           MOVE 0                  TO SK-WHSE.
           MOVE 0                  TO SK-PROD.
           START STOKF KEY NOT LESS THAN SK-WHSE
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM PROC-NEXT UNTIL EOF-YES.
      *    emit the final warehouse subtotal
           IF WK-FIRST-FLG = 0
               PERFORM PRINT-SUBTOTAL
           END-IF.
       PROC-999.
           EXIT.
      *----------------------------------------------------------------
       PROC-NEXT SECTION.
       PNXT-010.
           READ STOKF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO PNXT-999
           END-READ.
           IF FSTS NOT = "00" AND FSTS NOT = "02"
               MOVE "STOKF"        TO KA-FILE
               MOVE "READ NEXT STOKF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           IF WK-FIRST-FLG = 1
               MOVE 0              TO WK-FIRST-FLG
               MOVE SK-WHSE        TO WK-PREV-WHSE
           END-IF.
           IF SK-WHSE NOT = WK-PREV-WHSE
               PERFORM PRINT-SUBTOTAL
               PERFORM CLEAR-SUBTOTAL
               MOVE SK-WHSE        TO WK-PREV-WHSE
           END-IF.
           PERFORM PROCESS-ONE.
       PNXT-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-ONE SECTION.
       PONE-010.
           ADD 1                   TO WK-READ-CNT.
           MOVE 0                  TO WK-CHG-FLG.
      *    valuation = onhand * moving-average cost
           COMPUTE WK-ITEM-VAL = SK-ONHAND * SK-AVG-COST.
      *    available = onhand - allocated
           COMPUTE WK-AVAIL = SK-ONHAND - SK-ALLOCATED.
      *    accumulate grand + subtotal figures
           ADD SK-ONHAND           TO WK-ONHAND-TOT  WK-WH-ONHAND.
           ADD WK-AVAIL            TO WK-AVAIL-TOT.
           ADD WK-ITEM-VAL         TO WK-VAL-TOT     WK-WH-VAL.
           ADD SK-YTD-IN           TO WK-YTDIN-TOT.
           ADD SK-YTD-OUT          TO WK-YTDOUT-TOT.
           ADD 1                   TO WK-WH-ITEMS.
      *    classify exceptions
           IF WK-ITEM-VAL = 0
               ADD 1               TO WK-ZEROVAL-CNT
           END-IF.
           IF SK-ONHAND < 0
               ADD 1               TO WK-NEG-CNT
               MOVE SK-PROD        TO WK-E-PROD
               MOVE SK-WHSE        TO WK-E-WHSE
               MOVE SK-ONHAND      TO WK-E-QTY
               DISPLAY "   NEG prod " WK-E-PROD " wh " WK-E-WHSE
                   " onhand " WK-E-QTY
           END-IF.
           IF SK-ONHAND = 0
               ADD 1               TO WK-ZERO-CNT
           END-IF.
           PERFORM HOUSEKEEP-ONE.
           IF WK-CHG-FLG = 1
               MOVE WK-SYSDATE     TO SK-LAST-OUT-DATE
               REWRITE SK-REC
                   INVALID KEY
                       MOVE "STOKF" TO KA-FILE
                       MOVE "REWRITE STOKF failed" TO KA-DETAIL
                       PERFORM ABEND-RTN
               END-REWRITE
               ADD 1               TO WK-ADJ-CNT
           END-IF.
       PONE-999.
           EXIT.
      *----------------------------------------------------------------
      *  HOUSEKEEP-ONE : normalise doubtful balance values             *
      *----------------------------------------------------------------
       HOUSEKEEP-ONE SECTION.
       HOUS-010.
      *    zero (or negative) onhand -> clear the average cost
           IF SK-ONHAND <= 0 AND SK-AVG-COST NOT = 0
               MOVE 0              TO SK-AVG-COST
               MOVE 1              TO WK-CHG-FLG
           END-IF.
      *    negative committed / on-order quantities are impossible
           IF SK-ALLOCATED < 0
               MOVE 0              TO SK-ALLOCATED
               MOVE 1              TO WK-CHG-FLG
           END-IF.
           IF SK-ON-ORDER < 0
               MOVE 0              TO SK-ON-ORDER
               MOVE 1              TO WK-CHG-FLG
           END-IF.
       HOUS-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-SUBTOTAL SECTION.
       CLSB-010.
           MOVE 0                  TO WK-WH-ITEMS.
           MOVE 0                  TO WK-WH-ONHAND.
           MOVE 0                  TO WK-WH-VAL.
       CLSB-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-SUBTOTAL SECTION.
       PRSB-010.
           ADD 1                   TO WK-WHSE-CNT.
           MOVE WK-PREV-WHSE       TO WK-E-WHSE.
           MOVE WK-WH-ITEMS        TO WK-E-CNT.
           MOVE WK-WH-ONHAND       TO WK-E-QTY.
           MOVE WK-WH-VAL          TO WK-E-VAL.
           DISPLAY " " WK-E-WHSE " " WK-E-CNT " " WK-E-QTY
               " " WK-E-VAL.
       PRSB-999.
           EXIT.
      *----------------------------------------------------------------
      *  PRINT-SUMMARY                                                 *
      *----------------------------------------------------------------
       PRINT-SUMMARY SECTION.
       PSUM-010.
           DISPLAY "----------------------------------------------".
           DISPLAY " STOCK MONTHLY UPDATE SUMMARY".
           DISPLAY "----------------------------------------------".
           MOVE WK-READ-CNT        TO WK-E-CNT.
           DISPLAY " Stock rows read   : " WK-E-CNT.
           MOVE WK-WHSE-CNT        TO WK-E-CNT.
           DISPLAY " Warehouses        : " WK-E-CNT.
           MOVE WK-ADJ-CNT         TO WK-E-CNT.
           DISPLAY " Rows adjusted     : " WK-E-CNT.
           MOVE WK-ZERO-CNT        TO WK-E-CNT.
           DISPLAY " Zero-onhand rows  : " WK-E-CNT.
           MOVE WK-NEG-CNT         TO WK-E-CNT.
           DISPLAY " Negative-onhand   : " WK-E-CNT.
           MOVE WK-ZEROVAL-CNT     TO WK-E-CNT.
           DISPLAY " Zero-value rows   : " WK-E-CNT.
           MOVE WK-ONHAND-TOT      TO WK-E-QTY.
           DISPLAY " Total onhand qty  : " WK-E-QTY.
           MOVE WK-AVAIL-TOT       TO WK-E-QTY.
           DISPLAY " Total available   : " WK-E-QTY.
           MOVE WK-YTDIN-TOT       TO WK-E-QTY.
           DISPLAY " Total YTD in      : " WK-E-QTY.
           MOVE WK-YTDOUT-TOT      TO WK-E-QTY.
           DISPLAY " Total YTD out     : " WK-E-QTY.
           MOVE WK-VAL-TOT         TO WK-E-VAL.
           DISPLAY " Total valuation   : " WK-E-VAL.
           DISPLAY "----------------------------------------------".
           DISPLAY " BT0030 completed normally.".
       PSUM-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE STOKF.
           CLOSE SYSCF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABND-010.
           MOVE "BT0030"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EBATCH"           TO KA-MSGCODE.
           CALL "ABORTX" USING KABEND.
           CLOSE STOKF.
           CLOSE SYSCF.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABND-999.
           EXIT.
