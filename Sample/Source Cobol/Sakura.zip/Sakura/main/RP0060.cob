       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0060.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0060  -  Inventory valuation list              *
      *  FUNCTION : list stock balances (STOKF) in warehouse order   *
      *             with product name (PRODF), on-hand quantity,     *
      *             moving-average cost and stock value              *
      *             (= on-hand * avg cost).  Subtotal per warehouse  *
      *             plus a grand total.  132-column batch text.      *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SSTOK.
           COPY SPROD.
           COPY SWHSE.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FSTOK.
           COPY FPROD.
           COPY FWHSE.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0060.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
           02  WK-FIRST            PIC 9(1)  VALUE 1.
       01  WK-CUR-WHSE             PIC 9(3)  VALUE 0.
       01  WK-WH-NAME              PIC X(30) VALUE SPACE.
       01  WK-PROD-NAME            PIC X(30) VALUE SPACE.
       01  WK-VAL                  PIC S9(15)V9(2) COMP-3 VALUE 0.
       01  WK-SUB.
           02  WK-SUB-QTY          PIC S9(13) COMP-3 VALUE 0.
           02  WK-SUB-VAL          PIC S9(15)V9(2) COMP-3 VALUE 0.
       01  WK-TOTALS.
           02  WK-G-QTY            PIC S9(13) COMP-3 VALUE 0.
           02  WK-G-VAL            PIC S9(15)V9(2) COMP-3 VALUE 0.
           02  WK-G-CNT            PIC 9(7)  VALUE 0.
       01  WK-COMPANY              PIC X(40) VALUE SPACE.
       01  RPT-RULE               PIC X(120) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RH-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(8)  VALUE "PRODUCT".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(30) VALUE "PRODUCT NAME".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(12) VALUE "     ON HAND".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(14) VALUE "      AVG COST".
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(18) VALUE "             VALUE".
       01  RD-WHD.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(11) VALUE "WAREHOUSE: ".
           02  WHD-CODE           PIC 9(3).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  WHD-NAME           PIC X(30).
       01  RD-LINE.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RS-PROD            PIC 9(8).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  RS-NAME            PIC X(30).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RS-ONHAND          PIC ----,---,--9.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RS-AVGCOST         PIC ---,---,--9.99.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  RS-VALUE           PIC ---,---,---,--9.99.
       01  RD-SUB.
           02  FILLER             PIC X(42)
               VALUE "  WAREHOUSE SUBTOTAL".
           02  SUB-QTY            PIC ----,---,--9.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(14) VALUE SPACE.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  SUB-VAL            PIC ---,---,---,--9.99.
       01  RD-GRAND.
           02  FILLER             PIC X(42) VALUE "  GRAND TOTAL".
           02  GT-QTY             PIC ----,---,--9.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(14) VALUE SPACE.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  GT-VAL             PIC ---,---,---,--9.99.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0060"           TO WK-PROGID.
           MOVE "INVENTORY VALUATION LIST"      TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT STOKF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "STOKF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT PRODF.
           OPEN INPUT WHSEF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRINT-010.
           MOVE 0                  TO WK-G-CNT.
           MOVE 99                 TO WK-LINE.
           IF NOT MAIN-EOF
               MOVE 0              TO SK-WHSE
               MOVE 0              TO SK-PROD
               START STOKF KEY NOT < SK-WHSE
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-NEXT UNTIL MAIN-EOF.
           IF WK-FIRST = 0
               PERFORM PRINT-SUB
               PERFORM PRINT-GRAND
           ELSE
               PERFORM PAGE-HEAD
               MOVE "*** NO STOCK RECORDS ***" TO REP-REC
               WRITE REP-REC
           END-IF.
       PRINT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-NEXT SECTION.
       RN-010.
           READ STOKF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   PERFORM PROCESS-ONE
           END-READ.
       RN-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-ONE SECTION.
       PO-010.
           IF WK-FIRST = 1
               MOVE SK-WHSE        TO WK-CUR-WHSE
               PERFORM RESET-SUB
               PERFORM PRINT-WHD
               MOVE 0              TO WK-FIRST
           ELSE
               IF SK-WHSE NOT = WK-CUR-WHSE
                   PERFORM PRINT-SUB
                   MOVE SK-WHSE    TO WK-CUR-WHSE
                   PERFORM RESET-SUB
                   PERFORM PRINT-WHD
               END-IF
           END-IF.
           PERFORM PRINT-DETAIL.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       RESET-SUB SECTION.
       RS-010.
           MOVE 0                  TO WK-SUB-QTY WK-SUB-VAL.
       RS-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-WHD SECTION.
       PW-010.
           PERFORM CHECK-PAGE.
           MOVE SPACE              TO WK-WH-NAME.
           MOVE WK-CUR-WHSE        TO WH-CODE.
           READ WHSEF
               INVALID KEY
                   MOVE "(unknown)" TO WK-WH-NAME
               NOT INVALID KEY
                   MOVE WH-NAME     TO WK-WH-NAME
           END-READ.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           MOVE WK-CUR-WHSE        TO WHD-CODE.
           MOVE WK-WH-NAME         TO WHD-NAME.
           MOVE RD-WHD             TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
       PW-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-DETAIL SECTION.
       PDT-010.
           PERFORM CHECK-PAGE.
           MOVE SPACE              TO WK-PROD-NAME.
           MOVE SK-PROD            TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "(unknown)" TO WK-PROD-NAME
               NOT INVALID KEY
                   MOVE PR-NAME     TO WK-PROD-NAME
           END-READ.
           COMPUTE WK-VAL = SK-ONHAND * SK-AVG-COST.
           MOVE SK-PROD            TO RS-PROD.
           MOVE WK-PROD-NAME       TO RS-NAME.
           MOVE SK-ONHAND          TO RS-ONHAND.
           MOVE SK-AVG-COST        TO RS-AVGCOST.
           MOVE WK-VAL             TO RS-VALUE.
           MOVE RD-LINE            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           ADD SK-ONHAND           TO WK-SUB-QTY WK-G-QTY.
           ADD WK-VAL              TO WK-SUB-VAL WK-G-VAL.
           ADD 1                   TO WK-G-CNT.
       PDT-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-SUB SECTION.
       PSB-010.
           PERFORM CHECK-PAGE.
           MOVE WK-SUB-QTY         TO SUB-QTY.
           MOVE WK-SUB-VAL         TO SUB-VAL.
           MOVE RD-SUB             TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
       PSB-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-GRAND SECTION.
       PG-010.
           PERFORM CHECK-PAGE.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-G-QTY           TO GT-QTY.
           MOVE WK-G-VAL           TO GT-VAL.
           MOVE RD-GRAND           TO REP-REC.
           WRITE REP-REC.
       PG-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE RH-LINE            TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE 6                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE STOKF PRODF WHSEF REPF.
           DISPLAY "RP0060 complete.  Stock lines = " WK-G-CNT.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0060"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
