       IDENTIFICATION DIVISION.
       PROGRAM-ID. MS0030.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : MS0030  -  Product master maintenance            *
      *  FUNCTION : add / change / delete / inquire product master.  *
      *             Enter a product code; if it exists the record    *
      *             is shown for change or delete, otherwise a new   *
      *             record is entered.  Category, default supplier   *
      *             and default warehouse are validated against       *
      *             their masters and their names displayed.  The    *
      *             five rank prices, costs and list price are all   *
      *             maintained on the screen.                        *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SPROD.
           COPY SCATG.
           COPY SSUPP.
           COPY SWHSE.
       I-O-CONTROL.
           APPLY SHARED-MODE ON PRODF.
       DATA DIVISION.
       FILE SECTION.
           COPY FPROD.
           COPY FCATG.
           COPY FSUPP.
           COPY FWHSE.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-LOOKUP.
           02  WK-CATG-NAME       PIC X(30) VALUE SPACE.
           02  WK-SUPP-NAME       PIC X(40) VALUE SPACE.
           02  WK-WHSE-NAME       PIC X(30) VALUE SPACE.
       01  WK-SAVE-CODE           PIC 9(8)  VALUE 0.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4 COLUMN 2  VALUE "Product Code  :" COLOR YELLOW.
           02  SC-KEY LINE 4 COLUMN 20 PIC 9(8) USING PR-CODE.
       01  DS-BODY.
           02  LINE 5.
             03  COLUMN 2  VALUE "Name          :" COLOR YELLOW.
             03  COLUMN 20 PIC X(40) USING PR-NAME.
           02  LINE 6.
             03  COLUMN 2  VALUE "Search Name   :" COLOR YELLOW.
             03  COLUMN 20 PIC X(40) USING PR-KANA.
           02  LINE 7.
             03  COLUMN 2  VALUE "Spec / Model  :" COLOR YELLOW.
             03  COLUMN 20 PIC X(30) USING PR-SPEC.
           02  LINE 8.
             03  COLUMN 2  VALUE "Category      :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(4)  USING PR-CATEGORY.
             03  COLUMN 26 PIC X(30) FROM WK-CATG-NAME COLOR WHITE.
           02  LINE 9.
             03  COLUMN 2  VALUE "Barcode       :" COLOR YELLOW.
             03  COLUMN 20 PIC X(13) USING PR-BARCODE.
             03  COLUMN 36 VALUE "Unit:" COLOR YELLOW.
             03  COLUMN 42 PIC X(6)  USING PR-UNIT.
           02  LINE 10.
             03  COLUMN 2  VALUE "Std Cost      :" COLOR YELLOW.
             03  COLUMN 20 PIC S9(9)V9(2) USING PR-STD-COST.
             03  COLUMN 34 VALUE "List Price:" COLOR YELLOW.
             03  COLUMN 46 PIC S9(9)V9(2) USING PR-LIST-PRICE.
           02  LINE 11.
             03  COLUMN 2  VALUE "Last Cost     :" COLOR YELLOW.
             03  COLUMN 20 PIC S9(9)V9(2) USING PR-LAST-COST.
             03  COLUMN 34 VALUE "Tax:" COLOR YELLOW.
             03  COLUMN 39 PIC 9(1) USING PR-TAX-CATEGORY.
             03  COLUMN 41 VALUE "1:std 2:reduced 3:exempt" COLOR CYAN.
           02  LINE 12.
             03  COLUMN 2  VALUE "Rank1:" COLOR YELLOW.
             03  COLUMN 9  PIC S9(9)V9(2) USING PR-RANK-PRICE(1).
             03  COLUMN 23 VALUE "Rank2:" COLOR YELLOW.
             03  COLUMN 30 PIC S9(9)V9(2) USING PR-RANK-PRICE(2).
             03  COLUMN 44 VALUE "Rank3:" COLOR YELLOW.
             03  COLUMN 51 PIC S9(9)V9(2) USING PR-RANK-PRICE(3).
           02  LINE 13.
             03  COLUMN 2  VALUE "Rank4:" COLOR YELLOW.
             03  COLUMN 9  PIC S9(9)V9(2) USING PR-RANK-PRICE(4).
             03  COLUMN 23 VALUE "Rank5:" COLOR YELLOW.
             03  COLUMN 30 PIC S9(9)V9(2) USING PR-RANK-PRICE(5).
           02  LINE 14.
             03  COLUMN 2  VALUE "Safety Stock  :" COLOR YELLOW.
             03  COLUMN 20 PIC S9(9) USING PR-SAFETY-STOCK.
             03  COLUMN 34 VALUE "Reorder Pt:" COLOR YELLOW.
             03  COLUMN 46 PIC S9(9) USING PR-REORDER-POINT.
           02  LINE 15.
             03  COLUMN 2  VALUE "Reorder Qty   :" COLOR YELLOW.
             03  COLUMN 20 PIC S9(9) USING PR-REORDER-QTY.
             03  COLUMN 34 VALUE "Lead Days:" COLOR YELLOW.
             03  COLUMN 45 PIC 9(3) USING PR-LEAD-DAYS.
           02  LINE 16.
             03  COLUMN 2  VALUE "Dflt Supplier :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(6)  USING PR-DFLT-SUPP.
             03  COLUMN 28 PIC X(30) FROM WK-SUPP-NAME COLOR WHITE.
           02  LINE 17.
             03  COLUMN 2  VALUE "Dflt Warehouse:" COLOR YELLOW.
             03  COLUMN 20 PIC 9(3)  USING PR-DFLT-WHSE.
             03  COLUMN 25 PIC X(30) FROM WK-WHSE-NAME COLOR WHITE.
           02  LINE 18.
             03  COLUMN 2  VALUE "Stock Mng     :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(1)  USING PR-STOCK-MNG.
             03  COLUMN 23 VALUE "0:no 1:managed" COLOR CYAN.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Confirm (Y/N) :" COLOR YELLOW.
           02  SC-CONF LINE 21 COLUMN 20 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "MS0030"           TO WK-PROGID.
           MOVE "Product Master Maintenance"     TO WK-TITLE.
           MOVE "ENTER=Read  PF9=Delete  PF3=End" TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           OPEN I-O    PRODF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PRODF
               CLOSE PRODF
               OPEN I-O PRODF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "PRODF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT  CATGF.
           IF FSTS NOT = "00"
               MOVE "CATGF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT  SUPPF.
           IF FSTS NOT = "00"
               MOVE "SUPPF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT  WHSEF.
           IF FSTS NOT = "00"
               MOVE "WHSEF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-RTN-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE SPACE              TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-KEY
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-RTN-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLEAR-010.
           INITIALIZE PR-REC.
           MOVE SPACE              TO WK-CATG-NAME.
           MOVE SPACE              TO WK-SUPP-NAME WK-WHSE-NAME.
           MOVE SPACE              TO WK-CONFIRM.
       CLEAR-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-KEY SECTION.
       PKEY-010.
           IF PR-CODE = 0
               MOVE "Product code must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
           MOVE PR-CODE            TO WK-SAVE-CODE.
           READ PRODF
               INVALID KEY
                   PERFORM SETUP-ADD
               NOT INVALID KEY
                   PERFORM SETUP-CHANGE
           END-READ.
           PERFORM EDIT-RECORD.
       PKEY-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-ADD SECTION.
       SADD-010.
           SET MODE-ADD TO TRUE.
           INITIALIZE PR-REC.
           MOVE WK-SAVE-CODE       TO PR-CODE.
           MOVE 1                  TO PR-TAX-CATEGORY.
           MOVE 1                  TO PR-STOCK-MNG.
           MOVE "New product - enter details" TO WK-MSG-LINE.
       SADD-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-CHANGE SECTION.
       SCHG-010.
           IF PR-DEL-FLAG = 1
               SET MODE-ADD TO TRUE
               MOVE "Deleted product - re-registering" TO WK-MSG-LINE
           ELSE
               SET MODE-CHG TO TRUE
               MOVE "Existing product - change or PF9 delete"
                                   TO WK-MSG-LINE
           END-IF.
           PERFORM LOOKUP-NAMES.
       SCHG-999.
           EXIT.
      *----------------------------------------------------------------
       EDIT-RECORD SECTION.
       EDIT-010.
           DISPLAY DS-MSG.
           DISPLAY DS-BODY.
           ACCEPT  DS-BODY.
           EVALUATE ESTS
               WHEN "03"
                   CONTINUE
               WHEN "04"
                   MOVE "Cancelled" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               WHEN "09"
                   IF MODE-CHG
                       PERFORM DELETE-RECORD
                   ELSE
                       MOVE "Nothing to delete" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   END-IF
               WHEN "00"
                   PERFORM VALIDATE-BODY
                   IF NOT ERR-YES
                       PERFORM SAVE-RECORD
                   END-IF
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       EDIT-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-BODY SECTION.
       VAL-010.
           MOVE 0                  TO ERR-FLG.
           IF PR-NAME = SPACE
               MOVE "Name is required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF PR-CATEGORY = 0
               MOVE "Category is required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           MOVE PR-CATEGORY        TO CT-CODE.
           READ CATGF
               INVALID KEY
                   MOVE "Category code not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VAL-999
               NOT INVALID KEY
                   MOVE CT-NAME    TO WK-CATG-NAME
           END-READ.
           IF PR-TAX-CATEGORY < 1 OR PR-TAX-CATEGORY > 3
               MOVE "Tax category must be 1-3" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF PR-STOCK-MNG > 1
               MOVE "Stock mgmt must be 0 or 1" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF PR-STD-COST < 0 OR PR-LAST-COST < 0
               MOVE "Cost cannot be negative" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF PR-LIST-PRICE < 0
               MOVE "List price cannot be negative" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > 5
               IF PR-RANK-PRICE(WK-IDX) < 0
                   MOVE "Rank price cannot be negative" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
               END-IF
           END-PERFORM.
           IF ERR-YES
               GO TO VAL-999
           END-IF.
           IF PR-SAFETY-STOCK < 0 OR PR-REORDER-POINT < 0
               MOVE "Stock levels cannot be negative" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           IF PR-REORDER-QTY < 0
               MOVE "Reorder qty cannot be negative" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VAL-999
           END-IF.
           PERFORM CHK-SUPPLIER.
           IF ERR-YES
               GO TO VAL-999
           END-IF.
           PERFORM CHK-WAREHOUSE.
       VAL-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       CHK-SUPPLIER SECTION.
       CHKS-010.
           IF PR-DFLT-SUPP = 0
               GO TO CHKS-999
           END-IF.
           MOVE PR-DFLT-SUPP       TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE "Default supplier not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
               NOT INVALID KEY
                   MOVE SP-NAME    TO WK-SUPP-NAME
           END-READ.
       CHKS-999.
           EXIT.
      *----------------------------------------------------------------
       CHK-WAREHOUSE SECTION.
       CHKW-010.
           IF PR-DFLT-WHSE = 0
               GO TO CHKW-999
           END-IF.
           MOVE PR-DFLT-WHSE       TO WH-CODE.
           READ WHSEF
               INVALID KEY
                   MOVE "Default warehouse not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
               NOT INVALID KEY
                   MOVE WH-NAME    TO WK-WHSE-NAME
           END-READ.
       CHKW-999.
           EXIT.
      *----------------------------------------------------------------
       SAVE-RECORD SECTION.
       SAVE-010.
           MOVE WK-SYSDATE         TO PR-UPD-DATE.
           MOVE WK-USER-CODE       TO PR-UPD-USER.
           MOVE 0                  TO PR-DEL-FLAG.
           IF MODE-ADD
               MOVE WK-SYSDATE     TO PR-ADD-DATE
               MOVE WK-USER-CODE   TO PR-ADD-USER
               WRITE PR-REC
                   INVALID KEY
                       MOVE "Write failed - duplicate" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Product added" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-WRITE
           ELSE
               REWRITE PR-REC
                   INVALID KEY
                       MOVE "Update failed" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Product updated" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-REWRITE
           END-IF.
       SAVE-999.
           EXIT.
      *----------------------------------------------------------------
       DELETE-RECORD SECTION.
       DEL-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Press Y then ENTER to delete" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               MOVE 1              TO PR-DEL-FLAG
               MOVE WK-SYSDATE     TO PR-UPD-DATE
               MOVE WK-USER-CODE   TO PR-UPD-USER
               REWRITE PR-REC
                   INVALID KEY
                       MOVE "Delete failed" TO WK-MSG-LINE
                   NOT INVALID KEY
                       MOVE "Product deleted" TO WK-MSG-LINE
               END-REWRITE
           ELSE
               MOVE "Delete cancelled" TO WK-MSG-LINE
           END-IF.
           DISPLAY DS-MSG.
       DEL-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-NAMES SECTION.
       LOOK-010.
           MOVE SPACE              TO WK-CATG-NAME.
           IF PR-CATEGORY NOT = 0
               MOVE PR-CATEGORY    TO CT-CODE
               READ CATGF
                   INVALID KEY
                       MOVE "??? unknown category" TO WK-CATG-NAME
                   NOT INVALID KEY
                       MOVE CT-NAME TO WK-CATG-NAME
               END-READ
           END-IF.
           MOVE SPACE              TO WK-SUPP-NAME.
           IF PR-DFLT-SUPP NOT = 0
               MOVE PR-DFLT-SUPP   TO SP-CODE
               READ SUPPF
                   INVALID KEY
                       MOVE "??? unknown supplier" TO WK-SUPP-NAME
                   NOT INVALID KEY
                       MOVE SP-NAME TO WK-SUPP-NAME
               END-READ
           END-IF.
           MOVE SPACE              TO WK-WHSE-NAME.
           IF PR-DFLT-WHSE NOT = 0
               MOVE PR-DFLT-WHSE   TO WH-CODE
               READ WHSEF
                   INVALID KEY
                       MOVE "??? unknown warehouse" TO WK-WHSE-NAME
                   NOT INVALID KEY
                       MOVE WH-NAME TO WK-WHSE-NAME
               END-READ
           END-IF.
       LOOK-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE PRODF CATGF SUPPF WHSEF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "MS0030"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
