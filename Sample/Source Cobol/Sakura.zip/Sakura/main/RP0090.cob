       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0090.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0090  -  Sales order backlog                   *
      *  FUNCTION : list open sales orders (ORDHF, status < 3) and   *
      *             their detail lines (ORDDF) that still have        *
      *             outstanding quantity (order qty - shipped qty).  *
      *             Show per-order outstanding qty and amount and    *
      *             grand totals.  132-column batch text report.     *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SORDH.
           COPY SORDD.
           COPY SCUST.
           COPY SPROD.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FORDH.
           COPY FORDD.
           COPY FCUST.
           COPY FPROD.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0090.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
           02  WK-DTL-EOF          PIC 9(1)  VALUE 0.
             88  DTL-EOF                     VALUE 1.
           02  WK-HDR-PRINTED      PIC 9(1)  VALUE 0.
       01  WK-OUT                  PIC S9(11) VALUE 0.
       01  WK-OUT-AMT              PIC S9(15) COMP-3 VALUE 0.
       01  WK-CUST-NAME            PIC X(26) VALUE SPACE.
       01  WK-PROD-NAME            PIC X(22) VALUE SPACE.
       01  WK-ORD.
           02  WK-ORD-QTY          PIC S9(13) COMP-3 VALUE 0.
           02  WK-ORD-AMT          PIC S9(15) COMP-3 VALUE 0.
       01  WK-TOTALS.
           02  WK-G-QTY            PIC S9(13) COMP-3 VALUE 0.
           02  WK-G-AMT            PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-ORD            PIC 9(7)  VALUE 0.
           02  WK-G-LIN            PIC 9(7)  VALUE 0.
       01  WK-COMPANY              PIC X(40) VALUE SPACE.
       01  RPT-RULE               PIC X(120) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RD-ORDH.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "ORD# ".
           02  OH-NO-E            PIC 9(10).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "DATE ".
           02  OH-DATE-E          PIC 9999/99/99.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "CUST ".
           02  OH-CUST-E          PIC 9(6).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  OH-CNAME           PIC X(26).
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(5)  VALUE "DUE ".
           02  OH-DUE-E           PIC 9999/99/99.
           02  FILLER             PIC X(2)  VALUE SPACE.
           02  FILLER             PIC X(4)  VALUE "ST ".
           02  OH-ST-E            PIC 9(1).
       01  RD-ORDD.
           02  FILLER             PIC X(6)  VALUE SPACE.
           02  FILLER             PIC X(5)  VALUE "LINE ".
           02  OD-LINE-E          PIC 9(3).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  OD-PROD-E          PIC 9(8).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  OD-PNAME           PIC X(22).
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  OD-ORD-E           PIC ---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  OD-SHP-E           PIC ---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  OD-OUT-E           PIC ---,---,--9.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  OD-PRICE-E         PIC ---,---,--9.99.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  OD-AMT-E           PIC ---,---,---,--9.
       01  RD-DHEAD.
           02  FILLER             PIC X(47) VALUE SPACE.
           02  FILLER             PIC X(11) VALUE "    ORDERED".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(11) VALUE "    SHIPPED".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(11) VALUE "OUTSTANDING".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(14) VALUE "     PRICE".
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(15) VALUE "   OUT-AMOUNT".
       01  RD-SUB.
           02  FILLER             PIC X(71) VALUE
               "  ORDER OUTSTANDING TOTAL".
           02  SUB-QTY            PIC ---,---,--9.
           02  FILLER             PIC X(16) VALUE SPACE.
           02  SUB-AMT            PIC ---,---,---,--9.
       01  RD-GRAND.
           02  FILLER             PIC X(71) VALUE
               "  GRAND OUTSTANDING TOTAL".
           02  GT-QTY             PIC ---,---,--9.
           02  FILLER             PIC X(16) VALUE SPACE.
           02  GT-AMT             PIC ---,---,---,--9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0090"           TO WK-PROGID.
           MOVE "SALES ORDER BACKLOG"          TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT ORDHF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "ORDHF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT ORDDF.
           OPEN INPUT CUSTF.
           OPEN INPUT PRODF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRINT-010.
           MOVE 0                  TO WK-G-ORD WK-G-LIN.
           MOVE 99                 TO WK-LINE.
           IF NOT MAIN-EOF
               MOVE 0              TO OH-NO
               START ORDHF KEY NOT < OH-NO
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-HDR UNTIL MAIN-EOF.
           PERFORM PRINT-GRAND.
       PRINT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-HDR SECTION.
       RH-010.
           READ ORDHF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   PERFORM PROCESS-ORDER
           END-READ.
       RH-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-ORDER SECTION.
       PRO-010.
           IF OH-DEL-FLAG = 1 OR OH-STATUS NOT < 3
               GO TO PRO-999
           END-IF.
           MOVE 0                  TO WK-HDR-PRINTED.
           MOVE 0                  TO WK-ORD-QTY WK-ORD-AMT.
           PERFORM SCAN-DETAILS.
           IF WK-HDR-PRINTED = 1
               PERFORM PRINT-SUB
               ADD WK-ORD-QTY      TO WK-G-QTY
               ADD WK-ORD-AMT      TO WK-G-AMT
               ADD 1               TO WK-G-ORD
           END-IF.
       PRO-999.
           EXIT.
      *----------------------------------------------------------------
       SCAN-DETAILS SECTION.
       SD-010.
           MOVE 0                  TO WK-DTL-EOF.
           MOVE OH-NO              TO OD-NO.
           MOVE 0                  TO OD-LINE.
           START ORDDF KEY NOT < OD-NO
               INVALID KEY
                   MOVE 1          TO WK-DTL-EOF
           END-START.
           PERFORM READ-DTL UNTIL DTL-EOF.
       SD-999.
           EXIT.
      *----------------------------------------------------------------
       READ-DTL SECTION.
       RD-010.
           READ ORDDF NEXT
               AT END
                   MOVE 1          TO WK-DTL-EOF
               NOT AT END
                   IF OD-NO NOT = OH-NO
                       MOVE 1      TO WK-DTL-EOF
                   ELSE
                       PERFORM CHECK-DTL
                   END-IF
           END-READ.
       RD-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-DTL SECTION.
       CD-010.
           COMPUTE WK-OUT = OD-QTY - OD-SHIPPED-QTY.
           IF WK-OUT <= 0
               GO TO CD-999
           END-IF.
           IF WK-HDR-PRINTED = 0
               PERFORM PRINT-HEADER
               MOVE 1              TO WK-HDR-PRINTED
           END-IF.
           PERFORM PRINT-DTL.
       CD-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-HEADER SECTION.
       PHD-010.
           PERFORM CHECK-PAGE-HDR.
           MOVE SPACE              TO WK-CUST-NAME.
           MOVE OH-CUST            TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "(unknown)" TO WK-CUST-NAME
               NOT INVALID KEY
                   MOVE CU-NAME     TO WK-CUST-NAME
           END-READ.
           MOVE OH-NO             TO OH-NO-E.
           MOVE OH-DATE           TO OH-DATE-E.
           MOVE OH-CUST           TO OH-CUST-E.
           MOVE WK-CUST-NAME      TO OH-CNAME.
           MOVE OH-DUE-DATE       TO OH-DUE-E.
           MOVE OH-STATUS         TO OH-ST-E.
           MOVE RD-ORDH           TO REP-REC.
           WRITE REP-REC.
           ADD 1                  TO WK-LINE.
           MOVE RD-DHEAD          TO REP-REC.
           WRITE REP-REC.
           ADD 1                  TO WK-LINE.
       PHD-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-DTL SECTION.
       PDT-010.
           PERFORM CHECK-PAGE.
           MOVE SPACE             TO WK-PROD-NAME.
           MOVE OD-PROD           TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "(unknown)" TO WK-PROD-NAME
               NOT INVALID KEY
                   MOVE PR-NAME     TO WK-PROD-NAME
           END-READ.
           COMPUTE WK-OUT-AMT = WK-OUT * OD-UNIT-PRICE.
           MOVE OD-LINE           TO OD-LINE-E.
           MOVE OD-PROD           TO OD-PROD-E.
           MOVE WK-PROD-NAME      TO OD-PNAME.
           MOVE OD-QTY            TO OD-ORD-E.
           MOVE OD-SHIPPED-QTY    TO OD-SHP-E.
           MOVE WK-OUT            TO OD-OUT-E.
           MOVE OD-UNIT-PRICE     TO OD-PRICE-E.
           MOVE WK-OUT-AMT        TO OD-AMT-E.
           MOVE RD-ORDD           TO REP-REC.
           WRITE REP-REC.
           ADD 1                  TO WK-LINE.
           ADD WK-OUT             TO WK-ORD-QTY.
           ADD WK-OUT-AMT         TO WK-ORD-AMT.
           ADD 1                  TO WK-G-LIN.
       PDT-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-SUB SECTION.
       PSB-010.
           PERFORM CHECK-PAGE.
           MOVE WK-ORD-QTY        TO SUB-QTY.
           MOVE WK-ORD-AMT        TO SUB-AMT.
           MOVE RD-SUB            TO REP-REC.
           WRITE REP-REC.
           ADD 1                  TO WK-LINE.
           MOVE SPACE             TO REP-REC.
           WRITE REP-REC.
           ADD 1                  TO WK-LINE.
       PSB-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE-HDR SECTION.
       CPH-010.
           IF WK-LINE >= 50
               PERFORM PAGE-HEAD
           END-IF.
       CPH-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           MOVE "OPEN ORDERS (STATUS < 3)" TO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE 4                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-GRAND SECTION.
       PG-010.
           IF WK-G-ORD = 0
               PERFORM CHECK-PAGE-HDR
               MOVE "*** NO OPEN ORDERS ***" TO REP-REC
               WRITE REP-REC
               GO TO PG-999
           END-IF.
           PERFORM CHECK-PAGE.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-G-QTY           TO GT-QTY.
           MOVE WK-G-AMT           TO GT-AMT.
           MOVE RD-GRAND           TO REP-REC.
           WRITE REP-REC.
       PG-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE ORDHF ORDDF CUSTF PRODF REPF.
           DISPLAY "RP0090 complete.  Open orders = " WK-G-ORD
               "  Lines = " WK-G-LIN.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0090"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
