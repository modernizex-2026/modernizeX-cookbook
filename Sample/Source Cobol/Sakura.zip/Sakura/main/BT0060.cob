       IDENTIFICATION DIVISION.
       PROGRAM-ID. BT0060.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : BT0060  -  purge / archive                        *
      *  FUNCTION : physically removes records that are no longer     *
      *             required:                                         *
      *               - logically deleted master rows (DEL-FLAG = 1)  *
      *                 in CUSTF and PRODF;                            *
      *               - old fully-processed sales orders in ORDHF     *
      *                 (status 4 invoiced or 9 cancelled, or         *
      *                 DEL-FLAG 1) dated before an operator cut-off   *
      *                 date, together with their ORDDF detail lines.  *
      *             A "Y" confirmation is required before any DELETE.  *
      *             Prints per-file removal counts.                    *
      *             Console / batch (no screen section).               *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SCUST.
           COPY SPROD.
           COPY SORDH.
           COPY SORDD.
       DATA DIVISION.
       FILE SECTION.
           COPY FCUST.
           COPY FPROD.
           COPY FORDH.
           COPY FORDD.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- run parameters --------------------------------------------
       01  WK-PARM.
           02  WK-IN-LINE          PIC X(10) VALUE SPACE.
           02  WK-CUTOFF           PIC 9(8)  VALUE 0.
           02  WK-DFLT-CUT         PIC 9(8)  VALUE 0.
      *----- counters --------------------------------------------------
       01  WK-TOTALS.
           02  WK-CU-READ          PIC 9(7)  VALUE 0.
           02  WK-CU-DEL           PIC 9(7)  VALUE 0.
           02  WK-PR-READ          PIC 9(7)  VALUE 0.
           02  WK-PR-DEL           PIC 9(7)  VALUE 0.
           02  WK-OH-READ          PIC 9(7)  VALUE 0.
           02  WK-OH-DEL           PIC 9(7)  VALUE 0.
           02  WK-OD-DEL           PIC 9(7)  VALUE 0.
      *----- display edit work -----------------------------------------
       01  WK-DISP.
           02  WK-E-CNT            PIC Z,ZZZ,ZZ9.
           02  WK-E-DATE           PIC 9999/99/99.
      *----- flags -----------------------------------------------------
       01  WK-FLAGS.
           02  WK-ABORT-FLG        PIC 9(1)  VALUE 0.
           02  WK-PURGE-FLG        PIC 9(1)  VALUE 0.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           IF WK-ABORT-FLG = 0
               PERFORM PURGE-CUSTF
               PERFORM PURGE-PRODF
               PERFORM PURGE-ORDERS
               PERFORM PRINT-SUMMARY
           END-IF.
           PERFORM TERM-RTN.
           MOVE 0                  TO COMPLETION-CODE.
           EXIT PROGRAM.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "BT0060"           TO WK-PROGID.
           DISPLAY " ".
           DISPLAY "==============================================".
           DISPLAY " SAKURA-SMS  BT0060  -  PURGE / ARCHIVE".
           DISPLAY "==============================================".
           PERFORM GET-TODAY.
      *    default cut-off = one year before today
           MOVE "ADDD"             TO KD-FUNC.
           MOVE WK-SYSDATE         TO KD-DATE1.
           MOVE -365               TO KD-DAYS.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-DFLT-CUT.
           PERFORM OPEN-FILES.
           PERFORM ACCEPT-CUTOFF.
           IF WK-ABORT-FLG = 0
               PERFORM CONFIRM-RUN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       GET-TODAY SECTION.
       GTOD-010.
           MOVE "TODY"             TO KD-FUNC.
           MOVE 0                  TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE  WK-SYSYMD.
       GTOD-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPEN-010.
           PERFORM OPEN-CUSTF.
           PERFORM OPEN-PRODF.
           PERFORM OPEN-ORDHF.
           PERFORM OPEN-ORDDF.
       OPEN-999.
           EXIT.
       OPEN-CUSTF SECTION.
       OCUS-010.
           OPEN I-O CUSTF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT CUSTF
               CLOSE CUSTF
               OPEN I-O CUSTF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "CUSTF"        TO KA-FILE
               MOVE "Open CUSTF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OCUS-999.
           EXIT.
       OPEN-PRODF SECTION.
       OPRD-010.
           OPEN I-O PRODF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PRODF
               CLOSE PRODF
               OPEN I-O PRODF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "PRODF"        TO KA-FILE
               MOVE "Open PRODF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OPRD-999.
           EXIT.
       OPEN-ORDHF SECTION.
       OORH-010.
           OPEN I-O ORDHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ORDHF
               CLOSE ORDHF
               OPEN I-O ORDHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ORDHF"        TO KA-FILE
               MOVE "Open ORDHF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OORH-999.
           EXIT.
       OPEN-ORDDF SECTION.
       OORD-010.
           OPEN I-O ORDDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ORDDF
               CLOSE ORDDF
               OPEN I-O ORDDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ORDDF"        TO KA-FILE
               MOVE "Open ORDDF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OORD-999.
           EXIT.
      *----------------------------------------------------------------
       ACCEPT-CUTOFF SECTION.
       ACUT-010.
           MOVE WK-DFLT-CUT        TO WK-E-DATE.
           DISPLAY " ".
           DISPLAY " Transactions dated before the cut-off and".
           DISPLAY " fully processed will be purged.".
           DISPLAY " Enter cut-off date YYYYMMDD".
           DISPLAY "   (blank = " WK-E-DATE ") : " WITH NO ADVANCING.
           MOVE SPACE              TO WK-IN-LINE.
           ACCEPT WK-IN-LINE FROM CONSOLE.
           IF WK-IN-LINE = SPACE
               MOVE WK-DFLT-CUT    TO WK-CUTOFF
           ELSE
               IF WK-IN-LINE(1:8) NUMERIC
                   MOVE WK-IN-LINE(1:8) TO WK-CUTOFF
               ELSE
                   DISPLAY " ** invalid date - run cancelled."
                   MOVE 1          TO WK-ABORT-FLG
                   GO TO ACUT-999
               END-IF
           END-IF.
           MOVE "VALD"             TO KD-FUNC.
           MOVE WK-CUTOFF          TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           IF KD-STATUS NOT = "00"
               DISPLAY " ** date is not a valid calendar date."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       ACUT-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-RUN SECTION.
       CONF-010.
           MOVE WK-CUTOFF          TO WK-E-DATE.
           DISPLAY " ".
           DISPLAY " Purge deleted masters and orders < " WK-E-DATE.
           DISPLAY " This physically removes records - proceed ?".
           DISPLAY " Confirm (Y/N) : " WITH NO ADVANCING.
           MOVE SPACE              TO WK-CONFIRM.
           ACCEPT WK-CONFIRM FROM CONSOLE.
           IF CONFIRM-YES
               MOVE 1              TO WK-PURGE-FLG
           ELSE
               DISPLAY " ** cancelled by operator."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       CONF-999.
           EXIT.
      *----------------------------------------------------------------
      *  PURGE-CUSTF : remove logically-deleted customers              *
      *----------------------------------------------------------------
       PURGE-CUSTF SECTION.
       PCUS-010.
           DISPLAY " ".
           DISPLAY " Purging customers ...".
           MOVE 0                  TO EOF-FLG.
           MOVE 0                  TO CU-CODE.
           START CUSTF KEY NOT LESS THAN CU-CODE
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM PCUS-NEXT UNTIL EOF-YES.
       PCUS-999.
           EXIT.
       PCUS-NEXT SECTION.
       PCUX-010.
           READ CUSTF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO PCUX-999
           END-READ.
           ADD 1                   TO WK-CU-READ.
           IF CU-DEL-FLAG = 1
               DELETE CUSTF
                   INVALID KEY CONTINUE
               END-DELETE
               IF FSTS = "00"
                   ADD 1           TO WK-CU-DEL
               ELSE
                   MOVE "CUSTF"    TO KA-FILE
                   MOVE "DELETE CUSTF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
               END-IF
           END-IF.
       PCUX-999.
           EXIT.
      *----------------------------------------------------------------
      *  PURGE-PRODF : remove logically-deleted products               *
      *----------------------------------------------------------------
       PURGE-PRODF SECTION.
       PPRD-010.
           DISPLAY " Purging products ...".
           MOVE 0                  TO EOF-FLG.
           MOVE 0                  TO PR-CODE.
           START PRODF KEY NOT LESS THAN PR-CODE
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM PPRD-NEXT UNTIL EOF-YES.
       PPRD-999.
           EXIT.
       PPRD-NEXT SECTION.
       PPRX-010.
           READ PRODF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO PPRX-999
           END-READ.
           ADD 1                   TO WK-PR-READ.
           IF PR-DEL-FLAG = 1
               DELETE PRODF
                   INVALID KEY CONTINUE
               END-DELETE
               IF FSTS = "00"
                   ADD 1           TO WK-PR-DEL
               ELSE
                   MOVE "PRODF"    TO KA-FILE
                   MOVE "DELETE PRODF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
               END-IF
           END-IF.
       PPRX-999.
           EXIT.
      *----------------------------------------------------------------
      *  PURGE-ORDERS : remove old fully-processed / deleted orders    *
      *  with their detail lines                                       *
      *----------------------------------------------------------------
       PURGE-ORDERS SECTION.
       PORD-010.
           DISPLAY " Purging orders ...".
           MOVE 0                  TO EOF-FLG.
           MOVE 0                  TO OH-NO.
           START ORDHF KEY NOT LESS THAN OH-NO
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM PORD-NEXT UNTIL EOF-YES.
       PORD-999.
           EXIT.
       PORD-NEXT SECTION.
       PORX-010.
           READ ORDHF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO PORX-999
           END-READ.
           ADD 1                   TO WK-OH-READ.
           IF OH-DEL-FLAG = 1
               PERFORM DELETE-ORDER
           ELSE
               IF OH-DATE < WK-CUTOFF
                          AND (OH-STATUS = 4 OR OH-STATUS = 9)
                   PERFORM DELETE-ORDER
               END-IF
           END-IF.
       PORX-999.
           EXIT.
      *----------------------------------------------------------------
       DELETE-ORDER SECTION.
       DORD-010.
      *    remove the detail lines first, then the header
           PERFORM DELETE-ORDER-DETAILS.
           DELETE ORDHF
               INVALID KEY
                   MOVE "ORDHF"    TO KA-FILE
                   MOVE "DELETE ORDHF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-DELETE.
           IF FSTS = "00"
               ADD 1               TO WK-OH-DEL
           END-IF.
       DORD-999.
           EXIT.
      *----------------------------------------------------------------
       DELETE-ORDER-DETAILS SECTION.
       DODT-010.
           MOVE OH-NO              TO OD-NO.
           MOVE 0                  TO OD-LINE.
           START ORDDF KEY NOT LESS THAN OD-NO
               INVALID KEY
                   GO TO DODT-999
           END-START.
           IF FSTS NOT = "00"
               GO TO DODT-999
           END-IF.
           PERFORM DODT-NEXT
               UNTIL FSTS NOT = "00" OR OD-NO NOT = OH-NO.
       DODT-999.
           EXIT.
       DODT-NEXT SECTION.
       DODX-010.
           READ ORDDF NEXT
               AT END
                   MOVE "10"       TO FSTS
                   GO TO DODX-999
           END-READ.
           IF FSTS NOT = "00"
               GO TO DODX-999
           END-IF.
           IF OD-NO = OH-NO
               DELETE ORDDF
                   INVALID KEY CONTINUE
               END-DELETE
               IF FSTS = "00"
                   ADD 1           TO WK-OD-DEL
               ELSE
                   MOVE "ORDDF"    TO KA-FILE
                   MOVE "DELETE ORDDF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
               END-IF
           END-IF.
       DODX-999.
           EXIT.
      *----------------------------------------------------------------
      *  PRINT-SUMMARY                                                 *
      *----------------------------------------------------------------
       PRINT-SUMMARY SECTION.
       PSUM-010.
           MOVE WK-CUTOFF          TO WK-E-DATE.
           DISPLAY " ".
           DISPLAY "----------------------------------------------".
           DISPLAY " PURGE / ARCHIVE SUMMARY".
           DISPLAY "----------------------------------------------".
           DISPLAY " Cut-off date      : " WK-E-DATE.
           MOVE WK-CU-READ         TO WK-E-CNT.
           DISPLAY " Customers read    : " WK-E-CNT.
           MOVE WK-CU-DEL          TO WK-E-CNT.
           DISPLAY " Customers purged  : " WK-E-CNT.
           MOVE WK-PR-READ         TO WK-E-CNT.
           DISPLAY " Products read     : " WK-E-CNT.
           MOVE WK-PR-DEL          TO WK-E-CNT.
           DISPLAY " Products purged   : " WK-E-CNT.
           MOVE WK-OH-READ         TO WK-E-CNT.
           DISPLAY " Orders read       : " WK-E-CNT.
           MOVE WK-OH-DEL          TO WK-E-CNT.
           DISPLAY " Orders purged     : " WK-E-CNT.
           MOVE WK-OD-DEL          TO WK-E-CNT.
           DISPLAY " Order lines purge : " WK-E-CNT.
           DISPLAY "----------------------------------------------".
           DISPLAY " BT0060 completed normally.".
       PSUM-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE CUSTF.
           CLOSE PRODF.
           CLOSE ORDHF.
           CLOSE ORDDF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABND-010.
           MOVE "BT0060"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EBATCH"           TO KA-MSGCODE.
           CALL "ABORTX" USING KABEND.
           CLOSE CUSTF.
           CLOSE PRODF.
           CLOSE ORDHF.
           CLOSE ORDDF.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABND-999.
           EXIT.
