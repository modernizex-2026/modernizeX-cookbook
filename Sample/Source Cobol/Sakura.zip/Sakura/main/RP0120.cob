       IDENTIFICATION DIVISION.
       PROGRAM-ID. RP0120.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : RP0120  -  Sales-rep performance report          *
      *  FUNCTION : read the sales-invoice header file for a sales-  *
      *             date range (date alternate key) and accumulate   *
      *             invoice count, net / tax / total and cost by     *
      *             sales rep (IH-STAFF) into an in-core table.      *
      *             The table is ordered by staff code and printed   *
      *             one summary line per rep - a control break on    *
      *             staff - showing the rep name, invoice count,     *
      *             net / tax / total and gross margin               *
      *             (total - cost).  Grand totals close the report.  *
      *             132-column line-sequential batch text report.    *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SINVH.
           COPY SSTAF.
           COPY SSYSC.
           SELECT  REPF         ASSIGN  TO  REPF-MSD
                   ORGANIZATION      LINE SEQUENTIAL
                   FILE STATUS       FSTS.
       DATA DIVISION.
       FILE SECTION.
           COPY FINVH.
           COPY FSTAF.
           COPY FSYSC.
       FD  REPF
           LABEL RECORD STANDARD
           VALUE OF IDENTIFICATION "RP0120.TXT".
       01  REP-REC                 PIC X(132).
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- control flags ---------------------------------------------
       01  WK-FLAGS.
           02  WK-MAIN-EOF         PIC 9(1)  VALUE 0.
             88  MAIN-EOF                    VALUE 1.
      *----- console parameters ----------------------------------------
       01  WK-PARM.
           02  WK-IN-FROM          PIC X(8)  VALUE SPACE.
           02  WK-IN-TO            PIC X(8)  VALUE SPACE.
           02  WK-DATE-FROM        PIC 9(8)  VALUE 0.
           02  WK-DATE-TO          PIC 9(8)  VALUE 99999999.
      *----- staff accumulation table ----------------------------------
       01  WK-ST-MAX              PIC 9(3)  VALUE 300.
       01  WK-ST-NUM              PIC 9(3)  VALUE 0.
       01  WK-FOUND-IDX          PIC 9(3)  VALUE 0.
       01  WK-OVERFLOW           PIC 9(7)  VALUE 0.
       01  WK-SI                 PIC 9(4)  VALUE 0.
       01  WK-SJ                 PIC 9(4)  VALUE 0.
       01  WK-SMIN               PIC 9(4)  VALUE 0.
       01  WK-STAFF-TBL.
           02  WK-ST-ENT OCCURS 300.
             03  WK-ST-CODE       PIC 9(4).
             03  WK-ST-CNT        PIC 9(7).
             03  WK-ST-NET        PIC S9(15) COMP-3.
             03  WK-ST-TAX        PIC S9(15) COMP-3.
             03  WK-ST-TOT        PIC S9(15) COMP-3.
             03  WK-ST-COST       PIC S9(15) COMP-3.
       01  WK-ST-TEMP.
           02  WK-TP-CODE         PIC 9(4).
           02  WK-TP-CNT          PIC 9(7).
           02  WK-TP-NET          PIC S9(15) COMP-3.
           02  WK-TP-TAX          PIC S9(15) COMP-3.
           02  WK-TP-TOT          PIC S9(15) COMP-3.
           02  WK-TP-COST         PIC S9(15) COMP-3.
       01  WK-MARGIN             PIC S9(15) COMP-3 VALUE 0.
       01  WK-STAFF-NAME         PIC X(24) VALUE SPACE.
       01  WK-COMPANY            PIC X(40) VALUE SPACE.
      *----- counters / grand totals -----------------------------------
       01  WK-COUNTS.
           02  WK-INV-CNT          PIC 9(7)  VALUE 0.
           02  WK-REP-CNT          PIC 9(7)  VALUE 0.
       01  WK-TOTALS.
           02  WK-G-CNT            PIC S9(9)  COMP-3 VALUE 0.
           02  WK-G-NET            PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-TAX            PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-TOT            PIC S9(15) COMP-3 VALUE 0.
           02  WK-G-MARGIN         PIC S9(15) COMP-3 VALUE 0.
      *----- report layout ---------------------------------------------
       01  RPT-RULE               PIC X(105) VALUE ALL "-".
       01  RPT-H1.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  H1-COMPANY         PIC X(40).
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H1-TITLE           PIC X(45).
           02  FILLER             PIC X(10) VALUE SPACE.
           02  FILLER             PIC X(6)  VALUE "PAGE: ".
           02  H1-PAGE            PIC ZZZ9.
       01  RPT-H2.
           02  FILLER             PIC X(1)  VALUE SPACE.
           02  FILLER             PIC X(10) VALUE "RUN DATE: ".
           02  H2-DATE            PIC 9999/99/99.
           02  FILLER             PIC X(4)  VALUE SPACE.
           02  H2-INFO            PIC X(70).
       01  RC-HEAD.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(4)  VALUE "STAF".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(24) VALUE "SALES REP NAME".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(6)  VALUE "  INV#".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(15) VALUE "        NET-AMT".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(15) VALUE "        TAX-AMT".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(15) VALUE "      TOTAL-AMT".
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  FILLER  PIC X(15) VALUE "   GROSS-MARGIN".
       01  RD-LINE.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-CODE   PIC 9(4).
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-NAME   PIC X(24).
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-CNT    PIC ZZ,ZZ9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-NET    PIC ---,---,---,--9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-TAX    PIC ---,---,---,--9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-TOT    PIC ---,---,---,--9.
           02  FILLER  PIC X(1)  VALUE SPACE.
           02  RL-MARGIN PIC ---,---,---,--9.
       01  RT-LINE.
           02  FILLER    PIC X(31) VALUE " GRAND TOTAL (ALL REPS)".
           02  RT-CNT    PIC ZZ,ZZ9.
           02  FILLER    PIC X(1)  VALUE SPACE.
           02  RT-NET    PIC ---,---,---,--9.
           02  FILLER    PIC X(1)  VALUE SPACE.
           02  RT-TAX    PIC ---,---,---,--9.
           02  FILLER    PIC X(1)  VALUE SPACE.
           02  RT-TOT    PIC ---,---,---,--9.
           02  FILLER    PIC X(1)  VALUE SPACE.
           02  RT-MARGIN PIC ---,---,---,--9.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PARM-RTN.
           PERFORM GATHER-RTN.
           PERFORM SORT-TBL.
           PERFORM PRINT-RTN.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "RP0120"           TO WK-PROGID.
           MOVE "SALES REP PERFORMANCE"        TO WK-TITLE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE.
           MOVE "SAKURA Sales Management System" TO WK-COMPANY.
           OPEN INPUT SYSCF.
           IF FSTS = "00"
               MOVE 1              TO SY-KEY
               READ SYSCF
                   INVALID KEY
                       CONTINUE
                   NOT INVALID KEY
                       MOVE SY-COMPANY-NAME TO WK-COMPANY
               END-READ
               CLOSE SYSCF
           END-IF.
           OPEN INPUT INVHF.
           IF FSTS NOT = "00" AND FSTS NOT = "35" AND FSTS NOT = "30"
               MOVE "INVHF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           IF FSTS NOT = "00"
               MOVE 1              TO WK-MAIN-EOF
           END-IF.
           OPEN INPUT STAFF.
           OPEN OUTPUT REPF.
           IF FSTS NOT = "00"
               MOVE "REPF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       PARM-RTN SECTION.
       PARM-010.
           DISPLAY "RP0120 - Sales rep performance report".
           DISPLAY "From sales date YYYYMMDD (blank=earliest): ".
           ACCEPT  WK-IN-FROM FROM CONSOLE.
           DISPLAY "To   sales date YYYYMMDD (blank=latest  ): ".
           ACCEPT  WK-IN-TO   FROM CONSOLE.
           IF WK-IN-FROM NUMERIC AND WK-IN-FROM NOT = SPACE
               MOVE WK-IN-FROM     TO WK-DATE-FROM
           ELSE
               MOVE 0              TO WK-DATE-FROM
           END-IF.
           IF WK-IN-TO NUMERIC AND WK-IN-TO NOT = SPACE
               MOVE WK-IN-TO       TO WK-DATE-TO
           ELSE
               MOVE 99999999       TO WK-DATE-TO
           END-IF.
       PARM-999.
           EXIT.
      *----------------------------------------------------------------
      *  GATHER : scan invoices in date order, accumulate by rep       *
      *----------------------------------------------------------------
       GATHER-RTN SECTION.
       GAT-010.
           MOVE 0                  TO WK-INV-CNT.
           IF NOT MAIN-EOF
               MOVE WK-DATE-FROM   TO IH-DATE
               MOVE 0              TO IH-NO
               START INVHF KEY NOT < IH-DATE
                   INVALID KEY
                       MOVE 1      TO WK-MAIN-EOF
               END-START
           END-IF.
           PERFORM READ-INV UNTIL MAIN-EOF.
       GAT-999.
           EXIT.
      *----------------------------------------------------------------
       READ-INV SECTION.
       RI-010.
           READ INVHF NEXT
               AT END
                   MOVE 1          TO WK-MAIN-EOF
               NOT AT END
                   IF IH-DATE > WK-DATE-TO
                       MOVE 1      TO WK-MAIN-EOF
                   ELSE
                       PERFORM ACCUM-INV
                   END-IF
           END-READ.
       RI-999.
           EXIT.
      *----------------------------------------------------------------
       ACCUM-INV SECTION.
       AI-010.
           IF IH-DEL-FLAG = 1 OR IH-STATUS = 9
               GO TO AI-999
           END-IF.
           ADD 1                   TO WK-INV-CNT.
           PERFORM FIND-STAFF.
       AI-999.
           EXIT.
      *----------------------------------------------------------------
      *  FIND-STAFF : locate (or create) the table slot for IH-STAFF
      *  then add this invoice's figures into it
      *----------------------------------------------------------------
       FIND-STAFF SECTION.
       FS-010.
           MOVE 0                  TO WK-FOUND-IDX.
           MOVE 1                  TO WK-SI.
           PERFORM UNTIL WK-SI > WK-ST-NUM OR WK-FOUND-IDX > 0
               IF WK-ST-CODE(WK-SI) = IH-STAFF
                   MOVE WK-SI      TO WK-FOUND-IDX
               ELSE
                   ADD 1           TO WK-SI
               END-IF
           END-PERFORM.
           IF WK-FOUND-IDX = 0
               IF WK-ST-NUM < WK-ST-MAX
                   ADD 1           TO WK-ST-NUM
                   MOVE WK-ST-NUM  TO WK-FOUND-IDX
                   MOVE IH-STAFF   TO WK-ST-CODE(WK-FOUND-IDX)
                   MOVE 0          TO WK-ST-CNT(WK-FOUND-IDX)
                   MOVE 0          TO WK-ST-NET(WK-FOUND-IDX)
                   MOVE 0          TO WK-ST-TAX(WK-FOUND-IDX)
                   MOVE 0          TO WK-ST-TOT(WK-FOUND-IDX)
                   MOVE 0          TO WK-ST-COST(WK-FOUND-IDX)
               ELSE
                   ADD 1           TO WK-OVERFLOW
                   GO TO FS-999
               END-IF
           END-IF.
           ADD 1                   TO WK-ST-CNT(WK-FOUND-IDX).
           ADD IH-AMOUNT           TO WK-ST-NET(WK-FOUND-IDX).
           ADD IH-TAX-AMOUNT       TO WK-ST-TAX(WK-FOUND-IDX).
           ADD IH-TOTAL            TO WK-ST-TOT(WK-FOUND-IDX).
           ADD IH-COST-TOTAL       TO WK-ST-COST(WK-FOUND-IDX).
       FS-999.
           EXIT.
      *----------------------------------------------------------------
      *  SORT-TBL : selection sort the table ascending by staff code
      *----------------------------------------------------------------
       SORT-TBL SECTION.
       SR-010.
           IF WK-ST-NUM < 2
               GO TO SR-999
           END-IF.
           PERFORM VARYING WK-SI FROM 1 BY 1
                   UNTIL WK-SI >= WK-ST-NUM
               MOVE WK-SI          TO WK-SMIN
               PERFORM VARYING WK-SJ FROM WK-SI BY 1
                       UNTIL WK-SJ > WK-ST-NUM
                   IF WK-ST-CODE(WK-SJ) < WK-ST-CODE(WK-SMIN)
                       MOVE WK-SJ  TO WK-SMIN
                   END-IF
               END-PERFORM
               IF WK-SMIN NOT = WK-SI
                   MOVE WK-ST-ENT(WK-SI)   TO WK-ST-TEMP
                   MOVE WK-ST-ENT(WK-SMIN) TO WK-ST-ENT(WK-SI)
                   MOVE WK-ST-TEMP         TO WK-ST-ENT(WK-SMIN)
               END-IF
           END-PERFORM.
       SR-999.
           EXIT.
      *----------------------------------------------------------------
      *  PRINT : one summary line per rep, then grand totals           *
      *----------------------------------------------------------------
       PRINT-RTN SECTION.
       PRINT-010.
           MOVE 99                 TO WK-LINE.
           MOVE 0                  TO WK-REP-CNT.
           PERFORM VARYING WK-SI FROM 1 BY 1 UNTIL WK-SI > WK-ST-NUM
               PERFORM PRINT-ONE
           END-PERFORM.
           PERFORM PRINT-GRAND.
       PRINT-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-ONE SECTION.
       PO-010.
           PERFORM CHECK-PAGE.
           PERFORM LOOKUP-STAFF.
           COMPUTE WK-MARGIN =
               WK-ST-TOT(WK-SI) - WK-ST-COST(WK-SI).
           MOVE WK-ST-CODE(WK-SI)  TO RL-CODE.
           MOVE WK-STAFF-NAME      TO RL-NAME.
           MOVE WK-ST-CNT(WK-SI)   TO RL-CNT.
           MOVE WK-ST-NET(WK-SI)   TO RL-NET.
           MOVE WK-ST-TAX(WK-SI)   TO RL-TAX.
           MOVE WK-ST-TOT(WK-SI)   TO RL-TOT.
           MOVE WK-MARGIN          TO RL-MARGIN.
           MOVE RD-LINE            TO REP-REC.
           WRITE REP-REC.
           ADD 1                   TO WK-LINE.
           ADD 1                   TO WK-REP-CNT.
           ADD WK-ST-CNT(WK-SI)    TO WK-G-CNT.
           ADD WK-ST-NET(WK-SI)    TO WK-G-NET.
           ADD WK-ST-TAX(WK-SI)    TO WK-G-TAX.
           ADD WK-ST-TOT(WK-SI)    TO WK-G-TOT.
           ADD WK-MARGIN           TO WK-G-MARGIN.
       PO-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-STAFF SECTION.
       LKS-010.
           MOVE SPACE              TO WK-STAFF-NAME.
           IF WK-ST-CODE(WK-SI) = 0
               MOVE "(no rep assigned)" TO WK-STAFF-NAME
               GO TO LKS-999
           END-IF.
           MOVE WK-ST-CODE(WK-SI)  TO SF-CODE.
           READ STAFF
               INVALID KEY
                   MOVE "(unknown staff)" TO WK-STAFF-NAME
               NOT INVALID KEY
                   MOVE SF-NAME     TO WK-STAFF-NAME
           END-READ.
       LKS-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-PAGE SECTION.
       CP-010.
           IF WK-LINE >= 55
               PERFORM PAGE-HEAD
           END-IF.
       CP-999.
           EXIT.
      *----------------------------------------------------------------
       PAGE-HEAD SECTION.
       PH-010.
           ADD 1                   TO WK-PAGE.
           MOVE WK-COMPANY         TO H1-COMPANY.
           MOVE WK-TITLE           TO H1-TITLE.
           MOVE WK-PAGE            TO H1-PAGE.
           MOVE RPT-H1             TO REP-REC.
           WRITE REP-REC.
           MOVE WK-SYSDATE         TO H2-DATE.
           MOVE SPACE              TO H2-INFO.
           STRING "PERIOD " WK-DATE-FROM " - " WK-DATE-TO
               DELIMITED BY SIZE INTO H2-INFO.
           MOVE RPT-H2             TO REP-REC.
           WRITE REP-REC.
           MOVE SPACE              TO REP-REC.
           WRITE REP-REC.
           MOVE RC-HEAD            TO REP-REC.
           WRITE REP-REC.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE 6                  TO WK-LINE.
       PH-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-GRAND SECTION.
       PG-010.
           IF WK-REP-CNT = 0
               PERFORM CHECK-PAGE
               MOVE "*** NO INVOICES IN THE SELECTED PERIOD ***"
                                   TO REP-REC
               WRITE REP-REC
               GO TO PG-999
           END-IF.
           PERFORM CHECK-PAGE.
           MOVE RPT-RULE           TO REP-REC.
           WRITE REP-REC.
           MOVE WK-G-CNT           TO RT-CNT.
           MOVE WK-G-NET           TO RT-NET.
           MOVE WK-G-TAX           TO RT-TAX.
           MOVE WK-G-TOT           TO RT-TOT.
           MOVE WK-G-MARGIN        TO RT-MARGIN.
           MOVE RT-LINE            TO REP-REC.
           WRITE REP-REC.
       PG-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE INVHF STAFF REPF.
           DISPLAY "RP0120 complete.  Invoices read = " WK-INV-CNT.
           DISPLAY "         Sales reps reported     = " WK-REP-CNT.
           IF WK-OVERFLOW > 0
               DISPLAY " ** table overflow, invoices skipped = "
                   WK-OVERFLOW
           END-IF.
           MOVE 0                  TO COMPLETION-CODE.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       AB-010.
           MOVE "RP0120"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "Report file error" TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       AB-999.
           EXIT.
