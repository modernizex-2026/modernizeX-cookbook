       IDENTIFICATION DIVISION.
       PROGRAM-ID. BT0040.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : BT0040  -  accounts-receivable balance rebuild    *
      *  FUNCTION : reads the AR ledger in customer / date order      *
      *             (alternate key AL-CUST + AL-DATE), recomputes the *
      *             running balance on every ledger entry             *
      *             (balance = balance + debit - credit) and rewrites *
      *             AL-BALANCE.  At each customer control-break the    *
      *             final running balance is written back to the      *
      *             customer master (CUSTF CU-BALANCE).  Use this      *
      *             utility to repair AR balances after an aborted     *
      *             posting run.  Console / batch (no screen section). *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SARL.
           COPY SCUST.
       DATA DIVISION.
       FILE SECTION.
           COPY FARL.
           COPY FCUST.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- accumulators ----------------------------------------------
       01  WK-TOTALS.
           02  WK-LEDG-CNT         PIC 9(7)  VALUE 0.
           02  WK-CUST-CNT         PIC 9(7)  VALUE 0.
           02  WK-UPD-CNT          PIC 9(7)  VALUE 0.
           02  WK-NF-CNT           PIC 9(7)  VALUE 0.
           02  WK-ZERO-READ        PIC 9(7)  VALUE 0.
           02  WK-ZERO-CLR         PIC 9(7)  VALUE 0.
           02  WK-NONZERO-CNT      PIC 9(7)  VALUE 0.
           02  WK-DEBIT-TOT        PIC S9(13) VALUE 0.
           02  WK-CREDIT-TOT       PIC S9(13) VALUE 0.
           02  WK-BAL-TOT          PIC S9(13) VALUE 0.
      *----- control break / running balance ---------------------------
       01  WK-CTRL.
           02  WK-RUN-BAL          PIC S9(11) VALUE 0.
           02  WK-PREV-CUST        PIC 9(6)  VALUE 0.
           02  WK-FIRST-FLG        PIC 9(1)  VALUE 0.
      *----- display edit work -----------------------------------------
       01  WK-DISP.
           02  WK-E-CNT            PIC Z,ZZZ,ZZ9.
           02  WK-E-AMT            PIC Z,ZZZ,ZZZ,ZZZ,ZZ9-.
           02  WK-E-CODE           PIC ZZZZZ9.
      *----- flags -----------------------------------------------------
       01  WK-FLAGS.
           02  WK-ABORT-FLG        PIC 9(1)  VALUE 0.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           IF WK-ABORT-FLG = 0
               PERFORM CLEAR-MASTER
               PERFORM PROCESS-RTN
               PERFORM PRINT-SUMMARY
           END-IF.
           PERFORM TERM-RTN.
           MOVE 0                  TO COMPLETION-CODE.
           EXIT PROGRAM.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "BT0040"           TO WK-PROGID.
           DISPLAY " ".
           DISPLAY "==============================================".
           DISPLAY " SAKURA-SMS  BT0040  -  AR BALANCE REBUILD".
           DISPLAY "==============================================".
           PERFORM GET-TODAY.
           PERFORM OPEN-FILES.
           PERFORM CONFIRM-RUN.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       GET-TODAY SECTION.
       GTOD-010.
           MOVE "TODY"             TO KD-FUNC.
           MOVE 0                  TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE  WK-SYSYMD.
       GTOD-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPEN-010.
           OPEN I-O    ARLF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ARLF
               CLOSE ARLF
               OPEN I-O ARLF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ARLF"         TO KA-FILE
               MOVE "Open ARLF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O    CUSTF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT CUSTF
               CLOSE CUSTF
               OPEN I-O CUSTF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "CUSTF"        TO KA-FILE
               MOVE "Open CUSTF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OPEN-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-RUN SECTION.
       CONF-010.
           DISPLAY " ".
           DISPLAY " Rebuild AR ledger running balances and".
           DISPLAY " customer master balances from the ledger.".
           DISPLAY " Proceed ? (Y/N) : " WITH NO ADVANCING.
           MOVE SPACE              TO WK-CONFIRM.
           ACCEPT WK-CONFIRM FROM CONSOLE.
           IF NOT CONFIRM-YES
               DISPLAY " ** cancelled by operator."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       CONF-999.
           EXIT.
      *----------------------------------------------------------------
      *  CLEAR-MASTER : zero every customer balance first so that      *
      *  accounts with no ledger activity are also correctly reset     *
      *----------------------------------------------------------------
       CLEAR-MASTER SECTION.
       CLRM-010.
           DISPLAY " ".
           DISPLAY " Clearing customer balances ...".
           MOVE 0                  TO EOF-FLG.
           MOVE 0                  TO CU-CODE.
           START CUSTF KEY NOT LESS THAN CU-CODE
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM CLRM-NEXT UNTIL EOF-YES.
       CLRM-999.
           EXIT.
       CLRM-NEXT SECTION.
       CLRX-010.
           READ CUSTF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO CLRX-999
           END-READ.
           ADD 1                   TO WK-ZERO-READ.
           IF CU-BALANCE NOT = 0
               MOVE 0              TO CU-BALANCE
               REWRITE CU-REC
                   INVALID KEY
                       MOVE "CUSTF" TO KA-FILE
                       MOVE "Clear CUSTF balance failed" TO KA-DETAIL
                       PERFORM ABEND-RTN
               END-REWRITE
               ADD 1               TO WK-ZERO-CLR
           END-IF.
       CLRX-999.
           EXIT.
      *----------------------------------------------------------------
      *  PROCESS : walk the ledger in customer / date order            *
      *----------------------------------------------------------------
       PROCESS-RTN SECTION.
       PROC-010.
           DISPLAY " ".
           DISPLAY " Rebuilding ...".
           MOVE 0                  TO EOF-FLG.
           MOVE 1                  TO WK-FIRST-FLG.
           MOVE 0                  TO WK-PREV-CUST.
           MOVE 0                  TO WK-RUN-BAL.
           MOVE 0                  TO AL-CUST.
           MOVE 0                  TO AL-DATE.
           START ARLF KEY NOT LESS THAN AL-CUST
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM PROC-NEXT UNTIL EOF-YES.
      *    write back the last customer's balance
           IF WK-FIRST-FLG = 0
               PERFORM UPDATE-CUST
           END-IF.
       PROC-999.
           EXIT.
      *----------------------------------------------------------------
       PROC-NEXT SECTION.
       PNXT-010.
           READ ARLF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO PNXT-999
           END-READ.
           IF FSTS NOT = "00" AND FSTS NOT = "02"
               MOVE "ARLF"         TO KA-FILE
               MOVE "READ NEXT ARLF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           IF WK-FIRST-FLG = 1
               MOVE 0              TO WK-FIRST-FLG
               MOVE AL-CUST        TO WK-PREV-CUST
               MOVE 0              TO WK-RUN-BAL
           END-IF.
           IF AL-CUST NOT = WK-PREV-CUST
               PERFORM UPDATE-CUST
               MOVE AL-CUST        TO WK-PREV-CUST
               MOVE 0              TO WK-RUN-BAL
           END-IF.
           PERFORM POST-ENTRY.
       PNXT-999.
           EXIT.
      *----------------------------------------------------------------
      *  POST-ENTRY : recompute running balance and rewrite entry      *
      *----------------------------------------------------------------
       POST-ENTRY SECTION.
       PENT-010.
           ADD 1                   TO WK-LEDG-CNT.
      *    AR balance rises with debit (sale) falls with credit (recpt)
           ADD AL-DEBIT            TO WK-RUN-BAL.
           SUBTRACT AL-CREDIT      FROM WK-RUN-BAL.
           ADD AL-DEBIT            TO WK-DEBIT-TOT.
           ADD AL-CREDIT           TO WK-CREDIT-TOT.
           MOVE WK-RUN-BAL         TO AL-BALANCE.
           REWRITE AL-REC
               INVALID KEY
                   MOVE "ARLF"     TO KA-FILE
                   MOVE "REWRITE ARLF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-REWRITE.
       PENT-999.
           EXIT.
      *----------------------------------------------------------------
      *  UPDATE-CUST : write final running balance to CUSTF            *
      *----------------------------------------------------------------
       UPDATE-CUST SECTION.
       UCUS-010.
           IF WK-PREV-CUST = 0
               GO TO UCUS-999
           END-IF.
           ADD 1                   TO WK-CUST-CNT.
           ADD WK-RUN-BAL          TO WK-BAL-TOT.
           MOVE WK-PREV-CUST       TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   ADD 1           TO WK-NF-CNT
                   GO TO UCUS-999
           END-READ.
           MOVE WK-RUN-BAL         TO CU-BALANCE.
           MOVE WK-SYSDATE         TO CU-UPD-DATE.
           MOVE WK-USER-CODE       TO CU-UPD-USER.
           REWRITE CU-REC
               INVALID KEY
                   MOVE "CUSTF"    TO KA-FILE
                   MOVE "REWRITE CUSTF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-REWRITE.
           ADD 1                   TO WK-UPD-CNT.
      *    audit line for accounts with an outstanding balance
           IF WK-RUN-BAL NOT = 0
               ADD 1               TO WK-NONZERO-CNT
               MOVE WK-PREV-CUST   TO WK-E-CODE
               MOVE WK-RUN-BAL     TO WK-E-AMT
               DISPLAY "   cust " WK-E-CODE " balance " WK-E-AMT
           END-IF.
       UCUS-999.
           EXIT.
      *----------------------------------------------------------------
      *  PRINT-SUMMARY                                                 *
      *----------------------------------------------------------------
       PRINT-SUMMARY SECTION.
       PSUM-010.
           DISPLAY " ".
           DISPLAY "----------------------------------------------".
           DISPLAY " AR BALANCE REBUILD SUMMARY".
           DISPLAY "----------------------------------------------".
           MOVE WK-ZERO-READ       TO WK-E-CNT.
           DISPLAY " Customers cleared : " WK-E-CNT.
           MOVE WK-ZERO-CLR        TO WK-E-CNT.
           DISPLAY "   had prior bal   : " WK-E-CNT.
           MOVE WK-LEDG-CNT        TO WK-E-CNT.
           DISPLAY " Ledger entries    : " WK-E-CNT.
           MOVE WK-CUST-CNT        TO WK-E-CNT.
           DISPLAY " Customers in ledg : " WK-E-CNT.
           MOVE WK-UPD-CNT         TO WK-E-CNT.
           DISPLAY " Masters updated   : " WK-E-CNT.
           MOVE WK-NF-CNT          TO WK-E-CNT.
           DISPLAY " Masters not found : " WK-E-CNT.
           MOVE WK-NONZERO-CNT     TO WK-E-CNT.
           DISPLAY " Outstanding accts : " WK-E-CNT.
           MOVE WK-DEBIT-TOT       TO WK-E-AMT.
           DISPLAY " Total debit       : " WK-E-AMT.
           MOVE WK-CREDIT-TOT      TO WK-E-AMT.
           DISPLAY " Total credit      : " WK-E-AMT.
           MOVE WK-BAL-TOT         TO WK-E-AMT.
           DISPLAY " Sum of balances   : " WK-E-AMT.
           DISPLAY "----------------------------------------------".
           DISPLAY " BT0040 completed normally.".
       PSUM-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE ARLF.
           CLOSE CUSTF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABND-010.
           MOVE "BT0040"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EBATCH"           TO KA-MSGCODE.
           CALL "ABORTX" USING KABEND.
           CLOSE ARLF.
           CLOSE CUSTF.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABND-999.
           EXIT.
