       IDENTIFICATION DIVISION.
       PROGRAM-ID. MS0110.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : MS0110  -  Region master maintenance             *
      *  FUNCTION : add / change / delete / inquire the region       *
      *             (sales territory) master.  Enter a region code;  *
      *             if it exists the record is shown for change or   *
      *             delete, otherwise a new record is entered.       *
      *             Deletion is logical via the delete flag.         *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SREGN.
       I-O-CONTROL.
           APPLY SHARED-MODE ON REGNF.
       DATA DIVISION.
       FILE SECTION.
           COPY FREGN.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-SAVE-CODE          PIC 9(3)  VALUE 0.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4 COLUMN 2  VALUE "Region Code   :" COLOR YELLOW.
           02  SC-KEY LINE 4 COLUMN 20 PIC 9(3) USING RG-CODE.
       01  DS-BODY.
           02  LINE 6.
             03  COLUMN 2  VALUE "Region Name   :" COLOR YELLOW.
             03  COLUMN 20 PIC X(30) USING RG-NAME.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Confirm (Y/N) :" COLOR YELLOW.
           02  SC-CONF LINE 21 COLUMN 20 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "MS0110"           TO WK-PROGID.
           MOVE "Region Master Maintenance"  TO WK-TITLE.
           MOVE "ENTER=Read  PF9=Delete  PF3=End" TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           OPEN I-O    REGNF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT REGNF
               CLOSE REGNF
               OPEN I-O REGNF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "REGNF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-RTN-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE SPACE              TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-KEY
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-RTN-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLEAR-010.
           INITIALIZE RG-REC.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE 0                  TO WK-SAVE-CODE.
       CLEAR-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-KEY SECTION.
       PKEY-010.
           IF RG-CODE = 0
               MOVE "Region code must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
           MOVE RG-CODE            TO WK-SAVE-CODE.
           READ REGNF
               INVALID KEY
                   PERFORM SETUP-ADD
               NOT INVALID KEY
                   PERFORM SETUP-CHANGE
           END-READ.
           PERFORM EDIT-RECORD.
       PKEY-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-ADD SECTION.
       SADD-010.
           SET MODE-ADD TO TRUE.
           INITIALIZE RG-REC.
           MOVE WK-SAVE-CODE       TO RG-CODE.
           MOVE "New region - enter details" TO WK-MSG-LINE.
       SADD-999.
           EXIT.
      *----------------------------------------------------------------
       SETUP-CHANGE SECTION.
       SCHG-010.
           IF RG-DEL-FLAG = 1
               SET MODE-ADD TO TRUE
               MOVE "Deleted region - re-registering" TO WK-MSG-LINE
           ELSE
               SET MODE-CHG TO TRUE
               MOVE "Existing region - change or PF9 delete"
                                   TO WK-MSG-LINE
           END-IF.
       SCHG-999.
           EXIT.
      *----------------------------------------------------------------
       EDIT-RECORD SECTION.
       EDIT-010.
           DISPLAY DS-MSG.
           DISPLAY DS-BODY.
           ACCEPT  DS-BODY.
           EVALUATE ESTS
               WHEN "03"
                   CONTINUE
               WHEN "04"
                   MOVE "Cancelled" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               WHEN "09"
                   IF MODE-CHG
                       PERFORM DELETE-RECORD
                   ELSE
                       MOVE "Nothing to delete" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   END-IF
               WHEN "00"
                   PERFORM VALIDATE-BODY
                   IF NOT ERR-YES
                       PERFORM SAVE-RECORD
                   END-IF
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       EDIT-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-BODY SECTION.
       VAL-010.
           MOVE 0                  TO ERR-FLG.
           IF RG-NAME = SPACE
               MOVE "Region name is required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
           END-IF.
       VAL-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       SAVE-RECORD SECTION.
       SAVE-010.
           MOVE 0                  TO RG-DEL-FLAG.
           IF MODE-ADD
               WRITE RG-REC
                   INVALID KEY
                       MOVE "Write failed - duplicate" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Region added" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-WRITE
           ELSE
               REWRITE RG-REC
                   INVALID KEY
                       MOVE "Update failed" TO WK-MSG-LINE
                       DISPLAY DS-MSG
                   NOT INVALID KEY
                       MOVE "Region updated" TO WK-MSG-LINE
                       DISPLAY DS-MSG
               END-REWRITE
           END-IF.
       SAVE-999.
           EXIT.
      *----------------------------------------------------------------
       DELETE-RECORD SECTION.
       DEL-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Press Y then ENTER to delete" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               MOVE 1              TO RG-DEL-FLAG
               REWRITE RG-REC
                   INVALID KEY
                       MOVE "Delete failed" TO WK-MSG-LINE
                   NOT INVALID KEY
                       MOVE "Region deleted" TO WK-MSG-LINE
               END-REWRITE
           ELSE
               MOVE "Delete cancelled" TO WK-MSG-LINE
           END-IF.
           DISPLAY DS-MSG.
       DEL-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE REGNF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "MS0110"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
