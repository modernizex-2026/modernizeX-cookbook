       IDENTIFICATION DIVISION.
       PROGRAM-ID. IV0050.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : IV0050  -  Inter-warehouse stock transfer        *
      *  FUNCTION : move stock of one product from a source          *
      *             warehouse to a destination warehouse.  The       *
      *             operator enters the product, the from-warehouse, *
      *             the to-warehouse and the quantity.  The quantity *
      *             available at the source (SK-ONHAND - SK-ALLOCATED)*
      *             is validated.  On confirmation the source         *
      *             SK-ONHAND is decreased and the destination        *
      *             SK-ONHAND is increased (the destination stock     *
      *             record is created if it does not yet exist).  Two *
      *             SMOVF movements of kind 40 (transfer) are written *
      *             - a negative one at the source and a positive one *
      *             at the destination - each with its own sequence   *
      *             number from NUMGEN "STKMOV" and the correct        *
      *             SM-BAL-AFTER.  Both new balances are displayed.   *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SSTOK.
           COPY SSMOV.
           COPY SPROD.
           COPY SWHSE.
       I-O-CONTROL.
           APPLY SHARED-MODE ON STOKF
           APPLY SHARED-MODE ON SMOVF.
       DATA DIVISION.
       FILE SECTION.
           COPY FSTOK.
           COPY FSMOV.
           COPY FPROD.
           COPY FWHSE.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
      *----- transfer work --------------------------------------------
       01  WK-TR.
           02  WK-KEY-PROD         PIC 9(8)  VALUE 0.
           02  WK-FROM-WHSE        PIC 9(3)  VALUE 0.
           02  WK-TO-WHSE          PIC 9(3)  VALUE 0.
           02  WK-TR-QTY           PIC S9(9) VALUE 0.
           02  WK-PR-NAME          PIC X(40) VALUE SPACE.
           02  WK-FROM-NAME        PIC X(30) VALUE SPACE.
           02  WK-TO-NAME          PIC X(30) VALUE SPACE.
           02  WK-AVAIL            PIC S9(9) VALUE 0.
           02  WK-SRC-ONHAND       PIC S9(9) VALUE 0.
           02  WK-SRC-ALLOC        PIC S9(9) VALUE 0.
           02  WK-DST-ONHAND       PIC S9(9) VALUE 0.
           02  WK-SRC-NEW          PIC S9(9) VALUE 0.
           02  WK-DST-NEW          PIC S9(9) VALUE 0.
           02  WK-UNIT-COST        PIC S9(9)V9(2) VALUE 0.
           02  WK-STK-MNG          PIC 9(1)  VALUE 0.
      *----- movement build work --------------------------------------
       01  WK-MV.
           02  WK-MV-WHSE          PIC 9(3)  VALUE 0.
           02  WK-MV-QTY           PIC S9(9) VALUE 0.
           02  WK-MV-BAL           PIC S9(9) VALUE 0.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4.
             03  COLUMN 2  VALUE "Product Code :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(8) USING WK-KEY-PROD.
             03  COLUMN 30 PIC X(40) FROM WK-PR-NAME COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE "From Whse    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(3) USING WK-FROM-WHSE.
             03  COLUMN 30 PIC X(30) FROM WK-FROM-NAME COLOR WHITE.
           02  LINE 7.
             03  COLUMN 2  VALUE "To   Whse    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(3) USING WK-TO-WHSE.
             03  COLUMN 30 PIC X(30) FROM WK-TO-NAME COLOR WHITE.
           02  LINE 9.
             03  COLUMN 2  VALUE "Transfer Qty :" COLOR YELLOW.
             03  COLUMN 20 PIC S9(9) USING WK-TR-QTY.
       01  DS-SHOW.
           02  LINE 11 COLUMN 2 VALUE "--- Source warehouse ---"
                              COLOR CYAN.
           02  LINE 12.
             03  COLUMN 2  VALUE "OnHand now   :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM WK-SRC-ONHAND
                              COLOR WHITE.
           02  LINE 13.
             03  COLUMN 2  VALUE "Available    :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM WK-AVAIL COLOR WHITE.
           02  LINE 14.
             03  COLUMN 2  VALUE "OnHand after :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM WK-SRC-NEW COLOR WHITE.
           02  LINE 16 COLUMN 2 VALUE "--- Dest warehouse ---"
                              COLOR CYAN.
           02  LINE 17.
             03  COLUMN 2  VALUE "OnHand now   :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM WK-DST-ONHAND
                              COLOR WHITE.
           02  LINE 18.
             03  COLUMN 2  VALUE "OnHand after :" COLOR YELLOW.
             03  COLUMN 20 PIC ---,---,--9 FROM WK-DST-NEW COLOR WHITE.
       01  DS-CONFIRM.
           02  LINE 20 COLUMN 2 VALUE "Confirm transfer (Y/N):"
                              COLOR YELLOW.
           02  SC-CONF LINE 20 COLUMN 26 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "IV0050"           TO WK-PROGID.
           MOVE "Inter-Warehouse Transfer"          TO WK-TITLE.
           MOVE "ENTER=Read  PF3=End  PF4=Clear"    TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           OPEN I-O   STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O   SMOVF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SMOVF
               CLOSE SMOVF
               OPEN I-O SMOVF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SMOVF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT PRODF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PRODF
               CLOSE PRODF
               OPEN INPUT PRODF
           END-IF.
           OPEN INPUT WHSEF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT WHSEF
               CLOSE WHSEF
               OPEN INPUT WHSEF
           END-IF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAINR-010.
           PERFORM GET-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-KEY
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAINR-999.
           EXIT.
      *----------------------------------------------------------------
       GET-KEY SECTION.
       GKEY-010.
           PERFORM CLEAR-WORK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter product, from/to warehouse and quantity"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
       GKEY-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-WORK SECTION.
       CLRW-010.
           INITIALIZE SK-REC.
           MOVE 0                  TO WK-KEY-PROD.
           MOVE 0                  TO WK-FROM-WHSE WK-TO-WHSE.
           MOVE 0                  TO WK-TR-QTY WK-AVAIL.
           MOVE 0                  TO WK-SRC-ONHAND WK-SRC-ALLOC.
           MOVE 0                  TO WK-DST-ONHAND.
           MOVE 0                  TO WK-SRC-NEW WK-DST-NEW.
           MOVE 0                  TO WK-UNIT-COST WK-STK-MNG.
           MOVE SPACE              TO WK-PR-NAME WK-CONFIRM.
           MOVE SPACE              TO WK-FROM-NAME WK-TO-NAME.
       CLRW-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-KEY SECTION.
       PKEY-010.
           PERFORM VALIDATE-INPUT.
           IF ERR-YES
               GO TO PKEY-999
           END-IF.
           PERFORM READ-SOURCE-STOCK.
           IF ERR-YES
               GO TO PKEY-999
           END-IF.
           PERFORM READ-DEST-STOCK.
           COMPUTE WK-SRC-NEW = WK-SRC-ONHAND - WK-TR-QTY.
           COMPUTE WK-DST-NEW = WK-DST-ONHAND + WK-TR-QTY.
           PERFORM CONFIRM-TRANSFER.
       PKEY-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-INPUT SECTION.
       VIN-010.
           MOVE 0                  TO ERR-FLG.
           IF WK-KEY-PROD = 0
               MOVE "Product code must not be zero" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VIN-999
           END-IF.
           MOVE WK-KEY-PROD        TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "Product not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VIN-999
           END-READ.
           IF PR-DEL-FLAG = 1
               MOVE "Product is deleted" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VIN-999
           END-IF.
           MOVE PR-NAME            TO WK-PR-NAME.
           MOVE PR-STOCK-MNG       TO WK-STK-MNG.
           IF WK-STK-MNG = 0
               MOVE "Product is not stock-managed" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VIN-999
           END-IF.
           IF WK-FROM-WHSE = 0 OR WK-TO-WHSE = 0
               MOVE "Both warehouses are required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VIN-999
           END-IF.
           IF WK-FROM-WHSE = WK-TO-WHSE
               MOVE "From and to warehouse must differ"
                                   TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VIN-999
           END-IF.
           MOVE WK-FROM-WHSE       TO WH-CODE.
           READ WHSEF
               INVALID KEY
                   MOVE "From warehouse not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VIN-999
           END-READ.
           IF WH-DEL-FLAG = 1
               MOVE "From warehouse is deleted" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VIN-999
           END-IF.
           MOVE WH-NAME            TO WK-FROM-NAME.
           MOVE WK-TO-WHSE         TO WH-CODE.
           READ WHSEF
               INVALID KEY
                   MOVE "To warehouse not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VIN-999
           END-READ.
           IF WH-DEL-FLAG = 1
               MOVE "To warehouse is deleted" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VIN-999
           END-IF.
           MOVE WH-NAME            TO WK-TO-NAME.
           IF WK-TR-QTY <= 0
               MOVE "Transfer quantity must be positive"
                                   TO WK-MSG-LINE
               SET ERR-YES TO TRUE
           END-IF.
       VIN-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       READ-SOURCE-STOCK SECTION.
       RSS-010.
           MOVE 0                  TO ERR-FLG.
           MOVE WK-KEY-PROD        TO SK-PROD.
           MOVE WK-FROM-WHSE       TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   MOVE "No stock at source warehouse" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   DISPLAY DS-MSG
                   GO TO RSS-999
           END-READ.
           MOVE SK-ONHAND          TO WK-SRC-ONHAND.
           MOVE SK-ALLOCATED       TO WK-SRC-ALLOC.
           MOVE SK-AVG-COST        TO WK-UNIT-COST.
           COMPUTE WK-AVAIL = SK-ONHAND - SK-ALLOCATED.
           IF WK-TR-QTY > WK-AVAIL
               MOVE "Quantity exceeds available at source"
                                   TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               DISPLAY DS-MSG
           END-IF.
       RSS-999.
           EXIT.
      *----------------------------------------------------------------
       READ-DEST-STOCK SECTION.
       RDS-010.
           MOVE 0                  TO WK-DST-ONHAND.
           MOVE WK-KEY-PROD        TO SK-PROD.
           MOVE WK-TO-WHSE         TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   MOVE 0          TO WK-DST-ONHAND
               NOT INVALID KEY
                   MOVE SK-ONHAND  TO WK-DST-ONHAND
           END-READ.
       RDS-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-TRANSFER SECTION.
       CFT-010.
           MOVE SPACE              TO WK-CONFIRM.
           DISPLAY DS-SHOW.
           MOVE "Confirm the transfer (Y/N)" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               PERFORM POST-TRANSFER
           ELSE
               MOVE "Transfer cancelled" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CFT-999.
           EXIT.
      *----------------------------------------------------------------
       POST-TRANSFER SECTION.
       PT-010.
           PERFORM DECREASE-SOURCE.
           IF ERR-YES
               GO TO PT-999
           END-IF.
           MOVE WK-FROM-WHSE       TO WK-MV-WHSE.
           COMPUTE WK-MV-QTY = 0 - WK-TR-QTY.
           MOVE WK-SRC-NEW         TO WK-MV-BAL.
           PERFORM WRITE-MOVE.
           PERFORM INCREASE-DEST.
           MOVE WK-TO-WHSE         TO WK-MV-WHSE.
           MOVE WK-TR-QTY          TO WK-MV-QTY.
           MOVE WK-DST-NEW         TO WK-MV-BAL.
           PERFORM WRITE-MOVE.
           PERFORM SHOW-RESULT.
       PT-999.
           EXIT.
      *----------------------------------------------------------------
       DECREASE-SOURCE SECTION.
       DSR-010.
           MOVE 0                  TO ERR-FLG.
           MOVE WK-KEY-PROD        TO SK-PROD.
           MOVE WK-FROM-WHSE       TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   MOVE "Source stock disappeared" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   DISPLAY DS-MSG
                   GO TO DSR-999
           END-READ.
           SUBTRACT WK-TR-QTY      FROM SK-ONHAND.
           ADD WK-TR-QTY           TO SK-YTD-OUT.
           MOVE WK-SYSDATE         TO SK-LAST-OUT-DATE.
           MOVE SK-ONHAND          TO WK-SRC-NEW.
           MOVE SK-AVG-COST        TO WK-UNIT-COST.
           REWRITE SK-REC
               INVALID KEY
                   MOVE "Source stock update failed" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   DISPLAY DS-MSG
           END-REWRITE.
       DSR-999.
           EXIT.
      *----------------------------------------------------------------
       INCREASE-DEST SECTION.
       IND-010.
           MOVE WK-KEY-PROD        TO SK-PROD.
           MOVE WK-TO-WHSE         TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   PERFORM CREATE-DEST
                   GO TO IND-999
           END-READ.
           ADD WK-TR-QTY           TO SK-ONHAND.
           ADD WK-TR-QTY           TO SK-YTD-IN.
           MOVE WK-SYSDATE         TO SK-LAST-IN-DATE.
           MOVE SK-ONHAND          TO WK-DST-NEW.
           REWRITE SK-REC
               INVALID KEY
                   MOVE "Dest stock update failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
       IND-999.
           EXIT.
      *----------------------------------------------------------------
       CREATE-DEST SECTION.
       CRD-010.
           INITIALIZE SK-REC.
           MOVE WK-KEY-PROD        TO SK-PROD.
           MOVE WK-TO-WHSE         TO SK-WHSE.
           MOVE WK-TR-QTY          TO SK-ONHAND.
           MOVE 0                  TO SK-ALLOCATED.
           MOVE 0                  TO SK-ON-ORDER.
           MOVE WK-UNIT-COST       TO SK-AVG-COST.
           MOVE WK-SYSDATE         TO SK-LAST-IN-DATE.
           MOVE WK-TR-QTY          TO SK-YTD-IN.
           MOVE WK-TR-QTY          TO WK-DST-NEW.
           WRITE SK-REC
               INVALID KEY
                   MOVE "Dest stock create failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       CRD-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-MOVE SECTION.
      *    write one transfer movement (kind 40) using WK-MV fields
       WMV-010.
           MOVE "STKMOV"           TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Movement number assignment failed"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO WMV-999
           END-IF.
           INITIALIZE SM-REC.
           MOVE KNUM-NUMBER        TO SM-SEQ.
           MOVE WK-SYSDATE         TO SM-DATE.
           MOVE WK-KEY-PROD        TO SM-PROD.
           MOVE WK-MV-WHSE         TO SM-WHSE.
           MOVE 40                 TO SM-KIND.
           MOVE WK-MV-QTY          TO SM-QTY.
           MOVE WK-UNIT-COST       TO SM-UNIT-COST.
           MOVE WK-MV-BAL          TO SM-BAL-AFTER.
           MOVE 40                 TO SM-REF-TYPE.
           MOVE KNUM-NUMBER        TO SM-REF-NO.
           MOVE WK-USER-CODE       TO SM-USER.
           WRITE SM-REC
               INVALID KEY
                   MOVE "Movement write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       WMV-999.
           EXIT.
      *----------------------------------------------------------------
       SHOW-RESULT SECTION.
       SHR-010.
           DISPLAY DS-SHOW.
           MOVE WK-TR-QTY          TO WK-ED-QTY.
           MOVE SPACE              TO WK-MSG-LINE.
           STRING "Transferred "   DELIMITED SIZE
                  WK-ED-QTY         DELIMITED SIZE
                  " units - done"   DELIMITED SIZE
                  INTO WK-MSG-LINE.
           DISPLAY DS-MSG.
       SHR-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE STOKF SMOVF PRODF WHSEF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "IV0050"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
