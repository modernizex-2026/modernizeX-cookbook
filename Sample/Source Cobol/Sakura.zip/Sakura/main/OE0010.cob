       IDENTIFICATION DIVISION.
       PROGRAM-ID. OE0010.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : OE0010  -  Sales order entry                     *
      *  FUNCTION : enter a sales order header and its detail lines. *
      *             Customer / product are validated; unit price is  *
      *             resolved from the customer contract price or the *
      *             product rank price; stock is allocated; tax is   *
      *             computed; the order number is assigned by NUMGEN.*
      *  AUTHOR   : SAKURA-SMS team                                  *
      *  NOTE     : golden reference for transaction-entry programs. *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SORDH.
           COPY SORDD.
           COPY SCUST.
           COPY SPROD.
           COPY SCPRC.
           COPY SSTOK.
       I-O-CONTROL.
           APPLY SHARED-MODE ON ORDHF
           APPLY SHARED-MODE ON ORDDF
           APPLY SHARED-MODE ON STOKF.
       DATA DIVISION.
       FILE SECTION.
           COPY FORDH.
           COPY FORDD.
           COPY FCUST.
           COPY FPROD.
           COPY FCPRC.
           COPY FSTOK.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-FLAGS2.
           02  HDR-OK              PIC 9(1)  VALUE 0.
             88  HDR-YES                     VALUE 1.
           02  DTL-DONE            PIC 9(1)  VALUE 0.
             88  DTL-END                     VALUE 1.
           02  SAVE-OK             PIC 9(1)  VALUE 0.
       01  WK-HDR-DISP.
           02  WK-CUST-NAME        PIC X(40) VALUE SPACE.
           02  WK-ORD-NO-D         PIC 9(10) VALUE 0.
       01  WK-DET.
           02  WK-D-PROD           PIC 9(8)  VALUE 0.
           02  WK-D-WHSE           PIC 9(3)  VALUE 0.
           02  WK-D-QTY            PIC S9(9) VALUE 0.
           02  WK-D-PRICE          PIC S9(9)V9(2) VALUE 0.
           02  WK-D-AMT            PIC S9(11)     VALUE 0.
           02  WK-D-NAME           PIC X(40) VALUE SPACE.
           02  WK-D-TAXCAT         PIC 9(1)  VALUE 1.
           02  WK-D-AVAIL          PIC S9(9) VALUE 0.
       01  WK-TOTALS.
           02  WK-NET-TOTAL        PIC S9(13) VALUE 0.
           02  WK-TAX-TOTAL        PIC S9(13) VALUE 0.
           02  WK-GRS-TOTAL        PIC S9(13) VALUE 0.
       01  WK-LINE-TABLE.
           02  WK-LCNT             PIC 9(3)  VALUE 0.
           02  WK-LINE OCCURS 200 INDEXED BY LX.
             03  WL-PROD           PIC 9(8).
             03  WL-WHSE           PIC 9(3).
             03  WL-QTY            PIC S9(9).
             03  WL-PRICE          PIC S9(9)V9(2).
             03  WL-AMOUNT         PIC S9(11).
             03  WL-TAXCAT         PIC 9(1).
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-HEAD.
           02  LINE 3.
             03  COLUMN 2  VALUE "Order No   :" COLOR YELLOW.
             03  COLUMN 16 PIC ZZZZZZZZZ9 FROM WK-ORD-NO-D COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "Order Date :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING OH-DATE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Customer   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(6) USING OH-CUST.
             03  COLUMN 24 PIC X(40) FROM WK-CUST-NAME COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE "Sales Rep  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(4) USING OH-STAFF.
           02  LINE 7.
             03  COLUMN 2  VALUE "Warehouse  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(3) USING OH-WHSE.
           02  LINE 8.
             03  COLUMN 2  VALUE "Due Date   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING OH-DUE-DATE.
           02  LINE 9.
             03  COLUMN 2  VALUE "Customer PO:" COLOR YELLOW.
             03  COLUMN 16 PIC X(20) USING OH-CUST-PO.
           02  LINE 10.
             03  COLUMN 2  VALUE "Tax Type   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(1) USING OH-TAX-TYPE.
             03  COLUMN 20 VALUE "1:excl 2:incl 3:exempt" COLOR CYAN.
       01  DS-DETAIL.
           02  LINE 12 COLUMN 2 VALUE "--- Detail line entry ---"
                              COLOR CYAN.
           02  LINE 13.
             03  COLUMN 2  VALUE "Product    :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING WK-D-PROD.
             03  COLUMN 26 PIC X(40) FROM WK-D-NAME COLOR WHITE.
           02  LINE 14.
             03  COLUMN 2  VALUE "Warehouse  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(3) USING WK-D-WHSE.
           02  LINE 15.
             03  COLUMN 2  VALUE "Quantity   :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(9) USING WK-D-QTY.
           02  LINE 16.
             03  COLUMN 2  VALUE "Unit Price :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(9)V9(2) USING WK-D-PRICE.
       01  DS-STATUS.
           02  LINE 19.
             03  COLUMN 2  VALUE "Lines :" COLOR YELLOW.
             03  COLUMN 10 PIC ZZ9 FROM WK-LCNT COLOR WHITE.
             03  COLUMN 20 VALUE "Net Total :" COLOR YELLOW.
             03  COLUMN 32 PIC ---,---,---,--9 FROM WK-NET-TOTAL
                              COLOR WHITE.
       01  DS-CONFIRM.
           02  LINE 21 COLUMN 2 VALUE "Save order (Y/N):" COLOR YELLOW.
           02  LINE 21 COLUMN 24 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM ORDER-LOOP UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "OE0010"           TO WK-PROGID.
           MOVE "Sales Order Entry"                TO WK-TITLE.
           MOVE "ENTER=Next  PF3=End/Finish  PF4=Clear line"
                                   TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           PERFORM OPEN-IO-ORDH.
           PERFORM OPEN-IO-ORDD.
           OPEN I-O   STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           OPEN INPUT CUSTF.
           OPEN INPUT PRODF.
           OPEN INPUT CPRCF.
       OPENF-999.
           EXIT.
       OPEN-IO-ORDH SECTION.
       OIOH-010.
           OPEN I-O ORDHF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ORDHF
               CLOSE ORDHF
               OPEN I-O ORDHF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ORDHF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIOH-999.
           EXIT.
       OPEN-IO-ORDD SECTION.
       OIOD-010.
           OPEN I-O ORDDF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT ORDDF
               CLOSE ORDDF
               OPEN I-O ORDDF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "ORDDF" TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
       OIOD-999.
           EXIT.
      *----------------------------------------------------------------
       ORDER-LOOP SECTION.
       OLOOP-010.
           PERFORM CLEAR-ORDER.
           PERFORM ENTER-HEADER.
           IF END-YES
               GO TO OLOOP-999
           END-IF.
           IF NOT HDR-YES
               GO TO OLOOP-999
           END-IF.
           PERFORM DETAIL-LOOP UNTIL DTL-END.
           IF WK-LCNT > 0
               PERFORM CONFIRM-SAVE
           ELSE
               MOVE "No lines entered - order discarded"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       OLOOP-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-ORDER SECTION.
       CLRO-010.
           INITIALIZE OH-REC.
           INITIALIZE WK-DET.
           MOVE 0                  TO WK-LCNT.
           MOVE 0                  TO WK-NET-TOTAL WK-TAX-TOTAL.
           MOVE 0                  TO WK-GRS-TOTAL.
           MOVE 0                  TO HDR-OK DTL-DONE.
           MOVE 0                  TO WK-ORD-NO-D.
           MOVE SPACE              TO WK-CUST-NAME WK-CONFIRM.
           MOVE WK-SYSDATE         TO OH-DATE  OH-DUE-DATE.
           MOVE 1                  TO OH-TAX-TYPE.
       CLRO-999.
           EXIT.
      *----------------------------------------------------------------
       ENTER-HEADER SECTION.
       EHDR-010.
           MOVE 0                  TO HDR-OK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter order header - PF3 to quit" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-HEAD.
           ACCEPT  DS-HEAD.
           IF ESTS = "03"
               IF OH-CUST = 0
                   SET END-YES TO TRUE
               END-IF
               GO TO EHDR-999
           END-IF.
           PERFORM VALIDATE-HEADER.
       EHDR-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-HEADER SECTION.
       VHDR-010.
           IF OH-CUST = 0
               MOVE "Customer code required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO VHDR-999
           END-IF.
           MOVE OH-CUST            TO CU-CODE.
           READ CUSTF
               INVALID KEY
                   MOVE "Customer not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO VHDR-999
           END-READ.
           IF CU-DEL-FLAG = 1
               MOVE "Customer is deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO VHDR-999
           END-IF.
           MOVE CU-NAME            TO WK-CUST-NAME.
           IF OH-STAFF = 0
               MOVE CU-STAFF       TO OH-STAFF
           END-IF.
           IF OH-TAX-TYPE = 0
               MOVE CU-TAX-TYPE    TO OH-TAX-TYPE
           END-IF.
           MOVE 1                  TO HDR-OK.
           DISPLAY DS-HEAD.
           MOVE "Header OK - enter detail lines" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       VHDR-999.
           EXIT.
      *----------------------------------------------------------------
       DETAIL-LOOP SECTION.
       DLOOP-010.
           PERFORM CLEAR-DETAIL.
           MOVE OH-WHSE            TO WK-D-WHSE.
           DISPLAY DS-DETAIL.
           DISPLAY DS-STATUS.
           ACCEPT  DS-DETAIL.
           EVALUATE ESTS
               WHEN "03"
                   SET DTL-END TO TRUE
               WHEN "04"
                   MOVE "Line cleared" TO WK-MSG-LINE
                   DISPLAY DS-MSG
               WHEN "00"
                   PERFORM PROCESS-DETAIL
               WHEN OTHER
                   MOVE "Invalid key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       DLOOP-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-DETAIL SECTION.
       CLRD-010.
           MOVE 0                  TO WK-D-PROD WK-D-WHSE WK-D-QTY.
           MOVE 0                  TO WK-D-PRICE WK-D-AMT WK-D-AVAIL.
           MOVE 1                  TO WK-D-TAXCAT.
           MOVE SPACE              TO WK-D-NAME.
       CLRD-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-DETAIL SECTION.
       PDET-010.
           IF WK-D-PROD = 0
               MOVE "Product code required" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           MOVE WK-D-PROD          TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "Product not found" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO PDET-999
           END-READ.
           IF PR-DEL-FLAG = 1
               MOVE "Product is deleted" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           MOVE PR-NAME            TO WK-D-NAME.
           MOVE PR-TAX-CATEGORY    TO WK-D-TAXCAT.
           IF WK-D-QTY <= 0
               MOVE "Quantity must be positive" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PDET-999
           END-IF.
           IF WK-D-PRICE <= 0
               PERFORM RESOLVE-PRICE
           END-IF.
           COMPUTE WK-D-AMT = WK-D-QTY * WK-D-PRICE.
           PERFORM CHECK-STOCK.
           PERFORM ADD-LINE.
       PDET-999.
           EXIT.
      *----------------------------------------------------------------
       RESOLVE-PRICE SECTION.
       RPRC-010.
      *    1) customer contract price  2) product rank price  3) list
           MOVE OH-CUST            TO CP-CUST.
           MOVE WK-D-PROD          TO CP-PROD.
           READ CPRCF
               INVALID KEY
                   PERFORM RANK-PRICE
               NOT INVALID KEY
                   IF CP-DEL-FLAG = 0
                     AND CP-START-DATE <= OH-DATE
                     AND (CP-END-DATE = 0 OR CP-END-DATE >= OH-DATE)
                       MOVE CP-PRICE TO WK-D-PRICE
                   ELSE
                       PERFORM RANK-PRICE
                   END-IF
           END-READ.
       RPRC-999.
           EXIT.
       RANK-PRICE SECTION.
       RANK-010.
           IF CU-PRICE-RANK >= 1 AND CU-PRICE-RANK <= 5
               MOVE PR-RANK-PRICE (CU-PRICE-RANK) TO WK-D-PRICE
           END-IF.
           IF WK-D-PRICE <= 0
               MOVE PR-LIST-PRICE  TO WK-D-PRICE
           END-IF.
       RANK-999.
           EXIT.
      *----------------------------------------------------------------
       CHECK-STOCK SECTION.
       CSTK-010.
           IF PR-STOCK-MNG = 0
               GO TO CSTK-999
           END-IF.
           MOVE WK-D-PROD          TO SK-PROD.
           MOVE WK-D-WHSE          TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   MOVE 0          TO WK-D-AVAIL
               NOT INVALID KEY
                   COMPUTE WK-D-AVAIL = SK-ONHAND - SK-ALLOCATED
           END-READ.
           IF WK-D-QTY > WK-D-AVAIL
               MOVE "Warning: quantity exceeds available stock"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CSTK-999.
           EXIT.
      *----------------------------------------------------------------
       ADD-LINE SECTION.
       ADDL-010.
           IF WK-LCNT >= 200
               MOVE "Maximum 200 lines reached" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO ADDL-999
           END-IF.
           ADD 1                   TO WK-LCNT.
           SET LX                  TO WK-LCNT.
           MOVE WK-D-PROD          TO WL-PROD (LX).
           MOVE WK-D-WHSE          TO WL-WHSE (LX).
           MOVE WK-D-QTY           TO WL-QTY  (LX).
           MOVE WK-D-PRICE         TO WL-PRICE(LX).
           MOVE WK-D-AMT           TO WL-AMOUNT(LX).
           MOVE WK-D-TAXCAT        TO WL-TAXCAT(LX).
           ADD  WK-D-AMT           TO WK-NET-TOTAL.
           DISPLAY DS-STATUS.
           MOVE "Line added"       TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       ADDL-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-SAVE SECTION.
       CSAV-010.
           MOVE SPACE              TO WK-CONFIRM.
           PERFORM COMPUTE-TAX-TOTAL.
           DISPLAY DS-STATUS.
           MOVE "Review totals then confirm" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               PERFORM SAVE-ORDER
           ELSE
               MOVE "Order discarded" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CSAV-999.
           EXIT.
      *----------------------------------------------------------------
       COMPUTE-TAX-TOTAL SECTION.
       CTT-010.
           MOVE 1                  TO KT-CATEGORY.
           MOVE OH-TAX-TYPE        TO KT-TAX-TYPE.
           MOVE CU-TAX-ROUND       TO KT-ROUND.
           IF KT-ROUND = 0
               MOVE 1              TO KT-ROUND
           END-IF.
           MOVE OH-DATE            TO KT-DATE.
           MOVE WK-NET-TOTAL       TO KT-AMOUNT.
           CALL "TAXCAL" USING KTAX.
           MOVE KT-NET             TO WK-NET-TOTAL.
           MOVE KT-TAX             TO WK-TAX-TOTAL.
           MOVE KT-GROSS           TO WK-GRS-TOTAL.
       CTT-999.
           EXIT.
      *----------------------------------------------------------------
       SAVE-ORDER SECTION.
       SORD-010.
           MOVE "ORDER"            TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Number assignment failed" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO SORD-999
           END-IF.
           MOVE KNUM-NUMBER        TO OH-NO  WK-ORD-NO-D.
           MOVE WK-NET-TOTAL       TO OH-AMOUNT.
           MOVE WK-TAX-TOTAL       TO OH-TAX-AMOUNT.
           MOVE WK-GRS-TOTAL       TO OH-TOTAL.
           MOVE 0                  TO OH-STATUS.
           MOVE WK-LCNT            TO OH-LINES.
           MOVE WK-SYSDATE         TO OH-ADD-DATE OH-UPD-DATE.
           MOVE WK-USER-CODE       TO OH-ADD-USER OH-UPD-USER.
           MOVE 0                  TO OH-DEL-FLAG.
           WRITE OH-REC
               INVALID KEY
                   MOVE "Header write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO SORD-999
           END-WRITE.
           PERFORM WRITE-DETAILS.
           MOVE "Order saved"      TO WK-MSG-LINE.
           DISPLAY DS-STATUS.
           DISPLAY DS-MSG.
       SORD-999.
           EXIT.
      *----------------------------------------------------------------
       WRITE-DETAILS SECTION.
       WDET-010.
           PERFORM VARYING LX FROM 1 BY 1 UNTIL LX > WK-LCNT
               INITIALIZE OD-REC
               MOVE OH-NO          TO OD-NO
               SET WK-IDX TO LX
               MOVE WK-IDX TO OD-LINE
               MOVE WL-PROD  (LX)  TO OD-PROD
               MOVE WL-WHSE  (LX)  TO OD-WHSE
               MOVE WL-QTY   (LX)  TO OD-QTY
               MOVE WL-PRICE (LX)  TO OD-UNIT-PRICE
               MOVE WL-AMOUNT(LX)  TO OD-AMOUNT
               MOVE WL-TAXCAT(LX)  TO OD-TAX-CATEGORY
               MOVE 0              TO OD-SHIPPED-QTY OD-ALLOC-QTY
               MOVE OH-DUE-DATE    TO OD-DUE-DATE
               MOVE 0              TO OD-STATUS
               WRITE OD-REC
                   INVALID KEY
                       CONTINUE
               END-WRITE
               PERFORM ALLOCATE-STOCK
           END-PERFORM.
       WDET-999.
           EXIT.
      *----------------------------------------------------------------
       ALLOCATE-STOCK SECTION.
       ALOC-010.
           MOVE WL-PROD (LX)       TO SK-PROD.
           MOVE WL-WHSE (LX)       TO SK-WHSE.
           READ STOKF
               INVALID KEY
                   INITIALIZE SK-REC
                   MOVE WL-PROD (LX) TO SK-PROD
                   MOVE WL-WHSE (LX) TO SK-WHSE
                   MOVE WL-QTY  (LX) TO SK-ALLOCATED
                   WRITE SK-REC
                       INVALID KEY CONTINUE
                   END-WRITE
               NOT INVALID KEY
                   ADD WL-QTY (LX) TO SK-ALLOCATED
                   REWRITE SK-REC
                       INVALID KEY CONTINUE
                   END-REWRITE
           END-READ.
       ALOC-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE ORDHF ORDDF STOKF CUSTF PRODF CPRCF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "OE0010"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
