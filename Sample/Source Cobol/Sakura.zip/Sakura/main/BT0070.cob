       IDENTIFICATION DIVISION.
       PROGRAM-ID. BT0070.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : BT0070  -  fiscal-year close                      *
      *  FUNCTION : rolls the system into a new fiscal year.  It      *
      *             snapshots and then zeroes the year-to-date        *
      *             receipt / issue figures on every stock-balance    *
      *             row (SK-YTD-IN, SK-YTD-OUT), reporting the prior  *
      *             YTD totals and the closing inventory valuation    *
      *             per warehouse.  It then advances the system       *
      *             current accounting month (SYSCF SY-CURR-YM) to    *
      *             the start of the new fiscal year, derived from    *
      *             SY-FISCAL-START (operator may override).          *
      *             Console / batch (no screen section).               *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SSYSC.
           COPY SSTOK.
       DATA DIVISION.
       FILE SECTION.
           COPY FSYSC.
           COPY FSTOK.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
           COPY KLINK.
      *----- run parameters --------------------------------------------
       01  WK-PARM.
           02  WK-IN-LINE          PIC X(10) VALUE SPACE.
           02  WK-NEW-YM           PIC 9(6)  VALUE 0.
           02  WK-DFLT-YM          PIC 9(6)  VALUE 0.
           02  WK-OLD-YM           PIC 9(6)  VALUE 0.
      *----- fiscal calculation work -----------------------------------
       01  WK-FISCAL.
           02  WK-YYYY             PIC 9(4)  VALUE 0.
           02  WK-MM               PIC 9(2)  VALUE 0.
           02  WK-FY-YEAR          PIC 9(4)  VALUE 0.
           02  WK-NEW-YEAR         PIC 9(4)  VALUE 0.
      *----- accumulators (grand) --------------------------------------
       01  WK-TOTALS.
           02  WK-READ-CNT         PIC 9(7)  VALUE 0.
           02  WK-RESET-CNT        PIC 9(7)  VALUE 0.
           02  WK-ACTIVE-CNT       PIC 9(7)  VALUE 0.
           02  WK-WHSE-CNT         PIC 9(7)  VALUE 0.
           02  WK-ONHAND-TOT       PIC S9(13) VALUE 0.
           02  WK-VAL-TOT          PIC S9(13)V9(2) VALUE 0.
           02  WK-YTDIN-TOT        PIC S9(13) VALUE 0.
           02  WK-YTDOUT-TOT       PIC S9(13) VALUE 0.
      *----- per-warehouse subtotal ------------------------------------
       01  WK-SUBS.
           02  WK-WH-ITEMS         PIC 9(7)  VALUE 0.
           02  WK-WH-YTDIN         PIC S9(13) VALUE 0.
           02  WK-WH-YTDOUT        PIC S9(13) VALUE 0.
           02  WK-WH-VAL           PIC S9(13)V9(2) VALUE 0.
      *----- per-item / control break ----------------------------------
       01  WK-CALC.
           02  WK-ITEM-VAL         PIC S9(13)V9(2) VALUE 0.
           02  WK-FIRST-FLG        PIC 9(1)  VALUE 0.
           02  WK-PREV-WHSE        PIC 9(3)  VALUE 0.
      *----- display edit work -----------------------------------------
       01  WK-DISP.
           02  WK-E-CNT            PIC Z,ZZZ,ZZ9.
           02  WK-E-WHSE           PIC ZZ9.
           02  WK-E-QTY            PIC Z,ZZZ,ZZZ,ZZ9-.
           02  WK-E-VAL            PIC Z,ZZZ,ZZZ,ZZZ,ZZ9.99-.
           02  WK-E-YM             PIC 9999/99.
      *----- flags -----------------------------------------------------
       01  WK-FLAGS.
           02  WK-ABORT-FLG        PIC 9(1)  VALUE 0.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           IF WK-ABORT-FLG = 0
               PERFORM PROCESS-STOCK
               PERFORM UPDATE-SYSCF
               PERFORM PRINT-SUMMARY
           END-IF.
           PERFORM TERM-RTN.
           MOVE 0                  TO COMPLETION-CODE.
           EXIT PROGRAM.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "BT0070"           TO WK-PROGID.
           DISPLAY " ".
           DISPLAY "==============================================".
           DISPLAY " SAKURA-SMS  BT0070  -  FISCAL YEAR CLOSE".
           DISPLAY "==============================================".
           PERFORM GET-TODAY.
           PERFORM OPEN-FILES.
           PERFORM READ-SYSCF.
           PERFORM CALC-NEW-FY.
           PERFORM ACCEPT-NEW-FY.
           IF WK-ABORT-FLG = 0
               PERFORM CONFIRM-RUN
           END-IF.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       GET-TODAY SECTION.
       GTOD-010.
           MOVE "TODY"             TO KD-FUNC.
           MOVE 0                  TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSDATE  WK-SYSYMD.
       GTOD-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPEN-010.
           OPEN I-O    SYSCF.
           IF FSTS NOT = "00"
               MOVE "SYSCF"        TO KA-FILE
               MOVE "Open SYSCF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O    STOKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT STOKF
               CLOSE STOKF
               OPEN I-O STOKF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "STOKF"        TO KA-FILE
               MOVE "Open STOKF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
       OPEN-999.
           EXIT.
      *----------------------------------------------------------------
       READ-SYSCF SECTION.
       RSYS-010.
           MOVE 1                  TO SY-KEY.
           READ SYSCF
               INVALID KEY
                   MOVE "SYSCF"    TO KA-FILE
                   MOVE "System control record missing" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-READ.
           MOVE SY-CURR-YM         TO WK-OLD-YM.
       RSYS-999.
           EXIT.
      *----------------------------------------------------------------
      *  CALC-NEW-FY : derive next fiscal-year start (YYYYMM)          *
      *----------------------------------------------------------------
       CALC-NEW-FY SECTION.
       CFY-010.
           COMPUTE WK-YYYY = SY-CURR-YM / 100.
           COMPUTE WK-MM = SY-CURR-YM - WK-YYYY * 100.
      *    the fiscal year "belongs to" the year its start month falls
           IF WK-MM NOT < SY-FISCAL-START
               MOVE WK-YYYY        TO WK-FY-YEAR
           ELSE
               COMPUTE WK-FY-YEAR = WK-YYYY - 1
           END-IF.
           COMPUTE WK-NEW-YEAR = WK-FY-YEAR + 1.
           COMPUTE WK-DFLT-YM = WK-NEW-YEAR * 100 + SY-FISCAL-START.
       CFY-999.
           EXIT.
      *----------------------------------------------------------------
       ACCEPT-NEW-FY SECTION.
       ANF-010.
           MOVE WK-DFLT-YM         TO WK-E-YM.
           DISPLAY " ".
           DISPLAY " Fiscal start month : " SY-FISCAL-START.
           DISPLAY " Current month      : " SY-CURR-YM.
           DISPLAY " New fiscal year starts YYYYMM".
           DISPLAY "   (blank = " WK-E-YM ") : " WITH NO ADVANCING.
           MOVE SPACE              TO WK-IN-LINE.
           ACCEPT WK-IN-LINE FROM CONSOLE.
           IF WK-IN-LINE = SPACE
               MOVE WK-DFLT-YM     TO WK-NEW-YM
           ELSE
               IF WK-IN-LINE(1:6) NUMERIC
                   MOVE WK-IN-LINE(1:6) TO WK-NEW-YM
               ELSE
                   DISPLAY " ** invalid month - run cancelled."
                   MOVE 1          TO WK-ABORT-FLG
                   GO TO ANF-999
               END-IF
           END-IF.
           COMPUTE WK-MM = WK-NEW-YM - (WK-NEW-YM / 100) * 100.
           IF WK-MM < 1 OR WK-MM > 12
               DISPLAY " ** month part must be 01-12."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       ANF-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-RUN SECTION.
       CONF-010.
           MOVE WK-OLD-YM          TO WK-E-YM.
           DISPLAY " ".
           DISPLAY " Close fiscal year - reset all stock YTD figures".
           DISPLAY " Current month now : " WK-E-YM.
           MOVE WK-NEW-YM          TO WK-E-YM.
           DISPLAY " New current month : " WK-E-YM.
           DISPLAY " Proceed ? (Y/N) : " WITH NO ADVANCING.
           MOVE SPACE              TO WK-CONFIRM.
           ACCEPT WK-CONFIRM FROM CONSOLE.
           IF NOT CONFIRM-YES
               DISPLAY " ** cancelled by operator."
               MOVE 1              TO WK-ABORT-FLG
           END-IF.
       CONF-999.
           EXIT.
      *----------------------------------------------------------------
      *  PROCESS-STOCK : snapshot + reset YTD, warehouse control break *
      *----------------------------------------------------------------
       PROCESS-STOCK SECTION.
       PROC-010.
           DISPLAY " ".
           DISPLAY " Resetting stock YTD figures ...".
           DISPLAY " ".
           DISPLAY " WHSE     ITEMS       YTD-IN      YTD-OUT".
           DISPLAY "----------------------------------------------".
           MOVE 0                  TO EOF-FLG.
           MOVE 1                  TO WK-FIRST-FLG.
           MOVE 0                  TO WK-PREV-WHSE.
           PERFORM CLEAR-SUBTOTAL.
           MOVE 0                  TO SK-WHSE.
           MOVE 0                  TO SK-PROD.
           START STOKF KEY NOT LESS THAN SK-WHSE
               INVALID KEY
                   SET EOF-YES     TO TRUE
           END-START.
           PERFORM PROC-NEXT UNTIL EOF-YES.
           IF WK-FIRST-FLG = 0
               PERFORM PRINT-SUBTOTAL
           END-IF.
       PROC-999.
           EXIT.
      *----------------------------------------------------------------
       PROC-NEXT SECTION.
       PNXT-010.
           READ STOKF NEXT
               AT END
                   SET EOF-YES     TO TRUE
                   GO TO PNXT-999
           END-READ.
           IF FSTS NOT = "00" AND FSTS NOT = "02"
               MOVE "STOKF"        TO KA-FILE
               MOVE "READ NEXT STOKF failed" TO KA-DETAIL
               PERFORM ABEND-RTN
           END-IF.
           IF WK-FIRST-FLG = 1
               MOVE 0              TO WK-FIRST-FLG
               MOVE SK-WHSE        TO WK-PREV-WHSE
           END-IF.
           IF SK-WHSE NOT = WK-PREV-WHSE
               PERFORM PRINT-SUBTOTAL
               PERFORM CLEAR-SUBTOTAL
               MOVE SK-WHSE        TO WK-PREV-WHSE
           END-IF.
           PERFORM RESET-ONE.
       PNXT-999.
           EXIT.
      *----------------------------------------------------------------
       RESET-ONE SECTION.
       RONE-010.
           ADD 1                   TO WK-READ-CNT.
           COMPUTE WK-ITEM-VAL = SK-ONHAND * SK-AVG-COST.
      *    accumulate the prior-year YTD figures for the report
           ADD SK-ONHAND           TO WK-ONHAND-TOT.
           ADD WK-ITEM-VAL         TO WK-VAL-TOT     WK-WH-VAL.
           ADD SK-YTD-IN           TO WK-YTDIN-TOT   WK-WH-YTDIN.
           ADD SK-YTD-OUT          TO WK-YTDOUT-TOT  WK-WH-YTDOUT.
           ADD 1                   TO WK-WH-ITEMS.
           IF SK-YTD-IN NOT = 0 OR SK-YTD-OUT NOT = 0
               ADD 1               TO WK-ACTIVE-CNT
           END-IF.
      *    zero the year-to-date buckets for the new fiscal year
           MOVE 0                  TO SK-YTD-IN.
           MOVE 0                  TO SK-YTD-OUT.
           REWRITE SK-REC
               INVALID KEY
                   MOVE "STOKF"    TO KA-FILE
                   MOVE "REWRITE STOKF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-REWRITE.
           ADD 1                   TO WK-RESET-CNT.
       RONE-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-SUBTOTAL SECTION.
       CLSB-010.
           MOVE 0                  TO WK-WH-ITEMS.
           MOVE 0                  TO WK-WH-YTDIN.
           MOVE 0                  TO WK-WH-YTDOUT.
           MOVE 0                  TO WK-WH-VAL.
       CLSB-999.
           EXIT.
      *----------------------------------------------------------------
       PRINT-SUBTOTAL SECTION.
       PRSB-010.
           ADD 1                   TO WK-WHSE-CNT.
           MOVE WK-PREV-WHSE       TO WK-E-WHSE.
           MOVE WK-WH-ITEMS        TO WK-E-CNT.
           DISPLAY " " WK-E-WHSE " " WK-E-CNT WITH NO ADVANCING.
           MOVE WK-WH-YTDIN        TO WK-E-QTY.
           DISPLAY " " WK-E-QTY WITH NO ADVANCING.
           MOVE WK-WH-YTDOUT       TO WK-E-QTY.
           DISPLAY " " WK-E-QTY.
           MOVE WK-WH-VAL          TO WK-E-VAL.
           DISPLAY "          valuation " WK-E-VAL.
       PRSB-999.
           EXIT.
      *----------------------------------------------------------------
      *  UPDATE-SYSCF : advance to the new fiscal year start month     *
      *----------------------------------------------------------------
       UPDATE-SYSCF SECTION.
       USYS-010.
           MOVE 1                  TO SY-KEY.
           READ SYSCF
               INVALID KEY
                   MOVE "SYSCF"    TO KA-FILE
                   MOVE "Re-read SYSCF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-READ.
           MOVE WK-NEW-YM          TO SY-CURR-YM.
           REWRITE SY-REC
               INVALID KEY
                   MOVE "SYSCF"    TO KA-FILE
                   MOVE "REWRITE SYSCF failed" TO KA-DETAIL
                   PERFORM ABEND-RTN
           END-REWRITE.
       USYS-999.
           EXIT.
      *----------------------------------------------------------------
      *  PRINT-SUMMARY                                                 *
      *----------------------------------------------------------------
       PRINT-SUMMARY SECTION.
       PSUM-010.
           DISPLAY "----------------------------------------------".
           DISPLAY " FISCAL YEAR CLOSE SUMMARY".
           DISPLAY "----------------------------------------------".
           MOVE WK-READ-CNT        TO WK-E-CNT.
           DISPLAY " Stock rows read   : " WK-E-CNT.
           MOVE WK-RESET-CNT       TO WK-E-CNT.
           DISPLAY " Rows YTD reset    : " WK-E-CNT.
           MOVE WK-ACTIVE-CNT      TO WK-E-CNT.
           DISPLAY " Rows had activity : " WK-E-CNT.
           MOVE WK-WHSE-CNT        TO WK-E-CNT.
           DISPLAY " Warehouses        : " WK-E-CNT.
           MOVE WK-ONHAND-TOT      TO WK-E-QTY.
           DISPLAY " Total onhand qty  : " WK-E-QTY.
           MOVE WK-YTDIN-TOT       TO WK-E-QTY.
           DISPLAY " Prior YTD in      : " WK-E-QTY.
           MOVE WK-YTDOUT-TOT      TO WK-E-QTY.
           DISPLAY " Prior YTD out     : " WK-E-QTY.
           MOVE WK-VAL-TOT         TO WK-E-VAL.
           DISPLAY " Closing valuation : " WK-E-VAL.
           MOVE WK-OLD-YM          TO WK-E-YM.
           DISPLAY " Previous month    : " WK-E-YM.
           MOVE WK-NEW-YM          TO WK-E-YM.
           DISPLAY " New fiscal month  : " WK-E-YM.
           DISPLAY "----------------------------------------------".
           DISPLAY " BT0070 completed normally.".
       PSUM-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE SYSCF.
           CLOSE STOKF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABND-010.
           MOVE "BT0070"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EBATCH"           TO KA-MSGCODE.
           CALL "ABORTX" USING KABEND.
           CLOSE SYSCF.
           CLOSE STOKF.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABND-999.
           EXIT.
