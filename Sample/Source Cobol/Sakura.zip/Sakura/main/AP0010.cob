       IDENTIFICATION DIVISION.
       PROGRAM-ID. AP0010.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : AP0010  -  Payment entry                          *
      *  FUNCTION : record a payment to a supplier.  The supplier and *
      *             (for transfer) the bank are validated, the        *
      *             payment number is assigned by NUMGEN, a payment   *
      *             record is written to PAYF, an AP ledger line of   *
      *             kind 2 (payment) is posted to APLF with the       *
      *             amount in PL-DEBIT and a running balance, and the *
      *             amount is subtracted from the supplier AP balance.*
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SPAY.
           COPY SAPL.
           COPY SSUPP.
           COPY SBANK.
       I-O-CONTROL.
           APPLY SHARED-MODE ON PAYF
           APPLY SHARED-MODE ON APLF
           APPLY SHARED-MODE ON SUPPF.
       DATA DIVISION.
       FILE SECTION.
           COPY FPAY.
           COPY FAPL.
           COPY FSUPP.
           COPY FBANK.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-PAY.
           02  WK-SUPP-NAME        PIC X(40) VALUE SPACE.
           02  WK-BANK-NAME        PIC X(30) VALUE SPACE.
           02  WK-CUR-BAL          PIC S9(11) VALUE 0.
           02  WK-NEW-BAL          PIC S9(11) VALUE 0.
           02  WK-PY-NO-D          PIC 9(10) VALUE 0.
           02  WK-CLOSE-YM         PIC 9(6)  VALUE 0.
           02  WK-SESS-CNT         PIC 9(5)  VALUE 0.
           02  WK-SESS-AMT         PIC S9(11) VALUE 0.
       01  WK-FLAGS.
           02  HDR-OK              PIC 9(1)  VALUE 0.
             88  HDR-YES                     VALUE 1.
       01  WK-CONST.
           02  WK-REF-PAY          PIC 9(2)  VALUE 27.
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-HEAD.
           02  LINE 3.
             03  COLUMN 2  VALUE "Payment No :" COLOR YELLOW.
             03  COLUMN 16 PIC ZZZZZZZZZ9 FROM WK-PY-NO-D COLOR WHITE.
           02  LINE 4.
             03  COLUMN 2  VALUE "Date       :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(8) USING PY-DATE.
           02  LINE 5.
             03  COLUMN 2  VALUE "Supplier   :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(6) USING PY-SUPP.
             03  COLUMN 24 PIC X(40) FROM WK-SUPP-NAME COLOR WHITE.
           02  LINE 6.
             03  COLUMN 2  VALUE "AP Balance :" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-CUR-BAL
                              COLOR WHITE.
           02  LINE 7.
             03  COLUMN 2  VALUE "Method     :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(1) USING PY-METHOD.
             03  COLUMN 20 VALUE "1:cash 2:transfer 3:bill 4:offset"
                              COLOR CYAN.
           02  LINE 8.
             03  COLUMN 2  VALUE "Amount     :" COLOR YELLOW.
             03  COLUMN 16 PIC S9(11) USING PY-AMOUNT.
           02  LINE 9.
             03  COLUMN 2  VALUE "Bank Code  :" COLOR YELLOW.
             03  COLUMN 16 PIC 9(4) USING PY-BANK-CODE.
             03  COLUMN 24 PIC X(30) FROM WK-BANK-NAME COLOR WHITE.
           02  LINE 10.
             03  COLUMN 2  VALUE "Remark     :" COLOR YELLOW.
             03  COLUMN 16 PIC X(30) USING PY-REMARK.
           02  LINE 11.
             03  COLUMN 2  VALUE "Session cnt:" COLOR CYAN.
             03  COLUMN 16 PIC ZZZZ9 FROM WK-SESS-CNT.
             03  COLUMN 24 VALUE "amt:" COLOR CYAN.
             03  COLUMN 29 PIC ---,---,---,--9 FROM WK-SESS-AMT.
       01  DS-CONFIRM.
           02  LINE 12.
             03  COLUMN 2  VALUE "New Balance:" COLOR YELLOW.
             03  COLUMN 16 PIC ---,---,---,--9 FROM WK-NEW-BAL
                              COLOR WHITE.
           02  LINE 14 COLUMN 2 VALUE "Save payment Y/N:" COLOR YELLOW.
           02  SC-CONF LINE 14 COLUMN 20 PIC X(1) USING WK-CONFIRM.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM PAY-LOOP UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "AP0010"           TO WK-PROGID.
           MOVE "Payment Entry"                   TO WK-TITLE.
           MOVE "ENTER=Confirm  PF3=End  PF4=Clear"
                                   TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           OPEN I-O   PAYF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PAYF
               CLOSE PAYF
               OPEN I-O PAYF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "PAYF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O   APLF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT APLF
               CLOSE APLF
               OPEN I-O APLF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "APLF"         TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN I-O   SUPPF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SUPPF
               CLOSE SUPPF
               OPEN I-O SUPPF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SUPPF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT BANKF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT BANKF
               CLOSE BANKF
               OPEN INPUT BANKF
           END-IF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       PAY-LOOP SECTION.
       PLUP-010.
           PERFORM CLEAR-PAY.
           PERFORM ENTER-HEADER.
           IF END-YES
               GO TO PLUP-999
           END-IF.
           IF HDR-YES
               PERFORM CONFIRM-SAVE
           END-IF.
       PLUP-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-PAY SECTION.
       CLR-010.
           INITIALIZE PY-REC.
           MOVE 0                  TO HDR-OK.
           MOVE 0                  TO WK-CUR-BAL WK-NEW-BAL.
           MOVE 0                  TO WK-PY-NO-D WK-CLOSE-YM.
           MOVE SPACE              TO WK-SUPP-NAME WK-BANK-NAME.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE WK-SYSDATE         TO PY-DATE.
           MOVE 1                  TO PY-METHOD.
       CLR-999.
           EXIT.
      *----------------------------------------------------------------
       ENTER-HEADER SECTION.
       EHDR-010.
           MOVE 0                  TO HDR-OK.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter payment details - PF3 to end" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-HEAD.
           ACCEPT  DS-HEAD.
           IF ESTS = "03"
               SET END-YES TO TRUE
               GO TO EHDR-999
           END-IF.
           IF ESTS = "04"
               MOVE "Cleared" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO EHDR-999
           END-IF.
           PERFORM VALIDATE-HEADER.
       EHDR-999.
           EXIT.
      *----------------------------------------------------------------
       VALIDATE-HEADER SECTION.
       VHDR-010.
           MOVE 0                  TO ERR-FLG.
           MOVE "VALD"             TO KD-FUNC.
           MOVE PY-DATE            TO KD-DATE1.
           CALL "DATEUT" USING KDATE.
           IF KD-STATUS NOT = "00"
               MOVE "Payment date is invalid" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VHDR-999
           END-IF.
           IF PY-SUPP = 0
               MOVE "Supplier code required" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VHDR-999
           END-IF.
           MOVE PY-SUPP            TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE "Supplier not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VHDR-999
           END-READ.
           IF SP-DEL-FLAG = 1
               MOVE "Supplier is deleted" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VHDR-999
           END-IF.
           MOVE SP-NAME            TO WK-SUPP-NAME.
           MOVE SP-BALANCE         TO WK-CUR-BAL.
           IF PY-AMOUNT <= 0
               MOVE "Amount must be positive" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VHDR-999
           END-IF.
           IF PY-METHOD < 1 OR PY-METHOD > 4
               MOVE "Method must be 1 to 4" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VHDR-999
           END-IF.
           PERFORM VALIDATE-BANK.
           IF ERR-YES
               GO TO VHDR-999
           END-IF.
           COMPUTE WK-NEW-BAL = SP-BALANCE - PY-AMOUNT.
           MOVE 1                  TO HDR-OK.
           DISPLAY DS-HEAD.
           MOVE "Details OK - press ENTER to confirm" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
       VHDR-999.
           IF ERR-YES
               DISPLAY DS-MSG
           END-IF.
           CONTINUE.
      *----------------------------------------------------------------
       VALIDATE-BANK SECTION.
       VBNK-010.
           MOVE SPACE              TO WK-BANK-NAME.
           IF PY-BANK-CODE = 0
               IF PY-METHOD = 2
                   MOVE "Bank code required for transfer"
                                   TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
               END-IF
               GO TO VBNK-999
           END-IF.
           MOVE PY-BANK-CODE       TO BK-CODE.
           READ BANKF
               INVALID KEY
                   MOVE "Bank code not found" TO WK-MSG-LINE
                   SET ERR-YES TO TRUE
                   GO TO VBNK-999
           END-READ.
           IF BK-DEL-FLAG = 1
               MOVE "Bank is deleted" TO WK-MSG-LINE
               SET ERR-YES TO TRUE
               GO TO VBNK-999
           END-IF.
           MOVE BK-NAME            TO WK-BANK-NAME.
       VBNK-999.
           EXIT.
      *----------------------------------------------------------------
       CONFIRM-SAVE SECTION.
       CSAV-010.
           MOVE SPACE              TO WK-CONFIRM.
           MOVE "Confirm to post the payment" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-CONFIRM.
           ACCEPT  DS-CONFIRM.
           IF CONFIRM-YES
               PERFORM SAVE-PAY
           ELSE
               MOVE "Payment discarded" TO WK-MSG-LINE
               DISPLAY DS-MSG
           END-IF.
       CSAV-999.
           EXIT.
      *----------------------------------------------------------------
       SAVE-PAY SECTION.
       SAV-010.
           MOVE "PAYMENT"          TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Payment number assignment failed"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO SAV-999
           END-IF.
           MOVE KNUM-NUMBER        TO PY-NO WK-PY-NO-D.
           COMPUTE WK-CLOSE-YM = PY-DATE / 100.
           MOVE WK-CLOSE-YM        TO PY-CLOSE-YM.
           MOVE 0                  TO PY-STATUS PY-DEL-FLAG.
           MOVE WK-SYSDATE         TO PY-ADD-DATE.
           MOVE WK-USER-CODE       TO PY-ADD-USER.
           WRITE PY-REC
               INVALID KEY
                   MOVE "Payment write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO SAV-999
           END-WRITE.
           PERFORM POST-LEDGER.
           PERFORM UPDATE-SUPP-BAL.
           ADD 1                   TO WK-SESS-CNT.
           ADD PY-AMOUNT           TO WK-SESS-AMT.
           MOVE "Payment posted"   TO WK-MSG-LINE.
           DISPLAY DS-HEAD.
           DISPLAY DS-MSG.
       SAV-999.
           EXIT.
      *----------------------------------------------------------------
       UPDATE-SUPP-BAL SECTION.
       USB-010.
           MOVE PY-SUPP            TO SP-CODE.
           READ SUPPF
               INVALID KEY
                   MOVE "Supplier balance update failed"
                                   TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   GO TO USB-999
           END-READ.
           SUBTRACT PY-AMOUNT FROM SP-BALANCE.
           MOVE WK-SYSDATE         TO SP-UPD-DATE.
           MOVE WK-USER-CODE       TO SP-UPD-USER.
           REWRITE SP-REC
               INVALID KEY
                   MOVE "Supplier balance update failed"
                                   TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-REWRITE.
       USB-999.
           EXIT.
      *----------------------------------------------------------------
       POST-LEDGER SECTION.
       PLG-010.
           MOVE "APLDG"            TO KNUM-KEY.
           CALL "NUMGEN" USING KNUM.
           IF KNUM-STATUS NOT = "00"
               MOVE "Ledger number assignment failed"
                                   TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PLG-999
           END-IF.
           INITIALIZE PL-REC.
           MOVE KNUM-NUMBER        TO PL-SEQ.
           MOVE PY-SUPP            TO PL-SUPP.
           MOVE PY-DATE            TO PL-DATE.
           MOVE WK-CLOSE-YM        TO PL-CLOSE-YM.
           MOVE 2                  TO PL-KIND.
           MOVE WK-REF-PAY         TO PL-REF-TYPE.
           MOVE PY-NO              TO PL-REF-NO.
           MOVE PY-AMOUNT          TO PL-DEBIT.
           MOVE 0                  TO PL-CREDIT.
           MOVE WK-NEW-BAL         TO PL-BALANCE.
           MOVE PY-REMARK          TO PL-REMARK.
           MOVE WK-USER-CODE       TO PL-USER.
           WRITE PL-REC
               INVALID KEY
                   MOVE "Ledger write failed" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-WRITE.
       PLG-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE PAYF APLF SUPPF BANKF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "AP0010"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
