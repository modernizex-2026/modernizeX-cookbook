       IDENTIFICATION DIVISION.
       PROGRAM-ID. IV0040.
      *****************************************************************
      *  SYSTEM   : SAKURA Sales Management System                   *
      *  PROGRAM  : IV0040  -  Stock movement inquiry                 *
      *  FUNCTION : list the stock movement history for one product   *
      *             in date order using the SM-PROD + SM-DATE         *
      *             alternate key (START + READ NEXT).  Each line      *
      *             shows the movement date, a kind label, the signed *
      *             quantity, the balance after the movement and the  *
      *             source document reference.  Read-only inquiry;    *
      *             PF6 pages forward, PF4 re-keys, PF3 ends.         *
      *  AUTHOR   : SAKURA-SMS team                                  *
      *****************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. SAKURA-HOST.
       OBJECT-COMPUTER. SAKURA-HOST.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           COPY SSMOV.
           COPY SPROD.
       DATA DIVISION.
       FILE SECTION.
           COPY FSMOV.
           COPY FPROD.
       WORKING-STORAGE SECTION.
           COPY WCOMMON.
           COPY WMSG.
       01  WK-INQ.
           02  WK-KEY-PROD         PIC 9(8)  VALUE 0.
           02  WK-KEY-DATE         PIC 9(8)  VALUE 0.
           02  WK-PR-NAME          PIC X(40) VALUE SPACE.
           02  WK-KIND-LBL         PIC X(8)  VALUE SPACE.
           02  WK-ROW              PIC 9(2)  VALUE 0.
           02  WK-PAGE-NO          PIC 9(4)  VALUE 0.
           02  WK-TOT-IN           PIC S9(11) VALUE 0.
           02  WK-TOT-OUT          PIC S9(11) VALUE 0.
       01  WK-FLAGS.
           02  BRW-FLG             PIC 9(1)  VALUE 0.
             88  BRW-END                     VALUE 1.
           02  REC-FLG             PIC 9(1)  VALUE 0.
             88  REC-YES                     VALUE 1.
       01  WK-DL.
           02  WK-DL-DATE          PIC 9999/99/99.
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-DL-KIND          PIC X(8).
           02  FILLER              PIC X(1)  VALUE SPACE.
           02  WK-DL-QTY           PIC ---,---,--9.
           02  FILLER              PIC X(2)  VALUE SPACE.
           02  WK-DL-BAL           PIC ---,---,--9.
           02  FILLER              PIC X(2)  VALUE SPACE.
           02  WK-DL-RTYPE         PIC 9(2).
           02  FILLER              PIC X(1)  VALUE "-".
           02  WK-DL-RNO           PIC 9(10).
       01  WK-LIST-TABLE.
           02  WK-LIST OCCURS 12 TIMES PIC X(78).
           COPY KLINK.
      *----------------------------------------------------------------
       SCREEN SECTION.
           COPY GHEAD.
           COPY GFUNC.
           COPY GMSG.
       01  DS-KEY.
           02  LINE 4.
             03  COLUMN 2  VALUE "Product Code :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(8) USING WK-KEY-PROD.
           02  LINE 5.
             03  COLUMN 2  VALUE "From Date    :" COLOR YELLOW.
             03  COLUMN 20 PIC 9(8) USING WK-KEY-DATE.
             03  COLUMN 30 VALUE "(YYYYMMDD, 0=all)" COLOR CYAN.
       01  DS-LIST.
           02  LINE 3.
             03  COLUMN 2  VALUE "Product :" COLOR YELLOW.
             03  COLUMN 12 PIC 9(8) FROM WK-KEY-PROD COLOR WHITE.
             03  COLUMN 22 PIC X(40) FROM WK-PR-NAME COLOR WHITE.
           02  LINE 5 COLUMN 2
               VALUE "Date        Kind      Qty      BalAft  Ref"
               COLOR CYAN.
           02  LINE 7  COLUMN 2 PIC X(78) FROM WK-LIST (1) COLOR WHITE.
           02  LINE 8  COLUMN 2 PIC X(78) FROM WK-LIST (2) COLOR WHITE.
           02  LINE 9  COLUMN 2 PIC X(78) FROM WK-LIST (3) COLOR WHITE.
           02  LINE 10 COLUMN 2 PIC X(78) FROM WK-LIST (4) COLOR WHITE.
           02  LINE 11 COLUMN 2 PIC X(78) FROM WK-LIST (5) COLOR WHITE.
           02  LINE 12 COLUMN 2 PIC X(78) FROM WK-LIST (6) COLOR WHITE.
           02  LINE 13 COLUMN 2 PIC X(78) FROM WK-LIST (7) COLOR WHITE.
           02  LINE 14 COLUMN 2 PIC X(78) FROM WK-LIST (8) COLOR WHITE.
           02  LINE 15 COLUMN 2 PIC X(78) FROM WK-LIST (9) COLOR WHITE.
           02  LINE 16 COLUMN 2 PIC X(78) FROM WK-LIST (10) COLOR WHITE.
           02  LINE 17 COLUMN 2 PIC X(78) FROM WK-LIST (11) COLOR WHITE.
           02  LINE 18 COLUMN 2 PIC X(78) FROM WK-LIST (12) COLOR WHITE.
           02  LINE 20.
             03  COLUMN 2  VALUE "Page :" COLOR YELLOW.
             03  COLUMN 9  PIC ZZZ9 FROM WK-PAGE-NO COLOR WHITE.
           02  LINE 21.
             03  COLUMN 2  VALUE "Tot In :" COLOR YELLOW.
             03  COLUMN 11 PIC ---,---,--9 FROM WK-TOT-IN COLOR WHITE.
             03  COLUMN 26 VALUE "Tot Out:" COLOR YELLOW.
             03  COLUMN 35 PIC ---,---,--9 FROM WK-TOT-OUT COLOR WHITE.
      *----------------------------------------------------------------
       PROCEDURE DIVISION.
       MAIN SECTION.
       MAIN-000.
           PERFORM INIT-RTN.
           PERFORM MAIN-RTN UNTIL END-YES.
           PERFORM TERM-RTN.
           EXIT PROGRAM.
      *----------------------------------------------------------------
       INIT-RTN SECTION.
       INIT-010.
           MOVE "IV0040"           TO WK-PROGID.
           MOVE "Stock Movement Inquiry"         TO WK-TITLE.
           MOVE "ENTER/PF6=Next page PF4=New PF3=End"
                                   TO WK-FKEY-LINE.
           MOVE "TODY"             TO KD-FUNC.
           CALL "DATEUT" USING KDATE.
           MOVE KD-DATE1           TO WK-SYSYMD  WK-SYSDATE.
           PERFORM OPEN-FILES.
       INIT-999.
           EXIT.
      *----------------------------------------------------------------
       OPEN-FILES SECTION.
       OPENF-010.
           OPEN INPUT SMOVF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT SMOVF
               CLOSE SMOVF
               OPEN INPUT SMOVF
           END-IF.
           IF FSTS NOT = "00"
               MOVE "SMOVF"        TO KA-FILE
               PERFORM ABEND-RTN
           END-IF.
           OPEN INPUT PRODF.
           IF FSTS = "35" OR FSTS = "30"
               OPEN OUTPUT PRODF
               CLOSE PRODF
               OPEN INPUT PRODF
           END-IF.
       OPENF-999.
           EXIT.
      *----------------------------------------------------------------
       MAIN-RTN SECTION.
       MAIN-010.
           PERFORM GET-KEY.
           EVALUATE ESTS
               WHEN "03"
                   SET END-YES TO TRUE
               WHEN "00"
                   PERFORM PROCESS-KEY
               WHEN OTHER
                   MOVE "Invalid function key" TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       MAIN-999.
           EXIT.
      *----------------------------------------------------------------
       GET-KEY SECTION.
       GKEY-010.
           MOVE 0                  TO WK-KEY-PROD WK-KEY-DATE.
           MOVE SPACE              TO WK-PR-NAME.
           MOVE 0                  TO WK-PAGE-NO BRW-FLG.
           DISPLAY DS-HEADER.
           DISPLAY DS-FOOTER.
           MOVE "Enter product code then ENTER" TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-KEY.
           ACCEPT  DS-KEY.
       GKEY-999.
           EXIT.
      *----------------------------------------------------------------
       PROCESS-KEY SECTION.
       PKEY-010.
           IF WK-KEY-PROD = 0
               MOVE "Product code must not be zero" TO WK-MSG-LINE
               DISPLAY DS-MSG
               GO TO PKEY-999
           END-IF.
           PERFORM LOOKUP-PROD.
           PERFORM START-BROWSE.
           IF BRW-END
               GO TO PKEY-999
           END-IF.
           PERFORM BROWSE-LOOP UNTIL BRW-END.
       PKEY-999.
           EXIT.
      *----------------------------------------------------------------
       LOOKUP-PROD SECTION.
       LKPR-010.
           MOVE SPACE              TO WK-PR-NAME.
           MOVE WK-KEY-PROD        TO PR-CODE.
           READ PRODF
               INVALID KEY
                   MOVE "*** unknown product ***" TO WK-PR-NAME
               NOT INVALID KEY
                   MOVE PR-NAME    TO WK-PR-NAME
           END-READ.
       LKPR-999.
           EXIT.
      *----------------------------------------------------------------
       START-BROWSE SECTION.
       SBRW-010.
           MOVE 0                  TO BRW-FLG.
           MOVE 0                  TO WK-TOT-IN WK-TOT-OUT.
           MOVE WK-KEY-PROD        TO SM-PROD.
           MOVE WK-KEY-DATE        TO SM-DATE.
           START SMOVF KEY IS >= SM-PROD
               INVALID KEY
                   MOVE "No movements for that product"
                                   TO WK-MSG-LINE
                   DISPLAY DS-MSG
                   SET BRW-END TO TRUE
           END-START.
       SBRW-999.
           EXIT.
      *----------------------------------------------------------------
       BROWSE-LOOP SECTION.
       BLUP-010.
           PERFORM FILL-PAGE.
           IF WK-ROW = 0
               MOVE "End of movements - PF3/PF4" TO WK-MSG-LINE
               DISPLAY DS-MSG
               SET BRW-END TO TRUE
               GO TO BLUP-999
           END-IF.
           ADD 1                   TO WK-PAGE-NO.
           MOVE "ENTER/PF6=next page  PF3/PF4=re-key"
                                   TO WK-MSG-LINE.
           DISPLAY DS-MSG.
           DISPLAY DS-LIST.
           ACCEPT  DS-LIST.
           EVALUATE ESTS
               WHEN "03"
                   SET BRW-END TO TRUE
               WHEN "04"
                   SET BRW-END TO TRUE
               WHEN "00"
                   CONTINUE
               WHEN "06"
                   CONTINUE
               WHEN OTHER
                   MOVE "ENTER/PF6=next  PF3/PF4=re-key"
                                   TO WK-MSG-LINE
                   DISPLAY DS-MSG
           END-EVALUATE.
       BLUP-999.
           EXIT.
      *----------------------------------------------------------------
       FILL-PAGE SECTION.
       FPG-010.
           PERFORM CLEAR-LIST.
           MOVE 0                  TO WK-ROW.
           PERFORM UNTIL WK-ROW >= 12
               READ SMOVF NEXT
                   AT END
                       GO TO FPG-999
               END-READ
               IF FSTS NOT = "00"
                   GO TO FPG-999
               END-IF
               IF SM-PROD NOT = WK-KEY-PROD
                   GO TO FPG-999
               END-IF
               ADD 1               TO WK-ROW
               PERFORM FORMAT-LINE
           END-PERFORM.
       FPG-999.
           EXIT.
      *----------------------------------------------------------------
       CLEAR-LIST SECTION.
       CLST-010.
           PERFORM VARYING WK-IDX FROM 1 BY 1 UNTIL WK-IDX > 12
               MOVE SPACE          TO WK-LIST (WK-IDX)
           END-PERFORM.
       CLST-999.
           EXIT.
      *----------------------------------------------------------------
       FORMAT-LINE SECTION.
       FMT-010.
           PERFORM KIND-LABEL.
           MOVE SM-DATE            TO WK-DL-DATE.
           MOVE WK-KIND-LBL        TO WK-DL-KIND.
           MOVE SM-QTY             TO WK-DL-QTY.
           MOVE SM-BAL-AFTER       TO WK-DL-BAL.
           MOVE SM-REF-TYPE        TO WK-DL-RTYPE.
           MOVE SM-REF-NO          TO WK-DL-RNO.
           MOVE WK-DL              TO WK-LIST (WK-ROW).
           IF SM-QTY >= 0
               ADD SM-QTY          TO WK-TOT-IN
           ELSE
               SUBTRACT SM-QTY     FROM WK-TOT-OUT
           END-IF.
       FMT-999.
           EXIT.
      *----------------------------------------------------------------
       KIND-LABEL SECTION.
       KLB-010.
           EVALUATE SM-KIND
               WHEN 10
                   MOVE "SaleOut " TO WK-KIND-LBL
               WHEN 20
                   MOVE "PurchIn " TO WK-KIND-LBL
               WHEN 30
                   MOVE "Adjust  " TO WK-KIND-LBL
               WHEN 40
                   MOVE "Transfer" TO WK-KIND-LBL
               WHEN 50
                   MOVE "RetIn   " TO WK-KIND-LBL
               WHEN 60
                   MOVE "RetOut  " TO WK-KIND-LBL
               WHEN OTHER
                   MOVE "Other   " TO WK-KIND-LBL
           END-EVALUATE.
       KLB-999.
           EXIT.
      *----------------------------------------------------------------
       TERM-RTN SECTION.
       TERM-010.
           CLOSE SMOVF PRODF.
       TERM-999.
           EXIT.
      *----------------------------------------------------------------
       ABEND-RTN SECTION.
       ABEND-010.
           MOVE "IV0040"           TO KA-PROGID.
           MOVE FSTS               TO KA-FSTS.
           MOVE "EOPEN "           TO KA-MSGCODE.
           MOVE "File open error"  TO KA-DETAIL.
           CALL "ABORTX" USING KABEND.
           MOVE 255                TO COMPLETION-CODE.
           EXIT PROGRAM.
       ABEND-999.
           EXIT.
