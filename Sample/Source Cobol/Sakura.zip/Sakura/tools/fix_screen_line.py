#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEC COBOL85 requires every screen entry to have a LINE (its own, or inherited
from a parent group).  Our 2-level pattern
    02  LINE n COLUMN c VALUE "label"
    02  SC-x  COLUMN c2 PIC ... USING ...      <- no LINE  -> D3034
leaves the input field without a LINE.  This inserts  LINE <last>  before the
first COLUMN of any 02-level screen entry that has COLUMN but no LINE, using the
most recent LINE number seen in the same SCREEN SECTION.
Only touches files whose SCREEN SECTION is a real division header.
"""
import glob, os, re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
line_re = re.compile(r"\bLINE\s+(\d+)")

def is_code(l):
    return not (len(l) > 6 and l[6] in ("*", "/"))

def process(path):
    lines = open(path, encoding="utf-8", errors="replace").read().split("\n")
    inscr = False
    last_line = None
    changed = 0
    out = []
    for l in lines:
        raw = l.rstrip("\r")
        if is_code(raw):
            if re.match(r"\s*SCREEN\s+SECTION\.", raw):
                inscr = True
            elif re.match(r"\s*PROCEDURE\s+DIVISION", raw):
                inscr = False
            if inscr:
                m = line_re.search(raw)
                if m:
                    last_line = int(m.group(1))
                # 02-level entry with COLUMN but no LINE
                mm = re.match(r"(\s+)02\b", raw)
                if mm and "COLUMN" in raw and not line_re.search(raw) \
                   and last_line is not None:
                    raw = re.sub(r"\bCOLUMN\b",
                                 "LINE %d COLUMN" % last_line, raw, count=1)
                    changed += 1
        out.append(raw)
    if changed:
        open(path, "w", encoding="utf-8", newline="\r\n").write("\n".join(out))
    return changed

def main():
    tot = 0
    for d in ("main", "menu"):
        for p in sorted(glob.glob(os.path.join(ROOT, d, "*.cob"))):
            # only real screen programs
            txt = open(p, encoding="utf-8", errors="replace").read().split("\n")
            if not any(is_code(x) and re.match(r"\s*SCREEN\s+SECTION\.", x)
                       for x in txt):
                continue
            c = process(p)
            if c:
                tot += c
                print("  %-20s +%d LINE clauses" %
                      (os.path.relpath(p, ROOT), c))
    print("total LINE clauses inserted:", tot)

if __name__ == "__main__":
    main()
