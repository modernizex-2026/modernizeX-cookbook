#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
The screen end-status register ESTS (defined by SD ... END STATUS IS ESTS) is a
2-char ALPHANUMERIC field ("00","03",...). Our code compared it with numeric
literals (EVALUATE ESTS WHEN 3 / IF ESTS = 3) which compiles but never matches
at run time. This rewrites those comparisons to 2-char string literals, ONLY:
  * WHEN <n>  inside an  EVALUATE ESTS ... END-EVALUATE  block (depth-tracked,
    so nested EVALUATEs on other subjects are left alone), and
  * ESTS [NOT] = <n>  conditions anywhere.
Other EVALUATEs (WK-CHOICE, SM-KIND, status, ...) are untouched.
"""
import re, glob, os
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

def is_code(l):
    return not (len(l) > 6 and l[6] in ("*", "/"))

ests_cond = re.compile(r"(ESTS\s*(?:NOT\s*)?=\s*)(\d+)")
when_num  = re.compile(r"^(\s*WHEN\s+)(\d+)(\b)")
ev_ests   = re.compile(r"^\s*EVALUATE\s+ESTS\b")
ev_any    = re.compile(r"^\s*EVALUATE\b")
end_ev    = re.compile(r"\bEND-EVALUATE\b")

def conv_cond(l):
    return ests_cond.sub(lambda m: '%s"%02d"' % (m.group(1), int(m.group(2))), l)

def process(path):
    lines = open(path, encoding="utf-8").read().split("\n")
    inproc = False
    stack = []          # one bool per open EVALUATE: True if subject is ESTS
    changed = 0
    out = []
    for l in lines:
        raw = l.rstrip("\r")
        if is_code(raw):
            if re.match(r"\s*PROCEDURE\s+DIVISION", raw):
                inproc = True
            if inproc:
                # 1) ESTS = n  conditions (anywhere)
                nl = conv_cond(raw)
                if nl != raw:
                    changed += 1; raw = nl
                # 2) WHEN n inside EVALUATE ESTS
                if stack and stack[-1]:
                    m = when_num.match(raw)
                    if m:
                        raw = when_num.sub(
                            lambda mm: '%s"%02d"%s' %
                            (mm.group(1), int(mm.group(2)), mm.group(3)), raw)
                        changed += 1
                # 3) maintain EVALUATE stack (assume <=1 EVALUATE per line)
                if ev_ests.match(raw):
                    stack.append(True)
                elif ev_any.match(raw):
                    stack.append(False)
                if end_ev.search(raw) and stack:
                    stack.pop()
        out.append(raw)
    if changed:
        open(path, "w", encoding="utf-8", newline="\r\n").write("\n".join(out))
    return changed

def main():
    tot = 0; files = 0
    for d in ("main", "menu"):
        for p in sorted(glob.glob(os.path.join(ROOT, d, "*.cob"))):
            txt = open(p, encoding="utf-8").read()
            if "EVALUATE ESTS" not in txt and "ESTS =" not in txt \
               and "ESTS NOT" not in txt:
                continue
            c = process(p)
            if c:
                tot += c; files += 1
                print("  %-20s %d conversions" % (os.path.relpath(p, ROOT), c))
    print("ESTS string conversions: %d in %d files" % (tot, files))

if __name__ == "__main__":
    main()
