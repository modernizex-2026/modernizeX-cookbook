#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generate the MS SQL Server schema for SAKURA-SMS from the same authoritative
data model used for the copybooks (tools/gen_copybooks.py -> FILES).

DBLink note: NEC DBLink maps a COBOL field to a SQL column by its column TYPE.
For numeric columns it reads a *user-defined type* (UDT) whose name encodes the
COBOL usage, so COMP-3 / DISPLAY are represented faithfully (missing UDTs are
the root cause of the STS=39 / RE99 DBLink errors).  Convention used here:
    P3_i[_d]  = COMP-3 packed  S9(i)V9(d)   -> DECIMAL(i+d, d)
    D9_n[_d]  = DISPLAY numeric 9(n)[V9(d)] -> DECIMAL(n+d, d)
    alphanumeric X(n)                       -> CHAR(n)
Adjust the base types / names to match your site's DBLink kit if different.
"""
import os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
import gen_copybooks as G

OUT = os.path.join(os.path.dirname(__file__), "..", "sql")
os.makedirs(OUT, exist_ok=True)

def col(name):
    return name.replace("-", "_")

def parse_pic(pic):
    """return (kind, sqlbase, udt) ; kind in ('X','NUM')."""
    p = pic.upper()
    m = re.search(r"X\((\d+)\)", p)
    if m:
        return ("X", "CHAR(%d)" % int(m.group(1)), None)
    comp3 = "COMP-3" in p
    m = re.search(r"9\((\d+)\)(?:V9\((\d+)\))?", p)
    i = int(m.group(1)); d = int(m.group(2)) if m.group(2) else 0
    prec = i + d
    if comp3:
        udt = "P3_%d_%d" % (i, d) if d else "P3_%d" % i
    else:
        udt = "D9_%d_%d" % (i, d) if d else "D9_%d" % i
    return ("NUM", "DECIMAL(%d,%d)" % (prec, d), udt)

def flatten(fields):
    """yield (colname, pic) flattening OCCURS groups."""
    for f in fields:
        if len(f) == 3 and str(f[1]).startswith("OCCURS"):
            n = int(f[1].split()[1])
            for c in f[2]:
                for k in range(1, n + 1):
                    yield ("%s-%d" % (c[0], k), c[1])
        else:
            yield (f[0], f[1])

def main():
    udts = {}
    fil = 0
    tbl_lines = []
    idx_lines = []
    for f in G.FILES:
        cols = []
        filnum = 0
        for name, pic in flatten(f["fields"]):
            kind, base, udt = parse_pic(pic)
            if name == "FILLER":
                filnum += 1
                cname = "RSV_%d" % filnum
            else:
                cname = col(name)
            if kind == "NUM":
                udts[udt] = base
                coltype = udt
            else:
                coltype = base
            nn = "NOT NULL" if name != "FILLER" else "NULL"
            cols.append("    [%s] %s %s" % (cname, coltype, nn))
        pk = ", ".join("[%s]" % col(k) for k in f["rkey"])
        tbl_lines.append("CREATE TABLE [%s] (" % f["fd"])
        tbl_lines.append(",\n".join(cols) + ",")
        tbl_lines.append("    CONSTRAINT [PK_%s] PRIMARY KEY (%s)" % (f["fd"], pk))
        tbl_lines.append(");")
        tbl_lines.append("GO")
        tbl_lines.append("")
        # alternate keys -> indexes
        for n, (klist, dup) in enumerate(f["alts"], 1):
            uniq = "" if dup else "UNIQUE "
            kc = ", ".join("[%s]" % col(k) for k in klist)
            idx_lines.append("CREATE %sNONCLUSTERED INDEX [AK_%s_%d] ON [%s] (%s);"
                             % (uniq, f["fd"], n, f["fd"], kc))
        idx_lines.append("GO")

    with open(os.path.join(OUT, "00_database.sql"), "w", newline="\r\n") as fh:
        fh.write("-- SAKURA-SMS : create database\n")
        fh.write("IF DB_ID('SAKURA_SMS') IS NULL CREATE DATABASE [SAKURA_SMS];\n")
        fh.write("GO\nUSE [SAKURA_SMS];\nGO\n")

    with open(os.path.join(OUT, "01_types.sql"), "w", newline="\r\n") as fh:
        fh.write("-- SAKURA-SMS : DBLink user-defined types (COBOL usage map)\n")
        fh.write("USE [SAKURA_SMS];\nGO\n")
        for u in sorted(udts):
            fh.write("IF TYPE_ID('%s') IS NULL CREATE TYPE [%s] FROM %s;\n"
                     % (u, u, udts[u]))
        fh.write("GO\n")

    with open(os.path.join(OUT, "02_tables.sql"), "w", newline="\r\n") as fh:
        fh.write("-- SAKURA-SMS : tables (column order matches the COBOL record)\n")
        fh.write("USE [SAKURA_SMS];\nGO\n")
        fh.write("\n".join(tbl_lines))

    with open(os.path.join(OUT, "03_indexes.sql"), "w", newline="\r\n") as fh:
        fh.write("-- SAKURA-SMS : alternate-key indexes\n")
        fh.write("USE [SAKURA_SMS];\nGO\n")
        fh.write("\n".join(idx_lines) + "\n")

    print("tables : %d" % len(G.FILES))
    print("UDTs   : %d  (%s)" % (len(udts), ", ".join(sorted(udts))))
    print("indexes: %d" % sum(len(f["alts"]) for f in G.FILES))
    print("wrote sql/00_database.sql 01_types.sql 02_tables.sql 03_indexes.sql")

if __name__ == "__main__":
    main()
