#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SAKURA-SMS static sanity checker (no compiler required).

Checks every *.cob under copy/ sub/ main/ menu/ for:
  * source lines longer than 72 columns (fixed-format violation)
  * COPY <name> references that have no matching copy/<name>.cob
  * presence of PROGRAM-ID in program folders
  * tab characters (should be spaces in fixed format)
and prints a per-folder line-count summary and grand total LOC.
"""
import os, re, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC_DIRS = ["copy", "sub", "main", "menu"]
COPYDIR = os.path.join(ROOT, "copy")

copy_re = re.compile(r"^\s*COPY\s+([A-Z0-9][A-Z0-9-]*)\s*\.", re.IGNORECASE)
pid_re  = re.compile(r"PROGRAM-ID\.", re.IGNORECASE)

def available_copybooks():
    s = set()
    for f in os.listdir(COPYDIR):
        if f.lower().endswith(".cob"):
            s.add(os.path.splitext(f)[0].upper())
    return s

def main():
    copybooks = available_copybooks()
    long_lines = []
    tabs = []
    missing_copy = []
    no_pid = []
    totals = {}
    grand = 0
    for d in SRC_DIRS:
        dpath = os.path.join(ROOT, d)
        if not os.path.isdir(dpath):
            continue
        lc = 0
        for fn in sorted(os.listdir(dpath)):
            if not fn.lower().endswith(".cob"):
                continue
            path = os.path.join(dpath, fn)
            has_pid = False
            with open(path, "r", errors="replace") as fh:
                for i, line in enumerate(fh, 1):
                    line = line.rstrip("\n").rstrip("\r")
                    lc += 1
                    if len(line) > 72:
                        long_lines.append("%s/%s:%d (%d cols)" %
                                          (d, fn, i, len(line)))
                    if "\t" in line:
                        tabs.append("%s/%s:%d" % (d, fn, i))
                    if pid_re.search(line):
                        has_pid = True
                    m = copy_re.match(line)
                    if m:
                        nm = m.group(1).upper()
                        if nm not in copybooks:
                            missing_copy.append("%s/%s:%d COPY %s" %
                                                (d, fn, i, nm))
            if d in ("sub", "main", "menu") and not has_pid:
                no_pid.append("%s/%s" % (d, fn))
        totals[d] = lc
        grand += lc

    def section(title, items):
        print("\n== %s == (%d)" % (title, len(items)))
        for x in items[:40]:
            print("  " + x)
        if len(items) > 40:
            print("  ... and %d more" % (len(items) - 40))

    print("SAKURA-SMS static check")
    print("copybooks available:", len(copybooks))
    section("LINES > 72 COLUMNS", long_lines)
    section("TAB CHARACTERS", tabs)
    section("UNRESOLVED COPY", missing_copy)
    section("MISSING PROGRAM-ID", no_pid)
    print("\n== LINE COUNTS ==")
    for d in SRC_DIRS:
        if d in totals:
            print("  %-6s %6d" % (d, totals[d]))
    print("  %-6s %6d" % ("TOTAL", grand))
    problems = len(long_lines) + len(tabs) + len(missing_copy) + len(no_pid)
    print("\nPROBLEMS:", problems)
    sys.exit(1 if problems else 0)

if __name__ == "__main__":
    main()
