import re, subprocess, os, sys
BIN=r"C:\Program Files (x86)\Ocf21\cbl85pro\bin"
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),".."))
OBJ=os.path.join(ROOT,"build","obj"); os.makedirs(OBJ,exist_ok=True)
CP="/I"+os.path.join(ROOT,"copy")          # portable; derived from script location
os.environ["PATH"]=BIN+os.pathsep+os.environ["PATH"]
def compile_errs(path):
    scr=any(re.match(r"\s{0,7}SCREEN\s+SECTION\.",l) for l in open(path,encoding="utf-8",errors="replace"))
    flag="/Cweb" if scr else "/Ccon"
    r=subprocess.run(["cbl.exe","/c",flag,CP,os.path.abspath(path)],cwd=OBJ,
                     capture_output=True)
    out=r.stdout.decode("cp932","replace")
    errs=[]
    for l in out.splitlines():
        m=re.search(r"^\s*\d+\s+(\d+) F (J0054|J0201)",l)
        if m: errs.append((int(m.group(1)),m.group(2)))
    return errs
def fix(path):
    for _ in range(6):
        errs=compile_errs(path)
        if not errs: return True
        src=open(path,encoding="utf-8").read().split("\n")
        for tline,code in sorted(errs,reverse=True):
            i=tline-1
            if i>=len(src): continue
            line=src[i]; ind=" "*(len(line)-len(line.lstrip(" ")))
            if code=="J0201":
                m=re.match(r"\s*MOVE\s+LX\s+TO\s+(\S+)",line)
                if m:
                    y=m.group(1)
                    src[i:i+1]=[ind+"SET WK-IDX TO LX",
                                ind+"MOVE WK-IDX TO "+y]
            else:  # J0054
                m=re.match(r"\s*(WRITE|REWRITE|DELETE)\b",line)
                if m:
                    v=m.group(1)
                    src[i:i+1]=[line, ind+"    INVALID KEY CONTINUE",
                                ind+"END-"+v]
        open(path,"w",encoding="utf-8",newline="\r\n").write("\n".join(src))
    return not compile_errs(path)
for f in sys.argv[1:]:
    ok=fix(f); print(("OK  " if ok else "FAIL")+f)
