#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Deeper static analysis for SAKURA-SMS (no compiler).
Per program (COPY members inlined) it checks:
  1. PERFORM / GO TO targets resolve to a defined section/paragraph
  2. duplicate paragraph/section labels
  3. every COPY S<x> (SELECT) has a matching COPY F<x> (FD) and vice-versa
  4. scope-terminator balance (READ/END-READ, EVALUATE/END-EVALUATE,
     PERFORM..inline/END-PERFORM, STRING/END-STRING)
  5. data-name references in PROCEDURE that are not defined anywhere
     (own DATA DIVISION + inlined copybooks), reserved words filtered
"""
import glob, os, re, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
COPYDIR = os.path.join(ROOT, "copy")

COPYBOOKS = {}
for p in glob.glob(os.path.join(COPYDIR, "*.cob")):
    COPYBOOKS[os.path.splitext(os.path.basename(p))[0].upper()] = \
        open(p, encoding="utf-8", errors="replace").read().splitlines()

RESERVED = set("""ACCEPT ACCESS ADD ADVANCING AFTER ALL ALPHABET ALPHABETIC ALSO
ALTERNATE AND ANY APPLY ARE AREA ASCENDING ASSIGN AT AUTHOR BEFORE BLANK BLOCK
BORDER BY CALL CHARACTER CHARACTERS CLEAR CLOSE CODE COLUMN COMMA COMP COMP-3
COMPUTATIONAL COMPUTE CONFIGURATION CONSOLE CONTAINS CONTINUE CONTROL COPY
CORRESPONDING COUNT CURRENCY DATA DATE DAY DELETE DELIMITED DELIMITER DEPENDING
DESCENDING DISPLAY DIVIDE DIVISION DOWN DUPLICATES DYNAMIC ELSE END END-ACCEPT
END-ADD END-CALL END-COMPUTE END-DELETE END-DISPLAY END-DIVIDE END-EVALUATE
END-IF END-MULTIPLY END-PERFORM END-READ END-REWRITE END-SEARCH END-START
END-STRING END-SUBTRACT END-UNSTRING END-WRITE ENVIRONMENT EQUAL ERROR EVALUATE
EXCEPTION EXIT EXTEND FALSE FD FILE FILE-CONTROL FILLER FIRST FOR FROM FUNCTION
GIVING GO GOBACK GREATER HIGH-VALUE HIGH-VALUES I-O I-O-CONTROL IDENTIFICATION
IF IN INDEX INDEXED INITIAL INITIALIZE INPUT INPUT-OUTPUT INSPECT INTO INVALID
IS JUST JUSTIFIED KEY LABEL LEADING LEFT LENGTH LESS LINAGE LINE LINES LINKAGE
LOCK LOW-VALUE LOW-VALUES MODE MOVE MULTIPLY NATIVE NEGATIVE NEXT NO NOT NUMBER
NUMERIC OBJECT-COMPUTER OCCURS OF OFF OMITTED ON OPEN OPTIONAL OR ORGANIZATION
OUTPUT OVERFLOW PAGE PERFORM PIC PICTURE POINTER POSITION POSITIVE PROCEDURE
PROGRAM PROGRAM-ID QUOTE QUOTES RANDOM READ RECORD RECORDS REDEFINES REEL
REFERENCE RELATIVE REMAINDER REMOVAL RENAMES REPLACING RERUN RESERVE RETURN
RETURN-CODE REVERSE REVERSED REWIND REWRITE RIGHT ROUNDED RUN SAME SCREEN
SD SEARCH SECTION SECURE SELECT SENTENCE SEPARATE SEQUENCE SEQUENTIAL SET SHARED
SHARED-MODE SIGN SIZE SORT SOURCE-COMPUTER SPACE SPACES SPECIAL-NAMES STANDARD
START STATUS STOP STRING SUBTRACT SYNC SYNCHRONIZED TALLYING TERMINAL TEST THAN
THEN THROUGH THRU TIME TIMES TO TRUE UNTIL UP UPON USAGE USE USING VALUE VALUES
VARYING WHEN WITH WORKING-STORAGE WRITE ZERO ZEROES ZEROS COMPLETION-CODE
HIGHT WIDTH PARENT WINDOW END-EVALUATE THRU IFC CHECK COMPUTATIONAL-3 REPORT""".split())

label_def_re = re.compile(r"^ {0,10}([A-Z0-9][A-Z0-9-]*)(\s+SECTION)?\s*\.\s*$")
level_re = re.compile(r"^\s*(?:\d\d)\s+([A-Z0-9][A-Z0-9-]*)")
fd_re    = re.compile(r"^\s*(?:FD|SD)\s+([A-Z0-9][A-Z0-9-]*)")
select_re= re.compile(r"\bSELECT\s+([A-Z0-9][A-Z0-9-]*)")
idxby_re = re.compile(r"\bINDEXED\s+BY\s+([A-Z0-9][A-Z0-9-]*)")
copy_re  = re.compile(r"^\s*COPY\s+([A-Z0-9][A-Z0-9-]*)\s*\.", re.I)
perform_re = re.compile(r"\bPERFORM\s+([A-Z0-9][A-Z0-9-]*)")
thru_re    = re.compile(r"\b(?:THRU|THROUGH)\s+([A-Z0-9][A-Z0-9-]*)")
goto_re    = re.compile(r"\bGO\s+TO\s+([A-Z0-9][A-Z0-9-]*)")
token_re   = re.compile(r"[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+")   # hyphenated names

PERFORM_NONTARGET = {"UNTIL","VARYING","WITH","TEST","FOREVER"}

def expand(lines):
    out = []
    for ln in lines:
        m = copy_re.match(ln)
        if m and m.group(1).upper() in COPYBOOKS:
            out.extend(COPYBOOKS[m.group(1).upper()])
        else:
            out.append(ln)
    return out

def code_part(line):
    # strip sequence cols 1-6 not present (blank); drop comment lines (col7 '*')
    if len(line) > 6 and line[6] in ("*", "/"):
        return ""
    return line

def analyze(path):
    raw = open(path, encoding="utf-8", errors="replace").read().splitlines()
    lines = expand(raw)
    problems = []
    # split at PROCEDURE DIVISION
    proc_idx = None
    for i, ln in enumerate(lines):
        if re.match(r"^\s*PROCEDURE\s+DIVISION", ln):
            proc_idx = i; break
    data_lines = lines[:proc_idx] if proc_idx is not None else lines
    proc_lines = lines[proc_idx:] if proc_idx is not None else []

    # defined data names (data div + copybooks already inlined)
    defined = set()
    for ln in data_lines:
        c = code_part(ln)
        if not c: continue
        for rgx in (level_re, fd_re, idxby_re):
            m = rgx.match(c) if rgx in (level_re, fd_re) else None
            if m: defined.add(m.group(1).upper())
        m = idxby_re.search(c)
        if m: defined.add(m.group(1).upper())
        m = select_re.search(c)
        if m: defined.add(m.group(1).upper())
    # labels + duplicate detection
    labels = {}
    dups = []
    for ln in proc_lines:
        c = code_part(ln)
        if not c: continue
        if re.match(r"^\s*(PROCEDURE|MAIN)\s+", c) and "DIVISION" in c:
            continue
        m = label_def_re.match(c)
        if m:
            nm = m.group(1).upper()
            if nm in ("EXIT","CONTINUE","STOP","GOBACK"):
                continue
            labels[nm] = labels.get(nm, 0) + 1
    for nm, ct in labels.items():
        if ct > 1: dups.append(nm)
    labelset = set(labels)

    # perform / goto targets
    for ln in proc_lines:
        c = code_part(ln)
        if not c: continue
        for m in perform_re.finditer(c):
            t = m.group(1).upper()
            if t in PERFORM_NONTARGET: continue
            if t not in labelset:
                problems.append(("PERFORM-target", t))
        for m in thru_re.finditer(c):
            t = m.group(1).upper()
            if t not in labelset:
                problems.append(("THRU-target", t))
        for m in goto_re.finditer(c):
            t = m.group(1).upper()
            if t not in labelset:
                problems.append(("GOTO-target", t))

    # scope-terminator balance (rough)
    text = "\n".join(code_part(l) for l in proc_lines)
    bal = []
    for verb, end in (("EVALUATE","END-EVALUATE"), ("READ","END-READ"),
                      ("STRING","END-STRING")):
        o = len(re.findall(r"(?<![A-Z-])"+verb+r"\b", text))
        c = len(re.findall(r"\b"+end+r"\b", text))
        # only flag when explicit terminators are used but unbalanced
        if end == "END-EVALUATE" and o != c:
            bal.append("%s=%d %s=%d" % (verb,o,end,c))

    # SELECT/FD copybook pairing
    copies = [m.group(1).upper() for ln in raw for m in [copy_re.match(ln)] if m]
    sels = set(x[1:] for x in copies if x.startswith("S") and ("F"+x[1:]) in COPYBOOKS)
    fds  = set(x[1:] for x in copies if x.startswith("F") and ("S"+x[1:]) in COPYBOOKS)
    only_s = sels - fds
    only_f = fds - sels

    # data-name references not defined (filtered)
    undef = {}
    for ln in proc_lines:
        c = code_part(ln)
        if not c: continue
        # skip literals
        c2 = re.sub(r'"[^"]*"', " ", c)
        for tok in token_re.findall(c2):
            t = tok.upper()
            if t in RESERVED or t in defined or t in labelset: continue
            if t.startswith("END-"): continue
            undef[t] = undef.get(t, 0) + 1
    return dict(problems=problems, dups=dups, bal=bal,
                only_s=sorted(only_s), only_f=sorted(only_f), undef=undef)

def main():
    files = sorted(glob.glob(os.path.join(ROOT,"main","*.cob")) +
                   glob.glob(os.path.join(ROOT,"menu","*.cob")) +
                   glob.glob(os.path.join(ROOT,"sub","*.cob")))
    total_issues = 0
    undef_global = {}
    for f in files:
        r = analyze(f)
        name = os.path.relpath(f, ROOT)
        msgs = []
        if r["problems"]:
            for kind,t in r["problems"]:
                msgs.append("  %s -> %s (undefined)" % (kind, t))
        if r["dups"]:
            msgs.append("  duplicate labels: " + ", ".join(r["dups"]))
        if r["bal"]:
            msgs.append("  scope imbalance: " + "; ".join(r["bal"]))
        if r["only_s"]:
            msgs.append("  SELECT without FD copy: " + ",".join(r["only_s"]))
        if r["only_f"]:
            msgs.append("  FD without SELECT copy: " + ",".join(r["only_f"]))
        if msgs:
            total_issues += len(msgs)
            print("\n### %s" % name)
            print("\n".join(msgs))
        for t,c in r["undef"].items():
            undef_global[t] = undef_global.get(t,0)+c
    print("\n==== undefined hyphenated tokens (possible bad field names) ====")
    if undef_global:
        for t,c in sorted(undef_global.items(), key=lambda x:-x[1]):
            print("  %-24s x%d" % (t,c))
    else:
        print("  none")
    print("\nSTRUCTURAL ISSUES:", total_issues)

if __name__ == "__main__":
    main()
