#!/bin/sh
# Compile-check every SAKURA-SMS program with NEC COBOL85 (cbl.exe).
# Portable: derives all paths from this script's own location (handles a
# project path that contains spaces).  Screen -> /Cweb, others -> /Ccon.
export PATH="/c/Program Files (x86)/Ocf21/cbl85pro/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WINCOPY="$(cygpath -w "$ROOT/copy" 2>/dev/null || echo "$ROOT/copy")"
CP="/I$WINCOPY"
mkdir -p "$ROOT/build/obj"; cd "$ROOT/build/obj" || exit 1
LOG="$ROOT/build/compile.log"; : > "$LOG"
compile_one() {
    f="$1"; flags="$2"; n=$(basename "$f")
    src="$(cygpath -w "$f" 2>/dev/null || echo "$f")"
    out=$(cbl.exe /c $flags "$CP" "$src" 2>&1 | iconv -f CP932 -t UTF-8 2>/dev/null)
    fc=$(printf '%s' "$out" | grep -oE '[0-9]+  FATAL' | grep -oE '^[0-9]+' | head -1)
    [ -z "$fc" ] && fc=999
    { echo "########## $n  (FATAL=$fc) ##########"
      printf '%s\n' "$out" | grep -E "^ +[0-9]+ .* F [A-Z]"; } >> "$LOG"
    case "$fc" in 0|00000) : ;; *) echo "  FAIL $n (fatal=$fc)" ;; esac
}
for f in "$ROOT"/sub/*.cob; do compile_one "$f" ""; done
for f in "$ROOT"/main/*.cob "$ROOT"/menu/*.cob; do
    if grep -qE "^ {0,7}SCREEN +SECTION\." "$f"; then compile_one "$f" "/Cweb"
    else compile_one "$f" "/Ccon"; fi
done
echo "CLEAN: $(grep -c 'FATAL=00000' "$LOG")/$(grep -c '##########' "$LOG")"
rm -f "$ROOT"/build/obj/*.obj "$ROOT"/build/obj/*.res "$ROOT"/build/obj/*.exe 2>/dev/null
