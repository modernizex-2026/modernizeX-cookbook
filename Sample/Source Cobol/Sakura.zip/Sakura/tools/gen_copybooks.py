#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SAKURA-SMS copybook generator.
Emits fixed-format NEC COBOL85 FD-layout copybooks (F*.cob) and
SELECT copybooks (S*.cob) into ../copy from the authoritative data model
defined below (mirrors docs/SPEC.md section 4).

Fixed format: seq area (1-6) blank, indicator col 7, Area A col 8, Area B col 12.
"""
import os

COPYDIR = os.path.join(os.path.dirname(__file__), "..", "copy")

# device suffix for the ASSIGN assignment-name:
#   RDB = NEC DBLink -> SQL Server (numeric + composite keys OK)
#   MSD = local ISAM  (keys must be alphanumeric/single)
import sys as _sys
DEVICE = "MSD" if "--isam" in _sys.argv else "RDB"

# ------------------------------------------------------------------ helpers
def fld(name, pic):
    return (name, pic)

def grp(name, occurs, children):
    return (name, "OCCURS %d" % occurs, children)

def emit_field(f, indent=11, level="02"):
    """Render one 02/03 field (simple or occurs-group) as fixed-format lines."""
    lines = []
    pad = " " * indent
    if len(f) == 3 and str(f[1]).startswith("OCCURS"):
        name, occ, children = f
        lines.append("%s%s  %-20s%s." % (pad, level, name, occ))
        for c in children:
            lines.append("%s  03  %-18s%s." %
                         (pad, c[0], c[1]))
    else:
        name, pic = f
        lines.append("%s%s  %-20s%s." % (pad, level, name, pic))
    return lines

def key_clause(keyword, fields, dup=False):
    """Emit a (multi-component) RECORD KEY / ALTERNATE RECORD KEY clause,
    aligned under the SELECT block (text col 20, key field col 42)."""
    lead = " " * 19
    out = ["%s%-20s  %s" % (lead, keyword, fields[0])]
    contpad = " " * (19 + 20 + 2)
    for k in fields[1:]:
        out.append("%s%s" % (contpad, k))
    if dup:
        out[-1] = out[-1] + "  WITH DUPLICATES"
    return out

# ------------------------------------------------------------------ model
# each file: (fdname, copyF, copyS, title, recname,
#             recordkey(list), altkeys(list of (list,dup)), fields[])
FILES = []

def add(fd, cf, cs, title, rec, rkey, alts, fields):
    FILES.append(dict(fd=fd, cf=cf, cs=cs, title=title, rec=rec,
                      rkey=rkey, alts=alts, fields=fields))

AUDIT = [fld("%s-ADD-DATE", "PIC 9(8)"), fld("%s-ADD-USER", "PIC 9(6)"),
         fld("%s-UPD-DATE", "PIC 9(8)"), fld("%s-UPD-USER", "PIC 9(6)")]

# ---- 4.1 Customer
add("CUSTF", "FCUST", "SCUST", "Customer master", "CU-REC",
    ["CU-CODE"],
    [(["CU-NAME"], True), (["CU-REGION", "CU-CODE"], False)],
    [fld("CU-CODE","PIC 9(6)"), fld("CU-NAME","PIC X(40)"),
     fld("CU-KANA","PIC X(40)"), fld("CU-ZIP","PIC X(8)"),
     fld("CU-ADDR1","PIC X(40)"), fld("CU-ADDR2","PIC X(40)"),
     fld("CU-TEL","PIC X(15)"), fld("CU-FAX","PIC X(15)"),
     fld("CU-REGION","PIC 9(3)"), fld("CU-STAFF","PIC 9(4)"),
     fld("CU-CLOSE-DAY","PIC 9(2)"), fld("CU-PAY-MONTH","PIC 9(1)"),
     fld("CU-PAY-DAY","PIC 9(2)"), fld("CU-PAY-METHOD","PIC 9(1)"),
     fld("CU-TAX-TYPE","PIC 9(1)"), fld("CU-TAX-ROUND","PIC 9(1)"),
     fld("CU-CREDIT-LIMIT","PIC S9(11) COMP-3"),
     fld("CU-BALANCE","PIC S9(11) COMP-3"),
     fld("CU-PRICE-RANK","PIC 9(1)"), fld("CU-BANK-CODE","PIC 9(4)"),
     fld("CU-BANK-ACCT","PIC X(20)"), fld("CU-START-DATE","PIC 9(8)"),
     fld("CU-ADD-DATE","PIC 9(8)"), fld("CU-ADD-USER","PIC 9(6)"),
     fld("CU-UPD-DATE","PIC 9(8)"), fld("CU-UPD-USER","PIC 9(6)"),
     fld("CU-DEL-FLAG","PIC 9(1)"), fld("FILLER","PIC X(20)")])

# ---- 4.2 Supplier
add("SUPPF", "FSUPP", "SSUPP", "Supplier master", "SP-REC",
    ["SP-CODE"], [(["SP-NAME"], True)],
    [fld("SP-CODE","PIC 9(6)"), fld("SP-NAME","PIC X(40)"),
     fld("SP-KANA","PIC X(40)"), fld("SP-ZIP","PIC X(8)"),
     fld("SP-ADDR1","PIC X(40)"), fld("SP-ADDR2","PIC X(40)"),
     fld("SP-TEL","PIC X(15)"), fld("SP-FAX","PIC X(15)"),
     fld("SP-CLOSE-DAY","PIC 9(2)"), fld("SP-PAY-MONTH","PIC 9(1)"),
     fld("SP-PAY-DAY","PIC 9(2)"), fld("SP-PAY-METHOD","PIC 9(1)"),
     fld("SP-TAX-TYPE","PIC 9(1)"),
     fld("SP-BALANCE","PIC S9(11) COMP-3"),
     fld("SP-BANK-CODE","PIC 9(4)"), fld("SP-BANK-ACCT","PIC X(20)"),
     fld("SP-ADD-DATE","PIC 9(8)"), fld("SP-ADD-USER","PIC 9(6)"),
     fld("SP-UPD-DATE","PIC 9(8)"), fld("SP-UPD-USER","PIC 9(6)"),
     fld("SP-DEL-FLAG","PIC 9(1)"), fld("FILLER","PIC X(20)")])

# ---- 4.3 Product
add("PRODF", "FPROD", "SPROD", "Product master", "PR-REC",
    ["PR-CODE"],
    [(["PR-NAME"], True), (["PR-CATEGORY","PR-CODE"], False),
     (["PR-BARCODE"], True)],
    [fld("PR-CODE","PIC 9(8)"), fld("PR-NAME","PIC X(40)"),
     fld("PR-KANA","PIC X(40)"), fld("PR-SPEC","PIC X(30)"),
     fld("PR-CATEGORY","PIC 9(4)"), fld("PR-BARCODE","PIC X(13)"),
     fld("PR-UNIT","PIC X(6)"),
     fld("PR-STD-COST","PIC S9(9)V9(2) COMP-3"),
     fld("PR-LAST-COST","PIC S9(9)V9(2) COMP-3"),
     fld("PR-LIST-PRICE","PIC S9(9)V9(2) COMP-3"),
     grp("PR-PRICE-TBL", 5, [fld("PR-RANK-PRICE","PIC S9(9)V9(2) COMP-3")]),
     fld("PR-TAX-CATEGORY","PIC 9(1)"),
     fld("PR-SAFETY-STOCK","PIC S9(9) COMP-3"),
     fld("PR-REORDER-POINT","PIC S9(9) COMP-3"),
     fld("PR-REORDER-QTY","PIC S9(9) COMP-3"),
     fld("PR-LEAD-DAYS","PIC 9(3)"), fld("PR-DFLT-SUPP","PIC 9(6)"),
     fld("PR-DFLT-WHSE","PIC 9(3)"), fld("PR-STOCK-MNG","PIC 9(1)"),
     fld("PR-ADD-DATE","PIC 9(8)"), fld("PR-ADD-USER","PIC 9(6)"),
     fld("PR-UPD-DATE","PIC 9(8)"), fld("PR-UPD-USER","PIC 9(6)"),
     fld("PR-DEL-FLAG","PIC 9(1)"), fld("FILLER","PIC X(20)")])

# ---- 4.4 Warehouse
add("WHSEF", "FWHSE", "SWHSE", "Warehouse master", "WH-REC",
    ["WH-CODE"], [],
    [fld("WH-CODE","PIC 9(3)"), fld("WH-NAME","PIC X(30)"),
     fld("WH-ZIP","PIC X(8)"), fld("WH-ADDR","PIC X(40)"),
     fld("WH-TEL","PIC X(15)"), fld("WH-TYPE","PIC 9(1)"),
     fld("WH-MANAGER","PIC 9(4)"), fld("WH-DEL-FLAG","PIC 9(1)"),
     fld("FILLER","PIC X(20)")])

# ---- 4.5 Staff
add("STAFF", "FSTAF", "SSTAF", "Staff master", "SF-REC",
    ["SF-CODE"], [(["SF-DEPT","SF-CODE"], False)],
    [fld("SF-CODE","PIC 9(4)"), fld("SF-NAME","PIC X(30)"),
     fld("SF-KANA","PIC X(30)"), fld("SF-DEPT","PIC 9(4)"),
     fld("SF-TEL","PIC X(15)"), fld("SF-EMAIL","PIC X(40)"),
     fld("SF-TITLE","PIC X(20)"), fld("SF-DEL-FLAG","PIC 9(1)"),
     fld("FILLER","PIC X(20)")])

# ---- 4.6 Category
add("CATGF", "FCATG", "SCATG", "Category master", "CT-REC",
    ["CT-CODE"], [],
    [fld("CT-CODE","PIC 9(4)"), fld("CT-NAME","PIC X(30)"),
     fld("CT-PARENT","PIC 9(4)"), fld("CT-LEVEL","PIC 9(1)"),
     fld("CT-DEL-FLAG","PIC 9(1)"), fld("FILLER","PIC X(20)")])

# ---- 4.7 Customer price
add("CPRCF", "FCPRC", "SCPRC", "Customer price master", "CP-REC",
    ["CP-CUST","CP-PROD"], [],
    [fld("CP-CUST","PIC 9(6)"), fld("CP-PROD","PIC 9(8)"),
     fld("CP-PRICE","PIC S9(9)V9(2) COMP-3"),
     fld("CP-START-DATE","PIC 9(8)"), fld("CP-END-DATE","PIC 9(8)"),
     fld("CP-DEL-FLAG","PIC 9(1)"), fld("FILLER","PIC X(10)")])

# ---- 4.8 Department
add("DEPTF", "FDEPT", "SDEPT", "Department master", "DP-REC",
    ["DP-CODE"], [],
    [fld("DP-CODE","PIC 9(4)"), fld("DP-NAME","PIC X(30)"),
     fld("DP-PARENT","PIC 9(4)"), fld("DP-DEL-FLAG","PIC 9(1)"),
     fld("FILLER","PIC X(20)")])

# ---- 4.9 Tax
add("TAXF", "FTAX", "STAX", "Tax rate master", "TX-REC",
    ["TX-CODE","TX-START-DATE"], [],
    [fld("TX-CODE","PIC 9(1)"), fld("TX-START-DATE","PIC 9(8)"),
     fld("TX-RATE","PIC S9(2)V9(3) COMP-3"), fld("TX-NAME","PIC X(20)"),
     fld("FILLER","PIC X(10)")])

# ---- 4.10 Bank
add("BANKF", "FBANK", "SBANK", "Bank master", "BK-REC",
    ["BK-CODE"], [],
    [fld("BK-CODE","PIC 9(4)"), fld("BK-NAME","PIC X(30)"),
     fld("BK-BRANCH","PIC X(30)"), fld("BK-DEL-FLAG","PIC 9(1)"),
     fld("FILLER","PIC X(20)")])

# ---- 4.11 Region
add("REGNF", "FREGN", "SREGN", "Region master", "RG-REC",
    ["RG-CODE"], [],
    [fld("RG-CODE","PIC 9(3)"), fld("RG-NAME","PIC X(30)"),
     fld("RG-DEL-FLAG","PIC 9(1)"), fld("FILLER","PIC X(20)")])

# ---- 4.12 User
add("USERF", "FUSER", "SUSER", "User master", "US-REC",
    ["US-CODE"], [(["US-LOGIN"], False)],
    [fld("US-CODE","PIC 9(6)"), fld("US-LOGIN","PIC X(12)"),
     fld("US-PASSWORD","PIC X(16)"), fld("US-NAME","PIC X(30)"),
     fld("US-ROLE","PIC 9(1)"), fld("US-AUTH-MASTER","PIC 9(1)"),
     fld("US-AUTH-ORDER","PIC 9(1)"), fld("US-AUTH-SALES","PIC 9(1)"),
     fld("US-AUTH-PURCH","PIC 9(1)"), fld("US-AUTH-CLOSE","PIC 9(1)"),
     fld("US-LAST-LOGIN","PIC 9(8)"), fld("US-DEL-FLAG","PIC 9(1)"),
     fld("FILLER","PIC X(20)")])

# ---- 4.13 Message
add("MSGF", "FMSG", "SMSG", "Message master", "MG-REC",
    ["MG-CODE"], [],
    [fld("MG-CODE","PIC X(6)"), fld("MG-TEXT","PIC X(60)"),
     fld("FILLER","PIC X(10)")])

# ---- 4.14 System control
add("SYSCF", "FSYSC", "SSYSC", "System control", "SY-REC",
    ["SY-KEY"], [],
    [fld("SY-KEY","PIC 9(1)"), fld("SY-COMPANY-NAME","PIC X(40)"),
     fld("SY-COMPANY-ZIP","PIC X(8)"), fld("SY-COMPANY-ADDR","PIC X(40)"),
     fld("SY-COMPANY-TEL","PIC X(15)"), fld("SY-FISCAL-START","PIC 9(2)"),
     fld("SY-CURR-YM","PIC 9(6)"), fld("SY-LAST-DAY-CLOSE","PIC 9(8)"),
     fld("SY-LAST-MON-CLOSE","PIC 9(6)"),
     fld("SY-TAX-DFLT-RATE","PIC S9(2)V9(3) COMP-3"),
     fld("SY-DEC-ROUND","PIC 9(1)"), fld("FILLER","PIC X(30)")])

# ---- 4.15 Number control
add("NUMCF", "FNUMC", "SNUMC", "Number control", "NM-REC",
    ["NM-KEY"], [],
    [fld("NM-KEY","PIC X(8)"), fld("NM-PREFIX","PIC X(2)"),
     fld("NM-CURRENT","PIC 9(10)"), fld("NM-WIDTH","PIC 9(2)"),
     fld("FILLER","PIC X(10)")])

# ---- 4.16 Stock balance
add("STOKF", "FSTOK", "SSTOK", "Stock balance", "SK-REC",
    ["SK-PROD","SK-WHSE"], [(["SK-WHSE","SK-PROD"], False)],
    [fld("SK-PROD","PIC 9(8)"), fld("SK-WHSE","PIC 9(3)"),
     fld("SK-ONHAND","PIC S9(9) COMP-3"),
     fld("SK-ALLOCATED","PIC S9(9) COMP-3"),
     fld("SK-ON-ORDER","PIC S9(9) COMP-3"),
     fld("SK-AVG-COST","PIC S9(9)V9(2) COMP-3"),
     fld("SK-LAST-IN-DATE","PIC 9(8)"), fld("SK-LAST-OUT-DATE","PIC 9(8)"),
     fld("SK-YTD-IN","PIC S9(11) COMP-3"),
     fld("SK-YTD-OUT","PIC S9(11) COMP-3"),
     fld("SK-LOCATION","PIC X(10)"), fld("FILLER","PIC X(10)")])

# ---- 4.17 Stock movement
add("SMOVF", "FSMOV", "SSMOV", "Stock movement history", "SM-REC",
    ["SM-SEQ"], [(["SM-PROD","SM-DATE"], True)],
    [fld("SM-SEQ","PIC 9(10)"), fld("SM-DATE","PIC 9(8)"),
     fld("SM-PROD","PIC 9(8)"), fld("SM-WHSE","PIC 9(3)"),
     fld("SM-KIND","PIC 9(2)"), fld("SM-QTY","PIC S9(9) COMP-3"),
     fld("SM-UNIT-COST","PIC S9(9)V9(2) COMP-3"),
     fld("SM-BAL-AFTER","PIC S9(9) COMP-3"),
     fld("SM-REF-TYPE","PIC 9(2)"), fld("SM-REF-NO","PIC 9(10)"),
     fld("SM-USER","PIC 9(6)"), fld("FILLER","PIC X(10)")])

# ---- 4.18 Order header/detail
add("ORDHF", "FORDH", "SORDH", "Sales order header", "OH-REC",
    ["OH-NO"], [(["OH-CUST","OH-DATE"], True), (["OH-DATE","OH-NO"], False)],
    [fld("OH-NO","PIC 9(10)"), fld("OH-DATE","PIC 9(8)"),
     fld("OH-CUST","PIC 9(6)"), fld("OH-STAFF","PIC 9(4)"),
     fld("OH-WHSE","PIC 9(3)"), fld("OH-DUE-DATE","PIC 9(8)"),
     fld("OH-CUST-PO","PIC X(20)"), fld("OH-TAX-TYPE","PIC 9(1)"),
     fld("OH-AMOUNT","PIC S9(11) COMP-3"),
     fld("OH-TAX-AMOUNT","PIC S9(11) COMP-3"),
     fld("OH-TOTAL","PIC S9(11) COMP-3"), fld("OH-STATUS","PIC 9(1)"),
     fld("OH-LINES","PIC 9(3)"), fld("OH-REMARK","PIC X(40)"),
     fld("OH-ADD-DATE","PIC 9(8)"), fld("OH-ADD-USER","PIC 9(6)"),
     fld("OH-UPD-DATE","PIC 9(8)"), fld("OH-UPD-USER","PIC 9(6)"),
     fld("OH-DEL-FLAG","PIC 9(1)"), fld("FILLER","PIC X(20)")])

add("ORDDF", "FORDD", "SORDD", "Sales order detail", "OD-REC",
    ["OD-NO","OD-LINE"], [],
    [fld("OD-NO","PIC 9(10)"), fld("OD-LINE","PIC 9(3)"),
     fld("OD-PROD","PIC 9(8)"), fld("OD-WHSE","PIC 9(3)"),
     fld("OD-QTY","PIC S9(9) COMP-3"),
     fld("OD-UNIT-PRICE","PIC S9(9)V9(2) COMP-3"),
     fld("OD-AMOUNT","PIC S9(11) COMP-3"),
     fld("OD-TAX-CATEGORY","PIC 9(1)"),
     fld("OD-SHIPPED-QTY","PIC S9(9) COMP-3"),
     fld("OD-ALLOC-QTY","PIC S9(9) COMP-3"),
     fld("OD-DUE-DATE","PIC 9(8)"), fld("OD-STATUS","PIC 9(1)"),
     fld("OD-REMARK","PIC X(30)"), fld("FILLER","PIC X(10)")])

# ---- 4.19 Shipment header/detail
add("SHPHF", "FSHPH", "SSHPH", "Shipment header", "XH-REC",
    ["XH-NO"], [(["XH-ORDER"], True), (["XH-DATE","XH-NO"], False)],
    [fld("XH-NO","PIC 9(10)"), fld("XH-DATE","PIC 9(8)"),
     fld("XH-ORDER","PIC 9(10)"), fld("XH-CUST","PIC 9(6)"),
     fld("XH-WHSE","PIC 9(3)"), fld("XH-STAFF","PIC 9(4)"),
     fld("XH-STATUS","PIC 9(1)"), fld("XH-LINES","PIC 9(3)"),
     fld("XH-REMARK","PIC X(40)"), fld("XH-ADD-DATE","PIC 9(8)"),
     fld("XH-ADD-USER","PIC 9(6)"), fld("XH-DEL-FLAG","PIC 9(1)"),
     fld("FILLER","PIC X(20)")])

add("SHPDF", "FSHPD", "SSHPD", "Shipment detail", "XD-REC",
    ["XD-NO","XD-LINE"], [],
    [fld("XD-NO","PIC 9(10)"), fld("XD-LINE","PIC 9(3)"),
     fld("XD-ORDER","PIC 9(10)"), fld("XD-ORDER-LINE","PIC 9(3)"),
     fld("XD-PROD","PIC 9(8)"), fld("XD-WHSE","PIC 9(3)"),
     fld("XD-QTY","PIC S9(9) COMP-3"),
     fld("XD-UNIT-PRICE","PIC S9(9)V9(2) COMP-3"),
     fld("XD-AMOUNT","PIC S9(11) COMP-3"),
     fld("XD-UNIT-COST","PIC S9(9)V9(2) COMP-3"),
     fld("FILLER","PIC X(10)")])

# ---- 4.20 Invoice header/detail
add("INVHF", "FINVH", "SINVH", "Sales invoice header", "IH-REC",
    ["IH-NO"], [(["IH-CUST","IH-DATE"], True), (["IH-DATE","IH-NO"], False)],
    [fld("IH-NO","PIC 9(10)"), fld("IH-DATE","PIC 9(8)"),
     fld("IH-CUST","PIC 9(6)"), fld("IH-STAFF","PIC 9(4)"),
     fld("IH-SHIP-NO","PIC 9(10)"), fld("IH-CLOSE-YM","PIC 9(6)"),
     fld("IH-TAX-TYPE","PIC 9(1)"),
     fld("IH-AMOUNT","PIC S9(11) COMP-3"),
     fld("IH-TAX-AMOUNT","PIC S9(11) COMP-3"),
     fld("IH-TOTAL","PIC S9(11) COMP-3"),
     fld("IH-COST-TOTAL","PIC S9(11) COMP-3"),
     fld("IH-STATUS","PIC 9(1)"), fld("IH-KIND","PIC 9(1)"),
     fld("IH-LINES","PIC 9(3)"), fld("IH-REMARK","PIC X(40)"),
     fld("IH-ADD-DATE","PIC 9(8)"), fld("IH-ADD-USER","PIC 9(6)"),
     fld("IH-UPD-DATE","PIC 9(8)"), fld("IH-UPD-USER","PIC 9(6)"),
     fld("IH-DEL-FLAG","PIC 9(1)"), fld("FILLER","PIC X(20)")])

add("INVDF", "FINVD", "SINVD", "Sales invoice detail", "ID-REC",
    ["ID-NO","ID-LINE"], [],
    [fld("ID-NO","PIC 9(10)"), fld("ID-LINE","PIC 9(3)"),
     fld("ID-PROD","PIC 9(8)"), fld("ID-WHSE","PIC 9(3)"),
     fld("ID-QTY","PIC S9(9) COMP-3"),
     fld("ID-UNIT-PRICE","PIC S9(9)V9(2) COMP-3"),
     fld("ID-AMOUNT","PIC S9(11) COMP-3"),
     fld("ID-UNIT-COST","PIC S9(9)V9(2) COMP-3"),
     fld("ID-COST-AMOUNT","PIC S9(11) COMP-3"),
     fld("ID-TAX-CATEGORY","PIC 9(1)"), fld("ID-REMARK","PIC X(30)"),
     fld("FILLER","PIC X(10)")])

# ---- 4.21 PO header/detail
add("POHF", "FPOH", "SPOH", "Purchase order header", "PH-REC",
    ["PH-NO"], [(["PH-SUPP","PH-DATE"], True)],
    [fld("PH-NO","PIC 9(10)"), fld("PH-DATE","PIC 9(8)"),
     fld("PH-SUPP","PIC 9(6)"), fld("PH-WHSE","PIC 9(3)"),
     fld("PH-STAFF","PIC 9(4)"), fld("PH-DUE-DATE","PIC 9(8)"),
     fld("PH-TAX-TYPE","PIC 9(1)"),
     fld("PH-AMOUNT","PIC S9(11) COMP-3"),
     fld("PH-TAX-AMOUNT","PIC S9(11) COMP-3"),
     fld("PH-TOTAL","PIC S9(11) COMP-3"), fld("PH-STATUS","PIC 9(1)"),
     fld("PH-LINES","PIC 9(3)"), fld("PH-REMARK","PIC X(40)"),
     fld("PH-ADD-DATE","PIC 9(8)"), fld("PH-ADD-USER","PIC 9(6)"),
     fld("PH-DEL-FLAG","PIC 9(1)"), fld("FILLER","PIC X(20)")])

add("PODF", "FPOD", "SPOD", "Purchase order detail", "PD-REC",
    ["PD-NO","PD-LINE"], [],
    [fld("PD-NO","PIC 9(10)"), fld("PD-LINE","PIC 9(3)"),
     fld("PD-PROD","PIC 9(8)"), fld("PD-WHSE","PIC 9(3)"),
     fld("PD-QTY","PIC S9(9) COMP-3"),
     fld("PD-UNIT-COST","PIC S9(9)V9(2) COMP-3"),
     fld("PD-AMOUNT","PIC S9(11) COMP-3"),
     fld("PD-RECV-QTY","PIC S9(9) COMP-3"),
     fld("PD-DUE-DATE","PIC 9(8)"), fld("PD-STATUS","PIC 9(1)"),
     fld("FILLER","PIC X(10)")])

# ---- 4.22 Receiving header/detail
add("RCVHF", "FRCVH", "SRCVH", "Receiving header", "RH-REC",
    ["RH-NO"], [(["RH-PO"], True), (["RH-DATE","RH-NO"], False)],
    [fld("RH-NO","PIC 9(10)"), fld("RH-DATE","PIC 9(8)"),
     fld("RH-PO","PIC 9(10)"), fld("RH-SUPP","PIC 9(6)"),
     fld("RH-WHSE","PIC 9(3)"), fld("RH-STATUS","PIC 9(1)"),
     fld("RH-LINES","PIC 9(3)"), fld("RH-REMARK","PIC X(40)"),
     fld("RH-ADD-DATE","PIC 9(8)"), fld("RH-ADD-USER","PIC 9(6)"),
     fld("RH-DEL-FLAG","PIC 9(1)"), fld("FILLER","PIC X(20)")])

add("RCVDF", "FRCVD", "SRCVD", "Receiving detail", "RD-REC",
    ["RD-NO","RD-LINE"], [],
    [fld("RD-NO","PIC 9(10)"), fld("RD-LINE","PIC 9(3)"),
     fld("RD-PO","PIC 9(10)"), fld("RD-PO-LINE","PIC 9(3)"),
     fld("RD-PROD","PIC 9(8)"), fld("RD-WHSE","PIC 9(3)"),
     fld("RD-QTY","PIC S9(9) COMP-3"),
     fld("RD-UNIT-COST","PIC S9(9)V9(2) COMP-3"),
     fld("RD-AMOUNT","PIC S9(11) COMP-3"), fld("FILLER","PIC X(10)")])

# ---- 4.23 Purchase header/detail
add("PURHF", "FPURH", "SPURH", "Purchase header", "VH-REC",
    ["VH-NO"], [(["VH-SUPP","VH-DATE"], True)],
    [fld("VH-NO","PIC 9(10)"), fld("VH-DATE","PIC 9(8)"),
     fld("VH-SUPP","PIC 9(6)"), fld("VH-RECV-NO","PIC 9(10)"),
     fld("VH-CLOSE-YM","PIC 9(6)"), fld("VH-TAX-TYPE","PIC 9(1)"),
     fld("VH-AMOUNT","PIC S9(11) COMP-3"),
     fld("VH-TAX-AMOUNT","PIC S9(11) COMP-3"),
     fld("VH-TOTAL","PIC S9(11) COMP-3"), fld("VH-STATUS","PIC 9(1)"),
     fld("VH-KIND","PIC 9(1)"), fld("VH-LINES","PIC 9(3)"),
     fld("VH-REMARK","PIC X(40)"), fld("VH-ADD-DATE","PIC 9(8)"),
     fld("VH-ADD-USER","PIC 9(6)"), fld("VH-DEL-FLAG","PIC 9(1)"),
     fld("FILLER","PIC X(20)")])

add("PURDF", "FPURD", "SPURD", "Purchase detail", "VD-REC",
    ["VD-NO","VD-LINE"], [],
    [fld("VD-NO","PIC 9(10)"), fld("VD-LINE","PIC 9(3)"),
     fld("VD-PROD","PIC 9(8)"), fld("VD-WHSE","PIC 9(3)"),
     fld("VD-QTY","PIC S9(9) COMP-3"),
     fld("VD-UNIT-COST","PIC S9(9)V9(2) COMP-3"),
     fld("VD-AMOUNT","PIC S9(11) COMP-3"),
     fld("VD-TAX-CATEGORY","PIC 9(1)"), fld("FILLER","PIC X(10)")])

# ---- 4.24 AR ledger
add("ARLF", "FARL", "SARL", "AR ledger", "AL-REC",
    ["AL-SEQ"], [(["AL-CUST","AL-DATE"], True), (["AL-CUST","AL-CLOSE-YM"], True)],
    [fld("AL-SEQ","PIC 9(10)"), fld("AL-CUST","PIC 9(6)"),
     fld("AL-DATE","PIC 9(8)"), fld("AL-CLOSE-YM","PIC 9(6)"),
     fld("AL-KIND","PIC 9(1)"), fld("AL-REF-TYPE","PIC 9(2)"),
     fld("AL-REF-NO","PIC 9(10)"),
     fld("AL-DEBIT","PIC S9(11) COMP-3"),
     fld("AL-CREDIT","PIC S9(11) COMP-3"),
     fld("AL-BALANCE","PIC S9(11) COMP-3"),
     fld("AL-REMARK","PIC X(30)"), fld("AL-USER","PIC 9(6)"),
     fld("FILLER","PIC X(10)")])

# ---- 4.25 AP ledger
add("APLF", "FAPL", "SAPL", "AP ledger", "PL-REC",
    ["PL-SEQ"], [(["PL-SUPP","PL-DATE"], True)],
    [fld("PL-SEQ","PIC 9(10)"), fld("PL-SUPP","PIC 9(6)"),
     fld("PL-DATE","PIC 9(8)"), fld("PL-CLOSE-YM","PIC 9(6)"),
     fld("PL-KIND","PIC 9(1)"), fld("PL-REF-TYPE","PIC 9(2)"),
     fld("PL-REF-NO","PIC 9(10)"),
     fld("PL-DEBIT","PIC S9(11) COMP-3"),
     fld("PL-CREDIT","PIC S9(11) COMP-3"),
     fld("PL-BALANCE","PIC S9(11) COMP-3"),
     fld("PL-REMARK","PIC X(30)"), fld("PL-USER","PIC 9(6)"),
     fld("FILLER","PIC X(10)")])

# ---- 4.26 Cash receipt
add("RCPTF", "FRCPT", "SRCPT", "Cash receipt", "RE-REC",
    ["RE-NO"], [(["RE-CUST","RE-DATE"], True)],
    [fld("RE-NO","PIC 9(10)"), fld("RE-DATE","PIC 9(8)"),
     fld("RE-CUST","PIC 9(6)"), fld("RE-METHOD","PIC 9(1)"),
     fld("RE-AMOUNT","PIC S9(11) COMP-3"), fld("RE-BANK-CODE","PIC 9(4)"),
     fld("RE-CLOSE-YM","PIC 9(6)"), fld("RE-STATUS","PIC 9(1)"),
     fld("RE-REMARK","PIC X(30)"), fld("RE-ADD-DATE","PIC 9(8)"),
     fld("RE-ADD-USER","PIC 9(6)"), fld("RE-DEL-FLAG","PIC 9(1)"),
     fld("FILLER","PIC X(10)")])

# ---- 4.27 Payment
add("PAYF", "FPAY", "SPAY", "Payment", "PY-REC",
    ["PY-NO"], [(["PY-SUPP","PY-DATE"], True)],
    [fld("PY-NO","PIC 9(10)"), fld("PY-DATE","PIC 9(8)"),
     fld("PY-SUPP","PIC 9(6)"), fld("PY-METHOD","PIC 9(1)"),
     fld("PY-AMOUNT","PIC S9(11) COMP-3"), fld("PY-BANK-CODE","PIC 9(4)"),
     fld("PY-CLOSE-YM","PIC 9(6)"), fld("PY-STATUS","PIC 9(1)"),
     fld("PY-REMARK","PIC X(30)"), fld("PY-ADD-DATE","PIC 9(8)"),
     fld("PY-ADD-USER","PIC 9(6)"), fld("PY-DEL-FLAG","PIC 9(1)"),
     fld("FILLER","PIC X(10)")])

# ------------------------------------------------------------------ writers
def banner(title):
    return [
        "      *----------------------------------------------------------------",
        "      *  SAKURA-SMS  copybook  -  %s" % title,
        "      *----------------------------------------------------------------",
    ]

def write_select(f):
    lines = banner("SELECT : " + f["title"])
    lines.append('           SELECT  %-12s ASSIGN  TO  %s-%s'
                 % (f["fd"], f["fd"], DEVICE))
    lines.append("                   ORGANIZATION      INDEXED")
    lines.append("                   ACCESS MODE       DYNAMIC")
    lines += key_clause("RECORD KEY", f["rkey"])
    for (klist, dup) in f["alts"]:
        lines += key_clause("ALTERNATE RECORD KEY", klist, dup)
    lines.append("                   FILE STATUS       FSTS.")
    return "\n".join(lines) + "\n"

def write_fd(f):
    lines = banner("FD/RECORD : " + f["title"])
    lines.append("       FD  %s" % f["fd"])
    lines.append("           LABEL RECORD STANDARD")
    lines.append('           VALUE OF IDENTIFICATION "%s".' % f["fd"])
    lines.append("       01  %s." % f["rec"])
    for fdef in f["fields"]:
        lines += emit_field(fdef)
    return "\n".join(lines) + "\n"

def main():
    os.makedirs(COPYDIR, exist_ok=True)
    idx = []
    for f in FILES:
        p = os.path.join(COPYDIR, f["cs"] + ".cob")
        with open(p, "w", newline="\r\n") as fh:
            fh.write(write_select(f))
        p = os.path.join(COPYDIR, f["cf"] + ".cob")
        with open(p, "w", newline="\r\n") as fh:
            fh.write(write_fd(f))
        idx.append("%-8s %-8s %-8s %s" % (f["fd"], f["cs"], f["cf"], f["title"]))
    with open(os.path.join(COPYDIR, "..", "docs", "FILE_INDEX.txt"), "w",
              newline="\r\n") as fh:
        fh.write("FILE     SELECT   FD-COPY  TITLE\n")
        fh.write("\n".join(idx) + "\n")
    print("generated %d files x 2 copybooks = %d copybooks"
          % (len(FILES), len(FILES) * 2))

if __name__ == "__main__":
    main()
