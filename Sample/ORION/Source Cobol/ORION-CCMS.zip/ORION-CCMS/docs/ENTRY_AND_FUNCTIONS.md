# ORION-CCMS - Entry Application & Functions

Entry transaction **ORSN** -> `OCSGNON` (sign-on, validates USRSEC) -> `OCMENU` (main menu) or `OCADMEN` (admin). Each function is reached by a menu option which `XCTL`s to the program carrying the shared COMMAREA (`KCOMM`); PF3 returns. This is an ONLINE-CENTRIC system: every function is a BMS screen; non-screen processing (posting, maintenance, inquiry browse, MQ auth, IMS DL/I) is a sub-program the screen calls via `EXEC CICS LINK`. Tech: CICS/BMS + VSAM + DB2 + IMS + MQ. See `docs/SPEC.md` for the data model.

**Totals:** 74 programs, 26875 COBOL LOC (see README for full artifact counts).

## Menu tree
```
ORSN OCSGNON (sign on)
 +-- OCMENU  (main)  Acct / Card / Cust / Tran / Bill Pay / Reports
 +-- OCADMEN (admin) User maintenance (list/add/upd/del)
 (plus list & add screens, tran search, type/category/group maint,
  statement view, password change; DB2 report/posting variants OD*)
```

## On-line CICS screens (VSAM) (41 programs)

| ID | Type | Function | LOC |
|----|------|----------|----:|
| OCACCTA | CICS ONLINE  (pseudo-conversational) | Account Open (on-line) | 643 |
| OCACCTL | CICS ONLINE  (pseudo-conversational) | Account List (on-line) | 435 |
| OCACCTU | CICS ONLINE  (pseudo-conversational) | Account Update (on-line) | 585 |
| OCACCTV | CICS ONLINE  (pseudo-conversational) | Account View (on-line) | 178 |
| OCACTIN | ONLINE CICS  (inquiry) | Account Inquiry (consolidated) | 568 |
| OCADMEN | CICS ONLINE  (pseudo-conversational) | Administrator Menu (on-line) | 222 |
| OCANLIN | CICS ONLINE  (pseudo-conversational) | Analytics Inquiry (on-line) | 604 |
| OCAUTHQ | CICS ONLINE + MQ  (pseudo-conversational) | Card Authorization via MQ (on-line) | 267 |
| OCBILLP | CICS ONLINE  (pseudo-conversational) | Bill Payment (on-line) | 517 |
| OCCARDA | CICS ONLINE  (pseudo-conversational) | Card Add (on-line) | 537 |
| OCCARDL | CICS ONLINE  (pseudo-conversational) | Card List for an account (on-line) | 447 |
| OCCARDU | CICS ONLINE  (pseudo-conversational) | Card Update (on-line) | 437 |
| OCCARDV | CICS ONLINE  (pseudo-conversational) | Card View (on-line) | 280 |
| OCCRDIN | ONLINE CICS  (inquiry) | Card Inquiry (consolidated) | 554 |
| OCCUSIN | CICS ONLINE  (pseudo-conversational) | Customer Inquiry (on-line) | 577 |
| OCCUSTA | CICS ONLINE  (pseudo-conversational) | Customer Add (on-line) | 425 |
| OCCUSTL | CICS ONLINE  (pseudo-conversational) | Customer List (on-line) | 437 |
| OCCUSTU | CICS ONLINE  (pseudo-conversational) | Customer Update (on-line) | 486 |
| OCCUSTV | CICS ONLINE  (pseudo-conversational) | Customer View (on-line) | 352 |
| OCDGRP | CICS ONLINE  (pseudo-conversational) | Disclosure Group Maintenance | 542 |
| OCMENU | CICS ONLINE  (pseudo-conversational) | Main Menu (on-line) | 121 |
| OCOPS | CICS ONLINE  (pseudo-conversational) | Admin Batch Operations (on-line) | 392 |
| OCPAUIN | ONLINE CICS + IMS  (pseudo-conversational) | Pending Authorization Inquiry (online) | 253 |
| OCPWDCH | CICS ONLINE  (pseudo-conversational) | Password Change (on-line) | 137 |
| OCREPT | CICS ONLINE  (pseudo-conversational) | Report Request (on-line) | 430 |
| OCRPTMN | CICS ONLINE  (pseudo-conversational) | Reports Menu (on-line) | 251 |
| OCSGNON | CICS ONLINE  (pseudo-conversational) | Sign On (on-line) | 162 |
| OCSTMIN | CICS ONLINE  (pseudo-conversational) | Statement Inquiry (on-line) | 512 |
| OCSTMV | CICS ONLINE  (pseudo-conversational) | Statement View (on-line) | 358 |
| OCTCAT | CICS ONLINE  (pseudo-conversational) | Transaction Category Maintenance | 439 |
| OCTRANA | CICS ONLINE  (pseudo-conversational) | Transaction Add (on-line) | 629 |
| OCTRANL | CICS ONLINE  (pseudo-conversational) | Transaction List (on-line) | 350 |
| OCTRANV | CICS ONLINE  (pseudo-conversational) | Transaction View (on-line) | 257 |
| OCTRNIN | CICS ONLINE  (pseudo-conversational) | Transaction Inquiry (on-line) | 669 |
| OCTSRCH | CICS ONLINE  (pseudo-conversational) | Transaction Search (on-line) | 485 |
| OCTTYP | CICS ONLINE  (pseudo-conversational) | Transaction Type Maintenance | 371 |
| OCUSRA | CICS ONLINE  (pseudo-conversational) | User Add (on-line) | 265 |
| OCUSRD | CICS ONLINE  (pseudo-conversational) | User Delete (on-line) | 312 |
| OCUSRL | CICS ONLINE  (pseudo-conversational) | User List (on-line) | 348 |
| OCUSRU | CICS ONLINE  (pseudo-conversational) | User Update (on-line) | 355 |
| OCUTIL | CICS ONLINE  (pseudo-conversational) | Admin Data-Utilities driver (on-line) | 752 |

## On-line CICS + DB2 screens (6 programs)

| ID | Type | Function | LOC |
|----|------|----------|----:|
| ODACCTU | CICS ONLINE + DB2  (pseudo-conversational) | Account Update (on-line, DB2) | 293 |
| ODACCTV | CICS ONLINE + DB2  (pseudo-conversational) | Account View (on-line, DB2) | 202 |
| ODCARDV | CICS ONLINE + DB2  (pseudo-conversational) | Card View (on-line, DB2) | 185 |
| ODCUSTV | CICS ONLINE + DB2  (pseudo-conversational) | Customer View (on-line, DB2) | 208 |
| ODTRANA | CICS ONLINE + DB2  (pseudo-conversational) | Transaction Add (on-line, DB2) | 308 |
| ODTRANL | CICS ONLINE + DB2  (pseudo-conversational) | Transaction List (on-line, DB2) | 234 |

## Sub-programs (CICS-linked / MQ / IMS DL/I) (27 programs)

| ID | Type | Function | LOC |
|----|------|----------|----:|
| OUABND | SUBROUTINE (EXEC CICS LINK from online programs) | abnormal-end handler | 40 |
| OUACTIN | SUB  (VSAM browse) | Account Inquiry browse engine | 434 |
| OUANLIN | SUBROUTINE (EXEC CICS LINK from OCANLIN) | Analytics compute subroutine | 512 |
| OUARCH | SUB  (CICS file control) | Archive transactions older than a cutoff | 301 |
| OUBKP | SUB  (CICS file control) | Extract / backup transactions to a feed | 267 |
| OUCHGF | SUB  (CICS file control) | Charge-off processing SUB | 366 |
| OUCLOS | SUB  (CICS file control) | Account close SUB | 274 |
| OUCRDIN | SUB  (VSAM browse) | Card Inquiry browse engine | 381 |
| OUCUSIN | SUBROUTINE (EXEC CICS LINK from OCCUSIN) | Customer Inquiry browse engine | 262 |
| OUCYCL | SUB  (CICS file control) | Cycle / end-of-month roll SUB | 253 |
| OUDATE | SUBROUTINE (CALL / EXEC CICS LINK) | date utility subroutine | 75 |
| OUFEE | SUB  (CICS file control) | Fee assessment SUB | 415 |
| OUFLAG | SUB  (CICS file control) | Delinquency scan + expiry deactivation | 361 |
| OUIMP | SUB  (CICS file control) | Account import from a staged feed | 492 |
| OUIMSPA | SUB  (IMS DL/I) | Pending Authorization DL/I access | 411 |
| OUINT | SUB  (CICS file control) | Interest assessment SUB | 285 |
| OUMQBRG | SUB  (MQ / MQI CALL) | VSAM-to-MQ transaction bridge | 271 |
| OUMQREQ | SUB  (MQ / MQI CALL) | MQ authorization requester | 377 |
| OUMSG | SUBROUTINE (CALL / EXEC CICS LINK) | message-text retriever | 33 |
| OUPAY | SUB  (CICS file control) | Payment / bill posting SUB | 323 |
| OUPOST | SUB  (CICS file control) | Daily transaction posting SUB | 312 |
| OUPURG | SUB  (CICS file control) | Purge aged transactions by cutoff | 280 |
| OURNEW | SUB  (CICS file control) | Card renewal / reissue SUB | 322 |
| OUSTMB | SUB  (CICS file control) | Build monthly statements per account | 463 |
| OUSTMIN | SUBROUTINE (EXEC CICS LINK from OCSTMIN) | Statement browse subroutine | 295 |
| OUTRNIN | SUBROUTINE (EXEC CICS LINK from OCTRNIN) | Transaction Inquiry browse / analytics | 318 |
| OUXREF | SUB  (CICS file control) | Rebuild / validate card cross-reference | 381 |

## Batch (residual) (0 programs)

| ID | Type | Function | LOC |
|----|------|----------|----:|

