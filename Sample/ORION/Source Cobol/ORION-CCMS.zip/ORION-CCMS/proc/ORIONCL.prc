//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  PROC    : ORIONCL  - Generic ORION batch run procedure    *
//*  Cataloged procedure that runs any OB* batch program with  *
//*  the full set of ORION VSAM DDs pre-allocated.  Override   *
//*  PGM= on the EXEC, e.g.  //S EXEC ORIONCL,PGM=OBINTC       *
//*  Symbolics: PGM (program), HLQ (dataset high-level qual).  *
//***************************************************************
//ORIONCL  PROC PGM=OBACCTP,HLQ=ORION
//RUN      EXEC PGM=&PGM,REGION=0M
//STEPLIB  DD DSN=&HLQ..LOADLIB,DISP=SHR
//*
//*  All 12 master/reference VSAM files                        *
//ACCTFILE DD DSN=&HLQ..ACCTFILE,DISP=SHR
//CARDFILE DD DSN=&HLQ..CARDFILE,DISP=SHR
//CUSTFILE DD DSN=&HLQ..CUSTFILE,DISP=SHR
//XREFFILE DD DSN=&HLQ..XREFFILE,DISP=SHR
//TRANFILE DD DSN=&HLQ..TRANFILE,DISP=SHR
//TTYPFILE DD DSN=&HLQ..TTYPFILE,DISP=SHR
//TCATFILE DD DSN=&HLQ..TCATFILE,DISP=SHR
//DGRPFILE DD DSN=&HLQ..DGRPFILE,DISP=SHR
//USRSEC   DD DSN=&HLQ..USRSEC,DISP=SHR
//BILLFILE DD DSN=&HLQ..BILLFILE,DISP=SHR
//STMTFILE DD DSN=&HLQ..STMTFILE,DISP=SHR
//CTRLFILE DD DSN=&HLQ..CTRLFILE,DISP=SHR
//*
//*  Report / dump / runtime output                            *
//RPTFILE  DD SYSOUT=*
//SYSOUT   DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//CEEDUMP  DD SYSOUT=*
//SYSUDUMP DD SYSOUT=*
//         PEND
