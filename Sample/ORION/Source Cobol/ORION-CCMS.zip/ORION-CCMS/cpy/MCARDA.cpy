      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MCARDA
      *----------------------------------------------------------------
       01  MCARDAAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  CARDNUML PIC S9(04) COMP.
           02  CARDNUMF PIC X.
           02  FILLER REDEFINES CARDNUMF.
               03  CARDNUMA PIC X.
           02  CARDNUMI PIC X(16).
           02  CDACCTL PIC S9(04) COMP.
           02  CDACCTF PIC X.
           02  FILLER REDEFINES CDACCTF.
               03  CDACCTA PIC X.
           02  CDACCTI PIC X(11).
           02  CDNAMEL PIC S9(04) COMP.
           02  CDNAMEF PIC X.
           02  FILLER REDEFINES CDNAMEF.
               03  CDNAMEA PIC X.
           02  CDNAMEI PIC X(50).
           02  CDCVVL PIC S9(04) COMP.
           02  CDCVVF PIC X.
           02  FILLER REDEFINES CDCVVF.
               03  CDCVVA PIC X.
           02  CDCVVI PIC X(03).
           02  CDEXPL PIC S9(04) COMP.
           02  CDEXPF PIC X.
           02  FILLER REDEFINES CDEXPF.
               03  CDEXPA PIC X.
           02  CDEXPI PIC X(10).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MCARDAAO REDEFINES MCARDAAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CARDNUMO PIC X(16).
           02  FILLER PIC X(03).
           02  CDACCTO PIC X(11).
           02  FILLER PIC X(03).
           02  CDNAMEO PIC X(50).
           02  FILLER PIC X(03).
           02  CDCVVO PIC X(03).
           02  FILLER PIC X(03).
           02  CDEXPO PIC X(10).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
