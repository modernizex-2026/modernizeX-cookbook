      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MCUSIN
      *----------------------------------------------------------------
       01  MCUSINAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  FMODEL PIC S9(04) COMP.
           02  FMODEF PIC X.
           02  FILLER REDEFINES FMODEF.
               03  FMODEA PIC X.
           02  FMODEI PIC X(01).
           02  FRIDL PIC S9(04) COMP.
           02  FRIDF PIC X.
           02  FILLER REDEFINES FRIDF.
               03  FRIDA PIC X.
           02  FRIDI PIC X(09).
           02  TOIDL PIC S9(04) COMP.
           02  TOIDF PIC X.
           02  FILLER REDEFINES TOIDF.
               03  TOIDA PIC X.
           02  TOIDI PIC X(09).
           02  FRFICOL PIC S9(04) COMP.
           02  FRFICOF PIC X.
           02  FILLER REDEFINES FRFICOF.
               03  FRFICOA PIC X.
           02  FRFICOI PIC X(03).
           02  TOFICOL PIC S9(04) COMP.
           02  TOFICOF PIC X.
           02  FILLER REDEFINES TOFICOF.
               03  TOFICOA PIC X.
           02  TOFICOI PIC X(03).
           02  FSTATEL PIC S9(04) COMP.
           02  FSTATEF PIC X.
           02  FILLER REDEFINES FSTATEF.
               03  FSTATEA PIC X.
           02  FSTATEI PIC X(02).
           02  FZIPL PIC S9(04) COMP.
           02  FZIPF PIC X.
           02  FILLER REDEFINES FZIPF.
               03  FZIPA PIC X.
           02  FZIPI PIC X(10).
           02  CUL1L PIC S9(04) COMP.
           02  CUL1F PIC X.
           02  FILLER REDEFINES CUL1F.
               03  CUL1A PIC X.
           02  CUL1I PIC X(09).
           02  CUN1L PIC S9(04) COMP.
           02  CUN1F PIC X.
           02  FILLER REDEFINES CUN1F.
               03  CUN1A PIC X.
           02  CUN1I PIC X(30).
           02  CST1L PIC S9(04) COMP.
           02  CST1F PIC X.
           02  FILLER REDEFINES CST1F.
               03  CST1A PIC X.
           02  CST1I PIC X(02).
           02  CZP1L PIC S9(04) COMP.
           02  CZP1F PIC X.
           02  FILLER REDEFINES CZP1F.
               03  CZP1A PIC X.
           02  CZP1I PIC X(10).
           02  CFI1L PIC S9(04) COMP.
           02  CFI1F PIC X.
           02  FILLER REDEFINES CFI1F.
               03  CFI1A PIC X.
           02  CFI1I PIC X(03).
           02  CUL2L PIC S9(04) COMP.
           02  CUL2F PIC X.
           02  FILLER REDEFINES CUL2F.
               03  CUL2A PIC X.
           02  CUL2I PIC X(09).
           02  CUN2L PIC S9(04) COMP.
           02  CUN2F PIC X.
           02  FILLER REDEFINES CUN2F.
               03  CUN2A PIC X.
           02  CUN2I PIC X(30).
           02  CST2L PIC S9(04) COMP.
           02  CST2F PIC X.
           02  FILLER REDEFINES CST2F.
               03  CST2A PIC X.
           02  CST2I PIC X(02).
           02  CZP2L PIC S9(04) COMP.
           02  CZP2F PIC X.
           02  FILLER REDEFINES CZP2F.
               03  CZP2A PIC X.
           02  CZP2I PIC X(10).
           02  CFI2L PIC S9(04) COMP.
           02  CFI2F PIC X.
           02  FILLER REDEFINES CFI2F.
               03  CFI2A PIC X.
           02  CFI2I PIC X(03).
           02  CUL3L PIC S9(04) COMP.
           02  CUL3F PIC X.
           02  FILLER REDEFINES CUL3F.
               03  CUL3A PIC X.
           02  CUL3I PIC X(09).
           02  CUN3L PIC S9(04) COMP.
           02  CUN3F PIC X.
           02  FILLER REDEFINES CUN3F.
               03  CUN3A PIC X.
           02  CUN3I PIC X(30).
           02  CST3L PIC S9(04) COMP.
           02  CST3F PIC X.
           02  FILLER REDEFINES CST3F.
               03  CST3A PIC X.
           02  CST3I PIC X(02).
           02  CZP3L PIC S9(04) COMP.
           02  CZP3F PIC X.
           02  FILLER REDEFINES CZP3F.
               03  CZP3A PIC X.
           02  CZP3I PIC X(10).
           02  CFI3L PIC S9(04) COMP.
           02  CFI3F PIC X.
           02  FILLER REDEFINES CFI3F.
               03  CFI3A PIC X.
           02  CFI3I PIC X(03).
           02  CUL4L PIC S9(04) COMP.
           02  CUL4F PIC X.
           02  FILLER REDEFINES CUL4F.
               03  CUL4A PIC X.
           02  CUL4I PIC X(09).
           02  CUN4L PIC S9(04) COMP.
           02  CUN4F PIC X.
           02  FILLER REDEFINES CUN4F.
               03  CUN4A PIC X.
           02  CUN4I PIC X(30).
           02  CST4L PIC S9(04) COMP.
           02  CST4F PIC X.
           02  FILLER REDEFINES CST4F.
               03  CST4A PIC X.
           02  CST4I PIC X(02).
           02  CZP4L PIC S9(04) COMP.
           02  CZP4F PIC X.
           02  FILLER REDEFINES CZP4F.
               03  CZP4A PIC X.
           02  CZP4I PIC X(10).
           02  CFI4L PIC S9(04) COMP.
           02  CFI4F PIC X.
           02  FILLER REDEFINES CFI4F.
               03  CFI4A PIC X.
           02  CFI4I PIC X(03).
           02  CUL5L PIC S9(04) COMP.
           02  CUL5F PIC X.
           02  FILLER REDEFINES CUL5F.
               03  CUL5A PIC X.
           02  CUL5I PIC X(09).
           02  CUN5L PIC S9(04) COMP.
           02  CUN5F PIC X.
           02  FILLER REDEFINES CUN5F.
               03  CUN5A PIC X.
           02  CUN5I PIC X(30).
           02  CST5L PIC S9(04) COMP.
           02  CST5F PIC X.
           02  FILLER REDEFINES CST5F.
               03  CST5A PIC X.
           02  CST5I PIC X(02).
           02  CZP5L PIC S9(04) COMP.
           02  CZP5F PIC X.
           02  FILLER REDEFINES CZP5F.
               03  CZP5A PIC X.
           02  CZP5I PIC X(10).
           02  CFI5L PIC S9(04) COMP.
           02  CFI5F PIC X.
           02  FILLER REDEFINES CFI5F.
               03  CFI5A PIC X.
           02  CFI5I PIC X(03).
           02  CUL6L PIC S9(04) COMP.
           02  CUL6F PIC X.
           02  FILLER REDEFINES CUL6F.
               03  CUL6A PIC X.
           02  CUL6I PIC X(09).
           02  CUN6L PIC S9(04) COMP.
           02  CUN6F PIC X.
           02  FILLER REDEFINES CUN6F.
               03  CUN6A PIC X.
           02  CUN6I PIC X(30).
           02  CST6L PIC S9(04) COMP.
           02  CST6F PIC X.
           02  FILLER REDEFINES CST6F.
               03  CST6A PIC X.
           02  CST6I PIC X(02).
           02  CZP6L PIC S9(04) COMP.
           02  CZP6F PIC X.
           02  FILLER REDEFINES CZP6F.
               03  CZP6A PIC X.
           02  CZP6I PIC X(10).
           02  CFI6L PIC S9(04) COMP.
           02  CFI6F PIC X.
           02  FILLER REDEFINES CFI6F.
               03  CFI6A PIC X.
           02  CFI6I PIC X(03).
           02  CUL7L PIC S9(04) COMP.
           02  CUL7F PIC X.
           02  FILLER REDEFINES CUL7F.
               03  CUL7A PIC X.
           02  CUL7I PIC X(09).
           02  CUN7L PIC S9(04) COMP.
           02  CUN7F PIC X.
           02  FILLER REDEFINES CUN7F.
               03  CUN7A PIC X.
           02  CUN7I PIC X(30).
           02  CST7L PIC S9(04) COMP.
           02  CST7F PIC X.
           02  FILLER REDEFINES CST7F.
               03  CST7A PIC X.
           02  CST7I PIC X(02).
           02  CZP7L PIC S9(04) COMP.
           02  CZP7F PIC X.
           02  FILLER REDEFINES CZP7F.
               03  CZP7A PIC X.
           02  CZP7I PIC X(10).
           02  CFI7L PIC S9(04) COMP.
           02  CFI7F PIC X.
           02  FILLER REDEFINES CFI7F.
               03  CFI7A PIC X.
           02  CFI7I PIC X(03).
           02  CUL8L PIC S9(04) COMP.
           02  CUL8F PIC X.
           02  FILLER REDEFINES CUL8F.
               03  CUL8A PIC X.
           02  CUL8I PIC X(09).
           02  CUN8L PIC S9(04) COMP.
           02  CUN8F PIC X.
           02  FILLER REDEFINES CUN8F.
               03  CUN8A PIC X.
           02  CUN8I PIC X(30).
           02  CST8L PIC S9(04) COMP.
           02  CST8F PIC X.
           02  FILLER REDEFINES CST8F.
               03  CST8A PIC X.
           02  CST8I PIC X(02).
           02  CZP8L PIC S9(04) COMP.
           02  CZP8F PIC X.
           02  FILLER REDEFINES CZP8F.
               03  CZP8A PIC X.
           02  CZP8I PIC X(10).
           02  CFI8L PIC S9(04) COMP.
           02  CFI8F PIC X.
           02  FILLER REDEFINES CFI8F.
               03  CFI8A PIC X.
           02  CFI8I PIC X(03).
           02  CUL9L PIC S9(04) COMP.
           02  CUL9F PIC X.
           02  FILLER REDEFINES CUL9F.
               03  CUL9A PIC X.
           02  CUL9I PIC X(09).
           02  CUN9L PIC S9(04) COMP.
           02  CUN9F PIC X.
           02  FILLER REDEFINES CUN9F.
               03  CUN9A PIC X.
           02  CUN9I PIC X(30).
           02  CST9L PIC S9(04) COMP.
           02  CST9F PIC X.
           02  FILLER REDEFINES CST9F.
               03  CST9A PIC X.
           02  CST9I PIC X(02).
           02  CZP9L PIC S9(04) COMP.
           02  CZP9F PIC X.
           02  FILLER REDEFINES CZP9F.
               03  CZP9A PIC X.
           02  CZP9I PIC X(10).
           02  CFI9L PIC S9(04) COMP.
           02  CFI9F PIC X.
           02  FILLER REDEFINES CFI9F.
               03  CFI9A PIC X.
           02  CFI9I PIC X(03).
           02  CUL10L PIC S9(04) COMP.
           02  CUL10F PIC X.
           02  FILLER REDEFINES CUL10F.
               03  CUL10A PIC X.
           02  CUL10I PIC X(09).
           02  CUN10L PIC S9(04) COMP.
           02  CUN10F PIC X.
           02  FILLER REDEFINES CUN10F.
               03  CUN10A PIC X.
           02  CUN10I PIC X(30).
           02  CST10L PIC S9(04) COMP.
           02  CST10F PIC X.
           02  FILLER REDEFINES CST10F.
               03  CST10A PIC X.
           02  CST10I PIC X(02).
           02  CZP10L PIC S9(04) COMP.
           02  CZP10F PIC X.
           02  FILLER REDEFINES CZP10F.
               03  CZP10A PIC X.
           02  CZP10I PIC X(10).
           02  CFI10L PIC S9(04) COMP.
           02  CFI10F PIC X.
           02  FILLER REDEFINES CFI10F.
               03  CFI10A PIC X.
           02  CFI10I PIC X(03).
           02  CUL11L PIC S9(04) COMP.
           02  CUL11F PIC X.
           02  FILLER REDEFINES CUL11F.
               03  CUL11A PIC X.
           02  CUL11I PIC X(09).
           02  CUN11L PIC S9(04) COMP.
           02  CUN11F PIC X.
           02  FILLER REDEFINES CUN11F.
               03  CUN11A PIC X.
           02  CUN11I PIC X(30).
           02  CST11L PIC S9(04) COMP.
           02  CST11F PIC X.
           02  FILLER REDEFINES CST11F.
               03  CST11A PIC X.
           02  CST11I PIC X(02).
           02  CZP11L PIC S9(04) COMP.
           02  CZP11F PIC X.
           02  FILLER REDEFINES CZP11F.
               03  CZP11A PIC X.
           02  CZP11I PIC X(10).
           02  CFI11L PIC S9(04) COMP.
           02  CFI11F PIC X.
           02  FILLER REDEFINES CFI11F.
               03  CFI11A PIC X.
           02  CFI11I PIC X(03).
           02  CUL12L PIC S9(04) COMP.
           02  CUL12F PIC X.
           02  FILLER REDEFINES CUL12F.
               03  CUL12A PIC X.
           02  CUL12I PIC X(09).
           02  CUN12L PIC S9(04) COMP.
           02  CUN12F PIC X.
           02  FILLER REDEFINES CUN12F.
               03  CUN12A PIC X.
           02  CUN12I PIC X(30).
           02  CST12L PIC S9(04) COMP.
           02  CST12F PIC X.
           02  FILLER REDEFINES CST12F.
               03  CST12A PIC X.
           02  CST12I PIC X(02).
           02  CZP12L PIC S9(04) COMP.
           02  CZP12F PIC X.
           02  FILLER REDEFINES CZP12F.
               03  CZP12A PIC X.
           02  CZP12I PIC X(10).
           02  CFI12L PIC S9(04) COMP.
           02  CFI12F PIC X.
           02  FILLER REDEFINES CFI12F.
               03  CFI12A PIC X.
           02  CFI12I PIC X(03).
           02  CUL13L PIC S9(04) COMP.
           02  CUL13F PIC X.
           02  FILLER REDEFINES CUL13F.
               03  CUL13A PIC X.
           02  CUL13I PIC X(09).
           02  CUN13L PIC S9(04) COMP.
           02  CUN13F PIC X.
           02  FILLER REDEFINES CUN13F.
               03  CUN13A PIC X.
           02  CUN13I PIC X(30).
           02  CST13L PIC S9(04) COMP.
           02  CST13F PIC X.
           02  FILLER REDEFINES CST13F.
               03  CST13A PIC X.
           02  CST13I PIC X(02).
           02  CZP13L PIC S9(04) COMP.
           02  CZP13F PIC X.
           02  FILLER REDEFINES CZP13F.
               03  CZP13A PIC X.
           02  CZP13I PIC X(10).
           02  CFI13L PIC S9(04) COMP.
           02  CFI13F PIC X.
           02  FILLER REDEFINES CFI13F.
               03  CFI13A PIC X.
           02  CFI13I PIC X(03).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MCUSINAO REDEFINES MCUSINAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  FMODEO PIC X(01).
           02  FILLER PIC X(03).
           02  FRIDO PIC X(09).
           02  FILLER PIC X(03).
           02  TOIDO PIC X(09).
           02  FILLER PIC X(03).
           02  FRFICOO PIC X(03).
           02  FILLER PIC X(03).
           02  TOFICOO PIC X(03).
           02  FILLER PIC X(03).
           02  FSTATEO PIC X(02).
           02  FILLER PIC X(03).
           02  FZIPO PIC X(10).
           02  FILLER PIC X(03).
           02  CUL1O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN1O PIC X(30).
           02  FILLER PIC X(03).
           02  CST1O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP1O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI1O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL2O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN2O PIC X(30).
           02  FILLER PIC X(03).
           02  CST2O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP2O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI2O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL3O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN3O PIC X(30).
           02  FILLER PIC X(03).
           02  CST3O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP3O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI3O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL4O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN4O PIC X(30).
           02  FILLER PIC X(03).
           02  CST4O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP4O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI4O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL5O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN5O PIC X(30).
           02  FILLER PIC X(03).
           02  CST5O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP5O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI5O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL6O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN6O PIC X(30).
           02  FILLER PIC X(03).
           02  CST6O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP6O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI6O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL7O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN7O PIC X(30).
           02  FILLER PIC X(03).
           02  CST7O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP7O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI7O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL8O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN8O PIC X(30).
           02  FILLER PIC X(03).
           02  CST8O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP8O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI8O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL9O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN9O PIC X(30).
           02  FILLER PIC X(03).
           02  CST9O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP9O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI9O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL10O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN10O PIC X(30).
           02  FILLER PIC X(03).
           02  CST10O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP10O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI10O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL11O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN11O PIC X(30).
           02  FILLER PIC X(03).
           02  CST11O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP11O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI11O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL12O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN12O PIC X(30).
           02  FILLER PIC X(03).
           02  CST12O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP12O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI12O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL13O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN13O PIC X(30).
           02  FILLER PIC X(03).
           02  CST13O PIC X(02).
           02  FILLER PIC X(03).
           02  CZP13O PIC X(10).
           02  FILLER PIC X(03).
           02  CFI13O PIC X(03).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
