      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MUSRU
      *----------------------------------------------------------------
       01  MUSRUAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  USERIDL PIC S9(04) COMP.
           02  USERIDF PIC X.
           02  FILLER REDEFINES USERIDF.
               03  USERIDA PIC X.
           02  USERIDI PIC X(08).
           02  USFNAML PIC S9(04) COMP.
           02  USFNAMF PIC X.
           02  FILLER REDEFINES USFNAMF.
               03  USFNAMA PIC X.
           02  USFNAMI PIC X(20).
           02  USLNAML PIC S9(04) COMP.
           02  USLNAMF PIC X.
           02  FILLER REDEFINES USLNAMF.
               03  USLNAMA PIC X.
           02  USLNAMI PIC X(20).
           02  USPWDL PIC S9(04) COMP.
           02  USPWDF PIC X.
           02  FILLER REDEFINES USPWDF.
               03  USPWDA PIC X.
           02  USPWDI PIC X(08).
           02  USTYPEL PIC S9(04) COMP.
           02  USTYPEF PIC X.
           02  FILLER REDEFINES USTYPEF.
               03  USTYPEA PIC X.
           02  USTYPEI PIC X(01).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MUSRUAO REDEFINES MUSRUAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  USERIDO PIC X(08).
           02  FILLER PIC X(03).
           02  USFNAMO PIC X(20).
           02  FILLER PIC X(03).
           02  USLNAMO PIC X(20).
           02  FILLER PIC X(03).
           02  USPWDO PIC X(08).
           02  FILLER PIC X(03).
           02  USTYPEO PIC X(01).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
