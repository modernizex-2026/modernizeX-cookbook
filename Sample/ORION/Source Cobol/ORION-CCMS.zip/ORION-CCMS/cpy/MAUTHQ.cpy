      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MAUTHQ
      *----------------------------------------------------------------
       01  MAUTHQAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  CARDNUML PIC S9(04) COMP.
           02  CARDNUMF PIC X.
           02  FILLER REDEFINES CARDNUMF.
               03  CARDNUMA PIC X.
           02  CARDNUMI PIC X(16).
           02  AMOUNTL PIC S9(04) COMP.
           02  AMOUNTF PIC X.
           02  FILLER REDEFINES AMOUNTF.
               03  AMOUNTA PIC X.
           02  AMOUNTI PIC X(12).
           02  MERCHL PIC S9(04) COMP.
           02  MERCHF PIC X.
           02  FILLER REDEFINES MERCHF.
               03  MERCHA PIC X.
           02  MERCHI PIC X(20).
           02  DECISNL PIC S9(04) COMP.
           02  DECISNF PIC X.
           02  FILLER REDEFINES DECISNF.
               03  DECISNA PIC X.
           02  DECISNI PIC X(08).
           02  REASONL PIC S9(04) COMP.
           02  REASONF PIC X.
           02  FILLER REDEFINES REASONF.
               03  REASONA PIC X.
           02  REASONI PIC X(20).
           02  AVAILL PIC S9(04) COMP.
           02  AVAILF PIC X.
           02  FILLER REDEFINES AVAILF.
               03  AVAILA PIC X.
           02  AVAILI PIC X(15).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MAUTHQAO REDEFINES MAUTHQAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CARDNUMO PIC X(16).
           02  FILLER PIC X(03).
           02  AMOUNTO PIC X(12).
           02  FILLER PIC X(03).
           02  MERCHO PIC X(20).
           02  FILLER PIC X(03).
           02  DECISNO PIC X(08).
           02  FILLER PIC X(03).
           02  REASONO PIC X(20).
           02  FILLER PIC X(03).
           02  AVAILO PIC X(15).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
