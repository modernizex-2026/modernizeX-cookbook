      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MUTIL
      *----------------------------------------------------------------
       01  MUTILAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  UTOPTL PIC S9(04) COMP.
           02  UTOPTF PIC X.
           02  FILLER REDEFINES UTOPTF.
               03  UTOPTA PIC X.
           02  UTOPTI PIC X(02).
           02  UTMODEL PIC S9(04) COMP.
           02  UTMODEF PIC X.
           02  FILLER REDEFINES UTMODEF.
               03  UTMODEA PIC X.
           02  UTMODEI PIC X(04).
           02  UTDATEL PIC S9(04) COMP.
           02  UTDATEF PIC X.
           02  FILLER REDEFINES UTDATEF.
               03  UTDATEA PIC X.
           02  UTDATEI PIC X(10).
           02  UTCYCL PIC S9(04) COMP.
           02  UTCYCF PIC X.
           02  FILLER REDEFINES UTCYCF.
               03  UTCYCA PIC X.
           02  UTCYCI PIC X(06).
           02  UTNUML PIC S9(04) COMP.
           02  UTNUMF PIC X.
           02  FILLER REDEFINES UTNUMF.
               03  UTNUMA PIC X.
           02  UTNUMI PIC X(07).
           02  RSTATL PIC S9(04) COMP.
           02  RSTATF PIC X.
           02  FILLER REDEFINES RSTATF.
               03  RSTATA PIC X.
           02  RSTATI PIC X(02).
           02  RMSGL PIC S9(04) COMP.
           02  RMSGF PIC X.
           02  FILLER REDEFINES RMSGF.
               03  RMSGA PIC X.
           02  RMSGI PIC X(50).
           02  RLINE1L PIC S9(04) COMP.
           02  RLINE1F PIC X.
           02  FILLER REDEFINES RLINE1F.
               03  RLINE1A PIC X.
           02  RLINE1I PIC X(60).
           02  RLINE2L PIC S9(04) COMP.
           02  RLINE2F PIC X.
           02  FILLER REDEFINES RLINE2F.
               03  RLINE2A PIC X.
           02  RLINE2I PIC X(60).
           02  RLINE3L PIC S9(04) COMP.
           02  RLINE3F PIC X.
           02  FILLER REDEFINES RLINE3F.
               03  RLINE3A PIC X.
           02  RLINE3I PIC X(60).
           02  RLINE4L PIC S9(04) COMP.
           02  RLINE4F PIC X.
           02  FILLER REDEFINES RLINE4F.
               03  RLINE4A PIC X.
           02  RLINE4I PIC X(60).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MUTILAO REDEFINES MUTILAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  UTOPTO PIC X(02).
           02  FILLER PIC X(03).
           02  UTMODEO PIC X(04).
           02  FILLER PIC X(03).
           02  UTDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  UTCYCO PIC X(06).
           02  FILLER PIC X(03).
           02  UTNUMO PIC X(07).
           02  FILLER PIC X(03).
           02  RSTATO PIC X(02).
           02  FILLER PIC X(03).
           02  RMSGO PIC X(50).
           02  FILLER PIC X(03).
           02  RLINE1O PIC X(60).
           02  FILLER PIC X(03).
           02  RLINE2O PIC X(60).
           02  FILLER PIC X(03).
           02  RLINE3O PIC X(60).
           02  FILLER PIC X(03).
           02  RLINE4O PIC X(60).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
