      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KMSG : linkage for subroutine OUMSG
      *----------------------------------------------------------------
       01  KMSG-PARM.
           05  KM-CODE              PIC X(06).
           05  KM-TEXT              PIC X(80).
           05  KM-STATUS            PIC X(02).
