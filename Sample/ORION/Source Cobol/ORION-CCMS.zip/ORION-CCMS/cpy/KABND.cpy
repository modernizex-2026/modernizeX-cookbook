      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KABND : linkage for subroutine OUABND
      *----------------------------------------------------------------
       01  KABND-PARM.
           05  KA-PROGRAM           PIC X(08).
           05  KA-PARAGRAPH         PIC X(30).
           05  KA-RESP-CD           PIC S9(09) COMP.
           05  KA-REAS-CD           PIC S9(09) COMP.
           05  KA-DETAIL            PIC X(80).
