      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MSTMIN
      *----------------------------------------------------------------
       01  MSTMINAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  FRACCTL PIC S9(04) COMP.
           02  FRACCTF PIC X.
           02  FILLER REDEFINES FRACCTF.
               03  FRACCTA PIC X.
           02  FRACCTI PIC X(11).
           02  FRCYCL PIC S9(04) COMP.
           02  FRCYCF PIC X.
           02  FILLER REDEFINES FRCYCF.
               03  FRCYCA PIC X.
           02  FRCYCI PIC X(06).
           02  SA1L PIC S9(04) COMP.
           02  SA1F PIC X.
           02  FILLER REDEFINES SA1F.
               03  SA1A PIC X.
           02  SA1I PIC X(11).
           02  SC1L PIC S9(04) COMP.
           02  SC1F PIC X.
           02  FILLER REDEFINES SC1F.
               03  SC1A PIC X.
           02  SC1I PIC X(06).
           02  SO1L PIC S9(04) COMP.
           02  SO1F PIC X.
           02  FILLER REDEFINES SO1F.
               03  SO1A PIC X.
           02  SO1I PIC X(14).
           02  SL1L PIC S9(04) COMP.
           02  SL1F PIC X.
           02  FILLER REDEFINES SL1F.
               03  SL1A PIC X.
           02  SL1I PIC X(14).
           02  SM1L PIC S9(04) COMP.
           02  SM1F PIC X.
           02  FILLER REDEFINES SM1F.
               03  SM1A PIC X.
           02  SM1I PIC X(14).
           02  SD1L PIC S9(04) COMP.
           02  SD1F PIC X.
           02  FILLER REDEFINES SD1F.
               03  SD1A PIC X.
           02  SD1I PIC X(10).
           02  SA2L PIC S9(04) COMP.
           02  SA2F PIC X.
           02  FILLER REDEFINES SA2F.
               03  SA2A PIC X.
           02  SA2I PIC X(11).
           02  SC2L PIC S9(04) COMP.
           02  SC2F PIC X.
           02  FILLER REDEFINES SC2F.
               03  SC2A PIC X.
           02  SC2I PIC X(06).
           02  SO2L PIC S9(04) COMP.
           02  SO2F PIC X.
           02  FILLER REDEFINES SO2F.
               03  SO2A PIC X.
           02  SO2I PIC X(14).
           02  SL2L PIC S9(04) COMP.
           02  SL2F PIC X.
           02  FILLER REDEFINES SL2F.
               03  SL2A PIC X.
           02  SL2I PIC X(14).
           02  SM2L PIC S9(04) COMP.
           02  SM2F PIC X.
           02  FILLER REDEFINES SM2F.
               03  SM2A PIC X.
           02  SM2I PIC X(14).
           02  SD2L PIC S9(04) COMP.
           02  SD2F PIC X.
           02  FILLER REDEFINES SD2F.
               03  SD2A PIC X.
           02  SD2I PIC X(10).
           02  SA3L PIC S9(04) COMP.
           02  SA3F PIC X.
           02  FILLER REDEFINES SA3F.
               03  SA3A PIC X.
           02  SA3I PIC X(11).
           02  SC3L PIC S9(04) COMP.
           02  SC3F PIC X.
           02  FILLER REDEFINES SC3F.
               03  SC3A PIC X.
           02  SC3I PIC X(06).
           02  SO3L PIC S9(04) COMP.
           02  SO3F PIC X.
           02  FILLER REDEFINES SO3F.
               03  SO3A PIC X.
           02  SO3I PIC X(14).
           02  SL3L PIC S9(04) COMP.
           02  SL3F PIC X.
           02  FILLER REDEFINES SL3F.
               03  SL3A PIC X.
           02  SL3I PIC X(14).
           02  SM3L PIC S9(04) COMP.
           02  SM3F PIC X.
           02  FILLER REDEFINES SM3F.
               03  SM3A PIC X.
           02  SM3I PIC X(14).
           02  SD3L PIC S9(04) COMP.
           02  SD3F PIC X.
           02  FILLER REDEFINES SD3F.
               03  SD3A PIC X.
           02  SD3I PIC X(10).
           02  SA4L PIC S9(04) COMP.
           02  SA4F PIC X.
           02  FILLER REDEFINES SA4F.
               03  SA4A PIC X.
           02  SA4I PIC X(11).
           02  SC4L PIC S9(04) COMP.
           02  SC4F PIC X.
           02  FILLER REDEFINES SC4F.
               03  SC4A PIC X.
           02  SC4I PIC X(06).
           02  SO4L PIC S9(04) COMP.
           02  SO4F PIC X.
           02  FILLER REDEFINES SO4F.
               03  SO4A PIC X.
           02  SO4I PIC X(14).
           02  SL4L PIC S9(04) COMP.
           02  SL4F PIC X.
           02  FILLER REDEFINES SL4F.
               03  SL4A PIC X.
           02  SL4I PIC X(14).
           02  SM4L PIC S9(04) COMP.
           02  SM4F PIC X.
           02  FILLER REDEFINES SM4F.
               03  SM4A PIC X.
           02  SM4I PIC X(14).
           02  SD4L PIC S9(04) COMP.
           02  SD4F PIC X.
           02  FILLER REDEFINES SD4F.
               03  SD4A PIC X.
           02  SD4I PIC X(10).
           02  SA5L PIC S9(04) COMP.
           02  SA5F PIC X.
           02  FILLER REDEFINES SA5F.
               03  SA5A PIC X.
           02  SA5I PIC X(11).
           02  SC5L PIC S9(04) COMP.
           02  SC5F PIC X.
           02  FILLER REDEFINES SC5F.
               03  SC5A PIC X.
           02  SC5I PIC X(06).
           02  SO5L PIC S9(04) COMP.
           02  SO5F PIC X.
           02  FILLER REDEFINES SO5F.
               03  SO5A PIC X.
           02  SO5I PIC X(14).
           02  SL5L PIC S9(04) COMP.
           02  SL5F PIC X.
           02  FILLER REDEFINES SL5F.
               03  SL5A PIC X.
           02  SL5I PIC X(14).
           02  SM5L PIC S9(04) COMP.
           02  SM5F PIC X.
           02  FILLER REDEFINES SM5F.
               03  SM5A PIC X.
           02  SM5I PIC X(14).
           02  SD5L PIC S9(04) COMP.
           02  SD5F PIC X.
           02  FILLER REDEFINES SD5F.
               03  SD5A PIC X.
           02  SD5I PIC X(10).
           02  SA6L PIC S9(04) COMP.
           02  SA6F PIC X.
           02  FILLER REDEFINES SA6F.
               03  SA6A PIC X.
           02  SA6I PIC X(11).
           02  SC6L PIC S9(04) COMP.
           02  SC6F PIC X.
           02  FILLER REDEFINES SC6F.
               03  SC6A PIC X.
           02  SC6I PIC X(06).
           02  SO6L PIC S9(04) COMP.
           02  SO6F PIC X.
           02  FILLER REDEFINES SO6F.
               03  SO6A PIC X.
           02  SO6I PIC X(14).
           02  SL6L PIC S9(04) COMP.
           02  SL6F PIC X.
           02  FILLER REDEFINES SL6F.
               03  SL6A PIC X.
           02  SL6I PIC X(14).
           02  SM6L PIC S9(04) COMP.
           02  SM6F PIC X.
           02  FILLER REDEFINES SM6F.
               03  SM6A PIC X.
           02  SM6I PIC X(14).
           02  SD6L PIC S9(04) COMP.
           02  SD6F PIC X.
           02  FILLER REDEFINES SD6F.
               03  SD6A PIC X.
           02  SD6I PIC X(10).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MSTMINAO REDEFINES MSTMINAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  FRACCTO PIC X(11).
           02  FILLER PIC X(03).
           02  FRCYCO PIC X(06).
           02  FILLER PIC X(03).
           02  SA1O PIC X(11).
           02  FILLER PIC X(03).
           02  SC1O PIC X(06).
           02  FILLER PIC X(03).
           02  SO1O PIC X(14).
           02  FILLER PIC X(03).
           02  SL1O PIC X(14).
           02  FILLER PIC X(03).
           02  SM1O PIC X(14).
           02  FILLER PIC X(03).
           02  SD1O PIC X(10).
           02  FILLER PIC X(03).
           02  SA2O PIC X(11).
           02  FILLER PIC X(03).
           02  SC2O PIC X(06).
           02  FILLER PIC X(03).
           02  SO2O PIC X(14).
           02  FILLER PIC X(03).
           02  SL2O PIC X(14).
           02  FILLER PIC X(03).
           02  SM2O PIC X(14).
           02  FILLER PIC X(03).
           02  SD2O PIC X(10).
           02  FILLER PIC X(03).
           02  SA3O PIC X(11).
           02  FILLER PIC X(03).
           02  SC3O PIC X(06).
           02  FILLER PIC X(03).
           02  SO3O PIC X(14).
           02  FILLER PIC X(03).
           02  SL3O PIC X(14).
           02  FILLER PIC X(03).
           02  SM3O PIC X(14).
           02  FILLER PIC X(03).
           02  SD3O PIC X(10).
           02  FILLER PIC X(03).
           02  SA4O PIC X(11).
           02  FILLER PIC X(03).
           02  SC4O PIC X(06).
           02  FILLER PIC X(03).
           02  SO4O PIC X(14).
           02  FILLER PIC X(03).
           02  SL4O PIC X(14).
           02  FILLER PIC X(03).
           02  SM4O PIC X(14).
           02  FILLER PIC X(03).
           02  SD4O PIC X(10).
           02  FILLER PIC X(03).
           02  SA5O PIC X(11).
           02  FILLER PIC X(03).
           02  SC5O PIC X(06).
           02  FILLER PIC X(03).
           02  SO5O PIC X(14).
           02  FILLER PIC X(03).
           02  SL5O PIC X(14).
           02  FILLER PIC X(03).
           02  SM5O PIC X(14).
           02  FILLER PIC X(03).
           02  SD5O PIC X(10).
           02  FILLER PIC X(03).
           02  SA6O PIC X(11).
           02  FILLER PIC X(03).
           02  SC6O PIC X(06).
           02  FILLER PIC X(03).
           02  SO6O PIC X(14).
           02  FILLER PIC X(03).
           02  SL6O PIC X(14).
           02  FILLER PIC X(03).
           02  SM6O PIC X(14).
           02  FILLER PIC X(03).
           02  SD6O PIC X(10).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
