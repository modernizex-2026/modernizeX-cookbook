      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MCUSTU
      *----------------------------------------------------------------
       01  MCUSTUAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  CUSTIDL PIC S9(04) COMP.
           02  CUSTIDF PIC X.
           02  FILLER REDEFINES CUSTIDF.
               03  CUSTIDA PIC X.
           02  CUSTIDI PIC X(09).
           02  CUFNAML PIC S9(04) COMP.
           02  CUFNAMF PIC X.
           02  FILLER REDEFINES CUFNAMF.
               03  CUFNAMA PIC X.
           02  CUFNAMI PIC X(25).
           02  CULNAML PIC S9(04) COMP.
           02  CULNAMF PIC X.
           02  FILLER REDEFINES CULNAMF.
               03  CULNAMA PIC X.
           02  CULNAMI PIC X(25).
           02  CUADDRL PIC S9(04) COMP.
           02  CUADDRF PIC X.
           02  FILLER REDEFINES CUADDRF.
               03  CUADDRA PIC X.
           02  CUADDRI PIC X(50).
           02  CUCITYL PIC S9(04) COMP.
           02  CUCITYF PIC X.
           02  FILLER REDEFINES CUCITYF.
               03  CUCITYA PIC X.
           02  CUCITYI PIC X(50).
           02  CUPHONEL PIC S9(04) COMP.
           02  CUPHONEF PIC X.
           02  FILLER REDEFINES CUPHONEF.
               03  CUPHONEA PIC X.
           02  CUPHONEI PIC X(15).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MCUSTUAO REDEFINES MCUSTUAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CUSTIDO PIC X(09).
           02  FILLER PIC X(03).
           02  CUFNAMO PIC X(25).
           02  FILLER PIC X(03).
           02  CULNAMO PIC X(25).
           02  FILLER PIC X(03).
           02  CUADDRO PIC X(50).
           02  FILLER PIC X(03).
           02  CUCITYO PIC X(50).
           02  FILLER PIC X(03).
           02  CUPHONEO PIC X(15).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
