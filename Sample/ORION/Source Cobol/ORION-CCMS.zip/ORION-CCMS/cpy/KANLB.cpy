      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KANLB : linkage for browse sub OUANLIN
      *  One page of computed analytics rows per EXEC CICS LINK.  The
      *  caller (OCANLIN) sets KAB-MODE and KAB-START-OFF then LINKs
      *  OUANLIN, which scans TRANFILE (and XREF / ACCT as needed),
      *  computes the whole result set for the mode, and returns the
      *  requested page of rows plus two mode-specific grand totals.
      *  Modes : 'RW' rewards  'FR' fraud  'GL' gl-by-type  'RC' recon
      *----------------------------------------------------------------
       01  KANLB-PARM.
           05  KAB-REQUEST.
               10  KAB-MODE          PIC X(02).
               10  KAB-START-OFF     PIC 9(04).
               10  KAB-MAX-ROWS      PIC 9(02).
           05  KAB-RESULT.
               10  KAB-STATUS        PIC X(02).
      *            '00' rows returned  '10' none computed  '99' error
               10  KAB-ROW-CNT       PIC 9(02).
               10  KAB-RESULT-CNT    PIC 9(04).
               10  KAB-SCANNED       PIC 9(09).
               10  KAB-DISC          PIC 9(04).
               10  KAB-MORE          PIC X(01).
           05  KAB-TOTALS.
               10  KAB-TOT-1         PIC S9(15)V99.
               10  KAB-TOT-2         PIC S9(15)V99.
           05  KAB-ROWS.
               10  KAB-ROW OCCURS 6 TIMES.
                   15  KAB-R-KEY     PIC X(16).
                   15  KAB-R-INFO    PIC X(16).
                   15  KAB-R-CNT     PIC 9(09).
                   15  KAB-R-AMT     PIC S9(13)V99.
                   15  KAB-R-VAL     PIC S9(13)V99.
