      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KOPS : batch-operation request/result
      *  --------------------------------------------------------------
      *  Shared LINK interface for the OU* processing SUB-programs
      *  driven by the admin Operations screen (OCOPS, tran OROP).
      *  The area is passed inside the KCOMM commarea CA-WORK-AREA
      *  region (512 bytes); each SUB does
      *      SET ADDRESS OF KOPS-AREA TO ADDRESS OF CA-WORK-AREA
      *  to overlay it, reads KO-REQUEST, performs the job with CICS
      *  file control, and returns counts / status in KO-RESULT.
      *  The count / amount fields are generic; each SUB documents in
      *  its banner exactly which figure it loads into each one.
      *----------------------------------------------------------------
       01  KOPS-AREA.
      *  -- request (screen -> sub) -----------------------------------
           05  KO-REQUEST.
               10  KO-FUNCTION       PIC X(04).
                   88  KO-FN-POST                 VALUE 'POST'.
                   88  KO-FN-PAY                  VALUE 'PAY '.
                   88  KO-FN-INT                  VALUE 'INT '.
                   88  KO-FN-FEE                  VALUE 'FEE '.
                   88  KO-FN-CHGF                 VALUE 'CHGF'.
                   88  KO-FN-CLOS                 VALUE 'CLOS'.
                   88  KO-FN-RNEW                 VALUE 'RNEW'.
                   88  KO-FN-CYCL                 VALUE 'CYCL'.
               10  KO-PARM-ACCT      PIC 9(11).
               10  KO-PARM-CARD      PIC X(16).
               10  KO-PARM-AMT       PIC S9(10)V99.
               10  KO-PARM-DATE      PIC X(10).
      *  -- result (sub -> screen) ------------------------------------
           05  KO-RESULT.
               10  KO-STATUS         PIC X(01).
                   88  KO-OK                      VALUE 'O'.
                   88  KO-WARN                    VALUE 'W'.
                   88  KO-ERROR                   VALUE 'E'.
               10  KO-STATUS-MSG     PIC X(60).
               10  KO-READ-CNT       PIC 9(09).
               10  KO-SELECT-CNT     PIC 9(09).
               10  KO-UPDATE-CNT     PIC 9(09).
               10  KO-POSTED-CNT     PIC 9(09).
               10  KO-REJECT-CNT     PIC 9(09).
               10  KO-SKIP-CNT       PIC 9(09).
               10  KO-TRAN-CNT       PIC 9(09).
               10  KO-C1             PIC 9(09).
               10  KO-C2             PIC 9(09).
               10  KO-C3             PIC 9(09).
               10  KO-AMT-1          PIC S9(13)V99.
               10  KO-AMT-2          PIC S9(13)V99.
               10  KO-AMT-3          PIC S9(13)V99.
           05  FILLER                PIC X(263).
