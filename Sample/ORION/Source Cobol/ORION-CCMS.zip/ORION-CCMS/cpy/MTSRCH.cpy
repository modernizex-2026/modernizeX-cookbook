      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MTSRCH
      *----------------------------------------------------------------
       01  MTSRCHAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  CARDNUML PIC S9(04) COMP.
           02  CARDNUMF PIC X.
           02  FILLER REDEFINES CARDNUMF.
               03  CARDNUMA PIC X.
           02  CARDNUMI PIC X(16).
           02  FRAMTL PIC S9(04) COMP.
           02  FRAMTF PIC X.
           02  FILLER REDEFINES FRAMTF.
               03  FRAMTA PIC X.
           02  FRAMTI PIC X(12).
           02  TOAMTL PIC S9(04) COMP.
           02  TOAMTF PIC X.
           02  FILLER REDEFINES TOAMTF.
               03  TOAMTA PIC X.
           02  TOAMTI PIC X(12).
           02  SR1L PIC S9(04) COMP.
           02  SR1F PIC X.
           02  FILLER REDEFINES SR1F.
               03  SR1A PIC X.
           02  SR1I PIC X(70).
           02  SR2L PIC S9(04) COMP.
           02  SR2F PIC X.
           02  FILLER REDEFINES SR2F.
               03  SR2A PIC X.
           02  SR2I PIC X(70).
           02  SR3L PIC S9(04) COMP.
           02  SR3F PIC X.
           02  FILLER REDEFINES SR3F.
               03  SR3A PIC X.
           02  SR3I PIC X(70).
           02  SR4L PIC S9(04) COMP.
           02  SR4F PIC X.
           02  FILLER REDEFINES SR4F.
               03  SR4A PIC X.
           02  SR4I PIC X(70).
           02  SR5L PIC S9(04) COMP.
           02  SR5F PIC X.
           02  FILLER REDEFINES SR5F.
               03  SR5A PIC X.
           02  SR5I PIC X(70).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MTSRCHAO REDEFINES MTSRCHAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CARDNUMO PIC X(16).
           02  FILLER PIC X(03).
           02  FRAMTO PIC X(12).
           02  FILLER PIC X(03).
           02  TOAMTO PIC X(12).
           02  FILLER PIC X(03).
           02  SR1O PIC X(70).
           02  FILLER PIC X(03).
           02  SR2O PIC X(70).
           02  FILLER PIC X(03).
           02  SR3O PIC X(70).
           02  FILLER PIC X(03).
           02  SR4O PIC X(70).
           02  FILLER PIC X(03).
           02  SR5O PIC X(70).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
