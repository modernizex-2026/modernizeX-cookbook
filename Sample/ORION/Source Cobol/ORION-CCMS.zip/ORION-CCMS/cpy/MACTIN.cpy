      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MACTIN
      *----------------------------------------------------------------
       01  MACTINAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  FILTL PIC S9(04) COMP.
           02  FILTF PIC X.
           02  FILLER REDEFINES FILTF.
               03  FILTA PIC X.
           02  FILTI PIC X(10).
           02  FDESCL PIC S9(04) COMP.
           02  FDESCF PIC X.
           02  FILLER REDEFINES FDESCF.
               03  FDESCA PIC X.
           02  FDESCI PIC X(12).
           02  AID1L PIC S9(04) COMP.
           02  AID1F PIC X.
           02  FILLER REDEFINES AID1F.
               03  AID1A PIC X.
           02  AID1I PIC X(11).
           02  AST1L PIC S9(04) COMP.
           02  AST1F PIC X.
           02  FILLER REDEFINES AST1F.
               03  AST1A PIC X.
           02  AST1I PIC X(01).
           02  ABL1L PIC S9(04) COMP.
           02  ABL1F PIC X.
           02  FILLER REDEFINES ABL1F.
               03  ABL1A PIC X.
           02  ABL1I PIC X(15).
           02  ALM1L PIC S9(04) COMP.
           02  ALM1F PIC X.
           02  FILLER REDEFINES ALM1F.
               03  ALM1A PIC X.
           02  ALM1I PIC X(15).
           02  AAV1L PIC S9(04) COMP.
           02  AAV1F PIC X.
           02  FILLER REDEFINES AAV1F.
               03  AAV1A PIC X.
           02  AAV1I PIC X(15).
           02  AUT1L PIC S9(04) COMP.
           02  AUT1F PIC X.
           02  FILLER REDEFINES AUT1F.
               03  AUT1A PIC X.
           02  AUT1I PIC X(06).
           02  AID2L PIC S9(04) COMP.
           02  AID2F PIC X.
           02  FILLER REDEFINES AID2F.
               03  AID2A PIC X.
           02  AID2I PIC X(11).
           02  AST2L PIC S9(04) COMP.
           02  AST2F PIC X.
           02  FILLER REDEFINES AST2F.
               03  AST2A PIC X.
           02  AST2I PIC X(01).
           02  ABL2L PIC S9(04) COMP.
           02  ABL2F PIC X.
           02  FILLER REDEFINES ABL2F.
               03  ABL2A PIC X.
           02  ABL2I PIC X(15).
           02  ALM2L PIC S9(04) COMP.
           02  ALM2F PIC X.
           02  FILLER REDEFINES ALM2F.
               03  ALM2A PIC X.
           02  ALM2I PIC X(15).
           02  AAV2L PIC S9(04) COMP.
           02  AAV2F PIC X.
           02  FILLER REDEFINES AAV2F.
               03  AAV2A PIC X.
           02  AAV2I PIC X(15).
           02  AUT2L PIC S9(04) COMP.
           02  AUT2F PIC X.
           02  FILLER REDEFINES AUT2F.
               03  AUT2A PIC X.
           02  AUT2I PIC X(06).
           02  AID3L PIC S9(04) COMP.
           02  AID3F PIC X.
           02  FILLER REDEFINES AID3F.
               03  AID3A PIC X.
           02  AID3I PIC X(11).
           02  AST3L PIC S9(04) COMP.
           02  AST3F PIC X.
           02  FILLER REDEFINES AST3F.
               03  AST3A PIC X.
           02  AST3I PIC X(01).
           02  ABL3L PIC S9(04) COMP.
           02  ABL3F PIC X.
           02  FILLER REDEFINES ABL3F.
               03  ABL3A PIC X.
           02  ABL3I PIC X(15).
           02  ALM3L PIC S9(04) COMP.
           02  ALM3F PIC X.
           02  FILLER REDEFINES ALM3F.
               03  ALM3A PIC X.
           02  ALM3I PIC X(15).
           02  AAV3L PIC S9(04) COMP.
           02  AAV3F PIC X.
           02  FILLER REDEFINES AAV3F.
               03  AAV3A PIC X.
           02  AAV3I PIC X(15).
           02  AUT3L PIC S9(04) COMP.
           02  AUT3F PIC X.
           02  FILLER REDEFINES AUT3F.
               03  AUT3A PIC X.
           02  AUT3I PIC X(06).
           02  AID4L PIC S9(04) COMP.
           02  AID4F PIC X.
           02  FILLER REDEFINES AID4F.
               03  AID4A PIC X.
           02  AID4I PIC X(11).
           02  AST4L PIC S9(04) COMP.
           02  AST4F PIC X.
           02  FILLER REDEFINES AST4F.
               03  AST4A PIC X.
           02  AST4I PIC X(01).
           02  ABL4L PIC S9(04) COMP.
           02  ABL4F PIC X.
           02  FILLER REDEFINES ABL4F.
               03  ABL4A PIC X.
           02  ABL4I PIC X(15).
           02  ALM4L PIC S9(04) COMP.
           02  ALM4F PIC X.
           02  FILLER REDEFINES ALM4F.
               03  ALM4A PIC X.
           02  ALM4I PIC X(15).
           02  AAV4L PIC S9(04) COMP.
           02  AAV4F PIC X.
           02  FILLER REDEFINES AAV4F.
               03  AAV4A PIC X.
           02  AAV4I PIC X(15).
           02  AUT4L PIC S9(04) COMP.
           02  AUT4F PIC X.
           02  FILLER REDEFINES AUT4F.
               03  AUT4A PIC X.
           02  AUT4I PIC X(06).
           02  AID5L PIC S9(04) COMP.
           02  AID5F PIC X.
           02  FILLER REDEFINES AID5F.
               03  AID5A PIC X.
           02  AID5I PIC X(11).
           02  AST5L PIC S9(04) COMP.
           02  AST5F PIC X.
           02  FILLER REDEFINES AST5F.
               03  AST5A PIC X.
           02  AST5I PIC X(01).
           02  ABL5L PIC S9(04) COMP.
           02  ABL5F PIC X.
           02  FILLER REDEFINES ABL5F.
               03  ABL5A PIC X.
           02  ABL5I PIC X(15).
           02  ALM5L PIC S9(04) COMP.
           02  ALM5F PIC X.
           02  FILLER REDEFINES ALM5F.
               03  ALM5A PIC X.
           02  ALM5I PIC X(15).
           02  AAV5L PIC S9(04) COMP.
           02  AAV5F PIC X.
           02  FILLER REDEFINES AAV5F.
               03  AAV5A PIC X.
           02  AAV5I PIC X(15).
           02  AUT5L PIC S9(04) COMP.
           02  AUT5F PIC X.
           02  FILLER REDEFINES AUT5F.
               03  AUT5A PIC X.
           02  AUT5I PIC X(06).
           02  AID6L PIC S9(04) COMP.
           02  AID6F PIC X.
           02  FILLER REDEFINES AID6F.
               03  AID6A PIC X.
           02  AID6I PIC X(11).
           02  AST6L PIC S9(04) COMP.
           02  AST6F PIC X.
           02  FILLER REDEFINES AST6F.
               03  AST6A PIC X.
           02  AST6I PIC X(01).
           02  ABL6L PIC S9(04) COMP.
           02  ABL6F PIC X.
           02  FILLER REDEFINES ABL6F.
               03  ABL6A PIC X.
           02  ABL6I PIC X(15).
           02  ALM6L PIC S9(04) COMP.
           02  ALM6F PIC X.
           02  FILLER REDEFINES ALM6F.
               03  ALM6A PIC X.
           02  ALM6I PIC X(15).
           02  AAV6L PIC S9(04) COMP.
           02  AAV6F PIC X.
           02  FILLER REDEFINES AAV6F.
               03  AAV6A PIC X.
           02  AAV6I PIC X(15).
           02  AUT6L PIC S9(04) COMP.
           02  AUT6F PIC X.
           02  FILLER REDEFINES AUT6F.
               03  AUT6A PIC X.
           02  AUT6I PIC X(06).
           02  AID7L PIC S9(04) COMP.
           02  AID7F PIC X.
           02  FILLER REDEFINES AID7F.
               03  AID7A PIC X.
           02  AID7I PIC X(11).
           02  AST7L PIC S9(04) COMP.
           02  AST7F PIC X.
           02  FILLER REDEFINES AST7F.
               03  AST7A PIC X.
           02  AST7I PIC X(01).
           02  ABL7L PIC S9(04) COMP.
           02  ABL7F PIC X.
           02  FILLER REDEFINES ABL7F.
               03  ABL7A PIC X.
           02  ABL7I PIC X(15).
           02  ALM7L PIC S9(04) COMP.
           02  ALM7F PIC X.
           02  FILLER REDEFINES ALM7F.
               03  ALM7A PIC X.
           02  ALM7I PIC X(15).
           02  AAV7L PIC S9(04) COMP.
           02  AAV7F PIC X.
           02  FILLER REDEFINES AAV7F.
               03  AAV7A PIC X.
           02  AAV7I PIC X(15).
           02  AUT7L PIC S9(04) COMP.
           02  AUT7F PIC X.
           02  FILLER REDEFINES AUT7F.
               03  AUT7A PIC X.
           02  AUT7I PIC X(06).
           02  AID8L PIC S9(04) COMP.
           02  AID8F PIC X.
           02  FILLER REDEFINES AID8F.
               03  AID8A PIC X.
           02  AID8I PIC X(11).
           02  AST8L PIC S9(04) COMP.
           02  AST8F PIC X.
           02  FILLER REDEFINES AST8F.
               03  AST8A PIC X.
           02  AST8I PIC X(01).
           02  ABL8L PIC S9(04) COMP.
           02  ABL8F PIC X.
           02  FILLER REDEFINES ABL8F.
               03  ABL8A PIC X.
           02  ABL8I PIC X(15).
           02  ALM8L PIC S9(04) COMP.
           02  ALM8F PIC X.
           02  FILLER REDEFINES ALM8F.
               03  ALM8A PIC X.
           02  ALM8I PIC X(15).
           02  AAV8L PIC S9(04) COMP.
           02  AAV8F PIC X.
           02  FILLER REDEFINES AAV8F.
               03  AAV8A PIC X.
           02  AAV8I PIC X(15).
           02  AUT8L PIC S9(04) COMP.
           02  AUT8F PIC X.
           02  FILLER REDEFINES AUT8F.
               03  AUT8A PIC X.
           02  AUT8I PIC X(06).
           02  AID9L PIC S9(04) COMP.
           02  AID9F PIC X.
           02  FILLER REDEFINES AID9F.
               03  AID9A PIC X.
           02  AID9I PIC X(11).
           02  AST9L PIC S9(04) COMP.
           02  AST9F PIC X.
           02  FILLER REDEFINES AST9F.
               03  AST9A PIC X.
           02  AST9I PIC X(01).
           02  ABL9L PIC S9(04) COMP.
           02  ABL9F PIC X.
           02  FILLER REDEFINES ABL9F.
               03  ABL9A PIC X.
           02  ABL9I PIC X(15).
           02  ALM9L PIC S9(04) COMP.
           02  ALM9F PIC X.
           02  FILLER REDEFINES ALM9F.
               03  ALM9A PIC X.
           02  ALM9I PIC X(15).
           02  AAV9L PIC S9(04) COMP.
           02  AAV9F PIC X.
           02  FILLER REDEFINES AAV9F.
               03  AAV9A PIC X.
           02  AAV9I PIC X(15).
           02  AUT9L PIC S9(04) COMP.
           02  AUT9F PIC X.
           02  FILLER REDEFINES AUT9F.
               03  AUT9A PIC X.
           02  AUT9I PIC X(06).
           02  AID10L PIC S9(04) COMP.
           02  AID10F PIC X.
           02  FILLER REDEFINES AID10F.
               03  AID10A PIC X.
           02  AID10I PIC X(11).
           02  AST10L PIC S9(04) COMP.
           02  AST10F PIC X.
           02  FILLER REDEFINES AST10F.
               03  AST10A PIC X.
           02  AST10I PIC X(01).
           02  ABL10L PIC S9(04) COMP.
           02  ABL10F PIC X.
           02  FILLER REDEFINES ABL10F.
               03  ABL10A PIC X.
           02  ABL10I PIC X(15).
           02  ALM10L PIC S9(04) COMP.
           02  ALM10F PIC X.
           02  FILLER REDEFINES ALM10F.
               03  ALM10A PIC X.
           02  ALM10I PIC X(15).
           02  AAV10L PIC S9(04) COMP.
           02  AAV10F PIC X.
           02  FILLER REDEFINES AAV10F.
               03  AAV10A PIC X.
           02  AAV10I PIC X(15).
           02  AUT10L PIC S9(04) COMP.
           02  AUT10F PIC X.
           02  FILLER REDEFINES AUT10F.
               03  AUT10A PIC X.
           02  AUT10I PIC X(06).
           02  AID11L PIC S9(04) COMP.
           02  AID11F PIC X.
           02  FILLER REDEFINES AID11F.
               03  AID11A PIC X.
           02  AID11I PIC X(11).
           02  AST11L PIC S9(04) COMP.
           02  AST11F PIC X.
           02  FILLER REDEFINES AST11F.
               03  AST11A PIC X.
           02  AST11I PIC X(01).
           02  ABL11L PIC S9(04) COMP.
           02  ABL11F PIC X.
           02  FILLER REDEFINES ABL11F.
               03  ABL11A PIC X.
           02  ABL11I PIC X(15).
           02  ALM11L PIC S9(04) COMP.
           02  ALM11F PIC X.
           02  FILLER REDEFINES ALM11F.
               03  ALM11A PIC X.
           02  ALM11I PIC X(15).
           02  AAV11L PIC S9(04) COMP.
           02  AAV11F PIC X.
           02  FILLER REDEFINES AAV11F.
               03  AAV11A PIC X.
           02  AAV11I PIC X(15).
           02  AUT11L PIC S9(04) COMP.
           02  AUT11F PIC X.
           02  FILLER REDEFINES AUT11F.
               03  AUT11A PIC X.
           02  AUT11I PIC X(06).
           02  AID12L PIC S9(04) COMP.
           02  AID12F PIC X.
           02  FILLER REDEFINES AID12F.
               03  AID12A PIC X.
           02  AID12I PIC X(11).
           02  AST12L PIC S9(04) COMP.
           02  AST12F PIC X.
           02  FILLER REDEFINES AST12F.
               03  AST12A PIC X.
           02  AST12I PIC X(01).
           02  ABL12L PIC S9(04) COMP.
           02  ABL12F PIC X.
           02  FILLER REDEFINES ABL12F.
               03  ABL12A PIC X.
           02  ABL12I PIC X(15).
           02  ALM12L PIC S9(04) COMP.
           02  ALM12F PIC X.
           02  FILLER REDEFINES ALM12F.
               03  ALM12A PIC X.
           02  ALM12I PIC X(15).
           02  AAV12L PIC S9(04) COMP.
           02  AAV12F PIC X.
           02  FILLER REDEFINES AAV12F.
               03  AAV12A PIC X.
           02  AAV12I PIC X(15).
           02  AUT12L PIC S9(04) COMP.
           02  AUT12F PIC X.
           02  FILLER REDEFINES AUT12F.
               03  AUT12A PIC X.
           02  AUT12I PIC X(06).
           02  AID13L PIC S9(04) COMP.
           02  AID13F PIC X.
           02  FILLER REDEFINES AID13F.
               03  AID13A PIC X.
           02  AID13I PIC X(11).
           02  AST13L PIC S9(04) COMP.
           02  AST13F PIC X.
           02  FILLER REDEFINES AST13F.
               03  AST13A PIC X.
           02  AST13I PIC X(01).
           02  ABL13L PIC S9(04) COMP.
           02  ABL13F PIC X.
           02  FILLER REDEFINES ABL13F.
               03  ABL13A PIC X.
           02  ABL13I PIC X(15).
           02  ALM13L PIC S9(04) COMP.
           02  ALM13F PIC X.
           02  FILLER REDEFINES ALM13F.
               03  ALM13A PIC X.
           02  ALM13I PIC X(15).
           02  AAV13L PIC S9(04) COMP.
           02  AAV13F PIC X.
           02  FILLER REDEFINES AAV13F.
               03  AAV13A PIC X.
           02  AAV13I PIC X(15).
           02  AUT13L PIC S9(04) COMP.
           02  AUT13F PIC X.
           02  FILLER REDEFINES AUT13F.
               03  AUT13A PIC X.
           02  AUT13I PIC X(06).
           02  PAGENOL PIC S9(04) COMP.
           02  PAGENOF PIC X.
           02  FILLER REDEFINES PAGENOF.
               03  PAGENOA PIC X.
           02  PAGENOI PIC X(03).
           02  RUNTOTL PIC S9(04) COMP.
           02  RUNTOTF PIC X.
           02  FILLER REDEFINES RUNTOTF.
               03  RUNTOTA PIC X.
           02  RUNTOTI PIC X(07).
           02  PGBALL PIC S9(04) COMP.
           02  PGBALF PIC X.
           02  FILLER REDEFINES PGBALF.
               03  PGBALA PIC X.
           02  PGBALI PIC X(20).
           02  PGAVLL PIC S9(04) COMP.
           02  PGAVLF PIC X.
           02  FILLER REDEFINES PGAVLF.
               03  PGAVLA PIC X.
           02  PGAVLI PIC X(20).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MACTINAO REDEFINES MACTINAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  FILTO PIC X(10).
           02  FILLER PIC X(03).
           02  FDESCO PIC X(12).
           02  FILLER PIC X(03).
           02  AID1O PIC X(11).
           02  FILLER PIC X(03).
           02  AST1O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL1O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM1O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV1O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT1O PIC X(06).
           02  FILLER PIC X(03).
           02  AID2O PIC X(11).
           02  FILLER PIC X(03).
           02  AST2O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL2O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM2O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV2O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT2O PIC X(06).
           02  FILLER PIC X(03).
           02  AID3O PIC X(11).
           02  FILLER PIC X(03).
           02  AST3O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL3O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM3O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV3O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT3O PIC X(06).
           02  FILLER PIC X(03).
           02  AID4O PIC X(11).
           02  FILLER PIC X(03).
           02  AST4O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL4O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM4O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV4O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT4O PIC X(06).
           02  FILLER PIC X(03).
           02  AID5O PIC X(11).
           02  FILLER PIC X(03).
           02  AST5O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL5O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM5O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV5O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT5O PIC X(06).
           02  FILLER PIC X(03).
           02  AID6O PIC X(11).
           02  FILLER PIC X(03).
           02  AST6O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL6O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM6O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV6O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT6O PIC X(06).
           02  FILLER PIC X(03).
           02  AID7O PIC X(11).
           02  FILLER PIC X(03).
           02  AST7O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL7O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM7O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV7O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT7O PIC X(06).
           02  FILLER PIC X(03).
           02  AID8O PIC X(11).
           02  FILLER PIC X(03).
           02  AST8O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL8O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM8O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV8O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT8O PIC X(06).
           02  FILLER PIC X(03).
           02  AID9O PIC X(11).
           02  FILLER PIC X(03).
           02  AST9O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL9O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM9O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV9O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT9O PIC X(06).
           02  FILLER PIC X(03).
           02  AID10O PIC X(11).
           02  FILLER PIC X(03).
           02  AST10O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL10O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM10O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV10O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT10O PIC X(06).
           02  FILLER PIC X(03).
           02  AID11O PIC X(11).
           02  FILLER PIC X(03).
           02  AST11O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL11O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM11O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV11O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT11O PIC X(06).
           02  FILLER PIC X(03).
           02  AID12O PIC X(11).
           02  FILLER PIC X(03).
           02  AST12O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL12O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM12O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV12O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT12O PIC X(06).
           02  FILLER PIC X(03).
           02  AID13O PIC X(11).
           02  FILLER PIC X(03).
           02  AST13O PIC X(01).
           02  FILLER PIC X(03).
           02  ABL13O PIC X(15).
           02  FILLER PIC X(03).
           02  ALM13O PIC X(15).
           02  FILLER PIC X(03).
           02  AAV13O PIC X(15).
           02  FILLER PIC X(03).
           02  AUT13O PIC X(06).
           02  FILLER PIC X(03).
           02  PAGENOO PIC X(03).
           02  FILLER PIC X(03).
           02  RUNTOTO PIC X(07).
           02  FILLER PIC X(03).
           02  PGBALO PIC X(20).
           02  FILLER PIC X(03).
           02  PGAVLO PIC X(20).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
