      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RUSER : User security record
      *----------------------------------------------------------------
       01  USER-REC.
           05  US-ID               PIC X(08).
           05  US-FIRST-NAME       PIC X(20).
           05  US-LAST-NAME        PIC X(20).
           05  US-PASSWORD         PIC X(08).
           05  US-TYPE             PIC X(01).
           05  FILLER              PIC X(23).
