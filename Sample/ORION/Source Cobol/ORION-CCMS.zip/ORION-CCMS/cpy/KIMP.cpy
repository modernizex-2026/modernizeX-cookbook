      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KIMP : linkage for sub OUIMP
      *  Request / result block for the on-line account import utility.
      *  The staged feed is the KSDS IMPFILE (key IMP-KEY); each record
      *  carries one CSV-style account line.  Overlaid on CA-WORK-AREA.
      *----------------------------------------------------------------
       01  KIM-PARM.
           05  KIM-REQUEST.
               10  KIM-START-KEY     PIC X(08).
      *            resume staging key (spaces = from start of file)
               10  KIM-MAX           PIC 9(07).
      *            max staged lines to apply this run (0 = no cap)
           05  KIM-RESULT.
               10  KIM-STATUS        PIC X(02).
               10  KIM-MSG           PIC X(50).
               10  KIM-READ          PIC 9(07).
               10  KIM-ADDED         PIC 9(07).
               10  KIM-UPDATED       PIC 9(07).
               10  KIM-ACCEPTED      PIC 9(07).
               10  KIM-REJECTED      PIC 9(07).
               10  KIM-SKIPPED       PIC 9(07).
               10  KIM-ERRORS        PIC 9(07).
               10  KIM-LAST-REASON   PIC X(20).
               10  KIM-LAST-KEY      PIC X(08).
               10  KIM-NEXT-KEY      PIC X(08).
               10  KIM-MORE          PIC X(01).
