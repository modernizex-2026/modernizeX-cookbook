      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MANLIN
      *----------------------------------------------------------------
       01  MANLINAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  ANMODEL PIC S9(04) COMP.
           02  ANMODEF PIC X.
           02  FILLER REDEFINES ANMODEF.
               03  ANMODEA PIC X.
           02  ANMODEI PIC X(07).
           02  ANHEADL PIC S9(04) COMP.
           02  ANHEADF PIC X.
           02  FILLER REDEFINES ANHEADF.
               03  ANHEADA PIC X.
           02  ANHEADI PIC X(60).
           02  ANK1L PIC S9(04) COMP.
           02  ANK1F PIC X.
           02  FILLER REDEFINES ANK1F.
               03  ANK1A PIC X.
           02  ANK1I PIC X(16).
           02  ANI1L PIC S9(04) COMP.
           02  ANI1F PIC X.
           02  FILLER REDEFINES ANI1F.
               03  ANI1A PIC X.
           02  ANI1I PIC X(10).
           02  ANC1L PIC S9(04) COMP.
           02  ANC1F PIC X.
           02  FILLER REDEFINES ANC1F.
               03  ANC1A PIC X.
           02  ANC1I PIC X(09).
           02  ANA1L PIC S9(04) COMP.
           02  ANA1F PIC X.
           02  FILLER REDEFINES ANA1F.
               03  ANA1A PIC X.
           02  ANA1I PIC X(14).
           02  ANV1L PIC S9(04) COMP.
           02  ANV1F PIC X.
           02  FILLER REDEFINES ANV1F.
               03  ANV1A PIC X.
           02  ANV1I PIC X(14).
           02  ANK2L PIC S9(04) COMP.
           02  ANK2F PIC X.
           02  FILLER REDEFINES ANK2F.
               03  ANK2A PIC X.
           02  ANK2I PIC X(16).
           02  ANI2L PIC S9(04) COMP.
           02  ANI2F PIC X.
           02  FILLER REDEFINES ANI2F.
               03  ANI2A PIC X.
           02  ANI2I PIC X(10).
           02  ANC2L PIC S9(04) COMP.
           02  ANC2F PIC X.
           02  FILLER REDEFINES ANC2F.
               03  ANC2A PIC X.
           02  ANC2I PIC X(09).
           02  ANA2L PIC S9(04) COMP.
           02  ANA2F PIC X.
           02  FILLER REDEFINES ANA2F.
               03  ANA2A PIC X.
           02  ANA2I PIC X(14).
           02  ANV2L PIC S9(04) COMP.
           02  ANV2F PIC X.
           02  FILLER REDEFINES ANV2F.
               03  ANV2A PIC X.
           02  ANV2I PIC X(14).
           02  ANK3L PIC S9(04) COMP.
           02  ANK3F PIC X.
           02  FILLER REDEFINES ANK3F.
               03  ANK3A PIC X.
           02  ANK3I PIC X(16).
           02  ANI3L PIC S9(04) COMP.
           02  ANI3F PIC X.
           02  FILLER REDEFINES ANI3F.
               03  ANI3A PIC X.
           02  ANI3I PIC X(10).
           02  ANC3L PIC S9(04) COMP.
           02  ANC3F PIC X.
           02  FILLER REDEFINES ANC3F.
               03  ANC3A PIC X.
           02  ANC3I PIC X(09).
           02  ANA3L PIC S9(04) COMP.
           02  ANA3F PIC X.
           02  FILLER REDEFINES ANA3F.
               03  ANA3A PIC X.
           02  ANA3I PIC X(14).
           02  ANV3L PIC S9(04) COMP.
           02  ANV3F PIC X.
           02  FILLER REDEFINES ANV3F.
               03  ANV3A PIC X.
           02  ANV3I PIC X(14).
           02  ANK4L PIC S9(04) COMP.
           02  ANK4F PIC X.
           02  FILLER REDEFINES ANK4F.
               03  ANK4A PIC X.
           02  ANK4I PIC X(16).
           02  ANI4L PIC S9(04) COMP.
           02  ANI4F PIC X.
           02  FILLER REDEFINES ANI4F.
               03  ANI4A PIC X.
           02  ANI4I PIC X(10).
           02  ANC4L PIC S9(04) COMP.
           02  ANC4F PIC X.
           02  FILLER REDEFINES ANC4F.
               03  ANC4A PIC X.
           02  ANC4I PIC X(09).
           02  ANA4L PIC S9(04) COMP.
           02  ANA4F PIC X.
           02  FILLER REDEFINES ANA4F.
               03  ANA4A PIC X.
           02  ANA4I PIC X(14).
           02  ANV4L PIC S9(04) COMP.
           02  ANV4F PIC X.
           02  FILLER REDEFINES ANV4F.
               03  ANV4A PIC X.
           02  ANV4I PIC X(14).
           02  ANK5L PIC S9(04) COMP.
           02  ANK5F PIC X.
           02  FILLER REDEFINES ANK5F.
               03  ANK5A PIC X.
           02  ANK5I PIC X(16).
           02  ANI5L PIC S9(04) COMP.
           02  ANI5F PIC X.
           02  FILLER REDEFINES ANI5F.
               03  ANI5A PIC X.
           02  ANI5I PIC X(10).
           02  ANC5L PIC S9(04) COMP.
           02  ANC5F PIC X.
           02  FILLER REDEFINES ANC5F.
               03  ANC5A PIC X.
           02  ANC5I PIC X(09).
           02  ANA5L PIC S9(04) COMP.
           02  ANA5F PIC X.
           02  FILLER REDEFINES ANA5F.
               03  ANA5A PIC X.
           02  ANA5I PIC X(14).
           02  ANV5L PIC S9(04) COMP.
           02  ANV5F PIC X.
           02  FILLER REDEFINES ANV5F.
               03  ANV5A PIC X.
           02  ANV5I PIC X(14).
           02  ANK6L PIC S9(04) COMP.
           02  ANK6F PIC X.
           02  FILLER REDEFINES ANK6F.
               03  ANK6A PIC X.
           02  ANK6I PIC X(16).
           02  ANI6L PIC S9(04) COMP.
           02  ANI6F PIC X.
           02  FILLER REDEFINES ANI6F.
               03  ANI6A PIC X.
           02  ANI6I PIC X(10).
           02  ANC6L PIC S9(04) COMP.
           02  ANC6F PIC X.
           02  FILLER REDEFINES ANC6F.
               03  ANC6A PIC X.
           02  ANC6I PIC X(09).
           02  ANA6L PIC S9(04) COMP.
           02  ANA6F PIC X.
           02  FILLER REDEFINES ANA6F.
               03  ANA6A PIC X.
           02  ANA6I PIC X(14).
           02  ANV6L PIC S9(04) COMP.
           02  ANV6F PIC X.
           02  FILLER REDEFINES ANV6F.
               03  ANV6A PIC X.
           02  ANV6I PIC X(14).
           02  ANTOT1L PIC S9(04) COMP.
           02  ANTOT1F PIC X.
           02  FILLER REDEFINES ANTOT1F.
               03  ANTOT1A PIC X.
           02  ANTOT1I PIC X(78).
           02  ANTOT2L PIC S9(04) COMP.
           02  ANTOT2F PIC X.
           02  FILLER REDEFINES ANTOT2F.
               03  ANTOT2A PIC X.
           02  ANTOT2I PIC X(78).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MANLINAO REDEFINES MANLINAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  ANMODEO PIC X(07).
           02  FILLER PIC X(03).
           02  ANHEADO PIC X(60).
           02  FILLER PIC X(03).
           02  ANK1O PIC X(16).
           02  FILLER PIC X(03).
           02  ANI1O PIC X(10).
           02  FILLER PIC X(03).
           02  ANC1O PIC X(09).
           02  FILLER PIC X(03).
           02  ANA1O PIC X(14).
           02  FILLER PIC X(03).
           02  ANV1O PIC X(14).
           02  FILLER PIC X(03).
           02  ANK2O PIC X(16).
           02  FILLER PIC X(03).
           02  ANI2O PIC X(10).
           02  FILLER PIC X(03).
           02  ANC2O PIC X(09).
           02  FILLER PIC X(03).
           02  ANA2O PIC X(14).
           02  FILLER PIC X(03).
           02  ANV2O PIC X(14).
           02  FILLER PIC X(03).
           02  ANK3O PIC X(16).
           02  FILLER PIC X(03).
           02  ANI3O PIC X(10).
           02  FILLER PIC X(03).
           02  ANC3O PIC X(09).
           02  FILLER PIC X(03).
           02  ANA3O PIC X(14).
           02  FILLER PIC X(03).
           02  ANV3O PIC X(14).
           02  FILLER PIC X(03).
           02  ANK4O PIC X(16).
           02  FILLER PIC X(03).
           02  ANI4O PIC X(10).
           02  FILLER PIC X(03).
           02  ANC4O PIC X(09).
           02  FILLER PIC X(03).
           02  ANA4O PIC X(14).
           02  FILLER PIC X(03).
           02  ANV4O PIC X(14).
           02  FILLER PIC X(03).
           02  ANK5O PIC X(16).
           02  FILLER PIC X(03).
           02  ANI5O PIC X(10).
           02  FILLER PIC X(03).
           02  ANC5O PIC X(09).
           02  FILLER PIC X(03).
           02  ANA5O PIC X(14).
           02  FILLER PIC X(03).
           02  ANV5O PIC X(14).
           02  FILLER PIC X(03).
           02  ANK6O PIC X(16).
           02  FILLER PIC X(03).
           02  ANI6O PIC X(10).
           02  FILLER PIC X(03).
           02  ANC6O PIC X(09).
           02  FILLER PIC X(03).
           02  ANA6O PIC X(14).
           02  FILLER PIC X(03).
           02  ANV6O PIC X(14).
           02  FILLER PIC X(03).
           02  ANTOT1O PIC X(78).
           02  FILLER PIC X(03).
           02  ANTOT2O PIC X(78).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
