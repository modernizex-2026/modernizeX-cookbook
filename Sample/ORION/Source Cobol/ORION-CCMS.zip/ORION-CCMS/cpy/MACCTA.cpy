      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MACCTA
      *----------------------------------------------------------------
       01  MACCTAAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  ACCTIDL PIC S9(04) COMP.
           02  ACCTIDF PIC X.
           02  FILLER REDEFINES ACCTIDF.
               03  ACCTIDA PIC X.
           02  ACCTIDI PIC X(11).
           02  CUSTIDL PIC S9(04) COMP.
           02  CUSTIDF PIC X.
           02  FILLER REDEFINES CUSTIDF.
               03  CUSTIDA PIC X.
           02  CUSTIDI PIC X(09).
           02  ACCRLIML PIC S9(04) COMP.
           02  ACCRLIMF PIC X.
           02  FILLER REDEFINES ACCRLIMF.
               03  ACCRLIMA PIC X.
           02  ACCRLIMI PIC X(13).
           02  ACCSLIML PIC S9(04) COMP.
           02  ACCSLIMF PIC X.
           02  FILLER REDEFINES ACCSLIMF.
               03  ACCSLIMA PIC X.
           02  ACCSLIMI PIC X(13).
           02  ACOPENL PIC S9(04) COMP.
           02  ACOPENF PIC X.
           02  FILLER REDEFINES ACOPENF.
               03  ACOPENA PIC X.
           02  ACOPENI PIC X(10).
           02  ACGRPL PIC S9(04) COMP.
           02  ACGRPF PIC X.
           02  FILLER REDEFINES ACGRPF.
               03  ACGRPA PIC X.
           02  ACGRPI PIC X(10).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MACCTAAO REDEFINES MACCTAAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  ACCTIDO PIC X(11).
           02  FILLER PIC X(03).
           02  CUSTIDO PIC X(09).
           02  FILLER PIC X(03).
           02  ACCRLIMO PIC X(13).
           02  FILLER PIC X(03).
           02  ACCSLIMO PIC X(13).
           02  FILLER PIC X(03).
           02  ACOPENO PIC X(10).
           02  FILLER PIC X(03).
           02  ACGRPO PIC X(10).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
