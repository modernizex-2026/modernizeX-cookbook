      *----------------------------------------------------------------
      *  ORION-CCMS copybook - WHEAD : screen header work fields
      *  MOVE these into the BMS header fields (TRNNAMEO, TITLE01O,
      *  PGMNAMEO, CURDATEO, CURTIMEO) before EXEC CICS SEND MAP.
      *----------------------------------------------------------------
       01  WS-HEADER.
           05  WS-HDR-TITLE         PIC X(40)
               VALUE 'ORION CREDIT CARD MANAGEMENT SYSTEM'.
           05  WS-HDR-TRANID        PIC X(04) VALUE SPACES.
           05  WS-HDR-PGMNAME       PIC X(08) VALUE SPACES.
           05  WS-HDR-DATE          PIC X(10) VALUE SPACES.
           05  WS-HDR-TIME          PIC X(08) VALUE SPACES.
       01  WS-CURRENT-DATE-TIME.
           05  WS-CDT-DATE.
               10  WS-CDT-YYYY      PIC 9(04).
               10  WS-CDT-MM        PIC 9(02).
               10  WS-CDT-DD        PIC 9(02).
           05  WS-CDT-TIME.
               10  WS-CDT-HH        PIC 9(02).
               10  WS-CDT-MI        PIC 9(02).
               10  WS-CDT-SS        PIC 9(02).
