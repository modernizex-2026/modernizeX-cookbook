      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KCOMM : shared CICS COMMAREA
      *  Passed on every EXEC CICS RETURN TRANSID / XCTL.
      *----------------------------------------------------------------
       01  ORION-COMMAREA.
           05  CA-GENERAL.
               10  CA-FROM-PROGRAM   PIC X(08).
               10  CA-TO-PROGRAM     PIC X(08).
               10  CA-FROM-TRANID    PIC X(04).
               10  CA-TO-TRANID      PIC X(04).
               10  CA-USER-ID        PIC X(08).
               10  CA-USER-TYPE      PIC X(01).
                   88  CA-USER-ADMIN               VALUE 'A'.
                   88  CA-USER-NORMAL              VALUE 'U'.
               10  CA-PGM-CONTEXT    PIC 9(01).
                   88  CA-FIRST-ENTER              VALUE 0.
                   88  CA-RE-ENTER                 VALUE 1.
               10  CA-LAST-MAP       PIC X(07).
               10  CA-LAST-MAPSET    PIC X(06).
           05  CA-SELECTED.
               10  CA-ACCT-ID        PIC 9(11).
               10  CA-CARD-NUM       PIC X(16).
               10  CA-CUST-ID        PIC 9(09).
               10  CA-TRAN-ID        PIC X(16).
           05  CA-ERROR.
               10  CA-ERR-FLG        PIC X(01).
                   88  CA-ERR-ON                   VALUE 'Y'.
                   88  CA-ERR-OFF                  VALUE 'N'.
               10  CA-ERR-MSG        PIC X(80).
           05  CA-WORK-AREA          PIC X(512).
