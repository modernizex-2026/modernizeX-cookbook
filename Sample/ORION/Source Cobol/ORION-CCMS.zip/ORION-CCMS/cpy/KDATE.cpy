      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KDATE : linkage for subroutine OUDATE
      *----------------------------------------------------------------
       01  KDATE-PARM.
           05  KD-FUNC              PIC X(04).
      *        'VALD' validate  'TODY' current  'FMT ' format
           05  KD-DATE-IN           PIC X(10).
           05  KD-DATE-OUT          PIC X(10).
           05  KD-STATUS            PIC X(02).
