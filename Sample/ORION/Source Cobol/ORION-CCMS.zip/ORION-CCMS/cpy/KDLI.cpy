      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KDLI : DL/I (IMS DB) call helpers
      *  Used with CALL 'CBLTDLI' USING WS-FUNC PCB-MASK IO-AREA SSA.
      *  Provides the DL/I function codes as named constants, the PCB
      *  status values tested after each call, an SSA (segment search
      *  argument) work area for the PAUSEG segment, and a DB-PCB mask
      *  layout template that documents the shape of the PCB the CICS
      *  region passes to the DL/I sub OUIMSPA.
      *----------------------------------------------------------------
      *  DL/I function codes (4-char, blank padded) as named consts.
       01  ODLI-FUNCTIONS.
           05  ODLI-GU             PIC X(04) VALUE 'GU  '.
           05  ODLI-GHU            PIC X(04) VALUE 'GHU '.
           05  ODLI-GN             PIC X(04) VALUE 'GN  '.
           05  ODLI-GHN            PIC X(04) VALUE 'GHN '.
           05  ODLI-GNP            PIC X(04) VALUE 'GNP '.
           05  ODLI-ISRT           PIC X(04) VALUE 'ISRT'.
           05  ODLI-REPL           PIC X(04) VALUE 'REPL'.
           05  ODLI-DLET           PIC X(04) VALUE 'DLET'.
      *  Common DL/I PCB status codes tested after every call.
       01  ODLI-STATUS.
           05  ODLI-ST-OK          PIC X(02) VALUE '  '.
           05  ODLI-ST-NOTFOUND    PIC X(02) VALUE 'GE'.
           05  ODLI-ST-ENDDB       PIC X(02) VALUE 'GB'.
           05  ODLI-ST-NOTPOS      PIC X(02) VALUE 'GA'.
           05  ODLI-ST-DUP         PIC X(02) VALUE 'II'.
           05  ODLI-ST-NOSPACE     PIC X(02) VALUE 'FR'.
      *  DL/I relational operators used to build a qualified SSA.
       01  ODLI-RELOPS.
           05  ODLI-OP-EQ          PIC X(02) VALUE ' ='.
           05  ODLI-OP-GT          PIC X(02) VALUE '> '.
           05  ODLI-OP-GE          PIC X(02) VALUE '>='.
      *  Qualified SSA work area for the PAUSEG root segment.  Move a
      *  key value into ODLI-SSA-KEYVAL and a relop into ODLI-SSA-RELOP
      *  to build a fully qualified GU / GHU call.
       01  ODLI-SSA-PAUSEG.
           05  ODLI-SSA-SEGNAME    PIC X(08) VALUE 'PAUSEG  '.
           05  ODLI-SSA-LPAREN     PIC X(01) VALUE '('.
           05  ODLI-SSA-FLDNAME    PIC X(08) VALUE 'PAAUTHID'.
           05  ODLI-SSA-RELOP      PIC X(02) VALUE ' ='.
           05  ODLI-SSA-KEYVAL     PIC X(16) VALUE SPACES.
           05  ODLI-SSA-RPAREN     PIC X(01) VALUE ')'.
      *  Unqualified SSA (segment name only) for GN browse and ISRT.
       01  ODLI-SSA-UNQUAL.
           05  ODLI-SSAU-SEGNAME   PIC X(08) VALUE 'PAUSEG  '.
           05  ODLI-SSAU-BLANK     PIC X(01) VALUE ' '.
      *  DB-PCB mask layout (template).  The live PCB is received in
      *  the LINKAGE SECTION of the DL/I sub OUIMSPA; this documents
      *  the field layout DL/I returns feedback in after each call.
       01  ODLI-PCB-MASK.
           05  ODLI-PCB-DBD-NAME   PIC X(08).
           05  ODLI-PCB-SEG-LEVEL  PIC X(02).
           05  ODLI-PCB-STATUS     PIC X(02).
           05  ODLI-PCB-PROC-OPTS  PIC X(04).
           05  ODLI-PCB-RESERVED   PIC S9(05) COMP.
           05  ODLI-PCB-SEG-NAME   PIC X(08).
           05  ODLI-PCB-KFB-LEN    PIC S9(05) COMP.
           05  ODLI-PCB-SENSEGS    PIC S9(05) COMP.
           05  ODLI-PCB-KEY-FB     PIC X(16).
