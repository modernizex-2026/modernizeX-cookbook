      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RCARD : Card master record
      *----------------------------------------------------------------
       01  CARD-REC.
           05  CD-NUM              PIC X(16).
           05  CD-ACCT-ID          PIC 9(11).
           05  CD-CVV              PIC X(03).
           05  CD-EMBOSSED-NAME    PIC X(50).
           05  CD-EXPIRY-DATE      PIC X(10).
           05  CD-ACTIVE-STATUS    PIC X(01).
           05  FILLER              PIC X(59).
