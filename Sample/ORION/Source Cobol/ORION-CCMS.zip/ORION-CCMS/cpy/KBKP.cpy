      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KBKP : linkage for sub OUBKP
      *  Request / result block for the on-line transaction backup /
      *  extract utility (browse TRANFILE, write flat BKPFILE feed).
      *  Overlaid on CA-WORK-AREA of the shared COMMAREA (KCOMM).
      *----------------------------------------------------------------
       01  KBK-PARM.
           05  KBK-REQUEST.
               10  KBK-START-KEY     PIC X(16).
      *            resume browse key (spaces = from start of file)
               10  KBK-MAX           PIC 9(07).
           05  KBK-RESULT.
               10  KBK-STATUS        PIC X(02).
               10  KBK-MSG           PIC X(50).
               10  KBK-READ          PIC 9(07).
               10  KBK-WRITTEN       PIC 9(07).
               10  KBK-ERRORS        PIC 9(07).
               10  KBK-TOT-AMT       PIC S9(13)V99.
               10  KBK-CREDIT-AMT    PIC S9(13)V99.
               10  KBK-DEBIT-AMT     PIC S9(13)V99.
               10  KBK-NEXT-KEY      PIC X(16).
               10  KBK-MORE          PIC X(01).
