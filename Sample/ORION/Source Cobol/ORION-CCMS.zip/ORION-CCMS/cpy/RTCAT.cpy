      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RTCAT : Transaction category record
      *----------------------------------------------------------------
       01  TCAT-REC.
           05  TC-KEY.
             10  TC-TYPE-CD        PIC X(02).
             10  TC-CD             PIC 9(04).
           05  TC-DESC             PIC X(50).
           05  FILLER              PIC X(04).
