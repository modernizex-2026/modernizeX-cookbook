      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RCUST : Customer master record
      *----------------------------------------------------------------
       01  CUST-REC.
           05  CU-ID               PIC 9(09).
           05  CU-FIRST-NAME       PIC X(25).
           05  CU-MIDDLE-NAME      PIC X(25).
           05  CU-LAST-NAME        PIC X(25).
           05  CU-ADDR-LINE-1      PIC X(50).
           05  CU-ADDR-LINE-2      PIC X(50).
           05  CU-ADDR-CITY        PIC X(50).
           05  CU-ADDR-STATE       PIC X(02).
           05  CU-ADDR-COUNTRY     PIC X(03).
           05  CU-ADDR-ZIP         PIC X(10).
           05  CU-PHONE-1          PIC X(15).
           05  CU-PHONE-2          PIC X(15).
           05  CU-SSN              PIC 9(09).
           05  CU-GOVT-ID          PIC X(20).
           05  CU-DOB              PIC X(10).
           05  CU-FICO-SCORE       PIC 9(03).
           05  FILLER              PIC X(51).
