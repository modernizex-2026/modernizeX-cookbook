      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KFLAG : linkage for sub OUFLAG
      *  Request / result block for the on-line delinquency scan +
      *  expiry deactivation utility.  Overlaid on CA-WORK-AREA.
      *----------------------------------------------------------------
       01  KFL-PARM.
           05  KFL-REQUEST.
               10  KFL-MODE          PIC X(04).
      *            'BOTH' delinquency + expiry  'DELQ' only  'EXPY' only
               10  KFL-CUTOFF        PIC X(10).
      *            expiry cutoff date YYYY-MM-DD (usually today)
               10  KFL-START-ACCT    PIC 9(11).
               10  KFL-MAX           PIC 9(07).
           05  KFL-RESULT.
               10  KFL-STATUS        PIC X(02).
               10  KFL-MSG           PIC X(50).
               10  KFL-READ          PIC 9(07).
               10  KFL-SKIPPED       PIC 9(07).
               10  KFL-CURRENT       PIC 9(07).
               10  KFL-DELQ          PIC 9(07).
               10  KFL-B30           PIC 9(07).
               10  KFL-B60           PIC 9(07).
               10  KFL-B90           PIC 9(07).
               10  KFL-EXPIRED       PIC 9(07).
               10  KFL-ERRORS        PIC 9(07).
               10  KFL-DELQ-BAL      PIC S9(13)V99.
               10  KFL-SHORTFALL     PIC S9(13)V99.
               10  KFL-NEXT-ACCT     PIC 9(11).
               10  KFL-MORE          PIC X(01).
