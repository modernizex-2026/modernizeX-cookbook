      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MCRDIN
      *----------------------------------------------------------------
       01  MCRDINAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  FILTL PIC S9(04) COMP.
           02  FILTF PIC X.
           02  FILLER REDEFINES FILTF.
               03  FILTA PIC X.
           02  FILTI PIC X(10).
           02  FDESCL PIC S9(04) COMP.
           02  FDESCF PIC X.
           02  FILLER REDEFINES FDESCF.
               03  FDESCA PIC X.
           02  FDESCI PIC X(12).
           02  CNM1L PIC S9(04) COMP.
           02  CNM1F PIC X.
           02  FILLER REDEFINES CNM1F.
               03  CNM1A PIC X.
           02  CNM1I PIC X(16).
           02  CAC1L PIC S9(04) COMP.
           02  CAC1F PIC X.
           02  FILLER REDEFINES CAC1F.
               03  CAC1A PIC X.
           02  CAC1I PIC X(11).
           02  CNA1L PIC S9(04) COMP.
           02  CNA1F PIC X.
           02  FILLER REDEFINES CNA1F.
               03  CNA1A PIC X.
           02  CNA1I PIC X(20).
           02  CEX1L PIC S9(04) COMP.
           02  CEX1F PIC X.
           02  FILLER REDEFINES CEX1F.
               03  CEX1A PIC X.
           02  CEX1I PIC X(10).
           02  CST1L PIC S9(04) COMP.
           02  CST1F PIC X.
           02  FILLER REDEFINES CST1F.
               03  CST1A PIC X.
           02  CST1I PIC X(01).
           02  CNM2L PIC S9(04) COMP.
           02  CNM2F PIC X.
           02  FILLER REDEFINES CNM2F.
               03  CNM2A PIC X.
           02  CNM2I PIC X(16).
           02  CAC2L PIC S9(04) COMP.
           02  CAC2F PIC X.
           02  FILLER REDEFINES CAC2F.
               03  CAC2A PIC X.
           02  CAC2I PIC X(11).
           02  CNA2L PIC S9(04) COMP.
           02  CNA2F PIC X.
           02  FILLER REDEFINES CNA2F.
               03  CNA2A PIC X.
           02  CNA2I PIC X(20).
           02  CEX2L PIC S9(04) COMP.
           02  CEX2F PIC X.
           02  FILLER REDEFINES CEX2F.
               03  CEX2A PIC X.
           02  CEX2I PIC X(10).
           02  CST2L PIC S9(04) COMP.
           02  CST2F PIC X.
           02  FILLER REDEFINES CST2F.
               03  CST2A PIC X.
           02  CST2I PIC X(01).
           02  CNM3L PIC S9(04) COMP.
           02  CNM3F PIC X.
           02  FILLER REDEFINES CNM3F.
               03  CNM3A PIC X.
           02  CNM3I PIC X(16).
           02  CAC3L PIC S9(04) COMP.
           02  CAC3F PIC X.
           02  FILLER REDEFINES CAC3F.
               03  CAC3A PIC X.
           02  CAC3I PIC X(11).
           02  CNA3L PIC S9(04) COMP.
           02  CNA3F PIC X.
           02  FILLER REDEFINES CNA3F.
               03  CNA3A PIC X.
           02  CNA3I PIC X(20).
           02  CEX3L PIC S9(04) COMP.
           02  CEX3F PIC X.
           02  FILLER REDEFINES CEX3F.
               03  CEX3A PIC X.
           02  CEX3I PIC X(10).
           02  CST3L PIC S9(04) COMP.
           02  CST3F PIC X.
           02  FILLER REDEFINES CST3F.
               03  CST3A PIC X.
           02  CST3I PIC X(01).
           02  CNM4L PIC S9(04) COMP.
           02  CNM4F PIC X.
           02  FILLER REDEFINES CNM4F.
               03  CNM4A PIC X.
           02  CNM4I PIC X(16).
           02  CAC4L PIC S9(04) COMP.
           02  CAC4F PIC X.
           02  FILLER REDEFINES CAC4F.
               03  CAC4A PIC X.
           02  CAC4I PIC X(11).
           02  CNA4L PIC S9(04) COMP.
           02  CNA4F PIC X.
           02  FILLER REDEFINES CNA4F.
               03  CNA4A PIC X.
           02  CNA4I PIC X(20).
           02  CEX4L PIC S9(04) COMP.
           02  CEX4F PIC X.
           02  FILLER REDEFINES CEX4F.
               03  CEX4A PIC X.
           02  CEX4I PIC X(10).
           02  CST4L PIC S9(04) COMP.
           02  CST4F PIC X.
           02  FILLER REDEFINES CST4F.
               03  CST4A PIC X.
           02  CST4I PIC X(01).
           02  CNM5L PIC S9(04) COMP.
           02  CNM5F PIC X.
           02  FILLER REDEFINES CNM5F.
               03  CNM5A PIC X.
           02  CNM5I PIC X(16).
           02  CAC5L PIC S9(04) COMP.
           02  CAC5F PIC X.
           02  FILLER REDEFINES CAC5F.
               03  CAC5A PIC X.
           02  CAC5I PIC X(11).
           02  CNA5L PIC S9(04) COMP.
           02  CNA5F PIC X.
           02  FILLER REDEFINES CNA5F.
               03  CNA5A PIC X.
           02  CNA5I PIC X(20).
           02  CEX5L PIC S9(04) COMP.
           02  CEX5F PIC X.
           02  FILLER REDEFINES CEX5F.
               03  CEX5A PIC X.
           02  CEX5I PIC X(10).
           02  CST5L PIC S9(04) COMP.
           02  CST5F PIC X.
           02  FILLER REDEFINES CST5F.
               03  CST5A PIC X.
           02  CST5I PIC X(01).
           02  CNM6L PIC S9(04) COMP.
           02  CNM6F PIC X.
           02  FILLER REDEFINES CNM6F.
               03  CNM6A PIC X.
           02  CNM6I PIC X(16).
           02  CAC6L PIC S9(04) COMP.
           02  CAC6F PIC X.
           02  FILLER REDEFINES CAC6F.
               03  CAC6A PIC X.
           02  CAC6I PIC X(11).
           02  CNA6L PIC S9(04) COMP.
           02  CNA6F PIC X.
           02  FILLER REDEFINES CNA6F.
               03  CNA6A PIC X.
           02  CNA6I PIC X(20).
           02  CEX6L PIC S9(04) COMP.
           02  CEX6F PIC X.
           02  FILLER REDEFINES CEX6F.
               03  CEX6A PIC X.
           02  CEX6I PIC X(10).
           02  CST6L PIC S9(04) COMP.
           02  CST6F PIC X.
           02  FILLER REDEFINES CST6F.
               03  CST6A PIC X.
           02  CST6I PIC X(01).
           02  CNM7L PIC S9(04) COMP.
           02  CNM7F PIC X.
           02  FILLER REDEFINES CNM7F.
               03  CNM7A PIC X.
           02  CNM7I PIC X(16).
           02  CAC7L PIC S9(04) COMP.
           02  CAC7F PIC X.
           02  FILLER REDEFINES CAC7F.
               03  CAC7A PIC X.
           02  CAC7I PIC X(11).
           02  CNA7L PIC S9(04) COMP.
           02  CNA7F PIC X.
           02  FILLER REDEFINES CNA7F.
               03  CNA7A PIC X.
           02  CNA7I PIC X(20).
           02  CEX7L PIC S9(04) COMP.
           02  CEX7F PIC X.
           02  FILLER REDEFINES CEX7F.
               03  CEX7A PIC X.
           02  CEX7I PIC X(10).
           02  CST7L PIC S9(04) COMP.
           02  CST7F PIC X.
           02  FILLER REDEFINES CST7F.
               03  CST7A PIC X.
           02  CST7I PIC X(01).
           02  CNM8L PIC S9(04) COMP.
           02  CNM8F PIC X.
           02  FILLER REDEFINES CNM8F.
               03  CNM8A PIC X.
           02  CNM8I PIC X(16).
           02  CAC8L PIC S9(04) COMP.
           02  CAC8F PIC X.
           02  FILLER REDEFINES CAC8F.
               03  CAC8A PIC X.
           02  CAC8I PIC X(11).
           02  CNA8L PIC S9(04) COMP.
           02  CNA8F PIC X.
           02  FILLER REDEFINES CNA8F.
               03  CNA8A PIC X.
           02  CNA8I PIC X(20).
           02  CEX8L PIC S9(04) COMP.
           02  CEX8F PIC X.
           02  FILLER REDEFINES CEX8F.
               03  CEX8A PIC X.
           02  CEX8I PIC X(10).
           02  CST8L PIC S9(04) COMP.
           02  CST8F PIC X.
           02  FILLER REDEFINES CST8F.
               03  CST8A PIC X.
           02  CST8I PIC X(01).
           02  CNM9L PIC S9(04) COMP.
           02  CNM9F PIC X.
           02  FILLER REDEFINES CNM9F.
               03  CNM9A PIC X.
           02  CNM9I PIC X(16).
           02  CAC9L PIC S9(04) COMP.
           02  CAC9F PIC X.
           02  FILLER REDEFINES CAC9F.
               03  CAC9A PIC X.
           02  CAC9I PIC X(11).
           02  CNA9L PIC S9(04) COMP.
           02  CNA9F PIC X.
           02  FILLER REDEFINES CNA9F.
               03  CNA9A PIC X.
           02  CNA9I PIC X(20).
           02  CEX9L PIC S9(04) COMP.
           02  CEX9F PIC X.
           02  FILLER REDEFINES CEX9F.
               03  CEX9A PIC X.
           02  CEX9I PIC X(10).
           02  CST9L PIC S9(04) COMP.
           02  CST9F PIC X.
           02  FILLER REDEFINES CST9F.
               03  CST9A PIC X.
           02  CST9I PIC X(01).
           02  CNM10L PIC S9(04) COMP.
           02  CNM10F PIC X.
           02  FILLER REDEFINES CNM10F.
               03  CNM10A PIC X.
           02  CNM10I PIC X(16).
           02  CAC10L PIC S9(04) COMP.
           02  CAC10F PIC X.
           02  FILLER REDEFINES CAC10F.
               03  CAC10A PIC X.
           02  CAC10I PIC X(11).
           02  CNA10L PIC S9(04) COMP.
           02  CNA10F PIC X.
           02  FILLER REDEFINES CNA10F.
               03  CNA10A PIC X.
           02  CNA10I PIC X(20).
           02  CEX10L PIC S9(04) COMP.
           02  CEX10F PIC X.
           02  FILLER REDEFINES CEX10F.
               03  CEX10A PIC X.
           02  CEX10I PIC X(10).
           02  CST10L PIC S9(04) COMP.
           02  CST10F PIC X.
           02  FILLER REDEFINES CST10F.
               03  CST10A PIC X.
           02  CST10I PIC X(01).
           02  CNM11L PIC S9(04) COMP.
           02  CNM11F PIC X.
           02  FILLER REDEFINES CNM11F.
               03  CNM11A PIC X.
           02  CNM11I PIC X(16).
           02  CAC11L PIC S9(04) COMP.
           02  CAC11F PIC X.
           02  FILLER REDEFINES CAC11F.
               03  CAC11A PIC X.
           02  CAC11I PIC X(11).
           02  CNA11L PIC S9(04) COMP.
           02  CNA11F PIC X.
           02  FILLER REDEFINES CNA11F.
               03  CNA11A PIC X.
           02  CNA11I PIC X(20).
           02  CEX11L PIC S9(04) COMP.
           02  CEX11F PIC X.
           02  FILLER REDEFINES CEX11F.
               03  CEX11A PIC X.
           02  CEX11I PIC X(10).
           02  CST11L PIC S9(04) COMP.
           02  CST11F PIC X.
           02  FILLER REDEFINES CST11F.
               03  CST11A PIC X.
           02  CST11I PIC X(01).
           02  CNM12L PIC S9(04) COMP.
           02  CNM12F PIC X.
           02  FILLER REDEFINES CNM12F.
               03  CNM12A PIC X.
           02  CNM12I PIC X(16).
           02  CAC12L PIC S9(04) COMP.
           02  CAC12F PIC X.
           02  FILLER REDEFINES CAC12F.
               03  CAC12A PIC X.
           02  CAC12I PIC X(11).
           02  CNA12L PIC S9(04) COMP.
           02  CNA12F PIC X.
           02  FILLER REDEFINES CNA12F.
               03  CNA12A PIC X.
           02  CNA12I PIC X(20).
           02  CEX12L PIC S9(04) COMP.
           02  CEX12F PIC X.
           02  FILLER REDEFINES CEX12F.
               03  CEX12A PIC X.
           02  CEX12I PIC X(10).
           02  CST12L PIC S9(04) COMP.
           02  CST12F PIC X.
           02  FILLER REDEFINES CST12F.
               03  CST12A PIC X.
           02  CST12I PIC X(01).
           02  CNM13L PIC S9(04) COMP.
           02  CNM13F PIC X.
           02  FILLER REDEFINES CNM13F.
               03  CNM13A PIC X.
           02  CNM13I PIC X(16).
           02  CAC13L PIC S9(04) COMP.
           02  CAC13F PIC X.
           02  FILLER REDEFINES CAC13F.
               03  CAC13A PIC X.
           02  CAC13I PIC X(11).
           02  CNA13L PIC S9(04) COMP.
           02  CNA13F PIC X.
           02  FILLER REDEFINES CNA13F.
               03  CNA13A PIC X.
           02  CNA13I PIC X(20).
           02  CEX13L PIC S9(04) COMP.
           02  CEX13F PIC X.
           02  FILLER REDEFINES CEX13F.
               03  CEX13A PIC X.
           02  CEX13I PIC X(10).
           02  CST13L PIC S9(04) COMP.
           02  CST13F PIC X.
           02  FILLER REDEFINES CST13F.
               03  CST13A PIC X.
           02  CST13I PIC X(01).
           02  PAGENOL PIC S9(04) COMP.
           02  PAGENOF PIC X.
           02  FILLER REDEFINES PAGENOF.
               03  PAGENOA PIC X.
           02  PAGENOI PIC X(03).
           02  ACTCNTL PIC S9(04) COMP.
           02  ACTCNTF PIC X.
           02  FILLER REDEFINES ACTCNTF.
               03  ACTCNTA PIC X.
           02  ACTCNTI PIC X(07).
           02  INACNTL PIC S9(04) COMP.
           02  INACNTF PIC X.
           02  FILLER REDEFINES INACNTF.
               03  INACNTA PIC X.
           02  INACNTI PIC X(07).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MCRDINAO REDEFINES MCRDINAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  FILTO PIC X(10).
           02  FILLER PIC X(03).
           02  FDESCO PIC X(12).
           02  FILLER PIC X(03).
           02  CNM1O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC1O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA1O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX1O PIC X(10).
           02  FILLER PIC X(03).
           02  CST1O PIC X(01).
           02  FILLER PIC X(03).
           02  CNM2O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC2O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA2O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX2O PIC X(10).
           02  FILLER PIC X(03).
           02  CST2O PIC X(01).
           02  FILLER PIC X(03).
           02  CNM3O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC3O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA3O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX3O PIC X(10).
           02  FILLER PIC X(03).
           02  CST3O PIC X(01).
           02  FILLER PIC X(03).
           02  CNM4O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC4O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA4O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX4O PIC X(10).
           02  FILLER PIC X(03).
           02  CST4O PIC X(01).
           02  FILLER PIC X(03).
           02  CNM5O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC5O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA5O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX5O PIC X(10).
           02  FILLER PIC X(03).
           02  CST5O PIC X(01).
           02  FILLER PIC X(03).
           02  CNM6O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC6O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA6O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX6O PIC X(10).
           02  FILLER PIC X(03).
           02  CST6O PIC X(01).
           02  FILLER PIC X(03).
           02  CNM7O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC7O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA7O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX7O PIC X(10).
           02  FILLER PIC X(03).
           02  CST7O PIC X(01).
           02  FILLER PIC X(03).
           02  CNM8O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC8O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA8O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX8O PIC X(10).
           02  FILLER PIC X(03).
           02  CST8O PIC X(01).
           02  FILLER PIC X(03).
           02  CNM9O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC9O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA9O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX9O PIC X(10).
           02  FILLER PIC X(03).
           02  CST9O PIC X(01).
           02  FILLER PIC X(03).
           02  CNM10O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC10O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA10O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX10O PIC X(10).
           02  FILLER PIC X(03).
           02  CST10O PIC X(01).
           02  FILLER PIC X(03).
           02  CNM11O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC11O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA11O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX11O PIC X(10).
           02  FILLER PIC X(03).
           02  CST11O PIC X(01).
           02  FILLER PIC X(03).
           02  CNM12O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC12O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA12O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX12O PIC X(10).
           02  FILLER PIC X(03).
           02  CST12O PIC X(01).
           02  FILLER PIC X(03).
           02  CNM13O PIC X(16).
           02  FILLER PIC X(03).
           02  CAC13O PIC X(11).
           02  FILLER PIC X(03).
           02  CNA13O PIC X(20).
           02  FILLER PIC X(03).
           02  CEX13O PIC X(10).
           02  FILLER PIC X(03).
           02  CST13O PIC X(01).
           02  FILLER PIC X(03).
           02  PAGENOO PIC X(03).
           02  FILLER PIC X(03).
           02  ACTCNTO PIC X(07).
           02  FILLER PIC X(03).
           02  INACNTO PIC X(07).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
