      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KCRDIN : Card Inquiry browse interface
      *  Passed on EXEC CICS LINK PROGRAM('OUCRDIN') by the OCCRDIN
      *  screen.  The request half carries the filter and the resume
      *  card number; the response half carries one page of matching
      *  card rows plus active / inactive counters.
      *----------------------------------------------------------------
       01  KCRDIN-AREA.
      *  -- request (screen -> sub) -----------------------------------
           05  KCI-FILTER          PIC X(01).
               88  KCI-F-ALL                  VALUE 'A'.
               88  KCI-F-ACTIVE               VALUE 'Y'.
               88  KCI-F-INACTIVE             VALUE 'N'.
               88  KCI-F-EXPIRING             VALUE 'X'.
           05  KCI-START-KEY       PIC X(16).
           05  KCI-WANT-KPI        PIC X(01).
               88  KCI-DO-KPI                 VALUE 'Y'.
               88  KCI-SKIP-KPI               VALUE 'N'.
      *  -- response (sub -> screen) ----------------------------------
           05  KCI-RETURN-CD       PIC X(01).
               88  KCI-OK                     VALUE 'N'.
               88  KCI-ERROR                  VALUE 'E'.
           05  KCI-ROW-COUNT       PIC 9(02).
           05  KCI-MORE-SW         PIC X(01).
               88  KCI-MORE                   VALUE 'Y'.
               88  KCI-NO-MORE                VALUE 'N'.
           05  KCI-NEXT-KEY        PIC X(16).
           05  KCI-SCAN-COUNT      PIC 9(07).
      *  -- whole-population tallies (OBRCARD) - set when the screen
      *     requests it via KCI-WANT-KPI on the first page -----------
           05  KCI-ACTIVE-CNT      PIC 9(09).
           05  KCI-INACTIVE-CNT    PIC 9(09).
      *  -- one page of matching card rows ----------------------------
           05  KCI-ROW OCCURS 13 TIMES.
               10  KCI-R-NUM       PIC X(16).
               10  KCI-R-ACCT      PIC 9(11).
               10  KCI-R-NAME      PIC X(20).
               10  KCI-R-EXPIRY    PIC X(10).
               10  KCI-R-STATUS    PIC X(01).
