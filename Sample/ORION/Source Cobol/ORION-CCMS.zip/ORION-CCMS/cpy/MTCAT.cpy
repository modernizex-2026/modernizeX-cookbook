      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MTCAT
      *----------------------------------------------------------------
       01  MTCATAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  TCTYPEL PIC S9(04) COMP.
           02  TCTYPEF PIC X.
           02  FILLER REDEFINES TCTYPEF.
               03  TCTYPEA PIC X.
           02  TCTYPEI PIC X(02).
           02  TCCDL PIC S9(04) COMP.
           02  TCCDF PIC X.
           02  FILLER REDEFINES TCCDF.
               03  TCCDA PIC X.
           02  TCCDI PIC X(04).
           02  TCDESCL PIC S9(04) COMP.
           02  TCDESCF PIC X.
           02  FILLER REDEFINES TCDESCF.
               03  TCDESCA PIC X.
           02  TCDESCI PIC X(50).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MTCATAO REDEFINES MTCATAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  TCTYPEO PIC X(02).
           02  FILLER PIC X(03).
           02  TCCDO PIC X(04).
           02  FILLER PIC X(03).
           02  TCDESCO PIC X(50).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
