      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MTRANL
      *----------------------------------------------------------------
       01  MTRANLAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  CARDNUML PIC S9(04) COMP.
           02  CARDNUMF PIC X.
           02  FILLER REDEFINES CARDNUMF.
               03  CARDNUMA PIC X.
           02  CARDNUMI PIC X(16).
           02  TRN1L PIC S9(04) COMP.
           02  TRN1F PIC X.
           02  FILLER REDEFINES TRN1F.
               03  TRN1A PIC X.
           02  TRN1I PIC X(16).
           02  AMT1L PIC S9(04) COMP.
           02  AMT1F PIC X.
           02  FILLER REDEFINES AMT1F.
               03  AMT1A PIC X.
           02  AMT1I PIC X(15).
           02  TYP1L PIC S9(04) COMP.
           02  TYP1F PIC X.
           02  FILLER REDEFINES TYP1F.
               03  TYP1A PIC X.
           02  TYP1I PIC X(02).
           02  TRN2L PIC S9(04) COMP.
           02  TRN2F PIC X.
           02  FILLER REDEFINES TRN2F.
               03  TRN2A PIC X.
           02  TRN2I PIC X(16).
           02  AMT2L PIC S9(04) COMP.
           02  AMT2F PIC X.
           02  FILLER REDEFINES AMT2F.
               03  AMT2A PIC X.
           02  AMT2I PIC X(15).
           02  TYP2L PIC S9(04) COMP.
           02  TYP2F PIC X.
           02  FILLER REDEFINES TYP2F.
               03  TYP2A PIC X.
           02  TYP2I PIC X(02).
           02  TRN3L PIC S9(04) COMP.
           02  TRN3F PIC X.
           02  FILLER REDEFINES TRN3F.
               03  TRN3A PIC X.
           02  TRN3I PIC X(16).
           02  AMT3L PIC S9(04) COMP.
           02  AMT3F PIC X.
           02  FILLER REDEFINES AMT3F.
               03  AMT3A PIC X.
           02  AMT3I PIC X(15).
           02  TYP3L PIC S9(04) COMP.
           02  TYP3F PIC X.
           02  FILLER REDEFINES TYP3F.
               03  TYP3A PIC X.
           02  TYP3I PIC X(02).
           02  TRN4L PIC S9(04) COMP.
           02  TRN4F PIC X.
           02  FILLER REDEFINES TRN4F.
               03  TRN4A PIC X.
           02  TRN4I PIC X(16).
           02  AMT4L PIC S9(04) COMP.
           02  AMT4F PIC X.
           02  FILLER REDEFINES AMT4F.
               03  AMT4A PIC X.
           02  AMT4I PIC X(15).
           02  TYP4L PIC S9(04) COMP.
           02  TYP4F PIC X.
           02  FILLER REDEFINES TYP4F.
               03  TYP4A PIC X.
           02  TYP4I PIC X(02).
           02  TRN5L PIC S9(04) COMP.
           02  TRN5F PIC X.
           02  FILLER REDEFINES TRN5F.
               03  TRN5A PIC X.
           02  TRN5I PIC X(16).
           02  AMT5L PIC S9(04) COMP.
           02  AMT5F PIC X.
           02  FILLER REDEFINES AMT5F.
               03  AMT5A PIC X.
           02  AMT5I PIC X(15).
           02  TYP5L PIC S9(04) COMP.
           02  TYP5F PIC X.
           02  FILLER REDEFINES TYP5F.
               03  TYP5A PIC X.
           02  TYP5I PIC X(02).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MTRANLAO REDEFINES MTRANLAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CARDNUMO PIC X(16).
           02  FILLER PIC X(03).
           02  TRN1O PIC X(16).
           02  FILLER PIC X(03).
           02  AMT1O PIC X(15).
           02  FILLER PIC X(03).
           02  TYP1O PIC X(02).
           02  FILLER PIC X(03).
           02  TRN2O PIC X(16).
           02  FILLER PIC X(03).
           02  AMT2O PIC X(15).
           02  FILLER PIC X(03).
           02  TYP2O PIC X(02).
           02  FILLER PIC X(03).
           02  TRN3O PIC X(16).
           02  FILLER PIC X(03).
           02  AMT3O PIC X(15).
           02  FILLER PIC X(03).
           02  TYP3O PIC X(02).
           02  FILLER PIC X(03).
           02  TRN4O PIC X(16).
           02  FILLER PIC X(03).
           02  AMT4O PIC X(15).
           02  FILLER PIC X(03).
           02  TYP4O PIC X(02).
           02  FILLER PIC X(03).
           02  TRN5O PIC X(16).
           02  FILLER PIC X(03).
           02  AMT5O PIC X(15).
           02  FILLER PIC X(03).
           02  TYP5O PIC X(02).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
