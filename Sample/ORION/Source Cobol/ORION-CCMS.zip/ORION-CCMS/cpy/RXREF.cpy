      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RXREF : Card cross-reference record
      *----------------------------------------------------------------
       01  XREF-REC.
           05  XR-CARD-NUM         PIC X(16).
           05  XR-ACCT-ID          PIC 9(11).
           05  XR-CUST-ID          PIC 9(09).
           05  FILLER              PIC X(14).
