      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MSTMV
      *----------------------------------------------------------------
       01  MSTMVAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  ACCTIDL PIC S9(04) COMP.
           02  ACCTIDF PIC X.
           02  FILLER REDEFINES ACCTIDF.
               03  ACCTIDA PIC X.
           02  ACCTIDI PIC X(11).
           02  STCYCL PIC S9(04) COMP.
           02  STCYCF PIC X.
           02  FILLER REDEFINES STCYCF.
               03  STCYCA PIC X.
           02  STCYCI PIC X(06).
           02  STOPENL PIC S9(04) COMP.
           02  STOPENF PIC X.
           02  FILLER REDEFINES STOPENF.
               03  STOPENA PIC X.
           02  STOPENI PIC X(15).
           02  STCLOSEL PIC S9(04) COMP.
           02  STCLOSEF PIC X.
           02  FILLER REDEFINES STCLOSEF.
               03  STCLOSEA PIC X.
           02  STCLOSEI PIC X(15).
           02  STMINL PIC S9(04) COMP.
           02  STMINF PIC X.
           02  FILLER REDEFINES STMINF.
               03  STMINA PIC X.
           02  STMINI PIC X(15).
           02  STDUEL PIC S9(04) COMP.
           02  STDUEF PIC X.
           02  FILLER REDEFINES STDUEF.
               03  STDUEA PIC X.
           02  STDUEI PIC X(10).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MSTMVAO REDEFINES MSTMVAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  ACCTIDO PIC X(11).
           02  FILLER PIC X(03).
           02  STCYCO PIC X(06).
           02  FILLER PIC X(03).
           02  STOPENO PIC X(15).
           02  FILLER PIC X(03).
           02  STCLOSEO PIC X(15).
           02  FILLER PIC X(03).
           02  STMINO PIC X(15).
           02  FILLER PIC X(03).
           02  STDUEO PIC X(10).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
