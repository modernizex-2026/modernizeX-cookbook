      *----------------------------------------------------------------
      *  ORION-CCMS copybook - WMSG : message work area
      *----------------------------------------------------------------
       01  WS-MESSAGES.
           05  WS-MSG-CODE          PIC X(06) VALUE SPACES.
           05  WS-MSG-TEXT          PIC X(80) VALUE SPACES.
           05  WS-MSG-THANKYOU      PIC X(40)
               VALUE 'Thank you for using ORION-CCMS.'.
           05  WS-MSG-INVALID-KEY   PIC X(40)
               VALUE 'Invalid key pressed. Please try again.'.
           05  WS-MSG-NOTFND        PIC X(40)
               VALUE 'Record not found.'.
           05  WS-MSG-REQUIRED      PIC X(40)
               VALUE 'Please enter all required fields.'.
