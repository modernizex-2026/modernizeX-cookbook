      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MREPT
      *----------------------------------------------------------------
       01  MREPTAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  RPTYPEL PIC S9(04) COMP.
           02  RPTYPEF PIC X.
           02  FILLER REDEFINES RPTYPEF.
               03  RPTYPEA PIC X.
           02  RPTYPEI PIC X(02).
           02  RPFROML PIC S9(04) COMP.
           02  RPFROMF PIC X.
           02  FILLER REDEFINES RPFROMF.
               03  RPFROMA PIC X.
           02  RPFROMI PIC X(10).
           02  RPTOL PIC S9(04) COMP.
           02  RPTOF PIC X.
           02  FILLER REDEFINES RPTOF.
               03  RPTOA PIC X.
           02  RPTOI PIC X(10).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MREPTAO REDEFINES MREPTAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  RPTYPEO PIC X(02).
           02  FILLER PIC X(03).
           02  RPFROMO PIC X(10).
           02  FILLER PIC X(03).
           02  RPTOO PIC X(10).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
