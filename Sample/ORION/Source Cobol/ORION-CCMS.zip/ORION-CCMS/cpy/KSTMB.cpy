      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KSTMB : linkage for browse sub OUSTMIN
      *  One page of statement rows per EXEC CICS LINK.  The caller
      *  (OCSTMIN) fills KSB-REQUEST, LINKs OUSTMIN, then reads back
      *  KSB-RESULT and KSB-ROWS.  Mode ACCT positions the STMTFILE
      *  browse at KSB-START-ACCT / KSB-START-CYCLE (GTEQ).
      *----------------------------------------------------------------
       01  KSTMB-PARM.
           05  KSB-REQUEST.
               10  KSB-MODE          PIC X(04).
      *            'ACCT' = browse by account id then cycle
               10  KSB-START-ACCT    PIC 9(11).
               10  KSB-START-CYCLE   PIC 9(06).
               10  KSB-MAX-ROWS      PIC 9(02).
           05  KSB-RESULT.
               10  KSB-STATUS        PIC X(02).
      *            '00' rows returned  '10' none found  '99' error
               10  KSB-ROW-CNT       PIC 9(02).
               10  KSB-NEXT-ACCT     PIC 9(11).
               10  KSB-NEXT-CYCLE    PIC 9(06).
               10  KSB-MORE          PIC X(01).
      *            'Y' another page follows  'N' end of file
           05  KSB-ROWS.
               10  KSB-ROW OCCURS 6 TIMES.
                   15  KSB-R-ACCT    PIC 9(11).
                   15  KSB-R-CYCLE   PIC 9(06).
                   15  KSB-R-OPEN    PIC S9(10)V99.
                   15  KSB-R-CLOSE   PIC S9(10)V99.
                   15  KSB-R-CREDIT  PIC S9(10)V99.
                   15  KSB-R-DEBIT   PIC S9(10)V99.
                   15  KSB-R-MINDUE  PIC S9(10)V99.
                   15  KSB-R-DUEDT   PIC X(10).
