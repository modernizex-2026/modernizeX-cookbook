      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KSTMTB : linkage for sub OUSTMB
      *  Request / result block for the on-line monthly statement
      *  build utility.  Overlaid on CA-WORK-AREA of KCOMM by the sub.
      *----------------------------------------------------------------
       01  KSM-PARM.
           05  KSM-REQUEST.
               10  KSM-CYCLE         PIC 9(06).
      *            statement cycle YYYYMM applied to every account
               10  KSM-DUE-DATE      PIC X(10).
      *            payment due date stamped on each statement
               10  KSM-START-ACCT    PIC 9(11).
      *            resume account id (0 = from start of file)
               10  KSM-MAX           PIC 9(07).
      *            max accounts to process this run (0 = no cap)
           05  KSM-RESULT.
               10  KSM-STATUS        PIC X(02).
               10  KSM-MSG           PIC X(50).
               10  KSM-ACCT-READ     PIC 9(07).
               10  KSM-STMT-WRITTEN  PIC 9(07).
               10  KSM-NO-TRAN       PIC 9(07).
               10  KSM-ERRORS        PIC 9(07).
               10  KSM-TOT-CREDIT    PIC S9(13)V99.
               10  KSM-TOT-DEBIT     PIC S9(13)V99.
               10  KSM-NEXT-ACCT     PIC 9(11).
               10  KSM-MORE          PIC X(01).
