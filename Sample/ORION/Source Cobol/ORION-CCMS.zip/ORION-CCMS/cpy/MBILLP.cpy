      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MBILLP
      *----------------------------------------------------------------
       01  MBILLPAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  ACCTIDL PIC S9(04) COMP.
           02  ACCTIDF PIC X.
           02  FILLER REDEFINES ACCTIDF.
               03  ACCTIDA PIC X.
           02  ACCTIDI PIC X(11).
           02  BLBALL PIC S9(04) COMP.
           02  BLBALF PIC X.
           02  FILLER REDEFINES BLBALF.
               03  BLBALA PIC X.
           02  BLBALI PIC X(15).
           02  BLAMTL PIC S9(04) COMP.
           02  BLAMTF PIC X.
           02  FILLER REDEFINES BLAMTF.
               03  BLAMTA PIC X.
           02  BLAMTI PIC X(12).
           02  BLCONFL PIC S9(04) COMP.
           02  BLCONFF PIC X.
           02  FILLER REDEFINES BLCONFF.
               03  BLCONFA PIC X.
           02  BLCONFI PIC X(01).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MBILLPAO REDEFINES MBILLPAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  ACCTIDO PIC X(11).
           02  FILLER PIC X(03).
           02  BLBALO PIC X(15).
           02  FILLER PIC X(03).
           02  BLAMTO PIC X(12).
           02  FILLER PIC X(03).
           02  BLCONFO PIC X(01).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
