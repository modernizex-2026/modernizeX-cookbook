      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KARCH : linkage for sub OUARCH
      *  Request / result block for the on-line transaction archive
      *  utility (copy old trans to ARCHFILE, delete from TRANFILE).
      *  Overlaid on CA-WORK-AREA of the shared COMMAREA (KCOMM).
      *----------------------------------------------------------------
       01  KAR-PARM.
           05  KAR-REQUEST.
               10  KAR-CUTOFF        PIC X(10).
      *            archive trans with process date < cutoff YYYY-MM-DD
               10  KAR-START-TRAN    PIC X(16).
               10  KAR-MAX           PIC 9(07).
           05  KAR-RESULT.
               10  KAR-STATUS        PIC X(02).
               10  KAR-MSG           PIC X(50).
               10  KAR-READ          PIC 9(07).
               10  KAR-ARCHIVED      PIC 9(07).
               10  KAR-DELETED       PIC 9(07).
               10  KAR-KEPT          PIC 9(07).
               10  KAR-ERRORS        PIC 9(07).
               10  KAR-ARCH-AMT      PIC S9(13)V99.
               10  KAR-NEXT-TRAN     PIC X(16).
               10  KAR-MORE          PIC X(01).
