      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RTTYP : Transaction type record
      *----------------------------------------------------------------
       01  TTYP-REC.
           05  TT-CD               PIC X(02).
           05  TT-DESC             PIC X(50).
           05  FILLER              PIC X(08).
