      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MTRNIN
      *----------------------------------------------------------------
       01  MTRNINAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  TMODEL PIC S9(04) COMP.
           02  TMODEF PIC X.
           02  FILLER REDEFINES TMODEF.
               03  TMODEA PIC X.
           02  TMODEI PIC X(01).
           02  FCARDL PIC S9(04) COMP.
           02  FCARDF PIC X.
           02  FILLER REDEFINES FCARDF.
               03  FCARDA PIC X.
           02  FCARDI PIC X(16).
           02  FMERCHL PIC S9(04) COMP.
           02  FMERCHF PIC X.
           02  FILLER REDEFINES FMERCHF.
               03  FMERCHA PIC X.
           02  FMERCHI PIC X(09).
           02  FRDATEL PIC S9(04) COMP.
           02  FRDATEF PIC X.
           02  FILLER REDEFINES FRDATEF.
               03  FRDATEA PIC X.
           02  FRDATEI PIC X(10).
           02  FTDATEL PIC S9(04) COMP.
           02  FTDATEF PIC X.
           02  FILLER REDEFINES FTDATEF.
               03  FTDATEA PIC X.
           02  FTDATEI PIC X(10).
           02  FTYPEL PIC S9(04) COMP.
           02  FTYPEF PIC X.
           02  FILLER REDEFINES FTYPEF.
               03  FTYPEA PIC X.
           02  FTYPEI PIC X(02).
           02  FCATL PIC S9(04) COMP.
           02  FCATF PIC X.
           02  FILLER REDEFINES FCATF.
               03  FCATA PIC X.
           02  FCATI PIC X(04).
           02  FAMTL PIC S9(04) COMP.
           02  FAMTF PIC X.
           02  FILLER REDEFINES FAMTF.
               03  FAMTA PIC X.
           02  FAMTI PIC X(12).
           02  TID1L PIC S9(04) COMP.
           02  TID1F PIC X.
           02  FILLER REDEFINES TID1F.
               03  TID1A PIC X.
           02  TID1I PIC X(16).
           02  TCD1L PIC S9(04) COMP.
           02  TCD1F PIC X.
           02  FILLER REDEFINES TCD1F.
               03  TCD1A PIC X.
           02  TCD1I PIC X(04).
           02  TTC1L PIC S9(04) COMP.
           02  TTC1F PIC X.
           02  FILLER REDEFINES TTC1F.
               03  TTC1A PIC X.
           02  TTC1I PIC X(07).
           02  TDS1L PIC S9(04) COMP.
           02  TDS1F PIC X.
           02  FILLER REDEFINES TDS1F.
               03  TDS1A PIC X.
           02  TDS1I PIC X(10).
           02  TMC1L PIC S9(04) COMP.
           02  TMC1F PIC X.
           02  FILLER REDEFINES TMC1F.
               03  TMC1A PIC X.
           02  TMC1I PIC X(10).
           02  TAM1L PIC S9(04) COMP.
           02  TAM1F PIC X.
           02  FILLER REDEFINES TAM1F.
               03  TAM1A PIC X.
           02  TAM1I PIC X(15).
           02  TDT1L PIC S9(04) COMP.
           02  TDT1F PIC X.
           02  FILLER REDEFINES TDT1F.
               03  TDT1A PIC X.
           02  TDT1I PIC X(10).
           02  TID2L PIC S9(04) COMP.
           02  TID2F PIC X.
           02  FILLER REDEFINES TID2F.
               03  TID2A PIC X.
           02  TID2I PIC X(16).
           02  TCD2L PIC S9(04) COMP.
           02  TCD2F PIC X.
           02  FILLER REDEFINES TCD2F.
               03  TCD2A PIC X.
           02  TCD2I PIC X(04).
           02  TTC2L PIC S9(04) COMP.
           02  TTC2F PIC X.
           02  FILLER REDEFINES TTC2F.
               03  TTC2A PIC X.
           02  TTC2I PIC X(07).
           02  TDS2L PIC S9(04) COMP.
           02  TDS2F PIC X.
           02  FILLER REDEFINES TDS2F.
               03  TDS2A PIC X.
           02  TDS2I PIC X(10).
           02  TMC2L PIC S9(04) COMP.
           02  TMC2F PIC X.
           02  FILLER REDEFINES TMC2F.
               03  TMC2A PIC X.
           02  TMC2I PIC X(10).
           02  TAM2L PIC S9(04) COMP.
           02  TAM2F PIC X.
           02  FILLER REDEFINES TAM2F.
               03  TAM2A PIC X.
           02  TAM2I PIC X(15).
           02  TDT2L PIC S9(04) COMP.
           02  TDT2F PIC X.
           02  FILLER REDEFINES TDT2F.
               03  TDT2A PIC X.
           02  TDT2I PIC X(10).
           02  TID3L PIC S9(04) COMP.
           02  TID3F PIC X.
           02  FILLER REDEFINES TID3F.
               03  TID3A PIC X.
           02  TID3I PIC X(16).
           02  TCD3L PIC S9(04) COMP.
           02  TCD3F PIC X.
           02  FILLER REDEFINES TCD3F.
               03  TCD3A PIC X.
           02  TCD3I PIC X(04).
           02  TTC3L PIC S9(04) COMP.
           02  TTC3F PIC X.
           02  FILLER REDEFINES TTC3F.
               03  TTC3A PIC X.
           02  TTC3I PIC X(07).
           02  TDS3L PIC S9(04) COMP.
           02  TDS3F PIC X.
           02  FILLER REDEFINES TDS3F.
               03  TDS3A PIC X.
           02  TDS3I PIC X(10).
           02  TMC3L PIC S9(04) COMP.
           02  TMC3F PIC X.
           02  FILLER REDEFINES TMC3F.
               03  TMC3A PIC X.
           02  TMC3I PIC X(10).
           02  TAM3L PIC S9(04) COMP.
           02  TAM3F PIC X.
           02  FILLER REDEFINES TAM3F.
               03  TAM3A PIC X.
           02  TAM3I PIC X(15).
           02  TDT3L PIC S9(04) COMP.
           02  TDT3F PIC X.
           02  FILLER REDEFINES TDT3F.
               03  TDT3A PIC X.
           02  TDT3I PIC X(10).
           02  TID4L PIC S9(04) COMP.
           02  TID4F PIC X.
           02  FILLER REDEFINES TID4F.
               03  TID4A PIC X.
           02  TID4I PIC X(16).
           02  TCD4L PIC S9(04) COMP.
           02  TCD4F PIC X.
           02  FILLER REDEFINES TCD4F.
               03  TCD4A PIC X.
           02  TCD4I PIC X(04).
           02  TTC4L PIC S9(04) COMP.
           02  TTC4F PIC X.
           02  FILLER REDEFINES TTC4F.
               03  TTC4A PIC X.
           02  TTC4I PIC X(07).
           02  TDS4L PIC S9(04) COMP.
           02  TDS4F PIC X.
           02  FILLER REDEFINES TDS4F.
               03  TDS4A PIC X.
           02  TDS4I PIC X(10).
           02  TMC4L PIC S9(04) COMP.
           02  TMC4F PIC X.
           02  FILLER REDEFINES TMC4F.
               03  TMC4A PIC X.
           02  TMC4I PIC X(10).
           02  TAM4L PIC S9(04) COMP.
           02  TAM4F PIC X.
           02  FILLER REDEFINES TAM4F.
               03  TAM4A PIC X.
           02  TAM4I PIC X(15).
           02  TDT4L PIC S9(04) COMP.
           02  TDT4F PIC X.
           02  FILLER REDEFINES TDT4F.
               03  TDT4A PIC X.
           02  TDT4I PIC X(10).
           02  TID5L PIC S9(04) COMP.
           02  TID5F PIC X.
           02  FILLER REDEFINES TID5F.
               03  TID5A PIC X.
           02  TID5I PIC X(16).
           02  TCD5L PIC S9(04) COMP.
           02  TCD5F PIC X.
           02  FILLER REDEFINES TCD5F.
               03  TCD5A PIC X.
           02  TCD5I PIC X(04).
           02  TTC5L PIC S9(04) COMP.
           02  TTC5F PIC X.
           02  FILLER REDEFINES TTC5F.
               03  TTC5A PIC X.
           02  TTC5I PIC X(07).
           02  TDS5L PIC S9(04) COMP.
           02  TDS5F PIC X.
           02  FILLER REDEFINES TDS5F.
               03  TDS5A PIC X.
           02  TDS5I PIC X(10).
           02  TMC5L PIC S9(04) COMP.
           02  TMC5F PIC X.
           02  FILLER REDEFINES TMC5F.
               03  TMC5A PIC X.
           02  TMC5I PIC X(10).
           02  TAM5L PIC S9(04) COMP.
           02  TAM5F PIC X.
           02  FILLER REDEFINES TAM5F.
               03  TAM5A PIC X.
           02  TAM5I PIC X(15).
           02  TDT5L PIC S9(04) COMP.
           02  TDT5F PIC X.
           02  FILLER REDEFINES TDT5F.
               03  TDT5A PIC X.
           02  TDT5I PIC X(10).
           02  TID6L PIC S9(04) COMP.
           02  TID6F PIC X.
           02  FILLER REDEFINES TID6F.
               03  TID6A PIC X.
           02  TID6I PIC X(16).
           02  TCD6L PIC S9(04) COMP.
           02  TCD6F PIC X.
           02  FILLER REDEFINES TCD6F.
               03  TCD6A PIC X.
           02  TCD6I PIC X(04).
           02  TTC6L PIC S9(04) COMP.
           02  TTC6F PIC X.
           02  FILLER REDEFINES TTC6F.
               03  TTC6A PIC X.
           02  TTC6I PIC X(07).
           02  TDS6L PIC S9(04) COMP.
           02  TDS6F PIC X.
           02  FILLER REDEFINES TDS6F.
               03  TDS6A PIC X.
           02  TDS6I PIC X(10).
           02  TMC6L PIC S9(04) COMP.
           02  TMC6F PIC X.
           02  FILLER REDEFINES TMC6F.
               03  TMC6A PIC X.
           02  TMC6I PIC X(10).
           02  TAM6L PIC S9(04) COMP.
           02  TAM6F PIC X.
           02  FILLER REDEFINES TAM6F.
               03  TAM6A PIC X.
           02  TAM6I PIC X(15).
           02  TDT6L PIC S9(04) COMP.
           02  TDT6F PIC X.
           02  FILLER REDEFINES TDT6F.
               03  TDT6A PIC X.
           02  TDT6I PIC X(10).
           02  MCNTL PIC S9(04) COMP.
           02  MCNTF PIC X.
           02  FILLER REDEFINES MCNTF.
               03  MCNTA PIC X.
           02  MCNTI PIC X(09).
           02  MTOTL PIC S9(04) COMP.
           02  MTOTF PIC X.
           02  FILLER REDEFINES MTOTF.
               03  MTOTA PIC X.
           02  MTOTI PIC X(20).
           02  PCNTL PIC S9(04) COMP.
           02  PCNTF PIC X.
           02  FILLER REDEFINES PCNTF.
               03  PCNTA PIC X.
           02  PCNTI PIC X(07).
           02  PSUML PIC S9(04) COMP.
           02  PSUMF PIC X.
           02  FILLER REDEFINES PSUMF.
               03  PSUMA PIC X.
           02  PSUMI PIC X(20).
           02  YCNTL PIC S9(04) COMP.
           02  YCNTF PIC X.
           02  FILLER REDEFINES YCNTF.
               03  YCNTA PIC X.
           02  YCNTI PIC X(07).
           02  YSUML PIC S9(04) COMP.
           02  YSUMF PIC X.
           02  FILLER REDEFINES YSUMF.
               03  YSUMA PIC X.
           02  YSUMI PIC X(20).
           02  FCNTL PIC S9(04) COMP.
           02  FCNTF PIC X.
           02  FILLER REDEFINES FCNTF.
               03  FCNTA PIC X.
           02  FCNTI PIC X(07).
           02  FSUML PIC S9(04) COMP.
           02  FSUMF PIC X.
           02  FILLER REDEFINES FSUMF.
               03  FSUMA PIC X.
           02  FSUMI PIC X(20).
           02  ICNTL PIC S9(04) COMP.
           02  ICNTF PIC X.
           02  FILLER REDEFINES ICNTF.
               03  ICNTA PIC X.
           02  ICNTI PIC X(07).
           02  ISUML PIC S9(04) COMP.
           02  ISUMF PIC X.
           02  FILLER REDEFINES ISUMF.
               03  ISUMA PIC X.
           02  ISUMI PIC X(20).
           02  XIDL PIC S9(04) COMP.
           02  XIDF PIC X.
           02  FILLER REDEFINES XIDF.
               03  XIDA PIC X.
           02  XIDI PIC X(16).
           02  XAMTL PIC S9(04) COMP.
           02  XAMTF PIC X.
           02  FILLER REDEFINES XAMTF.
               03  XAMTA PIC X.
           02  XAMTI PIC X(20).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MTRNINAO REDEFINES MTRNINAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  TMODEO PIC X(01).
           02  FILLER PIC X(03).
           02  FCARDO PIC X(16).
           02  FILLER PIC X(03).
           02  FMERCHO PIC X(09).
           02  FILLER PIC X(03).
           02  FRDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  FTDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  FTYPEO PIC X(02).
           02  FILLER PIC X(03).
           02  FCATO PIC X(04).
           02  FILLER PIC X(03).
           02  FAMTO PIC X(12).
           02  FILLER PIC X(03).
           02  TID1O PIC X(16).
           02  FILLER PIC X(03).
           02  TCD1O PIC X(04).
           02  FILLER PIC X(03).
           02  TTC1O PIC X(07).
           02  FILLER PIC X(03).
           02  TDS1O PIC X(10).
           02  FILLER PIC X(03).
           02  TMC1O PIC X(10).
           02  FILLER PIC X(03).
           02  TAM1O PIC X(15).
           02  FILLER PIC X(03).
           02  TDT1O PIC X(10).
           02  FILLER PIC X(03).
           02  TID2O PIC X(16).
           02  FILLER PIC X(03).
           02  TCD2O PIC X(04).
           02  FILLER PIC X(03).
           02  TTC2O PIC X(07).
           02  FILLER PIC X(03).
           02  TDS2O PIC X(10).
           02  FILLER PIC X(03).
           02  TMC2O PIC X(10).
           02  FILLER PIC X(03).
           02  TAM2O PIC X(15).
           02  FILLER PIC X(03).
           02  TDT2O PIC X(10).
           02  FILLER PIC X(03).
           02  TID3O PIC X(16).
           02  FILLER PIC X(03).
           02  TCD3O PIC X(04).
           02  FILLER PIC X(03).
           02  TTC3O PIC X(07).
           02  FILLER PIC X(03).
           02  TDS3O PIC X(10).
           02  FILLER PIC X(03).
           02  TMC3O PIC X(10).
           02  FILLER PIC X(03).
           02  TAM3O PIC X(15).
           02  FILLER PIC X(03).
           02  TDT3O PIC X(10).
           02  FILLER PIC X(03).
           02  TID4O PIC X(16).
           02  FILLER PIC X(03).
           02  TCD4O PIC X(04).
           02  FILLER PIC X(03).
           02  TTC4O PIC X(07).
           02  FILLER PIC X(03).
           02  TDS4O PIC X(10).
           02  FILLER PIC X(03).
           02  TMC4O PIC X(10).
           02  FILLER PIC X(03).
           02  TAM4O PIC X(15).
           02  FILLER PIC X(03).
           02  TDT4O PIC X(10).
           02  FILLER PIC X(03).
           02  TID5O PIC X(16).
           02  FILLER PIC X(03).
           02  TCD5O PIC X(04).
           02  FILLER PIC X(03).
           02  TTC5O PIC X(07).
           02  FILLER PIC X(03).
           02  TDS5O PIC X(10).
           02  FILLER PIC X(03).
           02  TMC5O PIC X(10).
           02  FILLER PIC X(03).
           02  TAM5O PIC X(15).
           02  FILLER PIC X(03).
           02  TDT5O PIC X(10).
           02  FILLER PIC X(03).
           02  TID6O PIC X(16).
           02  FILLER PIC X(03).
           02  TCD6O PIC X(04).
           02  FILLER PIC X(03).
           02  TTC6O PIC X(07).
           02  FILLER PIC X(03).
           02  TDS6O PIC X(10).
           02  FILLER PIC X(03).
           02  TMC6O PIC X(10).
           02  FILLER PIC X(03).
           02  TAM6O PIC X(15).
           02  FILLER PIC X(03).
           02  TDT6O PIC X(10).
           02  FILLER PIC X(03).
           02  MCNTO PIC X(09).
           02  FILLER PIC X(03).
           02  MTOTO PIC X(20).
           02  FILLER PIC X(03).
           02  PCNTO PIC X(07).
           02  FILLER PIC X(03).
           02  PSUMO PIC X(20).
           02  FILLER PIC X(03).
           02  YCNTO PIC X(07).
           02  FILLER PIC X(03).
           02  YSUMO PIC X(20).
           02  FILLER PIC X(03).
           02  FCNTO PIC X(07).
           02  FILLER PIC X(03).
           02  FSUMO PIC X(20).
           02  FILLER PIC X(03).
           02  ICNTO PIC X(07).
           02  FILLER PIC X(03).
           02  ISUMO PIC X(20).
           02  FILLER PIC X(03).
           02  XIDO PIC X(16).
           02  FILLER PIC X(03).
           02  XAMTO PIC X(20).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
