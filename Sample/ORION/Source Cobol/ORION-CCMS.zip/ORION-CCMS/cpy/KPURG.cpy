      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KPURG : linkage for sub OUPURG
      *  Request / result block for the on-line transaction purge
      *  utility (delete aged trans by cutoff).  Overlaid on
      *  CA-WORK-AREA of the shared COMMAREA (KCOMM).
      *----------------------------------------------------------------
       01  KPG-PARM.
           05  KPG-REQUEST.
               10  KPG-CUTOFF        PIC X(10).
      *            purge trans with process date < cutoff YYYY-MM-DD
               10  KPG-START-TRAN    PIC X(16).
               10  KPG-MAX           PIC 9(07).
           05  KPG-RESULT.
               10  KPG-STATUS        PIC X(02).
               10  KPG-MSG           PIC X(50).
               10  KPG-READ          PIC 9(07).
               10  KPG-PURGED        PIC 9(07).
               10  KPG-KEPT          PIC 9(07).
               10  KPG-ERRORS        PIC 9(07).
               10  KPG-PURGE-AMT     PIC S9(13)V99.
               10  KPG-KEEP-AMT      PIC S9(13)V99.
               10  KPG-NEXT-TRAN     PIC X(16).
               10  KPG-MORE          PIC X(01).
