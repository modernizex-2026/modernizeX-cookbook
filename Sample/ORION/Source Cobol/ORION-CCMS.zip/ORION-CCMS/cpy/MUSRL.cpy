      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MUSRL
      *----------------------------------------------------------------
       01  MUSRLAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  USR1L PIC S9(04) COMP.
           02  USR1F PIC X.
           02  FILLER REDEFINES USR1F.
               03  USR1A PIC X.
           02  USR1I PIC X(08).
           02  UNM1L PIC S9(04) COMP.
           02  UNM1F PIC X.
           02  FILLER REDEFINES UNM1F.
               03  UNM1A PIC X.
           02  UNM1I PIC X(25).
           02  UTY1L PIC S9(04) COMP.
           02  UTY1F PIC X.
           02  FILLER REDEFINES UTY1F.
               03  UTY1A PIC X.
           02  UTY1I PIC X(01).
           02  USR2L PIC S9(04) COMP.
           02  USR2F PIC X.
           02  FILLER REDEFINES USR2F.
               03  USR2A PIC X.
           02  USR2I PIC X(08).
           02  UNM2L PIC S9(04) COMP.
           02  UNM2F PIC X.
           02  FILLER REDEFINES UNM2F.
               03  UNM2A PIC X.
           02  UNM2I PIC X(25).
           02  UTY2L PIC S9(04) COMP.
           02  UTY2F PIC X.
           02  FILLER REDEFINES UTY2F.
               03  UTY2A PIC X.
           02  UTY2I PIC X(01).
           02  USR3L PIC S9(04) COMP.
           02  USR3F PIC X.
           02  FILLER REDEFINES USR3F.
               03  USR3A PIC X.
           02  USR3I PIC X(08).
           02  UNM3L PIC S9(04) COMP.
           02  UNM3F PIC X.
           02  FILLER REDEFINES UNM3F.
               03  UNM3A PIC X.
           02  UNM3I PIC X(25).
           02  UTY3L PIC S9(04) COMP.
           02  UTY3F PIC X.
           02  FILLER REDEFINES UTY3F.
               03  UTY3A PIC X.
           02  UTY3I PIC X(01).
           02  USR4L PIC S9(04) COMP.
           02  USR4F PIC X.
           02  FILLER REDEFINES USR4F.
               03  USR4A PIC X.
           02  USR4I PIC X(08).
           02  UNM4L PIC S9(04) COMP.
           02  UNM4F PIC X.
           02  FILLER REDEFINES UNM4F.
               03  UNM4A PIC X.
           02  UNM4I PIC X(25).
           02  UTY4L PIC S9(04) COMP.
           02  UTY4F PIC X.
           02  FILLER REDEFINES UTY4F.
               03  UTY4A PIC X.
           02  UTY4I PIC X(01).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MUSRLAO REDEFINES MUSRLAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  USR1O PIC X(08).
           02  FILLER PIC X(03).
           02  UNM1O PIC X(25).
           02  FILLER PIC X(03).
           02  UTY1O PIC X(01).
           02  FILLER PIC X(03).
           02  USR2O PIC X(08).
           02  FILLER PIC X(03).
           02  UNM2O PIC X(25).
           02  FILLER PIC X(03).
           02  UTY2O PIC X(01).
           02  FILLER PIC X(03).
           02  USR3O PIC X(08).
           02  FILLER PIC X(03).
           02  UNM3O PIC X(25).
           02  FILLER PIC X(03).
           02  UTY3O PIC X(01).
           02  FILLER PIC X(03).
           02  USR4O PIC X(08).
           02  FILLER PIC X(03).
           02  UNM4O PIC X(25).
           02  FILLER PIC X(03).
           02  UTY4O PIC X(01).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
