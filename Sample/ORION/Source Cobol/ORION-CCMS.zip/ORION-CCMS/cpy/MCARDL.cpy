      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MCARDL
      *----------------------------------------------------------------
       01  MCARDLAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  ACCTIDL PIC S9(04) COMP.
           02  ACCTIDF PIC X.
           02  FILLER REDEFINES ACCTIDF.
               03  ACCTIDA PIC X.
           02  ACCTIDI PIC X(11).
           02  CARD1L PIC S9(04) COMP.
           02  CARD1F PIC X.
           02  FILLER REDEFINES CARD1F.
               03  CARD1A PIC X.
           02  CARD1I PIC X(16).
           02  STAT1L PIC S9(04) COMP.
           02  STAT1F PIC X.
           02  FILLER REDEFINES STAT1F.
               03  STAT1A PIC X.
           02  STAT1I PIC X(01).
           02  CARD2L PIC S9(04) COMP.
           02  CARD2F PIC X.
           02  FILLER REDEFINES CARD2F.
               03  CARD2A PIC X.
           02  CARD2I PIC X(16).
           02  STAT2L PIC S9(04) COMP.
           02  STAT2F PIC X.
           02  FILLER REDEFINES STAT2F.
               03  STAT2A PIC X.
           02  STAT2I PIC X(01).
           02  CARD3L PIC S9(04) COMP.
           02  CARD3F PIC X.
           02  FILLER REDEFINES CARD3F.
               03  CARD3A PIC X.
           02  CARD3I PIC X(16).
           02  STAT3L PIC S9(04) COMP.
           02  STAT3F PIC X.
           02  FILLER REDEFINES STAT3F.
               03  STAT3A PIC X.
           02  STAT3I PIC X(01).
           02  CARD4L PIC S9(04) COMP.
           02  CARD4F PIC X.
           02  FILLER REDEFINES CARD4F.
               03  CARD4A PIC X.
           02  CARD4I PIC X(16).
           02  STAT4L PIC S9(04) COMP.
           02  STAT4F PIC X.
           02  FILLER REDEFINES STAT4F.
               03  STAT4A PIC X.
           02  STAT4I PIC X(01).
           02  CARD5L PIC S9(04) COMP.
           02  CARD5F PIC X.
           02  FILLER REDEFINES CARD5F.
               03  CARD5A PIC X.
           02  CARD5I PIC X(16).
           02  STAT5L PIC S9(04) COMP.
           02  STAT5F PIC X.
           02  FILLER REDEFINES STAT5F.
               03  STAT5A PIC X.
           02  STAT5I PIC X(01).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MCARDLAO REDEFINES MCARDLAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  ACCTIDO PIC X(11).
           02  FILLER PIC X(03).
           02  CARD1O PIC X(16).
           02  FILLER PIC X(03).
           02  STAT1O PIC X(01).
           02  FILLER PIC X(03).
           02  CARD2O PIC X(16).
           02  FILLER PIC X(03).
           02  STAT2O PIC X(01).
           02  FILLER PIC X(03).
           02  CARD3O PIC X(16).
           02  FILLER PIC X(03).
           02  STAT3O PIC X(01).
           02  FILLER PIC X(03).
           02  CARD4O PIC X(16).
           02  FILLER PIC X(03).
           02  STAT4O PIC X(01).
           02  FILLER PIC X(03).
           02  CARD5O PIC X(16).
           02  FILLER PIC X(03).
           02  STAT5O PIC X(01).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
