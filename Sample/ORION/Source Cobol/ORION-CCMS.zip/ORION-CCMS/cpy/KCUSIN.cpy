      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KCUSIN : Customer Inquiry interface.
      *  LINK'd by OCCUSIN as COMMAREA(KCUSIN-AREA) to sub OUCUSIN.
      *  The request half carries the filter mode and the resume key;
      *  the response half carries one page of matching customer rows
      *  plus filter-wide aggregates (match count, average FICO), so
      *  the one screen replaces OBCUSTP / OBRSCORE / OBRZIP.
      *----------------------------------------------------------------
       01  KCUSIN-AREA.
      *  -- request (screen -> sub) -----------------------------------
           05  KUI-REQUEST.
               10  KUI-FILTER      PIC X(01).
                   88  KUI-F-IDRANGE          VALUE 'I'.
                   88  KUI-F-FICO             VALUE 'F'.
                   88  KUI-F-STZIP            VALUE 'S'.
               10  KUI-ID-FROM     PIC 9(09).
               10  KUI-ID-TO       PIC 9(09).
               10  KUI-FICO-FROM   PIC 9(03).
               10  KUI-FICO-TO     PIC 9(03).
               10  KUI-STATE       PIC X(02).
               10  KUI-ZIP         PIC X(10).
               10  KUI-START-KEY   PIC 9(09).
      *  -- response (sub -> screen) ----------------------------------
           05  KUI-RESPONSE.
               10  KUI-RETURN-CD   PIC X(01).
                   88  KUI-OK                 VALUE 'N'.
                   88  KUI-ERROR              VALUE 'E'.
               10  KUI-ROW-COUNT   PIC 9(02).
               10  KUI-MORE-SW     PIC X(01).
                   88  KUI-MORE               VALUE 'Y'.
                   88  KUI-NO-MORE            VALUE 'N'.
               10  KUI-NEXT-KEY    PIC 9(09).
               10  KUI-SCAN-COUNT  PIC 9(07).
               10  KUI-MATCH-COUNT PIC 9(07).
               10  KUI-FICO-TOT    PIC 9(11).
               10  KUI-FICO-AVG    PIC 9(03).
               10  KUI-FICO-MIN    PIC 9(03).
               10  KUI-FICO-MAX    PIC 9(03).
      *  -- one page of matching customer rows ------------------------
           05  KUI-ROWS.
               10  KUI-ROW OCCURS 13 TIMES.
                   15  KUR-ID      PIC 9(09).
                   15  KUR-NAME    PIC X(30).
                   15  KUR-STATE   PIC X(02).
                   15  KUR-ZIP     PIC X(10).
                   15  KUR-FICO    PIC 9(03).
