      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RPAUSEG : Pending-authorization segment
      *  IMS DB root segment PAUSEG in database OPAUDB.  This layout is
      *  BOTH the IMS segment definition image and the CBLTDLI I/O area
      *  passed on every DL/I call.  Total length = 200 bytes.
      *  Key = PA-AUTH-ID (segment offset 1, length 16, field PAAUTHID).
      *----------------------------------------------------------------
       01  PAUSEG-REC.
           05  PA-AUTH-ID          PIC X(16).
           05  PA-CARD-NUM         PIC X(16).
           05  PA-ACCT-ID          PIC 9(11).
           05  PA-AMOUNT           PIC S9(09)V99.
           05  PA-MERCHANT         PIC X(50).
           05  PA-REQUEST-TS       PIC X(26).
           05  PA-STATUS           PIC X(01).
               88  PA-ST-PENDING              VALUE 'P'.
               88  PA-ST-APPROVED             VALUE 'A'.
               88  PA-ST-DECLINED             VALUE 'D'.
               88  PA-ST-PURGED               VALUE 'X'.
           05  PA-DECISION.
               10  PA-DEC-CODE     PIC X(01).
                   88  PA-DEC-APPROVE         VALUE 'A'.
                   88  PA-DEC-DECLINE         VALUE 'D'.
                   88  PA-DEC-REFER           VALUE 'R'.
               10  PA-DEC-REASON   PIC X(30).
               10  PA-DEC-USER     PIC X(08).
               10  PA-DEC-TS       PIC X(26).
           05  FILLER              PIC X(04).
