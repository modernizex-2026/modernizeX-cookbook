      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KACTIN : Account Inquiry browse interface
      *  Passed on EXEC CICS LINK PROGRAM('OUACTIN') by the OCACTIN
      *  screen.  The request half carries the filter and the resume
      *  key; the response half carries one page of matching account
      *  rows plus page-level totals (portfolio / KPI figures).
      *----------------------------------------------------------------
       01  KACTIN-AREA.
      *  -- request (screen -> sub) -----------------------------------
           05  KAI-FILTER          PIC X(01).
               88  KAI-F-ALL                  VALUE 'A'.
               88  KAI-F-DELINQ               VALUE 'D'.
               88  KAI-F-OVERLMT              VALUE 'O'.
               88  KAI-F-DORMANT              VALUE 'M'.
               88  KAI-F-CLOSED               VALUE 'C'.
               88  KAI-F-NEW                  VALUE 'N'.
               88  KAI-F-HIGHUTL              VALUE 'H'.
           05  KAI-START-KEY       PIC 9(11).
           05  KAI-WANT-KPI        PIC X(01).
               88  KAI-DO-KPI                 VALUE 'Y'.
               88  KAI-SKIP-KPI               VALUE 'N'.
      *  -- response (sub -> screen) ----------------------------------
           05  KAI-RETURN-CD       PIC X(01).
               88  KAI-OK                     VALUE 'N'.
               88  KAI-ERROR                  VALUE 'E'.
           05  KAI-ROW-COUNT       PIC 9(02).
           05  KAI-MORE-SW         PIC X(01).
               88  KAI-MORE                   VALUE 'Y'.
               88  KAI-NO-MORE                VALUE 'N'.
           05  KAI-NEXT-KEY        PIC 9(11).
           05  KAI-SCAN-COUNT      PIC 9(07).
      *  -- whole-population roll-up (OBRPORT / OBRKPI) - set when the
      *     screen requests it via KAI-WANT-KPI on the first page -----
           05  KAI-POP-COUNT       PIC 9(09).
           05  KAI-POP-BAL-TOT     PIC S9(15)V99.
           05  KAI-POP-AVL-TOT     PIC S9(15)V99.
      *  -- one page of matching account rows -------------------------
           05  KAI-ROW OCCURS 13 TIMES.
               10  KAI-R-ID        PIC 9(11).
               10  KAI-R-STATUS    PIC X(01).
               10  KAI-R-BAL       PIC S9(10)V99.
               10  KAI-R-LIMIT     PIC S9(10)V99.
               10  KAI-R-AVAIL     PIC S9(10)V99.
               10  KAI-R-UTIL      PIC 9(03)V99.
