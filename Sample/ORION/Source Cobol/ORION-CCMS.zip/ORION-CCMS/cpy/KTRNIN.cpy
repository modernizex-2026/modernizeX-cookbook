      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KTRNIN : Transaction Inquiry interface.
      *  LINK'd by OCTRNIN as COMMAREA(KTRNIN-AREA) to sub OUTRNIN.
      *  The request half carries the filter and the resume key; the
      *  response half carries one page of matching transactions PLUS
      *  filter-wide aggregates (count, net total, per-class subtotals,
      *  largest single item).  These let the one screen stand in for
      *  OBRTRAN / OBRDAILY / OBRMERCH / OBRTOP / OBTRSUM / OBRINC /
      *  OBRFEE.
      *----------------------------------------------------------------
       01  KTRNIN-AREA.
      *  -- request (screen -> sub) -----------------------------------
           05  KTI-REQUEST.
               10  KTI-FILTER      PIC X(01).
                   88  KTI-F-CARD             VALUE 'C'.
                   88  KTI-F-DATE             VALUE 'D'.
                   88  KTI-F-MERCH            VALUE 'M'.
                   88  KTI-F-TYPECAT          VALUE 'T'.
                   88  KTI-F-AMOUNT           VALUE 'A'.
               10  KTI-CARD        PIC X(16).
               10  KTI-DATE-FROM   PIC X(10).
               10  KTI-DATE-TO     PIC X(10).
               10  KTI-MERCH-ID    PIC 9(09).
               10  KTI-F-TYPE      PIC X(02).
               10  KTI-F-CAT       PIC 9(04).
               10  KTI-AMT-THRESH  PIC S9(09)V99.
               10  KTI-START-KEY   PIC X(16).
      *  -- response (sub -> screen) ----------------------------------
           05  KTI-RESPONSE.
               10  KTI-RETURN-CD   PIC X(01).
                   88  KTI-OK                 VALUE 'N'.
                   88  KTI-ERROR              VALUE 'E'.
               10  KTI-ROW-COUNT   PIC 9(02).
               10  KTI-MORE-SW     PIC X(01).
                   88  KTI-MORE               VALUE 'Y'.
                   88  KTI-NO-MORE            VALUE 'N'.
               10  KTI-NEXT-KEY    PIC X(16).
               10  KTI-SCAN-COUNT  PIC 9(07).
               10  KTI-MATCH-COUNT PIC 9(07).
               10  KTI-NET-TOTAL   PIC S9(13)V99.
               10  KTI-MAX-AMT     PIC S9(11)V99.
               10  KTI-MAX-ID      PIC X(16).
               10  KTI-PURCH-CNT   PIC 9(07).
               10  KTI-PURCH-SUM   PIC S9(13)V99.
               10  KTI-PAY-CNT     PIC 9(07).
               10  KTI-PAY-SUM     PIC S9(13)V99.
               10  KTI-FEE-CNT     PIC 9(07).
               10  KTI-FEE-SUM     PIC S9(13)V99.
               10  KTI-INT-CNT     PIC 9(07).
               10  KTI-INT-SUM     PIC S9(13)V99.
      *  -- one page of matching transaction rows ---------------------
           05  KTI-ROWS.
               10  KTI-ROW OCCURS 6 TIMES.
                   15  KTR-ID      PIC X(16).
                   15  KTR-CARD    PIC X(16).
                   15  KTR-TYCAT   PIC X(07).
                   15  KTR-DESC    PIC X(20).
                   15  KTR-MERCH   PIC X(20).
                   15  KTR-AMT     PIC S9(09)V99.
                   15  KTR-DATE    PIC X(10).
