      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KMQ : MQI working-storage (ORIGINAL)
      *  Minimal ORION-original control blocks + named constants used
      *  by the MQI CALL API (MQCONN/MQOPEN/MQPUT/MQGET/MQCLOSE/MQDISC).
      *  These are ORION-authored layouts - NOT the vendor CMQ* books.
      *  Placed in WORKING-STORAGE only (VALUE clauses present).
      *----------------------------------------------------------------
       01  MQ-HANDLES.
           05  MQ-HCONN            PIC S9(09) COMP VALUE ZERO.
           05  MQ-HOBJ-REQ         PIC S9(09) COMP VALUE ZERO.
           05  MQ-HOBJ-RPY         PIC S9(09) COMP VALUE ZERO.
           05  MQ-HOBJ-OUT         PIC S9(09) COMP VALUE ZERO.
      *----------------------------------------------------------------
      *  Fullword option / length arguments passed to the calls.
      *----------------------------------------------------------------
       01  MQ-CALL-ARGS.
           05  MQ-OPEN-OPTIONS     PIC S9(09) COMP VALUE ZERO.
           05  MQ-CLOSE-OPTIONS    PIC S9(09) COMP VALUE ZERO.
           05  MQ-BUFFER-LEN       PIC S9(09) COMP VALUE ZERO.
           05  MQ-DATA-LEN         PIC S9(09) COMP VALUE ZERO.
      *----------------------------------------------------------------
      *  Completion code + reason code returned by every call.
      *----------------------------------------------------------------
       01  MQ-RESULT.
           05  MQ-CC               PIC S9(09) COMP VALUE ZERO.
               88  MQ-CC-OK                    VALUE 0.
               88  MQ-CC-WARNING               VALUE 1.
               88  MQ-CC-FAILED                VALUE 2.
           05  MQ-RC               PIC S9(09) COMP VALUE ZERO.
               88  MQ-RC-NONE                  VALUE 0.
               88  MQ-RC-NO-MSG                VALUE 2033.
      *----------------------------------------------------------------
      *  Object descriptor - names the queue for MQOPEN.
      *----------------------------------------------------------------
       01  MQ-OD.
           05  MQ-OD-STRUC-ID      PIC X(04) VALUE 'ODOR'.
           05  MQ-OD-VERSION       PIC S9(09) COMP VALUE 1.
           05  MQ-OD-OBJECT-TYPE   PIC S9(09) COMP VALUE 1.
           05  MQ-OD-OBJECT-NAME   PIC X(48) VALUE SPACES.
           05  MQ-OD-OBJECT-QMGR   PIC X(48) VALUE SPACES.
           05  MQ-OD-DYNAMIC-NAME  PIC X(48) VALUE SPACES.
           05  MQ-OD-RESOLVED-NAME PIC X(48) VALUE SPACES.
      *----------------------------------------------------------------
      *  Message descriptor - attributes of one message.
      *----------------------------------------------------------------
       01  MQ-MD.
           05  MQ-MD-STRUC-ID      PIC X(04) VALUE 'MDOR'.
           05  MQ-MD-VERSION       PIC S9(09) COMP VALUE 1.
           05  MQ-MD-REPORT        PIC S9(09) COMP VALUE 0.
           05  MQ-MD-MSG-TYPE      PIC S9(09) COMP VALUE 8.
           05  MQ-MD-EXPIRY        PIC S9(09) COMP VALUE -1.
           05  MQ-MD-FEEDBACK      PIC S9(09) COMP VALUE 0.
           05  MQ-MD-ENCODING      PIC S9(09) COMP VALUE 546.
           05  MQ-MD-CCSID         PIC S9(09) COMP VALUE 500.
           05  MQ-MD-FORMAT        PIC X(08) VALUE SPACES.
           05  MQ-MD-PRIORITY      PIC S9(09) COMP VALUE -1.
           05  MQ-MD-PERSISTENCE   PIC S9(09) COMP VALUE 2.
           05  MQ-MD-MSG-ID        PIC X(24) VALUE LOW-VALUES.
           05  MQ-MD-CORREL-ID     PIC X(24) VALUE LOW-VALUES.
           05  MQ-MD-REPLY-Q       PIC X(48) VALUE SPACES.
           05  MQ-MD-REPLY-QMGR    PIC X(48) VALUE SPACES.
           05  MQ-MD-PUT-DATE      PIC X(08) VALUE SPACES.
           05  MQ-MD-PUT-TIME      PIC X(08) VALUE SPACES.
      *----------------------------------------------------------------
      *  Put-message options - control block for MQPUT.
      *----------------------------------------------------------------
       01  MQ-PMO.
           05  MQ-PMO-STRUC-ID     PIC X(04) VALUE 'PMOR'.
           05  MQ-PMO-VERSION      PIC S9(09) COMP VALUE 1.
           05  MQ-PMO-OPTIONS      PIC S9(09) COMP VALUE 0.
           05  MQ-PMO-TIMEOUT      PIC S9(09) COMP VALUE -1.
           05  MQ-PMO-CONTEXT      PIC S9(09) COMP VALUE 0.
           05  MQ-PMO-RESOLVED-Q   PIC X(48) VALUE SPACES.
           05  MQ-PMO-RESLV-QMGR   PIC X(48) VALUE SPACES.
      *----------------------------------------------------------------
      *  Get-message options - control block for MQGET.
      *----------------------------------------------------------------
       01  MQ-GMO.
           05  MQ-GMO-STRUC-ID     PIC X(04) VALUE 'GMOR'.
           05  MQ-GMO-VERSION      PIC S9(09) COMP VALUE 1.
           05  MQ-GMO-OPTIONS      PIC S9(09) COMP VALUE 0.
           05  MQ-GMO-WAIT-INTVL   PIC S9(09) COMP VALUE 5000.
           05  MQ-GMO-SIGNAL       PIC S9(09) COMP VALUE 0.
           05  MQ-GMO-RESOLVED-Q   PIC X(48) VALUE SPACES.
      *----------------------------------------------------------------
      *  Named constants - open options, put/get options, connect.
      *  Values follow the standard (non-copyrightable) MQI numbers.
      *----------------------------------------------------------------
       01  MQ-CONSTANTS.
           05  MQ-HC-DEF-HCONN     PIC S9(09) COMP VALUE 0.
           05  MQ-OO-OUTPUT        PIC S9(09) COMP VALUE 16.
           05  MQ-OO-INPUT-SHARED  PIC S9(09) COMP VALUE 2.
           05  MQ-OO-INPUT-EXCL    PIC S9(09) COMP VALUE 1.
           05  MQ-OO-FAIL-IF-QSG   PIC S9(09) COMP VALUE 8192.
           05  MQ-CO-NONE          PIC S9(09) COMP VALUE 0.
           05  MQ-PM-NO-SYNCPOINT  PIC S9(09) COMP VALUE 4.
           05  MQ-PM-SYNCPOINT     PIC S9(09) COMP VALUE 2.
           05  MQ-PM-NEW-MSG-ID    PIC S9(09) COMP VALUE 64.
           05  MQ-GM-NO-SYNCPOINT  PIC S9(09) COMP VALUE 4.
           05  MQ-GM-WAIT          PIC S9(09) COMP VALUE 1.
           05  MQ-GM-ACCEPT-TRUNC  PIC S9(09) COMP VALUE 64.
           05  MQ-CL-NONE          PIC S9(09) COMP VALUE 0.
           05  MQ-MT-REQUEST       PIC S9(09) COMP VALUE 1.
           05  MQ-MT-REPLY         PIC S9(09) COMP VALUE 2.
           05  MQ-MT-DATAGRAM      PIC S9(09) COMP VALUE 8.
