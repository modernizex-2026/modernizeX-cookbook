      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RBILL : Bill payment record
      *----------------------------------------------------------------
       01  BILL-REC.
           05  BL-ID               PIC 9(11).
           05  BL-ACCT-ID          PIC 9(11).
           05  BL-AMOUNT           PIC S9(10)V99.
           05  BL-PAY-DATE         PIC X(10).
           05  BL-CONFIRM-NUM      PIC X(16).
           05  BL-STATUS           PIC X(01).
           05  FILLER              PIC X(20).
