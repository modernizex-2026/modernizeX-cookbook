      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MPAUIN
      *----------------------------------------------------------------
       01  MPAUINAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  AUTHIDL PIC S9(04) COMP.
           02  AUTHIDF PIC X.
           02  FILLER REDEFINES AUTHIDF.
               03  AUTHIDA PIC X.
           02  AUTHIDI PIC X(16).
           02  PACARDL PIC S9(04) COMP.
           02  PACARDF PIC X.
           02  FILLER REDEFINES PACARDF.
               03  PACARDA PIC X.
           02  PACARDI PIC X(16).
           02  PAACCTL PIC S9(04) COMP.
           02  PAACCTF PIC X.
           02  FILLER REDEFINES PAACCTF.
               03  PAACCTA PIC X.
           02  PAACCTI PIC X(11).
           02  PAAMTL PIC S9(04) COMP.
           02  PAAMTF PIC X.
           02  FILLER REDEFINES PAAMTF.
               03  PAAMTA PIC X.
           02  PAAMTI PIC X(16).
           02  PAMERCHL PIC S9(04) COMP.
           02  PAMERCHF PIC X.
           02  FILLER REDEFINES PAMERCHF.
               03  PAMERCHA PIC X.
           02  PAMERCHI PIC X(50).
           02  PAREQTSL PIC S9(04) COMP.
           02  PAREQTSF PIC X.
           02  FILLER REDEFINES PAREQTSF.
               03  PAREQTSA PIC X.
           02  PAREQTSI PIC X(26).
           02  PASTATL PIC S9(04) COMP.
           02  PASTATF PIC X.
           02  FILLER REDEFINES PASTATF.
               03  PASTATA PIC X.
           02  PASTATI PIC X(12).
           02  PADECL PIC S9(04) COMP.
           02  PADECF PIC X.
           02  FILLER REDEFINES PADECF.
               03  PADECA PIC X.
           02  PADECI PIC X(30).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MPAUINAO REDEFINES MPAUINAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  AUTHIDO PIC X(16).
           02  FILLER PIC X(03).
           02  PACARDO PIC X(16).
           02  FILLER PIC X(03).
           02  PAACCTO PIC X(11).
           02  FILLER PIC X(03).
           02  PAAMTO PIC X(16).
           02  FILLER PIC X(03).
           02  PAMERCHO PIC X(50).
           02  FILLER PIC X(03).
           02  PAREQTSO PIC X(26).
           02  FILLER PIC X(03).
           02  PASTATO PIC X(12).
           02  FILLER PIC X(03).
           02  PADECO PIC X(30).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
