      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KXREF : linkage for sub OUXREF
      *  Request / result block for the on-line card cross-reference
      *  rebuild + validate utility.  Overlaid on CA-WORK-AREA of the
      *  shared COMMAREA (KCOMM) by the sub via SET ADDRESS.
      *----------------------------------------------------------------
       01  KUX-PARM.
           05  KUX-REQUEST.
               10  KUX-MODE          PIC X(04).
      *            'REBL' rebuild (write/rewrite)  'VALD' validate only
               10  KUX-MAX           PIC 9(07).
      *            max cards to scan this run (0 = no cap)
               10  KUX-START-CARD    PIC X(16).
      *            resume browse key (spaces = from start of file)
           05  KUX-RESULT.
               10  KUX-STATUS        PIC X(02).
      *            '00' ok  '10' nothing processed  '99' error
               10  KUX-MSG           PIC X(50).
               10  KUX-READ          PIC 9(07).
               10  KUX-WRITTEN       PIC 9(07).
               10  KUX-UPDATED       PIC 9(07).
               10  KUX-SKIP-ACCT     PIC 9(07).
               10  KUX-SKIP-XREF     PIC 9(07).
               10  KUX-SKIP-CUST     PIC 9(07).
               10  KUX-ERRORS        PIC 9(07).
               10  KUX-NEXT-CARD     PIC X(16).
               10  KUX-MORE          PIC X(01).
