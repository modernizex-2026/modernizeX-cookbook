      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RCTRL : Control / counter record
      *----------------------------------------------------------------
       01  CTRL-REC.
           05  CT-KEY              PIC X(08).
           05  CT-LAST-VALUE       PIC 9(11).
           05  CT-DESC             PIC X(30).
           05  FILLER              PIC X(11).
