      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RTRAN : Transaction record
      *----------------------------------------------------------------
       01  TRAN-REC.
           05  TR-ID               PIC X(16).
           05  TR-TYPE-CD          PIC X(02).
           05  TR-CAT-CD           PIC 9(04).
           05  TR-SOURCE           PIC X(10).
           05  TR-DESC             PIC X(100).
           05  TR-AMT              PIC S9(09)V99.
           05  TR-MERCHANT-ID      PIC 9(09).
           05  TR-MERCHANT-NAME    PIC X(50).
           05  TR-MERCHANT-CITY    PIC X(50).
           05  TR-MERCHANT-ZIP     PIC X(10).
           05  TR-CARD-NUM         PIC X(16).
           05  TR-ORIG-TS          PIC X(26).
           05  TR-PROC-TS          PIC X(26).
           05  FILLER              PIC X(20).
