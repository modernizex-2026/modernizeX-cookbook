      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MTRANA
      *----------------------------------------------------------------
       01  MTRANAAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  CARDNUML PIC S9(04) COMP.
           02  CARDNUMF PIC X.
           02  FILLER REDEFINES CARDNUMF.
               03  CARDNUMA PIC X.
           02  CARDNUMI PIC X(16).
           02  TRTYPEL PIC S9(04) COMP.
           02  TRTYPEF PIC X.
           02  FILLER REDEFINES TRTYPEF.
               03  TRTYPEA PIC X.
           02  TRTYPEI PIC X(02).
           02  TRCATL PIC S9(04) COMP.
           02  TRCATF PIC X.
           02  FILLER REDEFINES TRCATF.
               03  TRCATA PIC X.
           02  TRCATI PIC X(04).
           02  TRAMTL PIC S9(04) COMP.
           02  TRAMTF PIC X.
           02  FILLER REDEFINES TRAMTF.
               03  TRAMTA PIC X.
           02  TRAMTI PIC X(12).
           02  TRMERCHL PIC S9(04) COMP.
           02  TRMERCHF PIC X.
           02  FILLER REDEFINES TRMERCHF.
               03  TRMERCHA PIC X.
           02  TRMERCHI PIC X(50).
           02  TRDESCL PIC S9(04) COMP.
           02  TRDESCF PIC X.
           02  FILLER REDEFINES TRDESCF.
               03  TRDESCA PIC X.
           02  TRDESCI PIC X(50).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MTRANAAO REDEFINES MTRANAAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CARDNUMO PIC X(16).
           02  FILLER PIC X(03).
           02  TRTYPEO PIC X(02).
           02  FILLER PIC X(03).
           02  TRCATO PIC X(04).
           02  FILLER PIC X(03).
           02  TRAMTO PIC X(12).
           02  FILLER PIC X(03).
           02  TRMERCHO PIC X(50).
           02  FILLER PIC X(03).
           02  TRDESCO PIC X(50).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
