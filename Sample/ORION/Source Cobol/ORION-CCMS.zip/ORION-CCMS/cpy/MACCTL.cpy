      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MACCTL
      *----------------------------------------------------------------
       01  MACCTLAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  FRACCTL PIC S9(04) COMP.
           02  FRACCTF PIC X.
           02  FILLER REDEFINES FRACCTF.
               03  FRACCTA PIC X.
           02  FRACCTI PIC X(11).
           02  ACL1L PIC S9(04) COMP.
           02  ACL1F PIC X.
           02  FILLER REDEFINES ACL1F.
               03  ACL1A PIC X.
           02  ACL1I PIC X(11).
           02  ACS1L PIC S9(04) COMP.
           02  ACS1F PIC X.
           02  FILLER REDEFINES ACS1F.
               03  ACS1A PIC X.
           02  ACS1I PIC X(01).
           02  ACB1L PIC S9(04) COMP.
           02  ACB1F PIC X.
           02  FILLER REDEFINES ACB1F.
               03  ACB1A PIC X.
           02  ACB1I PIC X(15).
           02  ACL2L PIC S9(04) COMP.
           02  ACL2F PIC X.
           02  FILLER REDEFINES ACL2F.
               03  ACL2A PIC X.
           02  ACL2I PIC X(11).
           02  ACS2L PIC S9(04) COMP.
           02  ACS2F PIC X.
           02  FILLER REDEFINES ACS2F.
               03  ACS2A PIC X.
           02  ACS2I PIC X(01).
           02  ACB2L PIC S9(04) COMP.
           02  ACB2F PIC X.
           02  FILLER REDEFINES ACB2F.
               03  ACB2A PIC X.
           02  ACB2I PIC X(15).
           02  ACL3L PIC S9(04) COMP.
           02  ACL3F PIC X.
           02  FILLER REDEFINES ACL3F.
               03  ACL3A PIC X.
           02  ACL3I PIC X(11).
           02  ACS3L PIC S9(04) COMP.
           02  ACS3F PIC X.
           02  FILLER REDEFINES ACS3F.
               03  ACS3A PIC X.
           02  ACS3I PIC X(01).
           02  ACB3L PIC S9(04) COMP.
           02  ACB3F PIC X.
           02  FILLER REDEFINES ACB3F.
               03  ACB3A PIC X.
           02  ACB3I PIC X(15).
           02  ACL4L PIC S9(04) COMP.
           02  ACL4F PIC X.
           02  FILLER REDEFINES ACL4F.
               03  ACL4A PIC X.
           02  ACL4I PIC X(11).
           02  ACS4L PIC S9(04) COMP.
           02  ACS4F PIC X.
           02  FILLER REDEFINES ACS4F.
               03  ACS4A PIC X.
           02  ACS4I PIC X(01).
           02  ACB4L PIC S9(04) COMP.
           02  ACB4F PIC X.
           02  FILLER REDEFINES ACB4F.
               03  ACB4A PIC X.
           02  ACB4I PIC X(15).
           02  ACL5L PIC S9(04) COMP.
           02  ACL5F PIC X.
           02  FILLER REDEFINES ACL5F.
               03  ACL5A PIC X.
           02  ACL5I PIC X(11).
           02  ACS5L PIC S9(04) COMP.
           02  ACS5F PIC X.
           02  FILLER REDEFINES ACS5F.
               03  ACS5A PIC X.
           02  ACS5I PIC X(01).
           02  ACB5L PIC S9(04) COMP.
           02  ACB5F PIC X.
           02  FILLER REDEFINES ACB5F.
               03  ACB5A PIC X.
           02  ACB5I PIC X(15).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MACCTLAO REDEFINES MACCTLAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  FRACCTO PIC X(11).
           02  FILLER PIC X(03).
           02  ACL1O PIC X(11).
           02  FILLER PIC X(03).
           02  ACS1O PIC X(01).
           02  FILLER PIC X(03).
           02  ACB1O PIC X(15).
           02  FILLER PIC X(03).
           02  ACL2O PIC X(11).
           02  FILLER PIC X(03).
           02  ACS2O PIC X(01).
           02  FILLER PIC X(03).
           02  ACB2O PIC X(15).
           02  FILLER PIC X(03).
           02  ACL3O PIC X(11).
           02  FILLER PIC X(03).
           02  ACS3O PIC X(01).
           02  FILLER PIC X(03).
           02  ACB3O PIC X(15).
           02  FILLER PIC X(03).
           02  ACL4O PIC X(11).
           02  FILLER PIC X(03).
           02  ACS4O PIC X(01).
           02  FILLER PIC X(03).
           02  ACB4O PIC X(15).
           02  FILLER PIC X(03).
           02  ACL5O PIC X(11).
           02  FILLER PIC X(03).
           02  ACS5O PIC X(01).
           02  FILLER PIC X(03).
           02  ACB5O PIC X(15).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
