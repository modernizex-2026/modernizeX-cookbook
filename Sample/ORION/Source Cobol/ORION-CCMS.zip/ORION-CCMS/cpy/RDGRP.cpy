      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RDGRP : Disclosure/interest group record
      *----------------------------------------------------------------
       01  DGRP-REC.
           05  DG-KEY.
             10  DG-ACCT-GROUP     PIC X(10).
             10  DG-TYPE-CD        PIC X(02).
             10  DG-CAT-CD         PIC 9(04).
           05  DG-INT-RATE         PIC S9(04)V99.
           05  FILLER              PIC X(28).
