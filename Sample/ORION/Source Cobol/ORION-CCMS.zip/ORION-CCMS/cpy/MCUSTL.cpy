      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MCUSTL
      *----------------------------------------------------------------
       01  MCUSTLAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  FRCUSTL PIC S9(04) COMP.
           02  FRCUSTF PIC X.
           02  FILLER REDEFINES FRCUSTF.
               03  FRCUSTA PIC X.
           02  FRCUSTI PIC X(09).
           02  CUL1L PIC S9(04) COMP.
           02  CUL1F PIC X.
           02  FILLER REDEFINES CUL1F.
               03  CUL1A PIC X.
           02  CUL1I PIC X(09).
           02  CUN1L PIC S9(04) COMP.
           02  CUN1F PIC X.
           02  FILLER REDEFINES CUN1F.
               03  CUN1A PIC X.
           02  CUN1I PIC X(30).
           02  CUF1L PIC S9(04) COMP.
           02  CUF1F PIC X.
           02  FILLER REDEFINES CUF1F.
               03  CUF1A PIC X.
           02  CUF1I PIC X(03).
           02  CUL2L PIC S9(04) COMP.
           02  CUL2F PIC X.
           02  FILLER REDEFINES CUL2F.
               03  CUL2A PIC X.
           02  CUL2I PIC X(09).
           02  CUN2L PIC S9(04) COMP.
           02  CUN2F PIC X.
           02  FILLER REDEFINES CUN2F.
               03  CUN2A PIC X.
           02  CUN2I PIC X(30).
           02  CUF2L PIC S9(04) COMP.
           02  CUF2F PIC X.
           02  FILLER REDEFINES CUF2F.
               03  CUF2A PIC X.
           02  CUF2I PIC X(03).
           02  CUL3L PIC S9(04) COMP.
           02  CUL3F PIC X.
           02  FILLER REDEFINES CUL3F.
               03  CUL3A PIC X.
           02  CUL3I PIC X(09).
           02  CUN3L PIC S9(04) COMP.
           02  CUN3F PIC X.
           02  FILLER REDEFINES CUN3F.
               03  CUN3A PIC X.
           02  CUN3I PIC X(30).
           02  CUF3L PIC S9(04) COMP.
           02  CUF3F PIC X.
           02  FILLER REDEFINES CUF3F.
               03  CUF3A PIC X.
           02  CUF3I PIC X(03).
           02  CUL4L PIC S9(04) COMP.
           02  CUL4F PIC X.
           02  FILLER REDEFINES CUL4F.
               03  CUL4A PIC X.
           02  CUL4I PIC X(09).
           02  CUN4L PIC S9(04) COMP.
           02  CUN4F PIC X.
           02  FILLER REDEFINES CUN4F.
               03  CUN4A PIC X.
           02  CUN4I PIC X(30).
           02  CUF4L PIC S9(04) COMP.
           02  CUF4F PIC X.
           02  FILLER REDEFINES CUF4F.
               03  CUF4A PIC X.
           02  CUF4I PIC X(03).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MCUSTLAO REDEFINES MCUSTLAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  FRCUSTO PIC X(09).
           02  FILLER PIC X(03).
           02  CUL1O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN1O PIC X(30).
           02  FILLER PIC X(03).
           02  CUF1O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL2O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN2O PIC X(30).
           02  FILLER PIC X(03).
           02  CUF2O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL3O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN3O PIC X(30).
           02  FILLER PIC X(03).
           02  CUF3O PIC X(03).
           02  FILLER PIC X(03).
           02  CUL4O PIC X(09).
           02  FILLER PIC X(03).
           02  CUN4O PIC X(30).
           02  FILLER PIC X(03).
           02  CUF4O PIC X(03).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
