      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RACCT : Account master record
      *----------------------------------------------------------------
       01  ACCT-REC.
           05  AC-ID               PIC 9(11).
           05  AC-ACTIVE-STATUS    PIC X(01).
           05  AC-CURR-BAL         PIC S9(10)V99.
           05  AC-CREDIT-LIMIT     PIC S9(10)V99.
           05  AC-CASH-LIMIT       PIC S9(10)V99.
           05  AC-OPEN-DATE        PIC X(10).
           05  AC-EXPIRY-DATE      PIC X(10).
           05  AC-REISSUE-DATE     PIC X(10).
           05  AC-CYC-CREDIT       PIC S9(10)V99.
           05  AC-CYC-DEBIT        PIC S9(10)V99.
           05  AC-ADDR-ZIP         PIC X(10).
           05  AC-GROUP-ID         PIC X(10).
           05  FILLER              PIC X(178).
