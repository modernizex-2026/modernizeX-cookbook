      *----------------------------------------------------------------
      *  ORION-CCMS BMS DSECT (generated) - mapset MOPS
      *----------------------------------------------------------------
       01  MOPSAI.
           02  FILLER PIC X(12).
           02  TRNNAMEL PIC S9(04) COMP.
           02  TRNNAMEF PIC X.
           02  FILLER REDEFINES TRNNAMEF.
               03  TRNNAMEA PIC X.
           02  TRNNAMEI PIC X(04).
           02  TITLEL PIC S9(04) COMP.
           02  TITLEF PIC X.
           02  FILLER REDEFINES TITLEF.
               03  TITLEA PIC X.
           02  TITLEI PIC X(40).
           02  CURDATEL PIC S9(04) COMP.
           02  CURDATEF PIC X.
           02  FILLER REDEFINES CURDATEF.
               03  CURDATEA PIC X.
           02  CURDATEI PIC X(10).
           02  PGMNAMEL PIC S9(04) COMP.
           02  PGMNAMEF PIC X.
           02  FILLER REDEFINES PGMNAMEF.
               03  PGMNAMEA PIC X.
           02  PGMNAMEI PIC X(08).
           02  CURTIMEL PIC S9(04) COMP.
           02  CURTIMEF PIC X.
           02  FILLER REDEFINES CURTIMEF.
               03  CURTIMEA PIC X.
           02  CURTIMEI PIC X(08).
           02  OPTIONL PIC S9(04) COMP.
           02  OPTIONF PIC X.
           02  FILLER REDEFINES OPTIONF.
               03  OPTIONA PIC X.
           02  OPTIONI PIC X(02).
           02  PARML PIC S9(04) COMP.
           02  PARMF PIC X.
           02  FILLER REDEFINES PARMF.
               03  PARMA PIC X.
           02  PARMI PIC X(16).
           02  RSTATL PIC S9(04) COMP.
           02  RSTATF PIC X.
           02  FILLER REDEFINES RSTATF.
               03  RSTATA PIC X.
           02  RSTATI PIC X(08).
           02  RMSGL PIC S9(04) COMP.
           02  RMSGF PIC X.
           02  FILLER REDEFINES RMSGF.
               03  RMSGA PIC X.
           02  RMSGI PIC X(58).
           02  RCREADL PIC S9(04) COMP.
           02  RCREADF PIC X.
           02  FILLER REDEFINES RCREADF.
               03  RCREADA PIC X.
           02  RCREADI PIC X(11).
           02  RCSELL PIC S9(04) COMP.
           02  RCSELF PIC X.
           02  FILLER REDEFINES RCSELF.
               03  RCSELA PIC X.
           02  RCSELI PIC X(11).
           02  RCPOSTL PIC S9(04) COMP.
           02  RCPOSTF PIC X.
           02  FILLER REDEFINES RCPOSTF.
               03  RCPOSTA PIC X.
           02  RCPOSTI PIC X(11).
           02  RCUPDL PIC S9(04) COMP.
           02  RCUPDF PIC X.
           02  FILLER REDEFINES RCUPDF.
               03  RCUPDA PIC X.
           02  RCUPDI PIC X(11).
           02  RCREJL PIC S9(04) COMP.
           02  RCREJF PIC X.
           02  FILLER REDEFINES RCREJF.
               03  RCREJA PIC X.
           02  RCREJI PIC X(11).
           02  RCTRANL PIC S9(04) COMP.
           02  RCTRANF PIC X.
           02  FILLER REDEFINES RCTRANF.
               03  RCTRANA PIC X.
           02  RCTRANI PIC X(11).
           02  RAMT1L PIC S9(04) COMP.
           02  RAMT1F PIC X.
           02  FILLER REDEFINES RAMT1F.
               03  RAMT1A PIC X.
           02  RAMT1I PIC X(18).
           02  RAMT2L PIC S9(04) COMP.
           02  RAMT2F PIC X.
           02  FILLER REDEFINES RAMT2F.
               03  RAMT2A PIC X.
           02  RAMT2I PIC X(18).
           02  ERRMSGL PIC S9(04) COMP.
           02  ERRMSGF PIC X.
           02  FILLER REDEFINES ERRMSGF.
               03  ERRMSGA PIC X.
           02  ERRMSGI PIC X(78).
       01  MOPSAO REDEFINES MOPSAI.
           02  FILLER PIC X(12).
           02  FILLER PIC X(03).
           02  TRNNAMEO PIC X(04).
           02  FILLER PIC X(03).
           02  TITLEO PIC X(40).
           02  FILLER PIC X(03).
           02  CURDATEO PIC X(10).
           02  FILLER PIC X(03).
           02  PGMNAMEO PIC X(08).
           02  FILLER PIC X(03).
           02  CURTIMEO PIC X(08).
           02  FILLER PIC X(03).
           02  OPTIONO PIC X(02).
           02  FILLER PIC X(03).
           02  PARMO PIC X(16).
           02  FILLER PIC X(03).
           02  RSTATO PIC X(08).
           02  FILLER PIC X(03).
           02  RMSGO PIC X(58).
           02  FILLER PIC X(03).
           02  RCREADO PIC X(11).
           02  FILLER PIC X(03).
           02  RCSELO PIC X(11).
           02  FILLER PIC X(03).
           02  RCPOSTO PIC X(11).
           02  FILLER PIC X(03).
           02  RCUPDO PIC X(11).
           02  FILLER PIC X(03).
           02  RCREJO PIC X(11).
           02  FILLER PIC X(03).
           02  RCTRANO PIC X(11).
           02  FILLER PIC X(03).
           02  RAMT1O PIC X(18).
           02  FILLER PIC X(03).
           02  RAMT2O PIC X(18).
           02  FILLER PIC X(03).
           02  ERRMSGO PIC X(78).
