      *----------------------------------------------------------------
      *  ORION-CCMS copybook - KAUTH : MQ authorization message area
      *  Request + response layouts carried in the MQ message buffer.
      *  Used in the LINKAGE SECTION (via CA-WORK-AREA overlay) as well
      *  as the WORKING-STORAGE of the driving screen, so NO data-name
      *  VALUE clauses appear here (only level-88 condition names).
      *----------------------------------------------------------------
       01  AUTH-MSG-AREA.
      *----------------------------------------------------------------
      *  Authorization request - sent to the request queue.
      *----------------------------------------------------------------
           05  AUTH-REQUEST.
               10  AQ-MSG-TYPE        PIC X(04).
               10  AQ-CARD-NUM        PIC X(16).
               10  AQ-ACCT-ID         PIC 9(11).
               10  AQ-AMOUNT          PIC S9(09)V99.
               10  AQ-MERCHANT-ID     PIC 9(09).
               10  AQ-MERCHANT-NAME   PIC X(50).
               10  AQ-REQUESTED-TS    PIC X(26).
               10  FILLER             PIC X(33).
      *----------------------------------------------------------------
      *  Authorization response - read back from the reply queue and
      *  also produced locally by the authorizer sub-program.
      *----------------------------------------------------------------
           05  AUTH-RESPONSE.
               10  AS-MSG-TYPE        PIC X(04).
               10  AS-CARD-NUM        PIC X(16).
               10  AS-ACCT-ID         PIC 9(11).
               10  AS-DECISION        PIC X(08).
                   88  AS-APPROVED             VALUE 'APPROVED'.
                   88  AS-DECLINED             VALUE 'DECLINED'.
                   88  AS-ERRORED              VALUE 'ERROR   '.
               10  AS-REASON          PIC X(20).
               10  AS-APPROVED-AMT    PIC S9(09)V99.
               10  AS-AVAIL-CREDIT    PIC S9(10)V99.
               10  AS-RESPONSE-TS     PIC X(26).
               10  FILLER             PIC X(12).
