      *----------------------------------------------------------------
      *  ORION-CCMS copybook - RSTMT : Statement record
      *----------------------------------------------------------------
       01  STMT-REC.
           05  ST-KEY.
             10  ST-ACCT-ID        PIC 9(11).
             10  ST-CYCLE          PIC 9(06).
           05  ST-OPEN-BAL         PIC S9(10)V99.
           05  ST-CLOSE-BAL        PIC S9(10)V99.
           05  ST-TOTAL-CREDIT     PIC S9(10)V99.
           05  ST-TOTAL-DEBIT      PIC S9(10)V99.
           05  ST-MIN-DUE          PIC S9(10)V99.
           05  ST-DUE-DATE         PIC X(10).
           05  FILLER              PIC X(20).
