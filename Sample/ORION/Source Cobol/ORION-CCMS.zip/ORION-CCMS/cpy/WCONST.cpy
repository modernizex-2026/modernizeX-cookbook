      *----------------------------------------------------------------
      *  ORION-CCMS copybook - WCONST : common working constants
      *----------------------------------------------------------------
       01  WS-CICS-RESP.
           05  WS-RESP-CD            PIC S9(09) COMP VALUE ZEROS.
           05  WS-REAS-CD            PIC S9(09) COMP VALUE ZEROS.
       01  WS-SWITCHES.
           05  WS-ERR-FLG           PIC X(01) VALUE 'N'.
               88  ERR-FLG-ON                 VALUE 'Y'.
               88  ERR-FLG-OFF                VALUE 'N'.
           05  WS-END-FLG           PIC X(01) VALUE 'N'.
               88  END-OF-FILE                VALUE 'Y'.
           05  WS-FOUND-FLG         PIC X(01) VALUE 'N'.
               88  REC-FOUND                  VALUE 'Y'.
               88  REC-NOT-FOUND              VALUE 'N'.
       01  WS-FILE-NAMES.
           05  WS-ACCTFILE          PIC X(08) VALUE 'ACCTFILE'.
           05  WS-CARDFILE          PIC X(08) VALUE 'CARDFILE'.
           05  WS-CUSTFILE          PIC X(08) VALUE 'CUSTFILE'.
           05  WS-XREFFILE          PIC X(08) VALUE 'XREFFILE'.
           05  WS-TRANFILE          PIC X(08) VALUE 'TRANFILE'.
           05  WS-TTYPFILE          PIC X(08) VALUE 'TTYPFILE'.
           05  WS-TCATFILE          PIC X(08) VALUE 'TCATFILE'.
           05  WS-DGRPFILE          PIC X(08) VALUE 'DGRPFILE'.
           05  WS-USRSEC            PIC X(08) VALUE 'USRSEC  '.
           05  WS-BILLFILE          PIC X(08) VALUE 'BILLFILE'.
           05  WS-STMTFILE          PIC X(08) VALUE 'STMTFILE'.
           05  WS-CTRLFILE          PIC X(08) VALUE 'CTRLFILE'.
       01  WS-WORK.
           05  WS-CNT               PIC 9(07) VALUE ZEROS.
           05  WS-IDX               PIC 9(04) VALUE ZEROS.
           05  WS-AMT               PIC S9(13)V99 VALUE ZEROS.
       01  WS-EDIT.
           05  WS-ED-AMT            PIC -,---,---,--9.99.
           05  WS-ED-BAL            PIC -,---,---,--9.99.
           05  WS-ED-ID             PIC ZZZZZZZZZZ9.
