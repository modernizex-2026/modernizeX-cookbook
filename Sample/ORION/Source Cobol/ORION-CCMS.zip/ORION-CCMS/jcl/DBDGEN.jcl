//DBDGEN   JOB (ACCT),'ORION DBDGEN OPAUDB',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : DBDGEN   - generate the DBD for OPAUDB          *
//*  Assembles the DBD macro source member OPAUDB and links    *
//*  the resulting DBD block into ORION.DBDLIB using the IMS   *
//*  DBDGEN cataloged procedure.                               *
//***************************************************************
//DBDGEN   EXEC DBDGEN,MBR=OPAUDB
//C.SYSIN  DD DISP=SHR,DSN=ORION.SOURCE.DBD(OPAUDB)
//L.SYSLMOD DD DISP=SHR,DSN=ORION.DBDLIB(OPAUDB)
//*
