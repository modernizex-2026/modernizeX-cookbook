//PSBGEN   JOB (ACCT),'ORION PSBGEN OPAUPSB',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : PSBGEN   - generate the PSB for OPAUPSB         *
//*  Assembles the PSB macro source member OPAUPSB and links   *
//*  the resulting PSB block into ORION.PSBLIB using the IMS   *
//*  PSBGEN cataloged procedure.                               *
//***************************************************************
//PSBGEN   EXEC PSBGEN,MBR=OPAUPSB
//C.SYSIN  DD DISP=SHR,DSN=ORION.SOURCE.PSB(OPAUPSB)
//L.SYSLMOD DD DISP=SHR,DSN=ORION.PSBLIB(OPAUPSB)
//*
