//RUNDCUST JOB (ACCT),'ORION RUN ODCUSTP',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : RUNDCUSTP- DB2 customer maintenance load        *
//*  Runs ODCUSTP under IKJEFT01 via DSN RUN, PLAN(ODCUSTP)    *
//*  bound from DBRM member ODCUSTP.  Applies the sequential   *
//*  CUSTIN maintenance file (add/change/delete) to the DB2    *
//*  CUSTOMER table and reports counts to RPTFILE.             *
//***************************************************************
//DCUSTP   EXEC PGM=IKJEFT01,DYNAMNBR=20,COND=(4,LT),REGION=0M
//STEPLIB  DD DSN=ORION.LOADLIB,DISP=SHR
//         DD DSN=DSN.V12R1M0.SDSNEXIT,DISP=SHR
//         DD DSN=DSN.V12R1M0.SDSNLOAD,DISP=SHR
//DBRMLIB  DD DSN=ORION.DBRMLIB,DISP=SHR
//CUSTIN   DD DSN=ORION.CUST.MAINT.SEQ,DISP=SHR
//RPTFILE  DD SYSOUT=*
//SYSTSPRT DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//SYSOUT   DD SYSOUT=*
//CEEDUMP  DD SYSOUT=*
//SYSUDUMP DD SYSOUT=*
//SYSTSIN  DD *
  DSN SYSTEM(DB2P)
  RUN  PROGRAM(ODCUSTP) PLAN(ODCUSTP) -
       LIB('ORION.LOADLIB')
  END
/*
