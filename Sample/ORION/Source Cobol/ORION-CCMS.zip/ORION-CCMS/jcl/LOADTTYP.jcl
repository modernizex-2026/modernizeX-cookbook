//LOADTTYP JOB (ACCT),'ORION LOAD TTYPFILE',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : LOADTTYP - IDCAMS REPRO load TTYPFILE           *
//*  Load the VSAM KSDS from a fixed-format sequential         *
//*  input dataset ORION.TTYPFILE.SEQ (RECFM=FB,LRECL=60).     *
//***************************************************************
//REPRO    EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SEQIN    DD DSN=ORION.TTYPFILE.SEQ,DISP=SHR
//VSAMOUT  DD DSN=ORION.TTYPFILE,DISP=SHR
//SYSIN    DD *
  REPRO INFILE(SEQIN)                           -
        OUTFILE(VSAMOUT)                        -
        REPLACE
/*
