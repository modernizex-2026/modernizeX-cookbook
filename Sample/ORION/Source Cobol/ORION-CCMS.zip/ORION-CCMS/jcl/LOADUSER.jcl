//LOADUSER JOB (ACCT),'ORION LOAD USRSEC',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : LOADUSER - IDCAMS REPRO load USRSEC             *
//*  Load the VSAM KSDS from a fixed-format sequential         *
//*  input dataset ORION.USRSEC.SEQ (RECFM=FB,LRECL=80).       *
//***************************************************************
//REPRO    EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SEQIN    DD DSN=ORION.USRSEC.SEQ,DISP=SHR
//VSAMOUT  DD DSN=ORION.USRSEC,DISP=SHR
//SYSIN    DD *
  REPRO INFILE(SEQIN)                           -
        OUTFILE(VSAMOUT)                        -
        REPLACE
/*
