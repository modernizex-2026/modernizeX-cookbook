//RUNMQBRG JOB (ACCT),'ORION RUN OUMQBRG',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : RUNMQBRG - VSAM-to-MQ transaction bridge        *
//*  Runs OUMQBRG - reads TRANFILE (VSAM KSDS) in key order    *
//*  and MQPUTs each transaction to ORION.TRAN.OUTBOUND.QUEUE  *
//*  on queue manager ORIONQM1 for downstream consumers.       *
//*  STEPLIB adds the MQ batch runtime (SCSQLOAD/SCSQANLE/     *
//*  SCSQAUTH); OUMQBRG is link-edited with the MQ batch stub  *
//*  CSQBSTUB.  Define the queue first with jcl/DEFMQ.jcl.     *
//***************************************************************
//BRIDGE   EXEC PGM=OUMQBRG
//STEPLIB  DD DSN=ORION.LOADLIB,DISP=SHR
//         DD DSN=MQM.V9R3M0.SCSQLOAD,DISP=SHR
//         DD DSN=MQM.V9R3M0.SCSQANLE,DISP=SHR
//         DD DSN=MQM.V9R3M0.SCSQAUTH,DISP=SHR
//TRANFILE DD DSN=ORION.TRANFILE,DISP=SHR
//SYSOUT   DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//CEEDUMP  DD SYSOUT=*
//SYSUDUMP DD SYSOUT=*
//*
//*  The queue manager name is coded inside OUMQBRG as
//*  WS-QMGR-NAME = 'ORIONQM1'.  If MQCONN or MQOPEN fail the
//*  job still reads TRANFILE and reports counts (RC=0), so it
//*  is safe to run before the queue manager is available.
