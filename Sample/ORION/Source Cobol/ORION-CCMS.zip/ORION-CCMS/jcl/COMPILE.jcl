//COMPILE  JOB (ACCT),'ORION COMPILE SAMPLES',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : COMPILE  - Translate/compile/link samples       *
//*  STEP OCACCTV : CICS command-level online program via the  *
//*    DFHYITVL proc (translate + COBOL compile + link-edit).  *
//*  STEP OBACCTP : batch program via the IGYWCL proc          *
//*    (COBOL compile + link-edit); copybooks ORION.COPYLIB.   *
//***************************************************************
//*
//*  Online program - OCACCTV (tran ORAV, mapset MACCTV)       *
//OCACCTV  EXEC DFHYITVL,
//         INDEX='CICSTS.V6R1M0',
//         PROGLIB='ORION.LOADLIB',
//         DSCTLIB='ORION.COPYLIB'
//TRN.SYSIN DD DSN=ORION.SOURCE(OCACCTV),DISP=SHR
//COBOL.SYSLIB DD DSN=ORION.COPYLIB,DISP=SHR
//LKED.SYSLMOD DD DSN=ORION.LOADLIB(OCACCTV),DISP=SHR
//*
//*  Batch program - OBACCTP                                   *
//OBACCTP  EXEC IGYWCL,
//         PARM.COBOL='RENT,MAP,LIST,XREF'
//COBOL.SYSIN DD DSN=ORION.SOURCE(OBACCTP),DISP=SHR
//COBOL.SYSLIB DD DSN=ORION.COPYLIB,DISP=SHR
//LKED.SYSLMOD DD DSN=ORION.LOADLIB(OBACCTP),DISP=SHR
//LKED.SYSIN DD *
  NAME OBACCTP(R)
/*
