//RUNDSTMT JOB (ACCT),'ORION RUN ODSTMT',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : RUNDSTMT - DB2 statement generation             *
//*  Runs ODSTMT under IKJEFT01 via DSN RUN, PLAN(ODSTMT)      *
//*  bound from DBRM member ODSTMT.  Reads the DB2 ACCOUNT,    *
//*  CUSTOMER and TRANSACT tables, INSERTs STATEMENT rows      *
//*  and writes the print image to STMTRPT.                    *
//***************************************************************
//DSTMT    EXEC PGM=IKJEFT01,DYNAMNBR=20,COND=(4,LT),REGION=0M
//STEPLIB  DD DSN=ORION.LOADLIB,DISP=SHR
//         DD DSN=DSN.V12R1M0.SDSNEXIT,DISP=SHR
//         DD DSN=DSN.V12R1M0.SDSNLOAD,DISP=SHR
//DBRMLIB  DD DSN=ORION.DBRMLIB,DISP=SHR
//STMTRPT  DD DSN=ORION.DB2.STMT.PRINT,
//            DISP=(NEW,CATLG,DELETE),
//            SPACE=(CYL,(10,5),RLSE),UNIT=SYSDA,
//            DCB=(RECFM=FB,LRECL=132,BLKSIZE=0)
//RPTFILE  DD SYSOUT=*
//SYSTSPRT DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//SYSOUT   DD SYSOUT=*
//CEEDUMP  DD SYSOUT=*
//SYSUDUMP DD SYSOUT=*
//SYSTSIN  DD *
  DSN SYSTEM(DB2P)
  RUN  PROGRAM(ODSTMT) PLAN(ODSTMT) -
       LIB('ORION.LOADLIB')
  END
/*
