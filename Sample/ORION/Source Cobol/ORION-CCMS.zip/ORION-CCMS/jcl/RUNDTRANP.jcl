//RUNDTRAN JOB (ACCT),'ORION RUN ODTRANP',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : RUNDTRANP- DB2 daily transaction posting        *
//*  Runs ODTRANP under IKJEFT01 via DSN RUN, PLAN(ODTRANP)    *
//*  bound from DBRM member ODTRANP.  Reads the sequential     *
//*  TRANIN file, INSERTs into the DB2 TRANSACT table,         *
//*  UPDATEs ACCOUNT balances and writes rejects to REJFILE.   *
//***************************************************************
//DTRANP   EXEC PGM=IKJEFT01,DYNAMNBR=20,COND=(4,LT),REGION=0M
//STEPLIB  DD DSN=ORION.LOADLIB,DISP=SHR
//         DD DSN=DSN.V12R1M0.SDSNEXIT,DISP=SHR
//         DD DSN=DSN.V12R1M0.SDSNLOAD,DISP=SHR
//DBRMLIB  DD DSN=ORION.DBRMLIB,DISP=SHR
//TRANIN   DD DSN=ORION.DALYTRAN.SEQ,DISP=SHR
//REJFILE  DD DSN=ORION.DB2.TRANP.REJECT,
//            DISP=(NEW,CATLG,DELETE),
//            SPACE=(CYL,(5,2),RLSE),UNIT=SYSDA,
//            DCB=(RECFM=FB,LRECL=350,BLKSIZE=0)
//RPTFILE  DD SYSOUT=*
//SYSTSPRT DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//SYSOUT   DD SYSOUT=*
//CEEDUMP  DD SYSOUT=*
//SYSUDUMP DD SYSOUT=*
//SYSTSIN  DD *
  DSN SYSTEM(DB2P)
  RUN  PROGRAM(ODTRANP) PLAN(ODTRANP) -
       LIB('ORION.LOADLIB')
  END
/*
