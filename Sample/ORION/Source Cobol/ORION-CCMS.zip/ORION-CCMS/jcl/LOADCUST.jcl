//LOADCUST JOB (ACCT),'ORION LOAD CUSTFILE',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : LOADCUST - IDCAMS REPRO load CUSTFILE           *
//*  Load the VSAM KSDS from a fixed-format sequential         *
//*  input dataset ORION.CUSTFILE.SEQ (RECFM=FB,LRECL=372).    *
//***************************************************************
//REPRO    EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SEQIN    DD DSN=ORION.CUSTFILE.SEQ,DISP=SHR
//VSAMOUT  DD DSN=ORION.CUSTFILE,DISP=SHR
//SYSIN    DD *
  REPRO INFILE(SEQIN)                           -
        OUTFILE(VSAMOUT)                        -
        REPLACE
/*
