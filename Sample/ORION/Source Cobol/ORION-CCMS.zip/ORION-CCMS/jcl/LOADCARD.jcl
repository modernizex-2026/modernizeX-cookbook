//LOADCARD JOB (ACCT),'ORION LOAD CARDFILE',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : LOADCARD - IDCAMS REPRO load CARDFILE           *
//*  Load the VSAM KSDS from a fixed-format sequential         *
//*  input dataset ORION.CARDFILE.SEQ (RECFM=FB,LRECL=150).    *
//***************************************************************
//REPRO    EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SEQIN    DD DSN=ORION.CARDFILE.SEQ,DISP=SHR
//VSAMOUT  DD DSN=ORION.CARDFILE,DISP=SHR
//SYSIN    DD *
  REPRO INFILE(SEQIN)                           -
        OUTFILE(VSAMOUT)                        -
        REPLACE
/*
//*
//*  Build alternate index CARDFILE.AIX1                       *
//CARDBX1  EXEC PGM=IDCAMS,COND=(0,NE)
//SYSPRINT DD SYSOUT=*
//IDCUT1   DD DSN=&&IDCUT1,DISP=(NEW,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(2,1))
//IDCUT2   DD DSN=&&IDCUT2,DISP=(NEW,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(2,1))
//SYSIN    DD *
  BLDINDEX INDATASET(ORION.CARDFILE)            -
           OUTDATASET(ORION.CARDFILE.AIX1)
/*
