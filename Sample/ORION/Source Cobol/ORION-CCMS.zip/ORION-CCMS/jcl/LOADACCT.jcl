//LOADACCT JOB (ACCT),'ORION LOAD ACCTFILE',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : LOADACCT - IDCAMS REPRO load ACCTFILE           *
//*  Load the VSAM KSDS from a fixed-format sequential         *
//*  input dataset ORION.ACCTFILE.SEQ (RECFM=FB,LRECL=300).    *
//***************************************************************
//REPRO    EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SEQIN    DD DSN=ORION.ACCTFILE.SEQ,DISP=SHR
//VSAMOUT  DD DSN=ORION.ACCTFILE,DISP=SHR
//SYSIN    DD *
  REPRO INFILE(SEQIN)                           -
        OUTFILE(VSAMOUT)                        -
        REPLACE
/*
