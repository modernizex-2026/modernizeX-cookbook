//LOADXREF JOB (ACCT),'ORION LOAD XREFFILE',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : LOADXREF - IDCAMS REPRO load XREFFILE           *
//*  Load the VSAM KSDS from a fixed-format sequential         *
//*  input dataset ORION.XREFFILE.SEQ (RECFM=FB,LRECL=50).     *
//***************************************************************
//REPRO    EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SEQIN    DD DSN=ORION.XREFFILE.SEQ,DISP=SHR
//VSAMOUT  DD DSN=ORION.XREFFILE,DISP=SHR
//SYSIN    DD *
  REPRO INFILE(SEQIN)                           -
        OUTFILE(VSAMOUT)                        -
        REPLACE
/*
//*
//*  Build alternate index XREFFILE.AIX1                       *
//XREFBX1  EXEC PGM=IDCAMS,COND=(0,NE)
//SYSPRINT DD SYSOUT=*
//IDCUT1   DD DSN=&&IDCUT1,DISP=(NEW,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(2,1))
//IDCUT2   DD DSN=&&IDCUT2,DISP=(NEW,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(2,1))
//SYSIN    DD *
  BLDINDEX INDATASET(ORION.XREFFILE)            -
           OUTDATASET(ORION.XREFFILE.AIX1)
/*
//*
//*  Build alternate index XREFFILE.AIX2                       *
//XREFBX2  EXEC PGM=IDCAMS,COND=(0,NE)
//SYSPRINT DD SYSOUT=*
//IDCUT1   DD DSN=&&IDCUT1,DISP=(NEW,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(2,1))
//IDCUT2   DD DSN=&&IDCUT2,DISP=(NEW,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(2,1))
//SYSIN    DD *
  BLDINDEX INDATASET(ORION.XREFFILE)            -
           OUTDATASET(ORION.XREFFILE.AIX2)
/*
