//DEFMQ    JOB (ACCT),'ORION DEFINE MQ',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : DEFMQ - define the local queues used by the     *
//*            ORION MQ authorization + bridge slice.          *
//*  Runs CSQUTIL COMMAND against queue manager ORIONQM1 and   *
//*  feeds MQSC DEFINE QLOCAL statements from MQSCIN.  Rerun    *
//*  safe: every queue is defined with REPLACE.                *
//*                                                            *
//*  Queues (documentation) :                                  *
//*   ORION.AUTH.REQUEST.QUEUE  - auth requests  (OUMQREQ put) *
//*   ORION.AUTH.REPLY.QUEUE    - auth replies    (OUMQREQ get)*
//*   ORION.TRAN.OUTBOUND.QUEUE - tran feed       (OUMQBRG put)*
//***************************************************************
//DEFQ     EXEC PGM=CSQUTIL,PARM='ORIONQM1'
//STEPLIB  DD DSN=MQM.V9R3M0.SCSQLOAD,DISP=SHR
//         DD DSN=MQM.V9R3M0.SCSQANLE,DISP=SHR
//         DD DSN=MQM.V9R3M0.SCSQAUTH,DISP=SHR
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
 COMMAND DDNAME(MQSCIN)
/*
//MQSCIN   DD *
*  -------------------------------------------------------------
*  Authorization request queue - OCAUTHQ/OUMQREQ MQPUT requests
*  -------------------------------------------------------------
 DEFINE QLOCAL('ORION.AUTH.REQUEST.QUEUE') REPLACE +
        DESCR('ORION auth requests') +
        DEFPSIST(YES) +
        MAXDEPTH(50000) +
        MAXMSGL(4096) +
        SHARE DEFSOPT(SHARED)
*  -------------------------------------------------------------
*  Authorization reply queue - OUMQREQ MQGETs the decision here
*  -------------------------------------------------------------
 DEFINE QLOCAL('ORION.AUTH.REPLY.QUEUE') REPLACE +
        DESCR('ORION auth replies') +
        DEFPSIST(YES) +
        MAXDEPTH(50000) +
        MAXMSGL(4096) +
        SHARE DEFSOPT(SHARED)
*  -------------------------------------------------------------
*  Outbound transaction feed - OUMQBRG MQPUTs tran images here
*  -------------------------------------------------------------
 DEFINE QLOCAL('ORION.TRAN.OUTBOUND.QUEUE') REPLACE +
        DESCR('ORION outbound tran feed') +
        DEFPSIST(YES) +
        MAXDEPTH(100000) +
        MAXMSGL(4096) +
        SHARE DEFSOPT(SHARED)
/*
