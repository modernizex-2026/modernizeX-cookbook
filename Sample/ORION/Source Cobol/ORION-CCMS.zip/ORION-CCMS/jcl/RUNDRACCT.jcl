//RUNDRACC JOB (ACCT),'ORION RUN ODRACCT',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : RUNDRACCT- DB2 account report by group          *
//*  Runs ODRACCT under IKJEFT01 via DSN RUN, PLAN(ODRACCT)    *
//*  bound from DBRM member ODRACCT.  SELECTs from the DB2     *
//*  ACCOUNT table joined to DISCGRP and prints subtotals      *
//*  per disclosure group to RPTFILE.                          *
//***************************************************************
//DRACCT   EXEC PGM=IKJEFT01,DYNAMNBR=20,COND=(4,LT),REGION=0M
//STEPLIB  DD DSN=ORION.LOADLIB,DISP=SHR
//         DD DSN=DSN.V12R1M0.SDSNEXIT,DISP=SHR
//         DD DSN=DSN.V12R1M0.SDSNLOAD,DISP=SHR
//DBRMLIB  DD DSN=ORION.DBRMLIB,DISP=SHR
//RPTFILE  DD SYSOUT=*
//SYSTSPRT DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//SYSOUT   DD SYSOUT=*
//CEEDUMP  DD SYSOUT=*
//SYSUDUMP DD SYSOUT=*
//SYSTSIN  DD *
  DSN SYSTEM(DB2P)
  RUN  PROGRAM(ODRACCT) PLAN(ODRACCT) -
       LIB('ORION.LOADLIB')
  END
/*
