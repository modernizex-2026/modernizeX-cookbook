//LOADCTRL JOB (ACCT),'ORION LOAD CTRLFILE',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : LOADCTRL - IDCAMS REPRO load CTRLFILE           *
//*  Load the VSAM KSDS from a fixed-format sequential         *
//*  input dataset ORION.CTRLFILE.SEQ (RECFM=FB,LRECL=60).     *
//***************************************************************
//REPRO    EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SEQIN    DD DSN=ORION.CTRLFILE.SEQ,DISP=SHR
//VSAMOUT  DD DSN=ORION.CTRLFILE,DISP=SHR
//SYSIN    DD *
  REPRO INFILE(SEQIN)                           -
        OUTFILE(VSAMOUT)                        -
        REPLACE
/*
