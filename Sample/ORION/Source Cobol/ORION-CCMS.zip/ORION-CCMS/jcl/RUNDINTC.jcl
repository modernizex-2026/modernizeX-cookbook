//RUNDINTC JOB (ACCT),'ORION RUN ODINTC',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : RUNDINTC - DB2 cycle interest calculation       *
//*  Runs ODINTC under IKJEFT01 via DSN RUN, PLAN(ODINTC)      *
//*  bound from DBRM member ODINTC.  Computes cycle interest   *
//*  from the DB2 DISCGRP rate table, UPDATEs ACCOUNT and      *
//*  INSERTs interest rows into TRANSACT.                      *
//***************************************************************
//DINTC    EXEC PGM=IKJEFT01,DYNAMNBR=20,COND=(4,LT),REGION=0M
//STEPLIB  DD DSN=ORION.LOADLIB,DISP=SHR
//         DD DSN=DSN.V12R1M0.SDSNEXIT,DISP=SHR
//         DD DSN=DSN.V12R1M0.SDSNLOAD,DISP=SHR
//DBRMLIB  DD DSN=ORION.DBRMLIB,DISP=SHR
//RPTFILE  DD SYSOUT=*
//SYSTSPRT DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//SYSOUT   DD SYSOUT=*
//CEEDUMP  DD SYSOUT=*
//SYSUDUMP DD SYSOUT=*
//SYSTSIN  DD *
  DSN SYSTEM(DB2P)
  RUN  PROGRAM(ODINTC) PLAN(ODINTC) -
       LIB('ORION.LOADLIB')
  END
/*
