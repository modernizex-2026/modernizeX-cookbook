//ACBGEN   JOB (ACCT),'ORION ACBGEN',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : ACBGEN   - build application control blocks     *
//*  Merges the OPAUDB DBD and OPAUPSB PSB into the ACB        *
//*  library ORION.ACBLIB so the online CICS-DLI region can    *
//*  schedule the PSB used by sub OUIMSPA.                     *
//***************************************************************
//ACBGEN   EXEC ACBGEN
//SYSIN    DD *
  BUILD PSB=(OPAUPSB)
/*
//*
