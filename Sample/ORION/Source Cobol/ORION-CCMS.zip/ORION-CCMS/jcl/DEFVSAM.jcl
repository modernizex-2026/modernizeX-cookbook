//DEFVSAM  JOB (ACCT),'ORION DEFINE VSAM',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  STEP    : DEFVSAM  - IDCAMS DEFINE CLUSTER - all 12 KSDS  *
//*  Creates the base KSDS clusters plus alternate indexes     *
//*  and paths.  DELETE precedes DEFINE so the job reruns      *
//*  cleanly.  BLDINDEX is run by the LOAD* jobs after load.   *
//***************************************************************
//*
//*  ACCTFILE  KSDS  RECSZ=300  KEY=(11,0)                     *
//DEFACCTF EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.ACCTFILE CLUSTER PURGE
  SET MAXCC = 0
  DEFINE CLUSTER                                -
         (NAME(ORION.ACCTFILE)                  -
          INDEXED                               -
          KEYS(11 0)                            -
          RECORDSIZE(300 300)                   -
          CYLINDERS(5 2)                        -
          FREESPACE(10 10)                      -
          SHAREOPTIONS(2 3)                     -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.ACCTFILE.DATA)             -
          CISZ(4096))                           -
    INDEX(NAME(ORION.ACCTFILE.INDEX))
/*
//*
//*  CARDFILE  KSDS  RECSZ=150  KEY=(16,0)                     *
//DEFCARDF EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.CARDFILE CLUSTER PURGE
  SET MAXCC = 0
  DEFINE CLUSTER                                -
         (NAME(ORION.CARDFILE)                  -
          INDEXED                               -
          KEYS(16 0)                            -
          RECORDSIZE(150 150)                   -
          CYLINDERS(2 1)                        -
          FREESPACE(10 10)                      -
          SHAREOPTIONS(2 3)                     -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.CARDFILE.DATA)             -
          CISZ(4096))                           -
    INDEX(NAME(ORION.CARDFILE.INDEX))
/*
//*
//*  ALT INDEX CARDFILE.AIX1  KEY=(11,16)                      *
//CARDAX1  EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.CARDFILE.AIX1 ALTERNATEINDEX PURGE
  SET MAXCC = 0
  DEFINE ALTERNATEINDEX                         -
         (NAME(ORION.CARDFILE.AIX1)             -
          RELATE(ORION.CARDFILE)                -
          KEYS(11 16)                           -
          RECORDSIZE(150 150)                   -
          NONUNIQUEKEY                          -
          UPGRADE                               -
          TRACKS(2 1)                           -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.CARDFILE.AIX1.DATA))
  DEFINE PATH                                   -
         (NAME(ORION.CARDFILE.PATH1)            -
          PATHENTRY(ORION.CARDFILE.AIX1))
/*
//*
//*  CUSTFILE  KSDS  RECSZ=372  KEY=(9,0)                      *
//DEFCUSTF EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.CUSTFILE CLUSTER PURGE
  SET MAXCC = 0
  DEFINE CLUSTER                                -
         (NAME(ORION.CUSTFILE)                  -
          INDEXED                               -
          KEYS(9 0)                             -
          RECORDSIZE(372 372)                   -
          CYLINDERS(5 2)                        -
          FREESPACE(10 10)                      -
          SHAREOPTIONS(2 3)                     -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.CUSTFILE.DATA)             -
          CISZ(4096))                           -
    INDEX(NAME(ORION.CUSTFILE.INDEX))
/*
//*
//*  XREFFILE  KSDS  RECSZ=50  KEY=(16,0)                      *
//DEFXREFF EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.XREFFILE CLUSTER PURGE
  SET MAXCC = 0
  DEFINE CLUSTER                                -
         (NAME(ORION.XREFFILE)                  -
          INDEXED                               -
          KEYS(16 0)                            -
          RECORDSIZE(50 50)                     -
          CYLINDERS(2 1)                        -
          FREESPACE(10 10)                      -
          SHAREOPTIONS(2 3)                     -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.XREFFILE.DATA)             -
          CISZ(4096))                           -
    INDEX(NAME(ORION.XREFFILE.INDEX))
/*
//*
//*  ALT INDEX XREFFILE.AIX1  KEY=(11,16)                      *
//XREFAX1  EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.XREFFILE.AIX1 ALTERNATEINDEX PURGE
  SET MAXCC = 0
  DEFINE ALTERNATEINDEX                         -
         (NAME(ORION.XREFFILE.AIX1)             -
          RELATE(ORION.XREFFILE)                -
          KEYS(11 16)                           -
          RECORDSIZE(50 50)                     -
          NONUNIQUEKEY                          -
          UPGRADE                               -
          TRACKS(2 1)                           -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.XREFFILE.AIX1.DATA))
  DEFINE PATH                                   -
         (NAME(ORION.XREFFILE.PATH1)            -
          PATHENTRY(ORION.XREFFILE.AIX1))
/*
//*
//*  ALT INDEX XREFFILE.AIX2  KEY=(9,27)                       *
//XREFAX2  EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.XREFFILE.AIX2 ALTERNATEINDEX PURGE
  SET MAXCC = 0
  DEFINE ALTERNATEINDEX                         -
         (NAME(ORION.XREFFILE.AIX2)             -
          RELATE(ORION.XREFFILE)                -
          KEYS(9 27)                            -
          RECORDSIZE(50 50)                     -
          NONUNIQUEKEY                          -
          UPGRADE                               -
          TRACKS(2 1)                           -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.XREFFILE.AIX2.DATA))
  DEFINE PATH                                   -
         (NAME(ORION.XREFFILE.PATH2)            -
          PATHENTRY(ORION.XREFFILE.AIX2))
/*
//*
//*  TRANFILE  KSDS  RECSZ=350  KEY=(16,0)                     *
//DEFTRANF EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.TRANFILE CLUSTER PURGE
  SET MAXCC = 0
  DEFINE CLUSTER                                -
         (NAME(ORION.TRANFILE)                  -
          INDEXED                               -
          KEYS(16 0)                            -
          RECORDSIZE(350 350)                   -
          CYLINDERS(10 5)                       -
          FREESPACE(10 10)                      -
          SHAREOPTIONS(2 3)                     -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.TRANFILE.DATA)             -
          CISZ(4096))                           -
    INDEX(NAME(ORION.TRANFILE.INDEX))
/*
//*
//*  ALT INDEX TRANFILE.AIX1  KEY=(16,262)                     *
//TRANAX1  EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.TRANFILE.AIX1 ALTERNATEINDEX PURGE
  SET MAXCC = 0
  DEFINE ALTERNATEINDEX                         -
         (NAME(ORION.TRANFILE.AIX1)             -
          RELATE(ORION.TRANFILE)                -
          KEYS(16 262)                          -
          RECORDSIZE(350 350)                   -
          NONUNIQUEKEY                          -
          UPGRADE                               -
          TRACKS(2 1)                           -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.TRANFILE.AIX1.DATA))
  DEFINE PATH                                   -
         (NAME(ORION.TRANFILE.PATH1)            -
          PATHENTRY(ORION.TRANFILE.AIX1))
/*
//*
//*  TTYPFILE  KSDS  RECSZ=60  KEY=(2,0)                       *
//DEFTTYPF EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.TTYPFILE CLUSTER PURGE
  SET MAXCC = 0
  DEFINE CLUSTER                                -
         (NAME(ORION.TTYPFILE)                  -
          INDEXED                               -
          KEYS(2 0)                             -
          RECORDSIZE(60 60)                     -
          TRACKS(1 1)                           -
          FREESPACE(10 10)                      -
          SHAREOPTIONS(2 3)                     -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.TTYPFILE.DATA)             -
          CISZ(4096))                           -
    INDEX(NAME(ORION.TTYPFILE.INDEX))
/*
//*
//*  TCATFILE  KSDS  RECSZ=60  KEY=(6,0)                       *
//DEFTCATF EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.TCATFILE CLUSTER PURGE
  SET MAXCC = 0
  DEFINE CLUSTER                                -
         (NAME(ORION.TCATFILE)                  -
          INDEXED                               -
          KEYS(6 0)                             -
          RECORDSIZE(60 60)                     -
          TRACKS(1 1)                           -
          FREESPACE(10 10)                      -
          SHAREOPTIONS(2 3)                     -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.TCATFILE.DATA)             -
          CISZ(4096))                           -
    INDEX(NAME(ORION.TCATFILE.INDEX))
/*
//*
//*  DGRPFILE  KSDS  RECSZ=50  KEY=(16,0)                      *
//DEFDGRPF EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.DGRPFILE CLUSTER PURGE
  SET MAXCC = 0
  DEFINE CLUSTER                                -
         (NAME(ORION.DGRPFILE)                  -
          INDEXED                               -
          KEYS(16 0)                            -
          RECORDSIZE(50 50)                     -
          TRACKS(1 1)                           -
          FREESPACE(10 10)                      -
          SHAREOPTIONS(2 3)                     -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.DGRPFILE.DATA)             -
          CISZ(4096))                           -
    INDEX(NAME(ORION.DGRPFILE.INDEX))
/*
//*
//*  USRSEC    KSDS  RECSZ=80  KEY=(8,0)                       *
//DEFUSRSE EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.USRSEC CLUSTER PURGE
  SET MAXCC = 0
  DEFINE CLUSTER                                -
         (NAME(ORION.USRSEC)                    -
          INDEXED                               -
          KEYS(8 0)                             -
          RECORDSIZE(80 80)                     -
          TRACKS(2 1)                           -
          FREESPACE(10 10)                      -
          SHAREOPTIONS(2 3)                     -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.USRSEC.DATA)               -
          CISZ(4096))                           -
    INDEX(NAME(ORION.USRSEC.INDEX))
/*
//*
//*  BILLFILE  KSDS  RECSZ=81  KEY=(11,0)                      *
//DEFBILLF EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.BILLFILE CLUSTER PURGE
  SET MAXCC = 0
  DEFINE CLUSTER                                -
         (NAME(ORION.BILLFILE)                  -
          INDEXED                               -
          KEYS(11 0)                            -
          RECORDSIZE(81 81)                     -
          CYLINDERS(2 1)                        -
          FREESPACE(10 10)                      -
          SHAREOPTIONS(2 3)                     -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.BILLFILE.DATA)             -
          CISZ(4096))                           -
    INDEX(NAME(ORION.BILLFILE.INDEX))
/*
//*
//*  STMTFILE  KSDS  RECSZ=107  KEY=(17,0)                     *
//DEFSTMTF EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.STMTFILE CLUSTER PURGE
  SET MAXCC = 0
  DEFINE CLUSTER                                -
         (NAME(ORION.STMTFILE)                  -
          INDEXED                               -
          KEYS(17 0)                            -
          RECORDSIZE(107 107)                   -
          CYLINDERS(2 1)                        -
          FREESPACE(10 10)                      -
          SHAREOPTIONS(2 3)                     -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.STMTFILE.DATA)             -
          CISZ(4096))                           -
    INDEX(NAME(ORION.STMTFILE.INDEX))
/*
//*
//*  CTRLFILE  KSDS  RECSZ=60  KEY=(8,0)                       *
//DEFCTRLF EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  DELETE ORION.CTRLFILE CLUSTER PURGE
  SET MAXCC = 0
  DEFINE CLUSTER                                -
         (NAME(ORION.CTRLFILE)                  -
          INDEXED                               -
          KEYS(8 0)                             -
          RECORDSIZE(60 60)                     -
          TRACKS(1 1)                           -
          FREESPACE(10 10)                      -
          SHAREOPTIONS(2 3)                     -
          VOLUMES(ORVOL1))                      -
    DATA (NAME(ORION.CTRLFILE.DATA)             -
          CISZ(4096))                           -
    INDEX(NAME(ORION.CTRLFILE.INDEX))
/*
