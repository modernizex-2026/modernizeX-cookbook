//LOADDGRP JOB (ACCT),'ORION LOAD DGRPFILE',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : LOADDGRP - IDCAMS REPRO load DGRPFILE           *
//*  Load the VSAM KSDS from a fixed-format sequential         *
//*  input dataset ORION.DGRPFILE.SEQ (RECFM=FB,LRECL=50).     *
//***************************************************************
//REPRO    EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SEQIN    DD DSN=ORION.DGRPFILE.SEQ,DISP=SHR
//VSAMOUT  DD DSN=ORION.DGRPFILE,DISP=SHR
//SYSIN    DD *
  REPRO INFILE(SEQIN)                           -
        OUTFILE(VSAMOUT)                        -
        REPLACE
/*
