//RUNDACCT JOB (ACCT),'ORION RUN ODACCTP',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : RUNDACCTP- DB2 account posting / extract        *
//*  Runs ODACCTP under TSO batch (IKJEFT01) via the DSN RUN   *
//*  sub-command, PLAN(ODACCTP) bound from DBRM member ODACCTP *
//*  in ORION.DBRMLIB.  Reads the DB2 ACCOUNT / CARDXREF       *
//*  tables, writes the extract to ACCTEXT and a control       *
//*  report to RPTFILE.                                        *
//***************************************************************
//DACCTP   EXEC PGM=IKJEFT01,DYNAMNBR=20,COND=(4,LT),REGION=0M
//STEPLIB  DD DSN=ORION.LOADLIB,DISP=SHR
//         DD DSN=DSN.V12R1M0.SDSNEXIT,DISP=SHR
//         DD DSN=DSN.V12R1M0.SDSNLOAD,DISP=SHR
//DBRMLIB  DD DSN=ORION.DBRMLIB,DISP=SHR
//ACCTEXT  DD DSN=ORION.DB2.ACCT.EXTRACT,
//            DISP=(NEW,CATLG,DELETE),
//            SPACE=(CYL,(10,5),RLSE),UNIT=SYSDA,
//            DCB=(RECFM=FB,LRECL=300,BLKSIZE=0)
//RPTFILE  DD SYSOUT=*
//SYSTSPRT DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//SYSOUT   DD SYSOUT=*
//CEEDUMP  DD SYSOUT=*
//SYSUDUMP DD SYSOUT=*
//SYSTSIN  DD *
  DSN SYSTEM(DB2P)
  RUN  PROGRAM(ODACCTP) PLAN(ODACCTP) -
       LIB('ORION.LOADLIB')
  END
/*
