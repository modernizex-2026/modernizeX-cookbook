//LOADTCAT JOB (ACCT),'ORION LOAD TCATFILE',CLASS=A,MSGCLASS=X,
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID,REGION=0M
//***************************************************************
//*  SYSTEM  : ORION-CCMS  (Credit Card Management)            *
//*  JOB     : LOADTCAT - IDCAMS REPRO load TCATFILE           *
//*  Load the VSAM KSDS from a fixed-format sequential         *
//*  input dataset ORION.TCATFILE.SEQ (RECFM=FB,LRECL=60).     *
//***************************************************************
//REPRO    EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SEQIN    DD DSN=ORION.TCATFILE.SEQ,DISP=SHR
//VSAMOUT  DD DSN=ORION.TCATFILE,DISP=SHR
//SYSIN    DD *
  REPRO INFILE(SEQIN)                           -
        OUTFILE(VSAMOUT)                        -
        REPLACE
/*
