      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCSGNON  -  Sign On (on-line)                     *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: validate user id + password against USRSEC and    *
      *            transfer to the main menu (admin menu if admin).  *
      *  NOTE    : this is the entry transaction (ORSN).             *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCSGNON.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCSGNON'.
           05  WS-TRANID            PIC X(04) VALUE 'ORSN'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
           05  WS-ADMEN-PGM         PIC X(08) VALUE 'OCADMEN'.
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RUSER.
       COPY MSGNON.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               IF CA-FIRST-ENTER
                   PERFORM 1000-SEND-INITIAL
               ELSE
                   PERFORM 2000-PROCESS-INPUT
               END-IF
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MSGNONAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Please sign on.' TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MSGNONA')
                     MAPSET('MSGNON')
                     FROM(MSGNONAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-SIGN-OFF
               WHEN DFHENTER
                   PERFORM 2100-VALIDATE-USER
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
       2100-VALIDATE-USER.
           EXEC CICS RECEIVE
                     MAP('MSGNONA')
                     MAPSET('MSGNON')
                     INTO(MSGNONAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF USERIDI = SPACES OR USERIDI = LOW-VALUES
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE USERIDI TO US-ID
               PERFORM 3000-READ-USER
               IF REC-NOT-FOUND
                   MOVE 'User not found.' TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   IF US-PASSWORD = PASSWDI
                       PERFORM 4000-TRANSFER-TO-MENU
                   ELSE
                       MOVE 'Invalid password.' TO ERRMSGO
                       PERFORM 8100-SEND-DATAONLY
                   END-IF
               END-IF
           END-IF.
      *----------------------------------------------------------------*
       3000-READ-USER.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-USRSEC)
                     INTO(USER-REC)
                     RIDFLD(US-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               SET REC-FOUND TO TRUE
           END-IF.
      *----------------------------------------------------------------*
       4000-TRANSFER-TO-MENU.
           MOVE US-ID    TO CA-USER-ID.
           MOVE US-TYPE  TO CA-USER-TYPE.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE 0        TO CA-PGM-CONTEXT.
           IF CA-USER-ADMIN
               EXEC CICS XCTL PROGRAM(WS-ADMEN-PGM)
                         COMMAREA(ORION-COMMAREA)
                         RESP(WS-RESP-CD) END-EXEC
           ELSE
               EXEC CICS XCTL PROGRAM(WS-MENU-PGM)
                         COMMAREA(ORION-COMMAREA)
                         RESP(WS-RESP-CD) END-EXEC
           END-IF.
      *----------------------------------------------------------------*
       7000-SIGN-OFF.
           EXEC CICS SEND TEXT
                     FROM(WS-MSG-THANKYOU)
                     LENGTH(LENGTH OF WS-MSG-THANKYOU)
                     ERASE FREEKB
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS RETURN RESP(WS-RESP-CD) END-EXEC.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           EXEC CICS ASKTIME ABSTIME(WS-AMT) RESP(WS-RESP-CD) END-EXEC.
           EXEC CICS FORMATTIME ABSTIME(WS-AMT) DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME) TIMESEP(':')
                     RESP(WS-RESP-CD) END-EXEC.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MSGNONA')
                     MAPSET('MSGNON')
                     FROM(MSGNONAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
