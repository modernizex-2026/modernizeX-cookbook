      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUMQREQ  -  MQ authorization requester           *
      *  TYPE    : SUB  (MQ / MQI CALL)                             *
      *  FUNCTION: build an auth request, MQPUT to the request queue*
      *            MQGET the reply; also authorize the card         *
      *            locally via XREF -> ACCT (no live QMGR needed).  *
      *  CALL    : EXEC CICS LINK PROGRAM('OUMQREQ')                *
      *                COMMAREA(ORION-COMMAREA) END-EXEC.           *
      *****************************************************************
      *---------------------------------------------------------------*
      *  DESIGN                                                        *
      *  ------                                                        *
      *  OUMQREQ is the on-line authorization engine linked from the   *
      *  OCAUTHQ BMS screen.  The screen builds an AUTH-REQUEST in the *
      *  commarea work area (CA-WORK-AREA); this sub overlays the      *
      *  KAUTH message area on that same storage so the request rides  *
      *  in, and the response rides back out, through the commarea.    *
      *                                                                *
      *  For every request the program:                               *
      *    1. Stamps the request (type + timestamp).                   *
      *    2. Authorizes locally - the authoritative decision - by     *
      *       reading the card cross-reference (XREFFILE) to find the  *
      *       owning account, then the account master (ACCTFILE), and  *
      *       approving when the amount is within available credit.    *
      *    3. MQOPEN / MQPUT the request onto the request queue so a   *
      *       downstream authorizer can also see it (best effort).     *
      *    4. MQOPEN / MQGET a reply from the reply queue (best        *
      *       effort) and MQCLOSE both queues.                         *
      *                                                                *
      *  Every MQI verb is a native CALL 'MQxxxx' (NOT an EXEC), so    *
      *  the EXEC CICS / END-EXEC balance is unaffected.  MQ-CC and    *
      *  MQ-RC are checked after each call; a transport failure is     *
      *  logged and the local decision stands, so the flow works even  *
      *  when no queue manager is connected.                          *
      *---------------------------------------------------------------*
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUMQREQ.
       AUTHOR.     ORION-CCMS-ONLINE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *---------------------------------------------------------------*
      *  Program identity.                                            *
      *---------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUMQREQ'.
      *---------------------------------------------------------------*
      *  MQ object names used by this sub-program.                    *
      *---------------------------------------------------------------*
       01  WS-QUEUE-NAMES.
           05  WS-REQ-QUEUE         PIC X(48)
               VALUE 'ORION.AUTH.REQUEST.QUEUE'.
           05  WS-RPY-QUEUE         PIC X(48)
               VALUE 'ORION.AUTH.REPLY.QUEUE'.
      *---------------------------------------------------------------*
      *  Local work fields and switches.                             *
      *---------------------------------------------------------------*
       01  WS-MQ-WORK.
           05  WS-REPLY-BUF         PIC X(300) VALUE SPACES.
           05  WS-MQ-OP             PIC X(08)  VALUE SPACES.
           05  WS-MQ-DOWN-FLG       PIC X(01)  VALUE 'N'.
               88  MQ-IS-DOWN                  VALUE 'Y'.
               88  MQ-IS-UP                    VALUE 'N'.
           05  WS-IO-FLG            PIC X(01)  VALUE 'N'.
               88  IO-ERROR                    VALUE 'Y'.
               88  IO-OK                       VALUE 'N'.
      *---------------------------------------------------------------*
      *  Timestamp builder (26 bytes : YYYY-MM-DD-HH:MM:SS + pad).    *
      *---------------------------------------------------------------*
       01  WS-STAMP.
           05  WS-ST-DATE           PIC X(10).
           05  FILLER               PIC X(01) VALUE '-'.
           05  WS-ST-TIME           PIC X(08).
           05  FILLER               PIC X(07) VALUE SPACES.
       01  WS-ABS-TIME              PIC S9(15) COMP-3 VALUE ZERO.
      *---------------------------------------------------------------*
      *  Shared constants / files / edit fields.                     *
      *---------------------------------------------------------------*
       COPY WCONST.
      *---------------------------------------------------------------*
      *  MQI control blocks + named constants (ORION-original).      *
      *---------------------------------------------------------------*
       COPY KMQ.
      *---------------------------------------------------------------*
      *  VSAM record layouts read for the local credit check.        *
      *---------------------------------------------------------------*
       COPY RXREF.
       COPY RACCT.
      *---------------------------------------------------------------*
       LINKAGE SECTION.
      *---------------------------------------------------------------*
      *  The commarea (KCOMM) is the single area passed on LINK.      *
      *  KAUTH is overlaid on CA-WORK-AREA via SET ADDRESS at entry.  *
      *---------------------------------------------------------------*
       COPY KCOMM.
       COPY KAUTH.
      *---------------------------------------------------------------*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *---------------------------------------------------------------*
      *  0000-MAIN - top level driver.                               *
      *---------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF AUTH-MSG-AREA TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INITIALIZE.
           PERFORM 2000-BUILD-REQUEST.
           PERFORM 3000-LOCAL-AUTHORIZE.
           PERFORM 4000-PUT-REQUEST.
           PERFORM 5000-GET-REPLY.
           PERFORM 9000-FINALIZE.
           GOBACK.
      *---------------------------------------------------------------*
      *  1000-INITIALIZE - reset switches and MQ handles.            *
      *---------------------------------------------------------------*
       1000-INITIALIZE.
           SET MQ-IS-UP  TO TRUE.
           SET IO-OK     TO TRUE.
           MOVE MQ-HC-DEF-HCONN TO MQ-HCONN.
           MOVE ZERO TO MQ-HOBJ-OUT.
           MOVE ZERO TO MQ-HOBJ-RPY.
           MOVE SPACES TO CA-ERR-MSG.
      *---------------------------------------------------------------*
      *  2000-BUILD-REQUEST - complete the inbound request message   *
      *  and prime the response fields.                              *
      *---------------------------------------------------------------*
       2000-BUILD-REQUEST.
           MOVE 'AREQ' TO AQ-MSG-TYPE.
           PERFORM 8500-GET-STAMP.
           MOVE WS-STAMP TO AQ-REQUESTED-TS.
           MOVE SPACES TO AUTH-RESPONSE.
           MOVE 'ARSP' TO AS-MSG-TYPE.
           MOVE AQ-CARD-NUM TO AS-CARD-NUM.
           MOVE ZERO TO AS-ACCT-ID.
           MOVE ZERO TO AS-APPROVED-AMT.
           MOVE ZERO TO AS-AVAIL-CREDIT.
           MOVE SPACES TO AS-REASON.
      *---------------------------------------------------------------*
      *  3000-LOCAL-AUTHORIZE - the authoritative decision.          *
      *  Read XREF(card) -> ACCT and approve when the amount fits    *
      *  the available credit; decline / error otherwise.           *
      *---------------------------------------------------------------*
       3000-LOCAL-AUTHORIZE.
           SET IO-OK TO TRUE.
           MOVE AQ-CARD-NUM TO XR-CARD-NUM.
           PERFORM 3100-READ-XREF.
           EVALUATE TRUE
               WHEN IO-ERROR
                   SET AS-ERRORED TO TRUE
                   MOVE 'FILE READ ERROR' TO AS-REASON
               WHEN REC-NOT-FOUND
                   PERFORM 3500-DECLINE-NOCARD
               WHEN OTHER
                   MOVE XR-ACCT-ID TO AC-ID
                   MOVE XR-ACCT-ID TO AQ-ACCT-ID
                   MOVE XR-ACCT-ID TO AS-ACCT-ID
                   PERFORM 3200-READ-ACCT
                   PERFORM 3300-EVALUATE-ACCT
           END-EVALUATE.
      *---------------------------------------------------------------*
      *  3100-READ-XREF - random read of the card cross-reference.   *
      *---------------------------------------------------------------*
       3100-READ-XREF.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-XREFFILE)
                     INTO(XREF-REC)
                     RIDFLD(XR-CARD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   SET IO-ERROR TO TRUE
                   DISPLAY 'OUMQREQ: XREF READ RESP=' WS-RESP-CD
           END-EVALUATE.
      *---------------------------------------------------------------*
      *  3200-READ-ACCT - random read of the owning account.        *
      *---------------------------------------------------------------*
       3200-READ-ACCT.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   SET IO-ERROR TO TRUE
                   DISPLAY 'OUMQREQ: ACCT READ RESP=' WS-RESP-CD
           END-EVALUATE.
      *---------------------------------------------------------------*
      *  3300-EVALUATE-ACCT - branch on the account read result.    *
      *---------------------------------------------------------------*
       3300-EVALUATE-ACCT.
           EVALUATE TRUE
               WHEN IO-ERROR
                   SET AS-ERRORED TO TRUE
                   MOVE 'FILE READ ERROR' TO AS-REASON
               WHEN REC-NOT-FOUND
                   PERFORM 3400-DECLINE-NOACCT
               WHEN OTHER
                   PERFORM 3600-DECIDE
           END-EVALUATE.
      *---------------------------------------------------------------*
      *  3400-DECLINE-NOACCT - card resolves but account is gone.    *
      *---------------------------------------------------------------*
       3400-DECLINE-NOACCT.
           SET AS-DECLINED TO TRUE.
           MOVE 'ACCOUNT NOT FOUND' TO AS-REASON.
           MOVE ZERO TO AS-APPROVED-AMT.
      *---------------------------------------------------------------*
      *  3500-DECLINE-NOCARD - card is not in the cross-reference.   *
      *---------------------------------------------------------------*
       3500-DECLINE-NOCARD.
           SET AS-DECLINED TO TRUE.
           MOVE 'CARD NOT FOUND' TO AS-REASON.
           MOVE ZERO TO AS-APPROVED-AMT.
      *---------------------------------------------------------------*
      *  3600-DECIDE - approve or decline against available credit.  *
      *---------------------------------------------------------------*
       3600-DECIDE.
           COMPUTE WS-AMT = AC-CREDIT-LIMIT - AC-CURR-BAL.
           MOVE WS-AMT TO AS-AVAIL-CREDIT.
           EVALUATE TRUE
               WHEN AC-ACTIVE-STATUS NOT = 'Y'
                   SET AS-DECLINED TO TRUE
                   MOVE 'ACCOUNT INACTIVE' TO AS-REASON
                   MOVE ZERO TO AS-APPROVED-AMT
               WHEN AQ-AMOUNT > WS-AMT
                   SET AS-DECLINED TO TRUE
                   MOVE 'INSUFFICIENT CREDIT' TO AS-REASON
                   MOVE ZERO TO AS-APPROVED-AMT
               WHEN OTHER
                   SET AS-APPROVED TO TRUE
                   MOVE 'APPROVED OK' TO AS-REASON
                   MOVE AQ-AMOUNT TO AS-APPROVED-AMT
           END-EVALUATE.
      *---------------------------------------------------------------*
      *  4000-PUT-REQUEST - MQOPEN the request queue and MQPUT the   *
      *  completed request (best effort - logged if MQ is down).    *
      *---------------------------------------------------------------*
       4000-PUT-REQUEST.
           MOVE WS-REQ-QUEUE TO MQ-OD-OBJECT-NAME.
           COMPUTE MQ-OPEN-OPTIONS =
               MQ-OO-OUTPUT + MQ-OO-FAIL-IF-QSG.
           MOVE 'MQOPEN  ' TO WS-MQ-OP.
           CALL 'MQOPEN' USING MQ-HCONN MQ-OD MQ-OPEN-OPTIONS
               MQ-HOBJ-OUT MQ-CC MQ-RC
           END-CALL.
           PERFORM 8000-CHECK-MQ.
           IF MQ-IS-UP
               PERFORM 4100-PUT-MSG
           END-IF.
      *---------------------------------------------------------------*
      *  4100-PUT-MSG - set the descriptor + options and MQPUT.      *
      *---------------------------------------------------------------*
       4100-PUT-MSG.
           MOVE MQ-MT-REQUEST TO MQ-MD-MSG-TYPE.
           MOVE 'MQSTR   ' TO MQ-MD-FORMAT.
           MOVE WS-RPY-QUEUE TO MQ-MD-REPLY-Q.
           MOVE MQ-PM-NO-SYNCPOINT TO MQ-PMO-OPTIONS.
           MOVE LENGTH OF AUTH-REQUEST TO MQ-BUFFER-LEN.
           MOVE 'MQPUT   ' TO WS-MQ-OP.
           CALL 'MQPUT' USING MQ-HCONN MQ-HOBJ-OUT MQ-MD
               MQ-PMO MQ-BUFFER-LEN AUTH-REQUEST MQ-CC MQ-RC
           END-CALL.
           PERFORM 8000-CHECK-MQ.
           MOVE MQ-CL-NONE TO MQ-CLOSE-OPTIONS.
           MOVE 'MQCLOSE ' TO WS-MQ-OP.
           CALL 'MQCLOSE' USING MQ-HCONN MQ-HOBJ-OUT
               MQ-CLOSE-OPTIONS MQ-CC MQ-RC
           END-CALL.
           PERFORM 8000-CHECK-MQ.
      *---------------------------------------------------------------*
      *  5000-GET-REPLY - MQOPEN the reply queue and MQGET a reply.  *
      *  A real downstream reply would be parsed here; when none is  *
      *  queued (RC 2033) the local decision already stands.        *
      *---------------------------------------------------------------*
       5000-GET-REPLY.
           MOVE WS-RPY-QUEUE TO MQ-OD-OBJECT-NAME.
           COMPUTE MQ-OPEN-OPTIONS =
               MQ-OO-INPUT-SHARED + MQ-OO-FAIL-IF-QSG.
           MOVE 'MQOPEN  ' TO WS-MQ-OP.
           CALL 'MQOPEN' USING MQ-HCONN MQ-OD MQ-OPEN-OPTIONS
               MQ-HOBJ-RPY MQ-CC MQ-RC
           END-CALL.
           PERFORM 8000-CHECK-MQ.
           IF MQ-IS-UP
               PERFORM 5100-GET-MSG
           END-IF.
      *---------------------------------------------------------------*
      *  5100-GET-MSG - issue the MQGET and interpret the result.    *
      *---------------------------------------------------------------*
       5100-GET-MSG.
           COMPUTE MQ-GMO-OPTIONS =
               MQ-GM-WAIT + MQ-GM-NO-SYNCPOINT.
           MOVE LENGTH OF WS-REPLY-BUF TO MQ-BUFFER-LEN.
           MOVE LOW-VALUES TO MQ-MD-MSG-ID.
           MOVE LOW-VALUES TO MQ-MD-CORREL-ID.
           MOVE 'MQGET   ' TO WS-MQ-OP.
           CALL 'MQGET' USING MQ-HCONN MQ-HOBJ-RPY MQ-MD MQ-GMO
               MQ-BUFFER-LEN WS-REPLY-BUF MQ-DATA-LEN MQ-CC MQ-RC
           END-CALL.
           IF MQ-CC-OK
               DISPLAY 'OUMQREQ: reply received len=' MQ-DATA-LEN
           ELSE
               IF MQ-RC-NO-MSG
                   DISPLAY 'OUMQREQ: no reply queued - local decision'
               ELSE
                   PERFORM 8000-CHECK-MQ
               END-IF
           END-IF.
           MOVE MQ-CL-NONE TO MQ-CLOSE-OPTIONS.
           MOVE 'MQCLOSE ' TO WS-MQ-OP.
           CALL 'MQCLOSE' USING MQ-HCONN MQ-HOBJ-RPY
               MQ-CLOSE-OPTIONS MQ-CC MQ-RC
           END-CALL.
           PERFORM 8000-CHECK-MQ.
      *---------------------------------------------------------------*
      *  8000-CHECK-MQ - inspect completion / reason after a call.  *
      *  On failure log the verb + codes and mark the adapter down; *
      *  the local decision remains authoritative.                  *
      *---------------------------------------------------------------*
       8000-CHECK-MQ.
           IF MQ-CC-OK
               CONTINUE
           ELSE
               SET MQ-IS-DOWN TO TRUE
               DISPLAY 'OUMQREQ: ' WS-MQ-OP ' FAILED CC=' MQ-CC
                       ' RC=' MQ-RC
           END-IF.
      *---------------------------------------------------------------*
      *  8500-GET-STAMP - build a 26-byte timestamp via CICS time.  *
      *---------------------------------------------------------------*
       8500-GET-STAMP.
           EXEC CICS ASKTIME
                     ABSTIME(WS-ABS-TIME)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-ABS-TIME)
                     DATESEP('-')
                     YYYYMMDD(WS-ST-DATE)
                     TIME(WS-ST-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *---------------------------------------------------------------*
      *  9000-FINALIZE - stamp the response, set the commarea error  *
      *  flag and a short decision message for the screen.          *
      *---------------------------------------------------------------*
       9000-FINALIZE.
           PERFORM 8500-GET-STAMP.
           MOVE WS-STAMP TO AS-RESPONSE-TS.
           IF AS-ERRORED
               SET CA-ERR-ON TO TRUE
           ELSE
               SET CA-ERR-OFF TO TRUE
           END-IF.
           STRING 'AUTH ' DELIMITED SIZE
                  AS-DECISION DELIMITED SIZE
                  ' - ' DELIMITED SIZE
                  AS-REASON DELIMITED SIZE
                  INTO CA-ERR-MSG
           END-STRING.
           DISPLAY 'OUMQREQ: card ' AS-CARD-NUM
                   ' decision ' AS-DECISION.
