      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCACTIN  -  Account Inquiry (consolidated)        *
      *  TYPE    : ONLINE CICS  (inquiry)                            *
      *  FUNCTION: paged inquiry over the account master.  The       *
      *            operator types a filter (ALL / DELINQUENT /       *
      *            OVER-LIMIT / DORMANT / CLOSED / NEW / HIGH-UTIL)  *
      *            and presses ENTER; the screen LINKs to the browse *
      *            sub OUACTIN which walks ACCTFILE and returns one   *
      *            page of matching accounts with balance, limit,    *
      *            available credit and utilisation.  PF8 pages       *
      *            forward, PF7 restarts, PF3 returns to the menu.    *
      *  MAPSET  : MACTIN      MAP : MACTINA     TRANID : ORAI       *
      *  LINKS   : OUACTIN  (COMMAREA = KACTIN)                      *
      *  NOTE    : follows the OCACCTL golden list skeleton but the   *
      *            file walk lives in the sub, not here.              *
      *****************************************************************
      *  This screen REPLACES twelve batch account reports:          *
      *    OBRDELQ OBRLIMIT OBRDORM OBRCLOSE OBRNEW OBRUTIL          *
      *    OBRAVAIL OBRAGE OBRINACT OBRACCT OBRPORT OBRKPI           *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - consolidated account inquiry.  *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCACTIN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCACTIN'.
           05  WS-TRANID            PIC X(04) VALUE 'ORAI'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
           05  WS-SUB-PGM           PIC X(08) VALUE 'OUACTIN'.
      *----------------------------------------------------------------*
      *  Validation switch.                                            *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Pseudo-conversational state kept in CA-WORK-AREA(1:60).       *
      *  The population portfolio figures are captured on the first    *
      *  page and carried forward so PF8 need not rescan the file.     *
      *----------------------------------------------------------------*
       01  WS-STATE.
           05  WS-ST-FILTER         PIC X(01).
           05  WS-ST-NEXT-KEY       PIC 9(11).
           05  WS-ST-PAGE-NO        PIC 9(03).
           05  WS-ST-MORE           PIC X(01).
           05  WS-ST-LISTED         PIC X(01).
           05  WS-ST-POP-CNT        PIC 9(09).
           05  WS-ST-POP-BAL        PIC S9(15)V99.
           05  WS-ST-POP-AVL        PIC S9(15)V99.
      *----------------------------------------------------------------*
      *  Filter parse work area and echoed description.                *
      *----------------------------------------------------------------*
       01  WS-FILTER-WORK.
           05  WS-FILT-IN           PIC X(10) VALUE SPACES.
           05  WS-FDESC             PIC X(12) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Row edit holders and screen edit fields.                      *
      *----------------------------------------------------------------*
       01  WS-ROW-HOLD.
           05  WS-O-ID              PIC X(11) VALUE SPACES.
           05  WS-O-ST              PIC X(01) VALUE SPACES.
           05  WS-O-BAL             PIC X(15) VALUE SPACES.
           05  WS-O-LIM             PIC X(15) VALUE SPACES.
           05  WS-O-AVL             PIC X(15) VALUE SPACES.
           05  WS-O-UTL             PIC X(06) VALUE SPACES.
       01  WS-EDIT-FIELDS.
           05  WS-I                 PIC 9(02) VALUE ZEROS.
           05  WS-CNT-ED            PIC Z9.
           05  WS-ED-PG             PIC ZZ9.
           05  WS-ED-RUN            PIC Z(6)9.
           05  WS-ED-UTIL           PIC ZZ9.99.
           05  WS-ED-TOT            PIC -,---,---,---,--9.99.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Type a filter and press ENTER.'.
           05  WS-M-BAD-FILTER      PIC X(50)
               VALUE 'Filter not recognised - see the list above.'.
           05  WS-M-NONE-FOUND      PIC X(50)
               VALUE 'No accounts match that filter.'.
           05  WS-M-END-FILE        PIC X(50)
               VALUE 'End of selection - no more accounts.'.
           05  WS-M-LIST-FIRST      PIC X(50)
               VALUE 'Apply a filter first (press ENTER).'.
           05  WS-M-LINK-ERR        PIC X(50)
               VALUE 'Unable to reach the account browse engine.'.
           05  WS-M-BROWSE-ERR      PIC X(50)
               VALUE 'Error browsing the account file.'.
           05  WS-M-MORE            PIC X(30)
               VALUE ' shown - PF8=more PF7=top'.
           05  WS-M-DONE            PIC X(30)
               VALUE ' shown - end of selection'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  Browse-interface area built here and passed on LINK.          *
      *----------------------------------------------------------------*
       COPY KACTIN.
      *----------------------------------------------------------------*
      *  BMS symbolic map.                                             *
      *----------------------------------------------------------------*
       COPY MACTIN.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh screen.      *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MACTINAO.
           INITIALIZE KACTIN-AREA.
           PERFORM 8000-POPULATE-HEADER.
           PERFORM 4100-CLEAR-ROWS.
           MOVE 'A' TO WS-ST-FILTER.
           MOVE ZEROS TO WS-ST-NEXT-KEY.
           MOVE ZEROS TO WS-ST-PAGE-NO.
           MOVE ZEROS TO WS-ST-POP-CNT.
           MOVE ZEROS TO WS-ST-POP-BAL.
           MOVE ZEROS TO WS-ST-POP-AVL.
           MOVE 'N' TO WS-ST-MORE.
           MOVE 'N' TO WS-ST-LISTED.
           MOVE WS-STATE TO CA-WORK-AREA(1:60).
           MOVE 'ALL' TO FDESCO.
           PERFORM 4400-SHOW-TOTALS.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO FILTL.
           EXEC CICS SEND
                     MAP('MACTINA')
                     MAPSET('MACTIN')
                     FROM(MACTINAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           MOVE CA-WORK-AREA(1:60) TO WS-STATE.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF12
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHCLEAR
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-APPLY-FILTER
               WHEN DFHPF7
                   PERFORM 2200-RESTART
               WHEN DFHPF8
                   PERFORM 2300-PAGE-FWD
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 6100-SET-FDESC
                   MOVE WS-FDESC TO FDESCO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2050-RECEIVE  -  read the map; treat MAPFAIL as empty input.  *
      *----------------------------------------------------------------*
       2050-RECEIVE.
           EXEC CICS RECEIVE
                     MAP('MACTINA')
                     MAPSET('MACTIN')
                     INTO(MACTINAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MACTINAI
           END-IF.
      *----------------------------------------------------------------*
      *  2100-APPLY-FILTER  -  ENTER: parse the filter and list from   *
      *  the top of the file.                                          *
      *----------------------------------------------------------------*
       2100-APPLY-FILTER.
           PERFORM 2050-RECEIVE.
           PERFORM 6000-PARSE-FILTER.
           IF WS-INVALID
               MOVE WS-M-BAD-FILTER TO ERRMSGO
               MOVE -1 TO FILTL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE WS-ST-FILTER TO KAI-FILTER
               MOVE ZEROS        TO KAI-START-KEY
               SET KAI-DO-KPI    TO TRUE
               MOVE 1            TO WS-ST-PAGE-NO
               MOVE 'Y'          TO WS-ST-LISTED
               PERFORM 2400-RUN-PAGE
           END-IF.
      *----------------------------------------------------------------*
      *  2200-RESTART  -  PF7: re-list the current filter from the top.*
      *----------------------------------------------------------------*
       2200-RESTART.
           IF WS-ST-LISTED NOT = 'Y'
               MOVE WS-M-LIST-FIRST TO ERRMSGO
               MOVE -1 TO FILTL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE WS-ST-FILTER TO KAI-FILTER
               MOVE ZEROS        TO KAI-START-KEY
               SET KAI-DO-KPI    TO TRUE
               MOVE 1            TO WS-ST-PAGE-NO
               PERFORM 2400-RUN-PAGE
           END-IF.
      *----------------------------------------------------------------*
      *  2300-PAGE-FWD  -  PF8: continue after the saved resume key.   *
      *----------------------------------------------------------------*
       2300-PAGE-FWD.
           IF WS-ST-LISTED NOT = 'Y'
               MOVE WS-M-LIST-FIRST TO ERRMSGO
               MOVE -1 TO FILTL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               IF WS-ST-MORE NOT = 'Y'
                   PERFORM 6100-SET-FDESC
                   MOVE WS-FDESC TO FDESCO
                   MOVE WS-M-END-FILE TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE WS-ST-FILTER   TO KAI-FILTER
                   MOVE WS-ST-NEXT-KEY TO KAI-START-KEY
                   SET KAI-SKIP-KPI    TO TRUE
                   ADD 1 TO WS-ST-PAGE-NO
                   PERFORM 2400-RUN-PAGE
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2400-RUN-PAGE  -  call the browse sub, capture the portfolio  *
      *  figures on the first page, save the resume state and paint.   *
      *----------------------------------------------------------------*
       2400-RUN-PAGE.
           PERFORM 3000-CALL-SUB.
           IF WS-INVALID
               MOVE -1 TO FILTL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               IF KAI-DO-KPI
                   MOVE KAI-POP-COUNT   TO WS-ST-POP-CNT
                   MOVE KAI-POP-BAL-TOT TO WS-ST-POP-BAL
                   MOVE KAI-POP-AVL-TOT TO WS-ST-POP-AVL
               END-IF
               MOVE KAI-NEXT-KEY   TO WS-ST-NEXT-KEY
               MOVE KAI-MORE-SW    TO WS-ST-MORE
               PERFORM 4000-SHOW-PAGE
               MOVE -1 TO FILTL
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  3000-CALL-SUB  -  LINK to the OUACTIN browse engine.          *
      *----------------------------------------------------------------*
       3000-CALL-SUB.
           SET WS-VALID TO TRUE.
           EXEC CICS LINK
                     PROGRAM(WS-SUB-PGM)
                     COMMAREA(KACTIN-AREA)
                     LENGTH(LENGTH OF KACTIN-AREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               SET WS-INVALID TO TRUE
               PERFORM 6100-SET-FDESC
               MOVE WS-FDESC TO FDESCO
               MOVE WS-M-LINK-ERR TO ERRMSGO
           ELSE
               IF KAI-ERROR
                   SET WS-INVALID TO TRUE
                   PERFORM 6100-SET-FDESC
                   MOVE WS-FDESC TO FDESCO
                   MOVE WS-M-BROWSE-ERR TO ERRMSGO
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  4000-SHOW-PAGE  -  paint the returned rows and the totals.    *
      *----------------------------------------------------------------*
       4000-SHOW-PAGE.
           PERFORM 6100-SET-FDESC.
           MOVE WS-FDESC TO FDESCO.
           PERFORM 4100-CLEAR-ROWS.
           IF KAI-ROW-COUNT = 0
               MOVE WS-M-NONE-FOUND TO ERRMSGO
           ELSE
               PERFORM VARYING WS-I FROM 1 BY 1
                       UNTIL WS-I > KAI-ROW-COUNT
                   PERFORM 4200-EDIT-ROW
                   PERFORM 4300-PLACE-ROW
               END-PERFORM
               PERFORM 4900-BUILD-MSG
           END-IF.
           PERFORM 4400-SHOW-TOTALS.
      *----------------------------------------------------------------*
      *  4100-CLEAR-ROWS  -  blank all thirteen display lines.         *
      *----------------------------------------------------------------*
       4100-CLEAR-ROWS.
           MOVE SPACES TO AID1O  AST1O  ABL1O  ALM1O  AAV1O  AUT1O.
           MOVE SPACES TO AID2O  AST2O  ABL2O  ALM2O  AAV2O  AUT2O.
           MOVE SPACES TO AID3O  AST3O  ABL3O  ALM3O  AAV3O  AUT3O.
           MOVE SPACES TO AID4O  AST4O  ABL4O  ALM4O  AAV4O  AUT4O.
           MOVE SPACES TO AID5O  AST5O  ABL5O  ALM5O  AAV5O  AUT5O.
           MOVE SPACES TO AID6O  AST6O  ABL6O  ALM6O  AAV6O  AUT6O.
           MOVE SPACES TO AID7O  AST7O  ABL7O  ALM7O  AAV7O  AUT7O.
           MOVE SPACES TO AID8O  AST8O  ABL8O  ALM8O  AAV8O  AUT8O.
           MOVE SPACES TO AID9O  AST9O  ABL9O  ALM9O  AAV9O  AUT9O.
           MOVE SPACES TO AID10O AST10O ABL10O ALM10O AAV10O AUT10O.
           MOVE SPACES TO AID11O AST11O ABL11O ALM11O AAV11O AUT11O.
           MOVE SPACES TO AID12O AST12O ABL12O ALM12O AAV12O AUT12O.
           MOVE SPACES TO AID13O AST13O ABL13O ALM13O AAV13O AUT13O.
      *----------------------------------------------------------------*
      *  4200-EDIT-ROW  -  format one KACTIN row into the hold fields. *
      *  Money uses WS-ED-BAL(2:15) exactly like the OCACCTL golden.   *
      *----------------------------------------------------------------*
       4200-EDIT-ROW.
           MOVE KAI-R-ID(WS-I)     TO WS-O-ID.
           MOVE KAI-R-STATUS(WS-I) TO WS-O-ST.
           MOVE KAI-R-BAL(WS-I)    TO WS-ED-BAL.
           MOVE WS-ED-BAL(2:15)    TO WS-O-BAL.
           MOVE KAI-R-LIMIT(WS-I)  TO WS-ED-BAL.
           MOVE WS-ED-BAL(2:15)    TO WS-O-LIM.
           MOVE KAI-R-AVAIL(WS-I)  TO WS-ED-BAL.
           MOVE WS-ED-BAL(2:15)    TO WS-O-AVL.
           MOVE KAI-R-UTIL(WS-I)   TO WS-ED-UTIL.
           MOVE WS-ED-UTIL         TO WS-O-UTL.
      *----------------------------------------------------------------*
      *  4300-PLACE-ROW  -  drop the hold fields onto the map line     *
      *  indicated by the row index.                                   *
      *----------------------------------------------------------------*
       4300-PLACE-ROW.
           EVALUATE WS-I
               WHEN 1
                   MOVE WS-O-ID TO AID1O   MOVE WS-O-ST TO AST1O
                   MOVE WS-O-BAL TO ABL1O  MOVE WS-O-LIM TO ALM1O
                   MOVE WS-O-AVL TO AAV1O  MOVE WS-O-UTL TO AUT1O
               WHEN 2
                   MOVE WS-O-ID TO AID2O   MOVE WS-O-ST TO AST2O
                   MOVE WS-O-BAL TO ABL2O  MOVE WS-O-LIM TO ALM2O
                   MOVE WS-O-AVL TO AAV2O  MOVE WS-O-UTL TO AUT2O
               WHEN 3
                   MOVE WS-O-ID TO AID3O   MOVE WS-O-ST TO AST3O
                   MOVE WS-O-BAL TO ABL3O  MOVE WS-O-LIM TO ALM3O
                   MOVE WS-O-AVL TO AAV3O  MOVE WS-O-UTL TO AUT3O
               WHEN 4
                   MOVE WS-O-ID TO AID4O   MOVE WS-O-ST TO AST4O
                   MOVE WS-O-BAL TO ABL4O  MOVE WS-O-LIM TO ALM4O
                   MOVE WS-O-AVL TO AAV4O  MOVE WS-O-UTL TO AUT4O
               WHEN 5
                   MOVE WS-O-ID TO AID5O   MOVE WS-O-ST TO AST5O
                   MOVE WS-O-BAL TO ABL5O  MOVE WS-O-LIM TO ALM5O
                   MOVE WS-O-AVL TO AAV5O  MOVE WS-O-UTL TO AUT5O
               WHEN 6
                   MOVE WS-O-ID TO AID6O   MOVE WS-O-ST TO AST6O
                   MOVE WS-O-BAL TO ABL6O  MOVE WS-O-LIM TO ALM6O
                   MOVE WS-O-AVL TO AAV6O  MOVE WS-O-UTL TO AUT6O
               WHEN 7
                   MOVE WS-O-ID TO AID7O   MOVE WS-O-ST TO AST7O
                   MOVE WS-O-BAL TO ABL7O  MOVE WS-O-LIM TO ALM7O
                   MOVE WS-O-AVL TO AAV7O  MOVE WS-O-UTL TO AUT7O
               WHEN 8
                   MOVE WS-O-ID TO AID8O   MOVE WS-O-ST TO AST8O
                   MOVE WS-O-BAL TO ABL8O  MOVE WS-O-LIM TO ALM8O
                   MOVE WS-O-AVL TO AAV8O  MOVE WS-O-UTL TO AUT8O
               WHEN 9
                   MOVE WS-O-ID TO AID9O   MOVE WS-O-ST TO AST9O
                   MOVE WS-O-BAL TO ABL9O  MOVE WS-O-LIM TO ALM9O
                   MOVE WS-O-AVL TO AAV9O  MOVE WS-O-UTL TO AUT9O
               WHEN 10
                   MOVE WS-O-ID TO AID10O  MOVE WS-O-ST TO AST10O
                   MOVE WS-O-BAL TO ABL10O MOVE WS-O-LIM TO ALM10O
                   MOVE WS-O-AVL TO AAV10O MOVE WS-O-UTL TO AUT10O
               WHEN 11
                   MOVE WS-O-ID TO AID11O  MOVE WS-O-ST TO AST11O
                   MOVE WS-O-BAL TO ABL11O MOVE WS-O-LIM TO ALM11O
                   MOVE WS-O-AVL TO AAV11O MOVE WS-O-UTL TO AUT11O
               WHEN 12
                   MOVE WS-O-ID TO AID12O  MOVE WS-O-ST TO AST12O
                   MOVE WS-O-BAL TO ABL12O MOVE WS-O-LIM TO ALM12O
                   MOVE WS-O-AVL TO AAV12O MOVE WS-O-UTL TO AUT12O
               WHEN 13
                   MOVE WS-O-ID TO AID13O  MOVE WS-O-ST TO AST13O
                   MOVE WS-O-BAL TO ABL13O MOVE WS-O-LIM TO ALM13O
                   MOVE WS-O-AVL TO AAV13O MOVE WS-O-UTL TO AUT13O
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4400-SHOW-TOTALS  -  page number, running matched count and   *
      *  the page portfolio balance / available totals.               *
      *----------------------------------------------------------------*
       4400-SHOW-TOTALS.
           MOVE WS-ST-PAGE-NO   TO WS-ED-PG.
           MOVE WS-ED-PG        TO PAGENOO.
           MOVE WS-ST-POP-CNT   TO WS-ED-RUN.
           MOVE WS-ED-RUN       TO RUNTOTO.
           MOVE WS-ST-POP-BAL   TO WS-ED-TOT.
           MOVE WS-ED-TOT       TO PGBALO.
           MOVE WS-ST-POP-AVL   TO WS-ED-TOT.
           MOVE WS-ED-TOT       TO PGAVLO.
      *----------------------------------------------------------------*
      *  4900-BUILD-MSG  -  compose the result-count status line.      *
      *----------------------------------------------------------------*
       4900-BUILD-MSG.
           MOVE KAI-ROW-COUNT TO WS-CNT-ED.
           MOVE SPACES TO ERRMSGO.
           IF WS-ST-MORE = 'Y'
               STRING WS-CNT-ED DELIMITED BY SIZE
                      WS-M-MORE DELIMITED BY SIZE
                      INTO ERRMSGO
               END-STRING
           ELSE
               STRING WS-CNT-ED DELIMITED BY SIZE
                      WS-M-DONE DELIMITED BY SIZE
                      INTO ERRMSGO
               END-STRING
           END-IF.
      *----------------------------------------------------------------*
      *  6000-PARSE-FILTER  -  map the typed keyword to a filter code. *
      *  Leading three characters are enough; input is up-cased first. *
      *----------------------------------------------------------------*
       6000-PARSE-FILTER.
           SET WS-VALID TO TRUE.
           MOVE FILTI TO WS-FILT-IN.
           INSPECT WS-FILT-IN REPLACING ALL LOW-VALUE BY SPACE.
           INSPECT WS-FILT-IN
               CONVERTING
               'abcdefghijklmnopqrstuvwxyz'
               TO 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.
           EVALUATE TRUE
               WHEN WS-FILT-IN = SPACES
                   MOVE 'A' TO WS-ST-FILTER
               WHEN WS-FILT-IN(1:3) = 'ALL'
                   MOVE 'A' TO WS-ST-FILTER
               WHEN WS-FILT-IN(1:3) = 'DEL'
                   MOVE 'D' TO WS-ST-FILTER
               WHEN WS-FILT-IN(1:3) = 'OVE'
                   MOVE 'O' TO WS-ST-FILTER
               WHEN WS-FILT-IN(1:3) = 'DOR'
                   MOVE 'M' TO WS-ST-FILTER
               WHEN WS-FILT-IN(1:3) = 'CLO'
                   MOVE 'C' TO WS-ST-FILTER
               WHEN WS-FILT-IN(1:3) = 'NEW'
                   MOVE 'N' TO WS-ST-FILTER
               WHEN WS-FILT-IN(1:3) = 'HIG'
                   MOVE 'H' TO WS-ST-FILTER
               WHEN OTHER
                   SET WS-INVALID TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6100-SET-FDESC  -  filter code back to its display name.      *
      *----------------------------------------------------------------*
       6100-SET-FDESC.
           EVALUATE WS-ST-FILTER
               WHEN 'A' MOVE 'ALL'        TO WS-FDESC
               WHEN 'D' MOVE 'DELINQUENT' TO WS-FDESC
               WHEN 'O' MOVE 'OVER-LIMIT' TO WS-FDESC
               WHEN 'M' MOVE 'DORMANT'    TO WS-FDESC
               WHEN 'C' MOVE 'CLOSED'     TO WS-FDESC
               WHEN 'N' MOVE 'NEW'        TO WS-FDESC
               WHEN 'H' MOVE 'HIGH-UTIL'  TO WS-FDESC
               WHEN OTHER MOVE 'ALL'      TO WS-FDESC
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu.        *
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  persist state and re-transmit the map. *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           MOVE WS-STATE TO CA-WORK-AREA(1:60).
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MACTINA')
                     MAPSET('MACTIN')
                     FROM(MACTINAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to CICS.         *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
