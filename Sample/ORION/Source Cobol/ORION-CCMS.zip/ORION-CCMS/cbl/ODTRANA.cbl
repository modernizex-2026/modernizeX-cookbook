      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : ODTRANA  -  Transaction Add (on-line, DB2)        *
      *  TYPE    : CICS ONLINE + DB2  (pseudo-conversational)        *
      *  FUNCTION: accept transaction detail, validate the card and  *
      *            transaction type with EXEC SQL SELECTs, obtain a  *
      *            new id from the CTRL counter, then INSERT a new   *
      *            row into the TRAN table (ORION.TRAN).             *
      *            ENTER = add, PF3 = back to menu, PF4 = clear.     *
      *  NOTE    : DB2 variant of the OCTRANA online program.        *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. ODTRANA.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'ODTRANA'.
           05  WS-TRANID            PIC X(04) VALUE 'OD06'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
       01  WS-VALID-FLAG            PIC X(01) VALUE 'Y'.
           88  INPUT-VALID                    VALUE 'Y'.
           88  INPUT-INVALID                  VALUE 'N'.
       01  WS-VALIDATION.
           05  WS-CHK-CARD-STAT     PIC X(01)  VALUE SPACES.
           05  WS-CHK-TYPE-DESC     PIC X(50)  VALUE SPACES.
           05  WS-CT-KEY            PIC X(08)  VALUE 'TRANID'.
           05  WS-CT-VALUE          PIC 9(11)  VALUE ZEROS.
           05  WS-TRAN-ID-N         PIC 9(16)  VALUE ZEROS.
           05  WS-TS-STAMP          PIC X(26)  VALUE SPACES.
      *----------------------------------------------------------------*
      *  DB2 communication area.                                       *
      *----------------------------------------------------------------*
           EXEC SQL INCLUDE SQLCA END-EXEC.
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RTRAN.
       COPY MTRANA.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MTRANAAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter transaction detail and press ENTER.'
               TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MTRANAA')
                     MAPSET('MTRANA')
                     FROM(MTRANAAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-ADD-TRAN
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
       2100-ADD-TRAN.
           EXEC CICS RECEIVE
                     MAP('MTRANAA')
                     MAPSET('MTRANA')
                     INTO(MTRANAAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           PERFORM 2200-EDIT-INPUT.
           IF INPUT-VALID
               PERFORM 3000-CHECK-CARD
               IF REC-FOUND
                   PERFORM 3100-CHECK-TYPE
                   IF REC-FOUND
                       PERFORM 3200-GET-NEXT-ID
                       PERFORM 3300-BUILD-RECORD
                       PERFORM 3400-INSERT-TRAN
                       IF REC-FOUND
                           MOVE SPACES TO ERRMSGO
                           STRING 'Transaction added. Id='
                                     DELIMITED BY SIZE
                                  TR-ID DELIMITED BY SIZE
                               INTO ERRMSGO
                           END-STRING
                       END-IF
                   ELSE
                       MOVE 'Transaction type not found.' TO ERRMSGO
                   END-IF
               ELSE
                   MOVE 'Card number not found.' TO ERRMSGO
               END-IF
           END-IF.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
       2200-EDIT-INPUT.
           SET INPUT-VALID TO TRUE.
           IF CARDNUMI = SPACES OR CARDNUMI = LOW-VALUES
               MOVE 'Card number is required.' TO ERRMSGO
               SET INPUT-INVALID TO TRUE
           END-IF.
           IF INPUT-VALID
               IF TRTYPEI = SPACES OR TRTYPEI = LOW-VALUES
                   MOVE 'Transaction type is required.' TO ERRMSGO
                   SET INPUT-INVALID TO TRUE
               END-IF
           END-IF.
           IF INPUT-VALID
               IF TRCATI = SPACES OR TRCATI NOT NUMERIC
                   MOVE 'Category must be numeric.' TO ERRMSGO
                   SET INPUT-INVALID TO TRUE
               END-IF
           END-IF.
           IF INPUT-VALID
               IF TRAMTI = SPACES OR TRAMTI = LOW-VALUES
                   MOVE 'Amount is required.' TO ERRMSGO
                   SET INPUT-INVALID TO TRUE
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  DB2 validation : does the card exist in the CARD table?       *
      *----------------------------------------------------------------*
       3000-CHECK-CARD.
           SET REC-NOT-FOUND TO TRUE.
           MOVE CARDNUMI TO TR-CARD-NUM.
           EXEC SQL
                SELECT CD_ACTIVE_STATUS
                  INTO :WS-CHK-CARD-STAT
                  FROM ORION.CARD
                 WHERE CD_NUM = :TR-CARD-NUM
           END-EXEC.
           EVALUATE SQLCODE
               WHEN 0
                   SET REC-FOUND TO TRUE
               WHEN 100
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   MOVE 'Error reading card table.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  DB2 validation : does the type exist in the TTYP table?       *
      *----------------------------------------------------------------*
       3100-CHECK-TYPE.
           SET REC-NOT-FOUND TO TRUE.
           MOVE TRTYPEI TO TR-TYPE-CD.
           EXEC SQL
                SELECT TT_DESC
                  INTO :WS-CHK-TYPE-DESC
                  FROM ORION.TTYP
                 WHERE TT_CD = :TR-TYPE-CD
           END-EXEC.
           EVALUATE SQLCODE
               WHEN 0
                   SET REC-FOUND TO TRUE
               WHEN 100
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   MOVE 'Error reading type table.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  DB2 counter : read and bump the CTRL 'TRANID' value.          *
      *----------------------------------------------------------------*
       3200-GET-NEXT-ID.
           EXEC SQL
                SELECT CT_LAST_VALUE
                  INTO :WS-CT-VALUE
                  FROM ORION.CTRL
                 WHERE CT_KEY = :WS-CT-KEY
           END-EXEC.
           IF SQLCODE = 0
               ADD 1 TO WS-CT-VALUE
               EXEC SQL
                    UPDATE ORION.CTRL
                       SET CT_LAST_VALUE = :WS-CT-VALUE
                     WHERE CT_KEY = :WS-CT-KEY
               END-EXEC
           ELSE
               MOVE 1 TO WS-CT-VALUE
           END-IF.
           MOVE WS-CT-VALUE TO WS-TRAN-ID-N.
           MOVE WS-TRAN-ID-N TO TR-ID.
      *----------------------------------------------------------------*
       3300-BUILD-RECORD.
           PERFORM 8500-GET-DATE-TIME.
           MOVE SPACES TO WS-TS-STAMP.
           STRING WS-HDR-DATE DELIMITED BY SIZE
                  ' '         DELIMITED BY SIZE
                  WS-HDR-TIME DELIMITED BY SIZE
                  INTO WS-TS-STAMP
           END-STRING.
           MOVE TRTYPEI  TO TR-TYPE-CD.
           MOVE TRCATI   TO TR-CAT-CD.
           MOVE 'ONLINE' TO TR-SOURCE.
           MOVE TRDESCI  TO TR-DESC.
           COMPUTE TR-AMT = FUNCTION NUMVAL(TRAMTI).
           MOVE ZEROS    TO TR-MERCHANT-ID.
           MOVE TRMERCHI TO TR-MERCHANT-NAME.
           MOVE SPACES   TO TR-MERCHANT-CITY.
           MOVE SPACES   TO TR-MERCHANT-ZIP.
           MOVE CARDNUMI TO TR-CARD-NUM.
           MOVE WS-TS-STAMP TO TR-ORIG-TS.
           MOVE WS-TS-STAMP TO TR-PROC-TS.
      *----------------------------------------------------------------*
      *  DB2 write : INSERT the new transaction row.                   *
      *----------------------------------------------------------------*
       3400-INSERT-TRAN.
           SET REC-NOT-FOUND TO TRUE.
           EXEC SQL
                INSERT INTO ORION.TRAN
                     ( TR_ID, TR_TYPE_CD, TR_CAT_CD, TR_SOURCE,
                       TR_DESC, TR_AMT, TR_MERCHANT_ID,
                       TR_MERCHANT_NAME, TR_MERCHANT_CITY,
                       TR_MERCHANT_ZIP, TR_CARD_NUM,
                       TR_ORIG_TS, TR_PROC_TS )
                VALUES ( :TR-ID, :TR-TYPE-CD, :TR-CAT-CD,
                       :TR-SOURCE, :TR-DESC, :TR-AMT,
                       :TR-MERCHANT-ID, :TR-MERCHANT-NAME,
                       :TR-MERCHANT-CITY, :TR-MERCHANT-ZIP,
                       :TR-CARD-NUM, :TR-ORIG-TS, :TR-PROC-TS )
           END-EXEC.
           EVALUATE SQLCODE
               WHEN 0
                   SET REC-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   MOVE 'Error inserting transaction row.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MTRANAA')
                     MAPSET('MTRANA')
                     FROM(MTRANAAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
