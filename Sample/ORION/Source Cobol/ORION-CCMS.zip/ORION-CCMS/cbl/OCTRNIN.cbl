      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCTRNIN  -  Transaction Inquiry (on-line)         *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: one consolidated transaction look-up + analytics  *
      *            screen that replaces a whole shelf of batch        *
      *            reports.  The operator chooses a filter mode and   *
      *            keys its arguments:                                *
      *              C = card number         (was OBRTRAN)            *
      *              D = processed-date range(was OBRDAILY)           *
      *              M = merchant id         (was OBRMERCH)           *
      *              T = type + category                              *
      *              A = amount threshold    (was OBRTOP)             *
      *            OCTRNIN LINKs the analytics engine OUTRNIN which   *
      *            scans TRANFILE, returns one page of matching       *
      *            transactions (each with its TTYP/TCAT description) *
      *            plus filter-wide totals - match count / net total  *
      *            (OBTRSUM), purchase & payment subtotals, fee       *
      *            subtotal (OBRFEE), interest subtotal (OBRINC) and  *
      *            the largest single item (OBRTOP).                  *
      *  KEYS    : ENTER = apply filter   PF8 = next   PF7 = restart  *
      *            PF3   = back to menu                               *
      *  MAPSET  : MTRNIN      MAP : MTRNINA     TRANID : ORQT        *
      *  LINK    : OUTRNIN via COMMAREA(KTRNIN-AREA)                  *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - consolidated tran inquiry.     *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCTRNIN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCTRNIN'.
           05  WS-TRANID            PIC X(04) VALUE 'ORQT'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
           05  WS-SUB-PGM           PIC X(08) VALUE 'OUTRNIN'.
      *----------------------------------------------------------------*
      *  Local work / edit fields.                                     *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-ROW-IDX           PIC 9(02) VALUE ZEROS.
           05  WS-MODE              PIC X(01) VALUE SPACES.
           05  WS-CNT-ED            PIC ZZZZZZZ9.
           05  WS-CNT7              PIC ZZZZZZ9.
           05  WS-ED-SUM            PIC -,---,---,---,--9.99.
           05  WS-MSG-LINE          PIC X(78) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Validation switch used by the field parsers.                  *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Reusable integer-field parser work area.                      *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(09) VALUE SPACES.
           05  WS-NC-LEN            PIC 9(02) VALUE ZEROS.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(09) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Decimal-amount parser work area (accepts digits, comma, dot). *
      *----------------------------------------------------------------*
       01  WS-AMTCHK.
           05  WS-AM-IN             PIC X(12) VALUE SPACES.
           05  WS-AM-POS            PIC 9(02) VALUE ZEROS.
           05  WS-AM-CHAR           PIC X(01) VALUE SPACES.
           05  WS-AM-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-AM-INT            PIC 9(09) VALUE ZEROS.
           05  WS-AM-DEC            PIC 9(02) VALUE ZEROS.
           05  WS-AM-DECCNT         PIC 9(01) VALUE ZEROS.
           05  WS-AM-DIGCNT         PIC 9(02) VALUE ZEROS.
           05  WS-AM-DOT-SW         PIC X(01) VALUE 'N'.
               88  WS-AM-SEEN-DOT             VALUE 'Y'.
       01  WS-AM-BUILD.
           05  WS-AB-INT            PIC 9(09) VALUE ZEROS.
           05  WS-AB-DEC            PIC 9(02) VALUE ZEROS.
       01  WS-AM-NUM REDEFINES WS-AM-BUILD PIC 9(09)V99.
       01  WS-AM-VALUE              PIC S9(09)V99 VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(60)
               VALUE 'Choose filter C/D/M/T/A, key args, press ENTER.'.
           05  WS-M-BAD-MODE        PIC X(60)
               VALUE 'Mode must be C D M T or A.'.
           05  WS-M-CARD-REQ        PIC X(60)
               VALUE 'Card number is required for the card filter.'.
           05  WS-M-MERCH-REQ       PIC X(60)
               VALUE 'Merchant id is required and must be numeric.'.
           05  WS-M-TYPE-REQ        PIC X(60)
               VALUE 'Type is required for the type/category filter.'.
           05  WS-M-BAD-NUM         PIC X(60)
               VALUE 'A numeric filter argument is not valid.'.
           05  WS-M-BAD-AMT         PIC X(60)
               VALUE 'Amount threshold is not a valid number.'.
           05  WS-M-NONE-FOUND      PIC X(60)
               VALUE 'No transactions match the filter.'.
           05  WS-M-END-LIST        PIC X(60)
               VALUE 'End of list - no more transactions.'.
           05  WS-M-LINK-ERR        PIC X(60)
               VALUE 'Unable to link to analytics engine OUTRNIN.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  Analytics LINK interface and BMS symbolic map.                *
      *----------------------------------------------------------------*
       COPY KTRNIN.
       COPY MTRNIN.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh empty screen.*
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MTRNINAO.
           PERFORM 8000-POPULATE-HEADER.
           PERFORM 4100-CLEAR-ROWS.
           PERFORM 4500-CLEAR-SUMMARY.
           INITIALIZE KTRNIN-AREA.
           SET KTI-F-CARD TO TRUE.
           MOVE LOW-VALUES TO KTI-START-KEY.
           MOVE KTI-REQUEST TO CA-WORK-AREA.
           MOVE 'C' TO TMODEO.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO TMODEL.
           EXEC CICS SEND
                     MAP('MTRNINA')
                     MAPSET('MTRNIN')
                     FROM(MTRNINAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF7
                   PERFORM 2300-RESTART
               WHEN DFHPF8
                   PERFORM 2200-PAGE-NEXT
               WHEN DFHENTER
                   PERFORM 2100-APPLY-FILTER
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-APPLY-FILTER  -  ENTER : read the filter arguments,      *
      *  validate them and list the first page of results.            *
      *----------------------------------------------------------------*
       2100-APPLY-FILTER.
           EXEC CICS RECEIVE
                     MAP('MTRNINA')
                     MAPSET('MTRNIN')
                     INTO(MTRNINAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MTRNINAI
           END-IF.
           PERFORM 5000-PARSE-FILTER.
           IF WS-INVALID
               MOVE -1 TO TMODEL
               PERFORM 8100-SEND-DATAONLY
               GO TO 2100-EXIT
           END-IF.
           MOVE LOW-VALUES TO KTI-START-KEY.
           PERFORM 3000-CALL-SUB.
           PERFORM 4000-SHOW-PAGE.
       2100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2200-PAGE-NEXT  -  PF8 : resume the browse at the saved key.  *
      *----------------------------------------------------------------*
       2200-PAGE-NEXT.
           MOVE CA-WORK-AREA TO KTI-REQUEST.
           PERFORM 3000-CALL-SUB.
           IF KTI-ROW-COUNT = ZEROS
               PERFORM 4400-SHOW-SUMMARY
               MOVE WS-M-END-LIST TO ERRMSGO
               MOVE -1 TO TMODEL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 4000-SHOW-PAGE
           END-IF.
      *----------------------------------------------------------------*
      *  2300-RESTART  -  PF7 : list the first page again for the same *
      *  filter, resetting the paging cursor to the top.              *
      *----------------------------------------------------------------*
       2300-RESTART.
           MOVE CA-WORK-AREA TO KTI-REQUEST.
           MOVE LOW-VALUES TO KTI-START-KEY.
           PERFORM 3000-CALL-SUB.
           PERFORM 4000-SHOW-PAGE.
      *----------------------------------------------------------------*
      *  3000-CALL-SUB  -  LINK the analytics engine and advance / save*
      *  the paging cursor into the commarea for the next turn.        *
      *----------------------------------------------------------------*
       3000-CALL-SUB.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-SUB-PGM TO CA-TO-PROGRAM.
           EXEC CICS LINK
                     PROGRAM(WS-SUB-PGM)
                     COMMAREA(KTRNIN-AREA)
                     LENGTH(LENGTH OF KTRNIN-AREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               SET KTI-ERROR TO TRUE
               MOVE WS-M-LINK-ERR TO CA-ERR-MSG
           END-IF.
           IF KTI-ROW-COUNT > ZEROS
               MOVE KTI-NEXT-KEY TO KTI-START-KEY
           END-IF.
           MOVE KTI-REQUEST TO CA-WORK-AREA.
      *----------------------------------------------------------------*
      *  4000-SHOW-PAGE  -  paint the returned rows and the analytics. *
      *----------------------------------------------------------------*
       4000-SHOW-PAGE.
           PERFORM 4100-CLEAR-ROWS.
           IF KTI-ERROR
               PERFORM 4500-CLEAR-SUMMARY
               MOVE CA-ERR-MSG TO ERRMSGO
               MOVE -1 TO TMODEL
               PERFORM 8100-SEND-DATAONLY
               GO TO 4000-EXIT
           END-IF.
           PERFORM 4400-SHOW-SUMMARY.
           IF KTI-ROW-COUNT = ZEROS
               MOVE WS-M-NONE-FOUND TO ERRMSGO
           ELSE
               PERFORM VARYING WS-ROW-IDX FROM 1 BY 1
                       UNTIL WS-ROW-IDX > KTI-ROW-COUNT
                   PERFORM 4200-PLACE-ROW
               END-PERFORM
               PERFORM 4600-BUILD-MSG
               MOVE WS-MSG-LINE TO ERRMSGO
           END-IF.
           MOVE -1 TO TMODEL.
           PERFORM 8100-SEND-DATAONLY.
       4000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  4100-CLEAR-ROWS  -  blank the six transaction display lines.  *
      *----------------------------------------------------------------*
       4100-CLEAR-ROWS.
           MOVE SPACES TO TID1O TCD1O TTC1O TDS1O TMC1O TAM1O TDT1O.
           MOVE SPACES TO TID2O TCD2O TTC2O TDS2O TMC2O TAM2O TDT2O.
           MOVE SPACES TO TID3O TCD3O TTC3O TDS3O TMC3O TAM3O TDT3O.
           MOVE SPACES TO TID4O TCD4O TTC4O TDS4O TMC4O TAM4O TDT4O.
           MOVE SPACES TO TID5O TCD5O TTC5O TDS5O TMC5O TAM5O TDT5O.
           MOVE SPACES TO TID6O TCD6O TTC6O TDS6O TMC6O TAM6O TDT6O.
      *----------------------------------------------------------------*
      *  4200-PLACE-ROW  -  move one returned transaction into its map *
      *  line (card shown as last four digits, amount edited).        *
      *----------------------------------------------------------------*
       4200-PLACE-ROW.
           MOVE KTR-AMT (WS-ROW-IDX) TO WS-ED-AMT.
           EVALUATE WS-ROW-IDX
               WHEN 1
                   MOVE KTR-ID (1)          TO TID1O
                   MOVE KTR-CARD (1) (13:4) TO TCD1O
                   MOVE KTR-TYCAT (1)       TO TTC1O
                   MOVE KTR-DESC (1)        TO TDS1O
                   MOVE KTR-MERCH (1)       TO TMC1O
                   MOVE WS-ED-AMT (2:15)    TO TAM1O
                   MOVE KTR-DATE (1)        TO TDT1O
               WHEN 2
                   MOVE KTR-ID (2)          TO TID2O
                   MOVE KTR-CARD (2) (13:4) TO TCD2O
                   MOVE KTR-TYCAT (2)       TO TTC2O
                   MOVE KTR-DESC (2)        TO TDS2O
                   MOVE KTR-MERCH (2)       TO TMC2O
                   MOVE WS-ED-AMT (2:15)    TO TAM2O
                   MOVE KTR-DATE (2)        TO TDT2O
               WHEN 3
                   MOVE KTR-ID (3)          TO TID3O
                   MOVE KTR-CARD (3) (13:4) TO TCD3O
                   MOVE KTR-TYCAT (3)       TO TTC3O
                   MOVE KTR-DESC (3)        TO TDS3O
                   MOVE KTR-MERCH (3)       TO TMC3O
                   MOVE WS-ED-AMT (2:15)    TO TAM3O
                   MOVE KTR-DATE (3)        TO TDT3O
               WHEN 4
                   MOVE KTR-ID (4)          TO TID4O
                   MOVE KTR-CARD (4) (13:4) TO TCD4O
                   MOVE KTR-TYCAT (4)       TO TTC4O
                   MOVE KTR-DESC (4)        TO TDS4O
                   MOVE KTR-MERCH (4)       TO TMC4O
                   MOVE WS-ED-AMT (2:15)    TO TAM4O
                   MOVE KTR-DATE (4)        TO TDT4O
               WHEN 5
                   MOVE KTR-ID (5)          TO TID5O
                   MOVE KTR-CARD (5) (13:4) TO TCD5O
                   MOVE KTR-TYCAT (5)       TO TTC5O
                   MOVE KTR-DESC (5)        TO TDS5O
                   MOVE KTR-MERCH (5)       TO TMC5O
                   MOVE WS-ED-AMT (2:15)    TO TAM5O
                   MOVE KTR-DATE (5)        TO TDT5O
               WHEN 6
                   MOVE KTR-ID (6)          TO TID6O
                   MOVE KTR-CARD (6) (13:4) TO TCD6O
                   MOVE KTR-TYCAT (6)       TO TTC6O
                   MOVE KTR-DESC (6)        TO TDS6O
                   MOVE KTR-MERCH (6)       TO TMC6O
                   MOVE WS-ED-AMT (2:15)    TO TAM6O
                   MOVE KTR-DATE (6)        TO TDT6O
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4400-SHOW-SUMMARY  -  paint the filter-wide analytics block.  *
      *----------------------------------------------------------------*
       4400-SHOW-SUMMARY.
           MOVE KTI-MATCH-COUNT TO WS-CNT-ED.
           MOVE WS-CNT-ED       TO MCNTO.
           MOVE KTI-NET-TOTAL   TO WS-ED-SUM.
           MOVE WS-ED-SUM       TO MTOTO.
           MOVE KTI-PURCH-CNT   TO WS-CNT7.
           MOVE WS-CNT7         TO PCNTO.
           MOVE KTI-PURCH-SUM   TO WS-ED-SUM.
           MOVE WS-ED-SUM       TO PSUMO.
           MOVE KTI-PAY-CNT     TO WS-CNT7.
           MOVE WS-CNT7         TO YCNTO.
           MOVE KTI-PAY-SUM     TO WS-ED-SUM.
           MOVE WS-ED-SUM       TO YSUMO.
           MOVE KTI-FEE-CNT     TO WS-CNT7.
           MOVE WS-CNT7         TO FCNTO.
           MOVE KTI-FEE-SUM     TO WS-ED-SUM.
           MOVE WS-ED-SUM       TO FSUMO.
           MOVE KTI-INT-CNT     TO WS-CNT7.
           MOVE WS-CNT7         TO ICNTO.
           MOVE KTI-INT-SUM     TO WS-ED-SUM.
           MOVE WS-ED-SUM       TO ISUMO.
           MOVE KTI-MAX-ID      TO XIDO.
           MOVE KTI-MAX-AMT     TO WS-ED-SUM.
           MOVE WS-ED-SUM       TO XAMTO.
      *----------------------------------------------------------------*
      *  4500-CLEAR-SUMMARY  -  blank the analytics block.            *
      *----------------------------------------------------------------*
       4500-CLEAR-SUMMARY.
           MOVE SPACES TO MCNTO MTOTO.
           MOVE SPACES TO PCNTO PSUMO.
           MOVE SPACES TO YCNTO YSUMO.
           MOVE SPACES TO FCNTO FSUMO.
           MOVE SPACES TO ICNTO ISUMO.
           MOVE SPACES TO XIDO  XAMTO.
      *----------------------------------------------------------------*
      *  4600-BUILD-MSG  -  compose the paging message line.          *
      *----------------------------------------------------------------*
       4600-BUILD-MSG.
           MOVE KTI-MATCH-COUNT TO WS-CNT-ED.
           MOVE SPACES TO WS-MSG-LINE.
           IF KTI-MORE
               STRING WS-CNT-ED DELIMITED BY SIZE
                      ' matching tran(s).  PF8=more PF7=top'
                      DELIMITED BY SIZE
                      INTO WS-MSG-LINE
               END-STRING
           ELSE
               STRING WS-CNT-ED DELIMITED BY SIZE
                      ' matching tran(s).  End of list.'
                      DELIMITED BY SIZE
                      INTO WS-MSG-LINE
               END-STRING
           END-IF.
      *----------------------------------------------------------------*
      *  5000-PARSE-FILTER  -  translate the map filter fields into    *
      *  the KTRNIN request half; set WS-INVALID on any bad argument.  *
      *----------------------------------------------------------------*
       5000-PARSE-FILTER.
           SET WS-VALID TO TRUE.
           MOVE TMODEI TO WS-MODE.
           INSPECT WS-MODE REPLACING ALL LOW-VALUE BY SPACE.
           INITIALIZE KTRNIN-AREA.
           EVALUATE WS-MODE
               WHEN 'C'
                   PERFORM 5100-PARSE-CARD
               WHEN 'D'
                   PERFORM 5200-PARSE-DATE
               WHEN 'M'
                   PERFORM 5300-PARSE-MERCH
               WHEN 'T'
                   PERFORM 5400-PARSE-TYPECAT
               WHEN 'A'
                   PERFORM 5500-PARSE-AMOUNT
               WHEN OTHER
                   MOVE WS-M-BAD-MODE TO ERRMSGO
                   SET WS-INVALID TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  5100-PARSE-CARD  -  card number filter (required).           *
      *----------------------------------------------------------------*
       5100-PARSE-CARD.
           SET KTI-F-CARD TO TRUE.
           MOVE FCARDI TO KTI-CARD.
           INSPECT KTI-CARD REPLACING ALL LOW-VALUE BY SPACE.
           IF KTI-CARD = SPACES
               MOVE WS-M-CARD-REQ TO ERRMSGO
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  5200-PARSE-DATE  -  processed-date range (blank = open end).  *
      *----------------------------------------------------------------*
       5200-PARSE-DATE.
           SET KTI-F-DATE TO TRUE.
           MOVE FRDATEI TO KTI-DATE-FROM.
           INSPECT KTI-DATE-FROM REPLACING ALL LOW-VALUE BY SPACE.
           MOVE FTDATEI TO KTI-DATE-TO.
           INSPECT KTI-DATE-TO REPLACING ALL LOW-VALUE BY SPACE.
           IF KTI-DATE-FROM = SPACES
               MOVE '0000-00-00' TO KTI-DATE-FROM
           END-IF.
           IF KTI-DATE-TO = SPACES
               MOVE '9999-99-99' TO KTI-DATE-TO
           END-IF.
      *----------------------------------------------------------------*
      *  5300-PARSE-MERCH  -  merchant id filter (required numeric).   *
      *----------------------------------------------------------------*
       5300-PARSE-MERCH.
           SET KTI-F-MERCH TO TRUE.
           MOVE FMERCHI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN = SPACES
               MOVE WS-M-MERCH-REQ TO ERRMSGO
               SET WS-INVALID TO TRUE
               GO TO 5300-EXIT
           END-IF.
           MOVE 9 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID
               MOVE WS-M-MERCH-REQ TO ERRMSGO
           ELSE
               MOVE WS-NC-VALUE TO KTI-MERCH-ID
           END-IF.
       5300-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5400-PARSE-TYPECAT  -  type (required) + category (optional). *
      *----------------------------------------------------------------*
       5400-PARSE-TYPECAT.
           SET KTI-F-TYPECAT TO TRUE.
           MOVE FTYPEI TO KTI-F-TYPE.
           INSPECT KTI-F-TYPE REPLACING ALL LOW-VALUE BY SPACE.
           IF KTI-F-TYPE = SPACES
               MOVE WS-M-TYPE-REQ TO ERRMSGO
               SET WS-INVALID TO TRUE
               GO TO 5400-EXIT
           END-IF.
           MOVE ZEROS TO KTI-F-CAT.
           MOVE FCATI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN NOT = SPACES
               MOVE 4 TO WS-NC-LEN
               PERFORM 6000-PARSE-NUM
               IF WS-INVALID
                   MOVE WS-M-BAD-NUM TO ERRMSGO
               ELSE
                   MOVE WS-NC-VALUE TO KTI-F-CAT
               END-IF
           END-IF.
       5400-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5500-PARSE-AMOUNT  -  amount threshold (blank = zero).        *
      *----------------------------------------------------------------*
       5500-PARSE-AMOUNT.
           SET KTI-F-AMOUNT TO TRUE.
           MOVE ZEROS TO KTI-AMT-THRESH.
           MOVE FAMTI TO WS-AM-IN.
           INSPECT WS-AM-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-AM-IN NOT = SPACES
               PERFORM 6500-PARSE-AMT
               IF WS-INVALID
                   MOVE WS-M-BAD-AMT TO ERRMSGO
               ELSE
                   MOVE WS-AM-VALUE TO KTI-AMT-THRESH
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  6000-PARSE-NUM  -  scan WS-NC-IN for WS-NC-LEN characters,    *
      *  ignore spaces, accumulate digits into WS-NC-VALUE.  Any other *
      *  character makes the field invalid.                            *
      *----------------------------------------------------------------*
       6000-PARSE-NUM.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > WS-NC-LEN
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  6500-PARSE-AMT  -  scan WS-AM-IN for a decimal amount.  Digits*
      *  build the integer part until a dot, then up to two decimals;  *
      *  spaces and commas are ignored; anything else is invalid.     *
      *----------------------------------------------------------------*
       6500-PARSE-AMT.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-AM-INT WS-AM-DEC.
           MOVE ZEROS TO WS-AM-DECCNT WS-AM-DIGCNT.
           MOVE 'N' TO WS-AM-DOT-SW.
           INSPECT WS-AM-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-AM-POS FROM 1 BY 1
                   UNTIL WS-AM-POS > 12
               MOVE WS-AM-IN(WS-AM-POS:1) TO WS-AM-CHAR
               EVALUATE TRUE
                   WHEN WS-AM-CHAR = SPACE
                       CONTINUE
                   WHEN WS-AM-CHAR = ','
                       CONTINUE
                   WHEN WS-AM-CHAR = '.'
                       IF WS-AM-SEEN-DOT
                           SET WS-INVALID TO TRUE
                       ELSE
                           SET WS-AM-SEEN-DOT TO TRUE
                       END-IF
                   WHEN WS-AM-CHAR >= '0' AND WS-AM-CHAR <= '9'
                       MOVE WS-AM-CHAR TO WS-AM-DIGIT
                       ADD 1 TO WS-AM-DIGCNT
                       IF WS-AM-SEEN-DOT
                           IF WS-AM-DECCNT < 2
                               COMPUTE WS-AM-DEC =
                                   WS-AM-DEC * 10 + WS-AM-DIGIT
                               ADD 1 TO WS-AM-DECCNT
                           END-IF
                       ELSE
                           COMPUTE WS-AM-INT =
                               WS-AM-INT * 10 + WS-AM-DIGIT
                       END-IF
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-AM-DIGCNT = 0
               SET WS-INVALID TO TRUE
           END-IF.
           IF WS-AM-SEEN-DOT AND WS-AM-DECCNT = 1
               COMPUTE WS-AM-DEC = WS-AM-DEC * 10
           END-IF.
           MOVE WS-AM-INT TO WS-AB-INT.
           MOVE WS-AM-DEC TO WS-AB-DEC.
           MOVE WS-AM-NUM TO WS-AM-VALUE.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.*
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  re-transmit the map data only.         *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MTRNINA')
                     MAPSET('MTRNIN')
                     FROM(MTRNINAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to CICS.         *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
