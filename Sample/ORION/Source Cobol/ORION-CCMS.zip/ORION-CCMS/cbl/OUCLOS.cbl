      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUCLOS  -  Account close SUB                      *
      *  TYPE    : SUB  (CICS file control)                          *
      *  FUNCTION: close expired or flagged accounts on demand.      *
      *            Browses the account master (ACCTFILE); an active   *
      *            account is closed (status set to 'N') when its      *
      *            expiry date is present and earlier than the run     *
      *            date (EXPIRED) or its credit limit is zero          *
      *            (ZEROLIMIT).  EXPIRED takes precedence so each      *
      *            closed account maps to one reason.  Closed accounts *
      *            are READ for UPDATE and REWRITTEN; accounts already *
      *            carrying status 'N' are counted and left untouched. *
      *            Ports the batch account-close OBACCT2.             *
      *  CALL    : EXEC CICS LINK PROGRAM('OUCLOS')                   *
      *                COMMAREA(ORION-COMMAREA) END-EXEC.             *
      *  REQUEST : KO-PARM-ACCT optional single account (0 = all).    *
      *  RESULT  : KO-READ read       KO-POSTED total closed          *
      *            KO-UPDATE rewritten KO-SKIP already closed         *
      *            KO-C1 closed expired KO-C2 closed zero-limit        *
      *            KO-C3 kept active    KO-AMT-1 balance of closed.    *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUCLOS.
       AUTHOR.     ORION-CCMS-ONLINE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and status literals.                         *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUCLOS'.
           05  WS-STATUS-ACTIVE     PIC X(01) VALUE 'Y'.
           05  WS-STATUS-CLOSED     PIC X(01) VALUE 'N'.
           05  WS-ZERO-AMOUNT       PIC S9(10)V99 VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Browse and reason switches.                                   *
      *----------------------------------------------------------------*
       01  WS-FLAGS.
           05  WS-BR-END-SW         PIC X(01) VALUE 'N'.
               88  BR-END                     VALUE 'Y'.
               88  BR-MORE                    VALUE 'N'.
           05  WS-BR-STARTED-SW     PIC X(01) VALUE 'N'.
               88  BR-STARTED                 VALUE 'Y'.
               88  BR-NOT-STARTED             VALUE 'N'.
           05  WS-CLOSE-SW          PIC X(01) VALUE 'N'.
               88  MUST-CLOSE                 VALUE 'Y'.
               88  MUST-KEEP                  VALUE 'N'.
           05  WS-REASON-SW         PIC X(01) VALUE ' '.
               88  REASON-NONE                VALUE ' '.
               88  REASON-EXPIRED             VALUE 'E'.
               88  REASON-ZEROLIMIT           VALUE 'Z'.
           05  WS-FILTER-ON         PIC X(01) VALUE 'N'.
               88  FILTER-ACTIVE              VALUE 'Y'.
      *----------------------------------------------------------------*
      *  Work fields and the run date for the expiry comparison.       *
      *----------------------------------------------------------------*
       01  WS-CALC.
           05  WS-FILTER-ACCT       PIC 9(11) VALUE ZEROS.
       01  WS-CURR-RAW              PIC X(21) VALUE SPACES.
       01  WS-CURR-N.
           05  WCN-YEAR             PIC 9(04).
           05  WCN-MON              PIC 9(02).
           05  WCN-DAY              PIC 9(02).
       01  WS-RUN-DATE.
           05  WR-YEAR              PIC 9(04).
           05  FILLER               PIC X(01) VALUE '-'.
           05  WR-MON               PIC 9(02).
           05  FILLER               PIC X(01) VALUE '-'.
           05  WR-DAY               PIC 9(02).
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RACCT.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KOPS.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN : overlay request, run the browse, return.          *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KOPS-AREA TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INITIALISE.
           PERFORM 3000-BROWSE-DRIVER.
           PERFORM 9000-FINALISE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INITIALISE : clear results, derive the run date.         *
      *----------------------------------------------------------------*
       1000-INITIALISE.
           SET KO-OK TO TRUE.
           MOVE SPACES TO KO-STATUS-MSG.
           MOVE ZEROS TO KO-READ-CNT.
           MOVE ZEROS TO KO-SELECT-CNT.
           MOVE ZEROS TO KO-UPDATE-CNT.
           MOVE ZEROS TO KO-POSTED-CNT.
           MOVE ZEROS TO KO-REJECT-CNT.
           MOVE ZEROS TO KO-SKIP-CNT.
           MOVE ZEROS TO KO-TRAN-CNT.
           MOVE ZEROS TO KO-C1.
           MOVE ZEROS TO KO-C2.
           MOVE ZEROS TO KO-C3.
           MOVE ZEROS TO KO-AMT-1.
           MOVE ZEROS TO KO-AMT-2.
           MOVE ZEROS TO KO-AMT-3.
           MOVE 'N' TO WS-FILTER-ON.
           IF KO-PARM-ACCT > ZERO
               MOVE KO-PARM-ACCT TO WS-FILTER-ACCT
               SET FILTER-ACTIVE TO TRUE
           END-IF.
           MOVE FUNCTION CURRENT-DATE TO WS-CURR-RAW.
           MOVE WS-CURR-RAW(1:8) TO WS-CURR-N.
           MOVE WCN-YEAR TO WR-YEAR.
           MOVE WCN-MON  TO WR-MON.
           MOVE WCN-DAY  TO WR-DAY.
           SET BR-MORE TO TRUE.
           SET BR-NOT-STARTED TO TRUE.
      *----------------------------------------------------------------*
      *  3000-BROWSE-DRIVER : browse accounts and close where due.     *
      *----------------------------------------------------------------*
       3000-BROWSE-DRIVER.
           PERFORM 3100-START-BROWSE.
           IF BR-STARTED
               PERFORM 3200-READ-NEXT-ACCT
               PERFORM 4000-PROCESS-ACCT
                   UNTIL BR-END OR KO-ERROR
               PERFORM 3400-END-BROWSE
           END-IF.
      *----------------------------------------------------------------*
      *  3100-START-BROWSE : STARTBR at filter key or file start.      *
      *----------------------------------------------------------------*
       3100-START-BROWSE.
           IF FILTER-ACTIVE
               MOVE WS-FILTER-ACCT TO AC-ID
           ELSE
               MOVE ZEROS TO AC-ID
           END-IF.
           EXEC CICS STARTBR
                     FILE(WS-ACCTFILE)
                     RIDFLD(AC-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BR-STARTED TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET BR-END TO TRUE
                   MOVE 'NO ACCOUNTS TO PROCESS.' TO KO-STATUS-MSG
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'STARTBR ACCTFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-READ-NEXT-ACCT : read one account forward.               *
      *----------------------------------------------------------------*
       3200-READ-NEXT-ACCT.
           EXEC CICS READNEXT
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KO-READ-CNT
               WHEN DFHRESP(ENDFILE)
                   SET BR-END TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'READNEXT ACCTFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-PROCESS-ACCT : classify the account and close if needed. *
      *----------------------------------------------------------------*
       4000-PROCESS-ACCT.
           IF FILTER-ACTIVE AND AC-ID NOT = WS-FILTER-ACCT
               SET BR-END TO TRUE
           ELSE
               IF AC-ACTIVE-STATUS = WS-STATUS-CLOSED
                   ADD 1 TO KO-SKIP-CNT
               ELSE
                   PERFORM 4100-CHECK-CONDITIONS
                   IF MUST-CLOSE
                       PERFORM 4200-CLOSE-ACCT
                   ELSE
                       ADD 1 TO KO-C3
                   END-IF
               END-IF
               PERFORM 3200-READ-NEXT-ACCT
           END-IF.
      *----------------------------------------------------------------*
      *  4100-CHECK-CONDITIONS : close + reason, EXPIRED wins.         *
      *----------------------------------------------------------------*
       4100-CHECK-CONDITIONS.
           SET MUST-KEEP TO TRUE.
           SET REASON-NONE TO TRUE.
           IF AC-EXPIRY-DATE NOT = SPACES
              AND AC-EXPIRY-DATE < WS-RUN-DATE
               SET MUST-CLOSE TO TRUE
               SET REASON-EXPIRED TO TRUE
           ELSE
               IF AC-CREDIT-LIMIT = WS-ZERO-AMOUNT
                   SET MUST-CLOSE TO TRUE
                   SET REASON-ZEROLIMIT TO TRUE
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  4200-CLOSE-ACCT : READ for UPDATE, set 'N', REWRITE, count.   *
      *----------------------------------------------------------------*
       4200-CLOSE-ACCT.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               ADD 1 TO KO-REJECT-CNT
               GO TO 4200-EXIT
           END-IF.
           MOVE WS-STATUS-CLOSED TO AC-ACTIVE-STATUS.
           EXEC CICS REWRITE
                     FILE(WS-ACCTFILE)
                     FROM(ACCT-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KO-POSTED-CNT
               ADD 1 TO KO-UPDATE-CNT
               ADD 1 TO KO-SELECT-CNT
               ADD AC-CURR-BAL TO KO-AMT-1
               IF REASON-EXPIRED
                   ADD 1 TO KO-C1
               END-IF
               IF REASON-ZEROLIMIT
                   ADD 1 TO KO-C2
               END-IF
           ELSE
               ADD 1 TO KO-REJECT-CNT
           END-IF.
       4200-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3400-END-BROWSE : release the account browse.                 *
      *----------------------------------------------------------------*
       3400-END-BROWSE.
           IF BR-STARTED
               EXEC CICS ENDBR
                         FILE(WS-ACCTFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
      *----------------------------------------------------------------*
      *  9000-FINALISE : set the completion status message.            *
      *----------------------------------------------------------------*
       9000-FINALISE.
           IF KO-ERROR
               CONTINUE
           ELSE
               IF KO-REJECT-CNT > 0
                   SET KO-WARN TO TRUE
               ELSE
                   SET KO-OK TO TRUE
               END-IF
               MOVE 'ACCOUNT CLOSE PROCESSING COMPLETE.'
                   TO KO-STATUS-MSG
           END-IF.
