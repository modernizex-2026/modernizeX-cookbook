      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCCARDV  -  Card View (on-line)                   *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: accept a 16-digit card number, read CARDFILE by   *
      *            CD-NUM and display the owning account id, the     *
      *            embossed name, expiry date and active status.     *
      *  KEYS    : ENTER = read      PF3 = menu      PF4 = clear     *
      *  NOTE    : if a card number was pre-selected upstream        *
      *            (CA-CARD-NUM) it is offered on the entry screen.  *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCCARDV.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity constants.                                   *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCCARDV'.
           05  WS-TRANID            PIC X(04) VALUE 'ORCV'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Validation switch.                                           *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Card number validation work area.                           *
      *----------------------------------------------------------------*
       01  WS-CARDCHK.
           05  WS-CN-IN             PIC X(16) VALUE SPACES.
           05  WS-CN-POS            PIC 9(02) VALUE ZEROS.
           05  WS-CN-CHAR           PIC X(01) VALUE SPACES.
           05  WS-CN-DIGITS         PIC 9(02) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Shared copybooks.                                            *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RCARD.
       COPY MCARDV.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN : standard dispatcher.                            *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL : prompt for a card number.              *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MCARDVAO.
           PERFORM 8000-POPULATE-HEADER.
           IF CA-CARD-NUM = SPACES OR CA-CARD-NUM = LOW-VALUES
               MOVE 'Enter card number and press ENTER.' TO ERRMSGO
           ELSE
               MOVE CA-CARD-NUM TO CARDNUMO
               MOVE 'Press ENTER to view the selected card.'
                   TO ERRMSGO
           END-IF.
           EXEC CICS SEND
                     MAP('MCARDVA')
                     MAPSET('MCARDV')
                     FROM(MCARDVAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT : react to the attention identifier.      *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF12
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHCLEAR
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-READ-AND-SHOW
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2050-RECEIVE : read the map; treat MAPFAIL as empty input.   *
      *----------------------------------------------------------------*
       2050-RECEIVE.
           EXEC CICS RECEIVE
                     MAP('MCARDVA')
                     MAPSET('MCARDV')
                     INTO(MCARDVAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MCARDVAI
           END-IF.
      *----------------------------------------------------------------*
      *  2100-READ-AND-SHOW : validate, read and display the card.    *
      *----------------------------------------------------------------*
       2100-READ-AND-SHOW.
           PERFORM 2050-RECEIVE.
           PERFORM 6000-VALIDATE-CARDNUM.
           IF WS-INVALID
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE WS-CN-IN TO CD-NUM
               MOVE CD-NUM   TO CA-CARD-NUM
               PERFORM 3000-READ-CARD
               IF REC-FOUND
                   PERFORM 4000-POPULATE-DETAIL
                   MOVE 'Card displayed.' TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE WS-MSG-NOTFND TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3000-READ-CARD : random read of CARDFILE by CD-NUM.         *
      *----------------------------------------------------------------*
       3000-READ-CARD.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-CARDFILE)
                     INTO(CARD-REC)
                     RIDFLD(CD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-POPULATE-DETAIL : move CARD-REC into the output map.    *
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE CD-NUM            TO CARDNUMO.
           MOVE CD-ACCT-ID        TO CDACCTO.
           MOVE CD-EMBOSSED-NAME  TO CDNAMEO.
           MOVE CD-EXPIRY-DATE    TO CDEXPO.
           MOVE CD-ACTIVE-STATUS  TO CDSTATO.
      *----------------------------------------------------------------*
      *  6000-VALIDATE-CARDNUM : card number must be 16 digits.       *
      *----------------------------------------------------------------*
       6000-VALIDATE-CARDNUM.
           SET WS-VALID TO TRUE.
           MOVE CARDNUMI TO WS-CN-IN.
           INSPECT WS-CN-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-CN-IN = SPACES
               SET WS-INVALID TO TRUE
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               GO TO 6000-EXIT
           END-IF.
           MOVE ZEROS TO WS-CN-DIGITS.
           PERFORM VARYING WS-CN-POS FROM 1 BY 1
                   UNTIL WS-CN-POS > 16
               MOVE WS-CN-IN(WS-CN-POS:1) TO WS-CN-CHAR
               IF WS-CN-CHAR >= '0' AND WS-CN-CHAR <= '9'
                   ADD 1 TO WS-CN-DIGITS
               ELSE
                   SET WS-INVALID TO TRUE
               END-IF
           END-PERFORM.
           IF WS-INVALID OR WS-CN-DIGITS NOT = 16
               SET WS-INVALID TO TRUE
               MOVE 'Card number must be exactly 16 digits.'
                   TO ERRMSGO
           END-IF.
       6000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU : return to the main menu.                    *
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER : common screen header.                *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY : refresh header and resend.             *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MCARDVA')
                     MAPSET('MCARDV')
                     FROM(MCARDVAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME : formatted current date and time.        *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN : pseudo-conversational return.                 *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9500-ABEND-RTN : unrecoverable file error.                  *
      *----------------------------------------------------------------*
       9500-ABEND-RTN.
           MOVE 'OCCARDV: unrecoverable file error. Contact support.'
               TO WS-MSG-TEXT.
           EXEC CICS SEND TEXT
                     FROM(WS-MSG-TEXT)
                     LENGTH(LENGTH OF WS-MSG-TEXT)
                     ERASE
                     FREEKB
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS RETURN
                     RESP(WS-RESP-CD)
           END-EXEC.
