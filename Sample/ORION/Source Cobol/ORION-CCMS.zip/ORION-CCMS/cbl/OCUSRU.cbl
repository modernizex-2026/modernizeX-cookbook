      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCUSRU   -  User Update (on-line)                *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: accept a user id and read the user security record *
      *            (USRSEC), display the current details, then on the *
      *            next ENTER validate the changes and REWRITE the     *
      *            record.  The user id itself is the key and is not   *
      *            changed.                                           *
      *  MAP     : MUSRUA of mapset MUSRU.                           *
      *  TRANID  : ORUP.  PF3 = admin menu, PF4 = clear.            *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCUSRU.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identification constants.                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCUSRU'.
           05  WS-TRANID            PIC X(04) VALUE 'ORUP'.
           05  WS-ADMEN-PGM         PIC X(08) VALUE 'OCADMEN'.
      *----------------------------------------------------------------*
      *  Pseudo-conversational state : which step of the dialogue we   *
      *  are in, plus the id of the user being maintained.            *
      *----------------------------------------------------------------*
       01  WS-STATE-AREA.
           05  WS-STAGE             PIC X(01) VALUE '0'.
               88  STAGE-NEED-ID             VALUE '0'.
               88  STAGE-NEED-UPD            VALUE '1'.
           05  WS-SV-USERID         PIC X(08) VALUE SPACES.
           05  FILLER               PIC X(503) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Validation work fields.                                       *
      *----------------------------------------------------------------*
       01  WS-EDIT-WORK.
           05  WS-EDIT-FLG          PIC X(01) VALUE 'Y'.
               88  WS-INPUT-OK               VALUE 'Y'.
               88  WS-INPUT-BAD              VALUE 'N'.
           05  WS-TYPE-IN           PIC X(01) VALUE SPACES.
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RUSER.
       COPY MUSRU.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN : pseudo-conversational entry point.                *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               MOVE CA-WORK-AREA TO WS-STATE-AREA
               MOVE SPACES       TO CA-ERR-MSG
               IF CA-FIRST-ENTER
                   PERFORM 1000-SEND-INITIAL
               ELSE
                   PERFORM 2000-PROCESS-INPUT
               END-IF
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL : prompt for the user id to update.         *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MUSRUAO.
           SET STAGE-NEED-ID TO TRUE.
           MOVE SPACES TO WS-SV-USERID.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter a user id and press ENTER.' TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MUSRUA')
                     MAPSET('MUSRU')
                     FROM(MUSRUAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT : dispatch on the AID key.                 *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-ADMEN
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-HANDLE-ENTER
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-HANDLE-ENTER : act on the current dialogue stage.        *
      *----------------------------------------------------------------*
       2100-HANDLE-ENTER.
           PERFORM 2110-RECEIVE-MAP.
           EVALUATE TRUE
               WHEN STAGE-NEED-ID
                   PERFORM 2200-FETCH-USER
               WHEN STAGE-NEED-UPD
                   PERFORM 2300-APPLY-UPDATE
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2110-RECEIVE-MAP : read whatever the operator entered.        *
      *----------------------------------------------------------------*
       2110-RECEIVE-MAP.
           EXEC CICS RECEIVE
                     MAP('MUSRUA')
                     MAPSET('MUSRU')
                     INTO(MUSRUAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  2200-FETCH-USER : stage 1.  Read the user and display the     *
      *  current values, then advance to the update stage.            *
      *----------------------------------------------------------------*
       2200-FETCH-USER.
           IF USERIDI = SPACES OR USERIDI = LOW-VALUES
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE USERIDI TO US-ID
               PERFORM 3000-READ-USER
               IF REC-FOUND
                   PERFORM 2210-SHOW-USER
               ELSE
                   MOVE 'User not found.' TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2210-SHOW-USER : populate the detail fields and remember the  *
      *  user id for the update.                                      *
      *----------------------------------------------------------------*
       2210-SHOW-USER.
           MOVE US-ID         TO WS-SV-USERID.
           MOVE US-ID         TO USERIDO.
           MOVE US-FIRST-NAME TO USFNAMO.
           MOVE US-LAST-NAME  TO USLNAMO.
           MOVE US-PASSWORD   TO USPWDO.
           MOVE US-TYPE       TO USTYPEO.
           SET STAGE-NEED-UPD TO TRUE.
           MOVE 'Modify fields and press ENTER to update.'
               TO ERRMSGO.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  2300-APPLY-UPDATE : stage 2.  Validate the modified values    *
      *  and rewrite the record under the saved key.                  *
      *----------------------------------------------------------------*
       2300-APPLY-UPDATE.
           PERFORM 2310-VALIDATE-INPUT.
           IF WS-INPUT-BAD
               PERFORM 4000-REPOPULATE
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 3100-UPDATE-USER
               IF ERR-FLG-ON
                   PERFORM 4000-REPOPULATE
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   PERFORM 4100-CONFIRM-UPDATE
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2310-VALIDATE-INPUT : names and password required; type A/U.  *
      *----------------------------------------------------------------*
       2310-VALIDATE-INPUT.
           SET WS-INPUT-OK TO TRUE.
           IF USFNAMI = SPACES OR USFNAMI = LOW-VALUES
               SET WS-INPUT-BAD TO TRUE
               MOVE 'First name is required.' TO ERRMSGO
               GO TO 2310-EXIT
           END-IF.
           IF USLNAMI = SPACES OR USLNAMI = LOW-VALUES
               SET WS-INPUT-BAD TO TRUE
               MOVE 'Last name is required.' TO ERRMSGO
               GO TO 2310-EXIT
           END-IF.
           IF USPWDI = SPACES OR USPWDI = LOW-VALUES
               SET WS-INPUT-BAD TO TRUE
               MOVE 'Password is required.' TO ERRMSGO
               GO TO 2310-EXIT
           END-IF.
           MOVE USTYPEI TO WS-TYPE-IN.
           IF WS-TYPE-IN NOT = 'A' AND WS-TYPE-IN NOT = 'U'
               SET WS-INPUT-BAD TO TRUE
               MOVE 'Type must be A (admin) or U (user).'
                   TO ERRMSGO
           END-IF.
       2310-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3000-READ-USER : simple read of the user record.             *
      *----------------------------------------------------------------*
       3000-READ-USER.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-USRSEC)
                     INTO(USER-REC)
                     RIDFLD(US-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error reading user file.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3100-UPDATE-USER : read the record for update, apply the new  *
      *  values and rewrite it.                                       *
      *----------------------------------------------------------------*
       3100-UPDATE-USER.
           SET ERR-FLG-OFF TO TRUE.
           MOVE WS-SV-USERID TO US-ID.
           EXEC CICS READ
                     FILE(WS-USRSEC)
                     INTO(USER-REC)
                     RIDFLD(US-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   PERFORM 3110-REWRITE-USER
               WHEN DFHRESP(NOTFND)
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'User no longer exists.' TO ERRMSGO
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error reading user for update.'
                       TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3110-REWRITE-USER : move new values into the record and       *
      *  rewrite it.  The key field US-ID is left unchanged.          *
      *----------------------------------------------------------------*
       3110-REWRITE-USER.
           MOVE USFNAMI    TO US-FIRST-NAME.
           MOVE USLNAMI    TO US-LAST-NAME.
           MOVE USPWDI     TO US-PASSWORD.
           MOVE WS-TYPE-IN TO US-TYPE.
           EXEC CICS REWRITE
                     FILE(WS-USRSEC)
                     FROM(USER-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               SET ERR-FLG-ON TO TRUE
               MOVE 'Error updating user file.' TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  4000-REPOPULATE : keep the entered values on the screen when  *
      *  an error is reported during the update stage.                *
      *----------------------------------------------------------------*
       4000-REPOPULATE.
           MOVE WS-SV-USERID TO USERIDO.
           MOVE USFNAMI      TO USFNAMO.
           MOVE USLNAMI      TO USLNAMO.
           MOVE USPWDI       TO USPWDO.
           MOVE USTYPEI      TO USTYPEO.
      *----------------------------------------------------------------*
      *  4100-CONFIRM-UPDATE : report success and return to stage 1.   *
      *----------------------------------------------------------------*
       4100-CONFIRM-UPDATE.
           MOVE LOW-VALUES TO MUSRUAO.
           SET STAGE-NEED-ID TO TRUE.
           MOVE SPACES TO WS-SV-USERID.
           MOVE 'User updated successfully.' TO ERRMSGO.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  7000-XCTL-ADMEN : return to the administrator menu.           *
      *----------------------------------------------------------------*
       7000-XCTL-ADMEN.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           MOVE WS-STATE-AREA TO CA-WORK-AREA.
           EXEC CICS XCTL
                     PROGRAM(WS-ADMEN-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER : fill the standard screen header.       *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY : resend the map without erasing.          *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MUSRUA')
                     MAPSET('MUSRU')
                     FROM(MUSRUAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME : obtain the current date and time.        *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN : save state and return pseudo-conversationally.  *
      *----------------------------------------------------------------*
       9000-RETURN.
           MOVE WS-STATE-AREA TO CA-WORK-AREA.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
