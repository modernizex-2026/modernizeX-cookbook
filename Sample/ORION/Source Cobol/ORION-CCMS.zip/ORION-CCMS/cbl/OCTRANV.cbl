      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCTRANV  -  Transaction View (on-line)           *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: accept a transaction id, read the transaction      *
      *            master (TRANFILE) and display the card number,     *
      *            type, amount, merchant name and description.       *
      *            PF3 = back to menu, PF4 = clear, ENTER = read.     *
      *  MAPSET  : MTRANV      MAP : MTRANVA     TRANID : ORTV        *
      *  FILES   : TRANFILE (read only, keyed on TR-ID)              *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.       *
      *****************************************************************
      *  MAINTENANCE LOG                                              *
      *  ----  ----------  --------------------------------------     *
      *  0001  2026-08-07  Original - transaction inquiry screen.     *
      *****************************************************************
      *  PROCESSING NARRATIVE                                         *
      *  1. First entry shows an empty screen prompting for a          *
      *     transaction id.                                            *
      *  2. On ENTER the id is checked for presence and the           *
      *     transaction record is read by its primary key.            *
      *  3. When found the detail fields are formatted and returned;   *
      *     otherwise a not-found message is issued.                   *
      *  4. PF3 returns to the main menu; PF4 clears the screen.       *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCTRANV.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identification and navigation constants               *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCTRANV'.
           05  WS-TRANID            PIC X(04) VALUE 'ORTV'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Work and formatting fields local to this program              *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-TRAN-KEY          PIC X(16) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Program specific operator messages                            *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter a transaction id and press ENTER.'.
           05  WS-M-TRAN-FOUND      PIC X(50)
               VALUE 'Transaction details displayed.'.
           05  WS-M-TRAN-NOTFND     PIC X(50)
               VALUE 'Transaction not found - check the id.'.
           05  WS-M-ID-REQUIRED     PIC X(50)
               VALUE 'Transaction id is required.'.
           05  WS-M-READ-ERROR      PIC X(50)
               VALUE 'Error reading the transaction file.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea      *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  File record layout and BMS symbolic map                       *
      *----------------------------------------------------------------*
       COPY RTRAN.
       COPY MTRANV.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants             *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh empty screen.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MTRANVAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO TRANIDL.
           EXEC CICS SEND
                     MAP('MTRANVA')
                     MAPSET('MTRANV')
                     FROM(MTRANVAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-READ-AND-SHOW
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-READ-AND-SHOW  -  receive the map, validate the key and
      *  drive the read/format/display of the transaction record.      *
      *----------------------------------------------------------------*
       2100-READ-AND-SHOW.
           EXEC CICS RECEIVE
                     MAP('MTRANVA')
                     MAPSET('MTRANV')
                     INTO(MTRANVAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF TRANIDI = SPACES OR TRANIDI = LOW-VALUES
               MOVE WS-M-ID-REQUIRED TO ERRMSGO
               MOVE -1 TO TRANIDL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE TRANIDI TO WS-TRAN-KEY
               INSPECT WS-TRAN-KEY REPLACING ALL LOW-VALUE BY SPACE
               MOVE WS-TRAN-KEY TO TR-ID
               MOVE TR-ID       TO CA-TRAN-ID
               PERFORM 3000-READ-TRAN
               EVALUATE TRUE
                   WHEN REC-FOUND
                       PERFORM 4000-POPULATE-DETAIL
                       MOVE WS-M-TRAN-FOUND TO ERRMSGO
                       MOVE -1 TO TRANIDL
                       PERFORM 8100-SEND-DATAONLY
                   WHEN OTHER
                       MOVE WS-M-TRAN-NOTFND TO ERRMSGO
                       MOVE -1 TO TRANIDL
                       PERFORM 8100-SEND-DATAONLY
               END-EVALUATE
           END-IF.
      *----------------------------------------------------------------*
      *  3000-READ-TRAN  -  read TRANFILE by primary key TR-ID.        *
      *----------------------------------------------------------------*
       3000-READ-TRAN.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   MOVE WS-M-READ-ERROR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-POPULATE-DETAIL  -  move the record fields into the map.
      *  The amount is edited through WS-ED-AMT; the leading pad byte
      *  is dropped so the value fits the fifteen character field.
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE TR-ID            TO TRANIDO.
           MOVE TR-CARD-NUM      TO TRCARDO.
           MOVE TR-TYPE-CD       TO TRTYPEO.
           MOVE TR-AMT           TO WS-ED-AMT.
           MOVE WS-ED-AMT(2:15)  TO TRAMTO.
           MOVE TR-MERCHANT-NAME TO TRMERCHO.
           MOVE TR-DESC          TO TRDESCO.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  re-transmit the map data only.         *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MTRANVA')
                     MAPSET('MTRANV')
                     FROM(MTRANVAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to CICS.         *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
