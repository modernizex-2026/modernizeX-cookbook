      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUABND  -  abnormal-end handler                   *
      *  TYPE    : SUBROUTINE (EXEC CICS LINK from online programs)  *
      *  FUNCTION: build a diagnostic line and issue a CICS ABEND    *
      *            with dump so the failure is captured.             *
      *  CALL    : EXEC CICS LINK PROGRAM('OUABND')                  *
      *                COMMAREA(KABND-PARM) END-EXEC.                *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUABND.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-RESP-CD               PIC S9(09) COMP VALUE ZEROS.
       01  WS-ABEND-MSG             PIC X(120).
       01  WS-ABCODE                PIC X(04) VALUE 'OABN'.
       LINKAGE SECTION.
       COPY KABND.
       PROCEDURE DIVISION USING KABND-PARM.
       0000-MAIN.
           STRING 'ABEND IN ' DELIMITED SIZE
                  KA-PROGRAM    DELIMITED SIZE
                  ' AT '        DELIMITED SIZE
                  KA-PARAGRAPH  DELIMITED SIZE
                  ' - '         DELIMITED SIZE
                  KA-DETAIL     DELIMITED SIZE
                  INTO WS-ABEND-MSG
           END-STRING.
           EXEC CICS WRITEQ TD
                     QUEUE('CSSL')
                     FROM(WS-ABEND-MSG)
                     LENGTH(LENGTH OF WS-ABEND-MSG)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS ABEND
                     ABCODE(WS-ABCODE)
                     RESP(WS-RESP-CD)
           END-EXEC.
           GOBACK.
