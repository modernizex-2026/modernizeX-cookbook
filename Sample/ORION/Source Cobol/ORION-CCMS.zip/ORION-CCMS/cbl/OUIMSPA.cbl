      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUIMSPA -  Pending Authorization DL/I access      *
      *  TYPE    : SUB  (IMS DL/I)                                   *
      *  FUNCTION: read / browse / insert / update / delete the      *
      *            PAUSEG root segment in IMS database OPAUDB using  *
      *            CALL 'CBLTDLI'.  The requested operation and its  *
      *            data travel in the CICS commarea work area        *
      *            (KCOMM / CA-WORK-AREA) laid out as WS-PAU-LINK.   *
      *  DL/I    : GU  by key  = inquire one pending authorization   *
      *            GU  key >   = browse next (key ascending)         *
      *            ISRT        = insert a new pending authorization  *
      *            GHU + REPL  = update the decision / status         *
      *            GHU + DLET  = purge a pending authorization       *
      *  CALL    : EXEC CICS LINK PROGRAM('OUIMSPA')                 *
      *            COMMAREA(ORION-COMMAREA) - the DB-PCB is passed   *
      *            by CICS on the PROCEDURE DIVISION USING list.     *
      *  NOTE    : this is a sub - it ends with GOBACK and issues    *
      *            no EXEC CICS; all database I/O is plain CBLTDLI.  *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUIMSPA.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUIMSPA'.
           05  WS-DLI-FUNC          PIC X(04) VALUE SPACES.
           05  WS-DLI-STATUS        PIC X(02) VALUE SPACES.
           05  WS-CALL-COUNT        PIC 9(04) VALUE ZEROS.
       COPY KDLI.
       COPY RPAUSEG.
      *----------------------------------------------------------------*
      *  Commarea work-area protocol shared with online pgm OCPAUIN.   *
      *  Occupies the first 264 bytes of KCOMM CA-WORK-AREA (X(512)).  *
      *----------------------------------------------------------------*
       01  WS-PAU-LINK.
           05  WS-PL-FUNC           PIC X(04).
               88  PL-INQUIRE                 VALUE 'INQ '.
               88  PL-BROWSE-NEXT             VALUE 'NXT '.
               88  PL-INSERT                  VALUE 'ADD '.
               88  PL-UPDATE                  VALUE 'UPD '.
               88  PL-DELETE                  VALUE 'DEL '.
           05  WS-PL-KEY            PIC X(16).
           05  WS-PL-STATUS         PIC X(02).
               88  PL-OK                      VALUE '  '.
               88  PL-NOTFOUND                VALUE 'GE'.
               88  PL-ENDLIST                 VALUE 'GB'.
               88  PL-DUPLICATE               VALUE 'II'.
               88  PL-BADFUNC                 VALUE 'BF'.
               88  PL-ERROR                   VALUE 'ER'.
           05  WS-PL-MSG            PIC X(40).
           05  WS-PL-DLI-STAT       PIC X(02).
           05  WS-PL-SEGMENT        PIC X(200).
       LINKAGE SECTION.
      *----------------------------------------------------------------*
      *  Live DB-PCB mask passed by CICS.  Same shape as ODLI-PCB-MASK *
      *  documented in copybook KDLI; DL/I posts feedback here.        *
      *----------------------------------------------------------------*
       01  LK-PAU-PCB.
           05  LK-PCB-DBD-NAME      PIC X(08).
           05  LK-PCB-SEG-LEVEL     PIC X(02).
           05  LK-PCB-STATUS        PIC X(02).
           05  LK-PCB-PROC-OPTS     PIC X(04).
           05  LK-PCB-RESERVED      PIC S9(05) COMP.
           05  LK-PCB-SEG-NAME      PIC X(08).
           05  LK-PCB-KFB-LEN       PIC S9(05) COMP.
           05  LK-PCB-SENSEGS       PIC S9(05) COMP.
           05  LK-PCB-KEY-FB        PIC X(16).
       COPY KCOMM.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION USING LK-PAU-PCB ORION-COMMAREA.
       0000-MAIN.
           PERFORM 1000-INITIALIZE.
           PERFORM 1100-VALIDATE-REQUEST.
           IF PL-BADFUNC
               PERFORM 9000-FINALIZE
               GOBACK
           END-IF.
           EVALUATE TRUE
               WHEN PL-INQUIRE
                   PERFORM 2000-INQUIRE
               WHEN PL-BROWSE-NEXT
                   PERFORM 2100-BROWSE-NEXT
               WHEN PL-INSERT
                   PERFORM 2200-INSERT
               WHEN PL-UPDATE
                   PERFORM 2300-UPDATE
               WHEN PL-DELETE
                   PERFORM 2400-DELETE
               WHEN OTHER
                   PERFORM 2900-BAD-FUNCTION
           END-EVALUATE.
           PERFORM 9000-FINALIZE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000 - copy the request out of the commarea and reset state.  *
      *----------------------------------------------------------------*
       1000-INITIALIZE.
           MOVE CA-WORK-AREA        TO WS-PAU-LINK.
           MOVE SPACES              TO WS-PL-STATUS.
           MOVE SPACES              TO WS-PL-MSG.
           MOVE SPACES              TO WS-DLI-STATUS.
           MOVE ZEROS               TO WS-CALL-COUNT.
      *----------------------------------------------------------------*
      *  1100 - basic edit of the requested function and key.  A key   *
      *  is mandatory for every function except an unqualified browse. *
      *----------------------------------------------------------------*
       1100-VALIDATE-REQUEST.
           IF NOT (PL-INQUIRE OR PL-BROWSE-NEXT OR PL-INSERT
                   OR PL-UPDATE OR PL-DELETE)
               MOVE 'BF'            TO WS-PL-STATUS
               MOVE 'Unknown DL/I request function code.'
                                    TO WS-PL-MSG
               GO TO 1100-EXIT
           END-IF.
           IF PL-INQUIRE OR PL-INSERT OR PL-UPDATE OR PL-DELETE
               IF WS-PL-KEY = SPACES OR WS-PL-KEY = LOW-VALUES
                   MOVE 'BF'        TO WS-PL-STATUS
                   MOVE 'Authorization id is required.'
                                    TO WS-PL-MSG
               END-IF
           END-IF.
       1100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2000 - INQUIRE : GU qualified on the key ( = operator ).      *
      *----------------------------------------------------------------*
       2000-INQUIRE.
           MOVE WS-PL-KEY           TO ODLI-SSA-KEYVAL.
           MOVE ODLI-OP-EQ          TO ODLI-SSA-RELOP.
           MOVE ODLI-GU             TO WS-DLI-FUNC.
           PERFORM 5000-CALL-GET-QUAL.
           EVALUATE WS-DLI-STATUS
               WHEN ODLI-ST-OK
                   PERFORM 6000-RETURN-SEGMENT
               WHEN ODLI-ST-NOTFOUND
                   PERFORM 6100-NOT-FOUND
               WHEN OTHER
                   PERFORM 6900-DLI-ERROR
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100 - BROWSE NEXT : textbook DL/I "get next" browse.  With   *
      *  an empty key a bare GN returns the lowest-keyed segment, the  *
      *  start of the list.  With a key, a GU on that key re-positions *
      *  DL/I within this PSB schedule, then GN steps to the next      *
      *  segment in key sequence.  If the anchor key has since been    *
      *  purged, GU repositions at the first segment past it with the  *
      *  greater-than operator and that segment becomes the result.    *
      *----------------------------------------------------------------*
       2100-BROWSE-NEXT.
           IF WS-PL-KEY = SPACES OR WS-PL-KEY = LOW-VALUES
               PERFORM 5400-CALL-GET-NEXT
           ELSE
               PERFORM 2110-POSITION-THEN-NEXT
           END-IF.
           EVALUATE WS-DLI-STATUS
               WHEN ODLI-ST-OK
                   PERFORM 6000-RETURN-SEGMENT
               WHEN ODLI-ST-NOTFOUND
                   PERFORM 6200-END-OF-LIST
               WHEN ODLI-ST-ENDDB
                   PERFORM 6200-END-OF-LIST
               WHEN OTHER
                   PERFORM 6900-DLI-ERROR
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2110 - anchor on the supplied key with GU, then advance with  *
      *  GN.  A GE from the anchor GU means the key is gone, so we     *
      *  reposition at the first higher key instead.                   *
      *----------------------------------------------------------------*
       2110-POSITION-THEN-NEXT.
           MOVE WS-PL-KEY           TO ODLI-SSA-KEYVAL.
           MOVE ODLI-OP-EQ          TO ODLI-SSA-RELOP.
           MOVE ODLI-GU             TO WS-DLI-FUNC.
           PERFORM 5000-CALL-GET-QUAL.
           EVALUATE WS-DLI-STATUS
               WHEN ODLI-ST-OK
                   PERFORM 5400-CALL-GET-NEXT
               WHEN ODLI-ST-NOTFOUND
                   MOVE WS-PL-KEY    TO ODLI-SSA-KEYVAL
                   MOVE ODLI-OP-GT   TO ODLI-SSA-RELOP
                   MOVE ODLI-GU      TO WS-DLI-FUNC
                   PERFORM 5000-CALL-GET-QUAL
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2200 - INSERT : ISRT a new pending authorization.  The full   *
      *  segment image arrives in WS-PL-SEGMENT; the key is forced     *
      *  from WS-PL-KEY and a blank status defaults to 'P' (pending).  *
      *----------------------------------------------------------------*
       2200-INSERT.
           MOVE WS-PL-SEGMENT       TO PAUSEG-REC.
           MOVE WS-PL-KEY           TO PA-AUTH-ID.
           PERFORM 2210-VALIDATE-INSERT.
           IF PL-BADFUNC
               GO TO 2200-EXIT
           END-IF.
           MOVE ODLI-ISRT           TO WS-DLI-FUNC.
           PERFORM 5100-CALL-INSERT.
           EVALUATE WS-DLI-STATUS
               WHEN ODLI-ST-OK
                   MOVE SPACES      TO WS-PL-STATUS
                   MOVE 'Pending authorization inserted.'
                                    TO WS-PL-MSG
                   MOVE PAUSEG-REC  TO WS-PL-SEGMENT
               WHEN ODLI-ST-DUP
                   MOVE 'II'        TO WS-PL-STATUS
                   MOVE 'Authorization id already exists.'
                                    TO WS-PL-MSG
               WHEN OTHER
                   PERFORM 6900-DLI-ERROR
           END-EVALUATE.
       2200-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2210 - edit the new segment before ISRT : the card number is  *
      *  mandatory, the account id must be numeric, and a blank status *
      *  defaults to 'P' (pending) so every root carries a valid flag. *
      *----------------------------------------------------------------*
       2210-VALIDATE-INSERT.
           IF PA-CARD-NUM = SPACES OR PA-CARD-NUM = LOW-VALUES
               MOVE 'BF'            TO WS-PL-STATUS
               MOVE 'Card number is required to insert.'
                                    TO WS-PL-MSG
               GO TO 2210-EXIT
           END-IF.
           IF PA-ACCT-ID NOT NUMERIC
               MOVE 'BF'            TO WS-PL-STATUS
               MOVE 'Account id must be numeric.'
                                    TO WS-PL-MSG
               GO TO 2210-EXIT
           END-IF.
           IF PA-STATUS = SPACE OR PA-STATUS = LOW-VALUE
               MOVE 'P'             TO PA-STATUS
           END-IF.
       2210-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2300 - UPDATE : GHU (get-hold-unique) to lock the segment,    *
      *  overlay it with the new image, then REPL.  The key column is  *
      *  never changed by an update.                                   *
      *----------------------------------------------------------------*
       2300-UPDATE.
           MOVE WS-PL-KEY           TO ODLI-SSA-KEYVAL.
           MOVE ODLI-OP-EQ          TO ODLI-SSA-RELOP.
           MOVE ODLI-GHU            TO WS-DLI-FUNC.
           PERFORM 5000-CALL-GET-QUAL.
           EVALUATE WS-DLI-STATUS
               WHEN ODLI-ST-OK
                   PERFORM 2310-APPLY-REPLACE
               WHEN ODLI-ST-NOTFOUND
                   PERFORM 6100-NOT-FOUND
               WHEN OTHER
                   PERFORM 6900-DLI-ERROR
           END-EVALUATE.
      *----------------------------------------------------------------*
       2310-APPLY-REPLACE.
           MOVE WS-PL-SEGMENT       TO PAUSEG-REC.
           MOVE WS-PL-KEY           TO PA-AUTH-ID.
           MOVE ODLI-REPL           TO WS-DLI-FUNC.
           PERFORM 5200-CALL-REPLACE.
           EVALUATE WS-DLI-STATUS
               WHEN ODLI-ST-OK
                   MOVE SPACES      TO WS-PL-STATUS
                   MOVE 'Pending authorization updated.'
                                    TO WS-PL-MSG
                   MOVE PAUSEG-REC  TO WS-PL-SEGMENT
               WHEN OTHER
                   PERFORM 6900-DLI-ERROR
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2400 - DELETE : GHU to lock, then DLET to purge the segment.  *
      *----------------------------------------------------------------*
       2400-DELETE.
           MOVE WS-PL-KEY           TO ODLI-SSA-KEYVAL.
           MOVE ODLI-OP-EQ          TO ODLI-SSA-RELOP.
           MOVE ODLI-GHU            TO WS-DLI-FUNC.
           PERFORM 5000-CALL-GET-QUAL.
           EVALUATE WS-DLI-STATUS
               WHEN ODLI-ST-OK
                   PERFORM 2410-APPLY-DELETE
               WHEN ODLI-ST-NOTFOUND
                   PERFORM 6100-NOT-FOUND
               WHEN OTHER
                   PERFORM 6900-DLI-ERROR
           END-EVALUATE.
      *----------------------------------------------------------------*
       2410-APPLY-DELETE.
           MOVE ODLI-DLET           TO WS-DLI-FUNC.
           PERFORM 5300-CALL-DELETE.
           EVALUATE WS-DLI-STATUS
               WHEN ODLI-ST-OK
                   MOVE SPACES      TO WS-PL-STATUS
                   MOVE 'Pending authorization purged.'
                                    TO WS-PL-MSG
                   MOVE SPACES      TO WS-PL-SEGMENT
               WHEN OTHER
                   PERFORM 6900-DLI-ERROR
           END-EVALUATE.
      *----------------------------------------------------------------*
       2900-BAD-FUNCTION.
           MOVE 'BF'                TO WS-PL-STATUS.
           MOVE 'Unknown DL/I request function code.'
                                    TO WS-PL-MSG.
      *----------------------------------------------------------------*
      *  5000 - qualified GET (GU or GHU) using the PAUSEG SSA.        *
      *  The IMS status code is captured from the PCB after the call.  *
      *----------------------------------------------------------------*
       5000-CALL-GET-QUAL.
           ADD 1                    TO WS-CALL-COUNT.
           CALL 'CBLTDLI' USING     WS-DLI-FUNC
                                    LK-PAU-PCB
                                    PAUSEG-REC
                                    ODLI-SSA-PAUSEG.
           MOVE LK-PCB-STATUS       TO WS-DLI-STATUS.
      *----------------------------------------------------------------*
      *  5400 - unqualified GN : get the next PAUSEG segment in key    *
      *  sequence from the current DL/I position.                      *
      *----------------------------------------------------------------*
       5400-CALL-GET-NEXT.
           MOVE ODLI-GN             TO WS-DLI-FUNC.
           ADD 1                    TO WS-CALL-COUNT.
           CALL 'CBLTDLI' USING     WS-DLI-FUNC
                                    LK-PAU-PCB
                                    PAUSEG-REC
                                    ODLI-SSA-UNQUAL.
           MOVE LK-PCB-STATUS       TO WS-DLI-STATUS.
      *----------------------------------------------------------------*
      *  5100 - ISRT using the unqualified (segment-name only) SSA.    *
      *----------------------------------------------------------------*
       5100-CALL-INSERT.
           ADD 1                    TO WS-CALL-COUNT.
           CALL 'CBLTDLI' USING     WS-DLI-FUNC
                                    LK-PAU-PCB
                                    PAUSEG-REC
                                    ODLI-SSA-UNQUAL.
           MOVE LK-PCB-STATUS       TO WS-DLI-STATUS.
      *----------------------------------------------------------------*
      *  5200 - REPL after a successful GHU; no SSA on a replace.      *
      *----------------------------------------------------------------*
       5200-CALL-REPLACE.
           ADD 1                    TO WS-CALL-COUNT.
           CALL 'CBLTDLI' USING     WS-DLI-FUNC
                                    LK-PAU-PCB
                                    PAUSEG-REC.
           MOVE LK-PCB-STATUS       TO WS-DLI-STATUS.
      *----------------------------------------------------------------*
      *  5300 - DLET after a successful GHU; no SSA on a delete.       *
      *----------------------------------------------------------------*
       5300-CALL-DELETE.
           ADD 1                    TO WS-CALL-COUNT.
           CALL 'CBLTDLI' USING     WS-DLI-FUNC
                                    LK-PAU-PCB
                                    PAUSEG-REC.
           MOVE LK-PCB-STATUS       TO WS-DLI-STATUS.
      *----------------------------------------------------------------*
      *  6000 - a segment was retrieved : return it to the caller.     *
      *----------------------------------------------------------------*
       6000-RETURN-SEGMENT.
           MOVE PAUSEG-REC          TO WS-PL-SEGMENT.
           MOVE PA-AUTH-ID          TO WS-PL-KEY.
           MOVE SPACES              TO WS-PL-STATUS.
           MOVE 'Pending authorization retrieved.'
                                    TO WS-PL-MSG.
      *----------------------------------------------------------------*
      *  6100 - GE : the requested key is not on the database.         *
      *----------------------------------------------------------------*
       6100-NOT-FOUND.
           MOVE 'GE'                TO WS-PL-STATUS.
           MOVE 'No pending authorization for that id.'
                                    TO WS-PL-MSG.
           MOVE SPACES              TO WS-PL-SEGMENT.
      *----------------------------------------------------------------*
      *  6200 - GE / GB during browse : no more segments to show.      *
      *----------------------------------------------------------------*
       6200-END-OF-LIST.
           MOVE 'GB'                TO WS-PL-STATUS.
           MOVE 'End of pending authorization list.'
                                    TO WS-PL-MSG.
           MOVE SPACES              TO WS-PL-SEGMENT.
      *----------------------------------------------------------------*
      *  6900 - any unexpected DL/I status : log it and flag error.    *
      *----------------------------------------------------------------*
       6900-DLI-ERROR.
           MOVE 'ER'                TO WS-PL-STATUS.
           MOVE SPACES              TO WS-PL-MSG.
           STRING 'DL/I error status=' DELIMITED BY SIZE
                  WS-DLI-STATUS        DELIMITED BY SIZE
                  ' func='             DELIMITED BY SIZE
                  WS-DLI-FUNC          DELIMITED BY SIZE
                  INTO WS-PL-MSG
           END-STRING.
           DISPLAY 'OUIMSPA DL/I ERROR - STATUS=' WS-DLI-STATUS
                   ' FUNC=' WS-DLI-FUNC
                   ' KEY=' WS-PL-KEY.
      *----------------------------------------------------------------*
      *  9000 - post the result back into the commarea and set the     *
      *  shared error flag / message for the online driver program.    *
      *----------------------------------------------------------------*
       9000-FINALIZE.
           MOVE WS-DLI-STATUS       TO WS-PL-DLI-STAT.
           IF WS-PL-STATUS = ODLI-ST-OK
               SET CA-ERR-OFF       TO TRUE
               MOVE SPACES          TO CA-ERR-MSG
           ELSE
               SET CA-ERR-ON        TO TRUE
               MOVE WS-PL-MSG       TO CA-ERR-MSG
           END-IF.
           MOVE WS-PAU-LINK         TO CA-WORK-AREA.
