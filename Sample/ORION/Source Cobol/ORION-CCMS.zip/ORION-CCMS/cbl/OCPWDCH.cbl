      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCPWDCH  -  Password Change (on-line)             *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: verify the current password against USRSEC and    *
      *            store a new one (with confirmation).              *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCPWDCH.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCPWDCH'.
           05  WS-TRANID            PIC X(04) VALUE 'ORPW'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RUSER.
       COPY MPWDCH.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           IF EIBCALEN = 0
               EXEC CICS XCTL PROGRAM(WS-MENU-PGM)
                         RESP(WS-RESP-CD) END-EXEC
           END-IF.
           MOVE DFHCOMMAREA TO ORION-COMMAREA.
           IF CA-FIRST-ENTER
               PERFORM 1000-SEND-INITIAL
           ELSE
               PERFORM 2000-PROCESS-INPUT
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MPWDCHAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter user id, old and new password.' TO ERRMSGO.
           EXEC CICS SEND MAP('MPWDCHA') MAPSET('MPWDCH')
                     FROM(MPWDCHAO) ERASE RESP(WS-RESP-CD) END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   MOVE 0 TO CA-PGM-CONTEXT
                   EXEC CICS XCTL PROGRAM(WS-MENU-PGM)
                             COMMAREA(ORION-COMMAREA)
                             RESP(WS-RESP-CD) END-EXEC
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-CHANGE-PWD
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
       2100-CHANGE-PWD.
           EXEC CICS RECEIVE MAP('MPWDCHA') MAPSET('MPWDCH')
                     INTO(MPWDCHAI) RESP(WS-RESP-CD) END-EXEC.
           IF USERIDI = SPACES OR USERIDI = LOW-VALUES
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               IF NEWPWDI NOT = CFMPWDI
                   MOVE 'New password and confirm do not match.'
                        TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE USERIDI TO US-ID
                   PERFORM 3000-READ-USER
                   IF REC-NOT-FOUND
                       MOVE WS-MSG-NOTFND TO ERRMSGO
                       PERFORM 8100-SEND-DATAONLY
                   ELSE
                       IF US-PASSWORD NOT = OLDPWDI
                           MOVE 'Current password is incorrect.'
                                TO ERRMSGO
                           PERFORM 8100-SEND-DATAONLY
                       ELSE
                           PERFORM 4000-UPDATE-PWD
                       END-IF
                   END-IF
               END-IF
           END-IF.
      *----------------------------------------------------------------*
       3000-READ-USER.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ FILE(WS-USRSEC) INTO(USER-REC)
                     RIDFLD(US-ID) UPDATE RESP(WS-RESP-CD) END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               SET REC-FOUND TO TRUE
           END-IF.
      *----------------------------------------------------------------*
       4000-UPDATE-PWD.
           MOVE NEWPWDI TO US-PASSWORD.
           EXEC CICS REWRITE FILE(WS-USRSEC) FROM(USER-REC)
                     RESP(WS-RESP-CD) END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               MOVE 'Password changed successfully.' TO ERRMSGO
           ELSE
               MOVE 'Password change failed.' TO ERRMSGO
           END-IF.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           EXEC CICS ASKTIME ABSTIME(WS-AMT) RESP(WS-RESP-CD) END-EXEC.
           EXEC CICS FORMATTIME ABSTIME(WS-AMT) DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME) TIMESEP(':')
                     RESP(WS-RESP-CD) END-EXEC.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND MAP('MPWDCHA') MAPSET('MPWDCH')
                     FROM(MPWDCHAO) DATAONLY RESP(WS-RESP-CD) END-EXEC.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA) RESP(WS-RESP-CD) END-EXEC.
