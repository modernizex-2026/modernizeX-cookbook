      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUPOST  -  Daily transaction posting SUB          *
      *  TYPE    : SUB  (CICS file control)                          *
      *  FUNCTION: apply transactions to account balances on demand. *
      *            Browses the transaction store (TRANFILE) with     *
      *            STARTBR / READNEXT / ENDBR.  For each transaction *
      *            it resolves the card to its owning account through *
      *            the card cross-reference (XREFFILE), READs that    *
      *            account for UPDATE, classifies the transaction as  *
      *            a credit (type PY / CR) or a debit, enforces the   *
      *            credit limit on debits, applies the amount to the  *
      *            balance and the cycle credit / debit buckets and   *
      *            REWRITEs the account.  Counts are returned in the  *
      *            KOPS commarea.  Ports the batch posters OBTRANP    *
      *            (VSAM) and ODTRANP (DB2) into one online engine.   *
      *  CALL    : EXEC CICS LINK PROGRAM('OUPOST')                   *
      *                COMMAREA(ORION-COMMAREA) END-EXEC.             *
      *  RESULT  : KO-READ  trans read      KO-SELECT selected        *
      *            KO-POSTED posted         KO-UPDATE accts rewritten *
      *            KO-REJECT rejected       KO-C1 no-xref             *
      *            KO-C2 no-account         KO-C3 over-limit          *
      *            KO-AMT-1 debit total     KO-AMT-2 credit total     *
      *            KO-AMT-3 net (debit-credit).                       *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUPOST.
       AUTHOR.     ORION-CCMS-ONLINE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and posting constants.                       *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUPOST'.
           05  WS-CR-TYPE-1         PIC X(02) VALUE 'PY'.
           05  WS-CR-TYPE-2         PIC X(02) VALUE 'CR'.
      *----------------------------------------------------------------*
      *  Browse and per-record control switches.                       *
      *----------------------------------------------------------------*
       01  WS-FLAGS.
           05  WS-BR-END-SW         PIC X(01) VALUE 'N'.
               88  BR-END                     VALUE 'Y'.
               88  BR-MORE                    VALUE 'N'.
           05  WS-BR-STARTED-SW     PIC X(01) VALUE 'N'.
               88  BR-STARTED                 VALUE 'Y'.
               88  BR-NOT-STARTED             VALUE 'N'.
           05  WS-REJECT-SW         PIC X(01) VALUE 'N'.
               88  REJECTED                   VALUE 'Y'.
               88  NOT-REJECTED               VALUE 'N'.
           05  WS-DC-IND            PIC X(02) VALUE SPACES.
               88  WS-IS-CREDIT               VALUE 'CR'.
               88  WS-IS-DEBIT                VALUE 'DB'.
      *----------------------------------------------------------------*
      *  Arithmetic and filter work fields.                            *
      *----------------------------------------------------------------*
       01  WS-CALC.
           05  WS-PROJ-BAL          PIC S9(11)V99 VALUE ZEROS.
           05  WS-FILTER-ACCT       PIC 9(11)     VALUE ZEROS.
           05  WS-FILTER-ON         PIC X(01)     VALUE 'N'.
               88  FILTER-ACTIVE              VALUE 'Y'.
      *----------------------------------------------------------------*
      *  Shared constants / file names and the record layouts.         *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RTRAN.
       COPY RXREF.
       COPY RACCT.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KOPS.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN : overlay the request area, run the browse, return. *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KOPS-AREA TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INITIALISE.
           PERFORM 3000-BROWSE-DRIVER.
           PERFORM 9000-FINALISE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INITIALISE : clear the result half of the commarea.      *
      *----------------------------------------------------------------*
       1000-INITIALISE.
           SET KO-OK TO TRUE.
           MOVE SPACES TO KO-STATUS-MSG.
           MOVE ZEROS TO KO-READ-CNT.
           MOVE ZEROS TO KO-SELECT-CNT.
           MOVE ZEROS TO KO-UPDATE-CNT.
           MOVE ZEROS TO KO-POSTED-CNT.
           MOVE ZEROS TO KO-REJECT-CNT.
           MOVE ZEROS TO KO-SKIP-CNT.
           MOVE ZEROS TO KO-TRAN-CNT.
           MOVE ZEROS TO KO-C1.
           MOVE ZEROS TO KO-C2.
           MOVE ZEROS TO KO-C3.
           MOVE ZEROS TO KO-AMT-1.
           MOVE ZEROS TO KO-AMT-2.
           MOVE ZEROS TO KO-AMT-3.
           MOVE 'N' TO WS-FILTER-ON.
           IF KO-PARM-ACCT > ZERO
               MOVE KO-PARM-ACCT TO WS-FILTER-ACCT
               SET FILTER-ACTIVE TO TRUE
           END-IF.
           SET BR-MORE TO TRUE.
           SET BR-NOT-STARTED TO TRUE.
      *----------------------------------------------------------------*
      *  3000-BROWSE-DRIVER : position at the top of TRANFILE, read    *
      *  every transaction forward and post it, then release browse.   *
      *----------------------------------------------------------------*
       3000-BROWSE-DRIVER.
           PERFORM 3100-START-BROWSE.
           IF BR-STARTED
               PERFORM 3200-READ-NEXT-TRAN
               PERFORM 4000-PROCESS-TRAN
                   UNTIL BR-END OR KO-ERROR
               PERFORM 3400-END-BROWSE
           END-IF.
      *----------------------------------------------------------------*
      *  3100-START-BROWSE : STARTBR TRANFILE at low key.              *
      *----------------------------------------------------------------*
       3100-START-BROWSE.
           MOVE LOW-VALUES TO TR-ID.
           EXEC CICS STARTBR
                     FILE(WS-TRANFILE)
                     RIDFLD(TR-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BR-STARTED TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET BR-END TO TRUE
                   MOVE 'NO TRANSACTIONS ON FILE TO POST.'
                       TO KO-STATUS-MSG
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'STARTBR TRANFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-READ-NEXT-TRAN : read one transaction record forward.    *
      *----------------------------------------------------------------*
       3200-READ-NEXT-TRAN.
           EXEC CICS READNEXT
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KO-READ-CNT
               WHEN DFHRESP(ENDFILE)
                   SET BR-END TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'READNEXT TRANFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-PROCESS-TRAN : resolve, classify and post one tran.      *
      *----------------------------------------------------------------*
       4000-PROCESS-TRAN.
           SET NOT-REJECTED TO TRUE.
           MOVE SPACES TO WS-DC-IND.
           IF TR-CARD-NUM = SPACES OR TR-CARD-NUM = LOW-VALUES
               ADD 1 TO KO-REJECT-CNT
               ADD 1 TO KO-C1
           ELSE
               PERFORM 4100-READ-XREF
           END-IF.
           PERFORM 3200-READ-NEXT-TRAN.
      *----------------------------------------------------------------*
      *  4100-READ-XREF : map the card number to its account id.       *
      *----------------------------------------------------------------*
       4100-READ-XREF.
           MOVE TR-CARD-NUM TO XR-CARD-NUM.
           EXEC CICS READ
                     FILE(WS-XREFFILE)
                     INTO(XREF-REC)
                     RIDFLD(XR-CARD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   PERFORM 4150-CHECK-FILTER
               WHEN DFHRESP(NOTFND)
                   ADD 1 TO KO-REJECT-CNT
                   ADD 1 TO KO-C1
               WHEN OTHER
                   ADD 1 TO KO-REJECT-CNT
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4150-CHECK-FILTER : honour an optional single-account filter. *
      *----------------------------------------------------------------*
       4150-CHECK-FILTER.
           IF FILTER-ACTIVE AND XR-ACCT-ID NOT = WS-FILTER-ACCT
               CONTINUE
           ELSE
               ADD 1 TO KO-SELECT-CNT
               PERFORM 4200-READ-ACCT-UPD
           END-IF.
      *----------------------------------------------------------------*
      *  4200-READ-ACCT-UPD : READ the owning account for UPDATE.      *
      *----------------------------------------------------------------*
       4200-READ-ACCT-UPD.
           MOVE XR-ACCT-ID TO AC-ID.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   PERFORM 4300-CLASSIFY
               WHEN DFHRESP(NOTFND)
                   ADD 1 TO KO-REJECT-CNT
                   ADD 1 TO KO-C2
               WHEN OTHER
                   ADD 1 TO KO-REJECT-CNT
                   PERFORM 4250-UNLOCK
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4250-UNLOCK : release an account held for update on error.    *
      *----------------------------------------------------------------*
       4250-UNLOCK.
           EXEC CICS UNLOCK
                     FILE(WS-ACCTFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  4300-CLASSIFY : decide credit vs debit; guard the limit.      *
      *  Type PY / CR is a credit (lowers what is owed); anything      *
      *  else is a debit that may not breach the credit limit.         *
      *----------------------------------------------------------------*
       4300-CLASSIFY.
           EVALUATE TR-TYPE-CD
               WHEN WS-CR-TYPE-1
               WHEN WS-CR-TYPE-2
                   SET WS-IS-CREDIT TO TRUE
                   PERFORM 4400-APPLY-UPDATE
               WHEN OTHER
                   SET WS-IS-DEBIT TO TRUE
                   COMPUTE WS-PROJ-BAL = AC-CURR-BAL + TR-AMT
                   IF WS-PROJ-BAL > AC-CREDIT-LIMIT
                       ADD 1 TO KO-REJECT-CNT
                       ADD 1 TO KO-C3
                       PERFORM 4250-UNLOCK
                   ELSE
                       PERFORM 4400-APPLY-UPDATE
                   END-IF
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4400-APPLY-UPDATE : apply the amount and REWRITE the account. *
      *----------------------------------------------------------------*
       4400-APPLY-UPDATE.
           IF WS-IS-CREDIT
               SUBTRACT TR-AMT FROM AC-CURR-BAL
               ADD TR-AMT TO AC-CYC-CREDIT
           ELSE
               ADD TR-AMT TO AC-CURR-BAL
               ADD TR-AMT TO AC-CYC-DEBIT
           END-IF.
           EXEC CICS REWRITE
                     FILE(WS-ACCTFILE)
                     FROM(ACCT-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KO-POSTED-CNT
               ADD 1 TO KO-UPDATE-CNT
               IF WS-IS-CREDIT
                   ADD TR-AMT TO KO-AMT-2
               ELSE
                   ADD TR-AMT TO KO-AMT-1
               END-IF
           ELSE
               ADD 1 TO KO-REJECT-CNT
           END-IF.
      *----------------------------------------------------------------*
      *  3400-END-BROWSE : release the transaction browse.             *
      *----------------------------------------------------------------*
       3400-END-BROWSE.
           IF BR-STARTED
               EXEC CICS ENDBR
                         FILE(WS-TRANFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
      *----------------------------------------------------------------*
      *  9000-FINALISE : compute the net and set the status message.   *
      *----------------------------------------------------------------*
       9000-FINALISE.
           COMPUTE KO-AMT-3 = KO-AMT-1 - KO-AMT-2.
           IF KO-ERROR
               CONTINUE
           ELSE
               IF KO-REJECT-CNT > 0
                   SET KO-WARN TO TRUE
               ELSE
                   SET KO-OK TO TRUE
               END-IF
               MOVE 'TRANSACTION POSTING COMPLETE.' TO KO-STATUS-MSG
           END-IF.
