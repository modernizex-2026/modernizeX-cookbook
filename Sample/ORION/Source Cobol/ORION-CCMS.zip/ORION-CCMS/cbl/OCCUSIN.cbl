      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCCUSIN  -  Customer Inquiry (on-line)            *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: one consolidated customer look-up screen that     *
      *            replaces three batch listings.  The operator      *
      *            chooses a filter mode and keys its arguments:      *
      *              I = customer-id range   (was OBCUSTP)            *
      *              F = FICO score band     (was OBRSCORE)           *
      *              S = state + ZIP prefix  (was OBRZIP)             *
      *            OCCUSIN LINKs the browse engine OUCUSIN which      *
      *            scans CUSTFILE, returns one page of matching       *
      *            customers plus the filter-wide match count and     *
      *            average FICO, and drives paging.                   *
      *  KEYS    : ENTER = apply filter (first page)                  *
      *            PF8   = next page      PF7 = restart at top        *
      *            PF3   = back to menu                               *
      *  MAPSET  : MCUSIN      MAP : MCUSINA     TRANID : ORQC        *
      *  LINK    : OUCUSIN via COMMAREA(KCUSIN-AREA)                  *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - consolidated customer inquiry. *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCCUSIN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCCUSIN'.
           05  WS-TRANID            PIC X(04) VALUE 'ORQC'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
           05  WS-SUB-PGM           PIC X(08) VALUE 'OUCUSIN'.
      *----------------------------------------------------------------*
      *  Local work fields.                                            *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-ROW-IDX           PIC 9(02) VALUE ZEROS.
           05  WS-MODE              PIC X(01) VALUE SPACES.
           05  WS-CNT-ED            PIC ZZZZZZZ9.
           05  WS-FICO-ED           PIC ZZ9.
           05  WS-FICO-MIN-ED       PIC ZZ9.
           05  WS-FICO-MAX-ED       PIC ZZ9.
           05  WS-MSG-LINE          PIC X(78) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Validation switch used by the numeric parser.                 *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Reusable numeric-field parser work area.                      *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(09) VALUE SPACES.
           05  WS-NC-LEN            PIC 9(02) VALUE ZEROS.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(09) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Choose filter mode I/F/S, key args, press ENTER.'.
           05  WS-M-BAD-MODE        PIC X(50)
               VALUE 'Mode must be I (id) F (fico) or S (state/zip).'.
           05  WS-M-BAD-NUM         PIC X(50)
               VALUE 'Numeric filter argument is not valid.'.
           05  WS-M-STATE-REQ       PIC X(50)
               VALUE 'State is required for the state/zip filter.'.
           05  WS-M-NONE-FOUND      PIC X(50)
               VALUE 'No customers match the filter.'.
           05  WS-M-END-LIST        PIC X(50)
               VALUE 'End of list - no more customers.'.
           05  WS-M-LINK-ERR        PIC X(50)
               VALUE 'Unable to link to browse engine OUCUSIN.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  Browse LINK interface and BMS symbolic map.                   *
      *----------------------------------------------------------------*
       COPY KCUSIN.
       COPY MCUSIN.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh empty screen.*
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MCUSINAO.
           PERFORM 8000-POPULATE-HEADER.
           PERFORM 4100-CLEAR-ROWS.
           INITIALIZE KCUSIN-AREA.
           SET KUI-F-IDRANGE TO TRUE.
           MOVE KUI-REQUEST TO CA-WORK-AREA.
           MOVE 'I' TO FMODEO.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO FMODEL.
           EXEC CICS SEND
                     MAP('MCUSINA')
                     MAPSET('MCUSIN')
                     FROM(MCUSINAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF7
                   PERFORM 2300-RESTART
               WHEN DFHPF8
                   PERFORM 2200-PAGE-NEXT
               WHEN DFHENTER
                   PERFORM 2100-APPLY-FILTER
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-APPLY-FILTER  -  ENTER : read the filter arguments from  *
      *  the map, validate them and list the first page.               *
      *----------------------------------------------------------------*
       2100-APPLY-FILTER.
           EXEC CICS RECEIVE
                     MAP('MCUSINA')
                     MAPSET('MCUSIN')
                     INTO(MCUSINAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MCUSINAI
           END-IF.
           PERFORM 5000-PARSE-FILTER.
           IF WS-INVALID
               MOVE -1 TO FMODEL
               PERFORM 8100-SEND-DATAONLY
               GO TO 2100-EXIT
           END-IF.
           MOVE ZEROS TO KUI-START-KEY.
           PERFORM 3000-CALL-SUB.
           PERFORM 4000-SHOW-PAGE.
       2100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2200-PAGE-NEXT  -  PF8 : resume the browse at the saved key.  *
      *----------------------------------------------------------------*
       2200-PAGE-NEXT.
           MOVE CA-WORK-AREA TO KUI-REQUEST.
           PERFORM 3000-CALL-SUB.
           IF KUI-ROW-COUNT = ZEROS
               MOVE WS-M-END-LIST TO ERRMSGO
               MOVE -1 TO FMODEL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 4000-SHOW-PAGE
           END-IF.
      *----------------------------------------------------------------*
      *  2300-RESTART  -  PF7 : list the first page again for the same *
      *  filter, resetting the paging cursor to the top.              *
      *----------------------------------------------------------------*
       2300-RESTART.
           MOVE CA-WORK-AREA TO KUI-REQUEST.
           MOVE ZEROS TO KUI-START-KEY.
           PERFORM 3000-CALL-SUB.
           PERFORM 4000-SHOW-PAGE.
      *----------------------------------------------------------------*
      *  3000-CALL-SUB  -  LINK the browse engine and advance / save   *
      *  the paging cursor into the commarea for the next turn.        *
      *----------------------------------------------------------------*
       3000-CALL-SUB.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-SUB-PGM TO CA-TO-PROGRAM.
           EXEC CICS LINK
                     PROGRAM(WS-SUB-PGM)
                     COMMAREA(KCUSIN-AREA)
                     LENGTH(LENGTH OF KCUSIN-AREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               SET KUI-ERROR TO TRUE
               MOVE WS-M-LINK-ERR TO CA-ERR-MSG
           END-IF.
           IF KUI-ROW-COUNT > ZEROS
               MOVE KUI-NEXT-KEY TO KUI-START-KEY
           END-IF.
           MOVE KUI-REQUEST TO CA-WORK-AREA.
      *----------------------------------------------------------------*
      *  4000-SHOW-PAGE  -  paint the returned rows and the summary.   *
      *----------------------------------------------------------------*
       4000-SHOW-PAGE.
           PERFORM 4100-CLEAR-ROWS.
           IF KUI-ERROR
               MOVE CA-ERR-MSG TO ERRMSGO
               MOVE -1 TO FMODEL
               PERFORM 8100-SEND-DATAONLY
               GO TO 4000-EXIT
           END-IF.
           IF KUI-ROW-COUNT = ZEROS
               MOVE WS-M-NONE-FOUND TO ERRMSGO
           ELSE
               PERFORM VARYING WS-ROW-IDX FROM 1 BY 1
                       UNTIL WS-ROW-IDX > KUI-ROW-COUNT
                   PERFORM 4200-PLACE-ROW
               END-PERFORM
               PERFORM 4300-BUILD-SUMMARY
               MOVE WS-MSG-LINE TO ERRMSGO
           END-IF.
           MOVE -1 TO FMODEL.
           PERFORM 8100-SEND-DATAONLY.
       4000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  4100-CLEAR-ROWS  -  blank the thirteen display lines.         *
      *----------------------------------------------------------------*
       4100-CLEAR-ROWS.
           MOVE SPACES TO CUL1O CUN1O CST1O CZP1O CFI1O.
           MOVE SPACES TO CUL2O CUN2O CST2O CZP2O CFI2O.
           MOVE SPACES TO CUL3O CUN3O CST3O CZP3O CFI3O.
           MOVE SPACES TO CUL4O CUN4O CST4O CZP4O CFI4O.
           MOVE SPACES TO CUL5O CUN5O CST5O CZP5O CFI5O.
           MOVE SPACES TO CUL6O CUN6O CST6O CZP6O CFI6O.
           MOVE SPACES TO CUL7O CUN7O CST7O CZP7O CFI7O.
           MOVE SPACES TO CUL8O CUN8O CST8O CZP8O CFI8O.
           MOVE SPACES TO CUL9O CUN9O CST9O CZP9O CFI9O.
           MOVE SPACES TO CUL10O CUN10O CST10O CZP10O CFI10O.
           MOVE SPACES TO CUL11O CUN11O CST11O CZP11O CFI11O.
           MOVE SPACES TO CUL12O CUN12O CST12O CZP12O CFI12O.
           MOVE SPACES TO CUL13O CUN13O CST13O CZP13O CFI13O.
      *----------------------------------------------------------------*
      *  4200-PLACE-ROW  -  move one returned row into its map line.   *
      *----------------------------------------------------------------*
       4200-PLACE-ROW.
           EVALUATE WS-ROW-IDX
               WHEN 1
                   MOVE KUR-ID (1)    TO CUL1O
                   MOVE KUR-NAME (1)  TO CUN1O
                   MOVE KUR-STATE (1) TO CST1O
                   MOVE KUR-ZIP (1)   TO CZP1O
                   MOVE KUR-FICO (1)  TO CFI1O
               WHEN 2
                   MOVE KUR-ID (2)    TO CUL2O
                   MOVE KUR-NAME (2)  TO CUN2O
                   MOVE KUR-STATE (2) TO CST2O
                   MOVE KUR-ZIP (2)   TO CZP2O
                   MOVE KUR-FICO (2)  TO CFI2O
               WHEN 3
                   MOVE KUR-ID (3)    TO CUL3O
                   MOVE KUR-NAME (3)  TO CUN3O
                   MOVE KUR-STATE (3) TO CST3O
                   MOVE KUR-ZIP (3)   TO CZP3O
                   MOVE KUR-FICO (3)  TO CFI3O
               WHEN 4
                   MOVE KUR-ID (4)    TO CUL4O
                   MOVE KUR-NAME (4)  TO CUN4O
                   MOVE KUR-STATE (4) TO CST4O
                   MOVE KUR-ZIP (4)   TO CZP4O
                   MOVE KUR-FICO (4)  TO CFI4O
               WHEN 5
                   MOVE KUR-ID (5)    TO CUL5O
                   MOVE KUR-NAME (5)  TO CUN5O
                   MOVE KUR-STATE (5) TO CST5O
                   MOVE KUR-ZIP (5)   TO CZP5O
                   MOVE KUR-FICO (5)  TO CFI5O
               WHEN 6
                   MOVE KUR-ID (6)    TO CUL6O
                   MOVE KUR-NAME (6)  TO CUN6O
                   MOVE KUR-STATE (6) TO CST6O
                   MOVE KUR-ZIP (6)   TO CZP6O
                   MOVE KUR-FICO (6)  TO CFI6O
               WHEN 7
                   MOVE KUR-ID (7)    TO CUL7O
                   MOVE KUR-NAME (7)  TO CUN7O
                   MOVE KUR-STATE (7) TO CST7O
                   MOVE KUR-ZIP (7)   TO CZP7O
                   MOVE KUR-FICO (7)  TO CFI7O
               WHEN 8
                   MOVE KUR-ID (8)    TO CUL8O
                   MOVE KUR-NAME (8)  TO CUN8O
                   MOVE KUR-STATE (8) TO CST8O
                   MOVE KUR-ZIP (8)   TO CZP8O
                   MOVE KUR-FICO (8)  TO CFI8O
               WHEN 9
                   MOVE KUR-ID (9)    TO CUL9O
                   MOVE KUR-NAME (9)  TO CUN9O
                   MOVE KUR-STATE (9) TO CST9O
                   MOVE KUR-ZIP (9)   TO CZP9O
                   MOVE KUR-FICO (9)  TO CFI9O
               WHEN 10
                   MOVE KUR-ID (10)   TO CUL10O
                   MOVE KUR-NAME (10) TO CUN10O
                   MOVE KUR-STATE (10) TO CST10O
                   MOVE KUR-ZIP (10)  TO CZP10O
                   MOVE KUR-FICO (10) TO CFI10O
               WHEN 11
                   MOVE KUR-ID (11)   TO CUL11O
                   MOVE KUR-NAME (11) TO CUN11O
                   MOVE KUR-STATE (11) TO CST11O
                   MOVE KUR-ZIP (11)  TO CZP11O
                   MOVE KUR-FICO (11) TO CFI11O
               WHEN 12
                   MOVE KUR-ID (12)   TO CUL12O
                   MOVE KUR-NAME (12) TO CUN12O
                   MOVE KUR-STATE (12) TO CST12O
                   MOVE KUR-ZIP (12)  TO CZP12O
                   MOVE KUR-FICO (12) TO CFI12O
               WHEN 13
                   MOVE KUR-ID (13)   TO CUL13O
                   MOVE KUR-NAME (13) TO CUN13O
                   MOVE KUR-STATE (13) TO CST13O
                   MOVE KUR-ZIP (13)  TO CZP13O
                   MOVE KUR-FICO (13) TO CFI13O
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4300-BUILD-SUMMARY  -  compose the summary / paging message.  *
      *----------------------------------------------------------------*
       4300-BUILD-SUMMARY.
           MOVE KUI-MATCH-COUNT TO WS-CNT-ED.
           MOVE KUI-FICO-MIN    TO WS-FICO-MIN-ED.
           MOVE KUI-FICO-AVG    TO WS-FICO-ED.
           MOVE KUI-FICO-MAX    TO WS-FICO-MAX-ED.
           MOVE SPACES TO WS-MSG-LINE.
           IF KUI-MORE
               STRING WS-CNT-ED       DELIMITED BY SIZE
                      ' match, FICO min/avg/max ' DELIMITED BY SIZE
                      WS-FICO-MIN-ED  DELIMITED BY SIZE
                      '/'             DELIMITED BY SIZE
                      WS-FICO-ED      DELIMITED BY SIZE
                      '/'             DELIMITED BY SIZE
                      WS-FICO-MAX-ED  DELIMITED BY SIZE
                      '  PF8=more PF7=top' DELIMITED BY SIZE
                      INTO WS-MSG-LINE
               END-STRING
           ELSE
               STRING WS-CNT-ED       DELIMITED BY SIZE
                      ' match, FICO min/avg/max ' DELIMITED BY SIZE
                      WS-FICO-MIN-ED  DELIMITED BY SIZE
                      '/'             DELIMITED BY SIZE
                      WS-FICO-ED      DELIMITED BY SIZE
                      '/'             DELIMITED BY SIZE
                      WS-FICO-MAX-ED  DELIMITED BY SIZE
                      '  End of list.' DELIMITED BY SIZE
                      INTO WS-MSG-LINE
               END-STRING
           END-IF.
      *----------------------------------------------------------------*
      *  5000-PARSE-FILTER  -  translate the map filter fields into    *
      *  the KCUSIN request half; set WS-INVALID on any bad argument.  *
      *----------------------------------------------------------------*
       5000-PARSE-FILTER.
           SET WS-VALID TO TRUE.
           MOVE FMODEI TO WS-MODE.
           INSPECT WS-MODE REPLACING ALL LOW-VALUE BY SPACE.
           INITIALIZE KUI-REQUEST.
           EVALUATE WS-MODE
               WHEN 'I'
                   PERFORM 5100-PARSE-IDRANGE
               WHEN 'F'
                   PERFORM 5200-PARSE-FICO
               WHEN 'S'
                   PERFORM 5300-PARSE-STZIP
               WHEN OTHER
                   MOVE WS-M-BAD-MODE TO ERRMSGO
                   SET WS-INVALID TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  5100-PARSE-IDRANGE  -  customer-id low / high bounds.         *
      *----------------------------------------------------------------*
       5100-PARSE-IDRANGE.
           SET KUI-F-IDRANGE TO TRUE.
           MOVE ZEROS TO KUI-ID-FROM.
           MOVE 999999999 TO KUI-ID-TO.
           MOVE FRIDI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN NOT = SPACES
               MOVE 9 TO WS-NC-LEN
               PERFORM 6000-PARSE-NUM
               IF WS-INVALID
                   MOVE WS-M-BAD-NUM TO ERRMSGO
                   GO TO 5100-EXIT
               END-IF
               MOVE WS-NC-VALUE TO KUI-ID-FROM
           END-IF.
           MOVE TOIDI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN NOT = SPACES
               MOVE 9 TO WS-NC-LEN
               PERFORM 6000-PARSE-NUM
               IF WS-INVALID
                   MOVE WS-M-BAD-NUM TO ERRMSGO
                   GO TO 5100-EXIT
               END-IF
               MOVE WS-NC-VALUE TO KUI-ID-TO
           END-IF.
       5100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5200-PARSE-FICO  -  FICO band low / high bounds.              *
      *----------------------------------------------------------------*
       5200-PARSE-FICO.
           SET KUI-F-FICO TO TRUE.
           MOVE ZEROS TO KUI-FICO-FROM.
           MOVE 999 TO KUI-FICO-TO.
           MOVE FRFICOI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN NOT = SPACES
               MOVE 3 TO WS-NC-LEN
               PERFORM 6000-PARSE-NUM
               IF WS-INVALID
                   MOVE WS-M-BAD-NUM TO ERRMSGO
                   GO TO 5200-EXIT
               END-IF
               MOVE WS-NC-VALUE TO KUI-FICO-FROM
           END-IF.
           MOVE TOFICOI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN NOT = SPACES
               MOVE 3 TO WS-NC-LEN
               PERFORM 6000-PARSE-NUM
               IF WS-INVALID
                   MOVE WS-M-BAD-NUM TO ERRMSGO
                   GO TO 5200-EXIT
               END-IF
               MOVE WS-NC-VALUE TO KUI-FICO-TO
           END-IF.
       5200-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5300-PARSE-STZIP  -  state (required) and optional ZIP prefix.*
      *----------------------------------------------------------------*
       5300-PARSE-STZIP.
           SET KUI-F-STZIP TO TRUE.
           MOVE FSTATEI TO KUI-STATE.
           INSPECT KUI-STATE REPLACING ALL LOW-VALUE BY SPACE.
           MOVE FZIPI TO KUI-ZIP.
           INSPECT KUI-ZIP REPLACING ALL LOW-VALUE BY SPACE.
           IF KUI-STATE = SPACES
               MOVE WS-M-STATE-REQ TO ERRMSGO
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  6000-PARSE-NUM  -  scan WS-NC-IN for WS-NC-LEN characters,    *
      *  ignore spaces, accumulate digits into WS-NC-VALUE.  Any other *
      *  character makes the field invalid.                            *
      *----------------------------------------------------------------*
       6000-PARSE-NUM.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > WS-NC-LEN
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.*
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  re-transmit the map data only.         *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MCUSINA')
                     MAPSET('MCUSIN')
                     FROM(MCUSINAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to CICS.         *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
