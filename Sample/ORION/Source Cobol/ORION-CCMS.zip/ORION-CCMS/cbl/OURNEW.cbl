      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OURNEW  -  Card renewal / reissue SUB             *
      *  TYPE    : SUB  (CICS file control)                          *
      *  FUNCTION: reissue cards approaching expiry on demand.       *
      *            Browses the card master (CARDFILE); an active card *
      *            whose expiry date is valid and falls on or before  *
      *            a lead-time cutoff (run date + 90 days) is         *
      *            reissued: the expiry year is extended by three     *
      *            years, a Feb-29 expiry landing on a non-leap year  *
      *            is clamped to Feb-28, the card is READ for UPDATE   *
      *            and REWRITTEN.  Ports the batch renewer OBRENEW,    *
      *            keeping its leap-year normalisation intact.        *
      *  CALL    : EXEC CICS LINK PROGRAM('OURNEW')                   *
      *                COMMAREA(ORION-COMMAREA) END-EXEC.             *
      *  REQUEST : KO-PARM-CARD optional single card (spaces = all).  *
      *  RESULT  : KO-READ cards read    KO-POSTED reissued           *
      *            KO-UPDATE rewritten   KO-C1 not due                *
      *            KO-C2 inactive        KO-C3 bad expiry date.       *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OURNEW.
       AUTHOR.     ORION-CCMS-ONLINE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and renewal parameters.                      *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OURNEW'.
           05  WS-LEAD-DAYS         PIC 9(05) VALUE 90.
           05  WS-EXTEND-YEARS      PIC 9(02) VALUE 3.
      *----------------------------------------------------------------*
      *  Browse and validation switches.                               *
      *----------------------------------------------------------------*
       01  WS-FLAGS.
           05  WS-BR-END-SW         PIC X(01) VALUE 'N'.
               88  BR-END                     VALUE 'Y'.
               88  BR-MORE                    VALUE 'N'.
           05  WS-BR-STARTED-SW     PIC X(01) VALUE 'N'.
               88  BR-STARTED                 VALUE 'Y'.
               88  BR-NOT-STARTED             VALUE 'N'.
           05  WS-EXP-VALID-SW      PIC X(01) VALUE 'Y'.
               88  EXP-VALID                  VALUE 'Y'.
               88  EXP-INVALID                VALUE 'N'.
           05  WS-FILTER-ON         PIC X(01) VALUE 'N'.
               88  FILTER-ACTIVE              VALUE 'Y'.
      *----------------------------------------------------------------*
      *  Date arithmetic work area for the expiry cutoff.              *
      *----------------------------------------------------------------*
       01  WS-DATE-CALC.
           05  WS-TODAY-YMD         PIC 9(08) VALUE ZEROS.
           05  WS-TODAY-INT         PIC 9(08) VALUE ZEROS.
           05  WS-CUTOFF-INT        PIC 9(08) VALUE ZEROS.
           05  WS-CUTOFF-YMD        PIC 9(08) VALUE ZEROS.
           05  WS-CUTOFF-RED REDEFINES WS-CUTOFF-YMD.
               10  WC-YEAR          PIC 9(04).
               10  WC-MM            PIC 9(02).
               10  WC-DD            PIC 9(02).
       01  WS-CUTOFF-STR.
           05  CS-YEAR              PIC 9(04).
           05  FILLER               PIC X(01) VALUE '-'.
           05  CS-MM                PIC 9(02).
           05  FILLER               PIC X(01) VALUE '-'.
           05  CS-DD                PIC 9(02).
       01  WS-CURR-RAW              PIC X(21) VALUE SPACES.
       01  WS-CURR-N.
           05  WCN-YEAR             PIC 9(04).
           05  WCN-MON              PIC 9(02).
           05  WCN-DAY              PIC 9(02).
      *----------------------------------------------------------------*
      *  Expiry parse / rebuild and leap-year work fields.             *
      *----------------------------------------------------------------*
       01  WS-EXP-PARSE.
           05  WS-EXP-YEAR-X        PIC X(04).
           05  WS-EXP-YEAR-N REDEFINES WS-EXP-YEAR-X PIC 9(04).
           05  WS-EXP-MM-X          PIC X(02).
           05  WS-EXP-DD-X          PIC X(02).
       01  WS-NEW-EXP.
           05  WNE-YEAR             PIC 9(04).
           05  FILLER               PIC X(01) VALUE '-'.
           05  WNE-MM               PIC X(02).
           05  FILLER               PIC X(01) VALUE '-'.
           05  WNE-DD               PIC X(02).
       01  WS-LEAP.
           05  WS-LEAP-R4           PIC 9(04) VALUE ZEROS.
           05  WS-LEAP-R100         PIC 9(04) VALUE ZEROS.
           05  WS-LEAP-R400         PIC 9(04) VALUE ZEROS.
       01  WS-MISC.
           05  WS-FILTER-CARD       PIC X(16) VALUE SPACES.
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RCARD.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KOPS.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN : overlay request, compute cutoff, browse, return.  *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KOPS-AREA TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INITIALISE.
           PERFORM 1300-COMPUTE-CUTOFF.
           PERFORM 3000-BROWSE-DRIVER.
           PERFORM 9000-FINALISE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INITIALISE : clear results, note any single-card filter. *
      *----------------------------------------------------------------*
       1000-INITIALISE.
           SET KO-OK TO TRUE.
           MOVE SPACES TO KO-STATUS-MSG.
           MOVE ZEROS TO KO-READ-CNT.
           MOVE ZEROS TO KO-SELECT-CNT.
           MOVE ZEROS TO KO-UPDATE-CNT.
           MOVE ZEROS TO KO-POSTED-CNT.
           MOVE ZEROS TO KO-REJECT-CNT.
           MOVE ZEROS TO KO-SKIP-CNT.
           MOVE ZEROS TO KO-TRAN-CNT.
           MOVE ZEROS TO KO-C1.
           MOVE ZEROS TO KO-C2.
           MOVE ZEROS TO KO-C3.
           MOVE ZEROS TO KO-AMT-1.
           MOVE ZEROS TO KO-AMT-2.
           MOVE ZEROS TO KO-AMT-3.
           MOVE 'N' TO WS-FILTER-ON.
           IF KO-PARM-CARD NOT = SPACES
              AND KO-PARM-CARD NOT = LOW-VALUES
               MOVE KO-PARM-CARD TO WS-FILTER-CARD
               SET FILTER-ACTIVE TO TRUE
           END-IF.
           SET BR-MORE TO TRUE.
           SET BR-NOT-STARTED TO TRUE.
      *----------------------------------------------------------------*
      *  1300-COMPUTE-CUTOFF : cutoff = run date + lead days.          *
      *----------------------------------------------------------------*
       1300-COMPUTE-CUTOFF.
           MOVE FUNCTION CURRENT-DATE TO WS-CURR-RAW.
           MOVE WS-CURR-RAW(1:8) TO WS-CURR-N.
           COMPUTE WS-TODAY-YMD =
               (WCN-YEAR * 10000) + (WCN-MON * 100) + WCN-DAY.
           COMPUTE WS-TODAY-INT =
               FUNCTION INTEGER-OF-DATE (WS-TODAY-YMD).
           COMPUTE WS-CUTOFF-INT = WS-TODAY-INT + WS-LEAD-DAYS.
           COMPUTE WS-CUTOFF-YMD =
               FUNCTION DATE-OF-INTEGER (WS-CUTOFF-INT).
           MOVE WC-YEAR TO CS-YEAR.
           MOVE WC-MM   TO CS-MM.
           MOVE WC-DD   TO CS-DD.
      *----------------------------------------------------------------*
      *  3000-BROWSE-DRIVER : browse cards and reissue where due.      *
      *----------------------------------------------------------------*
       3000-BROWSE-DRIVER.
           PERFORM 3100-START-BROWSE.
           IF BR-STARTED
               PERFORM 3200-READ-NEXT-CARD
               PERFORM 4000-PROCESS-CARD
                   UNTIL BR-END OR KO-ERROR
               PERFORM 3400-END-BROWSE
           END-IF.
      *----------------------------------------------------------------*
      *  3100-START-BROWSE : STARTBR at filter card or file start.     *
      *----------------------------------------------------------------*
       3100-START-BROWSE.
           IF FILTER-ACTIVE
               MOVE WS-FILTER-CARD TO CD-NUM
           ELSE
               MOVE LOW-VALUES TO CD-NUM
           END-IF.
           EXEC CICS STARTBR
                     FILE(WS-CARDFILE)
                     RIDFLD(CD-NUM)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BR-STARTED TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET BR-END TO TRUE
                   MOVE 'NO CARDS TO PROCESS.' TO KO-STATUS-MSG
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'STARTBR CARDFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-READ-NEXT-CARD : read one card forward.                  *
      *----------------------------------------------------------------*
       3200-READ-NEXT-CARD.
           EXEC CICS READNEXT
                     FILE(WS-CARDFILE)
                     INTO(CARD-REC)
                     RIDFLD(CD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KO-READ-CNT
               WHEN DFHRESP(ENDFILE)
                   SET BR-END TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'READNEXT CARDFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-PROCESS-CARD : classify the card and reissue if due.     *
      *----------------------------------------------------------------*
       4000-PROCESS-CARD.
           IF FILTER-ACTIVE AND CD-NUM NOT = WS-FILTER-CARD
               SET BR-END TO TRUE
           ELSE
               PERFORM 4100-VALIDATE-EXPIRY
               EVALUATE TRUE
                   WHEN CD-ACTIVE-STATUS NOT = 'Y'
                       ADD 1 TO KO-C2
                   WHEN EXP-INVALID
                       ADD 1 TO KO-C3
                   WHEN CD-EXPIRY-DATE <= WS-CUTOFF-STR
                       PERFORM 4200-REISSUE-CARD
                   WHEN OTHER
                       ADD 1 TO KO-C1
               END-EVALUATE
               PERFORM 3200-READ-NEXT-CARD
           END-IF.
      *----------------------------------------------------------------*
      *  4100-VALIDATE-EXPIRY : verify the YYYY-MM-DD parts numeric.   *
      *----------------------------------------------------------------*
       4100-VALIDATE-EXPIRY.
           SET EXP-VALID TO TRUE.
           MOVE CD-EXPIRY-DATE (1:4) TO WS-EXP-YEAR-X.
           MOVE CD-EXPIRY-DATE (6:2) TO WS-EXP-MM-X.
           MOVE CD-EXPIRY-DATE (9:2) TO WS-EXP-DD-X.
           IF WS-EXP-YEAR-X IS NOT NUMERIC
               SET EXP-INVALID TO TRUE
           END-IF.
           IF WS-EXP-MM-X IS NOT NUMERIC
               SET EXP-INVALID TO TRUE
           END-IF.
           IF WS-EXP-DD-X IS NOT NUMERIC
               SET EXP-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  4200-REISSUE-CARD : extend the expiry, clamp Feb-29, REWRITE. *
      *----------------------------------------------------------------*
       4200-REISSUE-CARD.
           COMPUTE WNE-YEAR = WS-EXP-YEAR-N + WS-EXTEND-YEARS.
           MOVE WS-EXP-MM-X TO WNE-MM.
           MOVE WS-EXP-DD-X TO WNE-DD.
           IF WNE-MM = '02' AND WNE-DD = '29'
               PERFORM 4250-ADJUST-LEAP
           END-IF.
           EXEC CICS READ
                     FILE(WS-CARDFILE)
                     INTO(CARD-REC)
                     RIDFLD(CD-NUM)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               ADD 1 TO KO-REJECT-CNT
               GO TO 4200-EXIT
           END-IF.
           MOVE WS-NEW-EXP TO CD-EXPIRY-DATE.
           EXEC CICS REWRITE
                     FILE(WS-CARDFILE)
                     FROM(CARD-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KO-POSTED-CNT
               ADD 1 TO KO-SELECT-CNT
               ADD 1 TO KO-UPDATE-CNT
           ELSE
               ADD 1 TO KO-REJECT-CNT
           END-IF.
       4200-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  4250-ADJUST-LEAP : if the extended year is not a leap year,   *
      *  clamp a Feb-29 expiry to Feb-28 so the date stays valid.      *
      *----------------------------------------------------------------*
       4250-ADJUST-LEAP.
           COMPUTE WS-LEAP-R4   = FUNCTION MOD (WNE-YEAR 4).
           COMPUTE WS-LEAP-R100 = FUNCTION MOD (WNE-YEAR 100).
           COMPUTE WS-LEAP-R400 = FUNCTION MOD (WNE-YEAR 400).
           IF WS-LEAP-R4 = 0 AND
              (WS-LEAP-R100 NOT = 0 OR WS-LEAP-R400 = 0)
               CONTINUE
           ELSE
               MOVE '28' TO WNE-DD
           END-IF.
      *----------------------------------------------------------------*
      *  3400-END-BROWSE : release the card browse.                    *
      *----------------------------------------------------------------*
       3400-END-BROWSE.
           IF BR-STARTED
               EXEC CICS ENDBR
                         FILE(WS-CARDFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
      *----------------------------------------------------------------*
      *  9000-FINALISE : set the completion status message.            *
      *----------------------------------------------------------------*
       9000-FINALISE.
           IF KO-ERROR
               CONTINUE
           ELSE
               IF KO-REJECT-CNT > 0
                   SET KO-WARN TO TRUE
               ELSE
                   SET KO-OK TO TRUE
               END-IF
               MOVE 'CARD RENEWAL PROCESSING COMPLETE.'
                   TO KO-STATUS-MSG
           END-IF.
