      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUMSG  -  message-text retriever                  *
      *  TYPE    : SUBROUTINE (CALL / EXEC CICS LINK)               *
      *  FUNCTION: return the text for a message code.               *
      *  CALL    : CALL 'OUMSG' USING KMSG-PARM.                     *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUMSG.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-FLAG PIC X(01) VALUE 'N'.
       LINKAGE SECTION.
       COPY KMSG.
       PROCEDURE DIVISION USING KMSG-PARM.
       0000-MAIN.
           MOVE '00' TO KM-STATUS.
           EVALUATE KM-CODE
               WHEN 'I0001' MOVE 'Operation completed successfully.'
                            TO KM-TEXT
               WHEN 'E0001' MOVE 'Record not found.'          TO KM-TEXT
               WHEN 'E0002' MOVE 'Duplicate record.'          TO KM-TEXT
               WHEN 'E0003' MOVE 'Please enter required fields.'
                            TO KM-TEXT
               WHEN 'E0004' MOVE 'Invalid data entered.'      TO KM-TEXT
               WHEN 'E0005' MOVE 'File access error.'         TO KM-TEXT
               WHEN 'W0001' MOVE 'No records to display.'     TO KM-TEXT
               WHEN OTHER
                   MOVE KM-CODE TO KM-TEXT
                   MOVE '01'    TO KM-STATUS
           END-EVALUATE.
           GOBACK.
