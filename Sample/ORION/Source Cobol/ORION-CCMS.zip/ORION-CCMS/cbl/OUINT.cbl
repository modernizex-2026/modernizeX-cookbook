      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUINT   -  Interest assessment SUB                *
      *  TYPE    : SUB  (CICS file control)                          *
      *  FUNCTION: assess one month of interest on revolving         *
      *            balances on demand.  Browses the account master   *
      *            (ACCTFILE) with STARTBR / READNEXT / ENDBR; for    *
      *            every active account carrying a positive balance   *
      *            it looks up the annual interest rate for the        *
      *            account's disclosure group (DGRPFILE, type 'IN'),  *
      *            computes monthly interest = balance * rate / 1200, *
      *            READs the account for UPDATE, adds the interest to  *
      *            the balance and the cycle debit bucket and         *
      *            REWRITEs the account.  Ports the interest batches  *
      *            OBINTC (VSAM) and ODINTC (DB2).                    *
      *  CALL    : EXEC CICS LINK PROGRAM('OUINT')                    *
      *                COMMAREA(ORION-COMMAREA) END-EXEC.             *
      *  REQUEST : KO-PARM-ACCT optional single account (0 = all).    *
      *  RESULT  : KO-READ examined    KO-SELECT eligible             *
      *            KO-POSTED charged   KO-UPDATE accts rewritten      *
      *            KO-SKIP skipped     KO-C1 rate defaulted           *
      *            KO-AMT-1 total interest  KO-AMT-2 balance before   *
      *            KO-AMT-3 balance after.                            *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUINT.
       AUTHOR.     ORION-CCMS-ONLINE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and interest constants.                      *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUINT'.
           05  WS-INT-TYPE          PIC X(02) VALUE 'IN'.
           05  WS-INT-CAT           PIC 9(04) VALUE 0001.
           05  WS-DEFAULT-RATE      PIC S9(04)V99 VALUE +18.99.
      *----------------------------------------------------------------*
      *  Browse and per-record control switches.                       *
      *----------------------------------------------------------------*
       01  WS-FLAGS.
           05  WS-BR-END-SW         PIC X(01) VALUE 'N'.
               88  BR-END                     VALUE 'Y'.
               88  BR-MORE                    VALUE 'N'.
           05  WS-BR-STARTED-SW     PIC X(01) VALUE 'N'.
               88  BR-STARTED                 VALUE 'Y'.
               88  BR-NOT-STARTED             VALUE 'N'.
           05  WS-RATE-FOUND-SW     PIC X(01) VALUE 'N'.
               88  RATE-FOUND                 VALUE 'Y'.
               88  RATE-NOT-FOUND             VALUE 'N'.
           05  WS-FILTER-ON         PIC X(01) VALUE 'N'.
               88  FILTER-ACTIVE              VALUE 'Y'.
      *----------------------------------------------------------------*
      *  Computation work fields.                                      *
      *----------------------------------------------------------------*
       01  WS-CALC.
           05  WS-USED-RATE         PIC S9(04)V99 VALUE ZEROS.
           05  WS-INT-AMT           PIC S9(11)V99 VALUE ZEROS.
           05  WS-FILTER-ACCT       PIC 9(11)     VALUE ZEROS.
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RACCT.
       COPY RDGRP.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KOPS.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN : overlay the request area, run the browse, return. *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KOPS-AREA TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INITIALISE.
           PERFORM 3000-BROWSE-DRIVER.
           PERFORM 9000-FINALISE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INITIALISE : clear result fields; note any filter.       *
      *----------------------------------------------------------------*
       1000-INITIALISE.
           SET KO-OK TO TRUE.
           MOVE SPACES TO KO-STATUS-MSG.
           MOVE ZEROS TO KO-READ-CNT.
           MOVE ZEROS TO KO-SELECT-CNT.
           MOVE ZEROS TO KO-UPDATE-CNT.
           MOVE ZEROS TO KO-POSTED-CNT.
           MOVE ZEROS TO KO-REJECT-CNT.
           MOVE ZEROS TO KO-SKIP-CNT.
           MOVE ZEROS TO KO-TRAN-CNT.
           MOVE ZEROS TO KO-C1.
           MOVE ZEROS TO KO-C2.
           MOVE ZEROS TO KO-C3.
           MOVE ZEROS TO KO-AMT-1.
           MOVE ZEROS TO KO-AMT-2.
           MOVE ZEROS TO KO-AMT-3.
           MOVE 'N' TO WS-FILTER-ON.
           IF KO-PARM-ACCT > ZERO
               MOVE KO-PARM-ACCT TO WS-FILTER-ACCT
               SET FILTER-ACTIVE TO TRUE
           END-IF.
           SET BR-MORE TO TRUE.
           SET BR-NOT-STARTED TO TRUE.
      *----------------------------------------------------------------*
      *  3000-BROWSE-DRIVER : browse accounts and assess interest.     *
      *----------------------------------------------------------------*
       3000-BROWSE-DRIVER.
           PERFORM 3100-START-BROWSE.
           IF BR-STARTED
               PERFORM 3200-READ-NEXT-ACCT
               PERFORM 4000-PROCESS-ACCT
                   UNTIL BR-END OR KO-ERROR
               PERFORM 3400-END-BROWSE
           END-IF.
      *----------------------------------------------------------------*
      *  3100-START-BROWSE : STARTBR at the filter key or file start.  *
      *----------------------------------------------------------------*
       3100-START-BROWSE.
           IF FILTER-ACTIVE
               MOVE WS-FILTER-ACCT TO AC-ID
           ELSE
               MOVE ZEROS TO AC-ID
           END-IF.
           EXEC CICS STARTBR
                     FILE(WS-ACCTFILE)
                     RIDFLD(AC-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BR-STARTED TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET BR-END TO TRUE
                   MOVE 'NO ACCOUNTS TO ASSESS.' TO KO-STATUS-MSG
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'STARTBR ACCTFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-READ-NEXT-ACCT : read one account forward.               *
      *----------------------------------------------------------------*
       3200-READ-NEXT-ACCT.
           EXEC CICS READNEXT
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KO-READ-CNT
               WHEN DFHRESP(ENDFILE)
                   SET BR-END TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'READNEXT ACCTFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-PROCESS-ACCT : screen the account then assess interest.  *
      *  Inactive accounts and non-positive balances are skipped.      *
      *----------------------------------------------------------------*
       4000-PROCESS-ACCT.
           IF FILTER-ACTIVE AND AC-ID NOT = WS-FILTER-ACCT
               SET BR-END TO TRUE
           ELSE
               ADD AC-CURR-BAL TO KO-AMT-2
               EVALUATE TRUE
                   WHEN AC-ACTIVE-STATUS = 'N'
                       ADD 1 TO KO-SKIP-CNT
                       ADD AC-CURR-BAL TO KO-AMT-3
                   WHEN AC-CURR-BAL <= ZERO
                       ADD 1 TO KO-SKIP-CNT
                       ADD AC-CURR-BAL TO KO-AMT-3
                   WHEN OTHER
                       ADD 1 TO KO-SELECT-CNT
                       PERFORM 4100-LOOKUP-RATE
                       PERFORM 4200-COMPUTE-INTEREST
                       PERFORM 4300-UPDATE-ACCT
               END-EVALUATE
               PERFORM 3200-READ-NEXT-ACCT
           END-IF.
      *----------------------------------------------------------------*
      *  4100-LOOKUP-RATE : read the disclosure rate for the group.    *
      *  A missing group entry falls back to the default rate.         *
      *----------------------------------------------------------------*
       4100-LOOKUP-RATE.
           SET RATE-NOT-FOUND TO TRUE.
           MOVE AC-GROUP-ID  TO DG-ACCT-GROUP.
           MOVE WS-INT-TYPE  TO DG-TYPE-CD.
           MOVE WS-INT-CAT   TO DG-CAT-CD.
           EXEC CICS READ
                     FILE(WS-DGRPFILE)
                     INTO(DGRP-REC)
                     RIDFLD(DG-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET RATE-FOUND TO TRUE
                   MOVE DG-INT-RATE TO WS-USED-RATE
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
           IF RATE-NOT-FOUND
               MOVE WS-DEFAULT-RATE TO WS-USED-RATE
               ADD 1 TO KO-C1
           END-IF.
      *----------------------------------------------------------------*
      *  4200-COMPUTE-INTEREST : monthly interest on the balance.      *
      *----------------------------------------------------------------*
       4200-COMPUTE-INTEREST.
           COMPUTE WS-INT-AMT ROUNDED =
               (AC-CURR-BAL * WS-USED-RATE) / 1200.
           IF WS-INT-AMT < ZERO
               MOVE ZERO TO WS-INT-AMT
           END-IF.
      *----------------------------------------------------------------*
      *  4300-UPDATE-ACCT : READ the account for UPDATE, add the       *
      *  interest to the balance and cycle debit, then REWRITE.        *
      *----------------------------------------------------------------*
       4300-UPDATE-ACCT.
           IF WS-INT-AMT <= ZERO
               ADD 1 TO KO-SKIP-CNT
               ADD AC-CURR-BAL TO KO-AMT-3
               GO TO 4300-EXIT
           END-IF.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               ADD 1 TO KO-REJECT-CNT
               ADD AC-CURR-BAL TO KO-AMT-3
               GO TO 4300-EXIT
           END-IF.
           ADD WS-INT-AMT TO AC-CURR-BAL.
           ADD WS-INT-AMT TO AC-CYC-DEBIT.
           EXEC CICS REWRITE
                     FILE(WS-ACCTFILE)
                     FROM(ACCT-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KO-POSTED-CNT
               ADD 1 TO KO-UPDATE-CNT
               ADD WS-INT-AMT TO KO-AMT-1
               ADD AC-CURR-BAL TO KO-AMT-3
           ELSE
               ADD 1 TO KO-REJECT-CNT
               ADD AC-CURR-BAL TO KO-AMT-3
           END-IF.
       4300-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3400-END-BROWSE : release the account browse.                 *
      *----------------------------------------------------------------*
       3400-END-BROWSE.
           IF BR-STARTED
               EXEC CICS ENDBR
                         FILE(WS-ACCTFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
      *----------------------------------------------------------------*
      *  9000-FINALISE : set the completion status message.            *
      *----------------------------------------------------------------*
       9000-FINALISE.
           IF KO-ERROR
               CONTINUE
           ELSE
               IF KO-REJECT-CNT > 0
                   SET KO-WARN TO TRUE
               ELSE
                   SET KO-OK TO TRUE
               END-IF
               MOVE 'INTEREST ASSESSMENT COMPLETE.' TO KO-STATUS-MSG
           END-IF.
