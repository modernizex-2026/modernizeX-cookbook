      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCTTYP   -  Transaction Type Maintenance         *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: maintain the transaction-type reference file      *
      *            (TTYPFILE).  ENTER reads a type code and shows    *
      *            its description or reports that it is new.  PF5    *
      *            saves the description - a REWRITE when the code    *
      *            already exists, otherwise a WRITE.                 *
      *            PF3 = back to menu, PF4 = clear, ENTER = read,     *
      *            PF5 = save.                                        *
      *  MAPSET  : MTTYP       MAP : MTTYPA      TRANID : ORTT       *
      *  FILES   : TTYPFILE (read / write / rewrite)                *
      *  STATE   : held in CA-WORK-AREA(1:1)                        *
      *              'K' key-entry (waiting for a type code)         *
      *              'E' exists    (loaded, update on save)          *
      *              'N' new       (not on file, add on save)        *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.      *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - tran type maintenance.        *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCTTYP.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCTTYP'.
           05  WS-TRANID            PIC X(04) VALUE 'ORTT'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Validation / update switches local to this program.          *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
           05  WS-SAVE-SW           PIC X(01) VALUE 'N'.
               88  WS-SAVE-OK                 VALUE 'Y'.
               88  WS-SAVE-BAD                VALUE 'N'.
      *----------------------------------------------------------------*
      *  Symbolic values for the pseudo-conversational state byte.     *
      *----------------------------------------------------------------*
       01  WS-STATE-CONST.
           05  WS-ST-KEY            PIC X(01) VALUE 'K'.
           05  WS-ST-EXIST          PIC X(01) VALUE 'E'.
           05  WS-ST-NEW            PIC X(01) VALUE 'N'.
      *----------------------------------------------------------------*
      *  Saved type code work field.                                   *
      *----------------------------------------------------------------*
       01  WS-KEY-FIELDS.
           05  WS-TT-CD             PIC X(02) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter a type code and press ENTER.'.
           05  WS-M-CD-REQ          PIC X(50)
               VALUE 'Type code is required.'.
           05  WS-M-DESC-REQ        PIC X(50)
               VALUE 'Description is required.'.
           05  WS-M-FOUND           PIC X(50)
               VALUE 'Type found. Change text, PF5 to update.'.
           05  WS-M-NEW             PIC X(50)
               VALUE 'New type. Enter text, PF5 to add.'.
           05  WS-M-KEY-FIRST       PIC X(50)
               VALUE 'Enter a type code and press ENTER first.'.
           05  WS-M-ADDED           PIC X(50)
               VALUE 'Transaction type added.'.
           05  WS-M-UPDATED         PIC X(50)
               VALUE 'Transaction type updated.'.
           05  WS-M-SAVE-ERR        PIC X(50)
               VALUE 'Error saving the transaction type.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  File record layout and BMS symbolic map.                      *
      *----------------------------------------------------------------*
       COPY RTTYP.
       COPY MTTYP.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  clear the map and prompt for a code.    *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MTTYPAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-ST-KEY TO CA-WORK-AREA(1:1).
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO TTCDL.
           EXEC CICS SEND
                     MAP('MTTYPA')
                     MAPSET('MTTYP')
                     FROM(MTTYPAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHPF5
                   PERFORM 2300-SAVE
               WHEN DFHENTER
                   PERFORM 2100-LOOKUP
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2050-RECEIVE  -  read the map; treat MAPFAIL as empty input.  *
      *----------------------------------------------------------------*
       2050-RECEIVE.
           EXEC CICS RECEIVE
                     MAP('MTTYPA')
                     MAPSET('MTTYP')
                     INTO(MTTYPAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MTTYPAI
           END-IF.
      *----------------------------------------------------------------*
      *  2100-LOOKUP  -  ENTER pressed.  Read the code and open it     *
      *  for maintenance, distinguishing existing from new.            *
      *----------------------------------------------------------------*
       2100-LOOKUP.
           PERFORM 2050-RECEIVE.
           IF TTCDI = SPACES OR TTCDI = LOW-VALUES
               MOVE WS-M-CD-REQ TO ERRMSGO
               MOVE -1 TO TTCDL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE TTCDI TO WS-TT-CD
               INSPECT WS-TT-CD REPLACING ALL LOW-VALUE BY SPACE
               PERFORM 3000-READ-TTYP
               IF REC-FOUND
                   MOVE TT-CD   TO TTCDO
                   MOVE TT-DESC TO TTDESCO
                   MOVE WS-ST-EXIST TO CA-WORK-AREA(1:1)
                   MOVE WS-M-FOUND TO ERRMSGO
               ELSE
                   MOVE WS-TT-CD TO TTCDO
                   MOVE SPACES   TO TTDESCO
                   MOVE WS-ST-NEW TO CA-WORK-AREA(1:1)
                   MOVE WS-M-NEW TO ERRMSGO
               END-IF
               MOVE -1 TO TTDESCL
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  2300-SAVE  -  PF5 pressed.  Validate the description then
      *  add or update the record according to the saved state.        *
      *----------------------------------------------------------------*
       2300-SAVE.
           IF CA-WORK-AREA(1:1) NOT = WS-ST-EXIST
              AND CA-WORK-AREA(1:1) NOT = WS-ST-NEW
               MOVE WS-M-KEY-FIRST TO ERRMSGO
               MOVE -1 TO TTCDL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 2050-RECEIVE
               IF TTDESCI = SPACES OR TTDESCI = LOW-VALUES
                   MOVE WS-M-DESC-REQ TO ERRMSGO
                   MOVE -1 TO TTDESCL
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   IF CA-WORK-AREA(1:1) = WS-ST-EXIST
                       PERFORM 3500-UPDATE-TTYP
                   ELSE
                       PERFORM 3600-ADD-TTYP
                   END-IF
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3000-READ-TTYP  -  random read of TTYPFILE by TT-CD.        *
      *----------------------------------------------------------------*
       3000-READ-TTYP.
           SET REC-NOT-FOUND TO TRUE.
           MOVE WS-TT-CD TO TT-CD.
           EXEC CICS READ
                     FILE(WS-TTYPFILE)
                     INTO(TTYP-REC)
                     RIDFLD(TT-CD)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3500-UPDATE-TTYP  -  READ UPDATE and REWRITE the record.     *
      *----------------------------------------------------------------*
       3500-UPDATE-TTYP.
           MOVE WS-TT-CD TO TT-CD.
           EXEC CICS READ
                     FILE(WS-TTYPFILE)
                     INTO(TTYP-REC)
                     RIDFLD(TT-CD)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE TTDESCI TO TT-DESC
                   EXEC CICS REWRITE
                             FILE(WS-TTYPFILE)
                             FROM(TTYP-REC)
                             RESP(WS-RESP-CD)
                   END-EXEC
                   IF WS-RESP-CD = DFHRESP(NORMAL)
                       MOVE WS-M-UPDATED TO ERRMSGO
                   ELSE
                       MOVE WS-M-SAVE-ERR TO ERRMSGO
                   END-IF
               WHEN DFHRESP(NOTFND)
                   PERFORM 3600-ADD-TTYP
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3600-ADD-TTYP  -  build TTYP-REC and write a new record.     *
      *----------------------------------------------------------------*
       3600-ADD-TTYP.
           INITIALIZE TTYP-REC.
           MOVE WS-TT-CD TO TT-CD.
           MOVE TTDESCI  TO TT-DESC.
           EXEC CICS WRITE
                     FILE(WS-TTYPFILE)
                     FROM(TTYP-REC)
                     RIDFLD(TT-CD)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE WS-M-ADDED TO ERRMSGO
                   MOVE WS-ST-EXIST TO CA-WORK-AREA(1:1)
               WHEN DFHRESP(DUPREC)
                   MOVE WS-M-SAVE-ERR TO ERRMSGO
               WHEN OTHER
                   MOVE WS-M-SAVE-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.*
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  refresh header and resend the map.     *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MTTYPA')
                     MAPSET('MTTYP')
                     FROM(MTTYPAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to this tran.    *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9500-ABEND-RTN  -  unrecoverable file error - inform and end. *
      *----------------------------------------------------------------*
       9500-ABEND-RTN.
           MOVE 'OCTTYP: unrecoverable file error. Contact support.'
               TO WS-MSG-TEXT.
           EXEC CICS SEND TEXT
                     FROM(WS-MSG-TEXT)
                     LENGTH(LENGTH OF WS-MSG-TEXT)
                     ERASE
                     FREEKB
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS RETURN
                     RESP(WS-RESP-CD)
           END-EXEC.
