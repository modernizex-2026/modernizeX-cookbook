      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCSTMIN  -  Statement Inquiry (on-line)          *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: browse the statement master (STMTFILE) in key    *
      *            order and display a page of six statement cycles *
      *            showing account, cycle, open and close balance,  *
      *            minimum due and due date.  The operator types a  *
      *            starting account id (and optional cycle) and     *
      *            presses ENTER; PF8 pages forward, PF7 restarts   *
      *            at the entered filter, PF3 returns to the report *
      *            menu and PF4 clears the screen.                  *
      *  PATTERN : list screen LINKs the browse subroutine OUSTMIN  *
      *            (STARTBR / READNEXT / ENDBR) once per page; the  *
      *            paging keys travel in the COMMAREA work area.    *
      *  MAPSET  : MSTMIN      MAP : MSTMINA     TRANID : ORSI       *
      *  REPLACES: batch reports OBRSTMT and OBSTMTX (statement     *
      *            summary / extract) with an on-line inquiry.      *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - statement inquiry with paging.*
      *****************************************************************
      *  PROCESSING NARRATIVE                                        *
      *  1. ENTER positions the browse at the typed account id and   *
      *     cycle (or the start of file when both are blank) and     *
      *     the filter start key is remembered for PF7.              *
      *  2. One page of up to six statements is returned by OUSTMIN  *
      *     together with the key that begins the following page.    *
      *  3. PF8 resumes from that saved key; PF7 re-runs the browse  *
      *     from the remembered filter start.                        *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCSTMIN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCSTMIN'.
           05  WS-TRANID            PIC X(04) VALUE 'ORSI'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCRPTMN'.
           05  WS-SUB-PGM           PIC X(08) VALUE 'OUSTMIN'.
      *----------------------------------------------------------------*
      *  Browse start key and paging state (also mirrored in the       *
      *  COMMAREA work area so it survives the pseudo-conversation).   *
      *----------------------------------------------------------------*
       01  WS-START-KEY.
           05  WS-START-ACCT        PIC 9(11) VALUE ZEROS.
           05  WS-START-CYCLE       PIC 9(06) VALUE ZEROS.
       01  WS-PAGE-STATE.
           05  WS-PS-NEXT-ACCT      PIC 9(11) VALUE ZEROS.
           05  WS-PS-NEXT-CYCLE     PIC 9(06) VALUE ZEROS.
           05  WS-PS-MORE           PIC X(01) VALUE 'N'.
           05  WS-PS-FLT-ACCT       PIC 9(11) VALUE ZEROS.
           05  WS-PS-FLT-CYCLE      PIC 9(06) VALUE ZEROS.
           05  WS-PS-FLT-SET        PIC X(01) VALUE 'N'.
      *----------------------------------------------------------------*
      *  Per-row display work fields and numeric edit patterns.        *
      *----------------------------------------------------------------*
       01  WS-ROW-WORK.
           05  WS-R-ACCT            PIC X(11).
           05  WS-R-CYCLE           PIC X(06).
           05  WS-R-OPEN            PIC X(14).
           05  WS-R-CLOSE           PIC X(14).
           05  WS-R-MIN             PIC X(14).
           05  WS-R-DUE             PIC X(10).
       01  WS-EDITS.
           05  WS-ED-MONEY          PIC ---,---,--9.99.
           05  WS-CNT-ED            PIC Z9.
      *----------------------------------------------------------------*
      *  Validation switch used by the numeric parser.                 *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Reusable numeric-field parser work area.                      *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(16) VALUE SPACES.
           05  WS-NC-LEN            PIC 9(02) VALUE ZEROS.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(16) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter account id (blank=first) and ENTER.'.
           05  WS-M-BAD-ACCT        PIC X(50)
               VALUE 'Account id must be numeric.'.
           05  WS-M-BAD-CYCLE       PIC X(50)
               VALUE 'Cycle must be numeric (YYYYMM).'.
           05  WS-M-NONE-FOUND      PIC X(50)
               VALUE 'No statements found from that point.'.
           05  WS-M-BROWSE-ERR      PIC X(50)
               VALUE 'Error browsing the statement file.'.
           05  WS-M-END-FILE        PIC X(50)
               VALUE 'End of file - no more statements.'.
           05  WS-M-SUFFIX          PIC X(30)
               VALUE ' statement(s) displayed.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea and  *
      *  the browse subroutine parameter block.                        *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY KSTMB.
      *----------------------------------------------------------------*
      *  BMS symbolic map and IBM-supplied AID / attribute constants.  *
      *----------------------------------------------------------------*
       COPY MSTMIN.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               MOVE CA-WORK-AREA(1:36) TO WS-PAGE-STATE
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh empty screen.*
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MSTMINAO.
           PERFORM 8000-POPULATE-HEADER.
           PERFORM 3050-CLEAR-ROWS.
           INITIALIZE WS-PAGE-STATE.
           MOVE 'N' TO WS-PS-MORE.
           MOVE 'N' TO WS-PS-FLT-SET.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO FRACCTL.
           EXEC CICS SEND
                     MAP('MSTMINA')
                     MAPSET('MSTMIN')
                     FROM(MSTMINAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHPF7
                   PERFORM 2300-RESTART
               WHEN DFHPF8
                   PERFORM 2200-PAGE-FWD
               WHEN DFHENTER
                   PERFORM 2100-SEARCH
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-SEARCH  -  ENTER pressed.  Receive the filter, validate  *
      *  it, remember it for PF7 and drive the first page.             *
      *----------------------------------------------------------------*
       2100-SEARCH.
           EXEC CICS RECEIVE
                     MAP('MSTMINA')
                     MAPSET('MSTMIN')
                     INTO(MSTMINAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MSTMINAI
           END-IF.
           PERFORM 2110-EDIT-ACCT.
           IF WS-INVALID
               GO TO 2100-EXIT
           END-IF.
           PERFORM 2120-EDIT-CYCLE.
           IF WS-INVALID
               GO TO 2100-EXIT
           END-IF.
           MOVE WS-START-ACCT  TO WS-PS-FLT-ACCT.
           MOVE WS-START-CYCLE TO WS-PS-FLT-CYCLE.
           MOVE 'Y'            TO WS-PS-FLT-SET.
           PERFORM 3000-DO-BROWSE.
           PERFORM 2400-BUILD-SUMMARY.
           MOVE -1 TO FRACCTL.
           PERFORM 8100-SEND-DATAONLY.
       2100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2110-EDIT-ACCT  -  validate the account id filter.            *
      *----------------------------------------------------------------*
       2110-EDIT-ACCT.
           SET WS-VALID TO TRUE.
           MOVE FRACCTI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN = SPACES
               MOVE ZEROS TO WS-START-ACCT
           ELSE
               MOVE 11 TO WS-NC-LEN
               PERFORM 6000-PARSE-NUM
               IF WS-INVALID
                   MOVE WS-M-BAD-ACCT TO ERRMSGO
                   MOVE -1 TO FRACCTL
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE WS-NC-VALUE TO WS-START-ACCT
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2120-EDIT-CYCLE  -  validate the optional cycle filter.       *
      *----------------------------------------------------------------*
       2120-EDIT-CYCLE.
           SET WS-VALID TO TRUE.
           MOVE FRCYCI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN = SPACES
               MOVE ZEROS TO WS-START-CYCLE
           ELSE
               MOVE 6 TO WS-NC-LEN
               PERFORM 6000-PARSE-NUM
               IF WS-INVALID
                   MOVE WS-M-BAD-CYCLE TO ERRMSGO
                   MOVE -1 TO FRACCTL
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE WS-NC-VALUE TO WS-START-CYCLE
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2200-PAGE-FWD  -  PF8 pressed.  Resume at the saved next key. *
      *----------------------------------------------------------------*
       2200-PAGE-FWD.
           IF WS-PS-MORE = 'Y'
               MOVE WS-PS-NEXT-ACCT  TO WS-START-ACCT
               MOVE WS-PS-NEXT-CYCLE TO WS-START-CYCLE
               PERFORM 3000-DO-BROWSE
               PERFORM 2400-BUILD-SUMMARY
           ELSE
               MOVE WS-M-END-FILE TO ERRMSGO
           END-IF.
           MOVE -1 TO FRACCTL.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  2300-RESTART  -  PF7 pressed.  Re-run from the filter start.  *
      *----------------------------------------------------------------*
       2300-RESTART.
           IF WS-PS-FLT-SET = 'Y'
               MOVE WS-PS-FLT-ACCT  TO WS-START-ACCT
               MOVE WS-PS-FLT-CYCLE TO WS-START-CYCLE
           ELSE
               MOVE ZEROS TO WS-START-ACCT
               MOVE ZEROS TO WS-START-CYCLE
           END-IF.
           PERFORM 3000-DO-BROWSE.
           PERFORM 2400-BUILD-SUMMARY.
           MOVE -1 TO FRACCTL.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  2400-BUILD-SUMMARY  -  compose the result-count message.      *
      *----------------------------------------------------------------*
       2400-BUILD-SUMMARY.
           EVALUATE TRUE
               WHEN KSB-STATUS = '99'
                   MOVE WS-M-BROWSE-ERR TO ERRMSGO
               WHEN KSB-ROW-CNT = ZEROS
                   MOVE WS-M-NONE-FOUND TO ERRMSGO
               WHEN OTHER
                   MOVE KSB-ROW-CNT TO WS-CNT-ED
                   MOVE SPACES TO ERRMSGO
                   STRING WS-CNT-ED   DELIMITED BY SIZE
                          WS-M-SUFFIX DELIMITED BY SIZE
                          INTO ERRMSGO
                   END-STRING
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3000-DO-BROWSE  -  LINK the browse subroutine for one page    *
      *  and unload the returned rows and paging keys.                 *
      *----------------------------------------------------------------*
       3000-DO-BROWSE.
           PERFORM 3050-CLEAR-ROWS.
           MOVE 'ACCT'         TO KSB-MODE.
           MOVE WS-START-ACCT  TO KSB-START-ACCT.
           MOVE WS-START-CYCLE TO KSB-START-CYCLE.
           MOVE 6              TO KSB-MAX-ROWS.
           EXEC CICS LINK
                     PROGRAM(WS-SUB-PGM)
                     COMMAREA(KSTMB-PARM)
                     LENGTH(LENGTH OF KSTMB-PARM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               MOVE '99'  TO KSB-STATUS
               MOVE ZEROS TO KSB-ROW-CNT
               MOVE 'N'   TO WS-PS-MORE
               GO TO 3000-EXIT
           END-IF.
           MOVE KSB-NEXT-ACCT  TO WS-PS-NEXT-ACCT.
           MOVE KSB-NEXT-CYCLE TO WS-PS-NEXT-CYCLE.
           MOVE KSB-MORE       TO WS-PS-MORE.
           IF KSB-ROW-CNT > ZEROS
               PERFORM 4000-MOVE-ROWS
           END-IF.
       3000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3050-CLEAR-ROWS  -  blank the six display lines.              *
      *----------------------------------------------------------------*
       3050-CLEAR-ROWS.
           MOVE SPACES TO SA1O SC1O SO1O SL1O SM1O SD1O.
           MOVE SPACES TO SA2O SC2O SO2O SL2O SM2O SD2O.
           MOVE SPACES TO SA3O SC3O SO3O SL3O SM3O SD3O.
           MOVE SPACES TO SA4O SC4O SO4O SL4O SM4O SD4O.
           MOVE SPACES TO SA5O SC5O SO5O SL5O SM5O SD5O.
           MOVE SPACES TO SA6O SC6O SO6O SL6O SM6O SD6O.
      *----------------------------------------------------------------*
      *  4000-MOVE-ROWS  -  format and place every returned row.       *
      *----------------------------------------------------------------*
       4000-MOVE-ROWS.
           PERFORM VARYING WS-IDX FROM 1 BY 1
                   UNTIL WS-IDX > KSB-ROW-CNT
               PERFORM 4100-FORMAT-ROW
               PERFORM 4200-PLACE-ROW
           END-PERFORM.
      *----------------------------------------------------------------*
      *  4100-FORMAT-ROW  -  edit one row into the display work area.  *
      *----------------------------------------------------------------*
       4100-FORMAT-ROW.
           MOVE KSB-R-ACCT  (WS-IDX) TO WS-R-ACCT.
           MOVE KSB-R-CYCLE (WS-IDX) TO WS-R-CYCLE.
           MOVE KSB-R-OPEN  (WS-IDX) TO WS-ED-MONEY.
           MOVE WS-ED-MONEY          TO WS-R-OPEN.
           MOVE KSB-R-CLOSE (WS-IDX) TO WS-ED-MONEY.
           MOVE WS-ED-MONEY          TO WS-R-CLOSE.
           MOVE KSB-R-MINDUE (WS-IDX) TO WS-ED-MONEY.
           MOVE WS-ED-MONEY          TO WS-R-MIN.
           MOVE KSB-R-DUEDT (WS-IDX) TO WS-R-DUE.
      *----------------------------------------------------------------*
      *  4200-PLACE-ROW  -  move the work area into the map line that  *
      *  matches the current row index.                               *
      *----------------------------------------------------------------*
       4200-PLACE-ROW.
           EVALUATE WS-IDX
               WHEN 1
                   MOVE WS-R-ACCT  TO SA1O
                   MOVE WS-R-CYCLE TO SC1O
                   MOVE WS-R-OPEN  TO SO1O
                   MOVE WS-R-CLOSE TO SL1O
                   MOVE WS-R-MIN   TO SM1O
                   MOVE WS-R-DUE   TO SD1O
               WHEN 2
                   MOVE WS-R-ACCT  TO SA2O
                   MOVE WS-R-CYCLE TO SC2O
                   MOVE WS-R-OPEN  TO SO2O
                   MOVE WS-R-CLOSE TO SL2O
                   MOVE WS-R-MIN   TO SM2O
                   MOVE WS-R-DUE   TO SD2O
               WHEN 3
                   MOVE WS-R-ACCT  TO SA3O
                   MOVE WS-R-CYCLE TO SC3O
                   MOVE WS-R-OPEN  TO SO3O
                   MOVE WS-R-CLOSE TO SL3O
                   MOVE WS-R-MIN   TO SM3O
                   MOVE WS-R-DUE   TO SD3O
               WHEN 4
                   MOVE WS-R-ACCT  TO SA4O
                   MOVE WS-R-CYCLE TO SC4O
                   MOVE WS-R-OPEN  TO SO4O
                   MOVE WS-R-CLOSE TO SL4O
                   MOVE WS-R-MIN   TO SM4O
                   MOVE WS-R-DUE   TO SD4O
               WHEN 5
                   MOVE WS-R-ACCT  TO SA5O
                   MOVE WS-R-CYCLE TO SC5O
                   MOVE WS-R-OPEN  TO SO5O
                   MOVE WS-R-CLOSE TO SL5O
                   MOVE WS-R-MIN   TO SM5O
                   MOVE WS-R-DUE   TO SD5O
               WHEN 6
                   MOVE WS-R-ACCT  TO SA6O
                   MOVE WS-R-CYCLE TO SC6O
                   MOVE WS-R-OPEN  TO SO6O
                   MOVE WS-R-CLOSE TO SL6O
                   MOVE WS-R-MIN   TO SM6O
                   MOVE WS-R-DUE   TO SD6O
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6000-PARSE-NUM  -  scan WS-NC-IN for WS-NC-LEN characters,
      *  ignore spaces, accumulate digits into WS-NC-VALUE and count   *
      *  them.  Any other character makes the field invalid.           *
      *----------------------------------------------------------------*
       6000-PARSE-NUM.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > WS-NC-LEN
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the reports menu.     *
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  re-transmit the map data only.         *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MSTMINA')
                     MAPSET('MSTMIN')
                     FROM(MSTMINAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  persist paging state and return to CICS.      *
      *----------------------------------------------------------------*
       9000-RETURN.
           MOVE WS-PAGE-STATE TO CA-WORK-AREA(1:36).
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *                   E N D   O F   O C S T M I N                  *
      *----------------------------------------------------------------*
