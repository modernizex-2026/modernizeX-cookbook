      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCMENU  -  Main Menu (on-line)                    *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: present the main menu and XCTL to the chosen      *
      *            function.  PF3 = sign off (back to sign-on).      *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCMENU.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCMENU'.
           05  WS-TRANID            PIC X(04) VALUE 'ORMN'.
           05  WS-SGNON-PGM         PIC X(08) VALUE 'OCSGNON'.
           05  WS-XCTL-PGM          PIC X(08) VALUE SPACES.
           05  WS-OPTION            PIC 9(02) VALUE ZEROS.
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY MMENU.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           IF EIBCALEN = 0
               EXEC CICS XCTL PROGRAM(WS-SGNON-PGM)
                         RESP(WS-RESP-CD) END-EXEC
           END-IF.
           MOVE DFHCOMMAREA TO ORION-COMMAREA.
           IF CA-FIRST-ENTER
               PERFORM 1000-SEND-INITIAL
           ELSE
               PERFORM 2000-PROCESS-INPUT
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MMENUAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Select an option (1-10) and press ENTER.' TO ERRMSGO.
           EXEC CICS SEND MAP('MMENUA') MAPSET('MMENU')
                     FROM(MMENUAO) ERASE RESP(WS-RESP-CD) END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   MOVE 0 TO CA-PGM-CONTEXT
                   EXEC CICS XCTL PROGRAM(WS-SGNON-PGM)
                             COMMAREA(ORION-COMMAREA)
                             RESP(WS-RESP-CD) END-EXEC
               WHEN DFHENTER
                   PERFORM 2100-DISPATCH
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
       2100-DISPATCH.
           EXEC CICS RECEIVE MAP('MMENUA') MAPSET('MMENU')
                     INTO(MMENUAI) RESP(WS-RESP-CD) END-EXEC.
           IF OPTIONI NUMERIC
               MOVE OPTIONI TO WS-OPTION
           ELSE
               MOVE 0 TO WS-OPTION
           END-IF.
           EVALUATE WS-OPTION
               WHEN 1  MOVE 'OCACCTV' TO WS-XCTL-PGM
               WHEN 2  MOVE 'OCACCTU' TO WS-XCTL-PGM
               WHEN 3  MOVE 'OCCARDL' TO WS-XCTL-PGM
               WHEN 4  MOVE 'OCCARDV' TO WS-XCTL-PGM
               WHEN 5  MOVE 'OCCARDU' TO WS-XCTL-PGM
               WHEN 6  MOVE 'OCCUSTV' TO WS-XCTL-PGM
               WHEN 7  MOVE 'OCTRANL' TO WS-XCTL-PGM
               WHEN 8  MOVE 'OCTRANA' TO WS-XCTL-PGM
               WHEN 9  MOVE 'OCBILLP' TO WS-XCTL-PGM
               WHEN 10 MOVE 'OCRPTMN' TO WS-XCTL-PGM
               WHEN OTHER MOVE SPACES TO WS-XCTL-PGM
           END-EVALUATE.
           IF WS-XCTL-PGM = SPACES
               PERFORM 1000-SEND-INITIAL
               MOVE 'Invalid option.' TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE WS-PGMNAME TO CA-FROM-PROGRAM
               MOVE 0 TO CA-PGM-CONTEXT
               EXEC CICS XCTL PROGRAM(WS-XCTL-PGM)
                         COMMAREA(ORION-COMMAREA)
                         RESP(WS-RESP-CD) END-EXEC
           END-IF.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           EXEC CICS ASKTIME ABSTIME(WS-AMT) RESP(WS-RESP-CD) END-EXEC.
           EXEC CICS FORMATTIME ABSTIME(WS-AMT) DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME) TIMESEP(':')
                     RESP(WS-RESP-CD) END-EXEC.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND MAP('MMENUA') MAPSET('MMENU')
                     FROM(MMENUAO) DATAONLY RESP(WS-RESP-CD) END-EXEC.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA) RESP(WS-RESP-CD) END-EXEC.
