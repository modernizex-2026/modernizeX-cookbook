      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUCHGF  -  Charge-off processing SUB              *
      *  TYPE    : SUB  (CICS file control)                          *
      *  FUNCTION: write off severely delinquent accounts on demand. *
      *            Browses the account master (ACCTFILE); an account  *
      *            is charged off when it is active, carries a         *
      *            positive balance materially over the credit limit  *
      *            (balance > limit * 1.20) and has taken no payment   *
      *            this cycle (cycle credit = 0).  For each such       *
      *            account a reversing charge-off transaction          *
      *            (type 'CO', amount = -balance) is WRITTEN to        *
      *            TRANFILE, the account is READ for UPDATE, its       *
      *            status set to 'C' with a zeroed balance, and it is  *
      *            REWRITTEN.  Ports the batch charge-off OBCHGOFF.    *
      *  CALL    : EXEC CICS LINK PROGRAM('OUCHGF')                   *
      *                COMMAREA(ORION-COMMAREA) END-EXEC.             *
      *  REQUEST : KO-PARM-ACCT optional single account (0 = all).    *
      *  RESULT  : KO-READ read       KO-SELECT charged off           *
      *            KO-UPDATE rewritten KO-TRAN adjustments            *
      *            KO-AMT-1 total charged-off amount.                 *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUCHGF.
       AUTHOR.     ORION-CCMS-ONLINE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and charge-off parameters.                   *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUCHGF'.
           05  WS-CTRL-KEY-ID       PIC X(08) VALUE 'TRANID  '.
           05  WS-ID-PREFIX         PIC X(02) VALUE 'CO'.
           05  WS-CO-FACTOR         PIC 9(01)V99 VALUE 1.20.
      *----------------------------------------------------------------*
      *  Browse and control switches.                                  *
      *----------------------------------------------------------------*
       01  WS-FLAGS.
           05  WS-BR-END-SW         PIC X(01) VALUE 'N'.
               88  BR-END                     VALUE 'Y'.
               88  BR-MORE                    VALUE 'N'.
           05  WS-BR-STARTED-SW     PIC X(01) VALUE 'N'.
               88  BR-STARTED                 VALUE 'Y'.
               88  BR-NOT-STARTED             VALUE 'N'.
           05  WS-CTRL-AVAIL-SW     PIC X(01) VALUE 'N'.
               88  CTRL-AVAILABLE            VALUE 'Y'.
               88  CTRL-MISSING              VALUE 'N'.
           05  WS-FILTER-ON         PIC X(01) VALUE 'N'.
               88  FILTER-ACTIVE             VALUE 'Y'.
      *----------------------------------------------------------------*
      *  Per-account work fields and the id builder.                   *
      *----------------------------------------------------------------*
       01  WS-CALC.
           05  WS-CO-THRESHOLD      PIC S9(10)V99 VALUE ZEROS.
           05  WS-OLD-BAL           PIC S9(10)V99 VALUE ZEROS.
           05  WS-OLD-STATUS        PIC X(01)     VALUE SPACES.
           05  WS-FILTER-ACCT       PIC 9(11)     VALUE ZEROS.
           05  WS-NEXT-ID-NUM       PIC 9(14)     VALUE ZEROS.
       01  WS-ID-BUILD.
           05  WS-IB-PREFIX         PIC X(02).
           05  WS-IB-SEQ            PIC 9(14).
      *----------------------------------------------------------------*
      *  Processing timestamp (X(26)) built from CURRENT-DATE.         *
      *----------------------------------------------------------------*
       01  WS-CURR-RAW              PIC X(21) VALUE SPACES.
       01  WS-CDT.
           05  WS-CDT-YEAR          PIC 9(04).
           05  WS-CDT-MON           PIC 9(02).
           05  WS-CDT-DAY           PIC 9(02).
           05  WS-CDT-HH            PIC 9(02).
           05  WS-CDT-MM            PIC 9(02).
           05  WS-CDT-SS            PIC 9(02).
       01  WS-PROC-TS.
           05  PT-YEAR              PIC 9(04).
           05  FILLER               PIC X(01) VALUE '-'.
           05  PT-MON               PIC 9(02).
           05  FILLER               PIC X(01) VALUE '-'.
           05  PT-DAY               PIC 9(02).
           05  FILLER               PIC X(01) VALUE '-'.
           05  PT-HH                PIC 9(02).
           05  FILLER               PIC X(01) VALUE '.'.
           05  PT-MM                PIC 9(02).
           05  FILLER               PIC X(01) VALUE '.'.
           05  PT-SS                PIC 9(02).
           05  FILLER               PIC X(07) VALUE '.000000'.
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RACCT.
       COPY RTRAN.
       COPY RCTRL.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KOPS.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN : overlay request, load counter, browse, return.    *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KOPS-AREA TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INITIALISE.
           PERFORM 1500-LOAD-COUNTER.
           PERFORM 3000-BROWSE-DRIVER.
           PERFORM 5500-SAVE-COUNTER.
           PERFORM 9000-FINALISE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INITIALISE : clear results, build timestamp, note filter.*
      *----------------------------------------------------------------*
       1000-INITIALISE.
           SET KO-OK TO TRUE.
           MOVE SPACES TO KO-STATUS-MSG.
           MOVE ZEROS TO KO-READ-CNT.
           MOVE ZEROS TO KO-SELECT-CNT.
           MOVE ZEROS TO KO-UPDATE-CNT.
           MOVE ZEROS TO KO-POSTED-CNT.
           MOVE ZEROS TO KO-REJECT-CNT.
           MOVE ZEROS TO KO-SKIP-CNT.
           MOVE ZEROS TO KO-TRAN-CNT.
           MOVE ZEROS TO KO-C1.
           MOVE ZEROS TO KO-C2.
           MOVE ZEROS TO KO-C3.
           MOVE ZEROS TO KO-AMT-1.
           MOVE ZEROS TO KO-AMT-2.
           MOVE ZEROS TO KO-AMT-3.
           MOVE 'N' TO WS-FILTER-ON.
           IF KO-PARM-ACCT > ZERO
               MOVE KO-PARM-ACCT TO WS-FILTER-ACCT
               SET FILTER-ACTIVE TO TRUE
           END-IF.
           MOVE FUNCTION CURRENT-DATE TO WS-CURR-RAW.
           MOVE WS-CURR-RAW(1:14) TO WS-CDT.
           MOVE WS-CDT-YEAR TO PT-YEAR.
           MOVE WS-CDT-MON  TO PT-MON.
           MOVE WS-CDT-DAY  TO PT-DAY.
           MOVE WS-CDT-HH   TO PT-HH.
           MOVE WS-CDT-MM   TO PT-MM.
           MOVE WS-CDT-SS   TO PT-SS.
           SET BR-MORE TO TRUE.
           SET BR-NOT-STARTED TO TRUE.
      *----------------------------------------------------------------*
      *  1500-LOAD-COUNTER : read the current TRANID sequence value.   *
      *----------------------------------------------------------------*
       1500-LOAD-COUNTER.
           MOVE WS-CTRL-KEY-ID TO CT-KEY.
      *    READ ... UPDATE holds the CTRLFILE lock for the whole task so
      *    concurrent runs cannot mint overlapping TRANIDs (see OUPAY).
           EXEC CICS READ
                     FILE(WS-CTRLFILE)
                     INTO(CTRL-REC)
                     RIDFLD(CT-KEY)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               MOVE CT-LAST-VALUE TO WS-NEXT-ID-NUM
               SET CTRL-AVAILABLE TO TRUE
           ELSE
               MOVE ZEROS TO WS-NEXT-ID-NUM
               SET CTRL-MISSING TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  3000-BROWSE-DRIVER : browse accounts and charge off.          *
      *----------------------------------------------------------------*
       3000-BROWSE-DRIVER.
           PERFORM 3100-START-BROWSE.
           IF BR-STARTED
               PERFORM 3200-READ-NEXT-ACCT
               PERFORM 4000-PROCESS-ACCT
                   UNTIL BR-END OR KO-ERROR
               PERFORM 3400-END-BROWSE
           END-IF.
      *----------------------------------------------------------------*
      *  3100-START-BROWSE : STARTBR at filter key or file start.      *
      *----------------------------------------------------------------*
       3100-START-BROWSE.
           IF FILTER-ACTIVE
               MOVE WS-FILTER-ACCT TO AC-ID
           ELSE
               MOVE ZEROS TO AC-ID
           END-IF.
           EXEC CICS STARTBR
                     FILE(WS-ACCTFILE)
                     RIDFLD(AC-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BR-STARTED TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET BR-END TO TRUE
                   MOVE 'NO ACCOUNTS TO PROCESS.' TO KO-STATUS-MSG
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'STARTBR ACCTFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-READ-NEXT-ACCT : read one account forward.               *
      *----------------------------------------------------------------*
       3200-READ-NEXT-ACCT.
           EXEC CICS READNEXT
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KO-READ-CNT
               WHEN DFHRESP(ENDFILE)
                   SET BR-END TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'READNEXT ACCTFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-PROCESS-ACCT : test the charge-off rule and act.         *
      *----------------------------------------------------------------*
       4000-PROCESS-ACCT.
           IF FILTER-ACTIVE AND AC-ID NOT = WS-FILTER-ACCT
               SET BR-END TO TRUE
           ELSE
               IF AC-ACTIVE-STATUS = 'Y' AND AC-CURR-BAL > ZERO
                   COMPUTE WS-CO-THRESHOLD =
                       AC-CREDIT-LIMIT * WS-CO-FACTOR
                   IF AC-CURR-BAL > WS-CO-THRESHOLD
                      AND AC-CYC-CREDIT = ZERO
                       PERFORM 4100-CHARGE-OFF
                   END-IF
               END-IF
               PERFORM 3200-READ-NEXT-ACCT
           END-IF.
      *----------------------------------------------------------------*
      *  4100-CHARGE-OFF : post the adjustment then flag the account.  *
      *----------------------------------------------------------------*
       4100-CHARGE-OFF.
           MOVE AC-CURR-BAL      TO WS-OLD-BAL.
           MOVE AC-ACTIVE-STATUS TO WS-OLD-STATUS.
           ADD 1 TO WS-NEXT-ID-NUM.
           PERFORM 4200-POST-ADJUSTMENT.
           PERFORM 4300-UPDATE-ACCT.
      *----------------------------------------------------------------*
      *  4200-POST-ADJUSTMENT : WRITE the reversing charge-off tran.   *
      *----------------------------------------------------------------*
       4200-POST-ADJUSTMENT.
           MOVE WS-ID-PREFIX   TO WS-IB-PREFIX.
           MOVE WS-NEXT-ID-NUM TO WS-IB-SEQ.
           INITIALIZE TRAN-REC.
           MOVE WS-ID-BUILD TO TR-ID.
           MOVE 'CO'        TO TR-TYPE-CD.
           MOVE 0000        TO TR-CAT-CD.
           MOVE 'CHGOFF'    TO TR-SOURCE.
           MOVE 'CHARGE-OFF ADJUSTMENT - BALANCE WRITTEN OFF'
               TO TR-DESC.
           COMPUTE TR-AMT = WS-OLD-BAL * -1.
           MOVE ZEROS       TO TR-MERCHANT-ID.
           MOVE 'INTERNAL ADJUSTMENT' TO TR-MERCHANT-NAME.
           MOVE SPACES      TO TR-MERCHANT-CITY.
           MOVE SPACES      TO TR-MERCHANT-ZIP.
           MOVE SPACES      TO TR-CARD-NUM.
           MOVE WS-PROC-TS  TO TR-ORIG-TS.
           MOVE WS-PROC-TS  TO TR-PROC-TS.
           EXEC CICS WRITE
                     FILE(WS-TRANFILE)
                     FROM(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KO-TRAN-CNT
           END-IF.
      *----------------------------------------------------------------*
      *  4300-UPDATE-ACCT : READ for UPDATE, flag 'C', zero, REWRITE.  *
      *----------------------------------------------------------------*
       4300-UPDATE-ACCT.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               ADD 1 TO KO-REJECT-CNT
               GO TO 4300-EXIT
           END-IF.
           MOVE 'C'  TO AC-ACTIVE-STATUS.
           MOVE ZERO TO AC-CURR-BAL.
           MOVE ZERO TO AC-CYC-DEBIT.
           EXEC CICS REWRITE
                     FILE(WS-ACCTFILE)
                     FROM(ACCT-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KO-SELECT-CNT
               ADD 1 TO KO-POSTED-CNT
               ADD 1 TO KO-UPDATE-CNT
               ADD WS-OLD-BAL TO KO-AMT-1
           ELSE
               ADD 1 TO KO-REJECT-CNT
           END-IF.
       4300-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3400-END-BROWSE : release the account browse.                 *
      *----------------------------------------------------------------*
       3400-END-BROWSE.
           IF BR-STARTED
               EXEC CICS ENDBR
                         FILE(WS-ACCTFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
      *----------------------------------------------------------------*
      *  5500-SAVE-COUNTER : persist the advanced TRANID counter.      *
      *----------------------------------------------------------------*
       5500-SAVE-COUNTER.
           IF KO-TRAN-CNT = ZERO
               GO TO 5500-EXIT
           END-IF.
           MOVE WS-CTRL-KEY-ID TO CT-KEY.
           EXEC CICS READ
                     FILE(WS-CTRLFILE)
                     INTO(CTRL-REC)
                     RIDFLD(CT-KEY)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               MOVE WS-NEXT-ID-NUM TO CT-LAST-VALUE
               EXEC CICS REWRITE
                         FILE(WS-CTRLFILE)
                         FROM(CTRL-REC)
                         RESP(WS-RESP-CD)
               END-EXEC
           ELSE
               MOVE WS-CTRL-KEY-ID TO CT-KEY
               MOVE WS-NEXT-ID-NUM TO CT-LAST-VALUE
               MOVE 'TRAN ID COUNTER' TO CT-DESC
               EXEC CICS WRITE
                         FILE(WS-CTRLFILE)
                         FROM(CTRL-REC)
                         RIDFLD(CT-KEY)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
       5500-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  9000-FINALISE : set the completion status message.            *
      *----------------------------------------------------------------*
       9000-FINALISE.
           IF KO-ERROR
               CONTINUE
           ELSE
               IF KO-REJECT-CNT > 0
                   SET KO-WARN TO TRUE
               ELSE
                   SET KO-OK TO TRUE
               END-IF
               MOVE 'CHARGE-OFF PROCESSING COMPLETE.' TO KO-STATUS-MSG
           END-IF.
