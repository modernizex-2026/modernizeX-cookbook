      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUPAY   -  Payment / bill posting SUB             *
      *  TYPE    : SUB  (CICS file control)                          *
      *  FUNCTION: post one bill payment against an account on        *
      *            demand.  Validates the amount and the account      *
      *            (must exist and be active), READs the account for  *
      *            UPDATE, reduces the current balance and raises the *
      *            cycle credit bucket, REWRITEs the account, draws a  *
      *            bill-id from the control file (CTRLFILE key        *
      *            'BILLID') and WRITEs a posted bill record          *
      *            (BILLFILE) carrying a confirmation number.  Ports  *
      *            the payment posters OBPAY (VSAM) and ODBILL (DB2). *
      *  CALL    : EXEC CICS LINK PROGRAM('OUPAY')                    *
      *                COMMAREA(ORION-COMMAREA) END-EXEC.             *
      *  REQUEST : KO-PARM-ACCT account id ; KO-PARM-AMT amount ;      *
      *            KO-PARM-DATE optional pay date (else run date).    *
      *  RESULT  : KO-POSTED 1 when posted   KO-REJECT 1 when refused *
      *            KO-C1 assigned bill id    KO-AMT-1 amount posted    *
      *            KO-AMT-2 new balance.                              *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUPAY.
       AUTHOR.     ORION-CCMS-ONLINE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and constants.                               *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUPAY'.
           05  WS-BILL-KEY          PIC X(08) VALUE 'BILLID  '.
      *----------------------------------------------------------------*
      *  Control switches for the single-payment unit of work.         *
      *----------------------------------------------------------------*
       01  WS-FLAGS.
           05  WS-REJECT-SW         PIC X(01) VALUE 'N'.
               88  REJECTED                   VALUE 'Y'.
               88  NOT-REJECTED               VALUE 'N'.
           05  WS-ACCT-LOCK-SW      PIC X(01) VALUE 'N'.
               88  ACCT-LOCKED                VALUE 'Y'.
               88  ACCT-FREE                  VALUE 'N'.
           05  WS-CTRL-AVAIL-SW     PIC X(01) VALUE 'N'.
               88  CTRL-AVAILABLE             VALUE 'Y'.
               88  CTRL-MISSING               VALUE 'N'.
      *----------------------------------------------------------------*
      *  Sequence, confirm-number and balance work fields.             *
      *----------------------------------------------------------------*
       01  WS-CALC.
           05  WS-BILL-SEQ          PIC 9(11) VALUE ZEROS.
           05  WS-NEW-BAL           PIC S9(10)V99 VALUE ZEROS.
           05  WS-PAY-DATE          PIC X(10) VALUE SPACES.
       01  WS-CONFIRM.
           05  FILLER               PIC X(03) VALUE 'CFM'.
           05  WS-CFM-SEQ           PIC 9(13) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Current date work area (for the default pay date).            *
      *----------------------------------------------------------------*
       01  WS-CURR-RAW              PIC X(21) VALUE SPACES.
       01  WS-CURR-DATE.
           05  WC-YEAR              PIC 9(04).
           05  FILLER               PIC X(01) VALUE '-'.
           05  WC-MON               PIC 9(02).
           05  FILLER               PIC X(01) VALUE '-'.
           05  WC-DAY               PIC 9(02).
       01  WS-CURR-N.
           05  WCN-YEAR             PIC 9(04).
           05  WCN-MON              PIC 9(02).
           05  WCN-DAY              PIC 9(02).
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RACCT.
       COPY RBILL.
       COPY RCTRL.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KOPS.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN : overlay the request, post the payment, return.    *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KOPS-AREA TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INITIALISE.
           PERFORM 2000-POST-PAYMENT.
           PERFORM 9000-FINALISE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INITIALISE : clear the result half and derive the date.  *
      *----------------------------------------------------------------*
       1000-INITIALISE.
           SET KO-OK TO TRUE.
           MOVE SPACES TO KO-STATUS-MSG.
           MOVE ZEROS TO KO-READ-CNT.
           MOVE ZEROS TO KO-SELECT-CNT.
           MOVE ZEROS TO KO-UPDATE-CNT.
           MOVE ZEROS TO KO-POSTED-CNT.
           MOVE ZEROS TO KO-REJECT-CNT.
           MOVE ZEROS TO KO-SKIP-CNT.
           MOVE ZEROS TO KO-TRAN-CNT.
           MOVE ZEROS TO KO-C1.
           MOVE ZEROS TO KO-C2.
           MOVE ZEROS TO KO-C3.
           MOVE ZEROS TO KO-AMT-1.
           MOVE ZEROS TO KO-AMT-2.
           MOVE ZEROS TO KO-AMT-3.
           SET NOT-REJECTED TO TRUE.
           SET ACCT-FREE TO TRUE.
           MOVE FUNCTION CURRENT-DATE TO WS-CURR-RAW.
           MOVE WS-CURR-RAW(1:8) TO WS-CURR-N.
           MOVE WCN-YEAR TO WC-YEAR.
           MOVE WCN-MON  TO WC-MON.
           MOVE WCN-DAY  TO WC-DAY.
           IF KO-PARM-DATE = SPACES OR KO-PARM-DATE = LOW-VALUES
               MOVE WS-CURR-DATE TO WS-PAY-DATE
           ELSE
               MOVE KO-PARM-DATE TO WS-PAY-DATE
           END-IF.
      *----------------------------------------------------------------*
      *  2000-POST-PAYMENT : validate then apply the payment.          *
      *----------------------------------------------------------------*
       2000-POST-PAYMENT.
           PERFORM 2050-VALIDATE-REQUEST.
           IF NOT-REJECTED
               PERFORM 2100-READ-ACCT-UPD
           END-IF.
           IF NOT-REJECTED
               PERFORM 2200-GET-SEQUENCE
           END-IF.
           IF NOT-REJECTED
               PERFORM 2300-CREDIT-ACCOUNT
           END-IF.
           IF NOT-REJECTED
               PERFORM 2400-WRITE-BILL
           END-IF.
           IF NOT-REJECTED
               PERFORM 2500-SAVE-SEQUENCE
           END-IF.
           IF REJECTED AND ACCT-LOCKED
               PERFORM 2900-UNLOCK-ACCT
           END-IF.
      *----------------------------------------------------------------*
      *  2050-VALIDATE-REQUEST : amount and account id must be valid.  *
      *----------------------------------------------------------------*
       2050-VALIDATE-REQUEST.
           IF KO-PARM-AMT <= ZERO
               SET REJECTED TO TRUE
               ADD 1 TO KO-REJECT-CNT
               MOVE 'PAYMENT AMOUNT MUST BE POSITIVE.' TO KO-STATUS-MSG
           END-IF.
           IF NOT-REJECTED AND KO-PARM-ACCT = ZERO
               SET REJECTED TO TRUE
               ADD 1 TO KO-REJECT-CNT
               MOVE 'ACCOUNT ID IS REQUIRED.' TO KO-STATUS-MSG
           END-IF.
      *----------------------------------------------------------------*
      *  2100-READ-ACCT-UPD : READ the account for UPDATE and check    *
      *  that it exists and is active.                                 *
      *----------------------------------------------------------------*
       2100-READ-ACCT-UPD.
           MOVE KO-PARM-ACCT TO AC-ID.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KO-READ-CNT
                   SET ACCT-LOCKED TO TRUE
                   IF AC-ACTIVE-STATUS = 'N'
                       SET REJECTED TO TRUE
                       ADD 1 TO KO-REJECT-CNT
                       MOVE 'ACCOUNT IS NOT ACTIVE.' TO KO-STATUS-MSG
                   END-IF
               WHEN DFHRESP(NOTFND)
                   SET REJECTED TO TRUE
                   ADD 1 TO KO-REJECT-CNT
                   MOVE 'ACCOUNT NOT FOUND.' TO KO-STATUS-MSG
               WHEN OTHER
                   SET REJECTED TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'READ ACCTFILE FOR UPDATE FAILED.'
                       TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2200-GET-SEQUENCE : read (for update) the bill-id counter.    *
      *----------------------------------------------------------------*
       2200-GET-SEQUENCE.
           MOVE WS-BILL-KEY TO CT-KEY.
           EXEC CICS READ
                     FILE(WS-CTRLFILE)
                     INTO(CTRL-REC)
                     RIDFLD(CT-KEY)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE CT-LAST-VALUE TO WS-BILL-SEQ
                   SET CTRL-AVAILABLE TO TRUE
               WHEN DFHRESP(NOTFND)
                   MOVE ZEROS TO WS-BILL-SEQ
                   SET CTRL-MISSING TO TRUE
               WHEN OTHER
                   SET REJECTED TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'READ CTRLFILE BILLID FAILED.'
                       TO KO-STATUS-MSG
           END-EVALUATE.
           IF NOT-REJECTED
               ADD 1 TO WS-BILL-SEQ
           END-IF.
      *----------------------------------------------------------------*
      *  2300-CREDIT-ACCOUNT : reduce the balance and REWRITE ACCT.    *
      *----------------------------------------------------------------*
       2300-CREDIT-ACCOUNT.
           SUBTRACT KO-PARM-AMT FROM AC-CURR-BAL.
           ADD KO-PARM-AMT TO AC-CYC-CREDIT.
           MOVE AC-CURR-BAL TO WS-NEW-BAL.
           EXEC CICS REWRITE
                     FILE(WS-ACCTFILE)
                     FROM(ACCT-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               SET ACCT-FREE TO TRUE
           ELSE
               SET REJECTED TO TRUE
               SET KO-ERROR TO TRUE
               MOVE 'REWRITE ACCTFILE FAILED.' TO KO-STATUS-MSG
           END-IF.
      *----------------------------------------------------------------*
      *  2400-WRITE-BILL : build and WRITE the posted bill record.     *
      *----------------------------------------------------------------*
       2400-WRITE-BILL.
           INITIALIZE BILL-REC.
           MOVE WS-BILL-SEQ  TO BL-ID.
           MOVE KO-PARM-ACCT TO BL-ACCT-ID.
           MOVE KO-PARM-AMT  TO BL-AMOUNT.
           MOVE WS-PAY-DATE  TO BL-PAY-DATE.
           MOVE WS-BILL-SEQ  TO WS-CFM-SEQ.
           MOVE WS-CONFIRM   TO BL-CONFIRM-NUM.
           MOVE 'P'          TO BL-STATUS.
           EXEC CICS WRITE
                     FILE(WS-BILLFILE)
                     FROM(BILL-REC)
                     RIDFLD(BL-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KO-POSTED-CNT
                   ADD 1 TO KO-TRAN-CNT
                   MOVE WS-BILL-SEQ TO KO-C1
                   MOVE KO-PARM-AMT TO KO-AMT-1
                   MOVE WS-NEW-BAL  TO KO-AMT-2
               WHEN OTHER
                   SET REJECTED TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'WRITE BILLFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2500-SAVE-SEQUENCE : persist the advanced bill-id counter.    *
      *----------------------------------------------------------------*
       2500-SAVE-SEQUENCE.
           IF CTRL-AVAILABLE
               MOVE WS-BILL-SEQ TO CT-LAST-VALUE
               EXEC CICS REWRITE
                         FILE(WS-CTRLFILE)
                         FROM(CTRL-REC)
                         RESP(WS-RESP-CD)
               END-EXEC
           ELSE
               MOVE WS-BILL-KEY TO CT-KEY
               MOVE WS-BILL-SEQ TO CT-LAST-VALUE
               MOVE 'BILL ID SEQUENCE' TO CT-DESC
               EXEC CICS WRITE
                         FILE(WS-CTRLFILE)
                         FROM(CTRL-REC)
                         RIDFLD(CT-KEY)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               MOVE 'PAYMENT POSTED, COUNTER UPDATE WARNING.'
                   TO KO-STATUS-MSG
               SET KO-WARN TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  2900-UNLOCK-ACCT : release the account held for update.       *
      *----------------------------------------------------------------*
       2900-UNLOCK-ACCT.
           EXEC CICS UNLOCK
                     FILE(WS-ACCTFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
           SET ACCT-FREE TO TRUE.
      *----------------------------------------------------------------*
      *  9000-FINALISE : set the completion status message.            *
      *----------------------------------------------------------------*
       9000-FINALISE.
           IF KO-ERROR
               CONTINUE
           ELSE
               IF KO-POSTED-CNT > 0
                   IF NOT KO-WARN
                       SET KO-OK TO TRUE
                       MOVE 'PAYMENT POSTED SUCCESSFULLY.'
                           TO KO-STATUS-MSG
                   END-IF
               ELSE
                   SET KO-WARN TO TRUE
                   IF KO-STATUS-MSG = SPACES
                       MOVE 'PAYMENT REJECTED.' TO KO-STATUS-MSG
                   END-IF
               END-IF
           END-IF.
