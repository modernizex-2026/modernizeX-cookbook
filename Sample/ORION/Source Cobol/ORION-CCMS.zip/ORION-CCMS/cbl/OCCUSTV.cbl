      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCCUSTV  -  Customer View (on-line)               *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: accept a customer id, read the customer master    *
      *            (CUSTFILE) and display the customer name, mailing  *
      *            address, city, primary phone and FICO score.       *
      *            PF3 = back to menu, PF4 = clear, ENTER = read.     *
      *  MAPSET  : MCUSTV      MAP : MCUSTVA     TRANID : ORUV        *
      *  FILES   : CUSTFILE (read only, keyed on CU-ID)              *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.       *
      *****************************************************************
      *  MAINTENANCE LOG                                              *
      *  ----  ----------  --------------------------------------     *
      *  0001  2026-08-07  Original - customer inquiry screen.        *
      *****************************************************************
      *  PROCESSING NARRATIVE                                         *
      *  1. First entry (no COMMAREA / context 0) shows an empty      *
      *     screen prompting for a customer id.                       *
      *  2. On ENTER the id is edited (present + numeric) and the     *
      *     customer master record is read by key.                   *
      *  3. When the record is found the detail fields are formatted  *
      *     and returned to the operator; otherwise a not-found       *
      *     message is issued.                                        *
      *  4. PF3 transfers control back to the main menu (OCMENU);     *
      *     PF4 clears the screen back to the initial prompt.         *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCCUSTV.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identification and navigation constants               *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCCUSTV'.
           05  WS-TRANID            PIC X(04) VALUE 'ORUV'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Work and formatting fields local to this program              *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-FULL-NAME         PIC X(50) VALUE SPACES.
           05  WS-IN-CUST-ID        PIC 9(09) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Generic numeric-string edit work area                         *
      *----------------------------------------------------------------*
       01  WS-VALIDATION.
           05  WS-VAL-STR           PIC X(20) VALUE SPACES.
           05  WS-VAL-LEN           PIC 9(02) VALUE ZEROS.
           05  WS-VAL-I             PIC 9(02) VALUE ZEROS.
           05  WS-VAL-CH            PIC X(01) VALUE SPACE.
           05  WS-VAL-DIGITS        PIC 9(02) VALUE ZEROS.
           05  WS-VAL-OK            PIC X(01) VALUE 'Y'.
               88  WS-VAL-GOOD                VALUE 'Y'.
               88  WS-VAL-BAD                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Program specific operator messages                            *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter a customer id and press ENTER.'.
           05  WS-M-CUST-FOUND      PIC X(50)
               VALUE 'Customer details displayed.'.
           05  WS-M-CUST-NOTFND     PIC X(50)
               VALUE 'Customer not found - check the id and retry.'.
           05  WS-M-ID-REQUIRED     PIC X(50)
               VALUE 'Customer id is required.'.
           05  WS-M-ID-NOTNUM       PIC X(50)
               VALUE 'Customer id must be numeric.'.
           05  WS-M-READ-ERROR      PIC X(50)
               VALUE 'Error reading the customer file.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea      *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  File record layout and BMS symbolic map                       *
      *----------------------------------------------------------------*
       COPY RCUST.
       COPY MCUSTV.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants             *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.
      *  Decide between first-time display and re-entry processing on
      *  the basis of EIBCALEN and the saved program context flag.
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh empty screen.
      *  Clears the symbolic map, loads the standard header line, and
      *  prompts the operator to key a customer id.  ERASE is used so
      *  the whole 3270 screen is cleared before the map is written.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MCUSTVAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-M-PROMPT TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MCUSTVA')
                     MAPSET('MCUSTV')
                     FROM(MCUSTVAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.
      *  PF3  = return to the menu.
      *  PF4  = clear / refresh the screen.
      *  ENTER= read and display the requested customer.               *
      *  any other key produces the standard invalid-key message.      *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-READ-AND-SHOW
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-READ-AND-SHOW  -  receive the map, validate the key and
      *  drive the read/format/display of the customer record.         *
      *----------------------------------------------------------------*
       2100-READ-AND-SHOW.
           EXEC CICS RECEIVE
                     MAP('MCUSTVA')
                     MAPSET('MCUSTV')
                     INTO(MCUSTVAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           PERFORM 2200-EDIT-CUST-ID.
           IF ERR-FLG-ON
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE WS-IN-CUST-ID TO CU-ID
               MOVE CU-ID         TO CA-CUST-ID
               PERFORM 3000-READ-CUST
               EVALUATE TRUE
                   WHEN REC-FOUND
                       PERFORM 4000-POPULATE-DETAIL
                       MOVE WS-M-CUST-FOUND TO ERRMSGO
                       PERFORM 8100-SEND-DATAONLY
                   WHEN OTHER
                       MOVE WS-M-CUST-NOTFND TO ERRMSGO
                       PERFORM 8100-SEND-DATAONLY
               END-EVALUATE
           END-IF.
      *----------------------------------------------------------------*
      *  2200-EDIT-CUST-ID  -  validate the customer id map field.
      *  The field must be present and, after removing pad characters,
      *  must consist only of decimal digits.  The clean numeric value
      *  is left in WS-IN-CUST-ID for the file read.
      *----------------------------------------------------------------*
       2200-EDIT-CUST-ID.
           SET ERR-FLG-OFF TO TRUE.
           MOVE ZEROS TO WS-IN-CUST-ID.
           IF CUSTIDI = SPACES OR CUSTIDI = LOW-VALUES
               SET ERR-FLG-ON TO TRUE
               MOVE WS-M-ID-REQUIRED TO ERRMSGO
           ELSE
               MOVE SPACES     TO WS-VAL-STR
               MOVE CUSTIDI    TO WS-VAL-STR
               MOVE 9          TO WS-VAL-LEN
               PERFORM 7600-VALIDATE-NUM
               IF WS-VAL-GOOD
                   COMPUTE WS-IN-CUST-ID =
                       FUNCTION NUMVAL(WS-VAL-STR(1:WS-VAL-LEN))
               ELSE
                   SET ERR-FLG-ON TO TRUE
                   MOVE WS-M-ID-NOTNUM TO ERRMSGO
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3000-READ-CUST  -  read CUSTFILE by primary key CU-ID.        *
      *  Sets the found switch and maps every CICS response into a
      *  meaningful operator message when the read is not normal.
      *----------------------------------------------------------------*
       3000-READ-CUST.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-CUSTFILE)
                     INTO(CUST-REC)
                     RIDFLD(CU-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   MOVE WS-M-READ-ERROR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-POPULATE-DETAIL  -  move the record fields into the map.
      *  The mailing name is assembled from first and last name; the
      *  numeric FICO score is moved into the alphanumeric map field.
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE CU-ID            TO CUSTIDO.
           PERFORM 4100-FORMAT-NAME.
           MOVE WS-FULL-NAME     TO CUNAMEO.
           MOVE CU-ADDR-LINE-1   TO CUADDRO.
           MOVE CU-ADDR-CITY     TO CUCITYO.
           MOVE CU-PHONE-1       TO CUPHONEO.
           MOVE CU-FICO-SCORE    TO CUFICOO.
      *----------------------------------------------------------------*
      *  4100-FORMAT-NAME  -  build "first last" into WS-FULL-NAME.
      *  Trailing blanks are stripped from each part with DELIMITED BY
      *  SPACE so the two names are separated by a single space.
      *----------------------------------------------------------------*
       4100-FORMAT-NAME.
           MOVE SPACES TO WS-FULL-NAME.
           STRING CU-FIRST-NAME  DELIMITED BY SPACE
                  ' '            DELIMITED BY SIZE
                  CU-LAST-NAME   DELIMITED BY SPACE
                  INTO WS-FULL-NAME
           END-STRING.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.
      *  The program context is reset to first-enter so OCMENU shows
      *  its initial panel, and the from-program trail is recorded.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  7600-VALIDATE-NUM  -  generic numeric string editor.          *
      *  Input : WS-VAL-STR / WS-VAL-LEN.                              *
      *  Output: WS-VAL-GOOD when the field holds at least one digit
      *          and contains only digits and blanks (nulls are first
      *          translated to blanks so short 3270 input is allowed).
      *----------------------------------------------------------------*
       7600-VALIDATE-NUM.
           SET WS-VAL-GOOD TO TRUE.
           MOVE ZEROS TO WS-VAL-DIGITS.
           INSPECT WS-VAL-STR(1:WS-VAL-LEN)
               REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-VAL-I FROM 1 BY 1
                   UNTIL WS-VAL-I > WS-VAL-LEN
               MOVE WS-VAL-STR(WS-VAL-I:1) TO WS-VAL-CH
               IF WS-VAL-CH = SPACE
                   CONTINUE
               ELSE
                   IF WS-VAL-CH >= '0' AND WS-VAL-CH <= '9'
                       ADD 1 TO WS-VAL-DIGITS
                   ELSE
                       SET WS-VAL-BAD TO TRUE
                   END-IF
               END-IF
           END-PERFORM.
           IF WS-VAL-DIGITS = ZEROS
               SET WS-VAL-BAD TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.
      *  Transaction id, program name, system title and the current
      *  date and time are moved into the map header fields.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  re-transmit the map data only.         *
      *  Used after the initial screen has been painted so the 3270
      *  buffer is updated without an ERASE (faster, no flicker).
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MCUSTVA')
                     MAPSET('MCUSTV')
                     FROM(MCUSTVAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *  ASKTIME loads the absolute time; FORMATTIME renders it into
      *  the display header work fields in YYYY-MM-DD and HH:MM:SS.
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to CICS.         *
      *  Control is returned specifying our own transaction id so the
      *  next operator action re-drives this program with the COMMAREA.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
