      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCUSRA   -  User Add (on-line)                   *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: accept a new user id, first name, last name,       *
      *            password and type, validate every field and write  *
      *            the record to the user security file (USRSEC).     *
      *            A duplicate id is rejected (DUPREC).               *
      *  MAP     : MUSRAA of mapset MUSRA.                           *
      *  TRANID  : ORUA.  PF3 = admin menu, PF4 = clear, ENTER = add. *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCUSRA.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identification constants.                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCUSRA'.
           05  WS-TRANID            PIC X(04) VALUE 'ORUA'.
           05  WS-ADMEN-PGM         PIC X(08) VALUE 'OCADMEN'.
      *----------------------------------------------------------------*
      *  Validation work fields.                                       *
      *----------------------------------------------------------------*
       01  WS-EDIT-WORK.
           05  WS-EDIT-FLG          PIC X(01) VALUE 'Y'.
               88  WS-INPUT-OK               VALUE 'Y'.
               88  WS-INPUT-BAD              VALUE 'N'.
           05  WS-TYPE-IN           PIC X(01) VALUE SPACES.
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RUSER.
       COPY MUSRA.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN : pseudo-conversational entry point.                *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               MOVE SPACES      TO CA-ERR-MSG
               IF CA-FIRST-ENTER
                   PERFORM 1000-SEND-INITIAL
               ELSE
                   PERFORM 2000-PROCESS-INPUT
               END-IF
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL : paint an empty add screen.               *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MUSRAAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter new user details and press ENTER.'
               TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MUSRAA')
                     MAPSET('MUSRA')
                     FROM(MUSRAAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT : dispatch on the AID key.                 *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-ADMEN
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-ADD-USER
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-ADD-USER : receive the map, validate and, when valid,    *
      *  write the new user.                                          *
      *----------------------------------------------------------------*
       2100-ADD-USER.
           PERFORM 2110-RECEIVE-MAP.
           PERFORM 2120-VALIDATE-INPUT.
           IF WS-INPUT-BAD
               PERFORM 4000-REPOPULATE
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 3000-WRITE-USER
               IF ERR-FLG-ON
                   PERFORM 4000-REPOPULATE
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   PERFORM 4100-CONFIRM-ADD
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2110-RECEIVE-MAP : read the entered user details.            *
      *----------------------------------------------------------------*
       2110-RECEIVE-MAP.
           EXEC CICS RECEIVE
                     MAP('MUSRAA')
                     MAPSET('MUSRA')
                     INTO(MUSRAAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  2120-VALIDATE-INPUT : every field is required and the type    *
      *  must be A (admin) or U (normal user).                        *
      *----------------------------------------------------------------*
       2120-VALIDATE-INPUT.
           SET WS-INPUT-OK TO TRUE.
           IF USERIDI = SPACES OR USERIDI = LOW-VALUES
               SET WS-INPUT-BAD TO TRUE
               MOVE 'User id is required.' TO ERRMSGO
               GO TO 2120-EXIT
           END-IF.
           IF USFNAMI = SPACES OR USFNAMI = LOW-VALUES
               SET WS-INPUT-BAD TO TRUE
               MOVE 'First name is required.' TO ERRMSGO
               GO TO 2120-EXIT
           END-IF.
           IF USLNAMI = SPACES OR USLNAMI = LOW-VALUES
               SET WS-INPUT-BAD TO TRUE
               MOVE 'Last name is required.' TO ERRMSGO
               GO TO 2120-EXIT
           END-IF.
           IF USPWDI = SPACES OR USPWDI = LOW-VALUES
               SET WS-INPUT-BAD TO TRUE
               MOVE 'Password is required.' TO ERRMSGO
               GO TO 2120-EXIT
           END-IF.
           MOVE USTYPEI TO WS-TYPE-IN
           IF WS-TYPE-IN NOT = 'A' AND WS-TYPE-IN NOT = 'U'
               SET WS-INPUT-BAD TO TRUE
               MOVE 'Type must be A (admin) or U (user).'
                   TO ERRMSGO
           END-IF.
       2120-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3000-WRITE-USER : build the user record and write it.  A      *
      *  duplicate id is reported back to the operator.               *
      *----------------------------------------------------------------*
       3000-WRITE-USER.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES  TO USER-REC.
           MOVE USERIDI TO US-ID.
           MOVE USFNAMI TO US-FIRST-NAME.
           MOVE USLNAMI TO US-LAST-NAME.
           MOVE USPWDI  TO US-PASSWORD.
           MOVE WS-TYPE-IN TO US-TYPE.
           EXEC CICS WRITE
                     FILE(WS-USRSEC)
                     FROM(USER-REC)
                     RIDFLD(US-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(DUPREC)
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'User id already exists.' TO ERRMSGO
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error writing user file.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-REPOPULATE : echo the operator input back to the map so  *
      *  it is not lost when an error is reported.                     *
      *----------------------------------------------------------------*
       4000-REPOPULATE.
           MOVE USERIDI TO USERIDO.
           MOVE USFNAMI TO USFNAMO.
           MOVE USLNAMI TO USLNAMO.
           MOVE USPWDI  TO USPWDO.
           MOVE USTYPEI TO USTYPEO.
      *----------------------------------------------------------------*
      *  4100-CONFIRM-ADD : report success and clear the input fields  *
      *  ready for the next user.                                     *
      *----------------------------------------------------------------*
       4100-CONFIRM-ADD.
           MOVE LOW-VALUES TO MUSRAAO.
           MOVE 'User added successfully.' TO ERRMSGO.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  7000-XCTL-ADMEN : return to the administrator menu.           *
      *----------------------------------------------------------------*
       7000-XCTL-ADMEN.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-ADMEN-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER : fill the standard screen header.       *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY : resend the map without erasing.          *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MUSRAA')
                     MAPSET('MUSRA')
                     FROM(MUSRAAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME : obtain the current date and time.        *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN : return pseudo-conversationally.                 *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
