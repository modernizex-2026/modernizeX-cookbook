      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUTRNIN  -  Transaction Inquiry browse / analytics *
      *  TYPE    : SUBROUTINE (EXEC CICS LINK from OCTRNIN)          *
      *  FUNCTION: browse the transaction master (TRANFILE) applying *
      *            a filter (card / date range / merchant / type +   *
      *            category / amount threshold) and return ONE page  *
      *            of matching transactions in the KTRNIN-AREA        *
      *            commarea, ALONG WITH the filter-wide analytics:    *
      *              - match count and net total          (OBTRSUM)  *
      *              - purchase / payment subtotals        (OBRTRAN)  *
      *              - fee subtotal                        (OBRFEE)   *
      *              - interest subtotal                   (OBRINC)   *
      *              - largest single transaction          (OBRTOP)   *
      *            The same figures serve the daily (OBRDAILY) and    *
      *            per-merchant (OBRMERCH) roll-ups by simply keying  *
      *            the date-range or merchant filter.                 *
      *            Each displayed row carries the TTYP/TCAT lookup    *
      *            description for its type and category.             *
      *  CALL    : EXEC CICS LINK PROGRAM('OUTRNIN')                 *
      *                COMMAREA(KTRNIN-AREA) END-EXEC.               *
      *  FILES   : TRANFILE (browse), TTYPFILE + TCATFILE (lookup)   *
      *****************************************************************
      *  DESIGN                                                       *
      *  ------                                                       *
      *  The full transaction file is scanned on every call so the    *
      *  analytics are genuine filter-wide totals (not just the page).*
      *  During the same pass the first WS-MAX-ROWS matches whose key *
      *  exceeds the resume key (KTI-START-KEY) are captured as the   *
      *  page; a further match sets the more-switch for PF8 paging.   *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUTRNIN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity.                                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUTRNIN'.
      *----------------------------------------------------------------*
      *  Browse control and work fields.                              *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-MAX-ROWS          PIC 9(02) VALUE 6.
           05  WS-LAST-KEY          PIC X(16) VALUE SPACES.
           05  WS-CAT-ED            PIC 9(04) VALUE ZEROS.
           05  WS-TYCAT             PIC X(07) VALUE SPACES.
           05  WS-DESC              PIC X(20) VALUE SPACES.
           05  WS-FIRST-SW          PIC X(01) VALUE 'Y'.
               88  WS-FIRST                   VALUE 'Y'.
               88  WS-NOT-FIRST               VALUE 'N'.
           05  WS-MATCH-SW          PIC X(01) VALUE 'N'.
               88  WS-MATCHED                 VALUE 'Y'.
               88  WS-NOT-MATCHED             VALUE 'N'.
      *----------------------------------------------------------------*
      *  Transaction-type codes used to classify the analytics.        *
      *----------------------------------------------------------------*
       01  WS-TYPE-CONSTS.
           05  WS-T-PURCH           PIC X(02) VALUE 'PU'.
           05  WS-T-PAY             PIC X(02) VALUE 'PY'.
           05  WS-T-FEE             PIC X(02) VALUE 'FE'.
           05  WS-T-INT             PIC X(02) VALUE 'IN'.
      *----------------------------------------------------------------*
      *  Shared constants (RESP fields, file names, switches).         *
      *----------------------------------------------------------------*
       COPY WCONST.
      *----------------------------------------------------------------*
      *  Record layouts : transaction browsed, type + category read.   *
      *----------------------------------------------------------------*
       COPY RTRAN.
       COPY RTTYP.
       COPY RTCAT.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
      *----------------------------------------------------------------*
      *  The transaction inquiry interface is the single area passed   *
      *  on LINK.  Request half in / response + rows + analytics out.  *
      *----------------------------------------------------------------*
       COPY KTRNIN.
      *================================================================*
       PROCEDURE DIVISION USING KTRNIN-AREA.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  top level driver.                              *
      *----------------------------------------------------------------*
       0000-MAIN.
           PERFORM 1000-INIT-RESPONSE.
           PERFORM 2000-BROWSE-TRANS.
           PERFORM 3000-FINALIZE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INIT-RESPONSE  -  clear the response half + analytics.  *
      *----------------------------------------------------------------*
       1000-INIT-RESPONSE.
           SET KTI-OK TO TRUE.
           MOVE ZEROS TO KTI-ROW-COUNT.
           MOVE ZEROS TO KTI-SCAN-COUNT.
           MOVE ZEROS TO KTI-MATCH-COUNT.
           MOVE ZEROS TO KTI-NET-TOTAL.
           MOVE ZEROS TO KTI-MAX-AMT.
           MOVE SPACES TO KTI-MAX-ID.
           MOVE ZEROS TO KTI-PURCH-CNT KTI-PURCH-SUM.
           MOVE ZEROS TO KTI-PAY-CNT   KTI-PAY-SUM.
           MOVE ZEROS TO KTI-FEE-CNT   KTI-FEE-SUM.
           MOVE ZEROS TO KTI-INT-CNT   KTI-INT-SUM.
           MOVE SPACES TO KTI-NEXT-KEY.
           SET KTI-NO-MORE TO TRUE.
           MOVE SPACES TO WS-LAST-KEY.
           SET WS-FIRST TO TRUE.
           SET WS-NOT-MATCHED TO TRUE.
           MOVE 'N' TO WS-END-FLG.
           INITIALIZE KTI-ROWS.
      *----------------------------------------------------------------*
      *  2000-BROWSE-TRANS  -  drive the sequential scan.            *
      *----------------------------------------------------------------*
       2000-BROWSE-TRANS.
           PERFORM 2100-START-BROWSE.
           IF NOT END-OF-FILE
               PERFORM 2200-READ-NEXT
                   UNTIL END-OF-FILE
               PERFORM 2300-END-BROWSE
           END-IF.
           IF KTI-ROW-COUNT > ZEROS
               MOVE WS-LAST-KEY TO KTI-NEXT-KEY
           END-IF.
      *----------------------------------------------------------------*
      *  2100-START-BROWSE  -  position at the start of the file.     *
      *----------------------------------------------------------------*
       2100-START-BROWSE.
           MOVE LOW-VALUES TO TR-ID.
           EXEC CICS STARTBR
                     FILE(WS-TRANFILE)
                     RIDFLD(TR-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(NOTFND)
                   SET END-OF-FILE TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET END-OF-FILE TO TRUE
               WHEN OTHER
                   SET END-OF-FILE TO TRUE
                   SET KTI-ERROR TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2200-READ-NEXT  -  read one transaction and process it.      *
      *----------------------------------------------------------------*
       2200-READ-NEXT.
           EXEC CICS READNEXT
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   PERFORM 2250-HANDLE-RECORD
               WHEN DFHRESP(ENDFILE)
                   SET END-OF-FILE TO TRUE
               WHEN OTHER
                   SET END-OF-FILE TO TRUE
                   SET KTI-ERROR TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2250-HANDLE-RECORD  -  filter, accumulate and (if on the      *
      *  requested page) capture the transaction as a display row.    *
      *----------------------------------------------------------------*
       2250-HANDLE-RECORD.
           ADD 1 TO KTI-SCAN-COUNT.
           PERFORM 2400-FILTER-CHECK.
           IF WS-MATCHED
               PERFORM 2700-ACCUMULATE
               IF TR-ID > KTI-START-KEY
                   IF KTI-ROW-COUNT < WS-MAX-ROWS
                       PERFORM 2500-STORE-ROW
                   ELSE
                       SET KTI-MORE TO TRUE
                   END-IF
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2300-END-BROWSE  -  release the browse position.             *
      *----------------------------------------------------------------*
       2300-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-TRANFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  2400-FILTER-CHECK  -  set WS-MATCHED for the active filter.   *
      *----------------------------------------------------------------*
       2400-FILTER-CHECK.
           SET WS-NOT-MATCHED TO TRUE.
           EVALUATE TRUE
               WHEN KTI-F-CARD
                   IF TR-CARD-NUM = KTI-CARD
                       SET WS-MATCHED TO TRUE
                   END-IF
               WHEN KTI-F-DATE
                   IF TR-PROC-TS(1:10) >= KTI-DATE-FROM
                      AND TR-PROC-TS(1:10) <= KTI-DATE-TO
                       SET WS-MATCHED TO TRUE
                   END-IF
               WHEN KTI-F-MERCH
                   IF TR-MERCHANT-ID = KTI-MERCH-ID
                       SET WS-MATCHED TO TRUE
                   END-IF
               WHEN KTI-F-TYPECAT
                   IF TR-TYPE-CD = KTI-F-TYPE
                      AND TR-CAT-CD = KTI-F-CAT
                       SET WS-MATCHED TO TRUE
                   END-IF
               WHEN KTI-F-AMOUNT
                   IF TR-AMT >= KTI-AMT-THRESH
                       SET WS-MATCHED TO TRUE
                   END-IF
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2500-STORE-ROW  -  copy the current transaction into the next *
      *  free display row, with its type/category description.        *
      *----------------------------------------------------------------*
       2500-STORE-ROW.
           ADD 1 TO KTI-ROW-COUNT.
           MOVE TR-ID TO WS-LAST-KEY.
           PERFORM 2600-LOOKUP-DESC.
           MOVE TR-ID            TO KTR-ID    (KTI-ROW-COUNT).
           MOVE TR-CARD-NUM      TO KTR-CARD  (KTI-ROW-COUNT).
           MOVE WS-TYCAT         TO KTR-TYCAT (KTI-ROW-COUNT).
           MOVE WS-DESC          TO KTR-DESC  (KTI-ROW-COUNT).
           MOVE TR-MERCHANT-NAME TO KTR-MERCH (KTI-ROW-COUNT).
           MOVE TR-AMT           TO KTR-AMT   (KTI-ROW-COUNT).
           MOVE TR-PROC-TS(1:10) TO KTR-DATE  (KTI-ROW-COUNT).
      *----------------------------------------------------------------*
      *  2600-LOOKUP-DESC  -  format the type/category code and read   *
      *  its description from TCATFILE, falling back to TTYPFILE.     *
      *----------------------------------------------------------------*
       2600-LOOKUP-DESC.
           MOVE TR-CAT-CD TO WS-CAT-ED.
           MOVE SPACES TO WS-TYCAT.
           STRING TR-TYPE-CD DELIMITED BY SIZE
                  '/'        DELIMITED BY SIZE
                  WS-CAT-ED  DELIMITED BY SIZE
                  INTO WS-TYCAT
           END-STRING.
           MOVE SPACES TO WS-DESC.
           MOVE TR-TYPE-CD TO TC-TYPE-CD.
           MOVE TR-CAT-CD  TO TC-CD.
           EXEC CICS READ
                     FILE(WS-TCATFILE)
                     INTO(TCAT-REC)
                     RIDFLD(TC-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               MOVE TC-DESC TO WS-DESC
           ELSE
               PERFORM 2650-LOOKUP-TYPE
           END-IF.
      *----------------------------------------------------------------*
      *  2650-LOOKUP-TYPE  -  fall back to the transaction-type text.  *
      *----------------------------------------------------------------*
       2650-LOOKUP-TYPE.
           MOVE TR-TYPE-CD TO TT-CD.
           EXEC CICS READ
                     FILE(WS-TTYPFILE)
                     INTO(TTYP-REC)
                     RIDFLD(TT-CD)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               MOVE TT-DESC TO WS-DESC
           ELSE
               MOVE 'UNKNOWN' TO WS-DESC
           END-IF.
      *----------------------------------------------------------------*
      *  2700-ACCUMULATE  -  update the filter-wide analytics for one  *
      *  matching transaction (net total, per-class subtotals, max).  *
      *----------------------------------------------------------------*
       2700-ACCUMULATE.
           ADD 1 TO KTI-MATCH-COUNT.
           ADD TR-AMT TO KTI-NET-TOTAL.
           EVALUATE TR-TYPE-CD
               WHEN WS-T-PURCH
                   ADD 1 TO KTI-PURCH-CNT
                   ADD TR-AMT TO KTI-PURCH-SUM
               WHEN WS-T-PAY
                   ADD 1 TO KTI-PAY-CNT
                   ADD TR-AMT TO KTI-PAY-SUM
               WHEN WS-T-FEE
                   ADD 1 TO KTI-FEE-CNT
                   ADD TR-AMT TO KTI-FEE-SUM
               WHEN WS-T-INT
                   ADD 1 TO KTI-INT-CNT
                   ADD TR-AMT TO KTI-INT-SUM
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
           IF WS-FIRST
               MOVE TR-AMT TO KTI-MAX-AMT
               MOVE TR-ID  TO KTI-MAX-ID
               SET WS-NOT-FIRST TO TRUE
           ELSE
               IF TR-AMT > KTI-MAX-AMT
                   MOVE TR-AMT TO KTI-MAX-AMT
                   MOVE TR-ID  TO KTI-MAX-ID
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3000-FINALIZE  -  nothing further; analytics are complete.   *
      *----------------------------------------------------------------*
       3000-FINALIZE.
           CONTINUE.
