      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUFEE   -  Fee assessment SUB                     *
      *  TYPE    : SUB  (CICS file control)                          *
      *  FUNCTION: assess over-limit and late fees on demand.        *
      *            Browses the account master (ACCTFILE); an active   *
      *            account is over limit when the balance exceeds the *
      *            credit limit and delinquent when the balance is    *
      *            positive yet the cycle credit is below the minimum *
      *            due (2% of balance, floor 25).  Each condition adds *
      *            its flat fee; the total fee is READ ... UPDATE      *
      *            added to the balance and cycle debit, the account   *
      *            REWRITTEN, and a fee transaction (type 'FE') is     *
      *            WRITTEN to TRANFILE using an id drawn from CTRLFILE *
      *            key 'TRANID'.  Ports OBLFEE (VSAM) and ODFEE (DB2).*
      *  CALL    : EXEC CICS LINK PROGRAM('OUFEE')                    *
      *                COMMAREA(ORION-COMMAREA) END-EXEC.             *
      *  REQUEST : KO-PARM-ACCT optional single account (0 = all).    *
      *  RESULT  : KO-READ scanned    KO-SELECT assessed              *
      *            KO-UPDATE rewritten KO-TRAN fee trans              *
      *            KO-C1 over-limit    KO-C2 late    KO-C3 both        *
      *            KO-AMT-1 total fees KO-AMT-2 late KO-AMT-3 over.    *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUFEE.
       AUTHOR.     ORION-CCMS-ONLINE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and fee schedule constants.                  *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUFEE'.
           05  WS-FEE-TYPE          PIC X(02) VALUE 'FE'.
           05  WS-FEE-CAT           PIC 9(04) VALUE 0090.
           05  WS-CTRL-KEY-ID       PIC X(08) VALUE 'TRANID  '.
           05  WS-ID-PREFIX         PIC X(02) VALUE 'FE'.
           05  WS-LATE-FEE          PIC S9(05)V99 VALUE +35.00.
           05  WS-OVLIM-FEE         PIC S9(05)V99 VALUE +29.00.
           05  WS-MIN-DUE-PCT       PIC S9(01)V9(04) VALUE +0.0200.
           05  WS-MIN-DUE-FLOOR     PIC S9(05)V99 VALUE +25.00.
      *----------------------------------------------------------------*
      *  Browse, eligibility and control switches.                     *
      *----------------------------------------------------------------*
       01  WS-FLAGS.
           05  WS-BR-END-SW         PIC X(01) VALUE 'N'.
               88  BR-END                     VALUE 'Y'.
               88  BR-MORE                    VALUE 'N'.
           05  WS-BR-STARTED-SW     PIC X(01) VALUE 'N'.
               88  BR-STARTED                 VALUE 'Y'.
               88  BR-NOT-STARTED             VALUE 'N'.
           05  WS-ELIG-SW           PIC X(01) VALUE 'N'.
               88  ACCT-ELIGIBLE              VALUE 'Y'.
               88  ACCT-NOT-ELIGIBLE          VALUE 'N'.
           05  WS-OVLIM-SW          PIC X(01) VALUE 'N'.
               88  IS-OVER-LIMIT              VALUE 'Y'.
           05  WS-DELQ-SW           PIC X(01) VALUE 'N'.
               88  IS-DELINQUENT             VALUE 'Y'.
           05  WS-CTRL-AVAIL-SW     PIC X(01) VALUE 'N'.
               88  CTRL-AVAILABLE            VALUE 'Y'.
               88  CTRL-MISSING              VALUE 'N'.
           05  WS-FILTER-ON         PIC X(01) VALUE 'N'.
               88  FILTER-ACTIVE             VALUE 'Y'.
      *----------------------------------------------------------------*
      *  Fee computation and id builder work fields.                   *
      *----------------------------------------------------------------*
       01  WS-CALC.
           05  WS-MIN-DUE           PIC S9(11)V99 VALUE ZEROS.
           05  WS-FEE-AMT           PIC S9(09)V99 VALUE ZEROS.
           05  WS-FILTER-ACCT       PIC 9(11)     VALUE ZEROS.
           05  WS-NEXT-ID-NUM       PIC 9(14)     VALUE ZEROS.
       01  WS-ID-BUILD.
           05  WS-IB-PREFIX         PIC X(02).
           05  WS-IB-SEQ            PIC 9(14).
      *----------------------------------------------------------------*
      *  Processing timestamp (X(26)) built from CURRENT-DATE.         *
      *----------------------------------------------------------------*
       01  WS-CURR-RAW              PIC X(21) VALUE SPACES.
       01  WS-CDT.
           05  WS-CDT-YEAR          PIC 9(04).
           05  WS-CDT-MON           PIC 9(02).
           05  WS-CDT-DAY           PIC 9(02).
           05  WS-CDT-HH            PIC 9(02).
           05  WS-CDT-MM            PIC 9(02).
           05  WS-CDT-SS            PIC 9(02).
       01  WS-PROC-TS.
           05  PT-YEAR              PIC 9(04).
           05  FILLER               PIC X(01) VALUE '-'.
           05  PT-MON               PIC 9(02).
           05  FILLER               PIC X(01) VALUE '-'.
           05  PT-DAY               PIC 9(02).
           05  FILLER               PIC X(01) VALUE '-'.
           05  PT-HH                PIC 9(02).
           05  FILLER               PIC X(01) VALUE '.'.
           05  PT-MM                PIC 9(02).
           05  FILLER               PIC X(01) VALUE '.'.
           05  PT-SS                PIC 9(02).
           05  FILLER               PIC X(07) VALUE '.000000'.
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RACCT.
       COPY RTRAN.
       COPY RCTRL.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KOPS.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN : overlay request, load counter, browse, return.    *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KOPS-AREA TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INITIALISE.
           PERFORM 1500-LOAD-COUNTER.
           PERFORM 3000-BROWSE-DRIVER.
           PERFORM 5500-SAVE-COUNTER.
           PERFORM 9000-FINALISE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INITIALISE : clear results, build timestamp, note filter.*
      *----------------------------------------------------------------*
       1000-INITIALISE.
           SET KO-OK TO TRUE.
           MOVE SPACES TO KO-STATUS-MSG.
           MOVE ZEROS TO KO-READ-CNT.
           MOVE ZEROS TO KO-SELECT-CNT.
           MOVE ZEROS TO KO-UPDATE-CNT.
           MOVE ZEROS TO KO-POSTED-CNT.
           MOVE ZEROS TO KO-REJECT-CNT.
           MOVE ZEROS TO KO-SKIP-CNT.
           MOVE ZEROS TO KO-TRAN-CNT.
           MOVE ZEROS TO KO-C1.
           MOVE ZEROS TO KO-C2.
           MOVE ZEROS TO KO-C3.
           MOVE ZEROS TO KO-AMT-1.
           MOVE ZEROS TO KO-AMT-2.
           MOVE ZEROS TO KO-AMT-3.
           MOVE 'N' TO WS-FILTER-ON.
           IF KO-PARM-ACCT > ZERO
               MOVE KO-PARM-ACCT TO WS-FILTER-ACCT
               SET FILTER-ACTIVE TO TRUE
           END-IF.
           MOVE FUNCTION CURRENT-DATE TO WS-CURR-RAW.
           MOVE WS-CURR-RAW(1:14) TO WS-CDT.
           MOVE WS-CDT-YEAR TO PT-YEAR.
           MOVE WS-CDT-MON  TO PT-MON.
           MOVE WS-CDT-DAY  TO PT-DAY.
           MOVE WS-CDT-HH   TO PT-HH.
           MOVE WS-CDT-MM   TO PT-MM.
           MOVE WS-CDT-SS   TO PT-SS.
           SET BR-MORE TO TRUE.
           SET BR-NOT-STARTED TO TRUE.
      *----------------------------------------------------------------*
      *  1500-LOAD-COUNTER : read the current TRANID sequence value.   *
      *----------------------------------------------------------------*
       1500-LOAD-COUNTER.
           MOVE WS-CTRL-KEY-ID TO CT-KEY.
      *    READ ... UPDATE holds the CTRLFILE lock for the whole task so
      *    concurrent runs cannot mint overlapping TRANIDs (see OUPAY).
           EXEC CICS READ
                     FILE(WS-CTRLFILE)
                     INTO(CTRL-REC)
                     RIDFLD(CT-KEY)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE CT-LAST-VALUE TO WS-NEXT-ID-NUM
                   SET CTRL-AVAILABLE TO TRUE
               WHEN DFHRESP(NOTFND)
                   MOVE ZEROS TO WS-NEXT-ID-NUM
                   SET CTRL-MISSING TO TRUE
               WHEN OTHER
                   MOVE ZEROS TO WS-NEXT-ID-NUM
                   SET CTRL-MISSING TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3000-BROWSE-DRIVER : browse accounts and assess fees.         *
      *----------------------------------------------------------------*
       3000-BROWSE-DRIVER.
           PERFORM 3100-START-BROWSE.
           IF BR-STARTED
               PERFORM 3200-READ-NEXT-ACCT
               PERFORM 4000-PROCESS-ACCT
                   UNTIL BR-END OR KO-ERROR
               PERFORM 3400-END-BROWSE
           END-IF.
      *----------------------------------------------------------------*
      *  3100-START-BROWSE : STARTBR at filter key or file start.      *
      *----------------------------------------------------------------*
       3100-START-BROWSE.
           IF FILTER-ACTIVE
               MOVE WS-FILTER-ACCT TO AC-ID
           ELSE
               MOVE ZEROS TO AC-ID
           END-IF.
           EXEC CICS STARTBR
                     FILE(WS-ACCTFILE)
                     RIDFLD(AC-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BR-STARTED TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET BR-END TO TRUE
                   MOVE 'NO ACCOUNTS TO ASSESS.' TO KO-STATUS-MSG
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'STARTBR ACCTFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-READ-NEXT-ACCT : read one account forward.               *
      *----------------------------------------------------------------*
       3200-READ-NEXT-ACCT.
           EXEC CICS READNEXT
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KO-READ-CNT
               WHEN DFHRESP(ENDFILE)
                   SET BR-END TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'READNEXT ACCTFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-PROCESS-ACCT : evaluate and, when due, assess the fee.   *
      *----------------------------------------------------------------*
       4000-PROCESS-ACCT.
           IF FILTER-ACTIVE AND AC-ID NOT = WS-FILTER-ACCT
               SET BR-END TO TRUE
           ELSE
               IF AC-ACTIVE-STATUS = 'N'
                   ADD 1 TO KO-SKIP-CNT
               ELSE
                   PERFORM 4200-EVAL-ELIGIBILITY
                   IF ACCT-ELIGIBLE
                       PERFORM 4300-COMPUTE-FEE
                       PERFORM 4400-UPDATE-ACCT
                       PERFORM 4500-WRITE-TRAN
                   END-IF
               END-IF
               PERFORM 3200-READ-NEXT-ACCT
           END-IF.
      *----------------------------------------------------------------*
      *  4200-EVAL-ELIGIBILITY : set over-limit and delinquency flags. *
      *----------------------------------------------------------------*
       4200-EVAL-ELIGIBILITY.
           SET ACCT-NOT-ELIGIBLE TO TRUE.
           MOVE 'N' TO WS-OVLIM-SW.
           MOVE 'N' TO WS-DELQ-SW.
           IF AC-CURR-BAL > AC-CREDIT-LIMIT
               SET IS-OVER-LIMIT TO TRUE
           END-IF.
           IF AC-CURR-BAL > ZERO
               COMPUTE WS-MIN-DUE ROUNDED =
                   AC-CURR-BAL * WS-MIN-DUE-PCT
               IF WS-MIN-DUE < WS-MIN-DUE-FLOOR
                   MOVE WS-MIN-DUE-FLOOR TO WS-MIN-DUE
               END-IF
               IF AC-CYC-CREDIT < WS-MIN-DUE
                   SET IS-DELINQUENT TO TRUE
               END-IF
           END-IF.
           IF IS-OVER-LIMIT OR IS-DELINQUENT
               SET ACCT-ELIGIBLE TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  4300-COMPUTE-FEE : total the applicable fees and count them.  *
      *----------------------------------------------------------------*
       4300-COMPUTE-FEE.
           MOVE ZERO TO WS-FEE-AMT.
           IF IS-DELINQUENT
               ADD WS-LATE-FEE TO WS-FEE-AMT
               ADD WS-LATE-FEE TO KO-AMT-2
               ADD 1 TO KO-C2
           END-IF.
           IF IS-OVER-LIMIT
               ADD WS-OVLIM-FEE TO WS-FEE-AMT
               ADD WS-OVLIM-FEE TO KO-AMT-3
               ADD 1 TO KO-C1
           END-IF.
           IF IS-OVER-LIMIT AND IS-DELINQUENT
               ADD 1 TO KO-C3
           END-IF.
           ADD WS-FEE-AMT TO KO-AMT-1.
           ADD 1 TO KO-SELECT-CNT.
      *----------------------------------------------------------------*
      *  4400-UPDATE-ACCT : READ for UPDATE, add fee, REWRITE.         *
      *----------------------------------------------------------------*
       4400-UPDATE-ACCT.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               ADD 1 TO KO-REJECT-CNT
               GO TO 4400-EXIT
           END-IF.
           ADD WS-FEE-AMT TO AC-CURR-BAL.
           ADD WS-FEE-AMT TO AC-CYC-DEBIT.
           EXEC CICS REWRITE
                     FILE(WS-ACCTFILE)
                     FROM(ACCT-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KO-UPDATE-CNT
               ADD 1 TO KO-POSTED-CNT
           ELSE
               ADD 1 TO KO-REJECT-CNT
           END-IF.
       4400-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  4500-WRITE-TRAN : build and WRITE the fee transaction.        *
      *----------------------------------------------------------------*
       4500-WRITE-TRAN.
           ADD 1 TO WS-NEXT-ID-NUM.
           MOVE WS-ID-PREFIX   TO WS-IB-PREFIX.
           MOVE WS-NEXT-ID-NUM TO WS-IB-SEQ.
           INITIALIZE TRAN-REC.
           MOVE WS-ID-BUILD TO TR-ID.
           MOVE WS-FEE-TYPE TO TR-TYPE-CD.
           MOVE WS-FEE-CAT  TO TR-CAT-CD.
           MOVE 'LATEFEE'   TO TR-SOURCE.
           MOVE 'FEE ASSESSMENT - OUFEE' TO TR-DESC.
           MOVE WS-FEE-AMT  TO TR-AMT.
           MOVE ZEROS       TO TR-MERCHANT-ID.
           MOVE 'ORION-CCMS' TO TR-MERCHANT-NAME.
           MOVE SPACES      TO TR-MERCHANT-CITY.
           MOVE SPACES      TO TR-MERCHANT-ZIP.
           MOVE SPACES      TO TR-CARD-NUM.
           MOVE WS-PROC-TS  TO TR-ORIG-TS.
           MOVE WS-PROC-TS  TO TR-PROC-TS.
           EXEC CICS WRITE
                     FILE(WS-TRANFILE)
                     FROM(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KO-TRAN-CNT
           END-IF.
      *----------------------------------------------------------------*
      *  3400-END-BROWSE : release the account browse.                 *
      *----------------------------------------------------------------*
       3400-END-BROWSE.
           IF BR-STARTED
               EXEC CICS ENDBR
                         FILE(WS-ACCTFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
      *----------------------------------------------------------------*
      *  5500-SAVE-COUNTER : persist the advanced TRANID counter.      *
      *----------------------------------------------------------------*
       5500-SAVE-COUNTER.
           IF KO-TRAN-CNT = ZERO
               GO TO 5500-EXIT
           END-IF.
           MOVE WS-CTRL-KEY-ID TO CT-KEY.
           EXEC CICS READ
                     FILE(WS-CTRLFILE)
                     INTO(CTRL-REC)
                     RIDFLD(CT-KEY)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               MOVE WS-NEXT-ID-NUM TO CT-LAST-VALUE
               EXEC CICS REWRITE
                         FILE(WS-CTRLFILE)
                         FROM(CTRL-REC)
                         RESP(WS-RESP-CD)
               END-EXEC
           ELSE
               MOVE WS-CTRL-KEY-ID TO CT-KEY
               MOVE WS-NEXT-ID-NUM TO CT-LAST-VALUE
               MOVE 'TRAN ID COUNTER' TO CT-DESC
               EXEC CICS WRITE
                         FILE(WS-CTRLFILE)
                         FROM(CTRL-REC)
                         RIDFLD(CT-KEY)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
       5500-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  9000-FINALISE : set the completion status message.            *
      *----------------------------------------------------------------*
       9000-FINALISE.
           IF KO-ERROR
               CONTINUE
           ELSE
               IF KO-REJECT-CNT > 0
                   SET KO-WARN TO TRUE
               ELSE
                   SET KO-OK TO TRUE
               END-IF
               MOVE 'FEE ASSESSMENT COMPLETE.' TO KO-STATUS-MSG
           END-IF.
