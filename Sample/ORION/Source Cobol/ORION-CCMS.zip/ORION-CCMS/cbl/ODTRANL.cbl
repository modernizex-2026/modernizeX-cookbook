      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : ODTRANL  -  Transaction List (on-line, DB2)       *
      *  TYPE    : CICS ONLINE + DB2  (pseudo-conversational)        *
      *  FUNCTION: accept a card number, DECLARE / OPEN a cursor on  *
      *            the TRAN table (ORION.TRAN) for that card, FETCH  *
      *            up to five rows in a loop and list them on map    *
      *            MTRANL, then CLOSE the cursor.                    *
      *            PF3 = back to menu, PF4 = clear, ENTER = list.    *
      *  NOTE    : DB2 variant of the OCTRANL online program.        *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. ODTRANL.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'ODTRANL'.
           05  WS-TRANID            PIC X(04) VALUE 'OD05'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
       01  WS-LIST-WORK.
           05  WS-ROW-CNT           PIC 9(02) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  DB2 communication area.                                       *
      *----------------------------------------------------------------*
           EXEC SQL INCLUDE SQLCA END-EXEC.
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RTRAN.
       COPY MTRANL.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
      *  Cursor over the transactions of one card (alt key TR_CARD_NUM)*
      *----------------------------------------------------------------*
           EXEC SQL
                DECLARE TRANCSR CURSOR FOR
                    SELECT TR_ID,
                           TR_AMT,
                           TR_TYPE_CD
                      FROM ORION.TRAN
                     WHERE TR_CARD_NUM = :TR-CARD-NUM
                     ORDER BY TR_ID
           END-EXEC.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MTRANLAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter card number and press ENTER.' TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MTRANLA')
                     MAPSET('MTRANL')
                     FROM(MTRANLAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-LIST-AND-SHOW
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
       2100-LIST-AND-SHOW.
           EXEC CICS RECEIVE
                     MAP('MTRANLA')
                     MAPSET('MTRANL')
                     INTO(MTRANLAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF CARDNUMI = SPACES OR CARDNUMI = LOW-VALUES
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE CARDNUMI TO TR-CARD-NUM
               MOVE CARDNUMI TO CA-CARD-NUM
               MOVE LOW-VALUES TO MTRANLAO
               MOVE TR-CARD-NUM TO CARDNUMO
               PERFORM 3000-LIST-TRANS
               IF WS-ROW-CNT > 0
                   MOVE 'Transactions listed.' TO ERRMSGO
               ELSE
                   IF ERRMSGO = SPACES OR ERRMSGO = LOW-VALUES
                       MOVE 'No transactions for this card.'
                           TO ERRMSGO
                   END-IF
               END-IF
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  DB2 cursor : OPEN, FETCH up to five rows, CLOSE.              *
      *----------------------------------------------------------------*
       3000-LIST-TRANS.
           MOVE ZEROS TO WS-ROW-CNT.
           MOVE 'N'   TO WS-END-FLG.
           EXEC SQL
                OPEN TRANCSR
           END-EXEC.
           IF SQLCODE NOT = 0
               MOVE 'Error opening transaction cursor.' TO ERRMSGO
           ELSE
               PERFORM 3100-FETCH-ROW
                   VARYING WS-IDX FROM 1 BY 1
                   UNTIL WS-IDX > 5 OR END-OF-FILE
               EXEC SQL
                    CLOSE TRANCSR
               END-EXEC
           END-IF.
      *----------------------------------------------------------------*
       3100-FETCH-ROW.
           EXEC SQL
                FETCH TRANCSR
                 INTO :TR-ID,
                      :TR-AMT,
                      :TR-TYPE-CD
           END-EXEC.
           EVALUATE SQLCODE
               WHEN 0
                   ADD 1 TO WS-ROW-CNT
                   PERFORM 3200-MOVE-ROW
               WHEN 100
                   SET END-OF-FILE TO TRUE
               WHEN OTHER
                   SET END-OF-FILE TO TRUE
                   MOVE 'Error fetching transactions.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
       3200-MOVE-ROW.
           MOVE TR-AMT TO WS-ED-AMT.
           EVALUATE WS-IDX
               WHEN 1
                   MOVE TR-ID      TO TRN1O
                   MOVE WS-ED-AMT  TO AMT1O
                   MOVE TR-TYPE-CD TO TYP1O
               WHEN 2
                   MOVE TR-ID      TO TRN2O
                   MOVE WS-ED-AMT  TO AMT2O
                   MOVE TR-TYPE-CD TO TYP2O
               WHEN 3
                   MOVE TR-ID      TO TRN3O
                   MOVE WS-ED-AMT  TO AMT3O
                   MOVE TR-TYPE-CD TO TYP3O
               WHEN 4
                   MOVE TR-ID      TO TRN4O
                   MOVE WS-ED-AMT  TO AMT4O
                   MOVE TR-TYPE-CD TO TYP4O
               WHEN 5
                   MOVE TR-ID      TO TRN5O
                   MOVE WS-ED-AMT  TO AMT5O
                   MOVE TR-TYPE-CD TO TYP5O
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MTRANLA')
                     MAPSET('MTRANL')
                     FROM(MTRANLAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
