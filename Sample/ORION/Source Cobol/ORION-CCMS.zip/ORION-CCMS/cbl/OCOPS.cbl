      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCOPS   -  Admin Batch Operations (on-line)       *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: present a menu of the eight processing jobs that   *
      *            were once run as overnight batch, let an operator  *
      *            pick one plus an optional parameter, drive the      *
      *            matching OU* SUB-program with EXEC CICS LINK,       *
      *            passing / receiving the KOPS request-result area   *
      *            inside CA-WORK-AREA, and display the returned       *
      *            counts and status.  Modelled on OCMENU / OCACCTU.  *
      *  KEYS    : ENTER = run the selected operation                 *
      *            PF3   = back to the main menu                      *
      *            PF4   = clear the screen                           *
      *  TRAN    : OROP  (new admin operations transaction)          *
      *  PARAM   : one free-form field - a numeric account id for     *
      *            most jobs, "account amount" for a bill payment,    *
      *            a card number for card renewal, or blank for all.  *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCOPS.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity constants.                                   *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCOPS'.
           05  WS-TRANID            PIC X(04) VALUE 'OROP'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
           05  WS-SUB-PGM           PIC X(08) VALUE SPACES.
           05  WS-OPTION            PIC 9(02) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Parsed parameter values built from the PARM screen field.     *
      *----------------------------------------------------------------*
       01  WS-PARSE.
           05  WS-PARM-IN           PIC X(16) VALUE SPACES.
           05  WS-TOK1              PIC X(16) VALUE SPACES.
           05  WS-TOK2              PIC X(16) VALUE SPACES.
           05  WS-P-ACCT            PIC 9(11) VALUE ZEROS.
           05  WS-P-AMT             PIC S9(10)V99 VALUE ZEROS.
       01  WS-NUMWORK.
           05  WS-NW-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NW-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NW-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NW-INT            PIC 9(11) VALUE ZEROS.
           05  WS-NW-INT-CNT        PIC 9(02) VALUE ZEROS.
           05  WS-NW-FRAC           PIC 9(02) VALUE ZEROS.
           05  WS-NW-FRAC-CNT       PIC 9(01) VALUE ZEROS.
           05  WS-NW-DOT-SW         PIC X(01) VALUE 'N'.
      *----------------------------------------------------------------*
      *  Display-edit fields for the returned counts and money.        *
      *----------------------------------------------------------------*
       01  WS-DISP.
           05  WS-D-CNT             PIC ZZZ,ZZZ,ZZ9.
           05  WS-D-AMT             PIC -,---,---,--9.99.
           05  WS-D-STAT            PIC X(08) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Shared copybooks (see SPEC sections 2, 4).                   *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY KOPS.
       COPY MOPS.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN : standard pseudo-conversational dispatcher.       *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL : clear the map and prompt for a choice.   *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MOPSAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Select an operation (1-8) and press ENTER.'
               TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MOPSA')
                     MAPSET('MOPS')
                     FROM(MOPSAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT : react to the attention identifier.      *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF12
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHCLEAR
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-RUN-OPERATION
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2050-RECEIVE : read the map; treat MAPFAIL as empty input.   *
      *----------------------------------------------------------------*
       2050-RECEIVE.
           EXEC CICS RECEIVE
                     MAP('MOPSA')
                     MAPSET('MOPS')
                     INTO(MOPSAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MOPSAI
           END-IF.
      *----------------------------------------------------------------*
      *  2100-RUN-OPERATION : validate the choice then LINK the sub.  *
      *----------------------------------------------------------------*
       2100-RUN-OPERATION.
           PERFORM 2050-RECEIVE.
           IF OPTIONI NUMERIC
               MOVE OPTIONI TO WS-OPTION
           ELSE
               MOVE ZEROS TO WS-OPTION
           END-IF.
           PERFORM 6000-PARSE-PARM.
           PERFORM 7000-BUILD-REQUEST.
           IF WS-SUB-PGM = SPACES
               MOVE 'Invalid option. Enter 1 through 8.' TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 2200-LINK-SUB
           END-IF.
      *----------------------------------------------------------------*
      *  2200-LINK-SUB : pass the request area and call the sub.      *
      *----------------------------------------------------------------*
       2200-LINK-SUB.
           MOVE KOPS-AREA TO CA-WORK-AREA.
           EXEC CICS LINK
                     PROGRAM(WS-SUB-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               MOVE CA-WORK-AREA TO KOPS-AREA
               PERFORM 7500-SHOW-RESULT
           ELSE
               MOVE 'Operation could not be started. Contact support.'
                   TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  6000-PARSE-PARM : split PARM into an account id and amount.  *
      *  Token one supplies the numeric account, token two supplies   *
      *  an amount (used by the bill-payment operation).              *
      *----------------------------------------------------------------*
       6000-PARSE-PARM.
           MOVE PARMI TO WS-PARM-IN.
           INSPECT WS-PARM-IN REPLACING ALL LOW-VALUE BY SPACE.
           MOVE SPACES TO WS-TOK1.
           MOVE SPACES TO WS-TOK2.
           UNSTRING WS-PARM-IN DELIMITED BY ALL SPACE
               INTO WS-TOK1 WS-TOK2.
           PERFORM 6100-PARSE-ACCT.
           PERFORM 6200-PARSE-AMT.
      *----------------------------------------------------------------*
      *  6100-PARSE-ACCT : fold the digits of token one into a value. *
      *----------------------------------------------------------------*
       6100-PARSE-ACCT.
           MOVE ZEROS TO WS-NW-INT.
           MOVE ZEROS TO WS-NW-INT-CNT.
           PERFORM VARYING WS-NW-POS FROM 1 BY 1
                   UNTIL WS-NW-POS > 11
               MOVE WS-TOK1(WS-NW-POS:1) TO WS-NW-CHAR
               IF WS-NW-CHAR >= '0' AND WS-NW-CHAR <= '9'
                   MOVE WS-NW-CHAR TO WS-NW-DIGIT
                   COMPUTE WS-NW-INT = WS-NW-INT * 10 + WS-NW-DIGIT
                   ADD 1 TO WS-NW-INT-CNT
               END-IF
           END-PERFORM.
           MOVE WS-NW-INT TO WS-P-ACCT.
      *----------------------------------------------------------------*
      *  6200-PARSE-AMT : parse token two into a signed money value.  *
      *  Digits accumulate; a single dot separates the two-digit      *
      *  fraction; commas and spaces are ignored.                     *
      *----------------------------------------------------------------*
       6200-PARSE-AMT.
           MOVE ZEROS TO WS-NW-INT.
           MOVE ZEROS TO WS-NW-FRAC.
           MOVE ZEROS TO WS-NW-FRAC-CNT.
           MOVE 'N' TO WS-NW-DOT-SW.
           MOVE ZEROS TO WS-P-AMT.
           PERFORM VARYING WS-NW-POS FROM 1 BY 1
                   UNTIL WS-NW-POS > 16
               MOVE WS-TOK2(WS-NW-POS:1) TO WS-NW-CHAR
               EVALUATE TRUE
                   WHEN WS-NW-CHAR = '.'
                       MOVE 'Y' TO WS-NW-DOT-SW
                   WHEN WS-NW-CHAR >= '0' AND WS-NW-CHAR <= '9'
                       MOVE WS-NW-CHAR TO WS-NW-DIGIT
                       IF WS-NW-DOT-SW = 'Y'
                           IF WS-NW-FRAC-CNT < 2
                               COMPUTE WS-NW-FRAC =
                                   WS-NW-FRAC * 10 + WS-NW-DIGIT
                               ADD 1 TO WS-NW-FRAC-CNT
                           END-IF
                       ELSE
                           COMPUTE WS-NW-INT =
                               WS-NW-INT * 10 + WS-NW-DIGIT
                       END-IF
                   WHEN OTHER
                       CONTINUE
               END-EVALUATE
           END-PERFORM.
           IF WS-NW-FRAC-CNT = 1
               COMPUTE WS-NW-FRAC = WS-NW-FRAC * 10
           END-IF.
           COMPUTE WS-P-AMT = WS-NW-INT + (WS-NW-FRAC / 100).
      *----------------------------------------------------------------*
      *  7000-BUILD-REQUEST : map the option to a sub and function.   *
      *----------------------------------------------------------------*
       7000-BUILD-REQUEST.
           MOVE SPACES TO WS-SUB-PGM.
           INITIALIZE KOPS-AREA.
           MOVE WS-P-ACCT TO KO-PARM-ACCT.
           MOVE WS-P-AMT  TO KO-PARM-AMT.
           MOVE SPACES    TO KO-PARM-CARD.
           MOVE SPACES    TO KO-PARM-DATE.
           EVALUATE WS-OPTION
               WHEN 1
                   MOVE 'OUPOST' TO WS-SUB-PGM
                   MOVE 'POST'   TO KO-FUNCTION
               WHEN 2
                   MOVE 'OUPAY'  TO WS-SUB-PGM
                   MOVE 'PAY '   TO KO-FUNCTION
               WHEN 3
                   MOVE 'OUINT'  TO WS-SUB-PGM
                   MOVE 'INT '   TO KO-FUNCTION
               WHEN 4
                   MOVE 'OUFEE'  TO WS-SUB-PGM
                   MOVE 'FEE '   TO KO-FUNCTION
               WHEN 5
                   MOVE 'OUCHGF' TO WS-SUB-PGM
                   MOVE 'CHGF'   TO KO-FUNCTION
               WHEN 6
                   MOVE 'OUCLOS' TO WS-SUB-PGM
                   MOVE 'CLOS'   TO KO-FUNCTION
               WHEN 7
                   MOVE 'OURNEW' TO WS-SUB-PGM
                   MOVE 'RNEW'   TO KO-FUNCTION
                   MOVE WS-PARM-IN TO KO-PARM-CARD
               WHEN 8
                   MOVE 'OUCYCL' TO WS-SUB-PGM
                   MOVE 'CYCL'   TO KO-FUNCTION
               WHEN OTHER
                   MOVE SPACES TO WS-SUB-PGM
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  7500-SHOW-RESULT : move the returned counts into the map.    *
      *----------------------------------------------------------------*
       7500-SHOW-RESULT.
           EVALUATE TRUE
               WHEN KO-OK
                   MOVE 'OK'      TO WS-D-STAT
               WHEN KO-WARN
                   MOVE 'WARNING' TO WS-D-STAT
               WHEN OTHER
                   MOVE 'ERROR'   TO WS-D-STAT
           END-EVALUATE.
           MOVE WS-D-STAT      TO RSTATO.
           MOVE KO-STATUS-MSG  TO RMSGO.
           MOVE KO-READ-CNT    TO WS-D-CNT.
           MOVE WS-D-CNT       TO RCREADO.
           MOVE KO-SELECT-CNT  TO WS-D-CNT.
           MOVE WS-D-CNT       TO RCSELO.
           MOVE KO-POSTED-CNT  TO WS-D-CNT.
           MOVE WS-D-CNT       TO RCPOSTO.
           MOVE KO-UPDATE-CNT  TO WS-D-CNT.
           MOVE WS-D-CNT       TO RCUPDO.
           MOVE KO-REJECT-CNT  TO WS-D-CNT.
           MOVE WS-D-CNT       TO RCREJO.
           MOVE KO-TRAN-CNT    TO WS-D-CNT.
           MOVE WS-D-CNT       TO RCTRANO.
           MOVE KO-AMT-1       TO WS-D-AMT.
           MOVE WS-D-AMT       TO RAMT1O.
           MOVE KO-AMT-2       TO WS-D-AMT.
           MOVE WS-D-AMT       TO RAMT2O.
           MOVE 'Operation complete. Review the counts below.'
               TO ERRMSGO.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU : hand control back to the main menu.         *
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER : fill the common screen header.        *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY : refresh header and resend the map.      *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MOPSA')
                     MAPSET('MOPS')
                     FROM(MOPSAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME : obtain formatted current date and time. *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN : pseudo-conversational return to this tran.     *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9500-ABEND-RTN : unrecoverable error - inform and end.       *
      *----------------------------------------------------------------*
       9500-ABEND-RTN.
           MOVE 'OCOPS: unrecoverable error. Contact support.'
               TO WS-MSG-TEXT.
           EXEC CICS SEND TEXT
                     FROM(WS-MSG-TEXT)
                     LENGTH(LENGTH OF WS-MSG-TEXT)
                     ERASE
                     FREEKB
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS RETURN
                     RESP(WS-RESP-CD)
           END-EXEC.
