      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)
      *  PROGRAM : OCUTIL  -  Admin Data-Utilities driver (on-line)
      *  TYPE    : CICS ONLINE  (pseudo-conversational)
      *  FUNCTION: present a menu of the data-utility sub-programs and,
      *            for the operator's choice, build the matching request
      *            in the shared COMMAREA work area, EXEC CICS LINK the
      *            OU* sub-program and display the returned counts and
      *            status.  Each utility is a CICS file-control sub that
      *            replaces one of the legacy batch jobs.
      *  KEYS    : ENTER = run the selected utility
      *            PF3   = back to the admin menu
      *            PF4   = clear the screen
      *  MAPSET  : MUTIL      MAP : MUTILA      TRANID : ORUT
      *  LINKS   : OUXREF OUSTMB OUFLAG OUIMP OUARCH OUPURG OUBKP
      *  NOTE    : modelled on the golden OCMENU / OCACCTU templates.
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCUTIL.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCUTIL'.
           05  WS-TRANID            PIC X(04) VALUE 'ORUT'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCADMEN'.
           05  WS-LINK-PGM          PIC X(08) VALUE SPACES.
           05  WS-OPTION            PIC 9(02) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Sub-program names for the seven utilities.                    *
      *----------------------------------------------------------------*
       01  WS-SUB-NAMES.
           05  WS-P-XREF            PIC X(08) VALUE 'OUXREF'.
           05  WS-P-STMB            PIC X(08) VALUE 'OUSTMB'.
           05  WS-P-FLAG            PIC X(08) VALUE 'OUFLAG'.
           05  WS-P-IMP             PIC X(08) VALUE 'OUIMP'.
           05  WS-P-ARCH            PIC X(08) VALUE 'OUARCH'.
           05  WS-P-PURG            PIC X(08) VALUE 'OUPURG'.
           05  WS-P-BKP             PIC X(08) VALUE 'OUBKP'.
      *----------------------------------------------------------------*
      *  Validated operator inputs.                                    *
      *----------------------------------------------------------------*
       01  WS-REQ.
           05  WS-REQ-MODE          PIC X(04) VALUE SPACES.
           05  WS-REQ-DATE          PIC X(10) VALUE SPACES.
           05  WS-MAX-NUM           PIC 9(07) VALUE ZEROS.
           05  WS-CYC-NUM           PIC 9(06) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Program work flags.                                           *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
           05  WS-LINK-BAD          PIC X(01) VALUE 'N'.
      *----------------------------------------------------------------*
      *  Reusable numeric-field parser work area.                      *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(16) VALUE SPACES.
           05  WS-NC-LEN            PIC 9(02) VALUE ZEROS.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(16) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Numeric edit patterns and result-line build area.            *
      *----------------------------------------------------------------*
       01  WS-EDITS.
           05  WS-E9                PIC ZZZ,ZZZ,ZZ9.
           05  WS-EA                PIC -,---,---,--9.99.
       01  WS-FMT.
           05  WS-L1                PIC X(11) VALUE SPACES.
           05  WS-V1                PIC X(16) VALUE SPACES.
           05  WS-L2                PIC X(11) VALUE SPACES.
           05  WS-V2                PIC X(16) VALUE SPACES.
           05  WS-LINE              PIC X(60) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea and  *
      *  the seven utility request / result blocks.                    *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY KXREF.
       COPY KSTMTB.
       COPY KFLAG.
       COPY KIMP.
       COPY KARCH.
       COPY KPURG.
       COPY KBKP.
      *----------------------------------------------------------------*
      *  BMS symbolic map and IBM-supplied AID / attribute constants.  *
      *----------------------------------------------------------------*
       COPY MUTIL.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh empty screen.*
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MUTILAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'REBL' TO UTMODEO.
           MOVE 'Select a utility (1-7), key params, press ENTER.'
               TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MUTILA')
                     MAPSET('MUTIL')
                     FROM(MUTILAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF12
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHCLEAR
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-RUN
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-RUN  -  receive the screen, edit the inputs, run the
      *  chosen utility and display the results.                       *
      *----------------------------------------------------------------*
       2100-RUN.
           EXEC CICS RECEIVE
                     MAP('MUTILA')
                     MAPSET('MUTIL')
                     INTO(MUTILAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MUTILAI
           END-IF.
           PERFORM 2150-EDIT-OPTION.
           IF WS-INVALID
               PERFORM 8100-SEND-DATAONLY
               GO TO 2100-EXIT
           END-IF.
           PERFORM 2200-EDIT-INPUTS.
           IF WS-INVALID
               PERFORM 8100-SEND-DATAONLY
               GO TO 2100-EXIT
           END-IF.
           PERFORM 5000-CLEAR-RESULT.
           MOVE 'N' TO WS-LINK-BAD.
           EVALUATE WS-OPTION
               WHEN 1  PERFORM 3100-DO-XREF
               WHEN 2  PERFORM 3200-DO-STMB
               WHEN 3  PERFORM 3300-DO-FLAG
               WHEN 4  PERFORM 3400-DO-IMP
               WHEN 5  PERFORM 3500-DO-ARCH
               WHEN 6  PERFORM 3600-DO-PURG
               WHEN 7  PERFORM 3700-DO-BKP
               WHEN OTHER CONTINUE
           END-EVALUATE.
           IF WS-LINK-BAD = 'Y'
               MOVE 'Sub-program link failed - check resources.'
                   TO ERRMSGO
           ELSE
               MOVE 'Utility complete - see counts below.' TO ERRMSGO
           END-IF.
           PERFORM 8100-SEND-DATAONLY.
       2100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2150-EDIT-OPTION  -  validate the utility number (1 - 7).
      *----------------------------------------------------------------*
       2150-EDIT-OPTION.
           SET WS-VALID TO TRUE.
           MOVE UTOPTI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN = SPACES
               SET WS-INVALID TO TRUE
               MOVE 'Enter a utility number 1 through 7.' TO ERRMSGO
               GO TO 2150-EXIT
           END-IF.
           MOVE 2 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-VALUE < 1 OR WS-NC-VALUE > 7
               SET WS-INVALID TO TRUE
               MOVE 'Utility number must be 1 through 7.' TO ERRMSGO
           ELSE
               MOVE WS-NC-VALUE TO WS-OPTION
           END-IF.
       2150-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2200-EDIT-INPUTS  -  capture mode / date and validate the
      *  optional numeric max-count and cycle fields.                  *
      *----------------------------------------------------------------*
       2200-EDIT-INPUTS.
           SET WS-VALID TO TRUE.
           MOVE UTMODEI TO WS-REQ-MODE.
           MOVE UTDATEI TO WS-REQ-DATE.
           INSPECT WS-REQ-MODE REPLACING ALL LOW-VALUE BY SPACE.
           INSPECT WS-REQ-DATE REPLACING ALL LOW-VALUE BY SPACE.
           MOVE ZEROS TO WS-MAX-NUM WS-CYC-NUM.
           MOVE UTNUMI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN NOT = SPACES
               MOVE 7 TO WS-NC-LEN
               PERFORM 6000-PARSE-NUM
               IF WS-INVALID
                   MOVE 'Max count must be numeric.' TO ERRMSGO
                   GO TO 2200-EXIT
               END-IF
               MOVE WS-NC-VALUE TO WS-MAX-NUM
           END-IF.
           MOVE UTCYCI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN NOT = SPACES
               MOVE 6 TO WS-NC-LEN
               PERFORM 6000-PARSE-NUM
               IF WS-INVALID
                   MOVE 'Cycle must be numeric (YYYYMM).' TO ERRMSGO
                   GO TO 2200-EXIT
               END-IF
               MOVE WS-NC-VALUE TO WS-CYC-NUM
           END-IF.
       2200-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3100-DO-XREF  -  run the cross-reference rebuild utility.
      *----------------------------------------------------------------*
       3100-DO-XREF.
           INITIALIZE KUX-PARM.
           IF WS-REQ-MODE = SPACES
               MOVE 'REBL' TO KUX-MODE
           ELSE
               MOVE WS-REQ-MODE TO KUX-MODE
           END-IF.
           MOVE WS-MAX-NUM TO KUX-MAX.
           MOVE SPACES     TO KUX-START-CARD.
           MOVE KUX-PARM   TO CA-WORK-AREA.
           MOVE WS-P-XREF  TO WS-LINK-PGM.
           PERFORM 4000-LINK-SUB.
           MOVE CA-WORK-AREA TO KUX-PARM.
           PERFORM 5100-FMT-XREF.
      *----------------------------------------------------------------*
      *  3200-DO-STMB  -  run the statement build utility.             *
      *----------------------------------------------------------------*
       3200-DO-STMB.
           INITIALIZE KSM-PARM.
           MOVE WS-CYC-NUM  TO KSM-CYCLE.
           MOVE WS-REQ-DATE TO KSM-DUE-DATE.
           MOVE ZEROS       TO KSM-START-ACCT.
           MOVE WS-MAX-NUM  TO KSM-MAX.
           MOVE KSM-PARM    TO CA-WORK-AREA.
           MOVE WS-P-STMB   TO WS-LINK-PGM.
           PERFORM 4000-LINK-SUB.
           MOVE CA-WORK-AREA TO KSM-PARM.
           PERFORM 5200-FMT-STMB.
      *----------------------------------------------------------------*
      *  3300-DO-FLAG  -  run the delinquency + expiry utility.        *
      *----------------------------------------------------------------*
       3300-DO-FLAG.
           INITIALIZE KFL-PARM.
           IF WS-REQ-MODE = SPACES
               MOVE 'BOTH' TO KFL-MODE
           ELSE
               MOVE WS-REQ-MODE TO KFL-MODE
           END-IF.
           MOVE WS-REQ-DATE TO KFL-CUTOFF.
           MOVE ZEROS       TO KFL-START-ACCT.
           MOVE WS-MAX-NUM  TO KFL-MAX.
           MOVE KFL-PARM    TO CA-WORK-AREA.
           MOVE WS-P-FLAG   TO WS-LINK-PGM.
           PERFORM 4000-LINK-SUB.
           MOVE CA-WORK-AREA TO KFL-PARM.
           PERFORM 5300-FMT-FLAG.
      *----------------------------------------------------------------*
      *  3400-DO-IMP  -  run the account import utility.               *
      *----------------------------------------------------------------*
       3400-DO-IMP.
           INITIALIZE KIM-PARM.
           MOVE SPACES     TO KIM-START-KEY.
           MOVE WS-MAX-NUM TO KIM-MAX.
           MOVE KIM-PARM   TO CA-WORK-AREA.
           MOVE WS-P-IMP   TO WS-LINK-PGM.
           PERFORM 4000-LINK-SUB.
           MOVE CA-WORK-AREA TO KIM-PARM.
           PERFORM 5400-FMT-IMP.
      *----------------------------------------------------------------*
      *  3500-DO-ARCH  -  run the transaction archive utility.         *
      *----------------------------------------------------------------*
       3500-DO-ARCH.
           INITIALIZE KAR-PARM.
           MOVE WS-REQ-DATE TO KAR-CUTOFF.
           MOVE SPACES      TO KAR-START-TRAN.
           MOVE WS-MAX-NUM  TO KAR-MAX.
           MOVE KAR-PARM    TO CA-WORK-AREA.
           MOVE WS-P-ARCH   TO WS-LINK-PGM.
           PERFORM 4000-LINK-SUB.
           MOVE CA-WORK-AREA TO KAR-PARM.
           PERFORM 5500-FMT-ARCH.
      *----------------------------------------------------------------*
      *  3600-DO-PURG  -  run the transaction purge utility.           *
      *----------------------------------------------------------------*
       3600-DO-PURG.
           INITIALIZE KPG-PARM.
           MOVE WS-REQ-DATE TO KPG-CUTOFF.
           MOVE SPACES      TO KPG-START-TRAN.
           MOVE WS-MAX-NUM  TO KPG-MAX.
           MOVE KPG-PARM    TO CA-WORK-AREA.
           MOVE WS-P-PURG   TO WS-LINK-PGM.
           PERFORM 4000-LINK-SUB.
           MOVE CA-WORK-AREA TO KPG-PARM.
           PERFORM 5600-FMT-PURG.
      *----------------------------------------------------------------*
      *  3700-DO-BKP  -  run the transaction backup utility.           *
      *----------------------------------------------------------------*
       3700-DO-BKP.
           INITIALIZE KBK-PARM.
           MOVE SPACES     TO KBK-START-KEY.
           MOVE WS-MAX-NUM TO KBK-MAX.
           MOVE KBK-PARM   TO CA-WORK-AREA.
           MOVE WS-P-BKP   TO WS-LINK-PGM.
           PERFORM 4000-LINK-SUB.
           MOVE CA-WORK-AREA TO KBK-PARM.
           PERFORM 5700-FMT-BKP.
      *----------------------------------------------------------------*
      *  4000-LINK-SUB  -  LINK the selected sub-program passing the
      *  shared COMMAREA that carries the request / result block.
      *----------------------------------------------------------------*
       4000-LINK-SUB.
           EXEC CICS LINK
                     PROGRAM(WS-LINK-PGM)
                     COMMAREA(ORION-COMMAREA)
                     LENGTH(LENGTH OF ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               MOVE 'Y' TO WS-LINK-BAD
           END-IF.
      *----------------------------------------------------------------*
      *  5000-CLEAR-RESULT  -  blank the status and detail lines.
      *----------------------------------------------------------------*
       5000-CLEAR-RESULT.
           MOVE SPACES TO RSTATO RMSGO.
           MOVE SPACES TO RLINE1O RLINE2O RLINE3O RLINE4O.
      *----------------------------------------------------------------*
      *  5100-FMT-XREF  -  format the cross-reference result.
      *----------------------------------------------------------------*
       5100-FMT-XREF.
           MOVE KUX-STATUS TO RSTATO.
           MOVE KUX-MSG    TO RMSGO.
           MOVE 'Read'    TO WS-L1.
           MOVE KUX-READ  TO WS-E9.
           MOVE WS-E9     TO WS-V1.
           MOVE 'Written' TO WS-L2.
           MOVE KUX-WRITTEN TO WS-E9.
           MOVE WS-E9     TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE1O.
           MOVE 'Updated'   TO WS-L1.
           MOVE KUX-UPDATED TO WS-E9.
           MOVE WS-E9       TO WS-V1.
           MOVE 'Skip-acct' TO WS-L2.
           MOVE KUX-SKIP-ACCT TO WS-E9.
           MOVE WS-E9       TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE2O.
           MOVE 'Skip-xref' TO WS-L1.
           MOVE KUX-SKIP-XREF TO WS-E9.
           MOVE WS-E9       TO WS-V1.
           MOVE 'Skip-cust' TO WS-L2.
           MOVE KUX-SKIP-CUST TO WS-E9.
           MOVE WS-E9       TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE3O.
           MOVE 'Errors'   TO WS-L1.
           MOVE KUX-ERRORS TO WS-E9.
           MOVE WS-E9      TO WS-V1.
           MOVE 'More'     TO WS-L2.
           MOVE KUX-MORE   TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE4O.
      *----------------------------------------------------------------*
      *  5200-FMT-STMB  -  format the statement-build result.          *
      *----------------------------------------------------------------*
       5200-FMT-STMB.
           MOVE KSM-STATUS TO RSTATO.
           MOVE KSM-MSG    TO RMSGO.
           MOVE 'Acct read'  TO WS-L1.
           MOVE KSM-ACCT-READ TO WS-E9.
           MOVE WS-E9        TO WS-V1.
           MOVE 'Stmts'      TO WS-L2.
           MOVE KSM-STMT-WRITTEN TO WS-E9.
           MOVE WS-E9        TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE1O.
           MOVE 'No-tran'  TO WS-L1.
           MOVE KSM-NO-TRAN TO WS-E9.
           MOVE WS-E9      TO WS-V1.
           MOVE 'Errors'   TO WS-L2.
           MOVE KSM-ERRORS TO WS-E9.
           MOVE WS-E9      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE2O.
           MOVE 'Tot cr'   TO WS-L1.
           MOVE KSM-TOT-CREDIT TO WS-EA.
           MOVE WS-EA      TO WS-V1.
           MOVE 'Tot dr'   TO WS-L2.
           MOVE KSM-TOT-DEBIT TO WS-EA.
           MOVE WS-EA      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE3O.
           MOVE 'More'      TO WS-L1.
           MOVE KSM-MORE    TO WS-V1.
           MOVE 'Next acct' TO WS-L2.
           MOVE KSM-NEXT-ACCT TO WS-E9.
           MOVE WS-E9       TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE4O.
      *----------------------------------------------------------------*
      *  5300-FMT-FLAG  -  format the delinquency + expiry result.
      *----------------------------------------------------------------*
       5300-FMT-FLAG.
           MOVE KFL-STATUS TO RSTATO.
           MOVE KFL-MSG    TO RMSGO.
           MOVE 'Read'    TO WS-L1.
           MOVE KFL-READ  TO WS-E9.
           MOVE WS-E9     TO WS-V1.
           MOVE 'Delinq'  TO WS-L2.
           MOVE KFL-DELQ  TO WS-E9.
           MOVE WS-E9     TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE1O.
           MOVE 'B30'     TO WS-L1.
           MOVE KFL-B30   TO WS-E9.
           MOVE WS-E9     TO WS-V1.
           MOVE 'B60'     TO WS-L2.
           MOVE KFL-B60   TO WS-E9.
           MOVE WS-E9     TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE2O.
           MOVE 'B90'     TO WS-L1.
           MOVE KFL-B90   TO WS-E9.
           MOVE WS-E9     TO WS-V1.
           MOVE 'Expired' TO WS-L2.
           MOVE KFL-EXPIRED TO WS-E9.
           MOVE WS-E9     TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE3O.
           MOVE 'Errors'  TO WS-L1.
           MOVE KFL-ERRORS TO WS-E9.
           MOVE WS-E9     TO WS-V1.
           MOVE 'More'    TO WS-L2.
           MOVE KFL-MORE  TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE4O.
      *----------------------------------------------------------------*
      *  5400-FMT-IMP  -  format the account-import result.            *
      *----------------------------------------------------------------*
       5400-FMT-IMP.
           MOVE KIM-STATUS TO RSTATO.
           MOVE KIM-MSG    TO RMSGO.
           MOVE 'Read'     TO WS-L1.
           MOVE KIM-READ   TO WS-E9.
           MOVE WS-E9      TO WS-V1.
           MOVE 'Accepted' TO WS-L2.
           MOVE KIM-ACCEPTED TO WS-E9.
           MOVE WS-E9      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE1O.
           MOVE 'Added'    TO WS-L1.
           MOVE KIM-ADDED  TO WS-E9.
           MOVE WS-E9      TO WS-V1.
           MOVE 'Updated'  TO WS-L2.
           MOVE KIM-UPDATED TO WS-E9.
           MOVE WS-E9      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE2O.
           MOVE 'Rejected' TO WS-L1.
           MOVE KIM-REJECTED TO WS-E9.
           MOVE WS-E9      TO WS-V1.
           MOVE 'Skipped'  TO WS-L2.
           MOVE KIM-SKIPPED TO WS-E9.
           MOVE WS-E9      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE3O.
           MOVE 'Errors'   TO WS-L1.
           MOVE KIM-ERRORS TO WS-E9.
           MOVE WS-E9      TO WS-V1.
           MOVE 'More'     TO WS-L2.
           MOVE KIM-MORE   TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE4O.
      *----------------------------------------------------------------*
      *  5500-FMT-ARCH  -  format the archive result.                 *
      *----------------------------------------------------------------*
       5500-FMT-ARCH.
           MOVE KAR-STATUS TO RSTATO.
           MOVE KAR-MSG    TO RMSGO.
           MOVE 'Read'     TO WS-L1.
           MOVE KAR-READ   TO WS-E9.
           MOVE WS-E9      TO WS-V1.
           MOVE 'Archived' TO WS-L2.
           MOVE KAR-ARCHIVED TO WS-E9.
           MOVE WS-E9      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE1O.
           MOVE 'Deleted'  TO WS-L1.
           MOVE KAR-DELETED TO WS-E9.
           MOVE WS-E9      TO WS-V1.
           MOVE 'Kept'     TO WS-L2.
           MOVE KAR-KEPT   TO WS-E9.
           MOVE WS-E9      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE2O.
           MOVE 'Arch amt' TO WS-L1.
           MOVE KAR-ARCH-AMT TO WS-EA.
           MOVE WS-EA      TO WS-V1.
           MOVE 'Errors'   TO WS-L2.
           MOVE KAR-ERRORS TO WS-E9.
           MOVE WS-E9      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE3O.
           MOVE 'More'     TO WS-L1.
           MOVE KAR-MORE   TO WS-V1.
           MOVE SPACES     TO WS-L2 WS-V2.
           PERFORM 7150-FMT1.
           MOVE WS-LINE   TO RLINE4O.
      *----------------------------------------------------------------*
      *  5600-FMT-PURG  -  format the purge result.                   *
      *----------------------------------------------------------------*
       5600-FMT-PURG.
           MOVE KPG-STATUS TO RSTATO.
           MOVE KPG-MSG    TO RMSGO.
           MOVE 'Read'     TO WS-L1.
           MOVE KPG-READ   TO WS-E9.
           MOVE WS-E9      TO WS-V1.
           MOVE 'Purged'   TO WS-L2.
           MOVE KPG-PURGED TO WS-E9.
           MOVE WS-E9      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE1O.
           MOVE 'Kept'     TO WS-L1.
           MOVE KPG-KEPT   TO WS-E9.
           MOVE WS-E9      TO WS-V1.
           MOVE 'Errors'   TO WS-L2.
           MOVE KPG-ERRORS TO WS-E9.
           MOVE WS-E9      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE2O.
           MOVE 'Purge amt' TO WS-L1.
           MOVE KPG-PURGE-AMT TO WS-EA.
           MOVE WS-EA      TO WS-V1.
           MOVE 'Keep amt' TO WS-L2.
           MOVE KPG-KEEP-AMT TO WS-EA.
           MOVE WS-EA      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE3O.
           MOVE 'More'     TO WS-L1.
           MOVE KPG-MORE   TO WS-V1.
           MOVE SPACES     TO WS-L2 WS-V2.
           PERFORM 7150-FMT1.
           MOVE WS-LINE   TO RLINE4O.
      *----------------------------------------------------------------*
      *  5700-FMT-BKP  -  format the backup / extract result.          *
      *----------------------------------------------------------------*
       5700-FMT-BKP.
           MOVE KBK-STATUS TO RSTATO.
           MOVE KBK-MSG    TO RMSGO.
           MOVE 'Read'     TO WS-L1.
           MOVE KBK-READ   TO WS-E9.
           MOVE WS-E9      TO WS-V1.
           MOVE 'Written'  TO WS-L2.
           MOVE KBK-WRITTEN TO WS-E9.
           MOVE WS-E9      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE1O.
           MOVE 'Tot amt'  TO WS-L1.
           MOVE KBK-TOT-AMT TO WS-EA.
           MOVE WS-EA      TO WS-V1.
           MOVE 'Errors'   TO WS-L2.
           MOVE KBK-ERRORS TO WS-E9.
           MOVE WS-E9      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE2O.
           MOVE 'Credit'   TO WS-L1.
           MOVE KBK-CREDIT-AMT TO WS-EA.
           MOVE WS-EA      TO WS-V1.
           MOVE 'Debit'    TO WS-L2.
           MOVE KBK-DEBIT-AMT TO WS-EA.
           MOVE WS-EA      TO WS-V2.
           PERFORM 7100-FMT2.
           MOVE WS-LINE   TO RLINE3O.
           MOVE 'More'     TO WS-L1.
           MOVE KBK-MORE   TO WS-V1.
           MOVE SPACES     TO WS-L2 WS-V2.
           PERFORM 7150-FMT1.
           MOVE WS-LINE   TO RLINE4O.
      *----------------------------------------------------------------*
      *  6000-PARSE-NUM  -  scan WS-NC-IN for WS-NC-LEN characters,
      *  ignore spaces, accumulate digits into WS-NC-VALUE and count
      *  them.  Any other character makes the field invalid.           *
      *----------------------------------------------------------------*
       6000-PARSE-NUM.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > WS-NC-LEN
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the admin menu.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  7100-FMT2  -  build one result line from two label / value
      *  pairs, trimming the padding for a compact display.            *
      *----------------------------------------------------------------*
       7100-FMT2.
           MOVE SPACES TO WS-LINE.
           STRING FUNCTION TRIM (WS-L1) DELIMITED BY SIZE
                  '=' DELIMITED BY SIZE
                  FUNCTION TRIM (WS-V1) DELIMITED BY SIZE
                  '   ' DELIMITED BY SIZE
                  FUNCTION TRIM (WS-L2) DELIMITED BY SIZE
                  '=' DELIMITED BY SIZE
                  FUNCTION TRIM (WS-V2) DELIMITED BY SIZE
                  INTO WS-LINE
           END-STRING.
      *----------------------------------------------------------------*
      *  7150-FMT1  -  build one result line from a single pair.
      *----------------------------------------------------------------*
       7150-FMT1.
           MOVE SPACES TO WS-LINE.
           STRING FUNCTION TRIM (WS-L1) DELIMITED BY SIZE
                  '=' DELIMITED BY SIZE
                  FUNCTION TRIM (WS-V1) DELIMITED BY SIZE
                  INTO WS-LINE
           END-STRING.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  refresh header and resend the map.
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MUTILA')
                     MAPSET('MUTIL')
                     FROM(MUTILAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to this tran.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *                   E N D   O F   O C U T I L                    *
      *----------------------------------------------------------------*
