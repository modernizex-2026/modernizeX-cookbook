      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUANLIN  -  Analytics compute subroutine          *
      *  TYPE    : SUBROUTINE (EXEC CICS LINK from OCANLIN)          *
      *  FUNCTION: scan the transaction master (TRANFILE) and, for   *
      *            the requested mode, compute an analytics result   *
      *            set, then return one page of rows plus two mode-  *
      *            specific grand totals to the caller.              *
      *            RW rewards : points accrued per card.             *
      *            FR fraud   : cards flagged for large amount or    *
      *                         high transaction velocity.           *
      *            GL general ledger : totals by type as debit/credit*
      *            RC recon   : movement per account vs balance.     *
      *  CALL    : EXEC CICS LINK PROGRAM('OUANLIN')                 *
      *                COMMAREA(KANLB-PARM)                          *
      *                LENGTH(LENGTH OF KANLB-PARM) END-EXEC.        *
      *  FILES   : TRANFILE (browse), XREFFILE (read), ACCTFILE      *
      *            (read).  Every EXEC CICS command tests RESP.      *
      *  REPLACES: batch reports OBRWD / OBRWDRPT (rewards),         *
      *            OBRFRD (fraud), OBGLEX (gl extract) and OBRECON   *
      *            (reconciliation) with a single on-line inquiry.   *
      *  RETURN  : ends with GOBACK (subroutine convention).         *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - four analytics modes.          *
      *****************************************************************
      *  PROCESSING NARRATIVE                                        *
      *  1. Validate the mode and clear the in-storage result table. *
      *  2. Browse TRANFILE from the start of file (bounded by a     *
      *     scan cap for on-line responsiveness) accumulating the    *
      *     mode-specific figures keyed by card, account or type.    *
      *  3. Finalise fraud (keep only flagged cards) and recon       *
      *     (compare each account movement to its balance).          *
      *  4. Copy the requested page of rows (by row offset) into the *
      *     COMMAREA and publish counts, totals and the MORE flag.   *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUANLIN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and tuning constants.                        *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUANLIN'.
           05  WS-MAX-SCAN          PIC 9(07) VALUE 0020000.
           05  WS-LARGE-THRESH      PIC S9(09)V99 VALUE +1000.00.
           05  WS-VELO-THRESH       PIC 9(09) VALUE 5.
           05  WS-BONUS-RATE        PIC 9(01) VALUE 2.
           05  WS-BASE-RATE         PIC 9(01) VALUE 1.
      *----------------------------------------------------------------*
      *  Browse / scan control fields.                                 *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-MAX-ROWS          PIC 9(02) VALUE ZEROS.
           05  WS-SCANNED           PIC 9(09) VALUE ZEROS.
           05  WS-DISC-CNT          PIC 9(04) VALUE ZEROS.
           05  WS-OFLOW-CNT         PIC 9(09) VALUE ZEROS.
           05  WS-ORPH-CNT          PIC 9(09) VALUE ZEROS.
           05  WS-SIDX              PIC 9(04) VALUE ZEROS.
           05  WS-FIDX              PIC 9(04) VALUE ZEROS.
           05  WS-NEW-CNT           PIC 9(04) VALUE ZEROS.
           05  WS-START-IDX         PIC 9(04) VALUE ZEROS.
           05  WS-OUT-CNT           PIC 9(02) VALUE ZEROS.
           05  WS-BROWSE-SW         PIC X(01) VALUE 'N'.
               88  WS-BR-ON                   VALUE 'Y'.
               88  WS-BR-OFF                  VALUE 'N'.
           05  WS-EOF-SW            PIC X(01) VALUE 'N'.
               88  WS-EOF-YES                 VALUE 'Y'.
               88  WS-EOF-NO                  VALUE 'N'.
           05  WS-SLOT-SW           PIC X(01) VALUE 'N'.
               88  SLOT-OK                    VALUE 'Y'.
               88  SLOT-NO                    VALUE 'N'.
           05  WS-PURCHASE-SW       PIC X(01) VALUE 'N'.
               88  WS-IS-PURCHASE             VALUE 'Y'.
               88  WS-NOT-PURCHASE            VALUE 'N'.
           05  WS-FLAG-SW           PIC X(01) VALUE 'N'.
      *----------------------------------------------------------------*
      *  Per-transaction computation work fields.                      *
      *----------------------------------------------------------------*
       01  WS-CALC.
           05  WS-KEY               PIC X(16) VALUE SPACES.
           05  WS-WHOLE-AMT         PIC 9(11) VALUE ZEROS.
           05  WS-POINTS            PIC 9(13) VALUE ZEROS.
           05  WS-MOVE              PIC S9(13)V99 VALUE ZEROS.
           05  WS-DIFF              PIC S9(13)V99 VALUE ZEROS.
           05  WS-REASON            PIC X(16) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Grand-total accumulators (published to KAB-TOTALS).           *
      *----------------------------------------------------------------*
       01  WS-ACCUM.
           05  WS-TOT-1             PIC S9(15)V99 VALUE ZEROS.
           05  WS-TOT-2             PIC S9(15)V99 VALUE ZEROS.
      *----------------------------------------------------------------*
      *  In-storage result table keyed by card / account / type.       *
      *----------------------------------------------------------------*
       01  WS-RES-CTL.
           05  WS-RES-CNT           PIC 9(04) VALUE ZEROS.
           05  WS-MAX-RES           PIC 9(04) VALUE 200.
       01  WS-RES-TABLE.
           05  WS-RES-ENT OCCURS 200 TIMES.
               10  WS-RE-KEY        PIC X(16).
               10  WS-RE-INFO       PIC X(16).
               10  WS-RE-CNT        PIC 9(09).
               10  WS-RE-AMT        PIC S9(13)V99.
               10  WS-RE-VAL        PIC S9(13)V99.
      *----------------------------------------------------------------*
      *  Shared constants (WS-RESP-CD, file names) and record layouts. *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RTRAN.
       COPY RXREF.
       COPY RACCT.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KANLB.
      *================================================================*
       PROCEDURE DIVISION USING KANLB-PARM.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  compute the mode and return one page.           *
      *----------------------------------------------------------------*
       0000-MAIN.
           PERFORM 1000-INIT.
           IF KAB-STATUS NOT = '99'
               PERFORM 2000-SCAN-FILE
               PERFORM 3000-FINALIZE
               PERFORM 4000-BUILD-PAGE
           END-IF.
           PERFORM 6000-SET-STATUS.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INIT  -  reset accumulators and validate the mode.       *
      *----------------------------------------------------------------*
       1000-INIT.
           MOVE ZEROS TO WS-RES-CNT.
           MOVE ZEROS TO WS-SCANNED.
           MOVE ZEROS TO WS-DISC-CNT.
           MOVE ZEROS TO WS-OFLOW-CNT.
           MOVE ZEROS TO WS-ORPH-CNT.
           MOVE ZEROS TO WS-TOT-1.
           MOVE ZEROS TO WS-TOT-2.
           SET WS-BR-OFF TO TRUE.
           SET WS-EOF-NO TO TRUE.
           MOVE '00' TO KAB-STATUS.
           MOVE KAB-MAX-ROWS TO WS-MAX-ROWS.
           IF WS-MAX-ROWS < 1 OR WS-MAX-ROWS > 6
               MOVE 6 TO WS-MAX-ROWS
           END-IF.
           EVALUATE KAB-MODE
               WHEN 'RW'
               WHEN 'FR'
               WHEN 'GL'
               WHEN 'RC'
                   CONTINUE
               WHEN OTHER
                   MOVE '99' TO KAB-STATUS
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2000-SCAN-FILE  -  browse TRANFILE and accumulate per mode.   *
      *----------------------------------------------------------------*
       2000-SCAN-FILE.
           PERFORM 2100-START-TRAN.
           IF WS-BR-ON
               PERFORM 2200-READ-TRAN
                   UNTIL WS-EOF-YES
                      OR WS-SCANNED >= WS-MAX-SCAN
               PERFORM 2900-END-TRAN
           END-IF.
      *----------------------------------------------------------------*
      *  2100-START-TRAN  -  position the browse at start of file.     *
      *----------------------------------------------------------------*
       2100-START-TRAN.
           MOVE LOW-VALUES TO TR-ID.
           EXEC CICS STARTBR
                     FILE(WS-TRANFILE)
                     RIDFLD(TR-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-BR-ON TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET WS-BR-OFF  TO TRUE
                   SET WS-EOF-YES TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-BR-OFF  TO TRUE
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   SET WS-BR-OFF  TO TRUE
                   SET WS-EOF-YES TO TRUE
                   MOVE '99' TO KAB-STATUS
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2200-READ-TRAN  -  read the next transaction and dispatch it. *
      *----------------------------------------------------------------*
       2200-READ-TRAN.
           EXEC CICS READNEXT
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO WS-SCANNED
                   PERFORM 2300-DISPATCH
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   SET WS-EOF-YES TO TRUE
                   MOVE '99' TO KAB-STATUS
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2300-DISPATCH  -  route one transaction to the mode logic.    *
      *----------------------------------------------------------------*
       2300-DISPATCH.
           EVALUATE KAB-MODE
               WHEN 'RW' PERFORM 2400-ACCUM-RW
               WHEN 'FR' PERFORM 2500-ACCUM-FR
               WHEN 'GL' PERFORM 2600-ACCUM-GL
               WHEN 'RC' PERFORM 2700-ACCUM-RC
               WHEN OTHER CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2350-CLASSIFY  -  purchases accrue; payments, credits, fees   *
      *  and interest do not.                                          *
      *----------------------------------------------------------------*
       2350-CLASSIFY.
           EVALUATE TR-TYPE-CD
               WHEN 'PY'
               WHEN 'CR'
               WHEN 'FE'
               WHEN 'IN'
                   SET WS-NOT-PURCHASE TO TRUE
               WHEN OTHER
                   SET WS-IS-PURCHASE TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2400-ACCUM-RW  -  reward points per card for purchases.       *
      *----------------------------------------------------------------*
       2400-ACCUM-RW.
           PERFORM 2350-CLASSIFY.
           IF WS-IS-PURCHASE
               MOVE TR-AMT TO WS-WHOLE-AMT
               IF TR-AMT >= WS-LARGE-THRESH
                   COMPUTE WS-POINTS = WS-WHOLE-AMT * WS-BONUS-RATE
               ELSE
                   COMPUTE WS-POINTS = WS-WHOLE-AMT * WS-BASE-RATE
               END-IF
               MOVE TR-CARD-NUM TO WS-KEY
               PERFORM 7000-FIND-OR-ADD
               IF SLOT-OK
                   ADD 1         TO WS-RE-CNT (WS-FIDX)
                   ADD TR-AMT    TO WS-RE-AMT (WS-FIDX)
                   ADD WS-POINTS TO WS-RE-VAL (WS-FIDX)
                   MOVE 'PURCHASES' TO WS-RE-INFO (WS-FIDX)
                   ADD TR-AMT    TO WS-TOT-1
                   ADD WS-POINTS TO WS-TOT-2
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2500-ACCUM-FR  -  gather per card the count, total amount and *
      *  the largest single amount.  Flagging happens at finalise.     *
      *----------------------------------------------------------------*
       2500-ACCUM-FR.
           MOVE TR-CARD-NUM TO WS-KEY.
           PERFORM 7000-FIND-OR-ADD.
           IF SLOT-OK
               ADD 1      TO WS-RE-CNT (WS-FIDX)
               ADD TR-AMT TO WS-RE-AMT (WS-FIDX)
               IF TR-AMT > WS-RE-VAL (WS-FIDX)
                   MOVE TR-AMT TO WS-RE-VAL (WS-FIDX)
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2600-ACCUM-GL  -  totals by transaction type as debit/credit. *
      *----------------------------------------------------------------*
       2600-ACCUM-GL.
           MOVE SPACES     TO WS-KEY.
           MOVE TR-TYPE-CD TO WS-KEY(1:2).
           PERFORM 7000-FIND-OR-ADD.
           IF SLOT-OK
               ADD 1      TO WS-RE-CNT (WS-FIDX)
               ADD TR-AMT TO WS-RE-AMT (WS-FIDX)
               IF TR-TYPE-CD = 'PY' OR TR-TYPE-CD = 'CR'
                   MOVE 'CR'  TO WS-RE-INFO (WS-FIDX)
                   ADD TR-AMT TO WS-TOT-2
               ELSE
                   MOVE 'DR'  TO WS-RE-INFO (WS-FIDX)
                   ADD TR-AMT TO WS-TOT-1
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2700-ACCUM-RC  -  signed movement per account (resolved from  *
      *  the card through XREFFILE).  Debits raise, credits lower.     *
      *----------------------------------------------------------------*
       2700-ACCUM-RC.
           IF TR-TYPE-CD = 'PY' OR TR-TYPE-CD = 'CR'
               ADD TR-AMT TO WS-TOT-2
               COMPUTE WS-MOVE = TR-AMT * -1
           ELSE
               ADD TR-AMT TO WS-TOT-1
               MOVE TR-AMT TO WS-MOVE
           END-IF.
           MOVE TR-CARD-NUM TO XR-CARD-NUM.
           EXEC CICS READ
                     FILE(WS-XREFFILE)
                     INTO(XREF-REC)
                     RIDFLD(XR-CARD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE SPACES     TO WS-KEY
                   MOVE XR-ACCT-ID TO WS-KEY(1:11)
                   PERFORM 7000-FIND-OR-ADD
                   IF SLOT-OK
                       ADD 1       TO WS-RE-CNT (WS-FIDX)
                       ADD WS-MOVE TO WS-RE-AMT (WS-FIDX)
                   END-IF
               WHEN DFHRESP(NOTFND)
                   ADD 1 TO WS-ORPH-CNT
               WHEN OTHER
                   ADD 1 TO WS-ORPH-CNT
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2900-END-TRAN  -  release the transaction browse.             *
      *----------------------------------------------------------------*
       2900-END-TRAN.
           EXEC CICS ENDBR
                     FILE(WS-TRANFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  3000-FINALIZE  -  mode specific post-processing of the table. *
      *----------------------------------------------------------------*
       3000-FINALIZE.
           EVALUATE KAB-MODE
               WHEN 'FR' PERFORM 3100-FINALIZE-FR
               WHEN 'RC' PERFORM 3200-FINALIZE-RC
               WHEN OTHER CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3100-FINALIZE-FR  -  keep only flagged cards, set the reason  *
      *  and accumulate the flagged totals.  A card is flagged when a  *
      *  single amount reaches the large threshold or the transaction  *
      *  count reaches the velocity threshold.                         *
      *----------------------------------------------------------------*
       3100-FINALIZE-FR.
           MOVE ZEROS TO WS-NEW-CNT.
           MOVE ZEROS TO WS-TOT-1.
           MOVE ZEROS TO WS-TOT-2.
           PERFORM VARYING WS-IDX FROM 1 BY 1
                   UNTIL WS-IDX > WS-RES-CNT
               MOVE 'N'    TO WS-FLAG-SW
               MOVE SPACES TO WS-REASON
               IF WS-RE-VAL (WS-IDX) >= WS-LARGE-THRESH
                   MOVE 'Y'         TO WS-FLAG-SW
                   MOVE 'LARGE AMT' TO WS-REASON
               END-IF
               IF WS-RE-CNT (WS-IDX) >= WS-VELO-THRESH
                   MOVE 'Y' TO WS-FLAG-SW
                   IF WS-REASON = SPACES
                       MOVE 'VELOCITY' TO WS-REASON
                   ELSE
                       MOVE 'LARGE+VELO' TO WS-REASON
                   END-IF
               END-IF
               IF WS-FLAG-SW = 'Y'
                   ADD 1 TO WS-NEW-CNT
                   MOVE WS-RE-KEY (WS-IDX) TO WS-RE-KEY (WS-NEW-CNT)
                   MOVE WS-REASON          TO WS-RE-INFO (WS-NEW-CNT)
                   MOVE WS-RE-CNT (WS-IDX) TO WS-RE-CNT (WS-NEW-CNT)
                   MOVE WS-RE-AMT (WS-IDX) TO WS-RE-AMT (WS-NEW-CNT)
                   MOVE WS-RE-VAL (WS-IDX) TO WS-RE-VAL (WS-NEW-CNT)
                   ADD WS-RE-AMT (WS-NEW-CNT) TO WS-TOT-1
                   ADD 1 TO WS-TOT-2
               END-IF
           END-PERFORM.
           MOVE WS-NEW-CNT TO WS-RES-CNT.
      *----------------------------------------------------------------*
      *  3200-FINALIZE-RC  -  read each account and compare movement   *
      *  to its current balance, noting matches and discrepancies.     *
      *----------------------------------------------------------------*
       3200-FINALIZE-RC.
           MOVE ZEROS TO WS-DISC-CNT.
           PERFORM VARYING WS-IDX FROM 1 BY 1
                   UNTIL WS-IDX > WS-RES-CNT
               MOVE WS-RE-KEY (WS-IDX) TO WS-KEY
               MOVE WS-KEY(1:11)       TO AC-ID
               EXEC CICS READ
                         FILE(WS-ACCTFILE)
                         INTO(ACCT-REC)
                         RIDFLD(AC-ID)
                         RESP(WS-RESP-CD)
               END-EXEC
               EVALUATE WS-RESP-CD
                   WHEN DFHRESP(NORMAL)
                       MOVE AC-CURR-BAL TO WS-RE-VAL (WS-IDX)
                       COMPUTE WS-DIFF =
                           WS-RE-AMT (WS-IDX) - AC-CURR-BAL
                       IF WS-DIFF = ZERO
                           MOVE 'OK' TO WS-RE-INFO (WS-IDX)
                       ELSE
                           MOVE 'MISMATCH' TO WS-RE-INFO (WS-IDX)
                           ADD 1 TO WS-DISC-CNT
                       END-IF
                   WHEN DFHRESP(NOTFND)
                       MOVE ZEROS     TO WS-RE-VAL (WS-IDX)
                       MOVE 'MISSING' TO WS-RE-INFO (WS-IDX)
                       ADD 1 TO WS-DISC-CNT
                   WHEN OTHER
                       MOVE 'READ ERR' TO WS-RE-INFO (WS-IDX)
               END-EVALUATE
           END-PERFORM.
      *----------------------------------------------------------------*
      *  4000-BUILD-PAGE  -  copy the requested page of result rows    *
      *  into the COMMAREA and publish counts and totals.             *
      *----------------------------------------------------------------*
       4000-BUILD-PAGE.
           MOVE WS-RES-CNT  TO KAB-RESULT-CNT.
           MOVE WS-SCANNED  TO KAB-SCANNED.
           MOVE WS-DISC-CNT TO KAB-DISC.
           MOVE WS-TOT-1    TO KAB-TOT-1.
           MOVE WS-TOT-2    TO KAB-TOT-2.
           PERFORM 4050-CLEAR-ROWS.
           MOVE ZEROS TO KAB-ROW-CNT.
           MOVE 'N'   TO KAB-MORE.
           IF WS-RES-CNT = ZEROS
               GO TO 4000-EXIT
           END-IF.
           COMPUTE WS-START-IDX = KAB-START-OFF + 1.
           IF WS-START-IDX < 1
               MOVE 1 TO WS-START-IDX
           END-IF.
           MOVE ZEROS TO WS-OUT-CNT.
           PERFORM VARYING WS-IDX FROM WS-START-IDX BY 1
                   UNTIL WS-IDX > WS-RES-CNT
                      OR WS-OUT-CNT >= WS-MAX-ROWS
               ADD 1 TO WS-OUT-CNT
               MOVE WS-RE-KEY (WS-IDX)  TO KAB-R-KEY  (WS-OUT-CNT)
               MOVE WS-RE-INFO (WS-IDX) TO KAB-R-INFO (WS-OUT-CNT)
               MOVE WS-RE-CNT (WS-IDX)  TO KAB-R-CNT  (WS-OUT-CNT)
               MOVE WS-RE-AMT (WS-IDX)  TO KAB-R-AMT  (WS-OUT-CNT)
               MOVE WS-RE-VAL (WS-IDX)  TO KAB-R-VAL  (WS-OUT-CNT)
           END-PERFORM.
           MOVE WS-OUT-CNT TO KAB-ROW-CNT.
           IF WS-IDX <= WS-RES-CNT
               MOVE 'Y' TO KAB-MORE
           END-IF.
       4000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  4050-CLEAR-ROWS  -  blank every output occurrence.            *
      *----------------------------------------------------------------*
       4050-CLEAR-ROWS.
           PERFORM VARYING WS-SIDX FROM 1 BY 1 UNTIL WS-SIDX > 6
               MOVE SPACES TO KAB-R-KEY  (WS-SIDX)
               MOVE SPACES TO KAB-R-INFO (WS-SIDX)
               MOVE ZEROS  TO KAB-R-CNT  (WS-SIDX)
               MOVE ZEROS  TO KAB-R-AMT  (WS-SIDX)
               MOVE ZEROS  TO KAB-R-VAL  (WS-SIDX)
           END-PERFORM.
      *----------------------------------------------------------------*
      *  6000-SET-STATUS  -  publish the completion status code.       *
      *----------------------------------------------------------------*
       6000-SET-STATUS.
           IF KAB-STATUS = '99'
               MOVE ZEROS TO KAB-ROW-CNT
           ELSE
               IF WS-RES-CNT = ZEROS
                   MOVE '10' TO KAB-STATUS
               ELSE
                   MOVE '00' TO KAB-STATUS
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  7000-FIND-OR-ADD  -  locate WS-KEY in the result table or add *
      *  a fresh zeroed entry.  Sets SLOT-OK and WS-FIDX on success;   *
      *  a full table sets SLOT-NO and counts the overflow.            *
      *----------------------------------------------------------------*
       7000-FIND-OR-ADD.
           SET SLOT-NO TO TRUE.
           MOVE ZEROS TO WS-FIDX.
           PERFORM VARYING WS-SIDX FROM 1 BY 1
                   UNTIL WS-SIDX > WS-RES-CNT OR SLOT-OK
               IF WS-RE-KEY (WS-SIDX) = WS-KEY
                   MOVE WS-SIDX TO WS-FIDX
                   SET SLOT-OK TO TRUE
               END-IF
           END-PERFORM.
           IF NOT SLOT-OK
               IF WS-RES-CNT < WS-MAX-RES
                   ADD 1 TO WS-RES-CNT
                   MOVE WS-RES-CNT TO WS-FIDX
                   MOVE WS-KEY  TO WS-RE-KEY  (WS-FIDX)
                   MOVE SPACES  TO WS-RE-INFO (WS-FIDX)
                   MOVE ZEROS   TO WS-RE-CNT  (WS-FIDX)
                   MOVE ZEROS   TO WS-RE-AMT  (WS-FIDX)
                   MOVE ZEROS   TO WS-RE-VAL  (WS-FIDX)
                   SET SLOT-OK TO TRUE
               ELSE
                   ADD 1 TO WS-OFLOW-CNT
                   SET SLOT-NO TO TRUE
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *                   E N D   O F   O U A N L I N                  *
      *----------------------------------------------------------------*
