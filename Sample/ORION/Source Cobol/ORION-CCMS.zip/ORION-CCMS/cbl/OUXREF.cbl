      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)
      *  PROGRAM : OUXREF  -  Rebuild / validate card cross-reference
      *  TYPE    : SUB  (CICS file control)
      *  FUNCTION: on-line port of batch OBXREFP.  Browse CARDFILE in
      *            card-number order; for each card validate the owning
      *            account (ACCTFILE), carry the customer id forward
      *            from the existing XREFFILE record, validate the
      *            customer (CUSTFILE) and - in rebuild mode - correct
      *            and REWRITE the cross-reference (or WRITE a fresh
      *            record if it vanished).  Counts are returned in the
      *            KXREF request / result block that is overlaid on the
      *            shared COMMAREA work area (KCOMM / CA-WORK-AREA).
      *  CALL    : EXEC CICS LINK PROGRAM('OUXREF')
      *                COMMAREA(ORION-COMMAREA)
      *                LENGTH(LENGTH OF ORION-COMMAREA) END-EXEC.
      *  FILES   : CARDFILE browse (STARTBR/READNEXT/ENDBR),
      *            ACCTFILE read, CUSTFILE read,
      *            XREFFILE read / READ UPDATE / REWRITE / WRITE.
      *  RETURN  : ends with GOBACK (subroutine convention).
      *****************************************************************
      *  MAINTENANCE LOG
      *  ----  ----------  -------------------------------------
      *  0001  2026-08-07  Original - on-line xref rebuild sub.
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUXREF.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity.                                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUXREF'.
      *----------------------------------------------------------------*
      *  Run-control switches and per-card work fields.               *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-EOF-SW            PIC X(01) VALUE 'N'.
               88  WS-EOF-YES                 VALUE 'Y'.
               88  WS-EOF-NO                  VALUE 'N'.
           05  WS-BROWSE-SW         PIC X(01) VALUE 'N'.
               88  WS-BR-ON                   VALUE 'Y'.
               88  WS-BR-OFF                  VALUE 'N'.
           05  WS-CARD-SW           PIC X(01) VALUE 'O'.
               88  WS-CARD-OK                 VALUE 'O'.
               88  WS-CARD-SKIP               VALUE 'S'.
           05  WS-MODE-SW           PIC X(01) VALUE 'R'.
               88  WS-MODE-REBUILD            VALUE 'R'.
               88  WS-MODE-VALIDATE           VALUE 'V'.
       01  WS-WORK-FIELDS.
           05  WS-SAVE-CUST         PIC 9(09) VALUE ZEROS.
           05  WS-MAX               PIC 9(07) VALUE ZEROS.
           05  WS-CAPPED            PIC X(01) VALUE 'N'.
      *----------------------------------------------------------------*
      *  Shared constants (WS-RESP-CD, file names) and record layouts  *
      *  used as READ / READNEXT INTO targets.                         *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RCARD.
       COPY RACCT.
       COPY RCUST.
       COPY RXREF.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KXREF.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  top level driver.  KUX-PARM is based on the
      *  COMMAREA work area so request and result travel in KCOMM.
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KUX-PARM TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INIT.
           IF KUX-STATUS NOT = '99'
               PERFORM 2000-POSITION
               IF WS-BR-ON
                   PERFORM 3000-READ-LOOP
                      UNTIL WS-EOF-YES
                         OR WS-CAPPED = 'Y'
                   PERFORM 4000-PEEK-NEXT
                   PERFORM 5000-END-BROWSE
               END-IF
           END-IF.
           PERFORM 6000-SET-STATUS.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INIT  -  reset the result area and validate the request. *
      *----------------------------------------------------------------*
       1000-INIT.
           SET WS-EOF-NO TO TRUE.
           SET WS-BR-OFF TO TRUE.
           MOVE 'N'   TO WS-CAPPED.
           MOVE ZEROS TO WS-SAVE-CUST.
           MOVE '00'  TO KUX-STATUS.
           MOVE SPACES TO KUX-MSG.
           MOVE ZEROS TO KUX-READ KUX-WRITTEN KUX-UPDATED.
           MOVE ZEROS TO KUX-SKIP-ACCT KUX-SKIP-XREF KUX-SKIP-CUST.
           MOVE ZEROS TO KUX-ERRORS.
           MOVE SPACES TO KUX-NEXT-CARD.
           MOVE 'N'   TO KUX-MORE.
           MOVE KUX-MAX TO WS-MAX.
           EVALUATE KUX-MODE
               WHEN 'REBL'
                   SET WS-MODE-REBUILD TO TRUE
               WHEN 'VALD'
                   SET WS-MODE-VALIDATE TO TRUE
               WHEN OTHER
                   MOVE '99' TO KUX-STATUS
                   MOVE 'INVALID MODE - USE REBL OR VALD' TO KUX-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2000-POSITION  -  open the card browse at the resume key.
      *----------------------------------------------------------------*
       2000-POSITION.
           IF KUX-START-CARD = SPACES OR KUX-START-CARD = LOW-VALUES
               MOVE LOW-VALUES TO CD-NUM
           ELSE
               MOVE KUX-START-CARD TO CD-NUM
           END-IF.
           EXEC CICS STARTBR
                     FILE(WS-CARDFILE)
                     RIDFLD(CD-NUM)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-BR-ON TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET WS-BR-OFF  TO TRUE
                   SET WS-EOF-YES TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-BR-OFF  TO TRUE
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   SET WS-BR-OFF  TO TRUE
                   MOVE '99' TO KUX-STATUS
                   MOVE 'CARDFILE STARTBR FAILED' TO KUX-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3000-READ-LOOP  -  process one card per iteration.            *
      *----------------------------------------------------------------*
       3000-READ-LOOP.
           PERFORM 3100-READ-CARD.
           IF NOT WS-EOF-YES
               PERFORM 3200-PROCESS-CARD
               IF WS-MAX > ZEROS AND KUX-READ >= WS-MAX
                   MOVE 'Y' TO WS-CAPPED
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3100-READ-CARD  -  advance the card browse.                   *
      *----------------------------------------------------------------*
       3100-READ-CARD.
           EXEC CICS READNEXT
                     FILE(WS-CARDFILE)
                     INTO(CARD-REC)
                     RIDFLD(CD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   SET WS-EOF-YES TO TRUE
                   ADD 1 TO KUX-ERRORS
                   MOVE 'CARDFILE READNEXT FAILED' TO KUX-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-PROCESS-CARD  -  validate the card and, in rebuild mode, *
      *  correct the cross-reference.  Each validation step turns the
      *  gate off when it fails so later steps are skipped.            *
      *----------------------------------------------------------------*
       3200-PROCESS-CARD.
           ADD 1 TO KUX-READ.
           SET WS-CARD-OK TO TRUE.
           MOVE ZEROS TO WS-SAVE-CUST.
           PERFORM 3300-VAL-ACCT.
           IF WS-CARD-OK
               PERFORM 3400-READ-XREF
           END-IF.
           IF WS-CARD-OK
               PERFORM 3500-VAL-CUST
           END-IF.
           IF WS-CARD-OK
               PERFORM 3600-APPLY
           END-IF.
      *----------------------------------------------------------------*
      *  3300-VAL-ACCT  -  the account carried by the card must exist.
      *----------------------------------------------------------------*
       3300-VAL-ACCT.
           MOVE CD-ACCT-ID TO AC-ID.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(NOTFND)
                   ADD 1 TO KUX-SKIP-ACCT
                   SET WS-CARD-SKIP TO TRUE
               WHEN OTHER
                   ADD 1 TO KUX-ERRORS
                   SET WS-CARD-SKIP TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3400-READ-XREF  -  the existing cross-reference is the only
      *  source of the card->customer link; a missing xref means the
      *  customer cannot be determined so the card is skipped.         *
      *----------------------------------------------------------------*
       3400-READ-XREF.
           MOVE CD-NUM TO XR-CARD-NUM.
           EXEC CICS READ
                     FILE(WS-XREFFILE)
                     INTO(XREF-REC)
                     RIDFLD(XR-CARD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE XR-CUST-ID TO WS-SAVE-CUST
               WHEN DFHRESP(NOTFND)
                   ADD 1 TO KUX-SKIP-XREF
                   SET WS-CARD-SKIP TO TRUE
               WHEN OTHER
                   ADD 1 TO KUX-ERRORS
                   SET WS-CARD-SKIP TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3500-VAL-CUST  -  the carried customer id must still exist.
      *----------------------------------------------------------------*
       3500-VAL-CUST.
           MOVE WS-SAVE-CUST TO CU-ID.
           EXEC CICS READ
                     FILE(WS-CUSTFILE)
                     INTO(CUST-REC)
                     RIDFLD(CU-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(NOTFND)
                   ADD 1 TO KUX-SKIP-CUST
                   SET WS-CARD-SKIP TO TRUE
               WHEN OTHER
                   ADD 1 TO KUX-ERRORS
                   SET WS-CARD-SKIP TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3600-APPLY  -  validate-only mode just counts a good card;
      *  rebuild mode corrects and rewrites the cross-reference.       *
      *----------------------------------------------------------------*
       3600-APPLY.
           IF WS-MODE-VALIDATE
               ADD 1 TO KUX-UPDATED
           ELSE
               PERFORM 3700-REWRITE-XREF
           END-IF.
      *----------------------------------------------------------------*
      *  3700-REWRITE-XREF  -  READ UPDATE the xref and rewrite it with
      *  the account id taken from the card master.  If the record has
      *  disappeared, write a fresh one from the validated parts.
      *----------------------------------------------------------------*
       3700-REWRITE-XREF.
           MOVE CD-NUM TO XR-CARD-NUM.
           EXEC CICS READ
                     FILE(WS-XREFFILE)
                     INTO(XREF-REC)
                     RIDFLD(XR-CARD-NUM)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE CD-ACCT-ID   TO XR-ACCT-ID
                   MOVE WS-SAVE-CUST TO XR-CUST-ID
                   EXEC CICS REWRITE
                             FILE(WS-XREFFILE)
                             FROM(XREF-REC)
                             RESP(WS-RESP-CD)
                   END-EXEC
                   IF WS-RESP-CD = DFHRESP(NORMAL)
                       ADD 1 TO KUX-UPDATED
                   ELSE
                       ADD 1 TO KUX-ERRORS
                   END-IF
               WHEN DFHRESP(NOTFND)
                   PERFORM 3800-WRITE-XREF
               WHEN OTHER
                   ADD 1 TO KUX-ERRORS
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3800-WRITE-XREF  -  create a fresh cross-reference record.
      *----------------------------------------------------------------*
       3800-WRITE-XREF.
           MOVE SPACES       TO XREF-REC.
           MOVE CD-NUM       TO XR-CARD-NUM.
           MOVE CD-ACCT-ID   TO XR-ACCT-ID.
           MOVE WS-SAVE-CUST TO XR-CUST-ID.
           EXEC CICS WRITE
                     FILE(WS-XREFFILE)
                     FROM(XREF-REC)
                     RIDFLD(XR-CARD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KUX-WRITTEN
               WHEN DFHRESP(DUPREC)
                   ADD 1 TO KUX-ERRORS
               WHEN OTHER
                   ADD 1 TO KUX-ERRORS
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-PEEK-NEXT  -  when the scan stopped on the cap, look one
      *  card ahead to publish the resume key for the next page.
      *----------------------------------------------------------------*
       4000-PEEK-NEXT.
           IF WS-EOF-YES
               MOVE 'N' TO KUX-MORE
               GO TO 4000-EXIT
           END-IF.
           EXEC CICS READNEXT
                     FILE(WS-CARDFILE)
                     INTO(CARD-REC)
                     RIDFLD(CD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE 'Y'    TO KUX-MORE
                   MOVE CD-NUM TO KUX-NEXT-CARD
               WHEN DFHRESP(ENDFILE)
                   MOVE 'N' TO KUX-MORE
               WHEN OTHER
                   MOVE 'N' TO KUX-MORE
                   ADD 1 TO KUX-ERRORS
           END-EVALUATE.
       4000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5000-END-BROWSE  -  release the card browse position.
      *----------------------------------------------------------------*
       5000-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-CARDFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  6000-SET-STATUS  -  publish the completion status and message.
      *----------------------------------------------------------------*
       6000-SET-STATUS.
           IF KUX-STATUS = '99'
               GO TO 6000-EXIT
           END-IF.
           IF KUX-READ = ZEROS
               MOVE '10' TO KUX-STATUS
               MOVE 'NO CARDS PROCESSED' TO KUX-MSG
           ELSE
               MOVE '00' TO KUX-STATUS
               IF WS-MODE-VALIDATE
                   MOVE 'XREF VALIDATION COMPLETE' TO KUX-MSG
               ELSE
                   MOVE 'XREF REBUILD COMPLETE' TO KUX-MSG
               END-IF
           END-IF.
       6000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *                   E N D   O F   O U X R E F                    *
      *----------------------------------------------------------------*
