      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)
      *  PROGRAM : OUPURG  -  Purge aged transactions by cutoff
      *  TYPE    : SUB  (CICS file control)
      *  FUNCTION: on-line port of batch OBPURG.  Browse TRANFILE in
      *            key order; transactions dated before the cutoff are
      *            captured (key + amount) into a bounded save table and
      *            those on or after the cutoff are counted as kept.
      *            After the browse ends each captured key is removed
      *            with DELETE FROM TRANFILE.  Counts and money totals
      *            are returned in the KPURG block that is overlaid on
      *            the shared COMMAREA work area.
      *  CALL    : EXEC CICS LINK PROGRAM('OUPURG')
      *                COMMAREA(ORION-COMMAREA)
      *                LENGTH(LENGTH OF ORION-COMMAREA) END-EXEC.
      *  FILES   : TRANFILE browse and DELETE.
      *  RETURN  : ends with GOBACK (subroutine convention).
      *****************************************************************
      *  MAINTENANCE LOG
      *  ----  ----------  -------------------------------------
      *  0001  2026-08-07  Original - on-line transaction purge sub.
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUPURG.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity.                                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUPURG'.
      *----------------------------------------------------------------*
      *  Run-control switches and cutoff-shape work fields.           *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-EOF-SW            PIC X(01) VALUE 'N'.
               88  WS-EOF-YES                 VALUE 'Y'.
               88  WS-EOF-NO                  VALUE 'N'.
           05  WS-BROWSE-SW         PIC X(01) VALUE 'N'.
               88  WS-BR-ON                   VALUE 'Y'.
               88  WS-BR-OFF                  VALUE 'N'.
           05  WS-CAPPED            PIC X(01) VALUE 'N'.
           05  WS-DT-OK             PIC X(01) VALUE 'N'.
       01  WS-WORK-FIELDS.
           05  WS-DT-IN             PIC X(12) VALUE SPACES.
           05  WS-DT                PIC X(10) VALUE SPACES.
           05  WS-PROC-DATE         PIC X(10) VALUE SPACES.
           05  WS-MAX               PIC 9(07) VALUE ZEROS.
           05  WS-CAP               PIC 9(04) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Save table - keys and amounts of transactions to purge.       *
      *----------------------------------------------------------------*
       01  WS-SAVE-TABLE.
           05  WS-SAVE-CNT          PIC 9(04) VALUE ZERO.
           05  WS-MAX-SAVE          PIC 9(04) VALUE 0100.
           05  WS-SAVE-ENTRY OCCURS 100 TIMES
                            INDEXED BY WS-SX.
               10  WS-P-ID          PIC X(16).
               10  WS-P-AMT         PIC S9(09)V99.
      *----------------------------------------------------------------*
      *  Shared constants and the transaction record layout.          *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RTRAN.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KPURG.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  top level driver.                               *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KPG-PARM TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INIT.
           IF KPG-STATUS NOT = '99'
               PERFORM 2000-POSITION
               IF WS-BR-ON
                   PERFORM 3000-SCAN-LOOP
                      UNTIL WS-EOF-YES
                         OR WS-CAPPED = 'Y'
                   PERFORM 4000-PEEK-NEXT
                   PERFORM 5000-END-BROWSE
                   PERFORM 5500-PURGE-SAVED
               END-IF
           END-IF.
           PERFORM 6000-SET-STATUS.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INIT  -  reset the result area and validate the cutoff.
      *----------------------------------------------------------------*
       1000-INIT.
           SET WS-EOF-NO TO TRUE.
           SET WS-BR-OFF TO TRUE.
           MOVE 'N'    TO WS-CAPPED.
           MOVE ZERO   TO WS-SAVE-CNT.
           MOVE '00'   TO KPG-STATUS.
           MOVE SPACES TO KPG-MSG.
           MOVE ZEROS  TO KPG-READ KPG-PURGED KPG-KEPT KPG-ERRORS.
           MOVE ZEROS  TO KPG-PURGE-AMT KPG-KEEP-AMT.
           MOVE SPACES TO KPG-NEXT-TRAN.
           MOVE 'N'    TO KPG-MORE.
           MOVE KPG-MAX TO WS-MAX.
           MOVE WS-MAX-SAVE TO WS-CAP.
           IF WS-MAX > ZEROS AND WS-MAX < WS-MAX-SAVE
               MOVE WS-MAX TO WS-CAP
           END-IF.
           MOVE KPG-CUTOFF TO WS-DT-IN.
           PERFORM 1100-CHK-DATE.
           IF WS-DT-OK NOT = 'Y'
               MOVE '99' TO KPG-STATUS
               MOVE 'INVALID CUTOFF - USE YYYY-MM-DD' TO KPG-MSG
           END-IF.
      *----------------------------------------------------------------*
      *  1100-CHK-DATE  -  verify the YYYY-MM-DD shape of the cutoff.
      *----------------------------------------------------------------*
       1100-CHK-DATE.
           MOVE 'N' TO WS-DT-OK.
           MOVE FUNCTION TRIM (WS-DT-IN) TO WS-DT.
           IF WS-DT (5:1) = '-' AND WS-DT (8:1) = '-'
               IF WS-DT (1:4) IS NUMERIC
                  AND WS-DT (6:2) IS NUMERIC
                  AND WS-DT (9:2) IS NUMERIC
                   MOVE 'Y' TO WS-DT-OK
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2000-POSITION  -  open the transaction browse at resume key.
      *----------------------------------------------------------------*
       2000-POSITION.
           IF KPG-START-TRAN = SPACES OR KPG-START-TRAN = LOW-VALUES
               MOVE LOW-VALUES TO TR-ID
           ELSE
               MOVE KPG-START-TRAN TO TR-ID
           END-IF.
           EXEC CICS STARTBR
                     FILE(WS-TRANFILE)
                     RIDFLD(TR-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-BR-ON TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET WS-EOF-YES TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   MOVE '99' TO KPG-STATUS
                   MOVE 'TRANFILE STARTBR FAILED' TO KPG-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3000-SCAN-LOOP  -  classify one transaction per iteration.    *
      *----------------------------------------------------------------*
       3000-SCAN-LOOP.
           PERFORM 3100-READ-TRAN.
           IF NOT WS-EOF-YES
               PERFORM 3200-CLASSIFY
               IF WS-SAVE-CNT >= WS-CAP
                   MOVE 'Y' TO WS-CAPPED
               END-IF
      *        bound the browse by records SCANNED (operator max), not
      *        only by aged rows saved, so a cutoff that matches few
      *        aged rows cannot read the whole file in one online task.
               IF WS-MAX > ZEROS AND KPG-READ >= WS-MAX
                   MOVE 'Y' TO WS-CAPPED
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3100-READ-TRAN  -  advance the transaction browse.            *
      *----------------------------------------------------------------*
       3100-READ-TRAN.
           EXEC CICS READNEXT
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   SET WS-EOF-YES TO TRUE
                   ADD 1 TO KPG-ERRORS
                   MOVE 'TRANFILE READNEXT FAILED' TO KPG-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-CLASSIFY  -  an aged transaction is saved for purge; a
      *  current one is counted as kept.                              *
      *----------------------------------------------------------------*
       3200-CLASSIFY.
           ADD 1 TO KPG-READ.
           MOVE TR-PROC-TS (1:10) TO WS-PROC-DATE.
           IF WS-PROC-DATE < KPG-CUTOFF
               IF WS-SAVE-CNT < WS-CAP
                   ADD 1 TO WS-SAVE-CNT
                   MOVE TR-ID  TO WS-P-ID(WS-SAVE-CNT)
                   MOVE TR-AMT TO WS-P-AMT(WS-SAVE-CNT)
               END-IF
           ELSE
               ADD 1      TO KPG-KEPT
               ADD TR-AMT TO KPG-KEEP-AMT
           END-IF.
      *----------------------------------------------------------------*
      *  4000-PEEK-NEXT  -  publish the resume key when the cap stopped
      *  the scan short of end-of-file.                                *
      *----------------------------------------------------------------*
       4000-PEEK-NEXT.
           IF WS-EOF-YES
               MOVE 'N' TO KPG-MORE
               GO TO 4000-EXIT
           END-IF.
           EXEC CICS READNEXT
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE 'Y'   TO KPG-MORE
                   MOVE TR-ID TO KPG-NEXT-TRAN
               WHEN DFHRESP(ENDFILE)
                   MOVE 'N' TO KPG-MORE
               WHEN OTHER
                   MOVE 'N' TO KPG-MORE
                   ADD 1 TO KPG-ERRORS
           END-EVALUATE.
       4000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5000-END-BROWSE  -  release the transaction browse position.
      *----------------------------------------------------------------*
       5000-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-TRANFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  5500-PURGE-SAVED  -  delete each captured aged transaction.
      *----------------------------------------------------------------*
       5500-PURGE-SAVED.
           PERFORM VARYING WS-SX FROM 1 BY 1
                   UNTIL WS-SX > WS-SAVE-CNT
               PERFORM 5600-PURGE-ONE
           END-PERFORM.
      *----------------------------------------------------------------*
      *  5600-PURGE-ONE  -  remove one aged transaction from TRANFILE.
      *----------------------------------------------------------------*
       5600-PURGE-ONE.
           MOVE WS-P-ID(WS-SX) TO TR-ID.
           EXEC CICS DELETE
                     FILE(WS-TRANFILE)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KPG-PURGED
               ADD WS-P-AMT(WS-SX) TO KPG-PURGE-AMT
           ELSE
               ADD 1 TO KPG-ERRORS
           END-IF.
      *----------------------------------------------------------------*
      *  6000-SET-STATUS  -  publish the completion status and message.
      *----------------------------------------------------------------*
       6000-SET-STATUS.
           IF KPG-STATUS = '99'
               GO TO 6000-EXIT
           END-IF.
           IF KPG-READ = ZEROS
               MOVE '10' TO KPG-STATUS
               MOVE 'NO TRANSACTIONS PROCESSED' TO KPG-MSG
           ELSE
               MOVE '00' TO KPG-STATUS
               MOVE 'TRANSACTION PURGE COMPLETE' TO KPG-MSG
           END-IF.
       6000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *                   E N D   O F   O U P U R G                    *
      *----------------------------------------------------------------*
