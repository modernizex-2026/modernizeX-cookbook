      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCACCTU  -  Account Update (on-line)              *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: read an account by id, display current values,   *
      *            validate operator changes and REWRITE the        *
      *            account master (ACCTFILE).                        *
      *  KEYS    : ENTER = read / validate                          *
      *            PF5   = save (confirm) the change                *
      *            PF3   = back to main menu                        *
      *            PF4   = clear and re-key the account id          *
      *  STATE   : held in CA-WORK-AREA(1:1)                        *
      *              'K' key-entry  (waiting for account id)        *
      *              'E' edit-mode  (account loaded, fields open)   *
      *  NOTE    : modelled on the GOLDEN template OCACCTV.         *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCACCTU.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity constants.                                   *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCACCTU'.
           05  WS-TRANID            PIC X(04) VALUE 'ORAU'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Validation / update switches local to this program.          *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
           05  WS-UPD-SW            PIC X(01) VALUE 'N'.
               88  WS-UPD-OK                  VALUE 'Y'.
               88  WS-UPD-BAD                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Symbolic values for the pseudo-conversational state byte.    *
      *----------------------------------------------------------------*
       01  WS-STATE-CONST.
           05  WS-ST-KEY            PIC X(01) VALUE 'K'.
           05  WS-ST-EDIT           PIC X(01) VALUE 'E'.
      *----------------------------------------------------------------*
      *  Work area for validating a numeric account key entered as    *
      *  free-form characters on the screen.                          *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(11) VALUE SPACES.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(11) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Work area for parsing a money amount typed by the operator.  *
      *  Commas and spaces are ignored; a single decimal point with   *
      *  up to two fraction digits is accepted.                       *
      *----------------------------------------------------------------*
       01  WS-AMT-EDIT.
           05  WS-AE-IN             PIC X(13) VALUE SPACES.
           05  WS-AE-POS            PIC 9(02) VALUE ZEROS.
           05  WS-AE-CHAR           PIC X(01) VALUE SPACES.
           05  WS-AE-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-AE-INT            PIC 9(10) VALUE ZEROS.
           05  WS-AE-INT-CNT        PIC 9(02) VALUE ZEROS.
           05  WS-AE-FRAC           PIC 9(02) VALUE ZEROS.
           05  WS-AE-FRAC-CNT       PIC 9(01) VALUE ZEROS.
           05  WS-AE-DOT-SW         PIC X(01) VALUE 'N'.
           05  WS-AE-RESULT         PIC S9(10)V99 VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Validated new field values, staged before the REWRITE.       *
      *----------------------------------------------------------------*
       01  WS-NEW-VALUES.
           05  WS-NEW-STATUS        PIC X(01) VALUE SPACES.
           05  WS-NEW-CRLIM         PIC S9(10)V99 VALUE ZEROS.
           05  WS-NEW-CSLIM         PIC S9(10)V99 VALUE ZEROS.
           05  WS-NEW-EXPIRY        PIC X(10) VALUE SPACES.
           05  WS-NEW-GROUP         PIC X(10) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Shared copybooks (see SPEC sections 2, 3, 4, 7).             *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY KDATE.
       COPY RACCT.
       COPY MACCTU.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN : standard pseudo-conversational dispatcher.       *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL : clear the map and prompt for a key.      *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MACCTUAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-ST-KEY TO CA-WORK-AREA(1:1).
           MOVE 'Enter account id and press ENTER.' TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MACCTUA')
                     MAPSET('MACCTU')
                     FROM(MACCTUAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT : react to the attention identifier.      *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF12
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHCLEAR
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHPF5
                   PERFORM 2300-SAVE
               WHEN DFHENTER
                   PERFORM 2100-ENTER
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2050-RECEIVE : read the map; treat MAPFAIL as empty input.   *
      *----------------------------------------------------------------*
       2050-RECEIVE.
           EXEC CICS RECEIVE
                     MAP('MACCTUA')
                     MAPSET('MACCTU')
                     INTO(MACCTUAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MACCTUAI
           END-IF.
      *----------------------------------------------------------------*
      *  2100-ENTER : ENTER key - branch on the current state.        *
      *----------------------------------------------------------------*
       2100-ENTER.
           PERFORM 2050-RECEIVE.
           EVALUATE CA-WORK-AREA(1:1)
               WHEN WS-ST-EDIT
                   PERFORM 2250-VALIDATE-ONLY
               WHEN OTHER
                   PERFORM 2200-LOOKUP
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2200-LOOKUP : key-entry state - read the account and open    *
      *  it for editing.                                              *
      *----------------------------------------------------------------*
       2200-LOOKUP.
           PERFORM 6000-VALIDATE-ACCTID.
           IF WS-INVALID
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE WS-NC-VALUE TO AC-ID
               MOVE AC-ID       TO CA-ACCT-ID
               PERFORM 3000-READ-ACCT
               IF REC-FOUND
                   PERFORM 4000-POPULATE-DETAIL
                   MOVE WS-ST-EDIT TO CA-WORK-AREA(1:1)
                   MOVE 'Account found. Change fields, PF5 to save.'
                       TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE WS-MSG-NOTFND TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2250-VALIDATE-ONLY : edit state, ENTER pressed.  Validate    *
      *  every field but do not update - prompt to confirm with PF5.  *
      *----------------------------------------------------------------*
       2250-VALIDATE-ONLY.
           PERFORM 5000-VALIDATE-ALL.
           IF WS-INVALID
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE 'Changes are valid.  Press PF5 to confirm save.'
                   TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  2300-SAVE : PF5 pressed - re-validate then REWRITE.          *
      *----------------------------------------------------------------*
       2300-SAVE.
           IF CA-WORK-AREA(1:1) NOT = WS-ST-EDIT
               MOVE 'Enter an account id and press ENTER first.'
                   TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 2050-RECEIVE
               PERFORM 5000-VALIDATE-ALL
               IF WS-INVALID
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   PERFORM 3500-UPDATE-ACCT
                   IF WS-UPD-OK
                       PERFORM 4000-POPULATE-DETAIL
                   END-IF
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3000-READ-ACCT : random read of ACCTFILE by AC-ID.          *
      *----------------------------------------------------------------*
       3000-READ-ACCT.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3500-UPDATE-ACCT : READ UPDATE, apply and REWRITE.          *
      *----------------------------------------------------------------*
       3500-UPDATE-ACCT.
           SET WS-UPD-BAD TO TRUE.
           MOVE CA-ACCT-ID TO AC-ID.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   PERFORM 3600-APPLY-UPDATE
               WHEN DFHRESP(NOTFND)
                   MOVE 'Account no longer exists. Update aborted.'
                       TO ERRMSGO
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3600-APPLY-UPDATE : final business check then REWRITE.       *
      *----------------------------------------------------------------*
       3600-APPLY-UPDATE.
           IF WS-NEW-CRLIM < AC-CURR-BAL
               MOVE 'Credit limit below current balance. Not saved.'
                   TO ERRMSGO
               EXEC CICS UNLOCK
                         FILE(WS-ACCTFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
               GO TO 3600-EXIT
           END-IF.
           MOVE WS-NEW-STATUS TO AC-ACTIVE-STATUS.
           MOVE WS-NEW-CRLIM  TO AC-CREDIT-LIMIT.
           MOVE WS-NEW-CSLIM  TO AC-CASH-LIMIT.
           MOVE WS-NEW-EXPIRY TO AC-EXPIRY-DATE.
           MOVE WS-NEW-GROUP  TO AC-GROUP-ID.
           EXEC CICS REWRITE
                     FILE(WS-ACCTFILE)
                     FROM(ACCT-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               SET WS-UPD-OK TO TRUE
               MOVE 'Account updated successfully.' TO ERRMSGO
           ELSE
               MOVE 'Update failed during REWRITE.' TO ERRMSGO
           END-IF.
       3600-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  4000-POPULATE-DETAIL : move ACCT-REC into the output map.    *
      *  Money is edited through WS-ED-AMT; the rightmost 13 bytes    *
      *  fit the 13-char screen fields.                              *
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE AC-ID             TO ACCTIDO.
           MOVE AC-ACTIVE-STATUS  TO ACSTATO.
           MOVE AC-CREDIT-LIMIT   TO WS-ED-AMT.
           MOVE WS-ED-AMT(4:13)   TO ACCRLIMO.
           MOVE AC-CASH-LIMIT     TO WS-ED-AMT.
           MOVE WS-ED-AMT(4:13)   TO ACCSLIMO.
           MOVE AC-EXPIRY-DATE    TO ACEXPO.
           MOVE AC-GROUP-ID       TO ACGRPO.
      *----------------------------------------------------------------*
      *  5000-VALIDATE-ALL : drive the individual field validations.  *
      *  Stops at the first failure so ERRMSGO names one problem.     *
      *----------------------------------------------------------------*
       5000-VALIDATE-ALL.
           SET WS-VALID TO TRUE.
           MOVE SPACES TO ERRMSGO.
           IF WS-VALID
               PERFORM 5010-VAL-STATUS
           END-IF.
           IF WS-VALID
               PERFORM 5020-VAL-CRLIM
           END-IF.
           IF WS-VALID
               PERFORM 5030-VAL-CSLIM
           END-IF.
           IF WS-VALID
               PERFORM 5040-VAL-RULES
           END-IF.
           IF WS-VALID
               PERFORM 5050-VAL-EXPIRY
           END-IF.
           IF WS-VALID
               PERFORM 5060-VAL-GROUP
           END-IF.
      *----------------------------------------------------------------*
      *  5010-VAL-STATUS : active status must be Y or N.             *
      *----------------------------------------------------------------*
       5010-VAL-STATUS.
           IF ACSTATI = 'Y' OR ACSTATI = 'N'
               MOVE ACSTATI TO WS-NEW-STATUS
           ELSE
               SET WS-INVALID TO TRUE
               MOVE 'Active status must be Y or N.' TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5020-VAL-CRLIM : credit limit must be a valid amount.        *
      *----------------------------------------------------------------*
       5020-VAL-CRLIM.
           MOVE ACCRLIMI TO WS-AE-IN.
           PERFORM 5100-PARSE-AMOUNT.
           IF WS-INVALID
               MOVE 'Credit limit is not a valid amount.' TO ERRMSGO
           ELSE
               MOVE WS-AE-RESULT TO WS-NEW-CRLIM
           END-IF.
      *----------------------------------------------------------------*
      *  5030-VAL-CSLIM : cash limit must be a valid amount.          *
      *----------------------------------------------------------------*
       5030-VAL-CSLIM.
           MOVE ACCSLIMI TO WS-AE-IN.
           PERFORM 5100-PARSE-AMOUNT.
           IF WS-INVALID
               MOVE 'Cash limit is not a valid amount.' TO ERRMSGO
           ELSE
               MOVE WS-AE-RESULT TO WS-NEW-CSLIM
           END-IF.
      *----------------------------------------------------------------*
      *  5040-VAL-RULES : cross-field business rules.                 *
      *----------------------------------------------------------------*
       5040-VAL-RULES.
           IF WS-NEW-CSLIM > WS-NEW-CRLIM
               SET WS-INVALID TO TRUE
               MOVE 'Cash limit cannot exceed credit limit.'
                   TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5050-VAL-EXPIRY : expiry date validated by OUDATE (VALD).    *
      *----------------------------------------------------------------*
       5050-VAL-EXPIRY.
           MOVE 'VALD'  TO KD-FUNC.
           MOVE ACEXPI  TO KD-DATE-IN.
           MOVE SPACES  TO KD-DATE-OUT.
           MOVE '00'    TO KD-STATUS.
           CALL 'OUDATE' USING KDATE-PARM.
           IF KD-STATUS = '00'
               MOVE ACEXPI TO WS-NEW-EXPIRY
           ELSE
               SET WS-INVALID TO TRUE
               MOVE 'Expiry date invalid, use YYYY-MM-DD.' TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5060-VAL-GROUP : disclosure group id is required.           *
      *----------------------------------------------------------------*
       5060-VAL-GROUP.
           IF ACGRPI = SPACES OR ACGRPI = LOW-VALUES
               SET WS-INVALID TO TRUE
               MOVE 'Group id is required.' TO ERRMSGO
           ELSE
               MOVE ACGRPI TO WS-NEW-GROUP
           END-IF.
      *----------------------------------------------------------------*
      *  5100-PARSE-AMOUNT : parse WS-AE-IN into WS-AE-RESULT.        *
      *  Accepts digits, ignores commas and spaces, allows one dot    *
      *  with at most two fraction digits.                            *
      *----------------------------------------------------------------*
       5100-PARSE-AMOUNT.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-AE-INT WS-AE-INT-CNT.
           MOVE ZEROS TO WS-AE-FRAC WS-AE-FRAC-CNT.
           MOVE 'N' TO WS-AE-DOT-SW.
           MOVE ZEROS TO WS-AE-RESULT.
           INSPECT WS-AE-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-AE-IN = SPACES
               SET WS-INVALID TO TRUE
               GO TO 5100-EXIT
           END-IF.
           PERFORM VARYING WS-AE-POS FROM 1 BY 1
                   UNTIL WS-AE-POS > 13
               MOVE WS-AE-IN(WS-AE-POS:1) TO WS-AE-CHAR
               EVALUATE TRUE
                   WHEN WS-AE-CHAR = SPACE
                       CONTINUE
                   WHEN WS-AE-CHAR = ','
                       CONTINUE
                   WHEN WS-AE-CHAR = '.'
                       IF WS-AE-DOT-SW = 'Y'
                           SET WS-INVALID TO TRUE
                       ELSE
                           MOVE 'Y' TO WS-AE-DOT-SW
                       END-IF
                   WHEN WS-AE-CHAR >= '0' AND WS-AE-CHAR <= '9'
                       PERFORM 5150-ACCUM-DIGIT
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-AE-FRAC-CNT = 1
               COMPUTE WS-AE-FRAC = WS-AE-FRAC * 10
           END-IF.
           COMPUTE WS-AE-RESULT = WS-AE-INT + (WS-AE-FRAC / 100).
       5100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5150-ACCUM-DIGIT : fold one digit into the integer or        *
      *  fraction accumulator depending on the decimal-point switch.  *
      *----------------------------------------------------------------*
       5150-ACCUM-DIGIT.
           MOVE WS-AE-CHAR TO WS-AE-DIGIT.
           IF WS-AE-DOT-SW = 'Y'
               ADD 1 TO WS-AE-FRAC-CNT
               IF WS-AE-FRAC-CNT > 2
                   SET WS-INVALID TO TRUE
               ELSE
                   COMPUTE WS-AE-FRAC = WS-AE-FRAC * 10 + WS-AE-DIGIT
               END-IF
           ELSE
               ADD 1 TO WS-AE-INT-CNT
               IF WS-AE-INT-CNT > 10
                   SET WS-INVALID TO TRUE
               ELSE
                   COMPUTE WS-AE-INT = WS-AE-INT * 10 + WS-AE-DIGIT
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  6000-VALIDATE-ACCTID : the account id must be numeric and    *
      *  fit in 11 digits.  Leading/trailing spaces are tolerated.    *
      *----------------------------------------------------------------*
       6000-VALIDATE-ACCTID.
           SET WS-VALID TO TRUE.
           MOVE ACCTIDI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN = SPACES
               SET WS-INVALID TO TRUE
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               GO TO 6000-EXIT
           END-IF.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > 11
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-INVALID OR WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
               MOVE 'Account id must be numeric.' TO ERRMSGO
           END-IF.
       6000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU : hand control back to the main menu.         *
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER : fill the common screen header.        *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY : refresh header and resend the map.      *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MACCTUA')
                     MAPSET('MACCTU')
                     FROM(MACCTUAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME : obtain formatted current date and time. *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN : pseudo-conversational return to this tran.     *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9500-ABEND-RTN : unrecoverable file error - inform and end.  *
      *----------------------------------------------------------------*
       9500-ABEND-RTN.
           MOVE 'OCACCTU: unrecoverable file error. Contact support.'
               TO WS-MSG-TEXT.
           EXEC CICS SEND TEXT
                     FROM(WS-MSG-TEXT)
                     LENGTH(LENGTH OF WS-MSG-TEXT)
                     ERASE
                     FREEKB
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS RETURN
                     RESP(WS-RESP-CD)
           END-EXEC.
