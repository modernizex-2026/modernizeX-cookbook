      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCCARDA  -  Card Add (on-line)                   *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: issue a new card against an existing account.     *
      *            The operator supplies the card number, account    *
      *            id, embossed name, CVV and expiry date.  The      *
      *            account must exist, the card number must be        *
      *            unique, and the expiry date must be valid.  On     *
      *            success the card master (CARDFILE) is written and  *
      *            a cross-reference (XREFFILE) links the card to     *
      *            its account and customer.                          *
      *            PF3 = back to menu, PF4 = clear, ENTER = add.      *
      *  MAPSET  : MCARDA      MAP : MCARDAA     TRANID : OROD       *
      *  FILES   : CARDFILE (read/write) ACCTFILE (read)            *
      *            XREFFILE (read/write)                             *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.      *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - card add.                     *
      *****************************************************************
      *  PROCESSING NARRATIVE                                        *
      *  1. Each entry field is validated in turn; the first fault    *
      *     is reported on the message line and the write suppressed. *
      *  2. The account id is read against ACCTFILE and must exist.   *
      *  3. The card number is read against CARDFILE and must NOT     *
      *     exist so the new key is unique.                           *
      *  4. The owning customer id is recovered from the account      *
      *     cross-reference stub written when the account was opened. *
      *  5. CARD-REC and XREF-REC are written.                        *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCCARDA.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCCARDA'.
           05  WS-TRANID            PIC X(04) VALUE 'OROD'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Validation / write switches local to this program.           *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
           05  WS-WRITE-SW          PIC X(01) VALUE 'N'.
               88  WS-WRITE-OK                VALUE 'Y'.
               88  WS-WRITE-BAD               VALUE 'N'.
      *----------------------------------------------------------------*
      *  Reusable numeric-field parser work area.                      *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(16) VALUE SPACES.
           05  WS-NC-LEN            PIC 9(02) VALUE ZEROS.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(16) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Validated new field values staged before the write.           *
      *----------------------------------------------------------------*
       01  WS-NEW-VALUES.
           05  WS-NEW-CARD          PIC X(16) VALUE SPACES.
           05  WS-NEW-ACCT          PIC 9(11) VALUE ZEROS.
           05  WS-NEW-CUST          PIC 9(09) VALUE ZEROS.
           05  WS-NEW-NAME          PIC X(50) VALUE SPACES.
           05  WS-NEW-CVV           PIC X(03) VALUE SPACES.
           05  WS-NEW-EXPIRY        PIC X(10) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Cross-reference stub key builder.                             *
      *----------------------------------------------------------------*
       01  WS-XREF-KEY              PIC 9(16) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter new card details and press ENTER.'.
           05  WS-M-CARD-REQ        PIC X(50)
               VALUE 'Card number must be sixteen digits.'.
           05  WS-M-ACCT-NUM        PIC X(50)
               VALUE 'Account id must be numeric.'.
           05  WS-M-ACCT-NF         PIC X(50)
               VALUE 'Account does not exist.'.
           05  WS-M-CARD-DUP        PIC X(50)
               VALUE 'Card number already exists.'.
           05  WS-M-NAME-REQ        PIC X(50)
               VALUE 'Embossed name is required.'.
           05  WS-M-CVV-NUM         PIC X(50)
               VALUE 'CVV must be three numeric digits.'.
           05  WS-M-EXP-BAD         PIC X(50)
               VALUE 'Expiry date invalid, use YYYY-MM-DD.'.
           05  WS-M-OK              PIC X(50)
               VALUE 'Card issued successfully.'.
           05  WS-M-WRITE-ERR       PIC X(50)
               VALUE 'Error writing the card file.'.
           05  WS-M-XREF-ERR        PIC X(50)
               VALUE 'Card written; cross-ref write failed.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY KDATE.
      *----------------------------------------------------------------*
      *  File record layouts and BMS symbolic map.                     *
      *----------------------------------------------------------------*
       COPY RCARD.
       COPY RACCT.
       COPY RXREF.
       COPY MCARDA.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  clear the map and prompt for entry.     *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MCARDAAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO CARDNUML.
           EXEC CICS SEND
                     MAP('MCARDAA')
                     MAPSET('MCARDA')
                     FROM(MCARDAAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-ADD-CARD
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-ADD-CARD  -  receive the map, validate and, when clean,  *
      *  write the new card and its cross-reference record.            *
      *----------------------------------------------------------------*
       2100-ADD-CARD.
           EXEC CICS RECEIVE
                     MAP('MCARDAA')
                     MAPSET('MCARDA')
                     INTO(MCARDAAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MCARDAAI
           END-IF.
           PERFORM 5000-VALIDATE-ALL.
           IF WS-INVALID
               MOVE -1 TO CARDNUML
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 3500-WRITE-CARD
               IF WS-WRITE-OK
                   PERFORM 3700-WRITE-XREF
                   MOVE WS-NEW-CARD TO CA-CARD-NUM
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-M-OK TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE -1 TO CARDNUML
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3000-READ-ACCT  -  confirm the owning account exists.         *
      *----------------------------------------------------------------*
       3000-READ-ACCT.
           SET REC-NOT-FOUND TO TRUE.
           MOVE WS-NEW-ACCT TO AC-ID.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3100-READ-CARD  -  confirm the card number is not already     *
      *  used.                                                        *
      *----------------------------------------------------------------*
       3100-READ-CARD.
           SET REC-NOT-FOUND TO TRUE.
           MOVE WS-NEW-CARD TO CD-NUM.
           EXEC CICS READ
                     FILE(WS-CARDFILE)
                     INTO(CARD-REC)
                     RIDFLD(CD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-READ-STUB  -  recover the owning customer id from the    *
      *  account cross-reference stub.  Absence is not fatal; the      *
      *  customer id then defaults to zero.                            *
      *----------------------------------------------------------------*
       3200-READ-STUB.
           MOVE ZEROS TO WS-NEW-CUST.
           MOVE WS-NEW-ACCT TO WS-XREF-KEY.
           MOVE WS-XREF-KEY TO XR-CARD-NUM.
           EXEC CICS READ
                     FILE(WS-XREFFILE)
                     INTO(XREF-REC)
                     RIDFLD(XR-CARD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               MOVE XR-CUST-ID TO WS-NEW-CUST
           END-IF.
      *----------------------------------------------------------------*
      *  3500-WRITE-CARD  -  build CARD-REC and write it.            *
      *----------------------------------------------------------------*
       3500-WRITE-CARD.
           SET WS-WRITE-BAD TO TRUE.
           INITIALIZE CARD-REC.
           MOVE WS-NEW-CARD   TO CD-NUM.
           MOVE WS-NEW-ACCT   TO CD-ACCT-ID.
           MOVE WS-NEW-CVV    TO CD-CVV.
           MOVE WS-NEW-NAME   TO CD-EMBOSSED-NAME.
           MOVE WS-NEW-EXPIRY TO CD-EXPIRY-DATE.
           MOVE 'Y'           TO CD-ACTIVE-STATUS.
           EXEC CICS WRITE
                     FILE(WS-CARDFILE)
                     FROM(CARD-REC)
                     RIDFLD(CD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-WRITE-OK TO TRUE
               WHEN DFHRESP(DUPREC)
                   MOVE WS-M-CARD-DUP TO ERRMSGO
               WHEN OTHER
                   MOVE WS-M-WRITE-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3700-WRITE-XREF  -  write the card cross-reference record.   *
      *----------------------------------------------------------------*
       3700-WRITE-XREF.
           INITIALIZE XREF-REC.
           MOVE WS-NEW-CARD TO XR-CARD-NUM.
           MOVE WS-NEW-ACCT TO XR-ACCT-ID.
           MOVE WS-NEW-CUST TO XR-CUST-ID.
           EXEC CICS WRITE
                     FILE(WS-XREFFILE)
                     FROM(XREF-REC)
                     RIDFLD(XR-CARD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(DUPREC)
                   CONTINUE
               WHEN OTHER
                   MOVE WS-M-XREF-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  5000-VALIDATE-ALL  -  drive the field validations, stopping   *
      *  at the first failure so one problem is named.                 *
      *----------------------------------------------------------------*
       5000-VALIDATE-ALL.
           SET WS-VALID TO TRUE.
           MOVE SPACES TO ERRMSGO.
           IF WS-VALID
               PERFORM 5010-VAL-CARD
           END-IF.
           IF WS-VALID
               PERFORM 5020-VAL-ACCT
           END-IF.
           IF WS-VALID
               PERFORM 5030-VAL-NAME
           END-IF.
           IF WS-VALID
               PERFORM 5040-VAL-CVV
           END-IF.
           IF WS-VALID
               PERFORM 5050-VAL-EXPIRY
           END-IF.
           IF WS-VALID
               PERFORM 5060-VAL-ACCT-EXISTS
           END-IF.
           IF WS-VALID
               PERFORM 5070-VAL-CARD-UNIQUE
           END-IF.
      *----------------------------------------------------------------*
      *  5010-VAL-CARD  -  card number must be sixteen numeric digits. *
      *----------------------------------------------------------------*
       5010-VAL-CARD.
           MOVE CARDNUMI TO WS-NC-IN.
           MOVE 16 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-DIGITS NOT = 16
               SET WS-INVALID TO TRUE
               MOVE WS-M-CARD-REQ TO ERRMSGO
           ELSE
               MOVE CARDNUMI TO WS-NEW-CARD
               INSPECT WS-NEW-CARD REPLACING ALL LOW-VALUE BY SPACE
           END-IF.
      *----------------------------------------------------------------*
      *  5020-VAL-ACCT  -  account id numeric and within 11 digits.    *
      *----------------------------------------------------------------*
       5020-VAL-ACCT.
           MOVE CDACCTI TO WS-NC-IN.
           MOVE 11 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-DIGITS > 11
               SET WS-INVALID TO TRUE
               MOVE WS-M-ACCT-NUM TO ERRMSGO
           ELSE
               MOVE WS-NC-VALUE TO WS-NEW-ACCT
           END-IF.
      *----------------------------------------------------------------*
      *  5030-VAL-NAME  -  embossed name is required.                  *
      *----------------------------------------------------------------*
       5030-VAL-NAME.
           IF CDNAMEI = SPACES OR CDNAMEI = LOW-VALUES
               SET WS-INVALID TO TRUE
               MOVE WS-M-NAME-REQ TO ERRMSGO
           ELSE
               MOVE CDNAMEI TO WS-NEW-NAME
           END-IF.
      *----------------------------------------------------------------*
      *  5040-VAL-CVV  -  CVV must be three numeric digits.            *
      *----------------------------------------------------------------*
       5040-VAL-CVV.
           MOVE CDCVVI TO WS-NC-IN.
           MOVE 3 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-DIGITS NOT = 3
               SET WS-INVALID TO TRUE
               MOVE WS-M-CVV-NUM TO ERRMSGO
           ELSE
               MOVE CDCVVI TO WS-NEW-CVV
               INSPECT WS-NEW-CVV REPLACING ALL LOW-VALUE BY SPACE
           END-IF.
      *----------------------------------------------------------------*
      *  5050-VAL-EXPIRY  -  expiry date validated by OUDATE (VALD).   *
      *----------------------------------------------------------------*
       5050-VAL-EXPIRY.
           MOVE 'VALD'  TO KD-FUNC.
           MOVE CDEXPI  TO KD-DATE-IN.
           MOVE SPACES  TO KD-DATE-OUT.
           MOVE '00'    TO KD-STATUS.
           CALL 'OUDATE' USING KDATE-PARM.
           IF KD-STATUS = '00'
               MOVE CDEXPI TO WS-NEW-EXPIRY
           ELSE
               SET WS-INVALID TO TRUE
               MOVE WS-M-EXP-BAD TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5060-VAL-ACCT-EXISTS  -  the account must be on file.         *
      *----------------------------------------------------------------*
       5060-VAL-ACCT-EXISTS.
           PERFORM 3000-READ-ACCT.
           IF REC-NOT-FOUND
               SET WS-INVALID TO TRUE
               MOVE WS-M-ACCT-NF TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5070-VAL-CARD-UNIQUE  -  the card number must be unused.      *
      *----------------------------------------------------------------*
       5070-VAL-CARD-UNIQUE.
           PERFORM 3100-READ-CARD.
           IF REC-FOUND
               SET WS-INVALID TO TRUE
               MOVE WS-M-CARD-DUP TO ERRMSGO
           ELSE
               PERFORM 3200-READ-STUB
           END-IF.
      *----------------------------------------------------------------*
      *  6000-PARSE-NUM  -  scan WS-NC-IN for WS-NC-LEN characters,
      *  ignore spaces, accumulate digits and count them.              *
      *----------------------------------------------------------------*
       6000-PARSE-NUM.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > WS-NC-LEN
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.*
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  refresh header and resend the map.     *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MCARDAA')
                     MAPSET('MCARDA')
                     FROM(MCARDAAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to this tran.    *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9500-ABEND-RTN  -  unrecoverable file error - inform and end. *
      *----------------------------------------------------------------*
       9500-ABEND-RTN.
           MOVE 'OCCARDA: unrecoverable file error. Contact support.'
               TO WS-MSG-TEXT.
           EXEC CICS SEND TEXT
                     FROM(WS-MSG-TEXT)
                     LENGTH(LENGTH OF WS-MSG-TEXT)
                     ERASE
                     FREEKB
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS RETURN
                     RESP(WS-RESP-CD)
           END-EXEC.
