      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCCUSTA  -  Customer Add (on-line)               *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: add a new customer to the customer master         *
      *            (CUSTFILE).  The operator supplies the customer   *
      *            id, name, address, city, social-security number   *
      *            and FICO score.  All required fields are checked   *
      *            and the id must be unique before the record is     *
      *            written.                                          *
      *            PF3 = back to menu, PF4 = clear, ENTER = add.      *
      *  MAPSET  : MCUSTA      MAP : MCUSTAA     TRANID : OROC       *
      *  FILES   : CUSTFILE (read for uniqueness / write)           *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.      *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - customer add.                  *
      *****************************************************************
      *  PROCESSING NARRATIVE                                        *
      *  1. Each entry field is validated in turn; the first fault    *
      *     is reported on the message line and the write suppressed. *
      *  2. CUST-REC is built from the validated fields and written   *
      *     with WRITE; a DUPREC response reports a duplicate id.     *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCCUSTA.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCCUSTA'.
           05  WS-TRANID            PIC X(04) VALUE 'OROC'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Validation / write switches local to this program.           *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
           05  WS-WRITE-SW          PIC X(01) VALUE 'N'.
               88  WS-WRITE-OK                VALUE 'Y'.
               88  WS-WRITE-BAD               VALUE 'N'.
      *----------------------------------------------------------------*
      *  Reusable numeric-field parser work area.                      *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(16) VALUE SPACES.
           05  WS-NC-LEN            PIC 9(02) VALUE ZEROS.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(16) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Validated new field values staged before the write.           *
      *----------------------------------------------------------------*
       01  WS-NEW-VALUES.
           05  WS-NEW-CUST          PIC 9(09) VALUE ZEROS.
           05  WS-NEW-SSN           PIC 9(09) VALUE ZEROS.
           05  WS-NEW-FICO          PIC 9(03) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter new customer details and press ENTER.'.
           05  WS-M-CUST-NUM        PIC X(50)
               VALUE 'Customer id must be numeric.'.
           05  WS-M-FNAME-REQ       PIC X(50)
               VALUE 'First name is required.'.
           05  WS-M-LNAME-REQ       PIC X(50)
               VALUE 'Last name is required.'.
           05  WS-M-ADDR-REQ        PIC X(50)
               VALUE 'Address line 1 is required.'.
           05  WS-M-CITY-REQ        PIC X(50)
               VALUE 'City is required.'.
           05  WS-M-SSN-NUM         PIC X(50)
               VALUE 'SSN must be nine numeric digits.'.
           05  WS-M-FICO-NUM        PIC X(50)
               VALUE 'FICO score must be numeric.'.
           05  WS-M-FICO-RNG        PIC X(50)
               VALUE 'FICO score must be 300 through 850.'.
           05  WS-M-CUST-DUP        PIC X(50)
               VALUE 'Customer id already exists.'.
           05  WS-M-OK              PIC X(50)
               VALUE 'Customer added successfully.'.
           05  WS-M-WRITE-ERR       PIC X(50)
               VALUE 'Error writing the customer file.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  File record layout and BMS symbolic map.                      *
      *----------------------------------------------------------------*
       COPY RCUST.
       COPY MCUSTA.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  clear the map and prompt for entry.     *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MCUSTAAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO CUSTIDL.
           EXEC CICS SEND
                     MAP('MCUSTAA')
                     MAPSET('MCUSTA')
                     FROM(MCUSTAAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-ADD-CUST
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-ADD-CUST  -  receive the map, validate and, when clean,  *
      *  write the new customer record.                               *
      *----------------------------------------------------------------*
       2100-ADD-CUST.
           EXEC CICS RECEIVE
                     MAP('MCUSTAA')
                     MAPSET('MCUSTA')
                     INTO(MCUSTAAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MCUSTAAI
           END-IF.
           PERFORM 5000-VALIDATE-ALL.
           IF WS-INVALID
               MOVE -1 TO CUSTIDL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 3500-WRITE-CUST
               IF WS-WRITE-OK
                   MOVE WS-NEW-CUST TO CA-CUST-ID
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-M-OK TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE -1 TO CUSTIDL
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3500-WRITE-CUST  -  build CUST-REC and write it.            *
      *----------------------------------------------------------------*
       3500-WRITE-CUST.
           SET WS-WRITE-BAD TO TRUE.
           INITIALIZE CUST-REC.
           MOVE WS-NEW-CUST TO CU-ID.
           MOVE CUFNAMI     TO CU-FIRST-NAME.
           MOVE SPACES      TO CU-MIDDLE-NAME.
           MOVE CULNAMI     TO CU-LAST-NAME.
           MOVE CUADDRI     TO CU-ADDR-LINE-1.
           MOVE SPACES      TO CU-ADDR-LINE-2.
           MOVE CUCITYI     TO CU-ADDR-CITY.
           MOVE SPACES      TO CU-ADDR-STATE.
           MOVE SPACES      TO CU-ADDR-COUNTRY.
           MOVE SPACES      TO CU-ADDR-ZIP.
           MOVE SPACES      TO CU-PHONE-1.
           MOVE SPACES      TO CU-PHONE-2.
           MOVE WS-NEW-SSN  TO CU-SSN.
           MOVE SPACES      TO CU-GOVT-ID.
           MOVE SPACES      TO CU-DOB.
           MOVE WS-NEW-FICO TO CU-FICO-SCORE.
           EXEC CICS WRITE
                     FILE(WS-CUSTFILE)
                     FROM(CUST-REC)
                     RIDFLD(CU-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-WRITE-OK TO TRUE
               WHEN DFHRESP(DUPREC)
                   MOVE WS-M-CUST-DUP TO ERRMSGO
               WHEN OTHER
                   MOVE WS-M-WRITE-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  5000-VALIDATE-ALL  -  drive the field validations, stopping   *
      *  at the first failure so one problem is named.                 *
      *----------------------------------------------------------------*
       5000-VALIDATE-ALL.
           SET WS-VALID TO TRUE.
           MOVE SPACES TO ERRMSGO.
           IF WS-VALID
               PERFORM 5010-VAL-CUST
           END-IF.
           IF WS-VALID
               PERFORM 5020-VAL-FNAME
           END-IF.
           IF WS-VALID
               PERFORM 5030-VAL-LNAME
           END-IF.
           IF WS-VALID
               PERFORM 5040-VAL-ADDR
           END-IF.
           IF WS-VALID
               PERFORM 5050-VAL-CITY
           END-IF.
           IF WS-VALID
               PERFORM 5060-VAL-SSN
           END-IF.
           IF WS-VALID
               PERFORM 5070-VAL-FICO
           END-IF.
      *----------------------------------------------------------------*
      *  5010-VAL-CUST  -  customer id numeric and within 9 digits.    *
      *----------------------------------------------------------------*
       5010-VAL-CUST.
           MOVE CUSTIDI TO WS-NC-IN.
           MOVE 9 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-DIGITS > 9
               SET WS-INVALID TO TRUE
               MOVE WS-M-CUST-NUM TO ERRMSGO
           ELSE
               MOVE WS-NC-VALUE TO WS-NEW-CUST
           END-IF.
      *----------------------------------------------------------------*
      *  5020-VAL-FNAME  -  first name is required.                    *
      *----------------------------------------------------------------*
       5020-VAL-FNAME.
           MOVE CUFNAMI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF CUFNAMI = SPACES OR CUFNAMI = LOW-VALUES
               SET WS-INVALID TO TRUE
               MOVE WS-M-FNAME-REQ TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5030-VAL-LNAME  -  last name is required.                     *
      *----------------------------------------------------------------*
       5030-VAL-LNAME.
           IF CULNAMI = SPACES OR CULNAMI = LOW-VALUES
               SET WS-INVALID TO TRUE
               MOVE WS-M-LNAME-REQ TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5040-VAL-ADDR  -  address line 1 is required.                 *
      *----------------------------------------------------------------*
       5040-VAL-ADDR.
           IF CUADDRI = SPACES OR CUADDRI = LOW-VALUES
               SET WS-INVALID TO TRUE
               MOVE WS-M-ADDR-REQ TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5050-VAL-CITY  -  city is required.                           *
      *----------------------------------------------------------------*
       5050-VAL-CITY.
           IF CUCITYI = SPACES OR CUCITYI = LOW-VALUES
               SET WS-INVALID TO TRUE
               MOVE WS-M-CITY-REQ TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5060-VAL-SSN  -  the SSN must be nine numeric digits.         *
      *----------------------------------------------------------------*
       5060-VAL-SSN.
           MOVE CUSSNI TO WS-NC-IN.
           MOVE 9 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-DIGITS NOT = 9
               SET WS-INVALID TO TRUE
               MOVE WS-M-SSN-NUM TO ERRMSGO
           ELSE
               MOVE WS-NC-VALUE TO WS-NEW-SSN
           END-IF.
      *----------------------------------------------------------------*
      *  5070-VAL-FICO  -  FICO score numeric and within 300 - 850.    *
      *----------------------------------------------------------------*
       5070-VAL-FICO.
           MOVE CUFICOI TO WS-NC-IN.
           MOVE 3 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-DIGITS > 3
               SET WS-INVALID TO TRUE
               MOVE WS-M-FICO-NUM TO ERRMSGO
           ELSE
               MOVE WS-NC-VALUE TO WS-NEW-FICO
               IF WS-NEW-FICO < 300 OR WS-NEW-FICO > 850
                   SET WS-INVALID TO TRUE
                   MOVE WS-M-FICO-RNG TO ERRMSGO
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  6000-PARSE-NUM  -  scan WS-NC-IN for WS-NC-LEN characters,
      *  ignore spaces, accumulate digits and count them.              *
      *----------------------------------------------------------------*
       6000-PARSE-NUM.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > WS-NC-LEN
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.*
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  refresh header and resend the map.     *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MCUSTAA')
                     MAPSET('MCUSTA')
                     FROM(MCUSTAAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to this tran.    *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
