      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCACCTA  -  Account Open (on-line)               *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: open a new credit-card account.  The operator    *
      *            supplies the account id, owning customer id,      *
      *            credit and cash limits, open date and disclosure  *
      *            group.  The customer must already exist, the      *
      *            account id must be unused, and the open date must  *
      *            be a valid calendar date.  On success the account  *
      *            master (ACCTFILE) is written and a cross-reference *
      *            stub (XREFFILE) links the account to its owner.    *
      *            PF3 = back to menu, PF4 = clear, ENTER = open.     *
      *  MAPSET  : MACCTA      MAP : MACCTAA     TRANID : OROA       *
      *  FILES   : ACCTFILE (read/write) CUSTFILE (read)            *
      *            XREFFILE (write)                                  *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.      *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - account open.                  *
      *****************************************************************
      *  PROCESSING NARRATIVE                                        *
      *  1. Every entry field is validated in turn; the first fault  *
      *     is reported on the message line and the write suppressed. *
      *  2. The customer id is read against CUSTFILE and must exist.  *
      *  3. The account id is read against ACCTFILE and must NOT      *
      *     exist so the new key is unique.                           *
      *  4. The open date is validated through the OUDATE subroutine  *
      *     (function VALD); a blank open date defaults to today.     *
      *  5. ACCT-REC is built and written; a cross-reference record   *
      *     keyed by the zero-filled account id (no card issued yet)  *
      *     is written to link the account to the customer.           *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCACCTA.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCACCTA'.
           05  WS-TRANID            PIC X(04) VALUE 'OROA'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Validation / write switches local to this program.           *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
           05  WS-WRITE-SW          PIC X(01) VALUE 'N'.
               88  WS-WRITE-OK                VALUE 'Y'.
               88  WS-WRITE-BAD               VALUE 'N'.
      *----------------------------------------------------------------*
      *  Reusable numeric-field parser work area.                      *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(16) VALUE SPACES.
           05  WS-NC-LEN            PIC 9(02) VALUE ZEROS.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(16) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Money-amount parser work area.                                *
      *----------------------------------------------------------------*
       01  WS-AMT-EDIT.
           05  WS-AE-IN             PIC X(13) VALUE SPACES.
           05  WS-AE-POS            PIC 9(02) VALUE ZEROS.
           05  WS-AE-CHAR           PIC X(01) VALUE SPACES.
           05  WS-AE-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-AE-INT            PIC 9(10) VALUE ZEROS.
           05  WS-AE-INT-CNT        PIC 9(02) VALUE ZEROS.
           05  WS-AE-FRAC           PIC 9(02) VALUE ZEROS.
           05  WS-AE-FRAC-CNT       PIC 9(01) VALUE ZEROS.
           05  WS-AE-DOT-SW         PIC X(01) VALUE 'N'.
           05  WS-AE-RESULT         PIC S9(10)V99 VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Validated new field values staged before the write.           *
      *----------------------------------------------------------------*
       01  WS-NEW-VALUES.
           05  WS-NEW-ACCT          PIC 9(11) VALUE ZEROS.
           05  WS-NEW-CUST          PIC 9(09) VALUE ZEROS.
           05  WS-NEW-CRLIM         PIC S9(10)V99 VALUE ZEROS.
           05  WS-NEW-CSLIM         PIC S9(10)V99 VALUE ZEROS.
           05  WS-NEW-OPEN          PIC X(10) VALUE SPACES.
           05  WS-NEW-GROUP         PIC X(10) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Cross-reference stub key builder.                             *
      *----------------------------------------------------------------*
       01  WS-XREF-KEY              PIC 9(16) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter new account details and press ENTER.'.
           05  WS-M-ACCT-NUM        PIC X(50)
               VALUE 'Account id must be numeric.'.
           05  WS-M-CUST-NUM        PIC X(50)
               VALUE 'Customer id must be numeric.'.
           05  WS-M-CUST-NF         PIC X(50)
               VALUE 'Customer does not exist.'.
           05  WS-M-ACCT-DUP        PIC X(50)
               VALUE 'Account id already exists.'.
           05  WS-M-CRLIM-BAD       PIC X(50)
               VALUE 'Credit limit is not a valid amount.'.
           05  WS-M-CSLIM-BAD       PIC X(50)
               VALUE 'Cash limit is not a valid amount.'.
           05  WS-M-CS-GT-CR        PIC X(50)
               VALUE 'Cash limit cannot exceed credit limit.'.
           05  WS-M-OPEN-BAD        PIC X(50)
               VALUE 'Open date invalid, use YYYY-MM-DD.'.
           05  WS-M-GROUP-REQ       PIC X(50)
               VALUE 'Disclosure group id is required.'.
           05  WS-M-OK              PIC X(50)
               VALUE 'Account opened successfully.'.
           05  WS-M-WRITE-ERR       PIC X(50)
               VALUE 'Error writing the account file.'.
           05  WS-M-XREF-ERR        PIC X(50)
               VALUE 'Account written; cross-ref write failed.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY KDATE.
      *----------------------------------------------------------------*
      *  File record layouts and BMS symbolic map.                     *
      *----------------------------------------------------------------*
       COPY RACCT.
       COPY RCUST.
       COPY RXREF.
       COPY MACCTA.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  clear the map and prompt for entry.     *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MACCTAAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO ACCTIDL.
           EXEC CICS SEND
                     MAP('MACCTAA')
                     MAPSET('MACCTA')
                     FROM(MACCTAAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-OPEN-ACCT
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-OPEN-ACCT  -  receive the map, validate and, when clean, *
      *  write the new account and its cross-reference stub.           *
      *----------------------------------------------------------------*
       2100-OPEN-ACCT.
           EXEC CICS RECEIVE
                     MAP('MACCTAA')
                     MAPSET('MACCTA')
                     INTO(MACCTAAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MACCTAAI
           END-IF.
           PERFORM 5000-VALIDATE-ALL.
           IF WS-INVALID
               MOVE -1 TO ACCTIDL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 3500-WRITE-ACCT
               IF WS-WRITE-OK
                   PERFORM 3700-WRITE-XREF
                   MOVE WS-NEW-ACCT TO CA-ACCT-ID
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-M-OK TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE -1 TO ACCTIDL
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3000-READ-CUST  -  confirm the owning customer exists.        *
      *----------------------------------------------------------------*
       3000-READ-CUST.
           SET REC-NOT-FOUND TO TRUE.
           MOVE WS-NEW-CUST TO CU-ID.
           EXEC CICS READ
                     FILE(WS-CUSTFILE)
                     INTO(CUST-REC)
                     RIDFLD(CU-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3100-READ-ACCT  -  confirm the account id is not already used.*
      *----------------------------------------------------------------*
       3100-READ-ACCT.
           SET REC-NOT-FOUND TO TRUE.
           MOVE WS-NEW-ACCT TO AC-ID.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3500-WRITE-ACCT  -  build ACCT-REC and write it.             *
      *----------------------------------------------------------------*
       3500-WRITE-ACCT.
           SET WS-WRITE-BAD TO TRUE.
           INITIALIZE ACCT-REC.
           MOVE WS-NEW-ACCT     TO AC-ID.
           MOVE 'Y'             TO AC-ACTIVE-STATUS.
           MOVE ZEROS          TO AC-CURR-BAL.
           MOVE WS-NEW-CRLIM    TO AC-CREDIT-LIMIT.
           MOVE WS-NEW-CSLIM    TO AC-CASH-LIMIT.
           MOVE WS-NEW-OPEN     TO AC-OPEN-DATE.
           MOVE SPACES          TO AC-EXPIRY-DATE.
           MOVE SPACES          TO AC-REISSUE-DATE.
           MOVE ZEROS          TO AC-CYC-CREDIT.
           MOVE ZEROS          TO AC-CYC-DEBIT.
           MOVE SPACES          TO AC-ADDR-ZIP.
           MOVE WS-NEW-GROUP    TO AC-GROUP-ID.
           EXEC CICS WRITE
                     FILE(WS-ACCTFILE)
                     FROM(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-WRITE-OK TO TRUE
               WHEN DFHRESP(DUPREC)
                   MOVE WS-M-ACCT-DUP TO ERRMSGO
               WHEN OTHER
                   MOVE WS-M-WRITE-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3700-WRITE-XREF  -  write the account-to-customer stub.  The  *
      *  cross-reference key is the account id right-justified into    *
      *  sixteen digits, standing in for the not-yet-issued card.      *
      *----------------------------------------------------------------*
       3700-WRITE-XREF.
           INITIALIZE XREF-REC.
           MOVE WS-NEW-ACCT TO WS-XREF-KEY.
           MOVE WS-XREF-KEY TO XR-CARD-NUM.
           MOVE WS-NEW-ACCT TO XR-ACCT-ID.
           MOVE WS-NEW-CUST TO XR-CUST-ID.
           EXEC CICS WRITE
                     FILE(WS-XREFFILE)
                     FROM(XREF-REC)
                     RIDFLD(XR-CARD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(DUPREC)
                   CONTINUE
               WHEN OTHER
                   MOVE WS-M-XREF-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  5000-VALIDATE-ALL  -  drive the field validations, stopping   *
      *  at the first failure so one problem is named.                 *
      *----------------------------------------------------------------*
       5000-VALIDATE-ALL.
           SET WS-VALID TO TRUE.
           MOVE SPACES TO ERRMSGO.
           IF WS-VALID
               PERFORM 5010-VAL-ACCT
           END-IF.
           IF WS-VALID
               PERFORM 5020-VAL-CUST
           END-IF.
           IF WS-VALID
               PERFORM 5030-VAL-CRLIM
           END-IF.
           IF WS-VALID
               PERFORM 5040-VAL-CSLIM
           END-IF.
           IF WS-VALID
               PERFORM 5050-VAL-RULES
           END-IF.
           IF WS-VALID
               PERFORM 5060-VAL-OPEN
           END-IF.
           IF WS-VALID
               PERFORM 5070-VAL-GROUP
           END-IF.
           IF WS-VALID
               PERFORM 5080-VAL-CUST-EXISTS
           END-IF.
           IF WS-VALID
               PERFORM 5090-VAL-ACCT-UNIQUE
           END-IF.
      *----------------------------------------------------------------*
      *  5010-VAL-ACCT  -  account id numeric and within 11 digits.    *
      *----------------------------------------------------------------*
       5010-VAL-ACCT.
           MOVE ACCTIDI TO WS-NC-IN.
           MOVE 11 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-DIGITS > 11
               SET WS-INVALID TO TRUE
               MOVE WS-M-ACCT-NUM TO ERRMSGO
           ELSE
               MOVE WS-NC-VALUE TO WS-NEW-ACCT
           END-IF.
      *----------------------------------------------------------------*
      *  5020-VAL-CUST  -  customer id numeric and within 9 digits.    *
      *----------------------------------------------------------------*
       5020-VAL-CUST.
           MOVE CUSTIDI TO WS-NC-IN.
           MOVE 9 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-DIGITS > 9
               SET WS-INVALID TO TRUE
               MOVE WS-M-CUST-NUM TO ERRMSGO
           ELSE
               MOVE WS-NC-VALUE TO WS-NEW-CUST
           END-IF.
      *----------------------------------------------------------------*
      *  5030-VAL-CRLIM  -  credit limit must parse as an amount.      *
      *----------------------------------------------------------------*
       5030-VAL-CRLIM.
           MOVE ACCRLIMI TO WS-AE-IN.
           PERFORM 5100-PARSE-AMOUNT.
           IF WS-INVALID
               MOVE WS-M-CRLIM-BAD TO ERRMSGO
           ELSE
               MOVE WS-AE-RESULT TO WS-NEW-CRLIM
           END-IF.
      *----------------------------------------------------------------*
      *  5040-VAL-CSLIM  -  cash limit must parse as an amount.        *
      *----------------------------------------------------------------*
       5040-VAL-CSLIM.
           MOVE ACCSLIMI TO WS-AE-IN.
           PERFORM 5100-PARSE-AMOUNT.
           IF WS-INVALID
               MOVE WS-M-CSLIM-BAD TO ERRMSGO
           ELSE
               MOVE WS-AE-RESULT TO WS-NEW-CSLIM
           END-IF.
      *----------------------------------------------------------------*
      *  5050-VAL-RULES  -  cross-field business rules.                *
      *----------------------------------------------------------------*
       5050-VAL-RULES.
           IF WS-NEW-CSLIM > WS-NEW-CRLIM
               SET WS-INVALID TO TRUE
               MOVE WS-M-CS-GT-CR TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5060-VAL-OPEN  -  open date; blank defaults to today, other   *
      *  values are validated by OUDATE.                              *
      *----------------------------------------------------------------*
       5060-VAL-OPEN.
           MOVE ACOPENI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN(1:10) = SPACES
               MOVE 'TODY'   TO KD-FUNC
               MOVE SPACES   TO KD-DATE-IN
               MOVE SPACES   TO KD-DATE-OUT
               MOVE '00'     TO KD-STATUS
               CALL 'OUDATE' USING KDATE-PARM
               MOVE KD-DATE-OUT TO WS-NEW-OPEN
           ELSE
               MOVE 'VALD'   TO KD-FUNC
               MOVE ACOPENI  TO KD-DATE-IN
               MOVE SPACES   TO KD-DATE-OUT
               MOVE '00'     TO KD-STATUS
               CALL 'OUDATE' USING KDATE-PARM
               IF KD-STATUS = '00'
                   MOVE ACOPENI TO WS-NEW-OPEN
               ELSE
                   SET WS-INVALID TO TRUE
                   MOVE WS-M-OPEN-BAD TO ERRMSGO
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  5070-VAL-GROUP  -  disclosure group id is required.           *
      *----------------------------------------------------------------*
       5070-VAL-GROUP.
           MOVE ACGRPI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN(1:10) = SPACES
               SET WS-INVALID TO TRUE
               MOVE WS-M-GROUP-REQ TO ERRMSGO
           ELSE
               MOVE ACGRPI TO WS-NEW-GROUP
           END-IF.
      *----------------------------------------------------------------*
      *  5080-VAL-CUST-EXISTS  -  the customer must be on file.        *
      *----------------------------------------------------------------*
       5080-VAL-CUST-EXISTS.
           PERFORM 3000-READ-CUST.
           IF REC-NOT-FOUND
               SET WS-INVALID TO TRUE
               MOVE WS-M-CUST-NF TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5090-VAL-ACCT-UNIQUE  -  the account id must be unused.       *
      *----------------------------------------------------------------*
       5090-VAL-ACCT-UNIQUE.
           PERFORM 3100-READ-ACCT.
           IF REC-FOUND
               SET WS-INVALID TO TRUE
               MOVE WS-M-ACCT-DUP TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5100-PARSE-AMOUNT  -  parse WS-AE-IN into WS-AE-RESULT.       *
      *  Accepts digits, ignores commas and spaces, allows one dot     *
      *  with at most two fraction digits.                            *
      *----------------------------------------------------------------*
       5100-PARSE-AMOUNT.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-AE-INT WS-AE-INT-CNT.
           MOVE ZEROS TO WS-AE-FRAC WS-AE-FRAC-CNT.
           MOVE 'N' TO WS-AE-DOT-SW.
           MOVE ZEROS TO WS-AE-RESULT.
           INSPECT WS-AE-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-AE-IN = SPACES
               SET WS-INVALID TO TRUE
               GO TO 5100-EXIT
           END-IF.
           PERFORM VARYING WS-AE-POS FROM 1 BY 1
                   UNTIL WS-AE-POS > 13
               MOVE WS-AE-IN(WS-AE-POS:1) TO WS-AE-CHAR
               EVALUATE TRUE
                   WHEN WS-AE-CHAR = SPACE
                       CONTINUE
                   WHEN WS-AE-CHAR = ','
                       CONTINUE
                   WHEN WS-AE-CHAR = '.'
                       IF WS-AE-DOT-SW = 'Y'
                           SET WS-INVALID TO TRUE
                       ELSE
                           MOVE 'Y' TO WS-AE-DOT-SW
                       END-IF
                   WHEN WS-AE-CHAR >= '0' AND WS-AE-CHAR <= '9'
                       PERFORM 5150-ACCUM-DIGIT
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-AE-FRAC-CNT = 1
               COMPUTE WS-AE-FRAC = WS-AE-FRAC * 10
           END-IF.
           COMPUTE WS-AE-RESULT = WS-AE-INT + (WS-AE-FRAC / 100).
       5100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5150-ACCUM-DIGIT  -  fold one digit into the integer or       *
      *  fraction accumulator depending on the decimal-point switch.   *
      *----------------------------------------------------------------*
       5150-ACCUM-DIGIT.
           MOVE WS-AE-CHAR TO WS-AE-DIGIT.
           IF WS-AE-DOT-SW = 'Y'
               ADD 1 TO WS-AE-FRAC-CNT
               IF WS-AE-FRAC-CNT > 2
                   SET WS-INVALID TO TRUE
               ELSE
                   COMPUTE WS-AE-FRAC = WS-AE-FRAC * 10 + WS-AE-DIGIT
               END-IF
           ELSE
               ADD 1 TO WS-AE-INT-CNT
               IF WS-AE-INT-CNT > 10
                   SET WS-INVALID TO TRUE
               ELSE
                   COMPUTE WS-AE-INT = WS-AE-INT * 10 + WS-AE-DIGIT
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  6000-PARSE-NUM  -  scan WS-NC-IN for WS-NC-LEN characters,
      *  ignore spaces, accumulate digits and count them.              *
      *----------------------------------------------------------------*
       6000-PARSE-NUM.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > WS-NC-LEN
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.*
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  refresh header and resend the map.     *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MACCTAA')
                     MAPSET('MACCTA')
                     FROM(MACCTAAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to this tran.    *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9500-ABEND-RTN  -  unrecoverable file error - inform and end. *
      *----------------------------------------------------------------*
       9500-ABEND-RTN.
           MOVE 'OCACCTA: unrecoverable file error. Contact support.'
               TO WS-MSG-TEXT.
           EXEC CICS SEND TEXT
                     FROM(WS-MSG-TEXT)
                     LENGTH(LENGTH OF WS-MSG-TEXT)
                     ERASE
                     FREEKB
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS RETURN
                     RESP(WS-RESP-CD)
           END-EXEC.
