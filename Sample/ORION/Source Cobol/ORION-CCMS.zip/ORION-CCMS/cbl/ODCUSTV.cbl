      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : ODCUSTV  -  Customer View (on-line, DB2)          *
      *  TYPE    : CICS ONLINE + DB2  (pseudo-conversational)        *
      *  FUNCTION: accept a customer id, SELECT the customer row     *
      *            from the CUST table (ORION.CUST) via EXEC SQL and *
      *            display the customer details on map MCUSTV.       *
      *            PF3 = back to menu, PF4 = clear, ENTER = read.    *
      *  NOTE    : DB2 variant of the OCCUSTV online program.        *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. ODCUSTV.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'ODCUSTV'.
           05  WS-TRANID            PIC X(04) VALUE 'OD04'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
       01  WS-NAME-BUILD.
           05  WS-FULL-NAME         PIC X(50) VALUE SPACES.
      *----------------------------------------------------------------*
      *  DB2 communication area.                                       *
      *----------------------------------------------------------------*
           EXEC SQL INCLUDE SQLCA END-EXEC.
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RCUST.
       COPY MCUSTV.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MCUSTVAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter customer id and press ENTER.' TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MCUSTVA')
                     MAPSET('MCUSTV')
                     FROM(MCUSTVAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-READ-AND-SHOW
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
       2100-READ-AND-SHOW.
           EXEC CICS RECEIVE
                     MAP('MCUSTVA')
                     MAPSET('MCUSTV')
                     INTO(MCUSTVAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF CUSTIDI = SPACES OR CUSTIDI = LOW-VALUES
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               IF CUSTIDI IS NUMERIC
                   MOVE CUSTIDI TO CU-ID
                   MOVE CU-ID   TO CA-CUST-ID
                   PERFORM 3000-READ-CUST
                   IF REC-FOUND
                       PERFORM 4000-POPULATE-DETAIL
                       MOVE 'Customer displayed.' TO ERRMSGO
                       PERFORM 8100-SEND-DATAONLY
                   ELSE
                       MOVE WS-MSG-NOTFND TO ERRMSGO
                       PERFORM 8100-SEND-DATAONLY
                   END-IF
               ELSE
                   MOVE 'Customer id must be numeric.' TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  DB2 read : SELECT the customer row by primary key CU_ID.      *
      *----------------------------------------------------------------*
       3000-READ-CUST.
           SET REC-NOT-FOUND TO TRUE.
           EXEC SQL
                SELECT CU_FIRST_NAME,
                       CU_MIDDLE_NAME,
                       CU_LAST_NAME,
                       CU_ADDR_LINE_1,
                       CU_ADDR_CITY,
                       CU_PHONE_1,
                       CU_FICO_SCORE
                  INTO :CU-FIRST-NAME,
                       :CU-MIDDLE-NAME,
                       :CU-LAST-NAME,
                       :CU-ADDR-LINE-1,
                       :CU-ADDR-CITY,
                       :CU-PHONE-1,
                       :CU-FICO-SCORE
                  FROM ORION.CUST
                 WHERE CU_ID = :CU-ID
           END-EXEC.
           EVALUATE SQLCODE
               WHEN 0
                   SET REC-FOUND TO TRUE
               WHEN 100
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   MOVE 'Error reading customer table.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE SPACES TO WS-FULL-NAME.
           STRING CU-FIRST-NAME  DELIMITED BY SPACE
                  ' '            DELIMITED BY SIZE
                  CU-MIDDLE-NAME DELIMITED BY SPACE
                  ' '            DELIMITED BY SIZE
                  CU-LAST-NAME   DELIMITED BY SPACE
                  INTO WS-FULL-NAME
               ON OVERFLOW CONTINUE
           END-STRING.
           MOVE CU-ID           TO CUSTIDO.
           MOVE WS-FULL-NAME    TO CUNAMEO.
           MOVE CU-ADDR-LINE-1  TO CUADDRO.
           MOVE CU-ADDR-CITY    TO CUCITYO.
           MOVE CU-PHONE-1      TO CUPHONEO.
           MOVE CU-FICO-SCORE   TO CUFICOO.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MCUSTVA')
                     MAPSET('MCUSTV')
                     FROM(MCUSTVAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
