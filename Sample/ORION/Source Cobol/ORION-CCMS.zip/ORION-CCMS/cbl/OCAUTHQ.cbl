      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCAUTHQ  -  Card Authorization via MQ (on-line)   *
      *  TYPE    : CICS ONLINE + MQ  (pseudo-conversational)        *
      *  FUNCTION: accept card / amount / merchant, LINK the MQ      *
      *            requester OUMQREQ to authorize the card, and      *
      *            display the approve / decline decision.           *
      *            PF3 = back to menu, PF4 = clear, ENTER = submit.  *
      *  NOTE    : mirrors the OCACCTV golden online structure.      *
      *****************************************************************
      *---------------------------------------------------------------*
      *  PATTERN                                                       *
      *  -------                                                       *
      *  BMS screen -> LINK sub-program.  OCAUTHQ owns the MAUTHQ map *
      *  and the ORAQ transaction; it never issues an MQI call itself. *
      *  Instead it packs the request into the commarea work area and  *
      *  EXEC CICS LINKs OUMQREQ, which performs the MQOPEN / MQPUT /  *
      *  MQGET / MQCLOSE round-trip and the local credit check, then   *
      *  returns the decision in the same commarea.                    *
      *---------------------------------------------------------------*
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCAUTHQ.
       AUTHOR.     ORION-CCMS-ONLINE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *---------------------------------------------------------------*
      *  Program identity and linked program names.                   *
      *---------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCAUTHQ'.
           05  WS-TRANID            PIC X(04) VALUE 'ORAQ'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
           05  WS-MQREQ-PGM         PIC X(08) VALUE 'OUMQREQ'.
      *---------------------------------------------------------------*
      *  Saved screen input + converted amount.                      *
      *---------------------------------------------------------------*
       01  WS-SCREEN-IN.
           05  WS-IN-CARD           PIC X(16) VALUE SPACES.
           05  WS-IN-AMT            PIC X(12) VALUE SPACES.
           05  WS-IN-MERCH          PIC X(20) VALUE SPACES.
       01  WS-AMT-NUM               PIC S9(09)V99 VALUE ZERO.
      *---------------------------------------------------------------*
      *  Shared copybooks (as used by the golden OCACCTV).            *
      *---------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY KAUTH.
       COPY MAUTHQ.
       COPY DFHAID.
       COPY DFHBMSCA.
      *---------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *---------------------------------------------------------------*
       PROCEDURE DIVISION.
      *---------------------------------------------------------------*
      *  0000-MAIN - pseudo-conversational entry logic.             *
      *---------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *---------------------------------------------------------------*
      *  1000-SEND-INITIAL - paint an empty authorization screen.   *
      *---------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MAUTHQAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter card, amount, merchant; press ENTER.'
               TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MAUTHQA')
                     MAPSET('MAUTHQ')
                     FROM(MAUTHQAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *---------------------------------------------------------------*
      *  2000-PROCESS-INPUT - dispatch on the AID key.              *
      *---------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-AUTHORIZE
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *---------------------------------------------------------------*
      *  2100-AUTHORIZE - receive the map, validate, LINK OUMQREQ.  *
      *---------------------------------------------------------------*
       2100-AUTHORIZE.
           EXEC CICS RECEIVE
                     MAP('MAUTHQA')
                     MAPSET('MAUTHQ')
                     INTO(MAUTHQAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE CARDNUMI TO WS-IN-CARD.
           MOVE AMOUNTI  TO WS-IN-AMT.
           MOVE MERCHI   TO WS-IN-MERCH.
           PERFORM 2200-VALIDATE-INPUT.
           IF ERR-FLG-ON
               PERFORM 2600-POPULATE-ECHO
               MOVE SPACES TO DECISNO
               MOVE SPACES TO REASONO
               MOVE SPACES TO AVAILO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 2300-CALL-MQREQ
               PERFORM 2400-SHOW-DECISION
           END-IF.
      *---------------------------------------------------------------*
      *  2200-VALIDATE-INPUT - card + positive amount are required.  *
      *---------------------------------------------------------------*
       2200-VALIDATE-INPUT.
           SET ERR-FLG-OFF TO TRUE.
           IF WS-IN-CARD = SPACES OR WS-IN-CARD = LOW-VALUES
               SET ERR-FLG-ON TO TRUE
               MOVE 'Card number is required.' TO ERRMSGO
           END-IF.
           IF ERR-FLG-OFF
               IF WS-IN-AMT = SPACES OR WS-IN-AMT = LOW-VALUES
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Amount is required.' TO ERRMSGO
               END-IF
           END-IF.
           IF ERR-FLG-OFF
               COMPUTE WS-AMT-NUM = FUNCTION NUMVAL(WS-IN-AMT)
               IF WS-AMT-NUM <= ZERO
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Amount must be greater than zero.'
                       TO ERRMSGO
               END-IF
           END-IF.
      *---------------------------------------------------------------*
      *  2300-CALL-MQREQ - build the request in the commarea work     *
      *  area and LINK the MQ requester sub-program.                 *
      *---------------------------------------------------------------*
       2300-CALL-MQREQ.
           INITIALIZE AUTH-MSG-AREA.
           MOVE 'AREQ'        TO AQ-MSG-TYPE.
           MOVE WS-IN-CARD    TO AQ-CARD-NUM.
           MOVE ZERO          TO AQ-ACCT-ID.
           MOVE WS-AMT-NUM    TO AQ-AMOUNT.
           MOVE ZERO          TO AQ-MERCHANT-ID.
           MOVE WS-IN-MERCH   TO AQ-MERCHANT-NAME.
           MOVE SPACES        TO AQ-REQUESTED-TS.
           MOVE WS-IN-CARD    TO CA-CARD-NUM.
           MOVE AUTH-MSG-AREA TO CA-WORK-AREA.
           EXEC CICS LINK
                     PROGRAM(WS-MQREQ-PGM)
                     COMMAREA(ORION-COMMAREA)
                     LENGTH(LENGTH OF ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               MOVE CA-WORK-AREA TO AUTH-MSG-AREA
           ELSE
               MOVE SPACES TO AUTH-MSG-AREA
               SET AS-ERRORED TO TRUE
               MOVE 'LINK OUMQREQ FAILED' TO AS-REASON
               DISPLAY 'OCAUTHQ: LINK RESP=' WS-RESP-CD
           END-IF.
      *---------------------------------------------------------------*
      *  2400-SHOW-DECISION - display the decision returned by MQ.   *
      *---------------------------------------------------------------*
       2400-SHOW-DECISION.
           PERFORM 2600-POPULATE-ECHO.
           MOVE AS-DECISION     TO DECISNO.
           MOVE AS-REASON       TO REASONO.
           MOVE AS-AVAIL-CREDIT TO WS-ED-BAL.
      *    AVAILO is X(15) but WS-ED-BAL edits to 16 chars; drop the
      *    leading sign position so the value is not right-truncated.
           MOVE WS-ED-BAL(2:15) TO AVAILO.
           IF CA-ERR-ON
               MOVE CA-ERR-MSG TO ERRMSGO
           ELSE
               MOVE 'Authorization complete. PF3=Back.' TO ERRMSGO
           END-IF.
           PERFORM 8100-SEND-DATAONLY.
      *---------------------------------------------------------------*
      *  2600-POPULATE-ECHO - re-display the entered request fields. *
      *---------------------------------------------------------------*
       2600-POPULATE-ECHO.
           MOVE WS-IN-CARD  TO CARDNUMO.
           MOVE WS-IN-AMT   TO AMOUNTO.
           MOVE WS-IN-MERCH TO MERCHO.
      *---------------------------------------------------------------*
      *  7000-XCTL-MENU - hand control back to the main menu.        *
      *---------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *---------------------------------------------------------------*
      *  8000-POPULATE-HEADER - standard screen header fields.       *
      *---------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *---------------------------------------------------------------*
      *  8100-SEND-DATAONLY - repaint the data with the header.      *
      *---------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MAUTHQA')
                     MAPSET('MAUTHQ')
                     FROM(MAUTHQAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *---------------------------------------------------------------*
      *  8500-GET-DATE-TIME - current date / time for the header.    *
      *---------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *---------------------------------------------------------------*
      *  9000-RETURN - pseudo-conversational return to ORAQ.        *
      *---------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
