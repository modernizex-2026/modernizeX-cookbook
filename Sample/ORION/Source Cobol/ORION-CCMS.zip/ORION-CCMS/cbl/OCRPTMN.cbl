      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCRPTMN  -  Reports Menu (on-line)               *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: present the reports / inquiry menu and transfer   *
      *            control to the chosen inquiry function.  These    *
      *            on-line inquiries REPLACE the former batch print  *
      *            reports: the operator queries the data directly   *
      *            on the screen instead of printing a listing.      *
      *            PF3 returns to the main menu.                      *
      *  MAPSET  : MRPTMN      MAP : MRPTMNA     TRANID : ORRM        *
      *  DISPATCH (mirrors OCMENU): option -> program via XCTL       *
      *     1 Account inquiry      OCACCTL  (was account listings)   *
      *     2 Card inquiry         OCCARDL                           *
      *     3 Customer inquiry     OCCUSTL                           *
      *     4 Transaction inquiry  OCTRANL                           *
      *     5 Statement inquiry    OCSTMIN  (was OBRSTMT / OBSTMTX)  *
      *     6 Analytics inquiry    OCANLIN  (was OBRWD / OBRFRD /    *
      *                                     OBGLEX / OBRECON)        *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - reports / inquiry menu.        *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCRPTMN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCRPTMN'.
           05  WS-TRANID            PIC X(04) VALUE 'ORRM'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
           05  WS-XCTL-PGM          PIC X(08) VALUE SPACES.
           05  WS-XCTL-TRAN         PIC X(04) VALUE SPACES.
           05  WS-OPTION            PIC 9(02) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Select an inquiry (1-6) and press ENTER.'.
           05  WS-M-BAD-OPT         PIC X(50)
               VALUE 'Invalid option - choose 1 through 6.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  BMS symbolic map and IBM-supplied constants.                  *
      *----------------------------------------------------------------*
       COPY MRPTMN.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit the menu screen.     *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MRPTMNAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO OPTIONL.
           EXEC CICS SEND
                     MAP('MRPTMNA')
                     MAPSET('MRPTMN')
                     FROM(MRPTMNAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MAIN
               WHEN DFHENTER
                   PERFORM 2100-DISPATCH
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-DISPATCH  -  receive the option and select the target    *
      *  inquiry program, then XCTL to it (or report a bad option).    *
      *----------------------------------------------------------------*
       2100-DISPATCH.
           EXEC CICS RECEIVE
                     MAP('MRPTMNA')
                     MAPSET('MRPTMN')
                     INTO(MRPTMNAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MRPTMNAI
           END-IF.
           IF OPTIONI NUMERIC
               MOVE OPTIONI TO WS-OPTION
           ELSE
               MOVE 0 TO WS-OPTION
           END-IF.
           PERFORM 2200-SELECT-TARGET.
           IF WS-XCTL-PGM = SPACES
               PERFORM 1000-SEND-INITIAL
               MOVE WS-M-BAD-OPT TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 7100-XCTL-TARGET
           END-IF.
      *----------------------------------------------------------------*
      *  2200-SELECT-TARGET  -  map the option to a program name.      *
      *----------------------------------------------------------------*
       2200-SELECT-TARGET.
           MOVE SPACES TO WS-XCTL-PGM.
           MOVE SPACES TO WS-XCTL-TRAN.
           EVALUATE WS-OPTION
               WHEN 1
                   MOVE 'OCACCTL' TO WS-XCTL-PGM
                   MOVE 'ORLA'    TO WS-XCTL-TRAN
               WHEN 2
                   MOVE 'OCCARDL' TO WS-XCTL-PGM
                   MOVE 'ORCL'    TO WS-XCTL-TRAN
               WHEN 3
                   MOVE 'OCCUSTL' TO WS-XCTL-PGM
                   MOVE 'ORLC'    TO WS-XCTL-TRAN
               WHEN 4
                   MOVE 'OCTRANL' TO WS-XCTL-PGM
                   MOVE 'ORTL'    TO WS-XCTL-TRAN
               WHEN 5
                   MOVE 'OCSTMIN' TO WS-XCTL-PGM
                   MOVE 'ORSI'    TO WS-XCTL-TRAN
               WHEN 6
                   MOVE 'OCANLIN' TO WS-XCTL-PGM
                   MOVE 'ORAN'    TO WS-XCTL-TRAN
               WHEN OTHER
                   MOVE SPACES TO WS-XCTL-PGM
                   MOVE SPACES TO WS-XCTL-TRAN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  7000-XCTL-MAIN  -  return to the main menu.                   *
      *----------------------------------------------------------------*
       7000-XCTL-MAIN.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  7100-XCTL-TARGET  -  transfer to the chosen inquiry program.  *
      *  CA-PGM-CONTEXT is reset so the target does a first-enter.     *
      *----------------------------------------------------------------*
       7100-XCTL-TARGET.
           MOVE WS-PGMNAME  TO CA-FROM-PROGRAM.
           MOVE WS-TRANID   TO CA-FROM-TRANID.
           MOVE WS-XCTL-PGM TO CA-TO-PROGRAM.
           MOVE WS-XCTL-TRAN TO CA-TO-TRANID.
           MOVE 0           TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-XCTL-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  re-transmit the map data only.         *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MRPTMNA')
                     MAPSET('MRPTMN')
                     FROM(MRPTMNAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to CICS.         *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *                   E N D   O F   O C R P T M N                  *
      *----------------------------------------------------------------*
