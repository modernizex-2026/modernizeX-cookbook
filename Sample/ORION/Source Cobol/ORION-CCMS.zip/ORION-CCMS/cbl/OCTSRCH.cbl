      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCTSRCH  -  Transaction Search (on-line)         *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: search the transaction file (TRANFILE) for the    *
      *            transactions of a card whose amount falls within   *
      *            an operator-supplied range.  The file is browsed   *
      *            sequentially and the matching records shown, up to  *
      *            a maximum of five, on the result lines.            *
      *            PF3 = back to menu, PF4 = clear, ENTER = search.   *
      *  MAPSET  : MTSRCH      MAP : MTSRCHA     TRANID : ORTS       *
      *  FILES   : TRANFILE (browse - STARTBR / READNEXT / ENDBR)   *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.      *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - transaction search.           *
      *****************************************************************
      *  PROCESSING NARRATIVE                                        *
      *  1. The operator keys a card number and, optionally, a low    *
      *     and high amount.  A blank low amount means zero; a blank  *
      *     high amount means no upper limit.                         *
      *  2. TRANFILE is browsed forward.  Each record whose card      *
      *     matches and whose amount is within the range is formatted *
      *     into the next result line, to a maximum of five.          *
      *  3. A summary count is shown on the message line.             *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCTSRCH.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCTSRCH'.
           05  WS-TRANID            PIC X(04) VALUE 'ORTS'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Browse control and search work fields.                        *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-CARD-KEY          PIC X(16) VALUE SPACES.
           05  WS-FROM-AMT          PIC S9(10)V99 VALUE ZEROS.
           05  WS-TO-AMT            PIC S9(10)V99 VALUE ZEROS.
           05  WS-ROW-CNT           PIC 9(01) VALUE ZEROS.
           05  WS-MAX-ROWS          PIC 9(01) VALUE 5.
           05  WS-BROWSE-STARTED    PIC X(01) VALUE 'N'.
               88  WS-BR-ON                   VALUE 'Y'.
               88  WS-BR-OFF                  VALUE 'N'.
           05  WS-CNT-ED            PIC Z9.
           05  WS-SR-LINE           PIC X(70) VALUE SPACES.
           05  WS-AMT-DISP          PIC X(15) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Validation switch shared by the parsers.                      *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Money-amount parser work area.                                *
      *----------------------------------------------------------------*
       01  WS-AMT-EDIT.
           05  WS-AE-IN             PIC X(13) VALUE SPACES.
           05  WS-AE-POS            PIC 9(02) VALUE ZEROS.
           05  WS-AE-CHAR           PIC X(01) VALUE SPACES.
           05  WS-AE-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-AE-INT            PIC 9(10) VALUE ZEROS.
           05  WS-AE-INT-CNT        PIC 9(02) VALUE ZEROS.
           05  WS-AE-FRAC           PIC 9(02) VALUE ZEROS.
           05  WS-AE-FRAC-CNT       PIC 9(01) VALUE ZEROS.
           05  WS-AE-DOT-SW         PIC X(01) VALUE 'N'.
           05  WS-AE-RESULT         PIC S9(10)V99 VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter card and amount range, press ENTER.'.
           05  WS-M-CARD-REQ        PIC X(50)
               VALUE 'Card number is required.'.
           05  WS-M-FROM-BAD        PIC X(50)
               VALUE 'From amount is not a valid number.'.
           05  WS-M-TO-BAD          PIC X(50)
               VALUE 'To amount is not a valid number.'.
           05  WS-M-RANGE           PIC X(50)
               VALUE 'From amount cannot exceed to amount.'.
           05  WS-M-NONE-FOUND      PIC X(50)
               VALUE 'No transactions in that range.'.
           05  WS-M-BROWSE-ERR      PIC X(50)
               VALUE 'Error browsing the transaction file.'.
           05  WS-M-SUFFIX          PIC X(30)
               VALUE ' match(es) displayed.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  File record layout and BMS symbolic map.                      *
      *----------------------------------------------------------------*
       COPY RTRAN.
       COPY MTSRCH.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh empty screen.*
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MTSRCHAO.
           PERFORM 8000-POPULATE-HEADER.
           PERFORM 3050-CLEAR-ROWS.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO CARDNUML.
           EXEC CICS SEND
                     MAP('MTSRCHA')
                     MAPSET('MTSRCH')
                     FROM(MTSRCHAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-SEARCH
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-SEARCH  -  receive the criteria, validate them and drive *
      *  the browse.                                                  *
      *----------------------------------------------------------------*
       2100-SEARCH.
           EXEC CICS RECEIVE
                     MAP('MTSRCHA')
                     MAPSET('MTSRCH')
                     INTO(MTSRCHAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MTSRCHAI
           END-IF.
           PERFORM 6100-VALIDATE-CRIT.
           IF WS-INVALID
               MOVE -1 TO CARDNUML
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 3000-BROWSE-TRANS
               PERFORM 2200-BUILD-SUMMARY
               MOVE -1 TO CARDNUML
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  2200-BUILD-SUMMARY  -  compose the result-count message.      *
      *----------------------------------------------------------------*
       2200-BUILD-SUMMARY.
           IF WS-ROW-CNT = ZEROS
               MOVE WS-M-NONE-FOUND TO ERRMSGO
           ELSE
               MOVE WS-ROW-CNT TO WS-CNT-ED
               MOVE SPACES TO ERRMSGO
               STRING WS-CNT-ED   DELIMITED BY SIZE
                      WS-M-SUFFIX DELIMITED BY SIZE
                      INTO ERRMSGO
               END-STRING
           END-IF.
      *----------------------------------------------------------------*
      *  3000-BROWSE-TRANS  -  browse the transaction file forward and *
      *  collect the matching rows.                                   *
      *----------------------------------------------------------------*
       3000-BROWSE-TRANS.
           MOVE ZEROS TO WS-ROW-CNT.
           MOVE 'N'   TO WS-END-FLG.
           SET WS-BR-OFF TO TRUE.
           PERFORM 3050-CLEAR-ROWS.
           PERFORM 3100-START-BROWSE.
           IF WS-BR-ON
               PERFORM 3200-READ-NEXT
                   UNTIL END-OF-FILE
                      OR WS-ROW-CNT >= WS-MAX-ROWS
               PERFORM 3300-END-BROWSE
           END-IF.
      *----------------------------------------------------------------*
      *  3050-CLEAR-ROWS  -  blank the five result lines.             *
      *----------------------------------------------------------------*
       3050-CLEAR-ROWS.
           MOVE SPACES TO SR1O SR2O SR3O SR4O SR5O.
      *----------------------------------------------------------------*
      *  3100-START-BROWSE  -  position the browse at the first record.*
      *----------------------------------------------------------------*
       3100-START-BROWSE.
           MOVE LOW-VALUES TO TR-ID.
           EXEC CICS STARTBR
                     FILE(WS-TRANFILE)
                     RIDFLD(TR-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-BR-ON TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET WS-BR-OFF TO TRUE
                   SET END-OF-FILE TO TRUE
               WHEN OTHER
                   SET WS-BR-OFF TO TRUE
                   SET END-OF-FILE TO TRUE
                   MOVE WS-M-BROWSE-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-READ-NEXT  -  read the next record and, if the card and  *
      *  amount match, format it into the next result line.           *
      *----------------------------------------------------------------*
       3200-READ-NEXT.
           EXEC CICS READNEXT
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   IF TR-CARD-NUM = WS-CARD-KEY
                      AND TR-AMT >= WS-FROM-AMT
                      AND TR-AMT <= WS-TO-AMT
                       ADD 1 TO WS-ROW-CNT
                       PERFORM 4000-MOVE-ROW
                   END-IF
               WHEN DFHRESP(ENDFILE)
                   SET END-OF-FILE TO TRUE
               WHEN OTHER
                   SET END-OF-FILE TO TRUE
                   MOVE WS-M-BROWSE-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3300-END-BROWSE  -  release the browse position.             *
      *----------------------------------------------------------------*
       3300-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-TRANFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  4000-MOVE-ROW  -  format the current transaction into a       *
      *  result line: id, type, amount and merchant name.             *
      *----------------------------------------------------------------*
       4000-MOVE-ROW.
           MOVE TR-AMT TO WS-ED-AMT.
           MOVE WS-ED-AMT(2:15) TO WS-AMT-DISP.
           MOVE SPACES TO WS-SR-LINE.
           STRING TR-ID            DELIMITED BY SIZE
                  ' '              DELIMITED BY SIZE
                  TR-TYPE-CD       DELIMITED BY SIZE
                  ' '              DELIMITED BY SIZE
                  WS-AMT-DISP      DELIMITED BY SIZE
                  ' '              DELIMITED BY SIZE
                  TR-MERCHANT-NAME DELIMITED BY SIZE
                  INTO WS-SR-LINE
           END-STRING.
           EVALUATE WS-ROW-CNT
               WHEN 1
                   MOVE WS-SR-LINE TO SR1O
               WHEN 2
                   MOVE WS-SR-LINE TO SR2O
               WHEN 3
                   MOVE WS-SR-LINE TO SR3O
               WHEN 4
                   MOVE WS-SR-LINE TO SR4O
               WHEN 5
                   MOVE WS-SR-LINE TO SR5O
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6100-VALIDATE-CRIT  -  card required; parse the amount range. *
      *  A blank low amount is zero, a blank high amount is the        *
      *  largest representable value.                                 *
      *----------------------------------------------------------------*
       6100-VALIDATE-CRIT.
           SET WS-VALID TO TRUE.
           MOVE SPACES TO ERRMSGO.
           IF CARDNUMI = SPACES OR CARDNUMI = LOW-VALUES
               SET WS-INVALID TO TRUE
               MOVE WS-M-CARD-REQ TO ERRMSGO
               GO TO 6100-EXIT
           END-IF.
           MOVE CARDNUMI TO WS-CARD-KEY.
           INSPECT WS-CARD-KEY REPLACING ALL LOW-VALUE BY SPACE.
           MOVE FRAMTI TO WS-AE-IN.
           INSPECT WS-AE-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-AE-IN = SPACES
               MOVE ZEROS TO WS-FROM-AMT
           ELSE
               PERFORM 5100-PARSE-AMOUNT
               IF WS-INVALID
                   MOVE WS-M-FROM-BAD TO ERRMSGO
                   GO TO 6100-EXIT
               END-IF
               MOVE WS-AE-RESULT TO WS-FROM-AMT
           END-IF.
           MOVE TOAMTI TO WS-AE-IN.
           INSPECT WS-AE-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-AE-IN = SPACES
               MOVE 9999999999.99 TO WS-TO-AMT
           ELSE
               PERFORM 5100-PARSE-AMOUNT
               IF WS-INVALID
                   MOVE WS-M-TO-BAD TO ERRMSGO
                   GO TO 6100-EXIT
               END-IF
               MOVE WS-AE-RESULT TO WS-TO-AMT
           END-IF.
           IF WS-FROM-AMT > WS-TO-AMT
               SET WS-INVALID TO TRUE
               MOVE WS-M-RANGE TO ERRMSGO
           END-IF.
       6100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5100-PARSE-AMOUNT  -  parse WS-AE-IN into WS-AE-RESULT.       *
      *  Accepts digits, ignores commas and spaces, allows one dot     *
      *  with at most two fraction digits.                            *
      *----------------------------------------------------------------*
       5100-PARSE-AMOUNT.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-AE-INT WS-AE-INT-CNT.
           MOVE ZEROS TO WS-AE-FRAC WS-AE-FRAC-CNT.
           MOVE 'N' TO WS-AE-DOT-SW.
           MOVE ZEROS TO WS-AE-RESULT.
           INSPECT WS-AE-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-AE-IN = SPACES
               SET WS-INVALID TO TRUE
               GO TO 5100-EXIT
           END-IF.
           PERFORM VARYING WS-AE-POS FROM 1 BY 1
                   UNTIL WS-AE-POS > 13
               MOVE WS-AE-IN(WS-AE-POS:1) TO WS-AE-CHAR
               EVALUATE TRUE
                   WHEN WS-AE-CHAR = SPACE
                       CONTINUE
                   WHEN WS-AE-CHAR = ','
                       CONTINUE
                   WHEN WS-AE-CHAR = '.'
                       IF WS-AE-DOT-SW = 'Y'
                           SET WS-INVALID TO TRUE
                       ELSE
                           MOVE 'Y' TO WS-AE-DOT-SW
                       END-IF
                   WHEN WS-AE-CHAR >= '0' AND WS-AE-CHAR <= '9'
                       PERFORM 5150-ACCUM-DIGIT
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-AE-FRAC-CNT = 1
               COMPUTE WS-AE-FRAC = WS-AE-FRAC * 10
           END-IF.
           COMPUTE WS-AE-RESULT = WS-AE-INT + (WS-AE-FRAC / 100).
       5100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5150-ACCUM-DIGIT  -  fold one digit into the integer or       *
      *  fraction accumulator depending on the decimal-point switch.   *
      *----------------------------------------------------------------*
       5150-ACCUM-DIGIT.
           MOVE WS-AE-CHAR TO WS-AE-DIGIT.
           IF WS-AE-DOT-SW = 'Y'
               ADD 1 TO WS-AE-FRAC-CNT
               IF WS-AE-FRAC-CNT > 2
                   SET WS-INVALID TO TRUE
               ELSE
                   COMPUTE WS-AE-FRAC = WS-AE-FRAC * 10 + WS-AE-DIGIT
               END-IF
           ELSE
               ADD 1 TO WS-AE-INT-CNT
               IF WS-AE-INT-CNT > 10
                   SET WS-INVALID TO TRUE
               ELSE
                   COMPUTE WS-AE-INT = WS-AE-INT * 10 + WS-AE-DIGIT
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.*
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  re-transmit the map data only.         *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MTSRCHA')
                     MAPSET('MTSRCH')
                     FROM(MTSRCHAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to CICS.         *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
