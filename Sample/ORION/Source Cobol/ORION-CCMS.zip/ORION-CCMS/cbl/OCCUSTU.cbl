      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCCUSTU  -  Customer Update (on-line)             *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: maintain a customer master record.  The operator  *
      *            keys a customer id; the current values are loaded  *
      *            for editing; a second ENTER validates the changes  *
      *            and rewrites the CUSTFILE record.                  *
      *            PF3 = back to menu, PF4 = clear, ENTER = load/save.*
      *  MAPSET  : MCUSTU      MAP : MCUSTUA     TRANID : ORUU        *
      *  FILES   : CUSTFILE (read for update / rewrite by CU-ID)     *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.       *
      *****************************************************************
      *  MAINTENANCE LOG                                              *
      *  ----  ----------  --------------------------------------     *
      *  0001  2026-08-07  Original - customer maintenance screen.    *
      *****************************************************************
      *  PROCESSING NARRATIVE                                         *
      *  The update is a two-step conversation controlled by a load   *
      *  flag carried in the COMMAREA scratch area:                   *
      *    STEP 1 (load) : key a customer id and press ENTER.  The    *
      *            record is read and its editable fields are shown.  *
      *    STEP 2 (save) : change any of the name / address / city /  *
      *            phone fields and press ENTER.  The fields are      *
      *            edited, the record is re-read for update and       *
      *            rewritten.                                         *
      *  Keying a different id at any time restarts at STEP 1.        *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCCUSTU.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identification and navigation constants               *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCCUSTU'.
           05  WS-TRANID            PIC X(04) VALUE 'ORUU'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Conversation state flag - kept in CA-WORK-AREA position 1
      *----------------------------------------------------------------*
       01  WS-STATE-FLAG            PIC X(01) VALUE 'N'.
               88  WS-CUST-LOADED             VALUE 'L'.
               88  WS-CUST-NOT-LOADED         VALUE 'N'.
      *----------------------------------------------------------------*
      *  Work and formatting fields local to this program              *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-IN-CUST-ID        PIC 9(09) VALUE ZEROS.
           05  WS-EDIT-FLAG         PIC X(01) VALUE 'N'.
               88  WS-EDIT-GOOD               VALUE 'Y'.
               88  WS-EDIT-BAD                VALUE 'N'.
      *----------------------------------------------------------------*
      *  Generic numeric-string edit work area                         *
      *----------------------------------------------------------------*
       01  WS-VALIDATION.
           05  WS-VAL-STR           PIC X(20) VALUE SPACES.
           05  WS-VAL-LEN           PIC 9(02) VALUE ZEROS.
           05  WS-VAL-I             PIC 9(02) VALUE ZEROS.
           05  WS-VAL-CH            PIC X(01) VALUE SPACE.
           05  WS-VAL-DIGITS        PIC 9(02) VALUE ZEROS.
           05  WS-VAL-OK            PIC X(01) VALUE 'Y'.
               88  WS-VAL-GOOD                VALUE 'Y'.
               88  WS-VAL-BAD                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Program specific operator messages                            *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(60)
               VALUE 'Enter a customer id and press ENTER to load.'.
           05  WS-M-LOADED          PIC X(60)
               VALUE 'Record loaded - change fields and ENTER to save.'.
           05  WS-M-UPDATED         PIC X(60)
               VALUE 'Customer updated successfully.'.
           05  WS-M-CUST-NOTFND     PIC X(60)
               VALUE 'Customer not found - check the id and retry.'.
           05  WS-M-ID-REQUIRED     PIC X(60)
               VALUE 'Customer id is required.'.
           05  WS-M-ID-NOTNUM       PIC X(60)
               VALUE 'Customer id must be numeric.'.
           05  WS-M-FNAME-REQ       PIC X(60)
               VALUE 'First name is required.'.
           05  WS-M-LNAME-REQ       PIC X(60)
               VALUE 'Last name is required.'.
           05  WS-M-ADDR-REQ        PIC X(60)
               VALUE 'Address line 1 is required.'.
           05  WS-M-CITY-REQ        PIC X(60)
               VALUE 'City is required.'.
           05  WS-M-PHONE-REQ       PIC X(60)
               VALUE 'Primary phone is required.'.
           05  WS-M-READ-ERROR      PIC X(60)
               VALUE 'Error reading the customer file.'.
           05  WS-M-UPD-ERROR       PIC X(60)
               VALUE 'Error rewriting the customer record.'.
           05  WS-M-DELETED         PIC X(60)
               VALUE 'Record no longer on file - reload the id.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea      *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  File record layout and BMS symbolic map                       *
      *----------------------------------------------------------------*
       COPY RCUST.
       COPY MCUSTU.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants             *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               MOVE CA-WORK-AREA(1:1) TO WS-STATE-FLAG
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh empty screen.
      *  Resets the conversation load flag so a new id will be loaded.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MCUSTUAO.
           SET WS-CUST-NOT-LOADED TO TRUE.
           MOVE WS-STATE-FLAG TO CA-WORK-AREA(1:1).
           MOVE ZEROS TO CA-CUST-ID.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO CUSTIDL.
           EXEC CICS SEND
                     MAP('MCUSTUA')
                     MAPSET('MCUSTU')
                     FROM(MCUSTUAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-PROCESS-ENTER
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-PROCESS-ENTER  -  receive the map and route to either
      *  the load step or the save step depending on the load flag and
      *  whether the keyed id matches the record already loaded.
      *----------------------------------------------------------------*
       2100-PROCESS-ENTER.
           EXEC CICS RECEIVE
                     MAP('MCUSTUA')
                     MAPSET('MCUSTU')
                     INTO(MCUSTUAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           PERFORM 2200-EDIT-CUST-ID.
           IF ERR-FLG-ON
               MOVE -1 TO CUSTIDL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               IF WS-CUST-NOT-LOADED
                  OR WS-IN-CUST-ID NOT = CA-CUST-ID
                   PERFORM 2300-LOAD-CUST
               ELSE
                   PERFORM 2400-APPLY-UPDATE
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2200-EDIT-CUST-ID  -  validate the customer id map field.
      *----------------------------------------------------------------*
       2200-EDIT-CUST-ID.
           SET ERR-FLG-OFF TO TRUE.
           MOVE ZEROS TO WS-IN-CUST-ID.
           IF CUSTIDI = SPACES OR CUSTIDI = LOW-VALUES
               SET ERR-FLG-ON TO TRUE
               MOVE WS-M-ID-REQUIRED TO ERRMSGO
           ELSE
               MOVE SPACES  TO WS-VAL-STR
               MOVE CUSTIDI TO WS-VAL-STR
               MOVE 9       TO WS-VAL-LEN
               PERFORM 7600-VALIDATE-NUM
               IF WS-VAL-GOOD
                   COMPUTE WS-IN-CUST-ID =
                       FUNCTION NUMVAL(WS-VAL-STR(1:WS-VAL-LEN))
               ELSE
                   SET ERR-FLG-ON TO TRUE
                   MOVE WS-M-ID-NOTNUM TO ERRMSGO
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2300-LOAD-CUST  -  STEP 1.  Read the requested customer and
      *  present its editable values.  On success the load flag is set
      *  and the id is remembered for the following save step.
      *----------------------------------------------------------------*
       2300-LOAD-CUST.
           MOVE WS-IN-CUST-ID TO CU-ID.
           PERFORM 3000-READ-CUST.
           EVALUATE TRUE
               WHEN REC-FOUND
                   PERFORM 4000-POPULATE-DETAIL
                   SET WS-CUST-LOADED TO TRUE
                   MOVE WS-STATE-FLAG   TO CA-WORK-AREA(1:1)
                   MOVE WS-IN-CUST-ID   TO CA-CUST-ID
                   MOVE WS-M-LOADED     TO ERRMSGO
                   MOVE -1              TO CUFNAML
                   PERFORM 8100-SEND-DATAONLY
               WHEN OTHER
                   SET WS-CUST-NOT-LOADED TO TRUE
                   MOVE WS-STATE-FLAG   TO CA-WORK-AREA(1:1)
                   MOVE WS-M-CUST-NOTFND TO ERRMSGO
                   MOVE -1              TO CUSTIDL
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2400-APPLY-UPDATE  -  STEP 2.  Edit the changed fields, then
      *  re-read the record for update and rewrite it.
      *----------------------------------------------------------------*
       2400-APPLY-UPDATE.
           PERFORM 5000-EDIT-FIELDS.
           IF WS-EDIT-BAD
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE CA-CUST-ID TO CU-ID
               PERFORM 6000-READ-FOR-UPDATE
               EVALUATE TRUE
                   WHEN REC-FOUND
                       PERFORM 6100-MOVE-CHANGES
                       PERFORM 6200-REWRITE-CUST
                   WHEN OTHER
                       SET WS-CUST-NOT-LOADED TO TRUE
                       MOVE WS-STATE-FLAG TO CA-WORK-AREA(1:1)
                       MOVE WS-M-DELETED  TO ERRMSGO
                       MOVE -1            TO CUSTIDL
                       PERFORM 8100-SEND-DATAONLY
               END-EVALUATE
           END-IF.
      *----------------------------------------------------------------*
      *  3000-READ-CUST  -  read CUSTFILE by primary key (no update).  *
      *----------------------------------------------------------------*
       3000-READ-CUST.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-CUSTFILE)
                     INTO(CUST-REC)
                     RIDFLD(CU-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   MOVE WS-M-READ-ERROR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-POPULATE-DETAIL  -  move current record values into the
      *  editable map fields so the operator can amend them.           *
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE CU-ID           TO CUSTIDO.
           MOVE CU-FIRST-NAME   TO CUFNAMO.
           MOVE CU-LAST-NAME    TO CULNAMO.
           MOVE CU-ADDR-LINE-1  TO CUADDRO.
           MOVE CU-ADDR-CITY    TO CUCITYO.
           MOVE CU-PHONE-1      TO CUPHONEO.
      *----------------------------------------------------------------*
      *  5000-EDIT-FIELDS  -  validate the editable input fields.
      *  Each of name, last name, address, city and phone must be
      *  present.  The first field in error receives the cursor and
      *  its message; validation stops at the first failure.
      *----------------------------------------------------------------*
       5000-EDIT-FIELDS.
           SET WS-EDIT-GOOD TO TRUE.
           IF CUFNAMI = SPACES OR CUFNAMI = LOW-VALUES
               SET WS-EDIT-BAD TO TRUE
               MOVE WS-M-FNAME-REQ TO ERRMSGO
               MOVE -1 TO CUFNAML
           END-IF.
           IF WS-EDIT-GOOD
               IF CULNAMI = SPACES OR CULNAMI = LOW-VALUES
                   SET WS-EDIT-BAD TO TRUE
                   MOVE WS-M-LNAME-REQ TO ERRMSGO
                   MOVE -1 TO CULNAML
               END-IF
           END-IF.
           IF WS-EDIT-GOOD
               IF CUADDRI = SPACES OR CUADDRI = LOW-VALUES
                   SET WS-EDIT-BAD TO TRUE
                   MOVE WS-M-ADDR-REQ TO ERRMSGO
                   MOVE -1 TO CUADDRL
               END-IF
           END-IF.
           IF WS-EDIT-GOOD
               IF CUCITYI = SPACES OR CUCITYI = LOW-VALUES
                   SET WS-EDIT-BAD TO TRUE
                   MOVE WS-M-CITY-REQ TO ERRMSGO
                   MOVE -1 TO CUCITYL
               END-IF
           END-IF.
           IF WS-EDIT-GOOD
               IF CUPHONEI = SPACES OR CUPHONEI = LOW-VALUES
                   SET WS-EDIT-BAD TO TRUE
                   MOVE WS-M-PHONE-REQ TO ERRMSGO
                   MOVE -1 TO CUPHONEL
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  6000-READ-FOR-UPDATE  -  re-read CUSTFILE with UPDATE intent
      *  so the record can be rewritten while holding exclusive
      *  control for the remainder of the task.                        *
      *----------------------------------------------------------------*
       6000-READ-FOR-UPDATE.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-CUSTFILE)
                     INTO(CUST-REC)
                     RIDFLD(CU-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   MOVE WS-M-READ-ERROR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6100-MOVE-CHANGES  -  overlay the record with the edited
      *  input values.  Only the maintainable attributes are changed;
      *  all other fields keep their read-for-update values.           *
      *----------------------------------------------------------------*
       6100-MOVE-CHANGES.
           MOVE CUFNAMI  TO CU-FIRST-NAME.
           MOVE CULNAMI  TO CU-LAST-NAME.
           MOVE CUADDRI  TO CU-ADDR-LINE-1.
           MOVE CUCITYI  TO CU-ADDR-CITY.
           MOVE CUPHONEI TO CU-PHONE-1.
      *----------------------------------------------------------------*
      *  6200-REWRITE-CUST  -  commit the change with a VSAM REWRITE.
      *  On success the amended values are re-displayed and the load
      *  flag stays set so further edits are possible.                 *
      *----------------------------------------------------------------*
       6200-REWRITE-CUST.
           EXEC CICS REWRITE
                     FILE(WS-CUSTFILE)
                     FROM(CUST-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   PERFORM 4000-POPULATE-DETAIL
                   SET WS-CUST-LOADED TO TRUE
                   MOVE WS-STATE-FLAG TO CA-WORK-AREA(1:1)
                   MOVE WS-M-UPDATED  TO ERRMSGO
                   MOVE -1            TO CUFNAML
                   PERFORM 8100-SEND-DATAONLY
               WHEN OTHER
                   MOVE WS-M-UPD-ERROR TO ERRMSGO
                   MOVE -1             TO CUFNAML
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  7600-VALIDATE-NUM  -  generic numeric string editor.          *
      *----------------------------------------------------------------*
       7600-VALIDATE-NUM.
           SET WS-VAL-GOOD TO TRUE.
           MOVE ZEROS TO WS-VAL-DIGITS.
           INSPECT WS-VAL-STR(1:WS-VAL-LEN)
               REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-VAL-I FROM 1 BY 1
                   UNTIL WS-VAL-I > WS-VAL-LEN
               MOVE WS-VAL-STR(WS-VAL-I:1) TO WS-VAL-CH
               IF WS-VAL-CH = SPACE
                   CONTINUE
               ELSE
                   IF WS-VAL-CH >= '0' AND WS-VAL-CH <= '9'
                       ADD 1 TO WS-VAL-DIGITS
                   ELSE
                       SET WS-VAL-BAD TO TRUE
                   END-IF
               END-IF
           END-PERFORM.
           IF WS-VAL-DIGITS = ZEROS
               SET WS-VAL-BAD TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  re-transmit the map data only, placing
      *  the cursor at the field whose length was set to -1.           *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MCUSTUA')
                     MAPSET('MCUSTU')
                     FROM(MCUSTUAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to CICS.         *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
