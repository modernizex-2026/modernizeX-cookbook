      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCANLIN  -  Analytics Inquiry (on-line)          *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: on-line analytics dashboard.  The operator types *
      *            a MODE and presses ENTER; the program LINKs the  *
      *            compute subroutine OUANLIN which scans TRANFILE   *
      *            (and XREF / ACCT as required) and returns one     *
      *            page of computed rows and two grand totals.      *
      *            Modes: RW rewards points per card, FR fraud      *
      *            exceptions (large amount / velocity), GL totals  *
      *            by type as debit/credit, RC per-account movement *
      *            versus balance.  PF8 pages, PF7 restarts, PF3    *
      *            returns to the report menu, PF4 clears.          *
      *  MAPSET  : MANLIN      MAP : MANLINA     TRANID : ORAN       *
      *  REPLACES: batch reports OBRWD / OBRWDRPT, OBRFRD, OBGLEX   *
      *            and OBRECON with a single on-line inquiry.       *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - four-mode analytics inquiry.   *
      *****************************************************************
      *  PROCESSING NARRATIVE                                        *
      *  1. ENTER normalises the typed mode keyword to a two-letter  *
      *     code and requests the first page (offset zero).          *
      *  2. OUANLIN returns the page rows, the row and result counts *
      *     and the two mode-specific totals used to build the two   *
      *     total lines and the descriptive column subtitle.         *
      *  3. PF8 advances the row offset by one page; PF7 rewinds to  *
      *     the first page of the same mode.                         *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCANLIN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCANLIN'.
           05  WS-TRANID            PIC X(04) VALUE 'ORAN'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCRPTMN'.
           05  WS-SUB-PGM           PIC X(08) VALUE 'OUANLIN'.
           05  WS-PAGE-SIZE         PIC 9(02) VALUE 6.
      *----------------------------------------------------------------*
      *  Paging state, mirrored in the COMMAREA work area so it        *
      *  survives the pseudo-conversation.                             *
      *----------------------------------------------------------------*
       01  WS-ANL-STATE.
           05  WS-AS-MODE           PIC X(02) VALUE SPACES.
           05  WS-AS-OFFSET         PIC 9(04) VALUE ZEROS.
           05  WS-AS-RESCNT         PIC 9(04) VALUE ZEROS.
           05  WS-AS-MORE           PIC X(01) VALUE 'N'.
      *----------------------------------------------------------------*
      *  Mode normalisation work fields.                               *
      *----------------------------------------------------------------*
       01  WS-MODE-WORK.
           05  WS-MODE-IN           PIC X(07) VALUE SPACES.
           05  WS-MODE-UP           PIC X(07) VALUE SPACES.
           05  WS-MODE-CODE         PIC X(02) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Per-row display work fields.                                  *
      *----------------------------------------------------------------*
       01  WS-ROW-WORK.
           05  WS-F-KEY             PIC X(16).
           05  WS-F-INFO            PIC X(10).
           05  WS-F-CNT             PIC X(09).
           05  WS-F-AMT             PIC X(14).
           05  WS-F-VAL             PIC X(14).
      *----------------------------------------------------------------*
      *  Numeric edit patterns for rows and totals.                    *
      *----------------------------------------------------------------*
       01  WS-EDITS.
           05  WS-ED-CNT            PIC Z,ZZZ,ZZ9.
           05  WS-ED-MONEY          PIC ---,---,--9.99.
           05  WS-ED-PTS            PIC ZZ,ZZZ,ZZZ,ZZ9.
           05  WS-ED-TOTAL          PIC ---,---,---,---,--9.99.
           05  WS-ED-TOTAL2         PIC ---,---,---,---,--9.99.
           05  WS-ED-BIG            PIC ZZZ,ZZZ,ZZZ,ZZ9.
           05  WS-ED-NUM            PIC ZZZ,ZZZ,ZZ9.
           05  WS-ED-NUM4           PIC ZZZ9.
           05  WS-CNT-ED            PIC Z9.
      *----------------------------------------------------------------*
      *  Page-of-pages feedback derived from the result count.         *
      *----------------------------------------------------------------*
       01  WS-PAGE-CALC.
           05  WS-PAGE-NO           PIC 9(04) VALUE ZEROS.
           05  WS-PAGE-TOT          PIC 9(04) VALUE ZEROS.
           05  WS-ED-PG             PIC ZZZ9.
           05  WS-ED-PGT            PIC ZZZ9.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter mode RW/FR/GL/RC and press ENTER.'.
           05  WS-M-BAD-MODE        PIC X(50)
               VALUE 'Mode must be RW, FR, GL or RC.'.
           05  WS-M-NONE-FOUND      PIC X(50)
               VALUE 'No analytics rows for that mode.'.
           05  WS-M-COMP-ERR        PIC X(50)
               VALUE 'Error computing analytics.'.
           05  WS-M-END-ROWS        PIC X(50)
               VALUE 'End of results - no more rows.'.
           05  WS-M-SUFFIX          PIC X(30)
               VALUE ' row(s) shown.'.
      *----------------------------------------------------------------*
      *  Column subtitles shown per mode.                              *
      *----------------------------------------------------------------*
       01  WS-HEADINGS.
           05  WS-H-RW              PIC X(60) VALUE
               'REWARDS: card / purchases / purchase amt / points'.
           05  WS-H-FR              PIC X(60) VALUE
               'FRAUD: card / reason / trans / total amt / max amt'.
           05  WS-H-GL              PIC X(60) VALUE
               'GL: type / dr-cr / count / amount'.
           05  WS-H-RC              PIC X(60) VALUE
               'RECON: account / note / trans / movement / balance'.
      *----------------------------------------------------------------*
      *  Shared copybooks and the compute subroutine parameter block.  *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY KANLB.
      *----------------------------------------------------------------*
      *  BMS symbolic map and IBM-supplied constants.                  *
      *----------------------------------------------------------------*
       COPY MANLIN.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               MOVE CA-WORK-AREA(1:11) TO WS-ANL-STATE
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh empty screen.*
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MANLINAO.
           PERFORM 8000-POPULATE-HEADER.
           PERFORM 3050-CLEAR-ROWS.
           MOVE SPACES TO ANHEADO.
           MOVE SPACES TO ANTOT1O.
           MOVE SPACES TO ANTOT2O.
           INITIALIZE WS-ANL-STATE.
           MOVE 'N' TO WS-AS-MORE.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO ANMODEL.
           EXEC CICS SEND
                     MAP('MANLINA')
                     MAPSET('MANLIN')
                     FROM(MANLINAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHPF7
                   PERFORM 2300-RESTART
               WHEN DFHPF8
                   PERFORM 2200-PAGE-FWD
               WHEN DFHENTER
                   PERFORM 2100-RUN
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-RUN  -  ENTER pressed.  Receive and normalise the mode   *
      *  then compute the first page.                                  *
      *----------------------------------------------------------------*
       2100-RUN.
           EXEC CICS RECEIVE
                     MAP('MANLINA')
                     MAPSET('MANLIN')
                     INTO(MANLINAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MANLINAI
           END-IF.
           MOVE ANMODEI TO WS-MODE-IN.
           INSPECT WS-MODE-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM 5000-NORMALIZE-MODE.
           IF WS-MODE-CODE = SPACES
               MOVE WS-M-BAD-MODE TO ERRMSGO
               MOVE -1 TO ANMODEL
               PERFORM 8100-SEND-DATAONLY
               GO TO 2100-EXIT
           END-IF.
           MOVE WS-MODE-CODE TO WS-AS-MODE.
           MOVE ZEROS        TO WS-AS-OFFSET.
           PERFORM 3000-DO-ANALYTICS.
           PERFORM 2400-BUILD-SUMMARY.
           MOVE -1 TO ANMODEL.
           PERFORM 8100-SEND-DATAONLY.
       2100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2200-PAGE-FWD  -  PF8 pressed.  Advance one page if more.     *
      *----------------------------------------------------------------*
       2200-PAGE-FWD.
           IF WS-AS-MODE = SPACES
               PERFORM 1000-SEND-INITIAL
               GO TO 2200-EXIT
           END-IF.
           IF WS-AS-MORE = 'Y'
               ADD WS-PAGE-SIZE TO WS-AS-OFFSET
               PERFORM 3000-DO-ANALYTICS
               PERFORM 2400-BUILD-SUMMARY
           ELSE
               MOVE WS-M-END-ROWS TO ERRMSGO
           END-IF.
           MOVE -1 TO ANMODEL.
           PERFORM 8100-SEND-DATAONLY.
       2200-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2300-RESTART  -  PF7 pressed.  Rewind to the first page.      *
      *----------------------------------------------------------------*
       2300-RESTART.
           IF WS-AS-MODE = SPACES
               PERFORM 1000-SEND-INITIAL
               GO TO 2300-EXIT
           END-IF.
           MOVE ZEROS TO WS-AS-OFFSET.
           PERFORM 3000-DO-ANALYTICS.
           PERFORM 2400-BUILD-SUMMARY.
           MOVE -1 TO ANMODEL.
           PERFORM 8100-SEND-DATAONLY.
       2300-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2400-BUILD-SUMMARY  -  compose the result-count message.      *
      *----------------------------------------------------------------*
       2400-BUILD-SUMMARY.
           EVALUATE TRUE
               WHEN KAB-STATUS = '99'
                   MOVE WS-M-COMP-ERR TO ERRMSGO
               WHEN KAB-ROW-CNT = ZEROS
                   MOVE WS-M-NONE-FOUND TO ERRMSGO
               WHEN OTHER
                   PERFORM 2450-PAGE-CALC
                   MOVE KAB-ROW-CNT  TO WS-CNT-ED
                   MOVE WS-PAGE-NO   TO WS-ED-PG
                   MOVE WS-PAGE-TOT  TO WS-ED-PGT
                   MOVE SPACES TO ERRMSGO
                   STRING WS-CNT-ED DELIMITED BY SIZE
                          ' row(s)  page ' DELIMITED BY SIZE
                          WS-ED-PG  DELIMITED BY SIZE
                          ' of ' DELIMITED BY SIZE
                          WS-ED-PGT DELIMITED BY SIZE
                          INTO ERRMSGO
                   END-STRING
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2450-PAGE-CALC  -  derive the current page number and the     *
      *  total number of pages from the row offset and result count.   *
      *----------------------------------------------------------------*
       2450-PAGE-CALC.
           COMPUTE WS-PAGE-NO =
               (WS-AS-OFFSET / WS-PAGE-SIZE) + 1.
           COMPUTE WS-PAGE-TOT =
               (WS-AS-RESCNT + WS-PAGE-SIZE - 1) / WS-PAGE-SIZE.
           IF WS-PAGE-TOT < WS-PAGE-NO
               MOVE WS-PAGE-NO TO WS-PAGE-TOT
           END-IF.
      *----------------------------------------------------------------*
      *  3000-DO-ANALYTICS  -  LINK the compute subroutine for one     *
      *  page and unload the rows, subtitle and totals.               *
      *----------------------------------------------------------------*
       3000-DO-ANALYTICS.
           PERFORM 3050-CLEAR-ROWS.
           MOVE WS-AS-MODE   TO KAB-MODE.
           MOVE WS-AS-OFFSET TO KAB-START-OFF.
           MOVE WS-PAGE-SIZE TO KAB-MAX-ROWS.
           EXEC CICS LINK
                     PROGRAM(WS-SUB-PGM)
                     COMMAREA(KANLB-PARM)
                     LENGTH(LENGTH OF KANLB-PARM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               MOVE '99'  TO KAB-STATUS
               MOVE ZEROS TO KAB-ROW-CNT
               MOVE 'N'   TO WS-AS-MORE
               GO TO 3000-EXIT
           END-IF.
           MOVE KAB-RESULT-CNT TO WS-AS-RESCNT.
           MOVE KAB-MORE       TO WS-AS-MORE.
           PERFORM 3100-SET-HEADER.
           IF KAB-ROW-CNT > ZEROS
               PERFORM 4000-MOVE-ROWS
               PERFORM 3200-BUILD-TOTALS
           ELSE
               MOVE SPACES TO ANTOT1O
               MOVE SPACES TO ANTOT2O
           END-IF.
       3000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3050-CLEAR-ROWS  -  blank the six display lines.              *
      *----------------------------------------------------------------*
       3050-CLEAR-ROWS.
           MOVE SPACES TO ANK1O ANI1O ANC1O ANA1O ANV1O.
           MOVE SPACES TO ANK2O ANI2O ANC2O ANA2O ANV2O.
           MOVE SPACES TO ANK3O ANI3O ANC3O ANA3O ANV3O.
           MOVE SPACES TO ANK4O ANI4O ANC4O ANA4O ANV4O.
           MOVE SPACES TO ANK5O ANI5O ANC5O ANA5O ANV5O.
           MOVE SPACES TO ANK6O ANI6O ANC6O ANA6O ANV6O.
      *----------------------------------------------------------------*
      *  3100-SET-HEADER  -  put the mode subtitle and echo the mode.  *
      *----------------------------------------------------------------*
       3100-SET-HEADER.
           MOVE WS-AS-MODE TO ANMODEO.
           EVALUATE WS-AS-MODE
               WHEN 'RW' MOVE WS-H-RW TO ANHEADO
               WHEN 'FR' MOVE WS-H-FR TO ANHEADO
               WHEN 'GL' MOVE WS-H-GL TO ANHEADO
               WHEN 'RC' MOVE WS-H-RC TO ANHEADO
               WHEN OTHER MOVE SPACES TO ANHEADO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-BUILD-TOTALS  -  build the two total lines per mode.     *
      *----------------------------------------------------------------*
       3200-BUILD-TOTALS.
           MOVE SPACES TO ANTOT1O.
           MOVE SPACES TO ANTOT2O.
           EVALUATE WS-AS-MODE
               WHEN 'RW' PERFORM 3210-TOT-RW
               WHEN 'FR' PERFORM 3220-TOT-FR
               WHEN 'GL' PERFORM 3230-TOT-GL
               WHEN 'RC' PERFORM 3240-TOT-RC
               WHEN OTHER CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3210-TOT-RW  -  rewards totals.                               *
      *----------------------------------------------------------------*
       3210-TOT-RW.
           MOVE KAB-TOT-1 TO WS-ED-TOTAL.
           STRING 'REWARDS - Purchase amount: ' DELIMITED BY SIZE
                  WS-ED-TOTAL DELIMITED BY SIZE
                  INTO ANTOT1O
           END-STRING.
           MOVE KAB-TOT-2      TO WS-ED-BIG.
           MOVE WS-AS-RESCNT   TO WS-ED-NUM4.
           MOVE KAB-SCANNED    TO WS-ED-NUM.
           STRING 'Points: '   DELIMITED BY SIZE
                  WS-ED-BIG     DELIMITED BY SIZE
                  '  Cards: '   DELIMITED BY SIZE
                  WS-ED-NUM4    DELIMITED BY SIZE
                  '  Scanned: ' DELIMITED BY SIZE
                  WS-ED-NUM     DELIMITED BY SIZE
                  INTO ANTOT2O
           END-STRING.
      *----------------------------------------------------------------*
      *  3220-TOT-FR  -  fraud totals.                                 *
      *----------------------------------------------------------------*
       3220-TOT-FR.
           MOVE KAB-TOT-1 TO WS-ED-TOTAL.
           STRING 'FRAUD - Flagged amount: ' DELIMITED BY SIZE
                  WS-ED-TOTAL DELIMITED BY SIZE
                  INTO ANTOT1O
           END-STRING.
           MOVE KAB-TOT-2   TO WS-ED-NUM.
           MOVE KAB-SCANNED TO WS-ED-BIG.
           STRING 'Flagged cards: ' DELIMITED BY SIZE
                  WS-ED-NUM         DELIMITED BY SIZE
                  '  Scanned: '     DELIMITED BY SIZE
                  WS-ED-BIG         DELIMITED BY SIZE
                  INTO ANTOT2O
           END-STRING.
      *----------------------------------------------------------------*
      *  3230-TOT-GL  -  general-ledger totals.                        *
      *----------------------------------------------------------------*
       3230-TOT-GL.
           MOVE KAB-TOT-1 TO WS-ED-TOTAL.
           MOVE KAB-TOT-2 TO WS-ED-TOTAL2.
           STRING 'GL - Debit: '  DELIMITED BY SIZE
                  WS-ED-TOTAL      DELIMITED BY SIZE
                  '   Credit: '    DELIMITED BY SIZE
                  WS-ED-TOTAL2     DELIMITED BY SIZE
                  INTO ANTOT1O
           END-STRING.
           MOVE WS-AS-RESCNT TO WS-ED-NUM4.
           MOVE KAB-SCANNED  TO WS-ED-NUM.
           STRING 'Types: '  DELIMITED BY SIZE
                  WS-ED-NUM4  DELIMITED BY SIZE
                  '   Transactions scanned: ' DELIMITED BY SIZE
                  WS-ED-NUM   DELIMITED BY SIZE
                  INTO ANTOT2O
           END-STRING.
      *----------------------------------------------------------------*
      *  3240-TOT-RC  -  reconciliation totals.                        *
      *----------------------------------------------------------------*
       3240-TOT-RC.
           MOVE KAB-TOT-1 TO WS-ED-TOTAL.
           MOVE KAB-TOT-2 TO WS-ED-TOTAL2.
           STRING 'RECON - Debit: ' DELIMITED BY SIZE
                  WS-ED-TOTAL        DELIMITED BY SIZE
                  '  Credit: '       DELIMITED BY SIZE
                  WS-ED-TOTAL2       DELIMITED BY SIZE
                  INTO ANTOT1O
           END-STRING.
           MOVE KAB-DISC       TO WS-ED-NUM4.
           MOVE WS-AS-RESCNT   TO WS-ED-CNT.
           MOVE KAB-SCANNED    TO WS-ED-NUM.
           STRING 'Discrepancies: ' DELIMITED BY SIZE
                  WS-ED-NUM4         DELIMITED BY SIZE
                  '  Accounts: '     DELIMITED BY SIZE
                  WS-ED-CNT          DELIMITED BY SIZE
                  '  Scanned: '      DELIMITED BY SIZE
                  WS-ED-NUM          DELIMITED BY SIZE
                  INTO ANTOT2O
           END-STRING.
      *----------------------------------------------------------------*
      *  4000-MOVE-ROWS  -  format and place every returned row.       *
      *----------------------------------------------------------------*
       4000-MOVE-ROWS.
           PERFORM VARYING WS-IDX FROM 1 BY 1
                   UNTIL WS-IDX > KAB-ROW-CNT
               PERFORM 4100-FORMAT-ROW
               PERFORM 4200-PLACE-ROW
           END-PERFORM.
      *----------------------------------------------------------------*
      *  4100-FORMAT-ROW  -  edit one row into the display work area.  *
      *  The value column is points for rewards and money otherwise.  *
      *----------------------------------------------------------------*
       4100-FORMAT-ROW.
           MOVE KAB-R-KEY  (WS-IDX) TO WS-F-KEY.
           MOVE KAB-R-INFO (WS-IDX) TO WS-F-INFO.
           MOVE KAB-R-CNT  (WS-IDX) TO WS-ED-CNT.
           MOVE WS-ED-CNT           TO WS-F-CNT.
           MOVE KAB-R-AMT  (WS-IDX) TO WS-ED-MONEY.
           MOVE WS-ED-MONEY         TO WS-F-AMT.
           IF WS-AS-MODE = 'RW'
               MOVE KAB-R-VAL (WS-IDX) TO WS-ED-PTS
               MOVE WS-ED-PTS          TO WS-F-VAL
           ELSE
               MOVE KAB-R-VAL (WS-IDX) TO WS-ED-MONEY
               MOVE WS-ED-MONEY        TO WS-F-VAL
           END-IF.
      *----------------------------------------------------------------*
      *  4200-PLACE-ROW  -  move the work area into the matching map   *
      *  line.                                                         *
      *----------------------------------------------------------------*
       4200-PLACE-ROW.
           EVALUATE WS-IDX
               WHEN 1
                   MOVE WS-F-KEY  TO ANK1O
                   MOVE WS-F-INFO TO ANI1O
                   MOVE WS-F-CNT  TO ANC1O
                   MOVE WS-F-AMT  TO ANA1O
                   MOVE WS-F-VAL  TO ANV1O
               WHEN 2
                   MOVE WS-F-KEY  TO ANK2O
                   MOVE WS-F-INFO TO ANI2O
                   MOVE WS-F-CNT  TO ANC2O
                   MOVE WS-F-AMT  TO ANA2O
                   MOVE WS-F-VAL  TO ANV2O
               WHEN 3
                   MOVE WS-F-KEY  TO ANK3O
                   MOVE WS-F-INFO TO ANI3O
                   MOVE WS-F-CNT  TO ANC3O
                   MOVE WS-F-AMT  TO ANA3O
                   MOVE WS-F-VAL  TO ANV3O
               WHEN 4
                   MOVE WS-F-KEY  TO ANK4O
                   MOVE WS-F-INFO TO ANI4O
                   MOVE WS-F-CNT  TO ANC4O
                   MOVE WS-F-AMT  TO ANA4O
                   MOVE WS-F-VAL  TO ANV4O
               WHEN 5
                   MOVE WS-F-KEY  TO ANK5O
                   MOVE WS-F-INFO TO ANI5O
                   MOVE WS-F-CNT  TO ANC5O
                   MOVE WS-F-AMT  TO ANA5O
                   MOVE WS-F-VAL  TO ANV5O
               WHEN 6
                   MOVE WS-F-KEY  TO ANK6O
                   MOVE WS-F-INFO TO ANI6O
                   MOVE WS-F-CNT  TO ANC6O
                   MOVE WS-F-AMT  TO ANA6O
                   MOVE WS-F-VAL  TO ANV6O
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  5000-NORMALIZE-MODE  -  map the typed keyword to a two-letter *
      *  code (blank code means the entry was not recognised).         *
      *----------------------------------------------------------------*
       5000-NORMALIZE-MODE.
           MOVE SPACES TO WS-MODE-CODE.
           MOVE FUNCTION UPPER-CASE (WS-MODE-IN) TO WS-MODE-UP.
           EVALUATE WS-MODE-UP
               WHEN 'RW'      MOVE 'RW' TO WS-MODE-CODE
               WHEN 'REWARDS' MOVE 'RW' TO WS-MODE-CODE
               WHEN 'FR'      MOVE 'FR' TO WS-MODE-CODE
               WHEN 'FRAUD'   MOVE 'FR' TO WS-MODE-CODE
               WHEN 'GL'      MOVE 'GL' TO WS-MODE-CODE
               WHEN 'RC'      MOVE 'RC' TO WS-MODE-CODE
               WHEN 'RECON'   MOVE 'RC' TO WS-MODE-CODE
               WHEN OTHER     MOVE SPACES TO WS-MODE-CODE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the reports menu.     *
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  re-transmit the map data only.         *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MANLINA')
                     MAPSET('MANLIN')
                     FROM(MANLINAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  persist paging state and return to CICS.      *
      *----------------------------------------------------------------*
       9000-RETURN.
           MOVE WS-ANL-STATE TO CA-WORK-AREA(1:11).
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *                   E N D   O F   O C A N L I N                  *
      *----------------------------------------------------------------*
