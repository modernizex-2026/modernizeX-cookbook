      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUCUSIN  -  Customer Inquiry browse engine        *
      *  TYPE    : SUBROUTINE (EXEC CICS LINK from OCCUSIN)          *
      *  FUNCTION: browse the customer master (CUSTFILE) applying a  *
      *            filter (customer-id range / FICO band / state +   *
      *            ZIP prefix) and return ONE page of matching rows  *
      *            in the KCUSIN-AREA commarea, together with the    *
      *            filter-wide aggregates (records scanned, matches  *
      *            found and the average FICO of the matched set).   *
      *  CALL    : EXEC CICS LINK PROGRAM('OUCUSIN')                 *
      *                COMMAREA(KCUSIN-AREA) END-EXEC.               *
      *  FILES   : CUSTFILE (browse - STARTBR / READNEXT / ENDBR)    *
      *****************************************************************
      *  DESIGN                                                       *
      *  ------                                                       *
      *  The whole (filtered) customer set is scanned on every call  *
      *  so the aggregates are genuine totals - the same figures the *
      *  OBCUSTP / OBRSCORE / OBRZIP batch listings used to print.   *
      *  While scanning, the first WS-MAX-ROWS matches whose key is  *
      *  greater than the resume key (KUI-START-KEY) are captured as *
      *  the page; if a further match exists the more-switch is set. *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUCUSIN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity.                                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUCUSIN'.
      *----------------------------------------------------------------*
      *  Browse control and work fields.                              *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-MAX-ROWS          PIC 9(02) VALUE 13.
           05  WS-LAST-KEY          PIC 9(09) VALUE ZEROS.
           05  WS-I                 PIC 9(02) VALUE ZEROS.
           05  WS-ZIPLEN            PIC 9(02) VALUE ZEROS.
           05  WS-NAME              PIC X(30) VALUE SPACES.
           05  WS-MATCH-SW          PIC X(01) VALUE 'N'.
               88  WS-MATCHED                 VALUE 'Y'.
               88  WS-NOT-MATCHED             VALUE 'N'.
      *----------------------------------------------------------------*
      *  Shared constants (RESP fields, file names, switches, edits).  *
      *----------------------------------------------------------------*
       COPY WCONST.
      *----------------------------------------------------------------*
      *  Customer record layout that is browsed.                       *
      *----------------------------------------------------------------*
       COPY RCUST.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
      *----------------------------------------------------------------*
      *  The customer inquiry interface is the single area passed on   *
      *  LINK.  Request half in / response half + rows out.           *
      *----------------------------------------------------------------*
       COPY KCUSIN.
      *================================================================*
       PROCEDURE DIVISION USING KCUSIN-AREA.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  top level driver.                              *
      *----------------------------------------------------------------*
       0000-MAIN.
           PERFORM 1000-INIT-RESPONSE.
           PERFORM 2000-BROWSE-CUSTOMERS.
           PERFORM 3000-FINALIZE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INIT-RESPONSE  -  clear the response half of the area.  *
      *----------------------------------------------------------------*
       1000-INIT-RESPONSE.
           SET KUI-OK TO TRUE.
           MOVE ZEROS TO KUI-ROW-COUNT.
           MOVE ZEROS TO KUI-SCAN-COUNT.
           MOVE ZEROS TO KUI-MATCH-COUNT.
           MOVE ZEROS TO KUI-FICO-TOT.
           MOVE ZEROS TO KUI-FICO-AVG.
           MOVE 999   TO KUI-FICO-MIN.
           MOVE ZEROS TO KUI-FICO-MAX.
           MOVE ZEROS TO KUI-NEXT-KEY.
           SET KUI-NO-MORE TO TRUE.
           MOVE ZEROS TO WS-LAST-KEY.
           SET WS-NOT-MATCHED TO TRUE.
           MOVE 'N' TO WS-END-FLG.
           INITIALIZE KUI-ROWS.
      *----------------------------------------------------------------*
      *  2000-BROWSE-CUSTOMERS  -  drive the sequential scan.         *
      *----------------------------------------------------------------*
       2000-BROWSE-CUSTOMERS.
           PERFORM 2100-START-BROWSE.
           IF NOT END-OF-FILE
               PERFORM 2200-READ-NEXT
                   UNTIL END-OF-FILE
               PERFORM 2300-END-BROWSE
           END-IF.
           IF KUI-ROW-COUNT > ZEROS
               MOVE WS-LAST-KEY TO KUI-NEXT-KEY
           END-IF.
      *----------------------------------------------------------------*
      *  2100-START-BROWSE  -  position the browse.  For an id range   *
      *  begin at the low id; otherwise begin at the start of file.   *
      *----------------------------------------------------------------*
       2100-START-BROWSE.
           IF KUI-F-IDRANGE
               MOVE KUI-ID-FROM TO CU-ID
           ELSE
               MOVE ZEROS TO CU-ID
           END-IF.
           EXEC CICS STARTBR
                     FILE(WS-CUSTFILE)
                     RIDFLD(CU-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(NOTFND)
                   SET END-OF-FILE TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET END-OF-FILE TO TRUE
               WHEN OTHER
                   SET END-OF-FILE TO TRUE
                   SET KUI-ERROR TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2200-READ-NEXT  -  read one customer, count it, apply the     *
      *  filter and, when it qualifies, tally it and (if it belongs   *
      *  to the requested page) capture it as a display row.          *
      *----------------------------------------------------------------*
       2200-READ-NEXT.
           EXEC CICS READNEXT
                     FILE(WS-CUSTFILE)
                     INTO(CUST-REC)
                     RIDFLD(CU-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   PERFORM 2250-HANDLE-RECORD
               WHEN DFHRESP(ENDFILE)
                   SET END-OF-FILE TO TRUE
               WHEN OTHER
                   SET END-OF-FILE TO TRUE
                   SET KUI-ERROR TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2250-HANDLE-RECORD  -  per-record processing.                *
      *----------------------------------------------------------------*
       2250-HANDLE-RECORD.
           ADD 1 TO KUI-SCAN-COUNT.
           IF KUI-F-IDRANGE AND CU-ID > KUI-ID-TO
               SET END-OF-FILE TO TRUE
           ELSE
               PERFORM 2400-FILTER-CHECK
               IF WS-MATCHED
                   ADD 1 TO KUI-MATCH-COUNT
                   ADD CU-FICO-SCORE TO KUI-FICO-TOT
                   IF CU-FICO-SCORE < KUI-FICO-MIN
                       MOVE CU-FICO-SCORE TO KUI-FICO-MIN
                   END-IF
                   IF CU-FICO-SCORE > KUI-FICO-MAX
                       MOVE CU-FICO-SCORE TO KUI-FICO-MAX
                   END-IF
                   IF CU-ID > KUI-START-KEY
                       IF KUI-ROW-COUNT < WS-MAX-ROWS
                           PERFORM 2500-STORE-ROW
                       ELSE
                           SET KUI-MORE TO TRUE
                       END-IF
                   END-IF
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2300-END-BROWSE  -  release the browse position.             *
      *----------------------------------------------------------------*
       2300-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-CUSTFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  2400-FILTER-CHECK  -  set WS-MATCHED for the active filter.   *
      *----------------------------------------------------------------*
       2400-FILTER-CHECK.
           SET WS-NOT-MATCHED TO TRUE.
           EVALUATE TRUE
               WHEN KUI-F-IDRANGE
                   IF CU-ID >= KUI-ID-FROM
                      AND CU-ID <= KUI-ID-TO
                       SET WS-MATCHED TO TRUE
                   END-IF
               WHEN KUI-F-FICO
                   IF CU-FICO-SCORE >= KUI-FICO-FROM
                      AND CU-FICO-SCORE <= KUI-FICO-TO
                       SET WS-MATCHED TO TRUE
                   END-IF
               WHEN KUI-F-STZIP
                   PERFORM 2450-CHECK-STATE-ZIP
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2450-CHECK-STATE-ZIP  -  match on state and, when a ZIP is    *
      *  keyed, on its leading (prefix) characters.                   *
      *----------------------------------------------------------------*
       2450-CHECK-STATE-ZIP.
           IF CU-ADDR-STATE NOT = KUI-STATE
               GO TO 2450-EXIT
           END-IF.
           MOVE ZEROS TO WS-ZIPLEN.
           PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > 10
               IF KUI-ZIP(WS-I:1) NOT = SPACE
                   MOVE WS-I TO WS-ZIPLEN
               END-IF
           END-PERFORM.
           IF WS-ZIPLEN = ZEROS
               SET WS-MATCHED TO TRUE
           ELSE
               IF CU-ADDR-ZIP(1:WS-ZIPLEN) = KUI-ZIP(1:WS-ZIPLEN)
                   SET WS-MATCHED TO TRUE
               END-IF
           END-IF.
       2450-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2500-STORE-ROW  -  copy the current customer into the next    *
      *  free display row of the page.                                *
      *----------------------------------------------------------------*
       2500-STORE-ROW.
           ADD 1 TO KUI-ROW-COUNT.
           MOVE CU-ID TO WS-LAST-KEY.
           PERFORM 2600-BUILD-NAME.
           MOVE CU-ID           TO KUR-ID     (KUI-ROW-COUNT).
           MOVE WS-NAME         TO KUR-NAME   (KUI-ROW-COUNT).
           MOVE CU-ADDR-STATE   TO KUR-STATE  (KUI-ROW-COUNT).
           MOVE CU-ADDR-ZIP     TO KUR-ZIP    (KUI-ROW-COUNT).
           MOVE CU-FICO-SCORE   TO KUR-FICO   (KUI-ROW-COUNT).
      *----------------------------------------------------------------*
      *  2600-BUILD-NAME  -  assemble "First Last" into WS-NAME.       *
      *----------------------------------------------------------------*
       2600-BUILD-NAME.
           MOVE SPACES TO WS-NAME.
           STRING CU-FIRST-NAME DELIMITED BY '  '
                  ' '           DELIMITED BY SIZE
                  CU-LAST-NAME  DELIMITED BY '  '
                  INTO WS-NAME
           END-STRING.
      *----------------------------------------------------------------*
      *  3000-FINALIZE  -  derive the average FICO of the matched set. *
      *----------------------------------------------------------------*
       3000-FINALIZE.
           IF KUI-MATCH-COUNT > ZEROS
               COMPUTE KUI-FICO-AVG ROUNDED =
                   KUI-FICO-TOT / KUI-MATCH-COUNT
           ELSE
               MOVE ZEROS TO KUI-FICO-AVG
               MOVE ZEROS TO KUI-FICO-MIN
           END-IF.
