      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : ODACCTU  -  Account Update (on-line, DB2)         *
      *  TYPE    : CICS ONLINE + DB2  (pseudo-conversational)        *
      *  FUNCTION: accept an account id, SELECT the account row for  *
      *            editing, then UPDATE the ACCT table (ORION.ACCT)  *
      *            via EXEC SQL with the amended values.             *
      *            ENTER = fetch current, PF5 = commit update,       *
      *            PF3 = back to menu, PF4 = clear.                  *
      *  NOTE    : DB2 variant of the OCACCTU online program.        *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. ODACCTU.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'ODACCTU'.
           05  WS-TRANID            PIC X(04) VALUE 'OD02'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
       01  WS-MODE-FLAG             PIC X(01) VALUE 'F'.
           88  MODE-FETCH                     VALUE 'F'.
           88  MODE-UPDATE                    VALUE 'U'.
       01  WS-VALID-FLAG            PIC X(01) VALUE 'Y'.
           88  INPUT-VALID                    VALUE 'Y'.
           88  INPUT-INVALID                  VALUE 'N'.
      *----------------------------------------------------------------*
      *  DB2 communication area.                                       *
      *----------------------------------------------------------------*
           EXEC SQL INCLUDE SQLCA END-EXEC.
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RACCT.
       COPY MACCTU.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MACCTUAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'F' TO CA-WORK-AREA (1:1).
           MOVE 'Enter account id and press ENTER to fetch.'
               TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MACCTUA')
                     MAPSET('MACCTU')
                     FROM(MACCTUAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           MOVE CA-WORK-AREA (1:1) TO WS-MODE-FLAG.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-FETCH-ACCT
               WHEN DFHPF5
                   PERFORM 2200-UPDATE-ACCT
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  ENTER : read the current row and display it for editing.      *
      *----------------------------------------------------------------*
       2100-FETCH-ACCT.
           EXEC CICS RECEIVE
                     MAP('MACCTUA')
                     MAPSET('MACCTU')
                     INTO(MACCTUAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF ACCTIDI = SPACES OR ACCTIDI = LOW-VALUES
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               IF ACCTIDI IS NUMERIC
                   MOVE ACCTIDI TO AC-ID
                   MOVE AC-ID   TO CA-ACCT-ID
                   PERFORM 3000-READ-ACCT
                   IF REC-FOUND
                       PERFORM 4000-POPULATE-DETAIL
                       MOVE 'U' TO CA-WORK-AREA (1:1)
                       MOVE 'Amend fields and press PF5 to update.'
                           TO ERRMSGO
                       PERFORM 8100-SEND-DATAONLY
                   ELSE
                       MOVE WS-MSG-NOTFND TO ERRMSGO
                       PERFORM 8100-SEND-DATAONLY
                   END-IF
               ELSE
                   MOVE 'Account id must be numeric.' TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  PF5 : validate the amended fields and UPDATE the row.         *
      *----------------------------------------------------------------*
       2200-UPDATE-ACCT.
           EXEC CICS RECEIVE
                     MAP('MACCTUA')
                     MAPSET('MACCTU')
                     INTO(MACCTUAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF NOT MODE-UPDATE
               MOVE 'Press ENTER to fetch a row before PF5.'
                   TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 2300-EDIT-INPUT
               IF INPUT-VALID
                   MOVE ACCTIDI TO AC-ID
                   PERFORM 3100-UPDATE-ACCT
                   IF REC-FOUND
                       MOVE 'Account updated successfully.'
                           TO ERRMSGO
                   ELSE
                       MOVE WS-MSG-NOTFND TO ERRMSGO
                   END-IF
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
       2300-EDIT-INPUT.
           SET INPUT-VALID TO TRUE.
           IF ACCTIDI = SPACES OR ACCTIDI NOT NUMERIC
               MOVE 'Account id is required and numeric.' TO ERRMSGO
               SET INPUT-INVALID TO TRUE
           END-IF.
           IF INPUT-VALID
               IF ACSTATI = 'Y' OR ACSTATI = 'N'
                   CONTINUE
               ELSE
                   MOVE 'Status must be Y or N.' TO ERRMSGO
                   SET INPUT-INVALID TO TRUE
               END-IF
           END-IF.
           IF INPUT-VALID
               IF ACCRLIMI = SPACES OR ACCSLIMI = SPACES
                   MOVE 'Credit and cash limits are required.'
                       TO ERRMSGO
                   SET INPUT-INVALID TO TRUE
               END-IF
           END-IF.
           IF INPUT-VALID
               MOVE ACSTATI TO AC-ACTIVE-STATUS
               COMPUTE AC-CREDIT-LIMIT = FUNCTION NUMVAL(ACCRLIMI)
               COMPUTE AC-CASH-LIMIT   = FUNCTION NUMVAL(ACCSLIMI)
               MOVE ACEXPI  TO AC-EXPIRY-DATE
               MOVE ACGRPI  TO AC-GROUP-ID
           END-IF.
      *----------------------------------------------------------------*
      *  DB2 read : SELECT the account row for display / editing.      *
      *----------------------------------------------------------------*
       3000-READ-ACCT.
           SET REC-NOT-FOUND TO TRUE.
           EXEC SQL
                SELECT AC_ACTIVE_STATUS,
                       AC_CREDIT_LIMIT,
                       AC_CASH_LIMIT,
                       AC_EXPIRY_DATE,
                       AC_GROUP_ID
                  INTO :AC-ACTIVE-STATUS,
                       :AC-CREDIT-LIMIT,
                       :AC-CASH-LIMIT,
                       :AC-EXPIRY-DATE,
                       :AC-GROUP-ID
                  FROM ORION.ACCT
                 WHERE AC_ID = :AC-ID
           END-EXEC.
           EVALUATE SQLCODE
               WHEN 0
                   SET REC-FOUND TO TRUE
               WHEN 100
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   MOVE 'Error reading account table.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  DB2 update : write the amended values back to the row.        *
      *----------------------------------------------------------------*
       3100-UPDATE-ACCT.
           SET REC-NOT-FOUND TO TRUE.
           EXEC SQL
                UPDATE ORION.ACCT
                   SET AC_ACTIVE_STATUS = :AC-ACTIVE-STATUS,
                       AC_CREDIT_LIMIT  = :AC-CREDIT-LIMIT,
                       AC_CASH_LIMIT    = :AC-CASH-LIMIT,
                       AC_EXPIRY_DATE   = :AC-EXPIRY-DATE,
                       AC_GROUP_ID      = :AC-GROUP-ID
                 WHERE AC_ID = :AC-ID
           END-EXEC.
           EVALUATE SQLCODE
               WHEN 0
                   SET REC-FOUND TO TRUE
               WHEN 100
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   MOVE 'Error updating account table.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE AC-ID             TO ACCTIDO.
           MOVE AC-ACTIVE-STATUS  TO ACSTATO.
           MOVE AC-CREDIT-LIMIT   TO WS-ED-AMT.
           MOVE WS-ED-AMT         TO ACCRLIMO.
           MOVE AC-CASH-LIMIT     TO WS-ED-AMT.
           MOVE WS-ED-AMT         TO ACCSLIMO.
           MOVE AC-EXPIRY-DATE    TO ACEXPO.
           MOVE AC-GROUP-ID       TO ACGRPO.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MACCTUA')
                     MAPSET('MACCTU')
                     FROM(MACCTUAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
