      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCCARDL  -  Card List for an account (on-line)    *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: accept an account id, browse CARDFILE and list    *
      *            up to five cards belonging to that account,       *
      *            showing card number and active status.            *
      *  KEYS    : ENTER = list first page                          *
      *            PF8   = next page      PF7 = first page           *
      *            PF3   = main menu      PF4 = clear                *
      *  STATE   : CA-WORK-AREA(1:1)  'K' key entry / 'L' listing    *
      *            CA-WORK-AREA(2:16) resume card number (paging)    *
      *  NOTE    : CARDFILE is browsed on its primary key (CD-NUM)   *
      *            and filtered by CD-ACCT-ID, so no alternate-index *
      *            path name is required.  Paging is forward-only;   *
      *            PF7 restarts the list from the top.               *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCCARDL.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity constants.                                   *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCCARDL'.
           05  WS-TRANID            PIC X(04) VALUE 'ORCL'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
           05  WS-MAX-ROWS          PIC 9(01) VALUE 5.
      *----------------------------------------------------------------*
      *  Validation switch.                                           *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  State byte constants.                                        *
      *----------------------------------------------------------------*
       01  WS-STATE-CONST.
           05  WS-ST-KEY            PIC X(01) VALUE 'K'.
           05  WS-ST-LIST           PIC X(01) VALUE 'L'.
      *----------------------------------------------------------------*
      *  Numeric key validation work area (account id).              *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(11) VALUE SPACES.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(11) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Browse control fields and the collected page of cards.       *
      *----------------------------------------------------------------*
       01  WS-BROWSE-FLAGS.
           05  WS-BR-END-SW         PIC X(01) VALUE 'N'.
               88  BR-END                     VALUE 'Y'.
               88  BR-MORE                    VALUE 'N'.
           05  WS-BR-STARTED-SW     PIC X(01) VALUE 'N'.
               88  BR-STARTED                 VALUE 'Y'.
               88  BR-NOT-STARTED             VALUE 'N'.
           05  WS-MORE-SW           PIC X(01) VALUE 'N'.
               88  WS-MORE-PAGES              VALUE 'Y'.
               88  WS-NO-MORE-PAGES           VALUE 'N'.
       01  WS-BROWSE-KEYS.
           05  WS-START-CARD        PIC X(16) VALUE LOW-VALUES.
           05  WS-BROWSE-KEY        PIC X(16) VALUE LOW-VALUES.
           05  WS-RESUME-CARD       PIC X(16) VALUE LOW-VALUES.
       01  WS-ROW-CTRS.
           05  WS-ROW-CNT           PIC 9(02) VALUE ZEROS.
       01  WS-CARD-TABLE.
           05  WS-ROW OCCURS 5 TIMES.
               10  WS-ROW-CARD      PIC X(16).
               10  WS-ROW-STAT      PIC X(01).
      *----------------------------------------------------------------*
      *  Shared copybooks.                                            *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RCARD.
       COPY MCARDL.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN : standard dispatcher.                            *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL : prompt for an account id.               *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MCARDLAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-ST-KEY TO CA-WORK-AREA(1:1).
           MOVE LOW-VALUES TO CA-WORK-AREA(2:16).
           MOVE 'Enter account id and press ENTER to list cards.'
               TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MCARDLA')
                     MAPSET('MCARDL')
                     FROM(MCARDLAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT : react to the attention identifier.      *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF12
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHCLEAR
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-FIRST-PAGE
               WHEN DFHPF7
                   PERFORM 2100-FIRST-PAGE
               WHEN DFHPF8
                   PERFORM 2200-NEXT-PAGE
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2050-RECEIVE : read the map; treat MAPFAIL as empty input.   *
      *----------------------------------------------------------------*
       2050-RECEIVE.
           EXEC CICS RECEIVE
                     MAP('MCARDLA')
                     MAPSET('MCARDL')
                     INTO(MCARDLAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MCARDLAI
           END-IF.
      *----------------------------------------------------------------*
      *  2100-FIRST-PAGE : validate the account and list from top.    *
      *----------------------------------------------------------------*
       2100-FIRST-PAGE.
           PERFORM 2050-RECEIVE.
           PERFORM 6000-VALIDATE-ACCTID.
           IF WS-INVALID
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE WS-NC-VALUE TO CA-ACCT-ID
               MOVE LOW-VALUES  TO WS-START-CARD
               PERFORM 3000-BROWSE-CARDS
               PERFORM 4000-SHOW-PAGE
               MOVE WS-ST-LIST TO CA-WORK-AREA(1:1)
               MOVE WS-RESUME-CARD TO CA-WORK-AREA(2:16)
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  2200-NEXT-PAGE : continue the list after the resume key.     *
      *----------------------------------------------------------------*
       2200-NEXT-PAGE.
           IF CA-WORK-AREA(1:1) NOT = WS-ST-LIST
               MOVE 'List an account first (press ENTER).'
                   TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 2050-RECEIVE
               MOVE CA-WORK-AREA(2:16) TO WS-START-CARD
               PERFORM 3000-BROWSE-CARDS
               PERFORM 4000-SHOW-PAGE
               IF WS-ROW-CNT = 0
                   MOVE 'No more cards for this account.' TO ERRMSGO
               END-IF
               MOVE WS-RESUME-CARD TO CA-WORK-AREA(2:16)
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  3000-BROWSE-CARDS : gather up to WS-MAX-ROWS matching cards  *
      *  starting at (and past) WS-START-CARD.                        *
      *----------------------------------------------------------------*
       3000-BROWSE-CARDS.
           MOVE ZEROS TO WS-ROW-CNT.
           SET BR-MORE TO TRUE.
           SET WS-NO-MORE-PAGES TO TRUE.
           INITIALIZE WS-CARD-TABLE.
           PERFORM 3050-START-BROWSE.
           IF BR-END
               GO TO 3000-EXIT
           END-IF.
           IF WS-START-CARD NOT = LOW-VALUES
               PERFORM 3100-READ-NEXT
           END-IF.
           PERFORM 3200-GATHER
               UNTIL WS-ROW-CNT >= WS-MAX-ROWS OR BR-END.
           IF BR-END
               SET WS-NO-MORE-PAGES TO TRUE
           ELSE
               SET WS-MORE-PAGES TO TRUE
           END-IF.
           PERFORM 3300-END-BROWSE.
       3000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3050-START-BROWSE : position the browse at the start key.    *
      *----------------------------------------------------------------*
       3050-START-BROWSE.
           SET BR-NOT-STARTED TO TRUE.
           MOVE WS-START-CARD TO WS-BROWSE-KEY.
           EXEC CICS STARTBR
                     FILE(WS-CARDFILE)
                     RIDFLD(WS-BROWSE-KEY)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BR-STARTED TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET BR-END TO TRUE
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3100-READ-NEXT : read one record forward.                    *
      *----------------------------------------------------------------*
       3100-READ-NEXT.
           EXEC CICS READNEXT
                     FILE(WS-CARDFILE)
                     INTO(CARD-REC)
                     RIDFLD(WS-BROWSE-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE WS-BROWSE-KEY TO WS-RESUME-CARD
               WHEN DFHRESP(ENDFILE)
                   SET BR-END TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-GATHER : read forward, keeping cards for this account.  *
      *----------------------------------------------------------------*
       3200-GATHER.
           PERFORM 3100-READ-NEXT.
           IF NOT BR-END
               IF CD-ACCT-ID = CA-ACCT-ID
                   ADD 1 TO WS-ROW-CNT
                   MOVE CD-NUM           TO WS-ROW-CARD(WS-ROW-CNT)
                   MOVE CD-ACTIVE-STATUS TO WS-ROW-STAT(WS-ROW-CNT)
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3300-END-BROWSE : terminate the browse if it was started.    *
      *----------------------------------------------------------------*
       3300-END-BROWSE.
           IF BR-STARTED
               EXEC CICS ENDBR
                         FILE(WS-CARDFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
      *----------------------------------------------------------------*
      *  4000-SHOW-PAGE : move the gathered rows into the map and     *
      *  build the status line.                                       *
      *----------------------------------------------------------------*
       4000-SHOW-PAGE.
           MOVE CA-ACCT-ID TO ACCTIDO.
           PERFORM 4100-CLEAR-ROWS.
           IF WS-ROW-CNT >= 1
               MOVE WS-ROW-CARD(1) TO CARD1O
               MOVE WS-ROW-STAT(1) TO STAT1O
           END-IF.
           IF WS-ROW-CNT >= 2
               MOVE WS-ROW-CARD(2) TO CARD2O
               MOVE WS-ROW-STAT(2) TO STAT2O
           END-IF.
           IF WS-ROW-CNT >= 3
               MOVE WS-ROW-CARD(3) TO CARD3O
               MOVE WS-ROW-STAT(3) TO STAT3O
           END-IF.
           IF WS-ROW-CNT >= 4
               MOVE WS-ROW-CARD(4) TO CARD4O
               MOVE WS-ROW-STAT(4) TO STAT4O
           END-IF.
           IF WS-ROW-CNT >= 5
               MOVE WS-ROW-CARD(5) TO CARD5O
               MOVE WS-ROW-STAT(5) TO STAT5O
           END-IF.
           IF WS-ROW-CNT = 0
               MOVE 'No cards found for this account.' TO ERRMSGO
           ELSE
               IF WS-MORE-PAGES
                   MOVE 'Cards listed. PF8=next PF7=top PF3=menu.'
                       TO ERRMSGO
               ELSE
                   MOVE 'End of list. PF7=top PF3=menu.'
                       TO ERRMSGO
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  4100-CLEAR-ROWS : blank all list fields before repopulating. *
      *----------------------------------------------------------------*
       4100-CLEAR-ROWS.
           MOVE SPACES TO CARD1O CARD2O CARD3O CARD4O CARD5O.
           MOVE SPACES TO STAT1O STAT2O STAT3O STAT4O STAT5O.
      *----------------------------------------------------------------*
      *  6000-VALIDATE-ACCTID : numeric account key, spaces tolerated.*
      *----------------------------------------------------------------*
       6000-VALIDATE-ACCTID.
           SET WS-VALID TO TRUE.
           MOVE ACCTIDI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN = SPACES
               SET WS-INVALID TO TRUE
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               GO TO 6000-EXIT
           END-IF.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > 11
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-INVALID OR WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
               MOVE 'Account id must be numeric.' TO ERRMSGO
           END-IF.
       6000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU : return to the main menu.                    *
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER : common screen header.                *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY : refresh header and resend.             *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MCARDLA')
                     MAPSET('MCARDL')
                     FROM(MCARDLAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME : formatted current date and time.        *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN : pseudo-conversational return.                 *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9500-ABEND-RTN : unrecoverable file error.                  *
      *----------------------------------------------------------------*
       9500-ABEND-RTN.
           IF BR-STARTED
               EXEC CICS ENDBR
                         FILE(WS-CARDFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
           MOVE 'OCCARDL: unrecoverable file error. Contact support.'
               TO WS-MSG-TEXT.
           EXEC CICS SEND TEXT
                     FROM(WS-MSG-TEXT)
                     LENGTH(LENGTH OF WS-MSG-TEXT)
                     ERASE
                     FREEKB
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS RETURN
                     RESP(WS-RESP-CD)
           END-EXEC.
