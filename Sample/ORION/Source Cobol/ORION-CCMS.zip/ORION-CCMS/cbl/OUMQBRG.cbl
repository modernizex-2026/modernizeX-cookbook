      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUMQBRG  -  VSAM-to-MQ transaction bridge        *
      *  TYPE    : SUB  (MQ / MQI CALL)                             *
      *  FUNCTION: read TRANFILE (VSAM KSDS) sequentially and       *
      *            MQPUT each transaction to the outbound queue      *
      *            for a downstream consumer, with counts.          *
      *  RUN     : batch, driven by jcl/RUNMQBRG.jcl (PGM=OUMQBRG). *
      *****************************************************************
      *---------------------------------------------------------------*
      *  DESIGN                                                        *
      *  ------                                                        *
      *  OUMQBRG is the outbound half of the ORION MQ story: it drains *
      *  the posted-transaction store (TRANFILE) and republishes every *
      *  record as an MQ message on ORION.TRAN.OUTBOUND.QUEUE so that  *
      *  downstream systems (fraud, analytics, general ledger) receive *
      *  a real-time transaction feed.                                *
      *                                                                *
      *  Flow:                                                         *
      *    1. OPEN the KSDS for sequential (key-order) input.          *
      *    2. MQCONN to the queue manager and MQOPEN the outbound      *
      *       queue for output.                                        *
      *    3. For each transaction, wrap the record image in a small   *
      *       routing header and MQPUT it, counting puts and errors.   *
      *    4. MQCLOSE the queue, MQDISC from the queue manager and     *
      *       CLOSE the file; print the run counts.                    *
      *                                                                *
      *  Every MQI verb is a native CALL (no EXEC), keeping the code   *
      *  free of any EXEC/END-EXEC pairing.  If MQCONN or MQOPEN fail  *
      *  (no queue manager) the program still reads the file and       *
      *  reports counts, so it is safe to run without live MQ.        *
      *  Ends with GOBACK (never STOP RUN).                            *
      *---------------------------------------------------------------*
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUMQBRG.
       AUTHOR.     ORION-CCMS-BATCH.
      *---------------------------------------------------------------*
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
      *---------------------------------------------------------------*
      *  Transaction store - indexed, read in key sequence.           *
      *---------------------------------------------------------------*
           SELECT TRAN-FILE ASSIGN TO TRANFILE
                  ORGANIZATION IS INDEXED
                  ACCESS MODE IS SEQUENTIAL
                  RECORD KEY IS TR-ID
                  FILE STATUS IS WS-TRAN-FS.
      *---------------------------------------------------------------*
       DATA DIVISION.
       FILE SECTION.
       FD  TRAN-FILE.
       COPY RTRAN.
      *---------------------------------------------------------------*
       WORKING-STORAGE SECTION.
      *---------------------------------------------------------------*
      *  Program constants and MQ object names.                       *
      *---------------------------------------------------------------*
       01  WS-CONSTANTS.
           05  WS-PROGRAM-ID     PIC X(08) VALUE 'OUMQBRG'.
           05  WS-QMGR-NAME      PIC X(48) VALUE 'ORIONQM1'.
           05  WS-OUT-QUEUE      PIC X(48)
               VALUE 'ORION.TRAN.OUTBOUND.QUEUE'.
      *---------------------------------------------------------------*
      *  File status.                                                 *
      *---------------------------------------------------------------*
       01  WS-FILE-STATUS.
           05  WS-TRAN-FS        PIC X(02) VALUE '00'.
      *---------------------------------------------------------------*
      *  Control flags.                                               *
      *---------------------------------------------------------------*
       01  WS-FLAGS.
           05  WS-EOF-FLG        PIC X(01) VALUE 'N'.
               88  END-OF-TRAN               VALUE 'Y'.
           05  WS-TRAN-OPEN-FLG  PIC X(01) VALUE 'N'.
               88  TRAN-OPEN                 VALUE 'Y'.
           05  WS-MQ-DOWN-FLG    PIC X(01) VALUE 'N'.
               88  MQ-IS-DOWN                VALUE 'Y'.
               88  MQ-IS-UP                  VALUE 'N'.
           05  WS-MQ-CONN-FLG    PIC X(01) VALUE 'N'.
               88  MQ-CONNECTED              VALUE 'Y'.
               88  MQ-NOT-CONN               VALUE 'N'.
           05  WS-MQ-OPEN-FLG    PIC X(01) VALUE 'N'.
               88  MQ-Q-OPEN                 VALUE 'Y'.
               88  MQ-Q-CLOSED               VALUE 'N'.
      *---------------------------------------------------------------*
      *  Run counters.                                                *
      *---------------------------------------------------------------*
       01  WS-COUNTERS.
           05  WS-READ-CNT       PIC 9(09) VALUE ZEROS.
           05  WS-PUT-CNT        PIC 9(09) VALUE ZEROS.
           05  WS-PUTERR-CNT     PIC 9(09) VALUE ZEROS.
           05  WS-SKIP-CNT       PIC 9(09) VALUE ZEROS.
      *---------------------------------------------------------------*
      *  Which MQ verb is being checked (for diagnostics).            *
      *---------------------------------------------------------------*
       01  WS-MQ-OP             PIC X(08) VALUE SPACES.
      *---------------------------------------------------------------*
      *  Outbound message = routing header + the tran record image.   *
      *---------------------------------------------------------------*
       01  WS-OUT-MSG.
           05  OM-REC-TYPE       PIC X(04) VALUE 'TRAN'.
           05  OM-SRC-SYSTEM     PIC X(08) VALUE 'ORION   '.
           05  OM-TRAN-DATA      PIC X(350) VALUE SPACES.
      *---------------------------------------------------------------*
      *  MQI control blocks + named constants (ORION-original).      *
      *---------------------------------------------------------------*
       COPY KMQ.
      *---------------------------------------------------------------*
       PROCEDURE DIVISION.
      *---------------------------------------------------------------*
      *  0000-MAIN - top level driver.                               *
      *---------------------------------------------------------------*
       0000-MAIN.
           PERFORM 1000-INITIALIZE.
           PERFORM 2000-BRIDGE-TRANS
               UNTIL END-OF-TRAN.
           PERFORM 3000-FINALIZE.
           GOBACK.
      *---------------------------------------------------------------*
      *  1000-INITIALIZE - open the file, connect + open the queue,   *
      *  and prime the first read.                                   *
      *---------------------------------------------------------------*
       1000-INITIALIZE.
           DISPLAY 'OUMQBRG: VSAM-to-MQ transaction bridge started.'.
           SET MQ-IS-UP TO TRUE.
           OPEN INPUT TRAN-FILE.
           IF WS-TRAN-FS = '00'
               SET TRAN-OPEN TO TRUE
           ELSE
               DISPLAY 'OUMQBRG: OPEN TRANFILE FS=' WS-TRAN-FS
               SET END-OF-TRAN TO TRUE
           END-IF.
           PERFORM 1100-MQ-CONNECT.
           IF MQ-IS-UP
               PERFORM 1200-MQ-OPEN-OUT
           END-IF.
           IF TRAN-OPEN
               PERFORM 2100-READ-TRAN
           END-IF.
      *---------------------------------------------------------------*
      *  1100-MQ-CONNECT - MQCONN to the queue manager.             *
      *---------------------------------------------------------------*
       1100-MQ-CONNECT.
           MOVE 'MQCONN  ' TO WS-MQ-OP.
           CALL 'MQCONN' USING WS-QMGR-NAME MQ-HCONN MQ-CC MQ-RC
           END-CALL.
           IF MQ-CC-OK
               SET MQ-CONNECTED TO TRUE
               DISPLAY 'OUMQBRG: connected to ' WS-QMGR-NAME
           ELSE
               SET MQ-IS-DOWN TO TRUE
               DISPLAY 'OUMQBRG: MQCONN FAILED CC=' MQ-CC ' RC=' MQ-RC
               DISPLAY 'OUMQBRG: continuing in read-only mode.'
           END-IF.
      *---------------------------------------------------------------*
      *  1200-MQ-OPEN-OUT - MQOPEN the outbound queue for output.    *
      *---------------------------------------------------------------*
       1200-MQ-OPEN-OUT.
           MOVE WS-OUT-QUEUE TO MQ-OD-OBJECT-NAME.
           COMPUTE MQ-OPEN-OPTIONS =
               MQ-OO-OUTPUT + MQ-OO-FAIL-IF-QSG.
           MOVE 'MQOPEN  ' TO WS-MQ-OP.
           CALL 'MQOPEN' USING MQ-HCONN MQ-OD MQ-OPEN-OPTIONS
               MQ-HOBJ-OUT MQ-CC MQ-RC
           END-CALL.
           IF MQ-CC-OK
               SET MQ-Q-OPEN TO TRUE
               DISPLAY 'OUMQBRG: opened ' WS-OUT-QUEUE
           ELSE
               SET MQ-IS-DOWN TO TRUE
               DISPLAY 'OUMQBRG: MQOPEN FAILED CC=' MQ-CC ' RC=' MQ-RC
           END-IF.
      *---------------------------------------------------------------*
      *  2000-BRIDGE-TRANS - publish one transaction, then read next.*
      *  When MQ is unavailable the record is counted as skipped so   *
      *  the run still reports what it saw.                          *
      *---------------------------------------------------------------*
       2000-BRIDGE-TRANS.
           ADD 1 TO WS-READ-CNT.
           IF MQ-IS-UP AND MQ-Q-OPEN
               PERFORM 2200-PUT-TRAN
           ELSE
               ADD 1 TO WS-SKIP-CNT
           END-IF.
           PERFORM 2100-READ-TRAN.
      *---------------------------------------------------------------*
      *  2100-READ-TRAN - read the next record in key sequence.      *
      *---------------------------------------------------------------*
       2100-READ-TRAN.
           READ TRAN-FILE
               AT END
                   SET END-OF-TRAN TO TRUE
           END-READ.
           IF WS-TRAN-FS NOT = '00' AND WS-TRAN-FS NOT = '10'
               DISPLAY 'OUMQBRG: READ TRANFILE FS=' WS-TRAN-FS
               SET END-OF-TRAN TO TRUE
           END-IF.
      *---------------------------------------------------------------*
      *  2200-PUT-TRAN - wrap the record and MQPUT it.              *
      *---------------------------------------------------------------*
       2200-PUT-TRAN.
           MOVE 'TRAN' TO OM-REC-TYPE.
           MOVE 'ORION   ' TO OM-SRC-SYSTEM.
           MOVE TRAN-REC TO OM-TRAN-DATA.
           MOVE MQ-MT-DATAGRAM TO MQ-MD-MSG-TYPE.
           MOVE 'MQSTR   ' TO MQ-MD-FORMAT.
           MOVE MQ-PM-NO-SYNCPOINT TO MQ-PMO-OPTIONS.
           MOVE LENGTH OF WS-OUT-MSG TO MQ-BUFFER-LEN.
           MOVE LOW-VALUES TO MQ-MD-MSG-ID.
           MOVE LOW-VALUES TO MQ-MD-CORREL-ID.
           MOVE 'MQPUT   ' TO WS-MQ-OP.
           CALL 'MQPUT' USING MQ-HCONN MQ-HOBJ-OUT MQ-MD
               MQ-PMO MQ-BUFFER-LEN WS-OUT-MSG MQ-CC MQ-RC
           END-CALL.
           IF MQ-CC-OK
               ADD 1 TO WS-PUT-CNT
           ELSE
               ADD 1 TO WS-PUTERR-CNT
               DISPLAY 'OUMQBRG: MQPUT id=' TR-ID
                       ' CC=' MQ-CC ' RC=' MQ-RC
           END-IF.
      *---------------------------------------------------------------*
      *  3000-FINALIZE - close the queue, disconnect, close file.    *
      *---------------------------------------------------------------*
       3000-FINALIZE.
           IF MQ-Q-OPEN
               PERFORM 3100-MQ-CLOSE-OUT
           END-IF.
           IF MQ-CONNECTED
               PERFORM 3200-MQ-DISCONNECT
           END-IF.
           IF TRAN-OPEN
               CLOSE TRAN-FILE
               IF WS-TRAN-FS NOT = '00'
                   DISPLAY 'OUMQBRG: CLOSE TRANFILE FS=' WS-TRAN-FS
               END-IF
           END-IF.
           PERFORM 3900-DISPLAY-SUMMARY.
      *---------------------------------------------------------------*
      *  3100-MQ-CLOSE-OUT - MQCLOSE the outbound queue.            *
      *---------------------------------------------------------------*
       3100-MQ-CLOSE-OUT.
           MOVE MQ-CL-NONE TO MQ-CLOSE-OPTIONS.
           MOVE 'MQCLOSE ' TO WS-MQ-OP.
           CALL 'MQCLOSE' USING MQ-HCONN MQ-HOBJ-OUT
               MQ-CLOSE-OPTIONS MQ-CC MQ-RC
           END-CALL.
           IF NOT MQ-CC-OK
               DISPLAY 'OUMQBRG: MQCLOSE CC=' MQ-CC ' RC=' MQ-RC
           END-IF.
      *---------------------------------------------------------------*
      *  3200-MQ-DISCONNECT - MQDISC from the queue manager.        *
      *---------------------------------------------------------------*
       3200-MQ-DISCONNECT.
           MOVE 'MQDISC  ' TO WS-MQ-OP.
           CALL 'MQDISC' USING MQ-HCONN MQ-CC MQ-RC
           END-CALL.
           IF NOT MQ-CC-OK
               DISPLAY 'OUMQBRG: MQDISC CC=' MQ-CC ' RC=' MQ-RC
           END-IF.
      *---------------------------------------------------------------*
      *  3900-DISPLAY-SUMMARY - echo run counts to the job log.      *
      *---------------------------------------------------------------*
       3900-DISPLAY-SUMMARY.
           DISPLAY 'OUMQBRG: records read    = ' WS-READ-CNT.
           DISPLAY 'OUMQBRG: messages put    = ' WS-PUT-CNT.
           DISPLAY 'OUMQBRG: put errors      = ' WS-PUTERR-CNT.
           DISPLAY 'OUMQBRG: skipped (no MQ) = ' WS-SKIP-CNT.
           DISPLAY 'OUMQBRG: bridge complete.'.
