      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCCRDIN  -  Card Inquiry (consolidated)           *
      *  TYPE    : ONLINE CICS  (inquiry)                            *
      *  FUNCTION: paged inquiry over the card master.  The operator *
      *            types a filter (ALL / ACTIVE / INACTIVE /         *
      *            EXPIRING-SOON) and presses ENTER; the screen LINKs *
      *            to the browse sub OUCRDIN which walks CARDFILE and *
      *            returns one page of matching cards with card       *
      *            number, owning account, embossed name, expiry and  *
      *            status.  PF8 pages forward, PF7 restarts, PF3      *
      *            returns to the menu.                              *
      *  MAPSET  : MCRDIN      MAP : MCRDINA     TRANID : ORCI       *
      *  LINKS   : OUCRDIN  (COMMAREA = KCRDIN)                      *
      *  NOTE    : follows the OCCARDL golden list skeleton but the   *
      *            file walk lives in the sub, not here.              *
      *****************************************************************
      *  This screen REPLACES four batch card reports:              *
      *    OBCARDP  OBRCARD  OBCARDX  OBRCHLDR                       *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - consolidated card inquiry.     *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCCRDIN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCCRDIN'.
           05  WS-TRANID            PIC X(04) VALUE 'ORCI'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
           05  WS-SUB-PGM           PIC X(08) VALUE 'OUCRDIN'.
      *----------------------------------------------------------------*
      *  Validation switch.                                            *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Pseudo-conversational state kept in CA-WORK-AREA(1:40).       *
      *  The whole-population active / inactive tallies are captured   *
      *  on the first page and carried forward so PF8 need not rescan. *
      *----------------------------------------------------------------*
       01  WS-STATE.
           05  WS-ST-FILTER         PIC X(01).
           05  WS-ST-NEXT-KEY       PIC X(16).
           05  WS-ST-PAGE-NO        PIC 9(03).
           05  WS-ST-ACT            PIC 9(09).
           05  WS-ST-INA            PIC 9(09).
           05  WS-ST-MORE           PIC X(01).
           05  WS-ST-LISTED         PIC X(01).
      *----------------------------------------------------------------*
      *  Filter parse work area and echoed description.                *
      *----------------------------------------------------------------*
       01  WS-FILTER-WORK.
           05  WS-FILT-IN           PIC X(10) VALUE SPACES.
           05  WS-FDESC             PIC X(12) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Screen edit fields.                                           *
      *----------------------------------------------------------------*
       01  WS-EDIT-FIELDS.
           05  WS-I                 PIC 9(02) VALUE ZEROS.
           05  WS-CNT-ED            PIC Z9.
           05  WS-ED-PG             PIC ZZ9.
           05  WS-ED-CNT            PIC Z(6)9.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Type a filter and press ENTER.'.
           05  WS-M-BAD-FILTER      PIC X(50)
               VALUE 'Filter not recognised - see the list above.'.
           05  WS-M-NONE-FOUND      PIC X(50)
               VALUE 'No cards match that filter.'.
           05  WS-M-END-FILE        PIC X(50)
               VALUE 'End of selection - no more cards.'.
           05  WS-M-LIST-FIRST      PIC X(50)
               VALUE 'Apply a filter first (press ENTER).'.
           05  WS-M-LINK-ERR        PIC X(50)
               VALUE 'Unable to reach the card browse engine.'.
           05  WS-M-BROWSE-ERR      PIC X(50)
               VALUE 'Error browsing the card file.'.
           05  WS-M-MORE            PIC X(30)
               VALUE ' shown - PF8=more PF7=top'.
           05  WS-M-DONE            PIC X(30)
               VALUE ' shown - end of selection'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  Browse-interface area built here and passed on LINK.          *
      *----------------------------------------------------------------*
       COPY KCRDIN.
      *----------------------------------------------------------------*
      *  BMS symbolic map.                                             *
      *----------------------------------------------------------------*
       COPY MCRDIN.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh screen.      *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MCRDINAO.
           INITIALIZE KCRDIN-AREA.
           PERFORM 8000-POPULATE-HEADER.
           PERFORM 4100-CLEAR-ROWS.
           MOVE 'A' TO WS-ST-FILTER.
           MOVE LOW-VALUES TO WS-ST-NEXT-KEY.
           MOVE ZEROS TO WS-ST-PAGE-NO.
           MOVE ZEROS TO WS-ST-ACT.
           MOVE ZEROS TO WS-ST-INA.
           MOVE 'N' TO WS-ST-MORE.
           MOVE 'N' TO WS-ST-LISTED.
           MOVE WS-STATE TO CA-WORK-AREA(1:40).
           MOVE 'ALL' TO FDESCO.
           PERFORM 4400-SHOW-TOTALS.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO FILTL.
           EXEC CICS SEND
                     MAP('MCRDINA')
                     MAPSET('MCRDIN')
                     FROM(MCRDINAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           MOVE CA-WORK-AREA(1:40) TO WS-STATE.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF12
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHCLEAR
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-APPLY-FILTER
               WHEN DFHPF7
                   PERFORM 2200-RESTART
               WHEN DFHPF8
                   PERFORM 2300-PAGE-FWD
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 6100-SET-FDESC
                   MOVE WS-FDESC TO FDESCO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2050-RECEIVE  -  read the map; treat MAPFAIL as empty input.  *
      *----------------------------------------------------------------*
       2050-RECEIVE.
           EXEC CICS RECEIVE
                     MAP('MCRDINA')
                     MAPSET('MCRDIN')
                     INTO(MCRDINAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MCRDINAI
           END-IF.
      *----------------------------------------------------------------*
      *  2100-APPLY-FILTER  -  ENTER: parse the filter and list from   *
      *  the top of the file.                                          *
      *----------------------------------------------------------------*
       2100-APPLY-FILTER.
           PERFORM 2050-RECEIVE.
           PERFORM 6000-PARSE-FILTER.
           IF WS-INVALID
               MOVE WS-M-BAD-FILTER TO ERRMSGO
               MOVE -1 TO FILTL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE WS-ST-FILTER TO KCI-FILTER
               MOVE LOW-VALUES   TO KCI-START-KEY
               SET KCI-DO-KPI    TO TRUE
               MOVE 1            TO WS-ST-PAGE-NO
               MOVE 'Y'          TO WS-ST-LISTED
               PERFORM 2400-RUN-PAGE
           END-IF.
      *----------------------------------------------------------------*
      *  2200-RESTART  -  PF7: re-list the current filter from the top.*
      *----------------------------------------------------------------*
       2200-RESTART.
           IF WS-ST-LISTED NOT = 'Y'
               MOVE WS-M-LIST-FIRST TO ERRMSGO
               MOVE -1 TO FILTL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE WS-ST-FILTER TO KCI-FILTER
               MOVE LOW-VALUES   TO KCI-START-KEY
               SET KCI-DO-KPI    TO TRUE
               MOVE 1            TO WS-ST-PAGE-NO
               PERFORM 2400-RUN-PAGE
           END-IF.
      *----------------------------------------------------------------*
      *  2300-PAGE-FWD  -  PF8: continue after the saved resume key.   *
      *----------------------------------------------------------------*
       2300-PAGE-FWD.
           IF WS-ST-LISTED NOT = 'Y'
               MOVE WS-M-LIST-FIRST TO ERRMSGO
               MOVE -1 TO FILTL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               IF WS-ST-MORE NOT = 'Y'
                   PERFORM 6100-SET-FDESC
                   MOVE WS-FDESC TO FDESCO
                   MOVE WS-M-END-FILE TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE WS-ST-FILTER   TO KCI-FILTER
                   MOVE WS-ST-NEXT-KEY TO KCI-START-KEY
                   SET KCI-SKIP-KPI    TO TRUE
                   ADD 1 TO WS-ST-PAGE-NO
                   PERFORM 2400-RUN-PAGE
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2400-RUN-PAGE  -  call the browse sub, capture the population *
      *  tallies on the first page, save resume state and paint.       *
      *----------------------------------------------------------------*
       2400-RUN-PAGE.
           PERFORM 3000-CALL-SUB.
           IF WS-INVALID
               MOVE -1 TO FILTL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               IF KCI-DO-KPI
                   MOVE KCI-ACTIVE-CNT   TO WS-ST-ACT
                   MOVE KCI-INACTIVE-CNT TO WS-ST-INA
               END-IF
               MOVE KCI-NEXT-KEY    TO WS-ST-NEXT-KEY
               MOVE KCI-MORE-SW     TO WS-ST-MORE
               PERFORM 4000-SHOW-PAGE
               MOVE -1 TO FILTL
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  3000-CALL-SUB  -  LINK to the OUCRDIN browse engine.          *
      *----------------------------------------------------------------*
       3000-CALL-SUB.
           SET WS-VALID TO TRUE.
           EXEC CICS LINK
                     PROGRAM(WS-SUB-PGM)
                     COMMAREA(KCRDIN-AREA)
                     LENGTH(LENGTH OF KCRDIN-AREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               SET WS-INVALID TO TRUE
               PERFORM 6100-SET-FDESC
               MOVE WS-FDESC TO FDESCO
               MOVE WS-M-LINK-ERR TO ERRMSGO
           ELSE
               IF KCI-ERROR
                   SET WS-INVALID TO TRUE
                   PERFORM 6100-SET-FDESC
                   MOVE WS-FDESC TO FDESCO
                   MOVE WS-M-BROWSE-ERR TO ERRMSGO
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  4000-SHOW-PAGE  -  paint the returned rows and the totals.    *
      *----------------------------------------------------------------*
       4000-SHOW-PAGE.
           PERFORM 6100-SET-FDESC.
           MOVE WS-FDESC TO FDESCO.
           PERFORM 4100-CLEAR-ROWS.
           IF KCI-ROW-COUNT = 0
               MOVE WS-M-NONE-FOUND TO ERRMSGO
           ELSE
               PERFORM VARYING WS-I FROM 1 BY 1
                       UNTIL WS-I > KCI-ROW-COUNT
                   PERFORM 4300-PLACE-ROW
               END-PERFORM
               PERFORM 4900-BUILD-MSG
           END-IF.
           PERFORM 4400-SHOW-TOTALS.
      *----------------------------------------------------------------*
      *  4100-CLEAR-ROWS  -  blank all thirteen display lines.         *
      *----------------------------------------------------------------*
       4100-CLEAR-ROWS.
           MOVE SPACES TO CNM1O  CAC1O  CNA1O  CEX1O  CST1O.
           MOVE SPACES TO CNM2O  CAC2O  CNA2O  CEX2O  CST2O.
           MOVE SPACES TO CNM3O  CAC3O  CNA3O  CEX3O  CST3O.
           MOVE SPACES TO CNM4O  CAC4O  CNA4O  CEX4O  CST4O.
           MOVE SPACES TO CNM5O  CAC5O  CNA5O  CEX5O  CST5O.
           MOVE SPACES TO CNM6O  CAC6O  CNA6O  CEX6O  CST6O.
           MOVE SPACES TO CNM7O  CAC7O  CNA7O  CEX7O  CST7O.
           MOVE SPACES TO CNM8O  CAC8O  CNA8O  CEX8O  CST8O.
           MOVE SPACES TO CNM9O  CAC9O  CNA9O  CEX9O  CST9O.
           MOVE SPACES TO CNM10O CAC10O CNA10O CEX10O CST10O.
           MOVE SPACES TO CNM11O CAC11O CNA11O CEX11O CST11O.
           MOVE SPACES TO CNM12O CAC12O CNA12O CEX12O CST12O.
           MOVE SPACES TO CNM13O CAC13O CNA13O CEX13O CST13O.
      *----------------------------------------------------------------*
      *  4300-PLACE-ROW  -  drop the current KCRDIN row onto the map   *
      *  line indicated by the row index.                             *
      *----------------------------------------------------------------*
       4300-PLACE-ROW.
           EVALUATE WS-I
               WHEN 1
                   MOVE KCI-R-NUM(1)    TO CNM1O
                   MOVE KCI-R-ACCT(1)   TO CAC1O
                   MOVE KCI-R-NAME(1)   TO CNA1O
                   MOVE KCI-R-EXPIRY(1) TO CEX1O
                   MOVE KCI-R-STATUS(1) TO CST1O
               WHEN 2
                   MOVE KCI-R-NUM(2)    TO CNM2O
                   MOVE KCI-R-ACCT(2)   TO CAC2O
                   MOVE KCI-R-NAME(2)   TO CNA2O
                   MOVE KCI-R-EXPIRY(2) TO CEX2O
                   MOVE KCI-R-STATUS(2) TO CST2O
               WHEN 3
                   MOVE KCI-R-NUM(3)    TO CNM3O
                   MOVE KCI-R-ACCT(3)   TO CAC3O
                   MOVE KCI-R-NAME(3)   TO CNA3O
                   MOVE KCI-R-EXPIRY(3) TO CEX3O
                   MOVE KCI-R-STATUS(3) TO CST3O
               WHEN 4
                   MOVE KCI-R-NUM(4)    TO CNM4O
                   MOVE KCI-R-ACCT(4)   TO CAC4O
                   MOVE KCI-R-NAME(4)   TO CNA4O
                   MOVE KCI-R-EXPIRY(4) TO CEX4O
                   MOVE KCI-R-STATUS(4) TO CST4O
               WHEN 5
                   MOVE KCI-R-NUM(5)    TO CNM5O
                   MOVE KCI-R-ACCT(5)   TO CAC5O
                   MOVE KCI-R-NAME(5)   TO CNA5O
                   MOVE KCI-R-EXPIRY(5) TO CEX5O
                   MOVE KCI-R-STATUS(5) TO CST5O
               WHEN 6
                   MOVE KCI-R-NUM(6)    TO CNM6O
                   MOVE KCI-R-ACCT(6)   TO CAC6O
                   MOVE KCI-R-NAME(6)   TO CNA6O
                   MOVE KCI-R-EXPIRY(6) TO CEX6O
                   MOVE KCI-R-STATUS(6) TO CST6O
               WHEN 7
                   MOVE KCI-R-NUM(7)    TO CNM7O
                   MOVE KCI-R-ACCT(7)   TO CAC7O
                   MOVE KCI-R-NAME(7)   TO CNA7O
                   MOVE KCI-R-EXPIRY(7) TO CEX7O
                   MOVE KCI-R-STATUS(7) TO CST7O
               WHEN 8
                   MOVE KCI-R-NUM(8)    TO CNM8O
                   MOVE KCI-R-ACCT(8)   TO CAC8O
                   MOVE KCI-R-NAME(8)   TO CNA8O
                   MOVE KCI-R-EXPIRY(8) TO CEX8O
                   MOVE KCI-R-STATUS(8) TO CST8O
               WHEN 9
                   MOVE KCI-R-NUM(9)    TO CNM9O
                   MOVE KCI-R-ACCT(9)   TO CAC9O
                   MOVE KCI-R-NAME(9)   TO CNA9O
                   MOVE KCI-R-EXPIRY(9) TO CEX9O
                   MOVE KCI-R-STATUS(9) TO CST9O
               WHEN 10
                   MOVE KCI-R-NUM(10)    TO CNM10O
                   MOVE KCI-R-ACCT(10)   TO CAC10O
                   MOVE KCI-R-NAME(10)   TO CNA10O
                   MOVE KCI-R-EXPIRY(10) TO CEX10O
                   MOVE KCI-R-STATUS(10) TO CST10O
               WHEN 11
                   MOVE KCI-R-NUM(11)    TO CNM11O
                   MOVE KCI-R-ACCT(11)   TO CAC11O
                   MOVE KCI-R-NAME(11)   TO CNA11O
                   MOVE KCI-R-EXPIRY(11) TO CEX11O
                   MOVE KCI-R-STATUS(11) TO CST11O
               WHEN 12
                   MOVE KCI-R-NUM(12)    TO CNM12O
                   MOVE KCI-R-ACCT(12)   TO CAC12O
                   MOVE KCI-R-NAME(12)   TO CNA12O
                   MOVE KCI-R-EXPIRY(12) TO CEX12O
                   MOVE KCI-R-STATUS(12) TO CST12O
               WHEN 13
                   MOVE KCI-R-NUM(13)    TO CNM13O
                   MOVE KCI-R-ACCT(13)   TO CAC13O
                   MOVE KCI-R-NAME(13)   TO CNA13O
                   MOVE KCI-R-EXPIRY(13) TO CEX13O
                   MOVE KCI-R-STATUS(13) TO CST13O
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4400-SHOW-TOTALS  -  page number and running active /         *
      *  inactive counts across the pages viewed.                      *
      *----------------------------------------------------------------*
       4400-SHOW-TOTALS.
           MOVE WS-ST-PAGE-NO TO WS-ED-PG.
           MOVE WS-ED-PG      TO PAGENOO.
           MOVE WS-ST-ACT     TO WS-ED-CNT.
           MOVE WS-ED-CNT     TO ACTCNTO.
           MOVE WS-ST-INA     TO WS-ED-CNT.
           MOVE WS-ED-CNT     TO INACNTO.
      *----------------------------------------------------------------*
      *  4900-BUILD-MSG  -  compose the result-count status line.      *
      *----------------------------------------------------------------*
       4900-BUILD-MSG.
           MOVE KCI-ROW-COUNT TO WS-CNT-ED.
           MOVE SPACES TO ERRMSGO.
           IF WS-ST-MORE = 'Y'
               STRING WS-CNT-ED DELIMITED BY SIZE
                      WS-M-MORE DELIMITED BY SIZE
                      INTO ERRMSGO
               END-STRING
           ELSE
               STRING WS-CNT-ED DELIMITED BY SIZE
                      WS-M-DONE DELIMITED BY SIZE
                      INTO ERRMSGO
               END-STRING
           END-IF.
      *----------------------------------------------------------------*
      *  6000-PARSE-FILTER  -  map the typed keyword to a filter code. *
      *  Leading three characters are enough; input is up-cased first. *
      *----------------------------------------------------------------*
       6000-PARSE-FILTER.
           SET WS-VALID TO TRUE.
           MOVE FILTI TO WS-FILT-IN.
           INSPECT WS-FILT-IN REPLACING ALL LOW-VALUE BY SPACE.
           INSPECT WS-FILT-IN
               CONVERTING
               'abcdefghijklmnopqrstuvwxyz'
               TO 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.
           EVALUATE TRUE
               WHEN WS-FILT-IN = SPACES
                   MOVE 'A' TO WS-ST-FILTER
               WHEN WS-FILT-IN(1:3) = 'ALL'
                   MOVE 'A' TO WS-ST-FILTER
               WHEN WS-FILT-IN(1:3) = 'ACT'
                   MOVE 'Y' TO WS-ST-FILTER
               WHEN WS-FILT-IN(1:3) = 'INA'
                   MOVE 'N' TO WS-ST-FILTER
               WHEN WS-FILT-IN(1:3) = 'EXP'
                   MOVE 'X' TO WS-ST-FILTER
               WHEN OTHER
                   SET WS-INVALID TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6100-SET-FDESC  -  filter code back to its display name.      *
      *----------------------------------------------------------------*
       6100-SET-FDESC.
           EVALUATE WS-ST-FILTER
               WHEN 'A' MOVE 'ALL'      TO WS-FDESC
               WHEN 'Y' MOVE 'ACTIVE'   TO WS-FDESC
               WHEN 'N' MOVE 'INACTIVE' TO WS-FDESC
               WHEN 'X' MOVE 'EXPIRING' TO WS-FDESC
               WHEN OTHER MOVE 'ALL'    TO WS-FDESC
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu.        *
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  persist state and re-transmit the map. *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           MOVE WS-STATE TO CA-WORK-AREA(1:40).
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MCRDINA')
                     MAPSET('MCRDIN')
                     FROM(MCRDINAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to CICS.         *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
