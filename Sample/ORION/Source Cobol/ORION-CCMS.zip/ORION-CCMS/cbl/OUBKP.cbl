      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)
      *  PROGRAM : OUBKP   -  Extract / backup transactions to a feed
      *  TYPE    : SUB  (CICS file control)
      *  FUNCTION: on-line port of batch OBTRANB.  Browse TRANFILE in
      *            key order, build a pipe-delimited flat backup record
      *            for each transaction and WRITE it to the backup feed
      *            (BKPFILE, keyed by transaction id).  Running total,
      *            credit and debit amounts plus record counts are
      *            returned in the KBKP block that is overlaid on the
      *            shared COMMAREA work area.
      *  CALL    : EXEC CICS LINK PROGRAM('OUBKP')
      *                COMMAREA(ORION-COMMAREA)
      *                LENGTH(LENGTH OF ORION-COMMAREA) END-EXEC.
      *  FILES   : TRANFILE browse, BKPFILE WRITE.
      *  RETURN  : ends with GOBACK (subroutine convention).
      *****************************************************************
      *  MAINTENANCE LOG
      *  ----  ----------  -------------------------------------
      *  0001  2026-08-07  Original - on-line transaction backup sub.
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUBKP.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and the backup feed name.                   *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUBKP'.
           05  WS-BKPFILE           PIC X(08) VALUE 'BKPFILE'.
      *----------------------------------------------------------------*
      *  Run-control switches.                                         *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-EOF-SW            PIC X(01) VALUE 'N'.
               88  WS-EOF-YES                 VALUE 'Y'.
               88  WS-EOF-NO                  VALUE 'N'.
           05  WS-BROWSE-SW         PIC X(01) VALUE 'N'.
               88  WS-BR-ON                   VALUE 'Y'.
               88  WS-BR-OFF                  VALUE 'N'.
           05  WS-CAPPED            PIC X(01) VALUE 'N'.
           05  WS-MAX               PIC 9(07) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Pipe-delimited backup / extract record built per transaction. *
      *----------------------------------------------------------------*
       01  BKP-REC.
           05  BK-TRAN-ID           PIC X(16).
           05  BK-BAR-1             PIC X(01) VALUE '|'.
           05  BK-TYPE              PIC X(02).
           05  BK-BAR-2             PIC X(01) VALUE '|'.
           05  BK-CAT               PIC 9(04).
           05  BK-BAR-3             PIC X(01) VALUE '|'.
           05  BK-CARD-NUM          PIC X(16).
           05  BK-BAR-4             PIC X(01) VALUE '|'.
           05  BK-AMT               PIC -,---,---,--9.99.
           05  BK-BAR-5             PIC X(01) VALUE '|'.
           05  BK-MERCH-ID          PIC 9(09).
           05  BK-BAR-6             PIC X(01) VALUE '|'.
           05  BK-ORIG-TS           PIC X(26).
           05  BK-BAR-7             PIC X(01) VALUE '|'.
           05  BK-DESC              PIC X(40).
      *----------------------------------------------------------------*
      *  Shared constants and the transaction record layout.          *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RTRAN.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KBKP.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  top level driver.                               *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KBK-PARM TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INIT.
           IF KBK-STATUS NOT = '99'
               PERFORM 2000-POSITION
               IF WS-BR-ON
                   PERFORM 3000-EXTRACT-LOOP
                      UNTIL WS-EOF-YES
                         OR WS-CAPPED = 'Y'
                   PERFORM 4000-PEEK-NEXT
                   PERFORM 5000-END-BROWSE
               END-IF
           END-IF.
           PERFORM 6000-SET-STATUS.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INIT  -  reset the result area.                          *
      *----------------------------------------------------------------*
       1000-INIT.
           SET WS-EOF-NO TO TRUE.
           SET WS-BR-OFF TO TRUE.
           MOVE 'N'    TO WS-CAPPED.
           MOVE '00'   TO KBK-STATUS.
           MOVE SPACES TO KBK-MSG.
           MOVE ZEROS  TO KBK-READ KBK-WRITTEN KBK-ERRORS.
           MOVE ZEROS  TO KBK-TOT-AMT KBK-CREDIT-AMT KBK-DEBIT-AMT.
           MOVE SPACES TO KBK-NEXT-KEY.
           MOVE 'N'    TO KBK-MORE.
           MOVE KBK-MAX TO WS-MAX.
      *----------------------------------------------------------------*
      *  2000-POSITION  -  open the transaction browse at resume key.
      *----------------------------------------------------------------*
       2000-POSITION.
           IF KBK-START-KEY = SPACES OR KBK-START-KEY = LOW-VALUES
               MOVE LOW-VALUES TO TR-ID
           ELSE
               MOVE KBK-START-KEY TO TR-ID
           END-IF.
           EXEC CICS STARTBR
                     FILE(WS-TRANFILE)
                     RIDFLD(TR-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-BR-ON TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET WS-EOF-YES TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   MOVE '99' TO KBK-STATUS
                   MOVE 'TRANFILE STARTBR FAILED' TO KBK-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3000-EXTRACT-LOOP  -  extract one transaction per iteration.  *
      *----------------------------------------------------------------*
       3000-EXTRACT-LOOP.
           PERFORM 3100-READ-TRAN.
           IF NOT WS-EOF-YES
               PERFORM 3200-EXTRACT-ONE
               IF WS-MAX > ZEROS AND KBK-READ >= WS-MAX
                   MOVE 'Y' TO WS-CAPPED
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3100-READ-TRAN  -  advance the transaction browse.            *
      *----------------------------------------------------------------*
       3100-READ-TRAN.
           EXEC CICS READNEXT
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   SET WS-EOF-YES TO TRUE
                   ADD 1 TO KBK-ERRORS
                   MOVE 'TRANFILE READNEXT FAILED' TO KBK-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-EXTRACT-ONE  -  build and write one backup record.       *
      *----------------------------------------------------------------*
       3200-EXTRACT-ONE.
           ADD 1 TO KBK-READ.
           PERFORM 3300-BUILD-BKP-REC.
           PERFORM 3400-WRITE-BKP-REC.
           PERFORM 3500-ACCUMULATE.
      *----------------------------------------------------------------*
      *  3300-BUILD-BKP-REC  -  map TR-* fields into the BK-* record.  *
      *----------------------------------------------------------------*
       3300-BUILD-BKP-REC.
           MOVE '|' TO BK-BAR-1 BK-BAR-2 BK-BAR-3 BK-BAR-4.
           MOVE '|' TO BK-BAR-5 BK-BAR-6 BK-BAR-7.
           MOVE TR-ID          TO BK-TRAN-ID.
           MOVE TR-TYPE-CD     TO BK-TYPE.
           MOVE TR-CAT-CD      TO BK-CAT.
           MOVE TR-CARD-NUM    TO BK-CARD-NUM.
           MOVE TR-AMT         TO BK-AMT.
           MOVE TR-MERCHANT-ID TO BK-MERCH-ID.
           MOVE TR-ORIG-TS     TO BK-ORIG-TS.
           MOVE TR-DESC        TO BK-DESC.
      *----------------------------------------------------------------*
      *  3400-WRITE-BKP-REC  -  write the backup record, check status.
      *----------------------------------------------------------------*
       3400-WRITE-BKP-REC.
           EXEC CICS WRITE
                     FILE(WS-BKPFILE)
                     FROM(BKP-REC)
                     RIDFLD(BK-TRAN-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KBK-WRITTEN
               WHEN DFHRESP(DUPREC)
                   ADD 1 TO KBK-ERRORS
               WHEN OTHER
                   ADD 1 TO KBK-ERRORS
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3500-ACCUMULATE  -  running grand total plus credit / debit.
      *----------------------------------------------------------------*
       3500-ACCUMULATE.
           ADD TR-AMT TO KBK-TOT-AMT.
           IF TR-AMT < ZERO
               ADD TR-AMT TO KBK-DEBIT-AMT
           ELSE
               ADD TR-AMT TO KBK-CREDIT-AMT
           END-IF.
      *----------------------------------------------------------------*
      *  4000-PEEK-NEXT  -  publish the resume key when the cap stopped
      *  the run short of end-of-file.                                 *
      *----------------------------------------------------------------*
       4000-PEEK-NEXT.
           IF WS-EOF-YES
               MOVE 'N' TO KBK-MORE
               GO TO 4000-EXIT
           END-IF.
           EXEC CICS READNEXT
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE 'Y'   TO KBK-MORE
                   MOVE TR-ID TO KBK-NEXT-KEY
               WHEN DFHRESP(ENDFILE)
                   MOVE 'N' TO KBK-MORE
               WHEN OTHER
                   MOVE 'N' TO KBK-MORE
                   ADD 1 TO KBK-ERRORS
           END-EVALUATE.
       4000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5000-END-BROWSE  -  release the transaction browse position.
      *----------------------------------------------------------------*
       5000-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-TRANFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  6000-SET-STATUS  -  publish the completion status and message.
      *----------------------------------------------------------------*
       6000-SET-STATUS.
           IF KBK-STATUS = '99'
               GO TO 6000-EXIT
           END-IF.
           IF KBK-READ = ZEROS
               MOVE '10' TO KBK-STATUS
               MOVE 'NO TRANSACTIONS EXTRACTED' TO KBK-MSG
           ELSE
               MOVE '00' TO KBK-STATUS
               MOVE 'TRANSACTION BACKUP COMPLETE' TO KBK-MSG
           END-IF.
       6000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *                   E N D   O F   O U B K P                      *
      *----------------------------------------------------------------*
