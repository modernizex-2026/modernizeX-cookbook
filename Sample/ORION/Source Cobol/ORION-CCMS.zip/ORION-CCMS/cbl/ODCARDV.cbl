      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : ODCARDV  -  Card View (on-line, DB2)              *
      *  TYPE    : CICS ONLINE + DB2  (pseudo-conversational)        *
      *  FUNCTION: accept a card number, SELECT the card row from    *
      *            the CARD table (ORION.CARD) via EXEC SQL and      *
      *            display the card details on map MCARDV.           *
      *            PF3 = back to menu, PF4 = clear, ENTER = read.    *
      *  NOTE    : DB2 variant of the OCCARDV online program.        *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. ODCARDV.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'ODCARDV'.
           05  WS-TRANID            PIC X(04) VALUE 'OD03'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  DB2 communication area.                                       *
      *----------------------------------------------------------------*
           EXEC SQL INCLUDE SQLCA END-EXEC.
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RCARD.
       COPY MCARDV.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MCARDVAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter card number and press ENTER.' TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MCARDVA')
                     MAPSET('MCARDV')
                     FROM(MCARDVAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-READ-AND-SHOW
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
       2100-READ-AND-SHOW.
           EXEC CICS RECEIVE
                     MAP('MCARDVA')
                     MAPSET('MCARDV')
                     INTO(MCARDVAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF CARDNUMI = SPACES OR CARDNUMI = LOW-VALUES
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE CARDNUMI TO CD-NUM
               MOVE CD-NUM   TO CA-CARD-NUM
               PERFORM 3000-READ-CARD
               IF REC-FOUND
                   PERFORM 4000-POPULATE-DETAIL
                   MOVE 'Card displayed.' TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE WS-MSG-NOTFND TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  DB2 read : SELECT the card row by primary key CD_NUM.         *
      *----------------------------------------------------------------*
       3000-READ-CARD.
           SET REC-NOT-FOUND TO TRUE.
           EXEC SQL
                SELECT CD_ACCT_ID,
                       CD_EMBOSSED_NAME,
                       CD_EXPIRY_DATE,
                       CD_ACTIVE_STATUS
                  INTO :CD-ACCT-ID,
                       :CD-EMBOSSED-NAME,
                       :CD-EXPIRY-DATE,
                       :CD-ACTIVE-STATUS
                  FROM ORION.CARD
                 WHERE CD_NUM = :CD-NUM
           END-EXEC.
           EVALUATE SQLCODE
               WHEN 0
                   SET REC-FOUND TO TRUE
               WHEN 100
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   MOVE 'Error reading card table.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE CD-NUM            TO CARDNUMO.
           MOVE CD-ACCT-ID        TO CDACCTO.
           MOVE CD-EMBOSSED-NAME  TO CDNAMEO.
           MOVE CD-EXPIRY-DATE    TO CDEXPO.
           MOVE CD-ACTIVE-STATUS  TO CDSTATO.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MCARDVA')
                     MAPSET('MCARDV')
                     FROM(MCARDVAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
