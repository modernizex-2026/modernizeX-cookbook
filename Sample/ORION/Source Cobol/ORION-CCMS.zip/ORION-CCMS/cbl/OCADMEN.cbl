      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCADMEN  -  Administrator Menu (on-line)          *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: present the user-administration menu (admin users  *
      *            only) and XCTL to the chosen user maintenance      *
      *            function.  Option 1 = list, 2 = add, 3 = update,   *
      *            4 = delete.  PF3 = sign off (back to OCSGNON).     *
      *  MAP     : MADMENA of mapset MADMEN.                         *
      *  TRANID  : ORAD.                                             *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCADMEN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identification and dispatch constants.               *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCADMEN'.
           05  WS-TRANID            PIC X(04) VALUE 'ORAD'.
           05  WS-SGNON-PGM         PIC X(08) VALUE 'OCSGNON'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
           05  WS-XCTL-PGM          PIC X(08) VALUE SPACES.
           05  WS-OPTION            PIC 9(02) VALUE ZEROS.
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY MADMEN.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN : pseudo-conversational entry point.  Guard the     *
      *  menu against non-administrator users.                         *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           IF EIBCALEN = 0
               EXEC CICS XCTL
                         PROGRAM(WS-SGNON-PGM)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
           MOVE DFHCOMMAREA TO ORION-COMMAREA.
           MOVE SPACES      TO CA-ERR-MSG.
           IF NOT CA-USER-ADMIN
               PERFORM 7100-XCTL-MENU
           ELSE
               IF CA-FIRST-ENTER
                   PERFORM 1000-SEND-INITIAL
               ELSE
                   PERFORM 2000-PROCESS-INPUT
               END-IF
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL : paint the administrator menu.             *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MADMENAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Select an option (1-4) and press ENTER.'
               TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MADMENA')
                     MAPSET('MADMEN')
                     FROM(MADMENAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT : dispatch on the AID key.                 *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-SIGN-OFF
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-DISPATCH
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-DISPATCH : receive the chosen option and select the      *
      *  target user-maintenance program.                             *
      *----------------------------------------------------------------*
       2100-DISPATCH.
           PERFORM 2110-RECEIVE-MAP.
           IF OPTIONI NUMERIC
               MOVE OPTIONI TO WS-OPTION
           ELSE
               MOVE 0 TO WS-OPTION
           END-IF.
           EVALUATE WS-OPTION
               WHEN 1
                   MOVE 'OCUSRL' TO WS-XCTL-PGM
               WHEN 2
                   MOVE 'OCUSRA' TO WS-XCTL-PGM
               WHEN 3
                   MOVE 'OCUSRU' TO WS-XCTL-PGM
               WHEN 4
                   MOVE 'OCUSRD' TO WS-XCTL-PGM
               WHEN OTHER
                   MOVE SPACES TO WS-XCTL-PGM
           END-EVALUATE.
           IF WS-XCTL-PGM = SPACES
               PERFORM 1000-SEND-INITIAL
               MOVE 'Invalid option. Choose 1 through 4.'
                   TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 2200-XCTL-FUNCTION
           END-IF.
      *----------------------------------------------------------------*
      *  2110-RECEIVE-MAP : read the option selection into MADMENAI.   *
      *----------------------------------------------------------------*
       2110-RECEIVE-MAP.
           EXEC CICS RECEIVE
                     MAP('MADMENA')
                     MAPSET('MADMEN')
                     INTO(MADMENAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  2200-XCTL-FUNCTION : transfer control to the chosen program.  *
      *----------------------------------------------------------------*
       2200-XCTL-FUNCTION.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-XCTL-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  7000-SIGN-OFF : PF3 returns to the sign-on program.          *
      *----------------------------------------------------------------*
       7000-SIGN-OFF.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-SGNON-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  7100-XCTL-MENU : send a non-administrator back to the main    *
      *  menu instead of the administrator menu.                       *
      *----------------------------------------------------------------*
       7100-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER : fill the standard screen header.       *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY : resend the map without erasing.          *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MADMENA')
                     MAPSET('MADMEN')
                     FROM(MADMENAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME : obtain the current date and time.        *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN : return pseudo-conversationally.                 *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
