      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCUSRL   -  User List (on-line)                  *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: browse the user security file (USRSEC) and display *
      *            up to four users per screen with STARTBR /         *
      *            READNEXT / ENDBR.  PF8 pages forward, PF7 restarts *
      *            at the top, PF3 returns to the administrator menu.  *
      *  MAP     : MUSRLA of mapset MUSRL.                           *
      *  TRANID  : ORUL.                                            *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCUSRL.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identification constants.                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCUSRL'.
           05  WS-TRANID            PIC X(04) VALUE 'ORUL'.
           05  WS-ADMEN-PGM         PIC X(08) VALUE 'OCADMEN'.
      *----------------------------------------------------------------*
      *  Pseudo-conversational state : the key of the last user shown  *
      *  on the current page, used to page forward.                    *
      *----------------------------------------------------------------*
       01  WS-STATE-AREA.
           05  WS-LAST-KEY          PIC X(08) VALUE LOW-VALUES.
           05  FILLER               PIC X(504) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Browse work fields.                                           *
      *----------------------------------------------------------------*
       01  WS-BROWSE-WORK.
           05  WS-START-KEY         PIC X(08) VALUE LOW-VALUES.
           05  WS-SKIP-FIRST        PIC X(01) VALUE 'N'.
               88  SKIP-FIRST-ON             VALUE 'Y'.
               88  SKIP-FIRST-OFF            VALUE 'N'.
           05  WS-ROW-IDX           PIC 9(02) VALUE ZEROS.
           05  WS-ROW-COUNT         PIC 9(02) VALUE ZEROS.
           05  WS-FULLNAME          PIC X(25) VALUE SPACES.
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RUSER.
       COPY MUSRL.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN : pseudo-conversational entry point.                *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               MOVE CA-WORK-AREA TO WS-STATE-AREA
               MOVE SPACES       TO CA-ERR-MSG
               IF CA-FIRST-ENTER
                   PERFORM 1000-SEND-INITIAL
               ELSE
                   PERFORM 2000-PROCESS-INPUT
               END-IF
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL : list the first page of users.             *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MUSRLAO.
           MOVE LOW-VALUES TO WS-START-KEY.
           SET SKIP-FIRST-OFF TO TRUE.
           PERFORM 2200-LIST-PAGE.
           PERFORM 8000-POPULATE-HEADER.
           IF WS-ROW-COUNT = 0
               MOVE 'No users found.' TO ERRMSGO
           ELSE
               MOVE 'PF8 next page  PF7 top  PF3 exit.' TO ERRMSGO
           END-IF.
           EXEC CICS SEND
                     MAP('MUSRLA')
                     MAPSET('MUSRL')
                     FROM(MUSRLAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT : dispatch on the AID key.                 *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-ADMEN
               WHEN DFHPF7
                   PERFORM 2100-PAGE-TOP
               WHEN DFHPF8
                   PERFORM 2150-PAGE-NEXT
               WHEN DFHENTER
                   PERFORM 2100-PAGE-TOP
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-PAGE-TOP : list from the beginning of the file.          *
      *----------------------------------------------------------------*
       2100-PAGE-TOP.
           MOVE LOW-VALUES TO MUSRLAO.
           MOVE LOW-VALUES TO WS-START-KEY.
           SET SKIP-FIRST-OFF TO TRUE.
           PERFORM 2200-LIST-PAGE.
           IF WS-ROW-COUNT = 0
               MOVE 'No users found.' TO ERRMSGO
           ELSE
               MOVE 'Top of list. PF8 next page.' TO ERRMSGO
           END-IF.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  2150-PAGE-NEXT : list the page after the last key shown.      *
      *----------------------------------------------------------------*
       2150-PAGE-NEXT.
           MOVE LOW-VALUES TO MUSRLAO.
           MOVE WS-LAST-KEY TO WS-START-KEY.
           SET SKIP-FIRST-ON TO TRUE.
           PERFORM 2200-LIST-PAGE.
           IF WS-ROW-COUNT = 0
               MOVE 'No more users to display.' TO ERRMSGO
           ELSE
               MOVE 'PF8 next page  PF7 top  PF3 exit.' TO ERRMSGO
           END-IF.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  2200-LIST-PAGE : STARTBR at the start key, optionally skip the*
      *  repositioning record, then read up to four users into the     *
      *  four display rows and end the browse.                         *
      *----------------------------------------------------------------*
       2200-LIST-PAGE.
           PERFORM 2210-CLEAR-ROWS.
           MOVE ZEROS TO WS-ROW-COUNT.
           MOVE 'N'   TO WS-END-FLG.
           MOVE WS-START-KEY TO US-ID.
           PERFORM 2220-STARTBR.
           IF ERR-FLG-ON OR END-OF-FILE
               GO TO 2200-EXIT
           END-IF.
           IF SKIP-FIRST-ON
               PERFORM 2230-SKIP-ONE
           END-IF.
           PERFORM VARYING WS-ROW-IDX FROM 1 BY 1
               UNTIL WS-ROW-IDX > 4 OR END-OF-FILE
               PERFORM 2240-READ-NEXT
               IF REC-FOUND
                   PERFORM 2250-STORE-ROW
               END-IF
           END-PERFORM.
           PERFORM 2260-ENDBR.
       2200-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2210-CLEAR-ROWS : blank the four display rows.                *
      *----------------------------------------------------------------*
       2210-CLEAR-ROWS.
           MOVE SPACES TO USR1O.
           MOVE SPACES TO UNM1O.
           MOVE SPACES TO UTY1O.
           MOVE SPACES TO USR2O.
           MOVE SPACES TO UNM2O.
           MOVE SPACES TO UTY2O.
           MOVE SPACES TO USR3O.
           MOVE SPACES TO UNM3O.
           MOVE SPACES TO UTY3O.
           MOVE SPACES TO USR4O.
           MOVE SPACES TO UNM4O.
           MOVE SPACES TO UTY4O.
      *----------------------------------------------------------------*
      *  2220-STARTBR : position the browse at the start key.          *
      *----------------------------------------------------------------*
       2220-STARTBR.
           SET ERR-FLG-OFF TO TRUE.
           EXEC CICS STARTBR
                     FILE(WS-USRSEC)
                     RIDFLD(US-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(NOTFND)
                   MOVE 'Y' TO WS-END-FLG
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error starting user browse.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2230-SKIP-ONE : consume the repositioning record when paging  *
      *  forward so the same user is not shown twice.                  *
      *----------------------------------------------------------------*
       2230-SKIP-ONE.
           EXEC CICS READNEXT
                     FILE(WS-USRSEC)
                     INTO(USER-REC)
                     RIDFLD(US-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(ENDFILE)
               MOVE 'Y' TO WS-END-FLG
           END-IF.
      *----------------------------------------------------------------*
      *  2240-READ-NEXT : read the next user record.                   *
      *----------------------------------------------------------------*
       2240-READ-NEXT.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READNEXT
                     FILE(WS-USRSEC)
                     INTO(USER-REC)
                     RIDFLD(US-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(ENDFILE)
                   MOVE 'Y' TO WS-END-FLG
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error reading user file.' TO ERRMSGO
                   MOVE 'Y' TO WS-END-FLG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2250-STORE-ROW : place the current user into the row matching *
      *  the loop index and remember the key for paging.              *
      *----------------------------------------------------------------*
       2250-STORE-ROW.
           PERFORM 2255-BUILD-NAME.
           ADD 1 TO WS-ROW-COUNT.
           MOVE US-ID TO WS-LAST-KEY.
           EVALUATE WS-ROW-IDX
               WHEN 1
                   MOVE US-ID       TO USR1O
                   MOVE WS-FULLNAME TO UNM1O
                   MOVE US-TYPE     TO UTY1O
               WHEN 2
                   MOVE US-ID       TO USR2O
                   MOVE WS-FULLNAME TO UNM2O
                   MOVE US-TYPE     TO UTY2O
               WHEN 3
                   MOVE US-ID       TO USR3O
                   MOVE WS-FULLNAME TO UNM3O
                   MOVE US-TYPE     TO UTY3O
               WHEN 4
                   MOVE US-ID       TO USR4O
                   MOVE WS-FULLNAME TO UNM4O
                   MOVE US-TYPE     TO UTY4O
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2255-BUILD-NAME : combine first and last name into 25 chars.  *
      *----------------------------------------------------------------*
       2255-BUILD-NAME.
           MOVE SPACES TO WS-FULLNAME.
           STRING US-FIRST-NAME DELIMITED BY SPACE
                  ' '           DELIMITED BY SIZE
                  US-LAST-NAME  DELIMITED BY SPACE
                  INTO WS-FULLNAME
           END-STRING.
      *----------------------------------------------------------------*
      *  2260-ENDBR : terminate the user browse.                       *
      *----------------------------------------------------------------*
       2260-ENDBR.
           EXEC CICS ENDBR
                     FILE(WS-USRSEC)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  7000-XCTL-ADMEN : return to the administrator menu.           *
      *----------------------------------------------------------------*
       7000-XCTL-ADMEN.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           MOVE WS-STATE-AREA TO CA-WORK-AREA.
           EXEC CICS XCTL
                     PROGRAM(WS-ADMEN-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER : fill the standard screen header.       *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY : resend the map without erasing.          *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MUSRLA')
                     MAPSET('MUSRL')
                     FROM(MUSRLAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME : obtain the current date and time.        *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN : save state and return pseudo-conversationally.  *
      *----------------------------------------------------------------*
       9000-RETURN.
           MOVE WS-STATE-AREA TO CA-WORK-AREA.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
