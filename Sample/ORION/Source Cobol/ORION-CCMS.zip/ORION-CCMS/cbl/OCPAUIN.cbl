      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCPAUIN -  Pending Authorization Inquiry (online) *
      *  TYPE    : ONLINE CICS + IMS  (pseudo-conversational)        *
      *  FUNCTION: accept an authorization id, LINK to sub OUIMSPA   *
      *            which reads the PAUSEG segment from IMS database  *
      *            OPAUDB via DL/I, and display the pending auth.    *
      *            ENTER = inquire by id, PF8 = browse next id,      *
      *            PF3   = back to menu, PF4 = clear the screen.     *
      *  MAPSET  : MPAUIN   MAP : MPAUINA   TRAN : ORPI              *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCPAUIN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCPAUIN'.
           05  WS-TRANID            PIC X(04) VALUE 'ORPI'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
           05  WS-SUB-PGM           PIC X(08) VALUE 'OUIMSPA'.
           05  WS-STATUS-WORD       PIC X(12) VALUE SPACES.
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RPAUSEG.
       COPY MPAUIN.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
      *  Work-area protocol passed to / from the DL/I sub OUIMSPA in   *
      *  the KCOMM CA-WORK-AREA.  Layout must match OUIMSPA exactly.   *
      *----------------------------------------------------------------*
       01  WS-PAU-LINK.
           05  WS-PL-FUNC           PIC X(04).
               88  PL-INQUIRE                 VALUE 'INQ '.
               88  PL-BROWSE-NEXT             VALUE 'NXT '.
               88  PL-INSERT                  VALUE 'ADD '.
               88  PL-UPDATE                  VALUE 'UPD '.
               88  PL-DELETE                  VALUE 'DEL '.
           05  WS-PL-KEY            PIC X(16).
           05  WS-PL-STATUS         PIC X(02).
               88  PL-OK                      VALUE '  '.
               88  PL-NOTFOUND                VALUE 'GE'.
               88  PL-ENDLIST                 VALUE 'GB'.
               88  PL-DUPLICATE               VALUE 'II'.
               88  PL-BADFUNC                 VALUE 'BF'.
               88  PL-ERROR                   VALUE 'ER'.
           05  WS-PL-MSG            PIC X(40).
           05  WS-PL-DLI-STAT       PIC X(02).
           05  WS-PL-SEGMENT        PIC X(200).
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MPAUINAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter an authorization id and press ENTER.'
               TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MPAUINA')
                     MAPSET('MPAUIN')
                     FROM(MPAUINAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHPF8
                   PERFORM 2200-BROWSE-NEXT
               WHEN DFHENTER
                   PERFORM 2100-INQUIRE
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100 - ENTER : inquire one pending authorization by its id.   *
      *----------------------------------------------------------------*
       2100-INQUIRE.
           EXEC CICS RECEIVE
                     MAP('MPAUINA')
                     MAPSET('MPAUIN')
                     INTO(MPAUINAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF AUTHIDI = SPACES OR AUTHIDI = LOW-VALUES
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE SPACES  TO WS-PAU-LINK
               MOVE AUTHIDI TO WS-PL-KEY
               MOVE AUTHIDI TO CA-TRAN-ID
               SET PL-INQUIRE TO TRUE
               PERFORM 3000-CALL-SUB
               IF PL-OK
                   PERFORM 4000-POPULATE-DETAIL
                   MOVE WS-PL-MSG TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE CA-ERR-MSG TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2200 - PF8 : browse the next pending authorization.  The id   *
      *  currently on the screen is used as the "greater than" key.    *
      *----------------------------------------------------------------*
       2200-BROWSE-NEXT.
           EXEC CICS RECEIVE
                     MAP('MPAUINA')
                     MAPSET('MPAUIN')
                     INTO(MPAUINAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE SPACES  TO WS-PAU-LINK.
           MOVE AUTHIDI TO WS-PL-KEY.
           SET PL-BROWSE-NEXT TO TRUE.
           PERFORM 3000-CALL-SUB.
           IF PL-OK
               PERFORM 4000-POPULATE-DETAIL
               MOVE WS-PL-KEY TO AUTHIDO
               MOVE WS-PL-MSG TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE CA-ERR-MSG TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  3000 - LINK to the DL/I access sub, passing the commarea.     *
      *----------------------------------------------------------------*
       3000-CALL-SUB.
           MOVE WS-PAU-LINK TO CA-WORK-AREA.
           MOVE WS-PGMNAME  TO CA-FROM-PROGRAM.
           MOVE WS-SUB-PGM  TO CA-TO-PROGRAM.
           EXEC CICS LINK
                     PROGRAM(WS-SUB-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE CA-WORK-AREA TO WS-PAU-LINK.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               MOVE 'Unable to link to IMS module OUIMSPA.'
                   TO CA-ERR-MSG
               MOVE 'ER' TO WS-PL-STATUS
           END-IF.
      *----------------------------------------------------------------*
      *  4000 - break the returned segment out onto the map fields.    *
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE WS-PL-SEGMENT   TO PAUSEG-REC.
           MOVE PA-AUTH-ID      TO AUTHIDO.
           MOVE PA-CARD-NUM     TO PACARDO.
           MOVE PA-ACCT-ID      TO PAACCTO.
           MOVE PA-AMOUNT       TO WS-ED-AMT.
           MOVE WS-ED-AMT       TO PAAMTO.
           MOVE PA-MERCHANT     TO PAMERCHO.
           MOVE PA-REQUEST-TS   TO PAREQTSO.
           PERFORM 4100-STATUS-WORD.
           MOVE WS-STATUS-WORD  TO PASTATO.
           MOVE PA-DEC-REASON   TO PADECO.
      *----------------------------------------------------------------*
      *  4100 - translate the one-byte status code to a display word.  *
      *----------------------------------------------------------------*
       4100-STATUS-WORD.
           EVALUATE PA-STATUS
               WHEN 'P'
                   MOVE 'PENDING'  TO WS-STATUS-WORD
               WHEN 'A'
                   MOVE 'APPROVED' TO WS-STATUS-WORD
               WHEN 'D'
                   MOVE 'DECLINED' TO WS-STATUS-WORD
               WHEN 'X'
                   MOVE 'PURGED'   TO WS-STATUS-WORD
               WHEN OTHER
                   MOVE 'UNKNOWN'  TO WS-STATUS-WORD
           END-EVALUATE.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MPAUINA')
                     MAPSET('MPAUIN')
                     FROM(MPAUINAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
