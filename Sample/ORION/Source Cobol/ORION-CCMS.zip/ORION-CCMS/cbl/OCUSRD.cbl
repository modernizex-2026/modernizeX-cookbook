      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCUSRD   -  User Delete (on-line)                *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: accept a user id, read the user security record    *
      *            (USRSEC) and display the user name, require a Y     *
      *            confirmation, then DELETE the record.             *
      *  MAP     : MUSRDA of mapset MUSRD.                           *
      *  TRANID  : ORUD.  PF3 = admin menu, PF4 = clear.            *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCUSRD.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identification constants.                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCUSRD'.
           05  WS-TRANID            PIC X(04) VALUE 'ORUD'.
           05  WS-ADMEN-PGM         PIC X(08) VALUE 'OCADMEN'.
      *----------------------------------------------------------------*
      *  Pseudo-conversational state : which step of the dialogue we   *
      *  are in, plus the id of the user being deleted.               *
      *----------------------------------------------------------------*
       01  WS-STATE-AREA.
           05  WS-STAGE             PIC X(01) VALUE '0'.
               88  STAGE-NEED-ID             VALUE '0'.
               88  STAGE-NEED-CONF           VALUE '1'.
           05  WS-SV-USERID         PIC X(08) VALUE SPACES.
           05  FILLER               PIC X(503) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Work fields.                                                  *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-FULLNAME          PIC X(40) VALUE SPACES.
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RUSER.
       COPY MUSRD.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN : pseudo-conversational entry point.                *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               MOVE CA-WORK-AREA TO WS-STATE-AREA
               MOVE SPACES       TO CA-ERR-MSG
               IF CA-FIRST-ENTER
                   PERFORM 1000-SEND-INITIAL
               ELSE
                   PERFORM 2000-PROCESS-INPUT
               END-IF
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL : prompt for the user id to delete.         *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MUSRDAO.
           SET STAGE-NEED-ID TO TRUE.
           MOVE SPACES TO WS-SV-USERID.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter a user id and press ENTER.' TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MUSRDA')
                     MAPSET('MUSRD')
                     FROM(MUSRDAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT : dispatch on the AID key.                 *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-ADMEN
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-HANDLE-ENTER
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-HANDLE-ENTER : act on the current dialogue stage.        *
      *----------------------------------------------------------------*
       2100-HANDLE-ENTER.
           PERFORM 2110-RECEIVE-MAP.
           EVALUATE TRUE
               WHEN STAGE-NEED-ID
                   PERFORM 2200-FETCH-USER
               WHEN STAGE-NEED-CONF
                   PERFORM 2300-CONFIRM-DELETE
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2110-RECEIVE-MAP : read whatever the operator entered.        *
      *----------------------------------------------------------------*
       2110-RECEIVE-MAP.
           EXEC CICS RECEIVE
                     MAP('MUSRDA')
                     MAPSET('MUSRD')
                     INTO(MUSRDAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  2200-FETCH-USER : stage 1.  Read the user and display the     *
      *  name, then ask for confirmation.                            *
      *----------------------------------------------------------------*
       2200-FETCH-USER.
           IF USERIDI = SPACES OR USERIDI = LOW-VALUES
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE USERIDI TO US-ID
               PERFORM 3000-READ-USER
               IF REC-FOUND
                   PERFORM 2210-SHOW-USER
               ELSE
                   MOVE 'User not found.' TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2210-SHOW-USER : populate the id and name and remember the id.*
      *----------------------------------------------------------------*
       2210-SHOW-USER.
           MOVE US-ID TO WS-SV-USERID.
           MOVE US-ID TO USERIDO.
           PERFORM 2220-BUILD-NAME.
           MOVE WS-FULLNAME TO USNAMEO.
           MOVE SPACES      TO USCONFO.
           SET STAGE-NEED-CONF TO TRUE.
           MOVE 'Type Y and press ENTER to delete this user.'
               TO ERRMSGO.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  2220-BUILD-NAME : combine first and last name into 40 chars.  *
      *----------------------------------------------------------------*
       2220-BUILD-NAME.
           MOVE SPACES TO WS-FULLNAME.
           STRING US-FIRST-NAME DELIMITED BY SPACE
                  ' '           DELIMITED BY SIZE
                  US-LAST-NAME  DELIMITED BY SPACE
                  INTO WS-FULLNAME
           END-STRING.
      *----------------------------------------------------------------*
      *  2300-CONFIRM-DELETE : stage 2.  A Y confirmation deletes the  *
      *  record; anything else cancels the request.                   *
      *----------------------------------------------------------------*
       2300-CONFIRM-DELETE.
           IF USCONFI = 'Y' OR USCONFI = 'y'
               PERFORM 3100-DELETE-USER
               IF ERR-FLG-ON
                   PERFORM 2310-REDISPLAY
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   PERFORM 4100-CONFIRM-DONE
               END-IF
           ELSE
               PERFORM 4200-CANCELLED
           END-IF.
      *----------------------------------------------------------------*
      *  2310-REDISPLAY : keep the id and name on screen after a failed*
      *  delete attempt.                                             *
      *----------------------------------------------------------------*
       2310-REDISPLAY.
           MOVE WS-SV-USERID TO USERIDO.
           MOVE WS-FULLNAME  TO USNAMEO.
      *----------------------------------------------------------------*
      *  3000-READ-USER : simple read of the user record.             *
      *----------------------------------------------------------------*
       3000-READ-USER.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-USRSEC)
                     INTO(USER-REC)
                     RIDFLD(US-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error reading user file.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3100-DELETE-USER : delete the user record by key.            *
      *----------------------------------------------------------------*
       3100-DELETE-USER.
           SET ERR-FLG-OFF TO TRUE.
           MOVE WS-SV-USERID TO US-ID.
           EXEC CICS DELETE
                     FILE(WS-USRSEC)
                     RIDFLD(US-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(NOTFND)
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'User no longer exists.' TO ERRMSGO
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error deleting user file.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4100-CONFIRM-DONE : report a successful delete and reset.     *
      *----------------------------------------------------------------*
       4100-CONFIRM-DONE.
           MOVE LOW-VALUES TO MUSRDAO.
           SET STAGE-NEED-ID TO TRUE.
           MOVE SPACES TO WS-SV-USERID.
           MOVE 'User deleted successfully.' TO ERRMSGO.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  4200-CANCELLED : the operator did not confirm; reset dialogue.*
      *----------------------------------------------------------------*
       4200-CANCELLED.
           MOVE LOW-VALUES TO MUSRDAO.
           SET STAGE-NEED-ID TO TRUE.
           MOVE SPACES TO WS-SV-USERID.
           MOVE 'Delete cancelled.' TO ERRMSGO.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  7000-XCTL-ADMEN : return to the administrator menu.           *
      *----------------------------------------------------------------*
       7000-XCTL-ADMEN.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           MOVE WS-STATE-AREA TO CA-WORK-AREA.
           EXEC CICS XCTL
                     PROGRAM(WS-ADMEN-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER : fill the standard screen header.       *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY : resend the map without erasing.          *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MUSRDA')
                     MAPSET('MUSRD')
                     FROM(MUSRDAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME : obtain the current date and time.        *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN : save state and return pseudo-conversationally.  *
      *----------------------------------------------------------------*
       9000-RETURN.
           MOVE WS-STATE-AREA TO CA-WORK-AREA.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
