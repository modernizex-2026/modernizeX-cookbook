      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCTRANL  -  Transaction List (on-line)           *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: accept a card number and list the first five      *
      *            transactions recorded against it.  The TRANFILE   *
      *            is browsed sequentially and the records whose card *
      *            number matches are shown with amount and type.     *
      *            PF3 = back to menu, PF4 = clear, ENTER = list.     *
      *  MAPSET  : MTRANL      MAP : MTRANLA     TRANID : ORTL        *
      *  FILES   : TRANFILE (browse - STARTBR / READNEXT / ENDBR)    *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.       *
      *****************************************************************
      *  MAINTENANCE LOG                                              *
      *  ----  ----------  --------------------------------------     *
      *  0001  2026-08-07  Original - transaction list by card.       *
      *****************************************************************
      *  PROCESSING NARRATIVE                                         *
      *  1. The operator keys a card number and presses ENTER.        *
      *  2. TRANFILE is opened for browse from the start of file and  *
      *     read forward.  Each record whose TR-CARD-NUM equals the   *
      *     requested card is moved into the next available display   *
      *     line (up to a maximum of five).                           *
      *  3. The browse ends when five matches have been collected or  *
      *     end-of-file is reached.  A summary count is shown.        *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCTRANL.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identification and navigation constants               *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCTRANL'.
           05  WS-TRANID            PIC X(04) VALUE 'ORTL'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Browse control and work fields
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-CARD-KEY          PIC X(16) VALUE SPACES.
           05  WS-ROW-CNT           PIC 9(01) VALUE ZEROS.
           05  WS-MAX-ROWS          PIC 9(01) VALUE 5.
           05  WS-BROWSE-STARTED    PIC X(01) VALUE 'N'.
               88  WS-BR-ON                   VALUE 'Y'.
               88  WS-BR-OFF                  VALUE 'N'.
           05  WS-CNT-ED            PIC Z9.
      *----------------------------------------------------------------*
      *  Program specific operator messages                            *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter a card number and press ENTER.'.
           05  WS-M-CARD-REQ        PIC X(50)
               VALUE 'Card number is required.'.
           05  WS-M-NONE-FOUND      PIC X(50)
               VALUE 'No transactions found for that card.'.
           05  WS-M-BROWSE-ERR      PIC X(50)
               VALUE 'Error browsing the transaction file.'.
           05  WS-M-SUFFIX          PIC X(30)
               VALUE ' transaction(s) displayed.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea      *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  File record layout and BMS symbolic map                       *
      *----------------------------------------------------------------*
       COPY RTRAN.
       COPY MTRANL.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants             *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh empty screen.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MTRANLAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO CARDNUML.
           EXEC CICS SEND
                     MAP('MTRANLA')
                     MAPSET('MTRANL')
                     FROM(MTRANLAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-LIST-TRANS
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-LIST-TRANS  -  receive the card number, validate it and
      *  drive the browse.  A summary message is produced afterwards.
      *----------------------------------------------------------------*
       2100-LIST-TRANS.
           EXEC CICS RECEIVE
                     MAP('MTRANLA')
                     MAPSET('MTRANL')
                     INTO(MTRANLAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF CARDNUMI = SPACES OR CARDNUMI = LOW-VALUES
               MOVE WS-M-CARD-REQ TO ERRMSGO
               MOVE -1 TO CARDNUML
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE CARDNUMI TO WS-CARD-KEY
               INSPECT WS-CARD-KEY REPLACING ALL LOW-VALUE BY SPACE
               MOVE WS-CARD-KEY TO CA-CARD-NUM
               PERFORM 3000-BROWSE-TRANS
               PERFORM 2200-BUILD-SUMMARY
               MOVE -1 TO CARDNUML
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  2200-BUILD-SUMMARY  -  compose the result-count message that
      *  is shown on the message line after the browse completes.
      *----------------------------------------------------------------*
       2200-BUILD-SUMMARY.
           IF WS-ROW-CNT = ZEROS
               MOVE WS-M-NONE-FOUND TO ERRMSGO
           ELSE
               MOVE WS-ROW-CNT TO WS-CNT-ED
               MOVE SPACES TO ERRMSGO
               STRING WS-CNT-ED   DELIMITED BY SIZE
                      WS-M-SUFFIX DELIMITED BY SIZE
                      INTO ERRMSGO
               END-STRING
           END-IF.
      *----------------------------------------------------------------*
      *  3000-BROWSE-TRANS  -  browse the transaction file forward and
      *  collect the matching rows.  The row fields are cleared first
      *  so lines left over from a previous request are blanked out.
      *----------------------------------------------------------------*
       3000-BROWSE-TRANS.
           MOVE ZEROS TO WS-ROW-CNT.
           MOVE 'N'   TO WS-END-FLG.
           SET WS-BR-OFF TO TRUE.
           PERFORM 3050-CLEAR-ROWS.
           PERFORM 3100-START-BROWSE.
           IF WS-BR-ON
               PERFORM 3200-READ-NEXT
                   UNTIL END-OF-FILE
                      OR WS-ROW-CNT >= WS-MAX-ROWS
               PERFORM 3300-END-BROWSE
           END-IF.
      *----------------------------------------------------------------*
      *  3050-CLEAR-ROWS  -  blank the five display lines.             *
      *----------------------------------------------------------------*
       3050-CLEAR-ROWS.
           MOVE SPACES TO TRN1O AMT1O TYP1O.
           MOVE SPACES TO TRN2O AMT2O TYP2O.
           MOVE SPACES TO TRN3O AMT3O TYP3O.
           MOVE SPACES TO TRN4O AMT4O TYP4O.
           MOVE SPACES TO TRN5O AMT5O TYP5O.
      *----------------------------------------------------------------*
      *  3100-START-BROWSE  -  position the browse at the first record.
      *  A GTEQ start with a low-values key positions at the start of
      *  the data set so the whole file can be scanned in key order.
      *----------------------------------------------------------------*
       3100-START-BROWSE.
           MOVE LOW-VALUES TO TR-ID.
           EXEC CICS STARTBR
                     FILE(WS-TRANFILE)
                     RIDFLD(TR-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-BR-ON TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET WS-BR-OFF TO TRUE
                   SET END-OF-FILE TO TRUE
               WHEN OTHER
                   SET WS-BR-OFF TO TRUE
                   SET END-OF-FILE TO TRUE
                   MOVE WS-M-BROWSE-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-READ-NEXT  -  read the next record and, if the card
      *  matches, move it into the next available display line.        *
      *----------------------------------------------------------------*
       3200-READ-NEXT.
           EXEC CICS READNEXT
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   IF TR-CARD-NUM = WS-CARD-KEY
                       ADD 1 TO WS-ROW-CNT
                       PERFORM 4000-MOVE-ROW
                   END-IF
               WHEN DFHRESP(ENDFILE)
                   SET END-OF-FILE TO TRUE
               WHEN OTHER
                   SET END-OF-FILE TO TRUE
                   MOVE WS-M-BROWSE-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3300-END-BROWSE  -  release the browse position.              *
      *----------------------------------------------------------------*
       3300-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-TRANFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  4000-MOVE-ROW  -  place the current record into the display
      *  line indicated by the running row counter.  The amount is
      *  edited through WS-ED-AMT and the leading pad byte dropped so
      *  it fits the fifteen-character map field.
      *----------------------------------------------------------------*
       4000-MOVE-ROW.
           MOVE TR-AMT TO WS-ED-AMT.
           EVALUATE WS-ROW-CNT
               WHEN 1
                   MOVE TR-ID           TO TRN1O
                   MOVE WS-ED-AMT(2:15) TO AMT1O
                   MOVE TR-TYPE-CD      TO TYP1O
               WHEN 2
                   MOVE TR-ID           TO TRN2O
                   MOVE WS-ED-AMT(2:15) TO AMT2O
                   MOVE TR-TYPE-CD      TO TYP2O
               WHEN 3
                   MOVE TR-ID           TO TRN3O
                   MOVE WS-ED-AMT(2:15) TO AMT3O
                   MOVE TR-TYPE-CD      TO TYP3O
               WHEN 4
                   MOVE TR-ID           TO TRN4O
                   MOVE WS-ED-AMT(2:15) TO AMT4O
                   MOVE TR-TYPE-CD      TO TYP4O
               WHEN 5
                   MOVE TR-ID           TO TRN5O
                   MOVE WS-ED-AMT(2:15) TO AMT5O
                   MOVE TR-TYPE-CD      TO TYP5O
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  re-transmit the map data only.         *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MTRANLA')
                     MAPSET('MTRANL')
                     FROM(MTRANLAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to CICS.         *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
