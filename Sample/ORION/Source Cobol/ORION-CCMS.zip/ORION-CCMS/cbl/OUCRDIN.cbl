      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUCRDIN  -  Card Inquiry browse engine            *
      *  TYPE    : SUB  (VSAM browse)                                *
      *  FUNCTION: browse the card master (CARDFILE) with            *
      *            STARTBR / READNEXT / ENDBR, apply the filter      *
      *            chosen on the OCCRDIN screen and hand back one     *
      *            page (up to 13) of matching cards with card       *
      *            number, owning account, embossed name, expiry     *
      *            date and active status, plus active / inactive    *
      *            tallies for the page.                             *
      *  CALL    : EXEC CICS LINK PROGRAM('OUCRDIN')                 *
      *                COMMAREA(KCRDIN-AREA) END-EXEC.               *
      *  INTERFACE: copybook KCRDIN  (request + response + rows)     *
      *****************************************************************
      *  This one browse engine REPLACES the following batch card    *
      *  reports - each was a sequential CARDFILE scan:              *
      *    OBCARDP  card master listing    -> filter ALL             *
      *    OBRCARD  active / inactive tally -> filter ACTIVE/INACTIVE*
      *    OBCARDX  cards expiring soon     -> filter EXPIRING-SOON   *
      *    OBRCHLDR cardholder name roster  -> embossed-name column   *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - consolidated card browse.      *
      *****************************************************************
      *  BUSINESS RULES APPLIED PER FILTER                           *
      *  ALL           every card on the file.                       *
      *  ACTIVE        active status = 'Y'.                          *
      *  INACTIVE      active status not 'Y'.                        *
      *  EXPIRING-SOON expiry date falls within the next 60 days     *
      *                (from today, inclusive, not already past).    *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUCRDIN.
       AUTHOR.     ORION-CCMS-ONLINE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity.                                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUCRDIN'.
           05  WS-MAX-ROWS          PIC 9(02) VALUE 13.
      *----------------------------------------------------------------*
      *  Browse control switches.                                      *
      *----------------------------------------------------------------*
       01  WS-BROWSE-FLAGS.
           05  WS-BR-END-SW         PIC X(01) VALUE 'N'.
               88  BR-END                     VALUE 'Y'.
               88  BR-MORE                    VALUE 'N'.
           05  WS-BR-STARTED-SW     PIC X(01) VALUE 'N'.
               88  BR-STARTED                 VALUE 'Y'.
               88  BR-NOT-STARTED             VALUE 'N'.
           05  WS-READ-SW           PIC X(01) VALUE 'N'.
               88  READ-OK                    VALUE 'Y'.
               88  READ-NO                    VALUE 'N'.
           05  WS-MATCH-SW          PIC X(01) VALUE 'N'.
               88  WS-MATCH                   VALUE 'Y'.
               88  WS-NOMATCH                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Browse keys.                                                  *
      *----------------------------------------------------------------*
       01  WS-KEYS.
           05  WS-BROWSE-KEY        PIC X(16) VALUE LOW-VALUES.
           05  WS-LAST-MATCH        PIC X(16) VALUE LOW-VALUES.
      *----------------------------------------------------------------*
      *  Date arithmetic work area for the EXPIRING-SOON test.         *
      *----------------------------------------------------------------*
       01  WS-DATE-WORK.
           05  WS-CDT               PIC X(21)     VALUE SPACES.
           05  WS-TODAY-N           PIC 9(08)     VALUE ZEROS.
           05  WS-TODAY-INT         PIC S9(09) COMP VALUE ZEROS.
           05  WS-CUT-INT           PIC S9(09) COMP VALUE ZEROS.
           05  WS-EXP-PARTS.
               10  WE-YYYY          PIC 9(04)     VALUE ZEROS.
               10  WE-MM            PIC 9(02)     VALUE ZEROS.
               10  WE-DD            PIC 9(02)     VALUE ZEROS.
           05  WS-EXP-N REDEFINES WS-EXP-PARTS PIC 9(08).
           05  WS-EXP-INT           PIC S9(09) COMP VALUE ZEROS.
           05  WS-EXP-VALID-SW      PIC X(01) VALUE 'N'.
               88  WS-EXP-VALID               VALUE 'Y'.
               88  WS-EXP-BAD                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Shared constants / file names / edit fields.                  *
      *----------------------------------------------------------------*
       COPY WCONST.
      *----------------------------------------------------------------*
      *  Card record read forward from CARDFILE.                       *
      *----------------------------------------------------------------*
       COPY RCARD.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
      *----------------------------------------------------------------*
      *  The single browse-interface area passed on LINK.             *
      *----------------------------------------------------------------*
       COPY KCRDIN.
      *================================================================*
       PROCEDURE DIVISION USING KCRDIN-AREA.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  top level driver.                              *
      *----------------------------------------------------------------*
       0000-MAIN.
           PERFORM 1000-INITIALISE.
           PERFORM 2000-COMPUTE-CUTOFF.
           PERFORM 3000-BROWSE-DRIVER.
           PERFORM 6000-COMPUTE-KPI.
           PERFORM 9000-FINALISE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INITIALISE  -  reset the response half of the commarea.  *
      *----------------------------------------------------------------*
       1000-INITIALISE.
           SET KCI-OK TO TRUE.
           MOVE ZEROS TO KCI-ROW-COUNT.
           MOVE ZEROS TO KCI-SCAN-COUNT.
           MOVE ZEROS TO KCI-ACTIVE-CNT.
           MOVE ZEROS TO KCI-INACTIVE-CNT.
           SET KCI-NO-MORE TO TRUE.
           MOVE LOW-VALUES TO KCI-NEXT-KEY.
           MOVE LOW-VALUES TO WS-LAST-MATCH.
           SET BR-MORE TO TRUE.
           SET BR-NOT-STARTED TO TRUE.
      *----------------------------------------------------------------*
      *  2000-COMPUTE-CUTOFF  -  today and today + 60 days as integer  *
      *  day numbers for the expiring-soon compare.                    *
      *----------------------------------------------------------------*
       2000-COMPUTE-CUTOFF.
           MOVE FUNCTION CURRENT-DATE TO WS-CDT.
           MOVE WS-CDT(1:8) TO WS-TODAY-N.
           COMPUTE WS-TODAY-INT = FUNCTION INTEGER-OF-DATE(WS-TODAY-N).
           COMPUTE WS-CUT-INT = WS-TODAY-INT + 60.
      *----------------------------------------------------------------*
      *  3000-BROWSE-DRIVER  -  position the browse (skipping the      *
      *  resume card when paging), gather matches, decide whether more *
      *  pages remain and stamp the resume key.                        *
      *----------------------------------------------------------------*
       3000-BROWSE-DRIVER.
           PERFORM 3100-START-BROWSE.
           IF BR-STARTED
               IF KCI-START-KEY NOT = LOW-VALUES
                   PERFORM 3300-READ-NEXT
               END-IF
               PERFORM 3200-GATHER-PAGE
                   UNTIL BR-END
                      OR KCI-ROW-COUNT >= WS-MAX-ROWS
               IF BR-END
                   SET KCI-NO-MORE TO TRUE
               ELSE
                   SET KCI-MORE TO TRUE
               END-IF
               IF KCI-ROW-COUNT > 0
                   MOVE WS-LAST-MATCH TO KCI-NEXT-KEY
               END-IF
               PERFORM 3400-END-BROWSE
           END-IF.
      *----------------------------------------------------------------*
      *  3100-START-BROWSE  -  STARTBR at (or after) the resume key.   *
      *----------------------------------------------------------------*
       3100-START-BROWSE.
           MOVE KCI-START-KEY TO WS-BROWSE-KEY.
           EXEC CICS STARTBR
                     FILE(WS-CARDFILE)
                     RIDFLD(WS-BROWSE-KEY)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BR-STARTED TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET BR-END TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET BR-END TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KCI-ERROR TO TRUE
                   DISPLAY 'OUCRDIN: STARTBR RESP=' WS-RESP-CD
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-GATHER-PAGE  -  read one card, count it, derive its      *
      *  figures, test it against the filter and keep it when matched. *
      *----------------------------------------------------------------*
       3200-GATHER-PAGE.
           PERFORM 3300-READ-NEXT.
           IF READ-OK
               ADD 1 TO KCI-SCAN-COUNT
               PERFORM 4000-DERIVE-FIGURES
               PERFORM 4500-APPLY-FILTER
               IF WS-MATCH
                   PERFORM 5000-STORE-ROW
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3300-READ-NEXT  -  one READNEXT with response handling.       *
      *----------------------------------------------------------------*
       3300-READ-NEXT.
           SET READ-NO TO TRUE.
           EXEC CICS READNEXT
                     FILE(WS-CARDFILE)
                     INTO(CARD-REC)
                     RIDFLD(WS-BROWSE-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET READ-OK TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET BR-END TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KCI-ERROR TO TRUE
                   DISPLAY 'OUCRDIN: READNEXT RESP=' WS-RESP-CD
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3400-END-BROWSE  -  release the browse if it was started.     *
      *----------------------------------------------------------------*
       3400-END-BROWSE.
           IF BR-STARTED
               EXEC CICS ENDBR
                         FILE(WS-CARDFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
      *----------------------------------------------------------------*
      *  4000-DERIVE-FIGURES  -  parse the expiry date into a day      *
      *  number for the expiring-soon window compare.                  *
      *----------------------------------------------------------------*
       4000-DERIVE-FIGURES.
           SET WS-EXP-BAD TO TRUE.
           MOVE ZEROS TO WS-EXP-INT.
           IF CD-EXPIRY-DATE(1:4) NUMERIC
              AND CD-EXPIRY-DATE(6:2) NUMERIC
              AND CD-EXPIRY-DATE(9:2) NUMERIC
               MOVE CD-EXPIRY-DATE(1:4) TO WE-YYYY
               MOVE CD-EXPIRY-DATE(6:2) TO WE-MM
               MOVE CD-EXPIRY-DATE(9:2) TO WE-DD
               COMPUTE WS-EXP-INT =
                   FUNCTION INTEGER-OF-DATE(WS-EXP-N)
               SET WS-EXP-VALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  4500-APPLY-FILTER  -  route to the individual selection tests.*
      *----------------------------------------------------------------*
       4500-APPLY-FILTER.
           SET WS-NOMATCH TO TRUE.
           EVALUATE TRUE
               WHEN KCI-F-ALL
                   PERFORM 4510-TEST-ALL
               WHEN KCI-F-ACTIVE
                   PERFORM 4520-TEST-ACTIVE
               WHEN KCI-F-INACTIVE
                   PERFORM 4530-TEST-INACTIVE
               WHEN KCI-F-EXPIRING
                   PERFORM 4540-TEST-EXPIRING
               WHEN OTHER
                   PERFORM 4510-TEST-ALL
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4510-TEST-ALL  -  unconditional match (OBCARDP listing).      *
      *----------------------------------------------------------------*
       4510-TEST-ALL.
           SET WS-MATCH TO TRUE.
      *----------------------------------------------------------------*
      *  4520-TEST-ACTIVE  -  active status 'Y' (OBRCARD).             *
      *----------------------------------------------------------------*
       4520-TEST-ACTIVE.
           IF CD-ACTIVE-STATUS = 'Y'
               SET WS-MATCH TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  4530-TEST-INACTIVE  -  active status not 'Y' (OBRCARD).       *
      *----------------------------------------------------------------*
       4530-TEST-INACTIVE.
           IF CD-ACTIVE-STATUS NOT = 'Y'
               SET WS-MATCH TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  4540-TEST-EXPIRING  -  expiry within the next 60 days         *
      *  (OBCARDX).  Undated or unparseable cards are not selected.    *
      *----------------------------------------------------------------*
       4540-TEST-EXPIRING.
           IF WS-EXP-VALID
              AND WS-EXP-INT >= WS-TODAY-INT
              AND WS-EXP-INT <= WS-CUT-INT
               SET WS-MATCH TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  5000-STORE-ROW  -  copy the matched card into the next page   *
      *  row and tally the active / inactive counters.                 *
      *----------------------------------------------------------------*
       5000-STORE-ROW.
           ADD 1 TO KCI-ROW-COUNT.
           MOVE CD-NUM           TO KCI-R-NUM(KCI-ROW-COUNT).
           MOVE CD-ACCT-ID       TO KCI-R-ACCT(KCI-ROW-COUNT).
           MOVE CD-EMBOSSED-NAME TO KCI-R-NAME(KCI-ROW-COUNT).
           MOVE CD-EXPIRY-DATE   TO KCI-R-EXPIRY(KCI-ROW-COUNT).
           MOVE CD-ACTIVE-STATUS TO KCI-R-STATUS(KCI-ROW-COUNT).
           MOVE CD-NUM           TO WS-LAST-MATCH.
      *----------------------------------------------------------------*
      *  6000-COMPUTE-KPI  -  when the screen asks (first page only),  *
      *  scan the WHOLE file for the same filter and tally the active  *
      *  and inactive cards - the population figures the OBRCARD batch *
      *  report produced.  On a page-forward the flag is off so the    *
      *  extra pass is skipped (the screen carries the figures).       *
      *----------------------------------------------------------------*
       6000-COMPUTE-KPI.
           IF KCI-DO-KPI
               MOVE ZEROS TO KCI-ACTIVE-CNT
               MOVE ZEROS TO KCI-INACTIVE-CNT
               PERFORM 6100-KPI-START
               IF BR-STARTED
                   PERFORM 6200-KPI-READ
                       UNTIL BR-END
                   PERFORM 6300-KPI-END
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  6100-KPI-START  -  position at the top of the file.           *
      *----------------------------------------------------------------*
       6100-KPI-START.
           SET BR-MORE TO TRUE.
           SET BR-NOT-STARTED TO TRUE.
           MOVE LOW-VALUES TO WS-BROWSE-KEY.
           EXEC CICS STARTBR
                     FILE(WS-CARDFILE)
                     RIDFLD(WS-BROWSE-KEY)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BR-STARTED TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6200-KPI-READ  -  read forward, filter and tally.             *
      *----------------------------------------------------------------*
       6200-KPI-READ.
           EXEC CICS READNEXT
                     FILE(WS-CARDFILE)
                     INTO(CARD-REC)
                     RIDFLD(WS-BROWSE-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   PERFORM 4000-DERIVE-FIGURES
                   PERFORM 4500-APPLY-FILTER
                   IF WS-MATCH
                       IF CD-ACTIVE-STATUS = 'Y'
                           ADD 1 TO KCI-ACTIVE-CNT
                       ELSE
                           ADD 1 TO KCI-INACTIVE-CNT
                       END-IF
                   END-IF
               WHEN OTHER
                   SET BR-END TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6300-KPI-END  -  release the population browse.               *
      *----------------------------------------------------------------*
       6300-KPI-END.
           EXEC CICS ENDBR
                     FILE(WS-CARDFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-FINALISE  -  confirm the return code and log a trace.    *
      *----------------------------------------------------------------*
       9000-FINALISE.
           IF KCI-ERROR
               CONTINUE
           ELSE
               SET KCI-OK TO TRUE
           END-IF.
           DISPLAY 'OUCRDIN: filter ' KCI-FILTER
                   ' matched ' KCI-ROW-COUNT
                   ' scanned ' KCI-SCAN-COUNT.
