      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCTRANA  -  Transaction Add (on-line)            *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: capture a new financial transaction.  The card,   *
      *            type, category, amount, merchant name and          *
      *            description are validated against the reference    *
      *            files; a new transaction id is drawn from the      *
      *            control counter and the record is written to the   *
      *            TRANFILE.                                          *
      *            PF3 = back to menu, PF4 = clear, ENTER = add.      *
      *  MAPSET  : MTRANA      MAP : MTRANAA     TRANID : ORTA        *
      *  FILES   : TRANFILE (write) , XREFFILE (read) ,             *
      *            TTYPFILE (read) , TCATFILE (read) ,              *
      *            CTRLFILE (read update / rewrite counter).         *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.       *
      *****************************************************************
      *  MAINTENANCE LOG                                              *
      *  ----  ----------  --------------------------------------     *
      *  0001  2026-08-07  Original - transaction capture screen.     *
      *****************************************************************
      *  PROCESSING NARRATIVE                                         *
      *  1. The operator keys the card number, type, category,        *
      *     amount, merchant name and description and presses ENTER.  *
      *  2. Each field is edited: the card must exist on the xref     *
      *     file, the type on the type file, the category on the      *
      *     category file, and the amount must be numeric and above   *
      *     zero.                                                     *
      *  3. When every edit passes, the next transaction id is        *
      *     obtained by reading the control record for update,        *
      *     incrementing the counter and rewriting it.                *
      *  4. The transaction record is built and written; a            *
      *     confirmation carrying the new id is returned.             *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCTRANA.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identification and navigation constants               *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCTRANA'.
           05  WS-TRANID            PIC X(04) VALUE 'ORTA'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Work fields captured from the map / built for the record      *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-CARD-KEY          PIC X(16) VALUE SPACES.
           05  WS-IN-CAT            PIC 9(04) VALUE ZEROS.
           05  WS-AMT-NUM           PIC S9(09)V99 VALUE ZEROS.
           05  WS-NEW-TRANID        PIC 9(16) VALUE ZEROS.
           05  WS-TIMESTAMP         PIC X(26) VALUE SPACES.
           05  WS-CTR-KEY           PIC X(08) VALUE 'TRANID'.
           05  WS-EDIT-FLAG         PIC X(01) VALUE 'N'.
               88  WS-EDIT-GOOD               VALUE 'Y'.
               88  WS-EDIT-BAD                VALUE 'N'.
           05  WS-ID-FLAG           PIC X(01) VALUE 'N'.
               88  WS-ID-OK                   VALUE 'Y'.
               88  WS-ID-NOT-OK               VALUE 'N'.
      *----------------------------------------------------------------*
      *  Generic string edit work area                                 *
      *----------------------------------------------------------------*
       01  WS-VALIDATION.
           05  WS-VAL-STR           PIC X(20) VALUE SPACES.
           05  WS-VAL-LEN           PIC 9(02) VALUE ZEROS.
           05  WS-VAL-I             PIC 9(02) VALUE ZEROS.
           05  WS-VAL-CH            PIC X(01) VALUE SPACE.
           05  WS-VAL-DIGITS        PIC 9(02) VALUE ZEROS.
           05  WS-DOT-CNT           PIC 9(02) VALUE ZEROS.
           05  WS-VAL-OK            PIC X(01) VALUE 'Y'.
               88  WS-VAL-GOOD                VALUE 'Y'.
               88  WS-VAL-BAD                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Program specific operator messages                            *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(60)
               VALUE 'Enter the transaction details and press ENTER.'.
           05  WS-M-CARD-REQ        PIC X(60)
               VALUE 'Card number is required.'.
           05  WS-M-CARD-BAD        PIC X(60)
               VALUE 'Card number is not on file.'.
           05  WS-M-TYPE-REQ        PIC X(60)
               VALUE 'Transaction type is required.'.
           05  WS-M-TYPE-BAD        PIC X(60)
               VALUE 'Transaction type is not valid.'.
           05  WS-M-CAT-REQ         PIC X(60)
               VALUE 'Category code is required.'.
           05  WS-M-CAT-NUM         PIC X(60)
               VALUE 'Category code must be numeric.'.
           05  WS-M-CAT-BAD         PIC X(60)
               VALUE 'Category is not valid for that type.'.
           05  WS-M-AMT-REQ         PIC X(60)
               VALUE 'Amount is required.'.
           05  WS-M-AMT-BAD         PIC X(60)
               VALUE 'Amount is not a valid number.'.
           05  WS-M-AMT-ZERO        PIC X(60)
               VALUE 'Amount must be greater than zero.'.
           05  WS-M-MERCH-REQ       PIC X(60)
               VALUE 'Merchant name is required.'.
           05  WS-M-DESC-REQ        PIC X(60)
               VALUE 'Description is required.'.
           05  WS-M-CTR-MISSING     PIC X(60)
               VALUE 'Transaction counter is not defined.'.
           05  WS-M-CTR-ERROR       PIC X(60)
               VALUE 'Error updating the transaction counter.'.
           05  WS-M-WRITE-ERROR     PIC X(60)
               VALUE 'Error writing the transaction record.'.
           05  WS-M-ADD-PREFIX      PIC X(14)
               VALUE 'Transaction '.
           05  WS-M-ADD-SUFFIX      PIC X(10)
               VALUE ' added.'.
           05  WS-M-SOURCE          PIC X(10)
               VALUE 'ONLINE'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea      *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  File record layouts and BMS symbolic map                      *
      *----------------------------------------------------------------*
       COPY RTRAN.
       COPY RXREF.
       COPY RTTYP.
       COPY RTCAT.
       COPY RCTRL.
       COPY MTRANA.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants             *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh empty screen.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MTRANAAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO CARDNUML.
           EXEC CICS SEND
                     MAP('MTRANAA')
                     MAPSET('MTRANA')
                     FROM(MTRANAAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-ADD-TRAN
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-ADD-TRAN  -  receive the map, edit every field and, when
      *  valid, assign an id and write the transaction record.         *
      *----------------------------------------------------------------*
       2100-ADD-TRAN.
           EXEC CICS RECEIVE
                     MAP('MTRANAA')
                     MAPSET('MTRANA')
                     INTO(MTRANAAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           PERFORM 5000-EDIT-INPUT.
           IF WS-EDIT-BAD
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 6000-GET-NEXT-ID
               IF WS-ID-OK
                   PERFORM 6500-WRITE-TRAN
               ELSE
                   MOVE -1 TO CARDNUML
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2200-CONFIRM-ADD  -  present a clean screen carrying the new
      *  transaction id so the operator can add another record.        *
      *----------------------------------------------------------------*
       2200-CONFIRM-ADD.
           MOVE LOW-VALUES TO MTRANAAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE SPACES TO ERRMSGO.
           STRING WS-M-ADD-PREFIX DELIMITED BY SIZE
                  TR-ID           DELIMITED BY SIZE
                  WS-M-ADD-SUFFIX DELIMITED BY SIZE
                  INTO ERRMSGO
           END-STRING.
           MOVE -1 TO CARDNUML.
           EXEC CICS SEND
                     MAP('MTRANAA')
                     MAPSET('MTRANA')
                     FROM(MTRANAAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  5000-EDIT-INPUT  -  drive the individual field edits in order.
      *  Validation stops at the first field that fails so the operator
      *  is guided one problem at a time.                              *
      *----------------------------------------------------------------*
       5000-EDIT-INPUT.
           SET WS-EDIT-GOOD TO TRUE.
           PERFORM 5100-EDIT-CARD.
           IF WS-EDIT-GOOD
               PERFORM 5200-EDIT-TYPE
           END-IF.
           IF WS-EDIT-GOOD
               PERFORM 5300-EDIT-CAT
           END-IF.
           IF WS-EDIT-GOOD
               PERFORM 5400-EDIT-AMT
           END-IF.
           IF WS-EDIT-GOOD
               PERFORM 5500-EDIT-MERCH
           END-IF.
           IF WS-EDIT-GOOD
               PERFORM 5600-EDIT-DESC
           END-IF.
      *----------------------------------------------------------------*
      *  5100-EDIT-CARD  -  card number present and known to the xref.
      *----------------------------------------------------------------*
       5100-EDIT-CARD.
           IF CARDNUMI = SPACES OR CARDNUMI = LOW-VALUES
               SET WS-EDIT-BAD TO TRUE
               MOVE WS-M-CARD-REQ TO ERRMSGO
               MOVE -1 TO CARDNUML
           ELSE
               MOVE CARDNUMI TO WS-CARD-KEY
               INSPECT WS-CARD-KEY REPLACING ALL LOW-VALUE BY SPACE
               PERFORM 5150-READ-XREF
               IF REC-NOT-FOUND
                   SET WS-EDIT-BAD TO TRUE
                   MOVE WS-M-CARD-BAD TO ERRMSGO
                   MOVE -1 TO CARDNUML
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  5150-READ-XREF  -  verify the card exists on XREFFILE.        *
      *----------------------------------------------------------------*
       5150-READ-XREF.
           SET REC-NOT-FOUND TO TRUE.
           MOVE WS-CARD-KEY TO XR-CARD-NUM.
           EXEC CICS READ
                     FILE(WS-XREFFILE)
                     INTO(XREF-REC)
                     RIDFLD(XR-CARD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               SET REC-FOUND TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  5200-EDIT-TYPE  -  type present and known to the type file.   *
      *----------------------------------------------------------------*
       5200-EDIT-TYPE.
           IF TRTYPEI = SPACES OR TRTYPEI = LOW-VALUES
               SET WS-EDIT-BAD TO TRUE
               MOVE WS-M-TYPE-REQ TO ERRMSGO
               MOVE -1 TO TRTYPEL
           ELSE
               MOVE TRTYPEI TO TT-CD
               INSPECT TT-CD REPLACING ALL LOW-VALUE BY SPACE
               PERFORM 5250-READ-TTYP
               IF REC-NOT-FOUND
                   SET WS-EDIT-BAD TO TRUE
                   MOVE WS-M-TYPE-BAD TO ERRMSGO
                   MOVE -1 TO TRTYPEL
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  5250-READ-TTYP  -  verify the type exists on TTYPFILE.        *
      *----------------------------------------------------------------*
       5250-READ-TTYP.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-TTYPFILE)
                     INTO(TTYP-REC)
                     RIDFLD(TT-CD)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               SET REC-FOUND TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  5300-EDIT-CAT  -  category present, numeric and valid for the
      *  chosen type.  The category key is the type code plus code.    *
      *----------------------------------------------------------------*
       5300-EDIT-CAT.
           IF TRCATI = SPACES OR TRCATI = LOW-VALUES
               SET WS-EDIT-BAD TO TRUE
               MOVE WS-M-CAT-REQ TO ERRMSGO
               MOVE -1 TO TRCATL
           ELSE
               MOVE SPACES TO WS-VAL-STR
               MOVE TRCATI TO WS-VAL-STR
               MOVE 4      TO WS-VAL-LEN
               PERFORM 7600-VALIDATE-NUM
               IF WS-VAL-BAD
                   SET WS-EDIT-BAD TO TRUE
                   MOVE WS-M-CAT-NUM TO ERRMSGO
                   MOVE -1 TO TRCATL
               ELSE
                   COMPUTE WS-IN-CAT =
                       FUNCTION NUMVAL(WS-VAL-STR(1:WS-VAL-LEN))
                   MOVE TRTYPEI  TO TC-TYPE-CD
                   MOVE WS-IN-CAT TO TC-CD
                   INSPECT TC-TYPE-CD REPLACING ALL LOW-VALUE BY SPACE
                   PERFORM 5350-READ-TCAT
                   IF REC-NOT-FOUND
                       SET WS-EDIT-BAD TO TRUE
                       MOVE WS-M-CAT-BAD TO ERRMSGO
                       MOVE -1 TO TRCATL
                   END-IF
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  5350-READ-TCAT  -  verify the category exists on TCATFILE.    *
      *----------------------------------------------------------------*
       5350-READ-TCAT.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-TCATFILE)
                     INTO(TCAT-REC)
                     RIDFLD(TC-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               SET REC-FOUND TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  5400-EDIT-AMT  -  amount present, numeric and greater than 0.
      *----------------------------------------------------------------*
       5400-EDIT-AMT.
           IF TRAMTI = SPACES OR TRAMTI = LOW-VALUES
               SET WS-EDIT-BAD TO TRUE
               MOVE WS-M-AMT-REQ TO ERRMSGO
               MOVE -1 TO TRAMTL
           ELSE
               MOVE SPACES TO WS-VAL-STR
               MOVE TRAMTI TO WS-VAL-STR
               MOVE 12     TO WS-VAL-LEN
               PERFORM 7700-VALIDATE-AMT
               IF WS-VAL-BAD
                   SET WS-EDIT-BAD TO TRUE
                   MOVE WS-M-AMT-BAD TO ERRMSGO
                   MOVE -1 TO TRAMTL
               ELSE
                   COMPUTE WS-AMT-NUM =
                       FUNCTION NUMVAL(WS-VAL-STR(1:WS-VAL-LEN))
                   IF WS-AMT-NUM <= ZEROS
                       SET WS-EDIT-BAD TO TRUE
                       MOVE WS-M-AMT-ZERO TO ERRMSGO
                       MOVE -1 TO TRAMTL
                   END-IF
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  5500-EDIT-MERCH  -  merchant name must be present.            *
      *----------------------------------------------------------------*
       5500-EDIT-MERCH.
           IF TRMERCHI = SPACES OR TRMERCHI = LOW-VALUES
               SET WS-EDIT-BAD TO TRUE
               MOVE WS-M-MERCH-REQ TO ERRMSGO
               MOVE -1 TO TRMERCHL
           END-IF.
      *----------------------------------------------------------------*
      *  5600-EDIT-DESC  -  description must be present.               *
      *----------------------------------------------------------------*
       5600-EDIT-DESC.
           IF TRDESCI = SPACES OR TRDESCI = LOW-VALUES
               SET WS-EDIT-BAD TO TRUE
               MOVE WS-M-DESC-REQ TO ERRMSGO
               MOVE -1 TO TRDESCL
           END-IF.
      *----------------------------------------------------------------*
      *  6000-GET-NEXT-ID  -  read the control counter for update,
      *  advance it and rewrite it.  The new value becomes the 16 byte *
      *  transaction id after zero padding.                            *
      *----------------------------------------------------------------*
       6000-GET-NEXT-ID.
           SET WS-ID-NOT-OK TO TRUE.
           MOVE 'TRANID' TO CT-KEY.
           EXEC CICS READ
                     FILE(WS-CTRLFILE)
                     INTO(CTRL-REC)
                     RIDFLD(CT-KEY)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO CT-LAST-VALUE
                   PERFORM 6100-REWRITE-CTR
               WHEN DFHRESP(NOTFND)
                   MOVE WS-M-CTR-MISSING TO ERRMSGO
               WHEN OTHER
                   MOVE WS-M-CTR-ERROR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6100-REWRITE-CTR  -  commit the advanced counter and derive
      *  the new transaction id.                                       *
      *----------------------------------------------------------------*
       6100-REWRITE-CTR.
           EXEC CICS REWRITE
                     FILE(WS-CTRLFILE)
                     FROM(CTRL-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               MOVE CT-LAST-VALUE TO WS-NEW-TRANID
               SET WS-ID-OK TO TRUE
           ELSE
               MOVE WS-M-CTR-ERROR TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  6500-WRITE-TRAN  -  build the record and write it, then
      *  confirm or report the write failure.                         *
      *----------------------------------------------------------------*
       6500-WRITE-TRAN.
           PERFORM 6600-BUILD-RECORD.
           EXEC CICS WRITE
                     FILE(WS-TRANFILE)
                     FROM(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   PERFORM 2200-CONFIRM-ADD
               WHEN OTHER
                   MOVE WS-M-WRITE-ERROR TO ERRMSGO
                   MOVE -1 TO CARDNUML
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6600-BUILD-RECORD  -  assemble the transaction record from the
      *  validated input values and a current timestamp.              *
      *----------------------------------------------------------------*
       6600-BUILD-RECORD.
           INITIALIZE TRAN-REC.
           PERFORM 8500-GET-DATE-TIME.
           MOVE SPACES TO WS-TIMESTAMP.
           STRING WS-HDR-DATE DELIMITED BY SIZE
                  ' '         DELIMITED BY SIZE
                  WS-HDR-TIME DELIMITED BY SIZE
                  INTO WS-TIMESTAMP
           END-STRING.
           MOVE WS-NEW-TRANID    TO TR-ID.
           MOVE TRTYPEI          TO TR-TYPE-CD.
           INSPECT TR-TYPE-CD REPLACING ALL LOW-VALUE BY SPACE.
           MOVE WS-IN-CAT        TO TR-CAT-CD.
           MOVE WS-M-SOURCE      TO TR-SOURCE.
           MOVE TRDESCI          TO TR-DESC.
           MOVE WS-AMT-NUM       TO TR-AMT.
           MOVE ZEROS            TO TR-MERCHANT-ID.
           MOVE TRMERCHI         TO TR-MERCHANT-NAME.
           MOVE SPACES           TO TR-MERCHANT-CITY.
           MOVE SPACES           TO TR-MERCHANT-ZIP.
           MOVE WS-CARD-KEY      TO TR-CARD-NUM.
           MOVE WS-TIMESTAMP     TO TR-ORIG-TS.
           MOVE WS-TIMESTAMP     TO TR-PROC-TS.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  7600-VALIDATE-NUM  -  generic integer string editor.         *
      *----------------------------------------------------------------*
       7600-VALIDATE-NUM.
           SET WS-VAL-GOOD TO TRUE.
           MOVE ZEROS TO WS-VAL-DIGITS.
           INSPECT WS-VAL-STR(1:WS-VAL-LEN)
               REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-VAL-I FROM 1 BY 1
                   UNTIL WS-VAL-I > WS-VAL-LEN
               MOVE WS-VAL-STR(WS-VAL-I:1) TO WS-VAL-CH
               IF WS-VAL-CH = SPACE
                   CONTINUE
               ELSE
                   IF WS-VAL-CH >= '0' AND WS-VAL-CH <= '9'
                       ADD 1 TO WS-VAL-DIGITS
                   ELSE
                       SET WS-VAL-BAD TO TRUE
                   END-IF
               END-IF
           END-PERFORM.
           IF WS-VAL-DIGITS = ZEROS
               SET WS-VAL-BAD TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  7700-VALIDATE-AMT  -  edit a signed decimal amount string.    *
      *  Digits, one optional decimal point, grouping commas and a     *
      *  leading or trailing sign are permitted; at least one digit    *
      *  must be present.  FUNCTION NUMVAL performs the conversion.
      *----------------------------------------------------------------*
       7700-VALIDATE-AMT.
           SET WS-VAL-GOOD TO TRUE.
           MOVE ZEROS TO WS-VAL-DIGITS.
           MOVE ZEROS TO WS-DOT-CNT.
           INSPECT WS-VAL-STR(1:WS-VAL-LEN)
               REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-VAL-I FROM 1 BY 1
                   UNTIL WS-VAL-I > WS-VAL-LEN
               MOVE WS-VAL-STR(WS-VAL-I:1) TO WS-VAL-CH
               EVALUATE TRUE
                   WHEN WS-VAL-CH = SPACE
                       CONTINUE
                   WHEN WS-VAL-CH >= '0' AND WS-VAL-CH <= '9'
                       ADD 1 TO WS-VAL-DIGITS
                   WHEN WS-VAL-CH = '.'
                       ADD 1 TO WS-DOT-CNT
                   WHEN WS-VAL-CH = ','
                       CONTINUE
                   WHEN WS-VAL-CH = '-'
                       CONTINUE
                   WHEN WS-VAL-CH = '+'
                       CONTINUE
                   WHEN OTHER
                       SET WS-VAL-BAD TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-VAL-DIGITS = ZEROS
               SET WS-VAL-BAD TO TRUE
           END-IF.
           IF WS-DOT-CNT > 1
               SET WS-VAL-BAD TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  re-transmit the map data only.         *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MTRANAA')
                     MAPSET('MTRANA')
                     FROM(MTRANAAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to CICS.         *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
