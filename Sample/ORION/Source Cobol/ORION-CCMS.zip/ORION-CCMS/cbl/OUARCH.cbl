      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)
      *  PROGRAM : OUARCH  -  Archive transactions older than a cutoff
      *  TYPE    : SUB  (CICS file control)
      *  FUNCTION: on-line port of batch OBARCH.  Browse TRANFILE in
      *            key order and capture every transaction whose process
      *            date is before the cutoff into an in-core save table
      *            (bounded so the transaction stays short).  After the
      *            browse ends, each captured record is copied to the
      *            archive file (ARCHFILE, WRITE) and then removed from
      *            the live file (DELETE FROM TRANFILE).  Counts and the
      *            archived amount are returned in the KARCH block that
      *            is overlaid on the shared COMMAREA work area.
      *  CALL    : EXEC CICS LINK PROGRAM('OUARCH')
      *                COMMAREA(ORION-COMMAREA)
      *                LENGTH(LENGTH OF ORION-COMMAREA) END-EXEC.
      *  FILES   : TRANFILE browse and DELETE, ARCHFILE WRITE.
      *  RETURN  : ends with GOBACK (subroutine convention).
      *****************************************************************
      *  MAINTENANCE LOG
      *  ----  ----------  -------------------------------------
      *  0001  2026-08-07  Original - on-line transaction archive sub.
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUARCH.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and the archive file name.                  *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUARCH'.
           05  WS-ARCHFILE          PIC X(08) VALUE 'ARCHFILE'.
      *----------------------------------------------------------------*
      *  Run-control switches and cutoff-shape work fields.           *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-EOF-SW            PIC X(01) VALUE 'N'.
               88  WS-EOF-YES                 VALUE 'Y'.
               88  WS-EOF-NO                  VALUE 'N'.
           05  WS-BROWSE-SW         PIC X(01) VALUE 'N'.
               88  WS-BR-ON                   VALUE 'Y'.
               88  WS-BR-OFF                  VALUE 'N'.
           05  WS-CAPPED            PIC X(01) VALUE 'N'.
           05  WS-DT-OK             PIC X(01) VALUE 'N'.
       01  WS-WORK-FIELDS.
           05  WS-DT-IN             PIC X(12) VALUE SPACES.
           05  WS-DT                PIC X(10) VALUE SPACES.
           05  WS-PROC-DATE         PIC X(10) VALUE SPACES.
           05  WS-MAX               PIC 9(07) VALUE ZEROS.
           05  WS-CAP               PIC 9(04) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Save table - old transactions captured during the browse and  *
      *  archived / deleted in a second pass.                          *
      *----------------------------------------------------------------*
       01  WS-SAVE-TABLE.
           05  WS-SAVE-CNT          PIC 9(04) VALUE ZERO.
           05  WS-MAX-SAVE          PIC 9(04) VALUE 0050.
           05  WS-SAVE-ENTRY OCCURS 50 TIMES
                            INDEXED BY WS-SX.
               10  WS-SAVE-REC      PIC X(350).
      *----------------------------------------------------------------*
      *  Shared constants and the transaction record layout.          *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RTRAN.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KARCH.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  top level driver.                               *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KAR-PARM TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INIT.
           IF KAR-STATUS NOT = '99'
               PERFORM 2000-POSITION
               IF WS-BR-ON
                   PERFORM 3000-SCAN-LOOP
                      UNTIL WS-EOF-YES
                         OR WS-CAPPED = 'Y'
                   PERFORM 4000-PEEK-NEXT
                   PERFORM 5000-END-BROWSE
                   PERFORM 5500-ARCHIVE-SAVED
               END-IF
           END-IF.
           PERFORM 6000-SET-STATUS.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INIT  -  reset the result area and validate the cutoff.
      *----------------------------------------------------------------*
       1000-INIT.
           SET WS-EOF-NO TO TRUE.
           SET WS-BR-OFF TO TRUE.
           MOVE 'N'    TO WS-CAPPED.
           MOVE ZERO   TO WS-SAVE-CNT.
           MOVE '00'   TO KAR-STATUS.
           MOVE SPACES TO KAR-MSG.
           MOVE ZEROS  TO KAR-READ KAR-ARCHIVED KAR-DELETED.
           MOVE ZEROS  TO KAR-KEPT KAR-ERRORS KAR-ARCH-AMT.
           MOVE SPACES TO KAR-NEXT-TRAN.
           MOVE 'N'    TO KAR-MORE.
           MOVE KAR-MAX TO WS-MAX.
           MOVE WS-MAX-SAVE TO WS-CAP.
           IF WS-MAX > ZEROS AND WS-MAX < WS-MAX-SAVE
               MOVE WS-MAX TO WS-CAP
           END-IF.
           MOVE KAR-CUTOFF TO WS-DT-IN.
           PERFORM 1100-CHK-DATE.
           IF WS-DT-OK NOT = 'Y'
               MOVE '99' TO KAR-STATUS
               MOVE 'INVALID CUTOFF - USE YYYY-MM-DD' TO KAR-MSG
           END-IF.
      *----------------------------------------------------------------*
      *  1100-CHK-DATE  -  verify the YYYY-MM-DD shape of the cutoff.
      *----------------------------------------------------------------*
       1100-CHK-DATE.
           MOVE 'N' TO WS-DT-OK.
           MOVE FUNCTION TRIM (WS-DT-IN) TO WS-DT.
           IF WS-DT (5:1) = '-' AND WS-DT (8:1) = '-'
               IF WS-DT (1:4) IS NUMERIC
                  AND WS-DT (6:2) IS NUMERIC
                  AND WS-DT (9:2) IS NUMERIC
                   MOVE 'Y' TO WS-DT-OK
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2000-POSITION  -  open the transaction browse at resume key.
      *----------------------------------------------------------------*
       2000-POSITION.
           IF KAR-START-TRAN = SPACES OR KAR-START-TRAN = LOW-VALUES
               MOVE LOW-VALUES TO TR-ID
           ELSE
               MOVE KAR-START-TRAN TO TR-ID
           END-IF.
           EXEC CICS STARTBR
                     FILE(WS-TRANFILE)
                     RIDFLD(TR-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-BR-ON TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET WS-EOF-YES TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   MOVE '99' TO KAR-STATUS
                   MOVE 'TRANFILE STARTBR FAILED' TO KAR-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3000-SCAN-LOOP  -  classify one transaction per iteration.    *
      *----------------------------------------------------------------*
       3000-SCAN-LOOP.
           PERFORM 3100-READ-TRAN.
           IF NOT WS-EOF-YES
               PERFORM 3200-CLASSIFY
               IF WS-SAVE-CNT >= WS-CAP
                   MOVE 'Y' TO WS-CAPPED
               END-IF
      *        bound the browse by records SCANNED (operator max), not
      *        only by old records saved, so a cutoff that matches few
      *        old rows cannot read the whole file in one online task.
               IF WS-MAX > ZEROS AND KAR-READ >= WS-MAX
                   MOVE 'Y' TO WS-CAPPED
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3100-READ-TRAN  -  advance the transaction browse.            *
      *----------------------------------------------------------------*
       3100-READ-TRAN.
           EXEC CICS READNEXT
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   SET WS-EOF-YES TO TRUE
                   ADD 1 TO KAR-ERRORS
                   MOVE 'TRANFILE READNEXT FAILED' TO KAR-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-CLASSIFY  -  an old transaction is saved for archiving;
      *  a current one is simply counted as kept.                      *
      *----------------------------------------------------------------*
       3200-CLASSIFY.
           ADD 1 TO KAR-READ.
           MOVE TR-PROC-TS (1:10) TO WS-PROC-DATE.
           IF WS-PROC-DATE < KAR-CUTOFF
               IF WS-SAVE-CNT < WS-CAP
                   ADD 1 TO WS-SAVE-CNT
                   MOVE TRAN-REC TO WS-SAVE-REC(WS-SAVE-CNT)
               END-IF
           ELSE
               ADD 1 TO KAR-KEPT
           END-IF.
      *----------------------------------------------------------------*
      *  4000-PEEK-NEXT  -  publish the resume key when the cap stopped
      *  the scan short of end-of-file.                                *
      *----------------------------------------------------------------*
       4000-PEEK-NEXT.
           IF WS-EOF-YES
               MOVE 'N' TO KAR-MORE
               GO TO 4000-EXIT
           END-IF.
           EXEC CICS READNEXT
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE 'Y'   TO KAR-MORE
                   MOVE TR-ID TO KAR-NEXT-TRAN
               WHEN DFHRESP(ENDFILE)
                   MOVE 'N' TO KAR-MORE
               WHEN OTHER
                   MOVE 'N' TO KAR-MORE
                   ADD 1 TO KAR-ERRORS
           END-EVALUATE.
       4000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5000-END-BROWSE  -  release the transaction browse position.
      *----------------------------------------------------------------*
       5000-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-TRANFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  5500-ARCHIVE-SAVED  -  archive then delete each saved record.
      *----------------------------------------------------------------*
       5500-ARCHIVE-SAVED.
           PERFORM VARYING WS-SX FROM 1 BY 1
                   UNTIL WS-SX > WS-SAVE-CNT
               MOVE WS-SAVE-REC(WS-SX) TO TRAN-REC
               PERFORM 5600-ARCHIVE-ONE
           END-PERFORM.
      *----------------------------------------------------------------*
      *  5600-ARCHIVE-ONE  -  write the archive copy; only when that
      *  succeeds is the live record deleted.                          *
      *----------------------------------------------------------------*
       5600-ARCHIVE-ONE.
           EXEC CICS WRITE
                     FILE(WS-ARCHFILE)
                     FROM(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KAR-ARCHIVED
                   ADD TR-AMT TO KAR-ARCH-AMT
                   PERFORM 5700-DELETE-ONE
               WHEN DFHRESP(DUPREC)
                   PERFORM 5700-DELETE-ONE
               WHEN OTHER
                   ADD 1 TO KAR-ERRORS
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  5700-DELETE-ONE  -  remove the archived record from the live
      *  transaction file.                                             *
      *----------------------------------------------------------------*
       5700-DELETE-ONE.
           EXEC CICS DELETE
                     FILE(WS-TRANFILE)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KAR-DELETED
           ELSE
               ADD 1 TO KAR-ERRORS
           END-IF.
      *----------------------------------------------------------------*
      *  6000-SET-STATUS  -  publish the completion status and message.
      *----------------------------------------------------------------*
       6000-SET-STATUS.
           IF KAR-STATUS = '99'
               GO TO 6000-EXIT
           END-IF.
           IF KAR-READ = ZEROS
               MOVE '10' TO KAR-STATUS
               MOVE 'NO TRANSACTIONS PROCESSED' TO KAR-MSG
           ELSE
               MOVE '00' TO KAR-STATUS
               MOVE 'TRANSACTION ARCHIVE COMPLETE' TO KAR-MSG
           END-IF.
       6000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *                   E N D   O F   O U A R C H                    *
      *----------------------------------------------------------------*
