      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCACCTL  -  Account List (on-line)               *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: browse the account master (ACCTFILE) in key      *
      *            order and display a page of five accounts.  The  *
      *            operator may type a starting account id and      *
      *            press ENTER; PF8 pages forward through the file.  *
      *            PF3 = back to menu, PF4 = clear, ENTER = list.    *
      *  MAPSET  : MACCTL      MAP : MACCTLA     TRANID : ORLA       *
      *  FILES   : ACCTFILE (browse - STARTBR / READNEXT / ENDBR)   *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.      *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - account list with paging.      *
      *****************************************************************
      *  PROCESSING NARRATIVE                                        *
      *  1. On ENTER the operator-supplied start account id (or the  *
      *     start of file when blank) positions the browse.          *
      *  2. Up to five records are read forward and moved into the   *
      *     five display lines with id, status and current balance.  *
      *  3. The key that would begin the following page is saved in  *
      *     the commarea so PF8 can resume the browse there.         *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCACCTL.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCACCTL'.
           05  WS-TRANID            PIC X(04) VALUE 'ORLA'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Browse control and work fields.                               *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-PAGE-START        PIC 9(11) VALUE ZEROS.
           05  WS-NEXT-START        PIC 9(11) VALUE ZEROS.
           05  WS-LAST-KEY          PIC 9(11) VALUE ZEROS.
           05  WS-ROW-CNT           PIC 9(01) VALUE ZEROS.
           05  WS-MAX-ROWS          PIC 9(01) VALUE 5.
           05  WS-BROWSE-STARTED    PIC X(01) VALUE 'N'.
               88  WS-BR-ON                   VALUE 'Y'.
               88  WS-BR-OFF                  VALUE 'N'.
           05  WS-CNT-ED            PIC Z9.
      *----------------------------------------------------------------*
      *  Validation switch shared by the numeric parser.               *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Reusable numeric-field parser work area.                      *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(16) VALUE SPACES.
           05  WS-NC-LEN            PIC 9(02) VALUE ZEROS.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(16) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter start account id (or blank) and ENTER.'.
           05  WS-M-BAD-START       PIC X(50)
               VALUE 'Start account id must be numeric.'.
           05  WS-M-NONE-FOUND      PIC X(50)
               VALUE 'No accounts found from that point.'.
           05  WS-M-BROWSE-ERR      PIC X(50)
               VALUE 'Error browsing the account file.'.
           05  WS-M-END-FILE        PIC X(50)
               VALUE 'End of file - no more accounts.'.
           05  WS-M-SUFFIX          PIC X(30)
               VALUE ' account(s) displayed.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  File record layout and BMS symbolic map.                      *
      *----------------------------------------------------------------*
       COPY RACCT.
       COPY MACCTL.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  build and transmit a fresh empty screen.*
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MACCTLAO.
           PERFORM 8000-POPULATE-HEADER.
           PERFORM 3050-CLEAR-ROWS.
           MOVE ZEROS TO WS-NEXT-START.
           MOVE WS-NEXT-START TO CA-WORK-AREA(1:11).
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO FRACCTL.
           EXEC CICS SEND
                     MAP('MACCTLA')
                     MAPSET('MACCTL')
                     FROM(MACCTLAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHPF8
                   PERFORM 2200-PAGE-FWD
               WHEN DFHENTER
                   PERFORM 2100-LIST-FROM-START
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-LIST-FROM-START  -  ENTER pressed.  Receive the start    *
      *  account id, validate it and drive the browse.                 *
      *----------------------------------------------------------------*
       2100-LIST-FROM-START.
           EXEC CICS RECEIVE
                     MAP('MACCTLA')
                     MAPSET('MACCTL')
                     INTO(MACCTLAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MACCTLAI
           END-IF.
           MOVE FRACCTI TO WS-NC-IN.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-NC-IN = SPACES
               MOVE ZEROS TO WS-PAGE-START
           ELSE
               MOVE 11 TO WS-NC-LEN
               PERFORM 6000-PARSE-NUM
               IF WS-INVALID
                   MOVE WS-M-BAD-START TO ERRMSGO
                   MOVE -1 TO FRACCTL
                   PERFORM 8100-SEND-DATAONLY
                   GO TO 2100-EXIT
               END-IF
               MOVE WS-NC-VALUE TO WS-PAGE-START
           END-IF.
           PERFORM 3000-BROWSE-PAGE.
           PERFORM 2300-BUILD-SUMMARY.
           MOVE -1 TO FRACCTL.
           PERFORM 8100-SEND-DATAONLY.
       2100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2200-PAGE-FWD  -  PF8 pressed.  Resume the browse at the key  *
      *  saved from the previous page.                                 *
      *----------------------------------------------------------------*
       2200-PAGE-FWD.
           IF CA-WORK-AREA(1:11) NUMERIC
               MOVE CA-WORK-AREA(1:11) TO WS-PAGE-START
           ELSE
               MOVE ZEROS TO WS-PAGE-START
           END-IF.
           PERFORM 3000-BROWSE-PAGE.
           IF WS-ROW-CNT = ZEROS
               MOVE WS-M-END-FILE TO ERRMSGO
           ELSE
               PERFORM 2300-BUILD-SUMMARY
           END-IF.
           MOVE -1 TO FRACCTL.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  2300-BUILD-SUMMARY  -  compose the result-count message.      *
      *----------------------------------------------------------------*
       2300-BUILD-SUMMARY.
           IF WS-ROW-CNT = ZEROS
               MOVE WS-M-NONE-FOUND TO ERRMSGO
           ELSE
               MOVE WS-ROW-CNT TO WS-CNT-ED
               MOVE SPACES TO ERRMSGO
               STRING WS-CNT-ED   DELIMITED BY SIZE
                      WS-M-SUFFIX DELIMITED BY SIZE
                      INTO ERRMSGO
               END-STRING
           END-IF.
      *----------------------------------------------------------------*
      *  3000-BROWSE-PAGE  -  browse forward from WS-PAGE-START and
      *  collect up to five records.  The next-page key is preserved.  *
      *----------------------------------------------------------------*
       3000-BROWSE-PAGE.
           MOVE ZEROS TO WS-ROW-CNT.
           MOVE 'N'   TO WS-END-FLG.
           SET WS-BR-OFF TO TRUE.
           PERFORM 3050-CLEAR-ROWS.
           PERFORM 3100-START-BROWSE.
           IF WS-BR-ON
               PERFORM 3200-READ-NEXT
                   UNTIL END-OF-FILE
                      OR WS-ROW-CNT >= WS-MAX-ROWS
               PERFORM 3300-END-BROWSE
           END-IF.
           IF WS-ROW-CNT > ZEROS
               COMPUTE WS-NEXT-START = WS-LAST-KEY + 1
               MOVE WS-NEXT-START TO CA-WORK-AREA(1:11)
           END-IF.
      *----------------------------------------------------------------*
      *  3050-CLEAR-ROWS  -  blank the five display lines.             *
      *----------------------------------------------------------------*
       3050-CLEAR-ROWS.
           MOVE SPACES TO ACL1O ACS1O ACB1O.
           MOVE SPACES TO ACL2O ACS2O ACB2O.
           MOVE SPACES TO ACL3O ACS3O ACB3O.
           MOVE SPACES TO ACL4O ACS4O ACB4O.
           MOVE SPACES TO ACL5O ACS5O ACB5O.
      *----------------------------------------------------------------*
      *  3100-START-BROWSE  -  position at the requested account id.   *
      *----------------------------------------------------------------*
       3100-START-BROWSE.
           MOVE WS-PAGE-START TO AC-ID.
           EXEC CICS STARTBR
                     FILE(WS-ACCTFILE)
                     RIDFLD(AC-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-BR-ON TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET WS-BR-OFF TO TRUE
                   SET END-OF-FILE TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-BR-OFF TO TRUE
                   SET END-OF-FILE TO TRUE
               WHEN OTHER
                   SET WS-BR-OFF TO TRUE
                   SET END-OF-FILE TO TRUE
                   MOVE WS-M-BROWSE-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-READ-NEXT  -  read the next account and move it into the *
      *  next available display line.                                 *
      *----------------------------------------------------------------*
       3200-READ-NEXT.
           EXEC CICS READNEXT
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO WS-ROW-CNT
                   MOVE AC-ID TO WS-LAST-KEY
                   PERFORM 4000-MOVE-ROW
               WHEN DFHRESP(ENDFILE)
                   SET END-OF-FILE TO TRUE
               WHEN OTHER
                   SET END-OF-FILE TO TRUE
                   MOVE WS-M-BROWSE-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3300-END-BROWSE  -  release the browse position.             *
      *----------------------------------------------------------------*
       3300-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-ACCTFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  4000-MOVE-ROW  -  place the current account into the display  *
      *  line indicated by the running row counter.  The balance is    *
      *  edited through WS-ED-BAL and the leading pad byte dropped so  *
      *  it fits the fifteen-character map field.                      *
      *----------------------------------------------------------------*
       4000-MOVE-ROW.
           MOVE AC-CURR-BAL TO WS-ED-BAL.
           EVALUATE WS-ROW-CNT
               WHEN 1
                   MOVE AC-ID            TO ACL1O
                   MOVE AC-ACTIVE-STATUS TO ACS1O
                   MOVE WS-ED-BAL(2:15)  TO ACB1O
               WHEN 2
                   MOVE AC-ID            TO ACL2O
                   MOVE AC-ACTIVE-STATUS TO ACS2O
                   MOVE WS-ED-BAL(2:15)  TO ACB2O
               WHEN 3
                   MOVE AC-ID            TO ACL3O
                   MOVE AC-ACTIVE-STATUS TO ACS3O
                   MOVE WS-ED-BAL(2:15)  TO ACB3O
               WHEN 4
                   MOVE AC-ID            TO ACL4O
                   MOVE AC-ACTIVE-STATUS TO ACS4O
                   MOVE WS-ED-BAL(2:15)  TO ACB4O
               WHEN 5
                   MOVE AC-ID            TO ACL5O
                   MOVE AC-ACTIVE-STATUS TO ACS5O
                   MOVE WS-ED-BAL(2:15)  TO ACB5O
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6000-PARSE-NUM  -  scan WS-NC-IN for WS-NC-LEN characters,
      *  ignore spaces, accumulate digits into WS-NC-VALUE and count   *
      *  them.  Any other character makes the field invalid.           *
      *----------------------------------------------------------------*
       6000-PARSE-NUM.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > WS-NC-LEN
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.*
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  re-transmit the map data only.         *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MACCTLA')
                     MAPSET('MACCTL')
                     FROM(MACCTLAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to CICS.         *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
