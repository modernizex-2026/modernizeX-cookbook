      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUACTIN  -  Account Inquiry browse engine         *
      *  TYPE    : SUB  (VSAM browse)                                *
      *  FUNCTION: browse the account master (ACCTFILE) with         *
      *            STARTBR / READNEXT / ENDBR, apply the filter      *
      *            chosen on the OCACTIN screen and hand back one     *
      *            page (up to 13) of matching accounts together     *
      *            with the derived figures (available credit,       *
      *            utilisation) and page-level portfolio totals.     *
      *  CALL    : EXEC CICS LINK PROGRAM('OUACTIN')                 *
      *                COMMAREA(KACTIN-AREA) END-EXEC.               *
      *  INTERFACE: copybook KACTIN  (request + response + rows)     *
      *****************************************************************
      *  This one browse engine REPLACES the following batch print   *
      *  reports - each was a sequential ACCTFILE scan that produced *
      *  the very figures this sub now computes on demand:           *
      *    OBRDELQ  delinquent accounts    -> filter DELINQUENT      *
      *    OBRLIMIT over-limit accounts    -> filter OVER-LIMIT      *
      *    OBRDORM  dormant (no activity)  -> filter DORMANT         *
      *    OBRCLOSE closed / inactive      -> filter CLOSED          *
      *    OBRNEW   newly opened accounts  -> filter NEW             *
      *    OBRUTIL  high-utilisation band  -> filter HIGH-UTIL       *
      *    OBRAVAIL available credit list  -> AVAILABLE column       *
      *    OBRAGE   account aging by open  -> NEW / open-date test   *
      *    OBRINACT inactive accounts      -> DORMANT / CLOSED       *
      *    OBRACCT  full account listing   -> filter ALL             *
      *    OBRPORT  portfolio balance roll -> page balance totals    *
      *    OBRKPI   key indicators (count) -> matched / scanned      *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - consolidated account browse.   *
      *****************************************************************
      *  BUSINESS RULES APPLIED PER FILTER                           *
      *  ALL        every account on the file.                       *
      *  DELINQUENT carries a debit balance yet paid less this cycle *
      *             than the minimum due (2% of balance, floor 25).  *
      *  OVER-LIMIT current balance exceeds the credit limit.        *
      *  DORMANT    no credit and no debit posted this cycle.        *
      *  CLOSED     active status is not 'Y'.                        *
      *  NEW        opened within the last 90 days.                  *
      *  HIGH-UTIL  utilisation at or above 80% of the credit limit. *
      *  Derived for every row : available = limit - balance ;       *
      *  utilisation = balance / limit * 100 (guarded, capped 999).  *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUACTIN.
       AUTHOR.     ORION-CCMS-ONLINE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity.                                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUACTIN'.
           05  WS-MAX-ROWS          PIC 9(02) VALUE 13.
      *----------------------------------------------------------------*
      *  Browse control switches.                                      *
      *----------------------------------------------------------------*
       01  WS-BROWSE-FLAGS.
           05  WS-BR-END-SW         PIC X(01) VALUE 'N'.
               88  BR-END                     VALUE 'Y'.
               88  BR-MORE                    VALUE 'N'.
           05  WS-BR-STARTED-SW     PIC X(01) VALUE 'N'.
               88  BR-STARTED                 VALUE 'Y'.
               88  BR-NOT-STARTED             VALUE 'N'.
           05  WS-MATCH-SW          PIC X(01) VALUE 'N'.
               88  WS-MATCH                   VALUE 'Y'.
               88  WS-NOMATCH                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  Derived figures for the record currently in ACCT-REC.         *
      *----------------------------------------------------------------*
       01  WS-COMPUTE-FIELDS.
           05  WS-AVAIL             PIC S9(10)V99 VALUE ZEROS.
           05  WS-UTILR             PIC 9(03)V99  VALUE ZEROS.
           05  WS-UTIL-BIG          PIC 9(07)V99  VALUE ZEROS.
           05  WS-MIN-DUE           PIC S9(10)V99 VALUE ZEROS.
           05  WS-MIN-FLOOR         PIC S9(04)V99 VALUE 25.00.
           05  WS-LAST-MATCH        PIC 9(11)     VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Whole-population accumulators for the portfolio / KPI pass.   *
      *----------------------------------------------------------------*
       01  WS-KPI-ACC.
           05  WS-KPI-COUNT         PIC 9(09)     VALUE ZEROS.
           05  WS-KPI-BAL           PIC S9(15)V99 VALUE ZEROS.
           05  WS-KPI-AVL           PIC S9(15)V99 VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Date arithmetic work area for the NEW / aging test.           *
      *----------------------------------------------------------------*
       01  WS-DATE-WORK.
           05  WS-CDT               PIC X(21)     VALUE SPACES.
           05  WS-TODAY-N           PIC 9(08)     VALUE ZEROS.
           05  WS-TODAY-INT         PIC S9(09) COMP VALUE ZEROS.
           05  WS-CUT-INT           PIC S9(09) COMP VALUE ZEROS.
           05  WS-OPEN-PARTS.
               10  WO-YYYY          PIC 9(04)     VALUE ZEROS.
               10  WO-MM            PIC 9(02)     VALUE ZEROS.
               10  WO-DD            PIC 9(02)     VALUE ZEROS.
           05  WS-OPEN-N REDEFINES WS-OPEN-PARTS PIC 9(08).
           05  WS-OPEN-INT          PIC S9(09) COMP VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Shared constants / file names / edit fields.                  *
      *----------------------------------------------------------------*
       COPY WCONST.
      *----------------------------------------------------------------*
      *  Account record read forward from ACCTFILE.                    *
      *----------------------------------------------------------------*
       COPY RACCT.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
      *----------------------------------------------------------------*
      *  The single browse-interface area passed on LINK.             *
      *----------------------------------------------------------------*
       COPY KACTIN.
      *================================================================*
       PROCEDURE DIVISION USING KACTIN-AREA.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  top level driver.                              *
      *----------------------------------------------------------------*
       0000-MAIN.
           PERFORM 1000-INITIALISE.
           PERFORM 2000-COMPUTE-CUTOFF.
           PERFORM 3000-BROWSE-DRIVER.
           PERFORM 6000-COMPUTE-KPI.
           PERFORM 9000-FINALISE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INITIALISE  -  reset the response half of the commarea.  *
      *----------------------------------------------------------------*
       1000-INITIALISE.
           SET KAI-OK TO TRUE.
           MOVE ZEROS TO KAI-ROW-COUNT.
           MOVE ZEROS TO KAI-SCAN-COUNT.
           SET KAI-NO-MORE TO TRUE.
           MOVE ZEROS TO KAI-NEXT-KEY.
           MOVE ZEROS TO KAI-POP-COUNT.
           MOVE ZEROS TO KAI-POP-BAL-TOT.
           MOVE ZEROS TO KAI-POP-AVL-TOT.
           MOVE ZEROS TO WS-LAST-MATCH.
           SET BR-MORE TO TRUE.
           SET BR-NOT-STARTED TO TRUE.
      *----------------------------------------------------------------*
      *  2000-COMPUTE-CUTOFF  -  today and the 90-day NEW cut-off as   *
      *  integer day numbers so the compare is calendar-correct.       *
      *----------------------------------------------------------------*
       2000-COMPUTE-CUTOFF.
           MOVE FUNCTION CURRENT-DATE TO WS-CDT.
           MOVE WS-CDT(1:8) TO WS-TODAY-N.
           COMPUTE WS-TODAY-INT = FUNCTION INTEGER-OF-DATE(WS-TODAY-N).
           COMPUTE WS-CUT-INT = WS-TODAY-INT - 90.
      *----------------------------------------------------------------*
      *  3000-BROWSE-DRIVER  -  position the browse, read forward      *
      *  collecting matches, then decide whether more pages remain     *
      *  and stamp the resume key (last matched id + 1).               *
      *----------------------------------------------------------------*
       3000-BROWSE-DRIVER.
           PERFORM 3100-START-BROWSE.
           IF BR-STARTED
               PERFORM 3200-GATHER-PAGE
                   UNTIL BR-END
                      OR KAI-ROW-COUNT >= WS-MAX-ROWS
               IF BR-END
                   SET KAI-NO-MORE TO TRUE
               ELSE
                   SET KAI-MORE TO TRUE
               END-IF
               IF KAI-ROW-COUNT > 0
                   COMPUTE KAI-NEXT-KEY = WS-LAST-MATCH + 1
               END-IF
               PERFORM 3400-END-BROWSE
           END-IF.
      *----------------------------------------------------------------*
      *  3100-START-BROWSE  -  STARTBR at (or after) the resume key.   *
      *----------------------------------------------------------------*
       3100-START-BROWSE.
           MOVE KAI-START-KEY TO AC-ID.
           EXEC CICS STARTBR
                     FILE(WS-ACCTFILE)
                     RIDFLD(AC-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BR-STARTED TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET BR-END TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET BR-END TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KAI-ERROR TO TRUE
                   DISPLAY 'OUACTIN: STARTBR RESP=' WS-RESP-CD
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-GATHER-PAGE  -  read one account, count it, derive its   *
      *  figures, test it against the filter and keep it when matched. *
      *----------------------------------------------------------------*
       3200-GATHER-PAGE.
           EXEC CICS READNEXT
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KAI-SCAN-COUNT
                   PERFORM 4000-DERIVE-FIGURES
                   PERFORM 4500-APPLY-FILTER
                   IF WS-MATCH
                       PERFORM 5000-STORE-ROW
                   END-IF
               WHEN DFHRESP(ENDFILE)
                   SET BR-END TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KAI-ERROR TO TRUE
                   DISPLAY 'OUACTIN: READNEXT RESP=' WS-RESP-CD
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3400-END-BROWSE  -  release the browse if it was started.     *
      *----------------------------------------------------------------*
       3400-END-BROWSE.
           IF BR-STARTED
               EXEC CICS ENDBR
                         FILE(WS-ACCTFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
      *----------------------------------------------------------------*
      *  4000-DERIVE-FIGURES  -  available credit, utilisation band    *
      *  and the cycle minimum due for the current account record.     *
      *----------------------------------------------------------------*
       4000-DERIVE-FIGURES.
           COMPUTE WS-AVAIL = AC-CREDIT-LIMIT - AC-CURR-BAL.
           IF AC-CREDIT-LIMIT > 0 AND AC-CURR-BAL > 0
               COMPUTE WS-UTIL-BIG ROUNDED =
                   (AC-CURR-BAL * 100) / AC-CREDIT-LIMIT
               IF WS-UTIL-BIG > 999.99
                   MOVE 999.99 TO WS-UTILR
               ELSE
                   MOVE WS-UTIL-BIG TO WS-UTILR
               END-IF
           ELSE
               MOVE ZEROS TO WS-UTILR
           END-IF.
           COMPUTE WS-MIN-DUE ROUNDED = AC-CURR-BAL * 0.02.
           IF AC-CURR-BAL > 0 AND WS-MIN-DUE < WS-MIN-FLOOR
               MOVE WS-MIN-FLOOR TO WS-MIN-DUE
           END-IF.
      *----------------------------------------------------------------*
      *  4500-APPLY-FILTER  -  route to the individual selection tests.*
      *----------------------------------------------------------------*
       4500-APPLY-FILTER.
           SET WS-NOMATCH TO TRUE.
           EVALUATE TRUE
               WHEN KAI-F-ALL
                   PERFORM 4510-TEST-ALL
               WHEN KAI-F-DELINQ
                   PERFORM 4520-TEST-DELINQ
               WHEN KAI-F-OVERLMT
                   PERFORM 4530-TEST-OVERLMT
               WHEN KAI-F-DORMANT
                   PERFORM 4540-TEST-DORMANT
               WHEN KAI-F-CLOSED
                   PERFORM 4550-TEST-CLOSED
               WHEN KAI-F-NEW
                   PERFORM 4560-TEST-NEW
               WHEN KAI-F-HIGHUTL
                   PERFORM 4570-TEST-HIGHUTL
               WHEN OTHER
                   PERFORM 4510-TEST-ALL
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4510-TEST-ALL  -  unconditional match (OBRACCT listing).      *
      *----------------------------------------------------------------*
       4510-TEST-ALL.
           SET WS-MATCH TO TRUE.
      *----------------------------------------------------------------*
      *  4520-TEST-DELINQ  -  balance owed but paid under the minimum  *
      *  due this cycle (OBRDELQ).                                     *
      *----------------------------------------------------------------*
       4520-TEST-DELINQ.
           IF AC-CURR-BAL > 0
              AND AC-CYC-CREDIT < WS-MIN-DUE
               SET WS-MATCH TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  4530-TEST-OVERLMT  -  balance above the credit limit          *
      *  (OBRLIMIT).                                                   *
      *----------------------------------------------------------------*
       4530-TEST-OVERLMT.
           IF AC-CURR-BAL > AC-CREDIT-LIMIT
               SET WS-MATCH TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  4540-TEST-DORMANT  -  no cycle activity either side (OBRDORM).*
      *----------------------------------------------------------------*
       4540-TEST-DORMANT.
           IF AC-CYC-CREDIT = 0
              AND AC-CYC-DEBIT = 0
               SET WS-MATCH TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  4550-TEST-CLOSED  -  active status not 'Y' (OBRCLOSE).       *
      *----------------------------------------------------------------*
       4550-TEST-CLOSED.
           IF AC-ACTIVE-STATUS NOT = 'Y'
               SET WS-MATCH TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  4560-TEST-NEW  -  opened within the last 90 days (OBRNEW /    *
      *  OBRAGE).  Bad dates are simply not selected.                  *
      *----------------------------------------------------------------*
       4560-TEST-NEW.
           IF AC-OPEN-DATE(1:4) NUMERIC
              AND AC-OPEN-DATE(6:2) NUMERIC
              AND AC-OPEN-DATE(9:2) NUMERIC
               MOVE AC-OPEN-DATE(1:4) TO WO-YYYY
               MOVE AC-OPEN-DATE(6:2) TO WO-MM
               MOVE AC-OPEN-DATE(9:2) TO WO-DD
               COMPUTE WS-OPEN-INT =
                   FUNCTION INTEGER-OF-DATE(WS-OPEN-N)
               IF WS-OPEN-INT >= WS-CUT-INT
                   SET WS-MATCH TO TRUE
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  4570-TEST-HIGHUTL  -  utilisation at or above 80% (OBRUTIL).  *
      *----------------------------------------------------------------*
       4570-TEST-HIGHUTL.
           IF WS-UTILR >= 80.00
               SET WS-MATCH TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  5000-STORE-ROW  -  copy the matched account into the next     *
      *  page row and accumulate the page portfolio totals.            *
      *----------------------------------------------------------------*
       5000-STORE-ROW.
           ADD 1 TO KAI-ROW-COUNT.
           MOVE AC-ID            TO KAI-R-ID(KAI-ROW-COUNT).
           MOVE AC-ACTIVE-STATUS TO KAI-R-STATUS(KAI-ROW-COUNT).
           MOVE AC-CURR-BAL      TO KAI-R-BAL(KAI-ROW-COUNT).
           MOVE AC-CREDIT-LIMIT  TO KAI-R-LIMIT(KAI-ROW-COUNT).
           MOVE WS-AVAIL         TO KAI-R-AVAIL(KAI-ROW-COUNT).
           MOVE WS-UTILR         TO KAI-R-UTIL(KAI-ROW-COUNT).
           MOVE AC-ID            TO WS-LAST-MATCH.
      *----------------------------------------------------------------*
      *  6000-COMPUTE-KPI  -  when the screen asks (first page only),  *
      *  scan the WHOLE file for the same filter and roll up the       *
      *  portfolio balance, available credit and matched count.  This  *
      *  is the population figure the OBRPORT / OBRKPI batch reports   *
      *  produced; on a page-forward the flag is off and the extra     *
      *  pass is skipped (the screen carries the figures forward).     *
      *----------------------------------------------------------------*
       6000-COMPUTE-KPI.
           IF KAI-DO-KPI
               MOVE ZEROS TO WS-KPI-COUNT
               MOVE ZEROS TO WS-KPI-BAL
               MOVE ZEROS TO WS-KPI-AVL
               PERFORM 6100-KPI-START
               IF BR-STARTED
                   PERFORM 6200-KPI-READ
                       UNTIL BR-END
                   PERFORM 6300-KPI-END
               END-IF
               MOVE WS-KPI-COUNT TO KAI-POP-COUNT
               MOVE WS-KPI-BAL   TO KAI-POP-BAL-TOT
               MOVE WS-KPI-AVL   TO KAI-POP-AVL-TOT
           END-IF.
      *----------------------------------------------------------------*
      *  6100-KPI-START  -  position at the top of the file.           *
      *----------------------------------------------------------------*
       6100-KPI-START.
           SET BR-MORE TO TRUE.
           SET BR-NOT-STARTED TO TRUE.
           MOVE ZEROS TO AC-ID.
           EXEC CICS STARTBR
                     FILE(WS-ACCTFILE)
                     RIDFLD(AC-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BR-STARTED TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6200-KPI-READ  -  read forward, filter and accumulate.        *
      *----------------------------------------------------------------*
       6200-KPI-READ.
           EXEC CICS READNEXT
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   PERFORM 4000-DERIVE-FIGURES
                   PERFORM 4500-APPLY-FILTER
                   IF WS-MATCH
                       ADD 1 TO WS-KPI-COUNT
                       ADD AC-CURR-BAL TO WS-KPI-BAL
                       ADD WS-AVAIL    TO WS-KPI-AVL
                   END-IF
               WHEN OTHER
                   SET BR-END TO TRUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6300-KPI-END  -  release the population browse.               *
      *----------------------------------------------------------------*
       6300-KPI-END.
           EXEC CICS ENDBR
                     FILE(WS-ACCTFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-FINALISE  -  confirm the return code and log a trace.    *
      *----------------------------------------------------------------*
       9000-FINALISE.
           IF KAI-ERROR
               CONTINUE
           ELSE
               SET KAI-OK TO TRUE
           END-IF.
           DISPLAY 'OUACTIN: filter ' KAI-FILTER
                   ' matched ' KAI-ROW-COUNT
                   ' scanned ' KAI-SCAN-COUNT.
