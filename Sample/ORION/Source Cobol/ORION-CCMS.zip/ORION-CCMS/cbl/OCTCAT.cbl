      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCTCAT   -  Transaction Category Maintenance     *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: maintain the transaction-category reference file  *
      *            (TCATFILE).  The key is the type code plus a       *
      *            four-digit category code.  ENTER reads a key and   *
      *            shows its description or reports that it is new;    *
      *            PF5 saves - a REWRITE when the key already exists,  *
      *            otherwise a WRITE.                                 *
      *            PF3 = back to menu, PF4 = clear, ENTER = read,     *
      *            PF5 = save.                                        *
      *  MAPSET  : MTCAT       MAP : MTCATA      TRANID : ORTC       *
      *  FILES   : TCATFILE (read / write / rewrite)                *
      *  STATE   : held in CA-WORK-AREA(1:1)  'K'/'E'/'N'           *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.      *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - tran category maintenance.    *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCTCAT.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCTCAT'.
           05  WS-TRANID            PIC X(04) VALUE 'ORTC'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Validation switch and state constants.                        *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
       01  WS-STATE-CONST.
           05  WS-ST-KEY            PIC X(01) VALUE 'K'.
           05  WS-ST-EXIST          PIC X(01) VALUE 'E'.
           05  WS-ST-NEW            PIC X(01) VALUE 'N'.
      *----------------------------------------------------------------*
      *  Saved key work fields.                                        *
      *----------------------------------------------------------------*
       01  WS-KEY-FIELDS.
           05  WS-TC-TYPE           PIC X(02) VALUE SPACES.
           05  WS-TC-CD             PIC 9(04) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Reusable numeric-field parser work area.                      *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(16) VALUE SPACES.
           05  WS-NC-LEN            PIC 9(02) VALUE ZEROS.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(16) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Category code edit field for display.                         *
      *----------------------------------------------------------------*
       01  WS-CD-ED                 PIC 9(04) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter type + category code and press ENTER.'.
           05  WS-M-TYPE-REQ        PIC X(50)
               VALUE 'Type code is required.'.
           05  WS-M-CD-NUM          PIC X(50)
               VALUE 'Category code must be numeric.'.
           05  WS-M-DESC-REQ        PIC X(50)
               VALUE 'Description is required.'.
           05  WS-M-FOUND           PIC X(50)
               VALUE 'Category found. Change text, PF5 to update.'.
           05  WS-M-NEW             PIC X(50)
               VALUE 'New category. Enter text, PF5 to add.'.
           05  WS-M-KEY-FIRST       PIC X(50)
               VALUE 'Enter the key and press ENTER first.'.
           05  WS-M-ADDED           PIC X(50)
               VALUE 'Transaction category added.'.
           05  WS-M-UPDATED         PIC X(50)
               VALUE 'Transaction category updated.'.
           05  WS-M-SAVE-ERR        PIC X(50)
               VALUE 'Error saving the transaction category.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  File record layout and BMS symbolic map.                      *
      *----------------------------------------------------------------*
       COPY RTCAT.
       COPY MTCAT.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  clear the map and prompt for a key.     *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MTCATAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-ST-KEY TO CA-WORK-AREA(1:1).
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO TCTYPEL.
           EXEC CICS SEND
                     MAP('MTCATA')
                     MAPSET('MTCAT')
                     FROM(MTCATAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHPF5
                   PERFORM 2300-SAVE
               WHEN DFHENTER
                   PERFORM 2100-LOOKUP
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2050-RECEIVE  -  read the map; treat MAPFAIL as empty input.  *
      *----------------------------------------------------------------*
       2050-RECEIVE.
           EXEC CICS RECEIVE
                     MAP('MTCATA')
                     MAPSET('MTCAT')
                     INTO(MTCATAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MTCATAI
           END-IF.
      *----------------------------------------------------------------*
      *  2100-LOOKUP  -  ENTER pressed.  Validate the key and open it  *
      *  for maintenance, distinguishing existing from new.            *
      *----------------------------------------------------------------*
       2100-LOOKUP.
           PERFORM 2050-RECEIVE.
           PERFORM 6100-VALIDATE-KEY.
           IF WS-INVALID
               MOVE -1 TO TCTYPEL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 3000-READ-TCAT
               MOVE WS-TC-TYPE TO TCTYPEO
               MOVE WS-TC-CD   TO WS-CD-ED
               MOVE WS-CD-ED   TO TCCDO
               IF REC-FOUND
                   MOVE TC-DESC TO TCDESCO
                   MOVE WS-ST-EXIST TO CA-WORK-AREA(1:1)
                   MOVE WS-M-FOUND TO ERRMSGO
               ELSE
                   MOVE SPACES TO TCDESCO
                   MOVE WS-ST-NEW TO CA-WORK-AREA(1:1)
                   MOVE WS-M-NEW TO ERRMSGO
               END-IF
               MOVE -1 TO TCDESCL
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  2300-SAVE  -  PF5 pressed.  Validate the description then
      *  add or update the record according to the saved state.        *
      *----------------------------------------------------------------*
       2300-SAVE.
           IF CA-WORK-AREA(1:1) NOT = WS-ST-EXIST
              AND CA-WORK-AREA(1:1) NOT = WS-ST-NEW
               MOVE WS-M-KEY-FIRST TO ERRMSGO
               MOVE -1 TO TCTYPEL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 2050-RECEIVE
               PERFORM 6100-VALIDATE-KEY
               IF WS-INVALID
                   MOVE -1 TO TCTYPEL
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   IF TCDESCI = SPACES OR TCDESCI = LOW-VALUES
                       MOVE WS-M-DESC-REQ TO ERRMSGO
                       MOVE -1 TO TCDESCL
                       PERFORM 8100-SEND-DATAONLY
                   ELSE
                       IF CA-WORK-AREA(1:1) = WS-ST-EXIST
                           PERFORM 3500-UPDATE-TCAT
                       ELSE
                           PERFORM 3600-ADD-TCAT
                       END-IF
                       PERFORM 8100-SEND-DATAONLY
                   END-IF
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3000-READ-TCAT  -  random read of TCATFILE by TC-KEY.        *
      *----------------------------------------------------------------*
       3000-READ-TCAT.
           SET REC-NOT-FOUND TO TRUE.
           MOVE WS-TC-TYPE TO TC-TYPE-CD.
           MOVE WS-TC-CD   TO TC-CD.
           EXEC CICS READ
                     FILE(WS-TCATFILE)
                     INTO(TCAT-REC)
                     RIDFLD(TC-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3500-UPDATE-TCAT  -  READ UPDATE and REWRITE the record.     *
      *----------------------------------------------------------------*
       3500-UPDATE-TCAT.
           MOVE WS-TC-TYPE TO TC-TYPE-CD.
           MOVE WS-TC-CD   TO TC-CD.
           EXEC CICS READ
                     FILE(WS-TCATFILE)
                     INTO(TCAT-REC)
                     RIDFLD(TC-KEY)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE TCDESCI TO TC-DESC
                   EXEC CICS REWRITE
                             FILE(WS-TCATFILE)
                             FROM(TCAT-REC)
                             RESP(WS-RESP-CD)
                   END-EXEC
                   IF WS-RESP-CD = DFHRESP(NORMAL)
                       MOVE WS-M-UPDATED TO ERRMSGO
                   ELSE
                       MOVE WS-M-SAVE-ERR TO ERRMSGO
                   END-IF
               WHEN DFHRESP(NOTFND)
                   PERFORM 3600-ADD-TCAT
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3600-ADD-TCAT  -  build TCAT-REC and write a new record.     *
      *----------------------------------------------------------------*
       3600-ADD-TCAT.
           INITIALIZE TCAT-REC.
           MOVE WS-TC-TYPE TO TC-TYPE-CD.
           MOVE WS-TC-CD   TO TC-CD.
           MOVE TCDESCI    TO TC-DESC.
           EXEC CICS WRITE
                     FILE(WS-TCATFILE)
                     FROM(TCAT-REC)
                     RIDFLD(TC-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE WS-M-ADDED TO ERRMSGO
                   MOVE WS-ST-EXIST TO CA-WORK-AREA(1:1)
               WHEN DFHRESP(DUPREC)
                   MOVE WS-M-SAVE-ERR TO ERRMSGO
               WHEN OTHER
                   MOVE WS-M-SAVE-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6100-VALIDATE-KEY  -  type code required, category numeric.   *
      *----------------------------------------------------------------*
       6100-VALIDATE-KEY.
           SET WS-VALID TO TRUE.
           MOVE SPACES TO ERRMSGO.
           IF TCTYPEI = SPACES OR TCTYPEI = LOW-VALUES
               SET WS-INVALID TO TRUE
               MOVE WS-M-TYPE-REQ TO ERRMSGO
               GO TO 6100-EXIT
           END-IF.
           MOVE TCTYPEI TO WS-TC-TYPE.
           INSPECT WS-TC-TYPE REPLACING ALL LOW-VALUE BY SPACE.
           MOVE TCCDI TO WS-NC-IN.
           MOVE 4 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-DIGITS > 4
               SET WS-INVALID TO TRUE
               MOVE WS-M-CD-NUM TO ERRMSGO
           ELSE
               MOVE WS-NC-VALUE TO WS-TC-CD
           END-IF.
       6100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  6000-PARSE-NUM  -  scan WS-NC-IN for WS-NC-LEN characters,
      *  ignore spaces, accumulate digits and count them.              *
      *----------------------------------------------------------------*
       6000-PARSE-NUM.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > WS-NC-LEN
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.*
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  refresh header and resend the map.     *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MTCATA')
                     MAPSET('MTCAT')
                     FROM(MTCATAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to this tran.    *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9500-ABEND-RTN  -  unrecoverable file error - inform and end. *
      *----------------------------------------------------------------*
       9500-ABEND-RTN.
           MOVE 'OCTCAT: unrecoverable file error. Contact support.'
               TO WS-MSG-TEXT.
           EXEC CICS SEND TEXT
                     FROM(WS-MSG-TEXT)
                     LENGTH(LENGTH OF WS-MSG-TEXT)
                     ERASE
                     FREEKB
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS RETURN
                     RESP(WS-RESP-CD)
           END-EXEC.
