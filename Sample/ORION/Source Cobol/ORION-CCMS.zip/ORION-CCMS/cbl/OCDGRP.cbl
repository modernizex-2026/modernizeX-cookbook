      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCDGRP   -  Disclosure Group Maintenance         *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: maintain the disclosure/interest group file       *
      *            (DGRPFILE).  The key is the account group plus a   *
      *            transaction type code plus a four-digit category   *
      *            code; the record holds the annual interest rate.   *
      *            ENTER reads a key and shows its rate or reports    *
      *            that it is new; PF5 saves - a REWRITE when the key  *
      *            already exists, otherwise a WRITE.                 *
      *            PF3 = back to menu, PF4 = clear, ENTER = read,     *
      *            PF5 = save.                                        *
      *  MAPSET  : MDGRP       MAP : MDGRPA      TRANID : ORDG       *
      *  FILES   : DGRPFILE (read / write / rewrite)                *
      *  STATE   : held in CA-WORK-AREA(1:1)  'K'/'E'/'N'           *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.      *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - disclosure group maintenance. *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCDGRP.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCDGRP'.
           05  WS-TRANID            PIC X(04) VALUE 'ORDG'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Validation switch and state constants.                        *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
       01  WS-STATE-CONST.
           05  WS-ST-KEY            PIC X(01) VALUE 'K'.
           05  WS-ST-EXIST          PIC X(01) VALUE 'E'.
           05  WS-ST-NEW            PIC X(01) VALUE 'N'.
      *----------------------------------------------------------------*
      *  Saved key work fields and staged rate value.                  *
      *----------------------------------------------------------------*
       01  WS-KEY-FIELDS.
           05  WS-DG-GROUP          PIC X(10) VALUE SPACES.
           05  WS-DG-TYPE           PIC X(02) VALUE SPACES.
           05  WS-DG-CAT            PIC 9(04) VALUE ZEROS.
           05  WS-NEW-RATE          PIC S9(04)V99 VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Reusable numeric-field parser work area.                      *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(16) VALUE SPACES.
           05  WS-NC-LEN            PIC 9(02) VALUE ZEROS.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(16) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Rate parser work area and display edit field.                 *
      *----------------------------------------------------------------*
       01  WS-RATE-EDIT.
           05  WS-RE-IN             PIC X(07) VALUE SPACES.
           05  WS-RE-POS            PIC 9(02) VALUE ZEROS.
           05  WS-RE-CHAR           PIC X(01) VALUE SPACES.
           05  WS-RE-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-RE-INT            PIC 9(04) VALUE ZEROS.
           05  WS-RE-INT-CNT        PIC 9(02) VALUE ZEROS.
           05  WS-RE-FRAC           PIC 9(02) VALUE ZEROS.
           05  WS-RE-FRAC-CNT       PIC 9(01) VALUE ZEROS.
           05  WS-RE-DOT-SW         PIC X(01) VALUE 'N'.
           05  WS-RE-RESULT         PIC S9(04)V99 VALUE ZEROS.
       01  WS-CAT-ED                PIC 9(04) VALUE ZEROS.
       01  WS-RATE-ED               PIC ZZZ9.99.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter group, type, category and press ENTER.'.
           05  WS-M-GRP-REQ         PIC X(50)
               VALUE 'Account group id is required.'.
           05  WS-M-TYPE-REQ        PIC X(50)
               VALUE 'Type code is required.'.
           05  WS-M-CAT-NUM         PIC X(50)
               VALUE 'Category code must be numeric.'.
           05  WS-M-RATE-BAD        PIC X(50)
               VALUE 'Interest rate is not a valid number.'.
           05  WS-M-FOUND           PIC X(50)
               VALUE 'Group found. Change rate, PF5 to update.'.
           05  WS-M-NEW             PIC X(50)
               VALUE 'New group. Enter rate, PF5 to add.'.
           05  WS-M-KEY-FIRST       PIC X(50)
               VALUE 'Enter the key and press ENTER first.'.
           05  WS-M-ADDED           PIC X(50)
               VALUE 'Disclosure group added.'.
           05  WS-M-UPDATED         PIC X(50)
               VALUE 'Disclosure group updated.'.
           05  WS-M-SAVE-ERR        PIC X(50)
               VALUE 'Error saving the disclosure group.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  File record layout and BMS symbolic map.                      *
      *----------------------------------------------------------------*
       COPY RDGRP.
       COPY MDGRP.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  clear the map and prompt for a key.     *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MDGRPAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-ST-KEY TO CA-WORK-AREA(1:1).
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO DGGRPL.
           EXEC CICS SEND
                     MAP('MDGRPA')
                     MAPSET('MDGRP')
                     FROM(MDGRPAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHPF5
                   PERFORM 2300-SAVE
               WHEN DFHENTER
                   PERFORM 2100-LOOKUP
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2050-RECEIVE  -  read the map; treat MAPFAIL as empty input.  *
      *----------------------------------------------------------------*
       2050-RECEIVE.
           EXEC CICS RECEIVE
                     MAP('MDGRPA')
                     MAPSET('MDGRP')
                     INTO(MDGRPAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MDGRPAI
           END-IF.
      *----------------------------------------------------------------*
      *  2100-LOOKUP  -  ENTER pressed.  Validate the key and open it  *
      *  for maintenance, distinguishing existing from new.            *
      *----------------------------------------------------------------*
       2100-LOOKUP.
           PERFORM 2050-RECEIVE.
           PERFORM 6100-VALIDATE-KEY.
           IF WS-INVALID
               MOVE -1 TO DGGRPL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 3000-READ-DGRP
               MOVE WS-DG-GROUP TO DGGRPO
               MOVE WS-DG-TYPE  TO DGTYPEO
               MOVE WS-DG-CAT   TO WS-CAT-ED
               MOVE WS-CAT-ED   TO DGCATO
               IF REC-FOUND
                   MOVE DG-INT-RATE TO WS-RATE-ED
                   MOVE WS-RATE-ED  TO DGRATEO
                   MOVE WS-ST-EXIST TO CA-WORK-AREA(1:1)
                   MOVE WS-M-FOUND TO ERRMSGO
               ELSE
                   MOVE SPACES TO DGRATEO
                   MOVE WS-ST-NEW TO CA-WORK-AREA(1:1)
                   MOVE WS-M-NEW TO ERRMSGO
               END-IF
               MOVE -1 TO DGRATEL
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  2300-SAVE  -  PF5 pressed.  Validate the key and rate then
      *  add or update the record according to the saved state.
      *----------------------------------------------------------------*
       2300-SAVE.
           IF CA-WORK-AREA(1:1) NOT = WS-ST-EXIST
              AND CA-WORK-AREA(1:1) NOT = WS-ST-NEW
               MOVE WS-M-KEY-FIRST TO ERRMSGO
               MOVE -1 TO DGGRPL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 2050-RECEIVE
               PERFORM 6100-VALIDATE-KEY
               IF WS-INVALID
                   MOVE -1 TO DGGRPL
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   PERFORM 6200-VALIDATE-RATE
                   IF WS-INVALID
                       MOVE -1 TO DGRATEL
                       PERFORM 8100-SEND-DATAONLY
                   ELSE
                       IF CA-WORK-AREA(1:1) = WS-ST-EXIST
                           PERFORM 3500-UPDATE-DGRP
                       ELSE
                           PERFORM 3600-ADD-DGRP
                       END-IF
                       PERFORM 8100-SEND-DATAONLY
                   END-IF
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3000-READ-DGRP  -  random read of DGRPFILE by DG-KEY.        *
      *----------------------------------------------------------------*
       3000-READ-DGRP.
           SET REC-NOT-FOUND TO TRUE.
           MOVE WS-DG-GROUP TO DG-ACCT-GROUP.
           MOVE WS-DG-TYPE  TO DG-TYPE-CD.
           MOVE WS-DG-CAT   TO DG-CAT-CD.
           EXEC CICS READ
                     FILE(WS-DGRPFILE)
                     INTO(DGRP-REC)
                     RIDFLD(DG-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3500-UPDATE-DGRP  -  READ UPDATE and REWRITE the record.     *
      *----------------------------------------------------------------*
       3500-UPDATE-DGRP.
           MOVE WS-DG-GROUP TO DG-ACCT-GROUP.
           MOVE WS-DG-TYPE  TO DG-TYPE-CD.
           MOVE WS-DG-CAT   TO DG-CAT-CD.
           EXEC CICS READ
                     FILE(WS-DGRPFILE)
                     INTO(DGRP-REC)
                     RIDFLD(DG-KEY)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE WS-NEW-RATE TO DG-INT-RATE
                   EXEC CICS REWRITE
                             FILE(WS-DGRPFILE)
                             FROM(DGRP-REC)
                             RESP(WS-RESP-CD)
                   END-EXEC
                   IF WS-RESP-CD = DFHRESP(NORMAL)
                       MOVE WS-M-UPDATED TO ERRMSGO
                   ELSE
                       MOVE WS-M-SAVE-ERR TO ERRMSGO
                   END-IF
               WHEN DFHRESP(NOTFND)
                   PERFORM 3600-ADD-DGRP
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3600-ADD-DGRP  -  build DGRP-REC and write a new record.     *
      *----------------------------------------------------------------*
       3600-ADD-DGRP.
           INITIALIZE DGRP-REC.
           MOVE WS-DG-GROUP TO DG-ACCT-GROUP.
           MOVE WS-DG-TYPE  TO DG-TYPE-CD.
           MOVE WS-DG-CAT   TO DG-CAT-CD.
           MOVE WS-NEW-RATE TO DG-INT-RATE.
           EXEC CICS WRITE
                     FILE(WS-DGRPFILE)
                     FROM(DGRP-REC)
                     RIDFLD(DG-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE WS-M-ADDED TO ERRMSGO
                   MOVE WS-ST-EXIST TO CA-WORK-AREA(1:1)
               WHEN DFHRESP(DUPREC)
                   MOVE WS-M-SAVE-ERR TO ERRMSGO
               WHEN OTHER
                   MOVE WS-M-SAVE-ERR TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  6100-VALIDATE-KEY  -  group and type required, category       *
      *  numeric.                                                     *
      *----------------------------------------------------------------*
       6100-VALIDATE-KEY.
           SET WS-VALID TO TRUE.
           MOVE SPACES TO ERRMSGO.
           IF DGGRPI = SPACES OR DGGRPI = LOW-VALUES
               SET WS-INVALID TO TRUE
               MOVE WS-M-GRP-REQ TO ERRMSGO
               GO TO 6100-EXIT
           END-IF.
           MOVE DGGRPI TO WS-DG-GROUP.
           INSPECT WS-DG-GROUP REPLACING ALL LOW-VALUE BY SPACE.
           IF DGTYPEI = SPACES OR DGTYPEI = LOW-VALUES
               SET WS-INVALID TO TRUE
               MOVE WS-M-TYPE-REQ TO ERRMSGO
               GO TO 6100-EXIT
           END-IF.
           MOVE DGTYPEI TO WS-DG-TYPE.
           INSPECT WS-DG-TYPE REPLACING ALL LOW-VALUE BY SPACE.
           MOVE DGCATI TO WS-NC-IN.
           MOVE 4 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-DIGITS > 4
               SET WS-INVALID TO TRUE
               MOVE WS-M-CAT-NUM TO ERRMSGO
           ELSE
               MOVE WS-NC-VALUE TO WS-DG-CAT
           END-IF.
       6100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  6200-VALIDATE-RATE  -  parse the interest rate into a         *
      *  signed 4v2 value.                                            *
      *----------------------------------------------------------------*
       6200-VALIDATE-RATE.
           MOVE DGRATEI TO WS-RE-IN.
           PERFORM 6300-PARSE-RATE.
           IF WS-INVALID
               MOVE WS-M-RATE-BAD TO ERRMSGO
           ELSE
               MOVE WS-RE-RESULT TO WS-NEW-RATE
           END-IF.
      *----------------------------------------------------------------*
      *  6300-PARSE-RATE  -  parse WS-RE-IN into WS-RE-RESULT.  Accepts
      *  digits, ignores spaces, allows one dot with up to two         *
      *  fraction digits and up to four integer digits.               *
      *----------------------------------------------------------------*
       6300-PARSE-RATE.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-RE-INT WS-RE-INT-CNT.
           MOVE ZEROS TO WS-RE-FRAC WS-RE-FRAC-CNT.
           MOVE 'N' TO WS-RE-DOT-SW.
           MOVE ZEROS TO WS-RE-RESULT.
           INSPECT WS-RE-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-RE-IN = SPACES
               SET WS-INVALID TO TRUE
               GO TO 6300-EXIT
           END-IF.
           PERFORM VARYING WS-RE-POS FROM 1 BY 1
                   UNTIL WS-RE-POS > 7
               MOVE WS-RE-IN(WS-RE-POS:1) TO WS-RE-CHAR
               EVALUATE TRUE
                   WHEN WS-RE-CHAR = SPACE
                       CONTINUE
                   WHEN WS-RE-CHAR = '.'
                       IF WS-RE-DOT-SW = 'Y'
                           SET WS-INVALID TO TRUE
                       ELSE
                           MOVE 'Y' TO WS-RE-DOT-SW
                       END-IF
                   WHEN WS-RE-CHAR >= '0' AND WS-RE-CHAR <= '9'
                       PERFORM 6350-ACCUM-DIGIT
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-RE-FRAC-CNT = 1
               COMPUTE WS-RE-FRAC = WS-RE-FRAC * 10
           END-IF.
           COMPUTE WS-RE-RESULT = WS-RE-INT + (WS-RE-FRAC / 100).
       6300-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  6350-ACCUM-DIGIT  -  fold one digit into the integer or       *
      *  fraction accumulator depending on the decimal-point switch.   *
      *----------------------------------------------------------------*
       6350-ACCUM-DIGIT.
           MOVE WS-RE-CHAR TO WS-RE-DIGIT.
           IF WS-RE-DOT-SW = 'Y'
               ADD 1 TO WS-RE-FRAC-CNT
               IF WS-RE-FRAC-CNT > 2
                   SET WS-INVALID TO TRUE
               ELSE
                   COMPUTE WS-RE-FRAC = WS-RE-FRAC * 10 + WS-RE-DIGIT
               END-IF
           ELSE
               ADD 1 TO WS-RE-INT-CNT
               IF WS-RE-INT-CNT > 4
                   SET WS-INVALID TO TRUE
               ELSE
                   COMPUTE WS-RE-INT = WS-RE-INT * 10 + WS-RE-DIGIT
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  6000-PARSE-NUM  -  scan WS-NC-IN for WS-NC-LEN characters,
      *  ignore spaces, accumulate digits and count them.              *
      *----------------------------------------------------------------*
       6000-PARSE-NUM.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > WS-NC-LEN
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.*
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  refresh header and resend the map.     *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MDGRPA')
                     MAPSET('MDGRP')
                     FROM(MDGRPAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to this tran.    *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9500-ABEND-RTN  -  unrecoverable file error - inform and end. *
      *----------------------------------------------------------------*
       9500-ABEND-RTN.
           MOVE 'OCDGRP: unrecoverable file error. Contact support.'
               TO WS-MSG-TEXT.
           EXEC CICS SEND TEXT
                     FROM(WS-MSG-TEXT)
                     LENGTH(LENGTH OF WS-MSG-TEXT)
                     ERASE
                     FREEKB
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS RETURN
                     RESP(WS-RESP-CD)
           END-EXEC.
