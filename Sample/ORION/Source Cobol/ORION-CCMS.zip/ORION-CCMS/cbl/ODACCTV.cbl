      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : ODACCTV  -  Account View (on-line, DB2)           *
      *  TYPE    : CICS ONLINE + DB2  (pseudo-conversational)        *
      *  FUNCTION: accept an account id, SELECT the account row from *
      *            the ACCT table (ORION.ACCT) via EXEC SQL and      *
      *            display the account details on map MACCTV.        *
      *            PF3 = back to menu, PF4 = clear, ENTER = read.    *
      *  NOTE    : DB2 variant of the golden OCACCTV online program. *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. ODACCTV.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'ODACCTV'.
           05  WS-TRANID            PIC X(04) VALUE 'OD01'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  DB2 communication area.                                       *
      *----------------------------------------------------------------*
           EXEC SQL INCLUDE SQLCA END-EXEC.
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RACCT.
       COPY MACCTV.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MACCTVAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter account id and press ENTER.' TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MACCTVA')
                     MAPSET('MACCTV')
                     FROM(MACCTVAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-READ-AND-SHOW
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
       2100-READ-AND-SHOW.
           EXEC CICS RECEIVE
                     MAP('MACCTVA')
                     MAPSET('MACCTV')
                     INTO(MACCTVAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF ACCTIDI = SPACES OR ACCTIDI = LOW-VALUES
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               IF ACCTIDI IS NUMERIC
                   MOVE ACCTIDI TO AC-ID
                   MOVE AC-ID   TO CA-ACCT-ID
                   PERFORM 3000-READ-ACCT
                   IF REC-FOUND
                       PERFORM 4000-POPULATE-DETAIL
                       MOVE 'Account displayed.' TO ERRMSGO
                       PERFORM 8100-SEND-DATAONLY
                   ELSE
                       MOVE WS-MSG-NOTFND TO ERRMSGO
                       PERFORM 8100-SEND-DATAONLY
                   END-IF
               ELSE
                   MOVE 'Account id must be numeric.' TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  DB2 read : SELECT the account row by primary key AC_ID.       *
      *----------------------------------------------------------------*
       3000-READ-ACCT.
           SET REC-NOT-FOUND TO TRUE.
           EXEC SQL
                SELECT AC_ACTIVE_STATUS,
                       AC_CURR_BAL,
                       AC_CREDIT_LIMIT,
                       AC_CASH_LIMIT,
                       AC_OPEN_DATE,
                       AC_EXPIRY_DATE,
                       AC_GROUP_ID
                  INTO :AC-ACTIVE-STATUS,
                       :AC-CURR-BAL,
                       :AC-CREDIT-LIMIT,
                       :AC-CASH-LIMIT,
                       :AC-OPEN-DATE,
                       :AC-EXPIRY-DATE,
                       :AC-GROUP-ID
                  FROM ORION.ACCT
                 WHERE AC_ID = :AC-ID
           END-EXEC.
           EVALUATE SQLCODE
               WHEN 0
                   SET REC-FOUND TO TRUE
               WHEN 100
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET REC-NOT-FOUND TO TRUE
                   MOVE 'Error reading account table.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE AC-ID             TO ACCTIDO.
           MOVE AC-ACTIVE-STATUS  TO ACSTATO.
           MOVE AC-CURR-BAL       TO WS-ED-BAL.
           MOVE WS-ED-BAL         TO ACBALO.
           MOVE AC-CREDIT-LIMIT   TO WS-ED-AMT.
           MOVE WS-ED-AMT         TO ACCRLIMO.
           MOVE AC-CASH-LIMIT     TO WS-ED-AMT.
           MOVE WS-ED-AMT         TO ACCSLIMO.
           MOVE AC-OPEN-DATE      TO ACOPENO.
           MOVE AC-EXPIRY-DATE    TO ACEXPO.
           MOVE AC-GROUP-ID       TO ACGRPO.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MACCTVA')
                     MAPSET('MACCTV')
                     FROM(MACCTVAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
