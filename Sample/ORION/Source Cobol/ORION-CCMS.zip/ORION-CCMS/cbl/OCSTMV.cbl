      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCSTMV   -  Statement View (on-line)             *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: read a monthly statement (STMTFILE) by account    *
      *            id and billing cycle (YYYYMM) and display the      *
      *            opening and closing balances, the minimum amount   *
      *            due and the payment due date.                      *
      *            PF3 = back to menu, PF4 = clear, ENTER = view.     *
      *  MAPSET  : MSTMV       MAP : MSTMVA      TRANID : ORSV       *
      *  FILES   : STMTFILE (read by ST-KEY = acct id + cycle)      *
      *  NOTE    : follows the OCACCTV golden on-line skeleton.      *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - statement view.               *
      *****************************************************************
      *  PROCESSING NARRATIVE                                        *
      *  1. The operator keys an account id and a six-digit cycle.    *
      *  2. Both are validated as numeric; the cycle month must be    *
      *     between 01 and 12.                                        *
      *  3. The composite statement key is read; when found the       *
      *     balances are edited and shown, otherwise a not-found      *
      *     message is displayed.                                     *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCSTMV.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and navigation constants.                    *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCSTMV'.
           05  WS-TRANID            PIC X(04) VALUE 'ORSV'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Validation switch and staged key values.                      *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
       01  WS-KEY-FIELDS.
           05  WS-ACCT              PIC 9(11) VALUE ZEROS.
           05  WS-CYCLE             PIC 9(06) VALUE ZEROS.
           05  WS-CYC-MM            PIC 9(02) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Reusable numeric-field parser work area.                      *
      *----------------------------------------------------------------*
       01  WS-NUMCHK.
           05  WS-NC-IN             PIC X(16) VALUE SPACES.
           05  WS-NC-LEN            PIC 9(02) VALUE ZEROS.
           05  WS-NC-POS            PIC 9(02) VALUE ZEROS.
           05  WS-NC-CHAR           PIC X(01) VALUE SPACES.
           05  WS-NC-DIGIT          PIC 9(01) VALUE ZEROS.
           05  WS-NC-DIGITS         PIC 9(02) VALUE ZEROS.
           05  WS-NC-VALUE          PIC 9(16) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Program specific operator messages.                           *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-MSGS.
           05  WS-M-PROMPT          PIC X(50)
               VALUE 'Enter account id and cycle, press ENTER.'.
           05  WS-M-ACCT-NUM        PIC X(50)
               VALUE 'Account id must be numeric.'.
           05  WS-M-CYC-NUM         PIC X(50)
               VALUE 'Cycle must be six digits (YYYYMM).'.
           05  WS-M-CYC-MM          PIC X(50)
               VALUE 'Cycle month must be 01 through 12.'.
           05  WS-M-NOTFND          PIC X(50)
               VALUE 'No statement for that account and cycle.'.
           05  WS-M-SHOWN           PIC X(50)
               VALUE 'Statement displayed.'.
      *----------------------------------------------------------------*
      *  Shared copybooks - constants, messages, header, commarea.     *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
      *----------------------------------------------------------------*
      *  File record layout and BMS symbolic map.                      *
      *----------------------------------------------------------------*
       COPY RSTMT.
       COPY MSTMV.
      *----------------------------------------------------------------*
      *  IBM supplied AID keys and BMS attribute constants.            *
      *----------------------------------------------------------------*
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *================================================================*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  pseudo-conversational entry / dispatch point.   *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL  -  clear the map and prompt for a key.     *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MSTMVAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-M-PROMPT TO ERRMSGO.
           MOVE -1 TO ACCTIDL.
           EXEC CICS SEND
                     MAP('MSTMVA')
                     MAPSET('MSTMV')
                     FROM(MSTMVAO)
                     ERASE
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT  -  interpret the attention identifier.    *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-VIEW-STMT
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-VIEW-STMT  -  receive the key, validate it and read the  *
      *  statement.                                                   *
      *----------------------------------------------------------------*
       2100-VIEW-STMT.
           EXEC CICS RECEIVE
                     MAP('MSTMVA')
                     MAPSET('MSTMV')
                     INTO(MSTMVAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MSTMVAI
           END-IF.
           PERFORM 6100-VALIDATE-KEY.
           IF WS-INVALID
               MOVE -1 TO ACCTIDL
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 3000-READ-STMT
               IF REC-FOUND
                   PERFORM 4000-POPULATE-DETAIL
                   MOVE WS-M-SHOWN TO ERRMSGO
               ELSE
                   PERFORM 4100-CLEAR-DETAIL
                   MOVE WS-M-NOTFND TO ERRMSGO
               END-IF
               MOVE -1 TO ACCTIDL
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  3000-READ-STMT  -  random read of STMTFILE by ST-KEY.        *
      *----------------------------------------------------------------*
       3000-READ-STMT.
           SET REC-NOT-FOUND TO TRUE.
           MOVE WS-ACCT  TO ST-ACCT-ID.
           MOVE WS-CYCLE TO ST-CYCLE.
           EXEC CICS READ
                     FILE(WS-STMTFILE)
                     INTO(STMT-REC)
                     RIDFLD(ST-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-POPULATE-DETAIL  -  edit the statement values into the   *
      *  output map.  Money is edited through WS-ED-BAL; the leading   *
      *  pad byte is dropped so the value fits the 15-char fields.     *
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE ST-ACCT-ID    TO ACCTIDO.
           MOVE ST-CYCLE      TO STCYCO.
           MOVE ST-OPEN-BAL   TO WS-ED-BAL.
           MOVE WS-ED-BAL(2:15) TO STOPENO.
           MOVE ST-CLOSE-BAL  TO WS-ED-BAL.
           MOVE WS-ED-BAL(2:15) TO STCLOSEO.
           MOVE ST-MIN-DUE    TO WS-ED-BAL.
           MOVE WS-ED-BAL(2:15) TO STMINO.
           MOVE ST-DUE-DATE   TO STDUEO.
      *----------------------------------------------------------------*
      *  4100-CLEAR-DETAIL  -  blank the balance display fields.       *
      *----------------------------------------------------------------*
       4100-CLEAR-DETAIL.
           MOVE SPACES TO STOPENO.
           MOVE SPACES TO STCLOSEO.
           MOVE SPACES TO STMINO.
           MOVE SPACES TO STDUEO.
      *----------------------------------------------------------------*
      *  6100-VALIDATE-KEY  -  account id numeric, cycle six digits    *
      *  with a month in the range 01 - 12.                           *
      *----------------------------------------------------------------*
       6100-VALIDATE-KEY.
           SET WS-VALID TO TRUE.
           MOVE SPACES TO ERRMSGO.
           MOVE ACCTIDI TO WS-NC-IN.
           MOVE 11 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-DIGITS > 11
               SET WS-INVALID TO TRUE
               MOVE WS-M-ACCT-NUM TO ERRMSGO
               GO TO 6100-EXIT
           END-IF.
           MOVE WS-NC-VALUE TO WS-ACCT.
           MOVE STCYCI TO WS-NC-IN.
           MOVE 6 TO WS-NC-LEN.
           PERFORM 6000-PARSE-NUM.
           IF WS-INVALID OR WS-NC-DIGITS NOT = 6
               SET WS-INVALID TO TRUE
               MOVE WS-M-CYC-NUM TO ERRMSGO
               GO TO 6100-EXIT
           END-IF.
           MOVE WS-NC-VALUE TO WS-CYCLE.
           MOVE WS-CYCLE(5:2) TO WS-CYC-MM.
           IF WS-CYC-MM < 1 OR WS-CYC-MM > 12
               SET WS-INVALID TO TRUE
               MOVE WS-M-CYC-MM TO ERRMSGO
           END-IF.
       6100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  6000-PARSE-NUM  -  scan WS-NC-IN for WS-NC-LEN characters,
      *  ignore spaces, accumulate digits and count them.              *
      *----------------------------------------------------------------*
       6000-PARSE-NUM.
           SET WS-VALID TO TRUE.
           MOVE ZEROS TO WS-NC-VALUE WS-NC-DIGITS.
           INSPECT WS-NC-IN REPLACING ALL LOW-VALUE BY SPACE.
           PERFORM VARYING WS-NC-POS FROM 1 BY 1
                   UNTIL WS-NC-POS > WS-NC-LEN
               MOVE WS-NC-IN(WS-NC-POS:1) TO WS-NC-CHAR
               EVALUATE TRUE
                   WHEN WS-NC-CHAR = SPACE
                       CONTINUE
                   WHEN WS-NC-CHAR >= '0' AND WS-NC-CHAR <= '9'
                       MOVE WS-NC-CHAR TO WS-NC-DIGIT
                       COMPUTE WS-NC-VALUE =
                           WS-NC-VALUE * 10 + WS-NC-DIGIT
                       ADD 1 TO WS-NC-DIGITS
                   WHEN OTHER
                       SET WS-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-NC-DIGITS = 0
               SET WS-INVALID TO TRUE
           END-IF.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU  -  hand control back to the main menu program.*
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER  -  load the standard screen header.     *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY  -  refresh header and resend the map.     *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MSTMVA')
                     MAPSET('MSTMV')
                     FROM(MSTMVAO)
                     DATAONLY
                     CURSOR
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME  -  obtain the current date and time.      *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN  -  pseudo-conversational return to this tran.    *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9500-ABEND-RTN  -  unrecoverable file error - inform and end. *
      *----------------------------------------------------------------*
       9500-ABEND-RTN.
           MOVE 'OCSTMV: unrecoverable file error. Contact support.'
               TO WS-MSG-TEXT.
           EXEC CICS SEND TEXT
                     FROM(WS-MSG-TEXT)
                     LENGTH(LENGTH OF WS-MSG-TEXT)
                     ERASE
                     FREEKB
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS RETURN
                     RESP(WS-RESP-CD)
           END-EXEC.
