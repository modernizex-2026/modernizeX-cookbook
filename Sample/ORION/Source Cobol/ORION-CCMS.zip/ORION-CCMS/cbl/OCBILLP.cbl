      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCBILLP  -  Bill Payment (on-line)               *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: accept an account id, read the account master    *
      *            (ACCTFILE) and display the current balance.      *
      *            Accept a payment amount and a confirmation flag; *
      *            on confirm assign a bill id from the control     *
      *            file (CTRLFILE key 'BILLID'), WRITE the payment  *
      *            to BILLFILE, subtract the amount from the account *
      *            balance (READ UPDATE + REWRITE ACCTFILE) and      *
      *            display the generated confirmation number.        *
      *  MAP     : MBILLPA of mapset MBILLP.                         *
      *  TRANID  : ORBP.  PF3 = menu, PF4 = clear, ENTER = process.  *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCBILLP.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identification constants.                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCBILLP'.
           05  WS-TRANID            PIC X(04) VALUE 'ORBP'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Pseudo-conversational state.  This structure is stored in the *
      *  COMMAREA scratch field CA-WORK-AREA between interactions so   *
      *  the program knows whether it is waiting for an account id or  *
      *  for a payment amount.                                         *
      *----------------------------------------------------------------*
       01  WS-STATE-AREA.
           05  WS-STAGE             PIC X(01) VALUE '0'.
               88  STAGE-NEED-ACCT            VALUE '0'.
               88  STAGE-NEED-PAY             VALUE '1'.
           05  WS-SV-ACCT-ID        PIC 9(11) VALUE ZEROS.
           05  WS-SV-BAL            PIC S9(10)V99 VALUE ZEROS.
           05  FILLER               PIC X(488) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Work fields used to validate and post a payment.              *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-PAY-AMT           PIC S9(10)V99 VALUE ZEROS.
           05  WS-NEW-BAL           PIC S9(10)V99 VALUE ZEROS.
           05  WS-AMT-IN            PIC X(12) VALUE SPACES.
           05  WS-CH                PIC X(01) VALUE SPACES.
           05  WS-I                 PIC 9(02) VALUE ZEROS.
           05  WS-DOT-CNT           PIC 9(02) VALUE ZEROS.
           05  WS-DIG-CNT           PIC 9(02) VALUE ZEROS.
           05  WS-VALID-FLG         PIC X(01) VALUE 'Y'.
               88  WS-AMT-VALID              VALUE 'Y'.
               88  WS-AMT-INVALID           VALUE 'N'.
           05  WS-ID-11             PIC 9(11) VALUE ZEROS.
           05  WS-CONFIRM-NUM       PIC X(16) VALUE SPACES.
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RACCT.
       COPY RBILL.
       COPY RCTRL.
       COPY MBILLP.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN : pseudo-conversational entry point.                *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               MOVE CA-WORK-AREA TO WS-STATE-AREA
               MOVE SPACES       TO CA-ERR-MSG
               IF CA-FIRST-ENTER
                   PERFORM 1000-SEND-INITIAL
               ELSE
                   PERFORM 2000-PROCESS-INPUT
               END-IF
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL : paint an empty screen and prompt for the  *
      *  account id.  Resets the conversational stage.                 *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MBILLPAO.
           SET STAGE-NEED-ACCT TO TRUE.
           MOVE ZEROS      TO WS-SV-ACCT-ID.
           MOVE ZEROS      TO WS-SV-BAL.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter account id and press ENTER.' TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MBILLPA')
                     MAPSET('MBILLP')
                     FROM(MBILLPAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT : dispatch on the AID key.                 *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-HANDLE-ENTER
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-HANDLE-ENTER : receive the map, then act according to    *
      *  the current conversational stage.                             *
      *----------------------------------------------------------------*
       2100-HANDLE-ENTER.
           PERFORM 2110-RECEIVE-MAP.
           EVALUATE TRUE
               WHEN STAGE-NEED-ACCT
                   PERFORM 2200-PROCESS-ACCT
               WHEN STAGE-NEED-PAY
                   PERFORM 2300-PROCESS-PAY
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2110-RECEIVE-MAP : read the operator input into MBILLPAI.     *
      *----------------------------------------------------------------*
       2110-RECEIVE-MAP.
           EXEC CICS RECEIVE
                     MAP('MBILLPA')
                     MAPSET('MBILLP')
                     INTO(MBILLPAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  2200-PROCESS-ACCT : stage 1.  Validate the account id, read   *
      *  the account master and display the current balance.  On       *
      *  success advance to the payment stage.                         *
      *----------------------------------------------------------------*
       2200-PROCESS-ACCT.
           IF ACCTIDI = SPACES OR ACCTIDI = LOW-VALUES
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE ACCTIDI TO AC-ID
               MOVE AC-ID   TO CA-ACCT-ID
               PERFORM 3000-READ-ACCT
               IF REC-FOUND
                   PERFORM 2210-SHOW-BALANCE
               ELSE
                   MOVE WS-MSG-NOTFND TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2210-SHOW-BALANCE : save the account and balance in the       *
      *  conversational state and prompt for the payment amount.       *
      *----------------------------------------------------------------*
       2210-SHOW-BALANCE.
           MOVE AC-ID       TO WS-SV-ACCT-ID.
           MOVE AC-CURR-BAL TO WS-SV-BAL.
           SET STAGE-NEED-PAY TO TRUE.
           PERFORM 4000-POPULATE-PAY-SCREEN.
           MOVE 'Enter amount, set confirm to Y, press ENTER.'
               TO ERRMSGO.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  2300-PROCESS-PAY : stage 2.  Validate the payment amount and  *
      *  the confirmation flag, then post the payment.                 *
      *----------------------------------------------------------------*
       2300-PROCESS-PAY.
           PERFORM 2310-VALIDATE-AMOUNT.
           IF WS-AMT-INVALID
               PERFORM 4000-POPULATE-PAY-SCREEN
               PERFORM 8100-SEND-DATAONLY
           ELSE
               IF WS-PAY-AMT NOT > ZEROS
                   MOVE 'Amount must be greater than zero.'
                       TO ERRMSGO
                   PERFORM 4000-POPULATE-PAY-SCREEN
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   IF WS-PAY-AMT > WS-SV-BAL
                       MOVE 'Amount exceeds current balance.'
                           TO ERRMSGO
                       PERFORM 4000-POPULATE-PAY-SCREEN
                       PERFORM 8100-SEND-DATAONLY
                   ELSE
                       PERFORM 2320-CHECK-CONFIRM
                   END-IF
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2310-VALIDATE-AMOUNT : scan the amount field.  Only digits,   *
      *  spaces and a single decimal point are allowed.  Convert with  *
      *  FUNCTION NUMVAL when the syntax is valid.                     *
      *----------------------------------------------------------------*
       2310-VALIDATE-AMOUNT.
           MOVE BLAMTI TO WS-AMT-IN.
           MOVE 0      TO WS-DOT-CNT.
           MOVE 0      TO WS-DIG-CNT.
           SET WS-AMT-VALID TO TRUE.
           IF WS-AMT-IN = SPACES OR WS-AMT-IN = LOW-VALUES
               SET WS-AMT-INVALID TO TRUE
               MOVE 'Please enter a payment amount.' TO ERRMSGO
               GO TO 2310-EXIT
           END-IF.
           PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > 12
               MOVE WS-AMT-IN(WS-I:1) TO WS-CH
               EVALUATE WS-CH
                   WHEN ' '
                       CONTINUE
                   WHEN '.'
                       ADD 1 TO WS-DOT-CNT
                   WHEN '0' THRU '9'
                       ADD 1 TO WS-DIG-CNT
                   WHEN OTHER
                       SET WS-AMT-INVALID TO TRUE
               END-EVALUATE
           END-PERFORM.
           IF WS-DOT-CNT > 1
               SET WS-AMT-INVALID TO TRUE
           END-IF.
           IF WS-DIG-CNT = 0
               SET WS-AMT-INVALID TO TRUE
           END-IF.
           IF WS-AMT-INVALID
               MOVE 'Amount is not a valid number.' TO ERRMSGO
               GO TO 2310-EXIT
           END-IF.
           COMPUTE WS-PAY-AMT = FUNCTION NUMVAL(WS-AMT-IN).
       2310-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2320-CHECK-CONFIRM : require the confirm flag to be Y before  *
      *  the payment is actually posted.                              *
      *----------------------------------------------------------------*
       2320-CHECK-CONFIRM.
           IF BLCONFI = 'Y' OR BLCONFI = 'y'
               PERFORM 2400-POST-PAYMENT
           ELSE
               MOVE 'Set confirm to Y to post this payment.'
                   TO ERRMSGO
               PERFORM 4000-POPULATE-PAY-SCREEN
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  2400-POST-PAYMENT : assign the next bill id, write the bill   *
      *  record, reduce the account balance and report the result.     *
      *----------------------------------------------------------------*
       2400-POST-PAYMENT.
           PERFORM 3100-GET-NEXT-BILLID.
           IF ERR-FLG-ON
               PERFORM 4000-POPULATE-PAY-SCREEN
               PERFORM 8100-SEND-DATAONLY
               GO TO 2400-EXIT
           END-IF.
           PERFORM 4100-BUILD-CONFIRM.
           PERFORM 3200-WRITE-BILL.
           IF ERR-FLG-ON
               PERFORM 4000-POPULATE-PAY-SCREEN
               PERFORM 8100-SEND-DATAONLY
               GO TO 2400-EXIT
           END-IF.
           PERFORM 3300-UPDATE-ACCT-BAL.
           IF ERR-FLG-ON
               PERFORM 4000-POPULATE-PAY-SCREEN
               PERFORM 8100-SEND-DATAONLY
               GO TO 2400-EXIT
           END-IF.
           PERFORM 4200-SHOW-CONFIRMATION.
       2400-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3000-READ-ACCT : simple read of the account master.          *
      *----------------------------------------------------------------*
       3000-READ-ACCT.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error reading account file.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3100-GET-NEXT-BILLID : read the control record for 'BILLID'   *
      *  with UPDATE intent, bump the counter and rewrite it.  The     *
      *  resulting value becomes the new bill id.                      *
      *----------------------------------------------------------------*
       3100-GET-NEXT-BILLID.
           SET ERR-FLG-OFF TO TRUE.
           MOVE 'BILLID  ' TO CT-KEY.
           EXEC CICS READ
                     FILE(WS-CTRLFILE)
                     INTO(CTRL-REC)
                     RIDFLD(CT-KEY)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO CT-LAST-VALUE
                   MOVE CT-LAST-VALUE TO BL-ID
                   MOVE CT-LAST-VALUE TO WS-ID-11
                   PERFORM 3110-REWRITE-CTRL
               WHEN DFHRESP(NOTFND)
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Control record BILLID missing.' TO ERRMSGO
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error reading control file.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3110-REWRITE-CTRL : persist the bumped counter.              *
      *----------------------------------------------------------------*
       3110-REWRITE-CTRL.
           EXEC CICS REWRITE
                     FILE(WS-CTRLFILE)
                     FROM(CTRL-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               SET ERR-FLG-ON TO TRUE
               MOVE 'Error updating control file.' TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  3200-WRITE-BILL : build and write the bill payment record.    *
      *----------------------------------------------------------------*
       3200-WRITE-BILL.
           SET ERR-FLG-OFF TO TRUE.
           MOVE WS-SV-ACCT-ID   TO BL-ACCT-ID.
           MOVE WS-PAY-AMT      TO BL-AMOUNT.
           MOVE WS-HDR-DATE     TO BL-PAY-DATE.
           MOVE WS-CONFIRM-NUM  TO BL-CONFIRM-NUM.
           MOVE 'P'             TO BL-STATUS.
           EXEC CICS WRITE
                     FILE(WS-BILLFILE)
                     FROM(BILL-REC)
                     RIDFLD(BL-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(DUPREC)
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Duplicate bill id generated.' TO ERRMSGO
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error writing bill file.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3300-UPDATE-ACCT-BAL : read the account with UPDATE intent,   *
      *  subtract the payment from the current balance and rewrite.    *
      *----------------------------------------------------------------*
       3300-UPDATE-ACCT-BAL.
           SET ERR-FLG-OFF TO TRUE.
           MOVE WS-SV-ACCT-ID TO AC-ID.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   COMPUTE AC-CURR-BAL = AC-CURR-BAL - WS-PAY-AMT
                   ADD WS-PAY-AMT TO AC-CYC-CREDIT
                   MOVE AC-CURR-BAL TO WS-NEW-BAL
                   PERFORM 3310-REWRITE-ACCT
               WHEN DFHRESP(NOTFND)
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Account not found on update.' TO ERRMSGO
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error reading account for update.'
                       TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3310-REWRITE-ACCT : persist the reduced balance.             *
      *----------------------------------------------------------------*
       3310-REWRITE-ACCT.
           EXEC CICS REWRITE
                     FILE(WS-ACCTFILE)
                     FROM(ACCT-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               SET ERR-FLG-ON TO TRUE
               MOVE 'Error updating account balance.' TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  4000-POPULATE-PAY-SCREEN : redisplay the account id and the   *
      *  saved balance during the payment stage.                       *
      *----------------------------------------------------------------*
       4000-POPULATE-PAY-SCREEN.
           MOVE WS-SV-ACCT-ID TO ACCTIDO.
           MOVE WS-SV-BAL     TO WS-ED-BAL.
           MOVE WS-ED-BAL     TO BLBALO.
      *----------------------------------------------------------------*
      *  4100-BUILD-CONFIRM : construct the 16-byte confirmation       *
      *  number from a fixed prefix plus the new bill id.              *
      *----------------------------------------------------------------*
       4100-BUILD-CONFIRM.
           MOVE SPACES TO WS-CONFIRM-NUM.
           STRING 'ORB'    DELIMITED BY SIZE
                  WS-ID-11 DELIMITED BY SIZE
                  '00'     DELIMITED BY SIZE
                  INTO WS-CONFIRM-NUM
           END-STRING.
      *----------------------------------------------------------------*
      *  4200-SHOW-CONFIRMATION : show the new balance and confirmation*
      *  number, then reset for the next payment.                      *
      *----------------------------------------------------------------*
       4200-SHOW-CONFIRMATION.
           MOVE WS-NEW-BAL TO WS-SV-BAL.
           MOVE WS-NEW-BAL TO WS-ED-BAL.
           MOVE WS-ED-BAL  TO BLBALO.
           MOVE SPACES     TO BLAMTO.
           MOVE SPACES     TO BLCONFO.
           MOVE SPACES     TO ERRMSGO.
           STRING 'Payment posted. Confirmation: ' DELIMITED BY SIZE
                  WS-CONFIRM-NUM DELIMITED BY SIZE
                  INTO ERRMSGO
           END-STRING.
           SET STAGE-NEED-ACCT TO TRUE.
           MOVE ZEROS TO WS-SV-ACCT-ID.
           MOVE ZEROS TO WS-SV-BAL.
           PERFORM 8100-SEND-DATAONLY.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU : return control to the main menu.            *
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           MOVE WS-STATE-AREA TO CA-WORK-AREA.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER : fill the standard screen header.       *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY : resend the map without erasing.          *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MBILLPA')
                     MAPSET('MBILLP')
                     FROM(MBILLPAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME : obtain the current date and time.        *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN : save state and return pseudo-conversationally.  *
      *----------------------------------------------------------------*
       9000-RETURN.
           MOVE WS-STATE-AREA TO CA-WORK-AREA.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
