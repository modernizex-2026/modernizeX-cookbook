      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUSTMIN  -  Statement browse subroutine           *
      *  TYPE    : SUBROUTINE (EXEC CICS LINK from OCSTMIN)          *
      *  FUNCTION: return one page of statement rows from STMTFILE   *
      *            positioned at the requested account / cycle.  The *
      *            caller fills KSB-REQUEST, LINKs this program and   *
      *            reads back KSB-RESULT and KSB-ROWS.  The browse    *
      *            is opened GTEQ on the composite key ST-KEY        *
      *            (ST-ACCT-ID + ST-CYCLE), up to KSB-MAX-ROWS       *
      *            records are read forward, one extra record is      *
      *            peeked to publish the next-page key and the MORE   *
      *            flag, then the browse is closed.  Every EXEC CICS  *
      *            command tests RESP and file failures are logged.   *
      *  CALL    : EXEC CICS LINK PROGRAM('OUSTMIN')                 *
      *                COMMAREA(KSTMB-PARM)                          *
      *                LENGTH(LENGTH OF KSTMB-PARM) END-EXEC.        *
      *  FILES   : STMTFILE (browse - STARTBR / READNEXT / ENDBR)   *
      *  RETURN  : ends with GOBACK (subroutine convention).         *
      *****************************************************************
      *  MAINTENANCE LOG                                             *
      *  ----  ----------  -------------------------------------     *
      *  0001  2026-08-07  Original - statement page browse.         *
      *****************************************************************
      *  PROCESSING NARRATIVE                                        *
      *  1. Validate the request; only the ACCT browse mode is       *
      *     supported.  Reset the result occurrences.                *
      *  2. Build the composite start key from the request and       *
      *     STARTBR the statement file GREATER-THAN-OR-EQUAL.        *
      *  3. READNEXT up to the requested number of rows into the     *
      *     output occurrence table, moving balances and dates.      *
      *  4. If the page filled without end-of-file, READNEXT one     *
      *     more record; its key becomes the next-page start and     *
      *     MORE is set so the caller can enable PF8 paging.         *
      *  5. ENDBR and publish the row count and completion status.   *
      *     Any abnormal RESP writes a diagnostic to the CSSL log.   *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUSTMIN.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity.                                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUSTMIN'.
      *----------------------------------------------------------------*
      *  Browse control and work fields.                              *
      *----------------------------------------------------------------*
       01  WS-WORK-FIELDS.
           05  WS-ROW-CNT           PIC 9(02) VALUE ZEROS.
           05  WS-MAX-ROWS          PIC 9(02) VALUE ZEROS.
           05  WS-BROWSE-SW         PIC X(01) VALUE 'N'.
               88  WS-BR-ON                   VALUE 'Y'.
               88  WS-BR-OFF                  VALUE 'N'.
           05  WS-EOF-SW            PIC X(01) VALUE 'N'.
               88  WS-EOF-YES                 VALUE 'Y'.
               88  WS-EOF-NO                  VALUE 'N'.
      *----------------------------------------------------------------*
      *  Diagnostic message written to the CICS transient-data log     *
      *  (CSSL) when a file operation returns an abnormal response.    *
      *----------------------------------------------------------------*
       01  WS-DIAG.
           05  WS-DIAG-QNAME        PIC X(04) VALUE 'CSSL'.
           05  WS-DIAG-MSG          PIC X(80) VALUE SPACES.
           05  WS-DIAG-CTX          PIC X(20) VALUE SPACES.
           05  WS-DIAG-RESP         PIC 9(09) VALUE ZEROS.
       01  WS-DIAG-LINE.
           05  FILLER               PIC X(10) VALUE 'OUSTMIN : '.
           05  WDL-CTX              PIC X(20) VALUE SPACES.
           05  FILLER               PIC X(06) VALUE ' RESP='.
           05  WDL-RESP             PIC ZZZZZZZZ9.
           05  FILLER               PIC X(46) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Shared constants (WS-RESP-CD, file names) and record layout.  *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RSTMT.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KSTMB.
      *================================================================*
       PROCEDURE DIVISION USING KSTMB-PARM.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  top level driver for the page browse.           *
      *----------------------------------------------------------------*
       0000-MAIN.
           PERFORM 1000-INIT.
           IF KSB-STATUS NOT = '99'
               PERFORM 2000-POSITION
               IF WS-BR-ON
                   PERFORM 3000-READ-PAGE
                   PERFORM 4000-PEEK-NEXT
                   PERFORM 5000-END-BROWSE
               END-IF
           END-IF.
           PERFORM 6000-SET-STATUS.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INIT  -  reset the result area, validate the request and *
      *  cap the requested number of rows.                            *
      *----------------------------------------------------------------*
       1000-INIT.
           SET WS-BR-OFF  TO TRUE.
           SET WS-EOF-NO  TO TRUE.
           MOVE ZEROS     TO WS-ROW-CNT.
           MOVE '00'  TO KSB-STATUS.
           MOVE ZEROS TO KSB-ROW-CNT.
           MOVE ZEROS TO KSB-NEXT-ACCT.
           MOVE ZEROS TO KSB-NEXT-CYCLE.
           MOVE 'N'   TO KSB-MORE.
           PERFORM 1100-CLEAR-ROWS.
           PERFORM 1200-VALIDATE-REQ.
      *----------------------------------------------------------------*
      *  1100-CLEAR-ROWS  -  blank every output occurrence.            *
      *----------------------------------------------------------------*
       1100-CLEAR-ROWS.
           PERFORM VARYING WS-IDX FROM 1 BY 1 UNTIL WS-IDX > 6
               MOVE ZEROS  TO KSB-R-ACCT   (WS-IDX)
               MOVE ZEROS  TO KSB-R-CYCLE  (WS-IDX)
               MOVE ZEROS  TO KSB-R-OPEN   (WS-IDX)
               MOVE ZEROS  TO KSB-R-CLOSE  (WS-IDX)
               MOVE ZEROS  TO KSB-R-CREDIT (WS-IDX)
               MOVE ZEROS  TO KSB-R-DEBIT  (WS-IDX)
               MOVE ZEROS  TO KSB-R-MINDUE (WS-IDX)
               MOVE SPACES TO KSB-R-DUEDT  (WS-IDX)
           END-PERFORM.
      *----------------------------------------------------------------*
      *  1200-VALIDATE-REQ  -  only the ACCT browse mode is supported; *
      *  the row cap is forced into the range 1 through 6.             *
      *----------------------------------------------------------------*
       1200-VALIDATE-REQ.
           MOVE KSB-MAX-ROWS TO WS-MAX-ROWS.
           IF WS-MAX-ROWS < 1 OR WS-MAX-ROWS > 6
               MOVE 6 TO WS-MAX-ROWS
           END-IF.
           IF KSB-MODE NOT = 'ACCT'
               MOVE '99' TO KSB-STATUS
               MOVE 'BAD REQUEST MODE'  TO WS-DIAG-CTX
               MOVE ZEROS               TO WS-DIAG-RESP
               PERFORM 9500-LOG-ERROR
           END-IF.
      *----------------------------------------------------------------*
      *  2000-POSITION  -  open the browse at the requested key.       *
      *  A NOTFND or ENDFILE at this point means the requested start   *
      *  is past the last statement, which is simply an empty page.    *
      *----------------------------------------------------------------*
       2000-POSITION.
           MOVE KSB-START-ACCT  TO ST-ACCT-ID.
           MOVE KSB-START-CYCLE TO ST-CYCLE.
           EXEC CICS STARTBR
                     FILE(WS-STMTFILE)
                     RIDFLD(ST-KEY)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-BR-ON TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET WS-BR-OFF  TO TRUE
                   SET WS-EOF-YES TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-BR-OFF  TO TRUE
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   SET WS-BR-OFF  TO TRUE
                   SET WS-EOF-YES TO TRUE
                   MOVE '99' TO KSB-STATUS
                   MOVE 'STARTBR STMTFILE'  TO WS-DIAG-CTX
                   MOVE WS-RESP-CD          TO WS-DIAG-RESP
                   PERFORM 9500-LOG-ERROR
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3000-READ-PAGE  -  fill the page from the browse.             *
      *----------------------------------------------------------------*
       3000-READ-PAGE.
           PERFORM 3100-READ-ONE
               UNTIL WS-EOF-YES
                  OR WS-ROW-CNT >= WS-MAX-ROWS.
      *----------------------------------------------------------------*
      *  3100-READ-ONE  -  read one statement and store it.            *
      *----------------------------------------------------------------*
       3100-READ-ONE.
           EXEC CICS READNEXT
                     FILE(WS-STMTFILE)
                     INTO(STMT-REC)
                     RIDFLD(ST-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO WS-ROW-CNT
                   PERFORM 3200-MOVE-ROW
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   SET WS-EOF-YES TO TRUE
                   MOVE '99' TO KSB-STATUS
                   MOVE 'READNEXT STMTFILE' TO WS-DIAG-CTX
                   MOVE WS-RESP-CD          TO WS-DIAG-RESP
                   PERFORM 9500-LOG-ERROR
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-MOVE-ROW  -  copy the current statement into the row     *
      *  indicated by the running row counter.                         *
      *----------------------------------------------------------------*
       3200-MOVE-ROW.
           MOVE ST-ACCT-ID      TO KSB-R-ACCT   (WS-ROW-CNT).
           MOVE ST-CYCLE        TO KSB-R-CYCLE  (WS-ROW-CNT).
           MOVE ST-OPEN-BAL     TO KSB-R-OPEN   (WS-ROW-CNT).
           MOVE ST-CLOSE-BAL    TO KSB-R-CLOSE  (WS-ROW-CNT).
           MOVE ST-TOTAL-CREDIT TO KSB-R-CREDIT (WS-ROW-CNT).
           MOVE ST-TOTAL-DEBIT  TO KSB-R-DEBIT  (WS-ROW-CNT).
           MOVE ST-MIN-DUE      TO KSB-R-MINDUE (WS-ROW-CNT).
           MOVE ST-DUE-DATE     TO KSB-R-DUEDT  (WS-ROW-CNT).
      *----------------------------------------------------------------*
      *  4000-PEEK-NEXT  -  when the page filled, look one record      *
      *  ahead so the caller knows the next-page start key.            *
      *----------------------------------------------------------------*
       4000-PEEK-NEXT.
           IF WS-EOF-YES
               MOVE 'N' TO KSB-MORE
               GO TO 4000-EXIT
           END-IF.
           EXEC CICS READNEXT
                     FILE(WS-STMTFILE)
                     INTO(STMT-REC)
                     RIDFLD(ST-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE 'Y'        TO KSB-MORE
                   MOVE ST-ACCT-ID TO KSB-NEXT-ACCT
                   MOVE ST-CYCLE   TO KSB-NEXT-CYCLE
               WHEN DFHRESP(ENDFILE)
                   MOVE 'N' TO KSB-MORE
               WHEN OTHER
                   MOVE 'N'  TO KSB-MORE
                   MOVE '99' TO KSB-STATUS
                   MOVE 'PEEK STMTFILE'     TO WS-DIAG-CTX
                   MOVE WS-RESP-CD          TO WS-DIAG-RESP
                   PERFORM 9500-LOG-ERROR
           END-EVALUATE.
       4000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5000-END-BROWSE  -  release the browse position.              *
      *----------------------------------------------------------------*
       5000-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-STMTFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               MOVE 'ENDBR STMTFILE'    TO WS-DIAG-CTX
               MOVE WS-RESP-CD          TO WS-DIAG-RESP
               PERFORM 9500-LOG-ERROR
           END-IF.
      *----------------------------------------------------------------*
      *  6000-SET-STATUS  -  publish the row count and status code.    *
      *  '99' (already set on error) is preserved; otherwise '10'      *
      *  signals an empty page and '00' a page of one or more rows.    *
      *----------------------------------------------------------------*
       6000-SET-STATUS.
           MOVE WS-ROW-CNT TO KSB-ROW-CNT.
           IF KSB-STATUS = '99'
               CONTINUE
           ELSE
               IF WS-ROW-CNT = ZEROS
                   MOVE '10' TO KSB-STATUS
               ELSE
                   MOVE '00' TO KSB-STATUS
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  9500-LOG-ERROR  -  build and write one diagnostic line to the *
      *  CSSL transient-data queue.  A logging failure is swallowed so *
      *  it never masks the original condition returned to the caller. *
      *----------------------------------------------------------------*
       9500-LOG-ERROR.
           MOVE WS-DIAG-CTX  TO WDL-CTX.
           MOVE WS-DIAG-RESP TO WDL-RESP.
           MOVE WS-DIAG-LINE TO WS-DIAG-MSG.
           EXEC CICS WRITEQ TD
                     QUEUE(WS-DIAG-QNAME)
                     FROM(WS-DIAG-MSG)
                     LENGTH(LENGTH OF WS-DIAG-MSG)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *                   E N D   O F   O U S T M I N                  *
      *----------------------------------------------------------------*
