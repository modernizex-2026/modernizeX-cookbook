      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)
      *  PROGRAM : OUFLAG  -  Delinquency scan + expiry deactivation
      *  TYPE    : SUB  (CICS file control)
      *  FUNCTION: on-line port of batch OBDELQ (delinquency aging) and
      *            the expiry pass.  Browse ACCTFILE in account order;
      *            for each active account compute the minimum due, flag
      *            delinquency and classify it into a 30 / 60 / 90 aging
      *            bucket by credit utilisation, and capture accounts
      *            whose expiry date has passed the cutoff.  Expired
      *            accounts are then re-read for UPDATE and REWRITTEN
      *            with an inactive status.  Counts and money totals are
      *            returned in the KFLAG block overlaid on CA-WORK-AREA.
      *  CALL    : EXEC CICS LINK PROGRAM('OUFLAG')
      *                COMMAREA(ORION-COMMAREA)
      *                LENGTH(LENGTH OF ORION-COMMAREA) END-EXEC.
      *  FILES   : ACCTFILE browse and READ UPDATE / REWRITE.
      *  RETURN  : ends with GOBACK (subroutine convention).
      *****************************************************************
      *  MAINTENANCE LOG
      *  ----  ----------  -------------------------------------
      *  0001  2026-08-07  Original - on-line delinquency+expiry sub.
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUFLAG.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity.                                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUFLAG'.
      *----------------------------------------------------------------*
      *  Run-control switches.                                         *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-EOF-SW            PIC X(01) VALUE 'N'.
               88  WS-EOF-YES                 VALUE 'Y'.
               88  WS-EOF-NO                  VALUE 'N'.
           05  WS-BROWSE-SW         PIC X(01) VALUE 'N'.
               88  WS-BR-ON                   VALUE 'Y'.
               88  WS-BR-OFF                  VALUE 'N'.
           05  WS-CAPPED            PIC X(01) VALUE 'N'.
           05  WS-DO-DELQ           PIC X(01) VALUE 'N'.
               88  DO-DELQ                    VALUE 'Y'.
           05  WS-DO-EXPY           PIC X(01) VALUE 'N'.
               88  DO-EXPY                    VALUE 'Y'.
      *----------------------------------------------------------------*
      *  Computation work fields and program constants.               *
      *----------------------------------------------------------------*
       01  WS-CALC.
           05  WS-MIN-DUE           PIC S9(11)V99 VALUE ZEROS.
           05  WS-SHORTFALL         PIC S9(11)V99 VALUE ZEROS.
           05  WS-UTIL              PIC S9(05)V99 VALUE ZEROS.
       01  WS-CONSTANTS.
           05  WS-MIN-DUE-PCT       PIC S9(01)V9(04) VALUE +0.0200.
           05  WS-MIN-DUE-FLOOR     PIC S9(05)V99 VALUE +25.00.
           05  WS-MAX               PIC 9(07) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Expiry-candidate table - account ids captured during the      *
      *  browse and deactivated in a second pass.                      *
      *----------------------------------------------------------------*
       01  WS-EXP-TABLE.
           05  WS-EXP-CNT           PIC 9(04) VALUE ZERO.
           05  WS-MAX-EXP           PIC 9(04) VALUE 0300.
           05  WS-EXP-ENTRY OCCURS 300 TIMES
                           INDEXED BY WS-EX.
               10  WS-EXP-ID        PIC 9(11).
      *----------------------------------------------------------------*
      *  Shared constants and the account record layout.              *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RACCT.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KFLAG.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  top level driver.                               *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KFL-PARM TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INIT.
           IF KFL-STATUS NOT = '99'
               PERFORM 2000-POSITION
               IF WS-BR-ON
                   PERFORM 3000-SCAN-LOOP
                      UNTIL WS-EOF-YES
                         OR WS-CAPPED = 'Y'
                   PERFORM 4000-PEEK-NEXT
                   PERFORM 5000-END-BROWSE
                   IF DO-EXPY
                       PERFORM 5500-DEACTIVATE-EXPIRED
                   END-IF
               END-IF
           END-IF.
           PERFORM 6000-SET-STATUS.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INIT  -  reset the result area and validate the request. *
      *----------------------------------------------------------------*
       1000-INIT.
           SET WS-EOF-NO TO TRUE.
           SET WS-BR-OFF TO TRUE.
           MOVE 'N'    TO WS-CAPPED WS-DO-DELQ WS-DO-EXPY.
           MOVE ZERO   TO WS-EXP-CNT.
           MOVE '00'   TO KFL-STATUS.
           MOVE SPACES TO KFL-MSG.
           MOVE ZEROS  TO KFL-READ KFL-SKIPPED KFL-CURRENT KFL-DELQ.
           MOVE ZEROS  TO KFL-B30 KFL-B60 KFL-B90.
           MOVE ZEROS  TO KFL-EXPIRED KFL-ERRORS.
           MOVE ZEROS  TO KFL-DELQ-BAL KFL-SHORTFALL.
           MOVE ZEROS  TO KFL-NEXT-ACCT.
           MOVE 'N'    TO KFL-MORE.
           MOVE KFL-MAX TO WS-MAX.
           EVALUATE KFL-MODE
               WHEN 'BOTH'
                   SET DO-DELQ TO TRUE
                   SET DO-EXPY TO TRUE
               WHEN 'DELQ'
                   SET DO-DELQ TO TRUE
               WHEN 'EXPY'
                   SET DO-EXPY TO TRUE
               WHEN OTHER
                   MOVE '99' TO KFL-STATUS
                   MOVE 'INVALID MODE - BOTH / DELQ / EXPY' TO KFL-MSG
           END-EVALUATE.
           IF KFL-STATUS NOT = '99' AND DO-EXPY
               IF KFL-CUTOFF = SPACES OR KFL-CUTOFF = LOW-VALUES
                   MOVE '99' TO KFL-STATUS
                   MOVE 'EXPIRY CUTOFF DATE REQUIRED' TO KFL-MSG
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2000-POSITION  -  open the account browse at the resume key.
      *----------------------------------------------------------------*
       2000-POSITION.
           MOVE KFL-START-ACCT TO AC-ID.
           EXEC CICS STARTBR
                     FILE(WS-ACCTFILE)
                     RIDFLD(AC-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-BR-ON TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET WS-EOF-YES TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   MOVE '99' TO KFL-STATUS
                   MOVE 'ACCTFILE STARTBR FAILED' TO KFL-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3000-SCAN-LOOP  -  evaluate one account per iteration.        *
      *----------------------------------------------------------------*
       3000-SCAN-LOOP.
           PERFORM 3100-READ-ACCT.
           IF NOT WS-EOF-YES
               PERFORM 3200-EVAL-ACCT
               IF WS-MAX > ZEROS AND KFL-READ >= WS-MAX
                   MOVE 'Y' TO WS-CAPPED
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3100-READ-ACCT  -  advance the account browse.                *
      *----------------------------------------------------------------*
       3100-READ-ACCT.
           EXEC CICS READNEXT
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   SET WS-EOF-YES TO TRUE
                   ADD 1 TO KFL-ERRORS
                   MOVE 'ACCTFILE READNEXT FAILED' TO KFL-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-EVAL-ACCT  -  delinquency evaluation and expiry capture. *
      *  Inactive accounts are skipped for both passes.               *
      *----------------------------------------------------------------*
       3200-EVAL-ACCT.
           ADD 1 TO KFL-READ.
           IF AC-ACTIVE-STATUS = 'N'
               ADD 1 TO KFL-SKIPPED
               GO TO 3200-EXIT
           END-IF.
           IF DO-DELQ
               PERFORM 3300-EVAL-DELQ
           END-IF.
           IF DO-EXPY
               PERFORM 3400-CHECK-EXPIRY
           END-IF.
       3200-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3300-EVAL-DELQ  -  decide delinquency for one active account. *
      *----------------------------------------------------------------*
       3300-EVAL-DELQ.
           IF AC-CURR-BAL <= ZERO
               ADD 1 TO KFL-CURRENT
               GO TO 3300-EXIT
           END-IF.
           COMPUTE WS-MIN-DUE ROUNDED = AC-CURR-BAL * WS-MIN-DUE-PCT.
           IF WS-MIN-DUE < WS-MIN-DUE-FLOOR
               MOVE WS-MIN-DUE-FLOOR TO WS-MIN-DUE
           END-IF.
           IF AC-CYC-CREDIT >= WS-MIN-DUE
               ADD 1 TO KFL-CURRENT
           ELSE
               PERFORM 3310-FLAG-DELQ
           END-IF.
       3300-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3310-FLAG-DELQ  -  compute shortfall, utilisation and bucket. *
      *----------------------------------------------------------------*
       3310-FLAG-DELQ.
           ADD 1 TO KFL-DELQ.
           COMPUTE WS-SHORTFALL = WS-MIN-DUE - AC-CYC-CREDIT.
           IF WS-SHORTFALL < ZERO
               MOVE ZERO TO WS-SHORTFALL
           END-IF.
           IF AC-CREDIT-LIMIT > ZERO
               COMPUTE WS-UTIL ROUNDED =
                   (AC-CURR-BAL / AC-CREDIT-LIMIT) * 100
           ELSE
               MOVE 999.99 TO WS-UTIL
           END-IF.
           EVALUATE TRUE
               WHEN WS-UTIL >= 100.00
                   ADD 1 TO KFL-B90
               WHEN WS-UTIL >= 90.00
                   ADD 1 TO KFL-B60
               WHEN OTHER
                   ADD 1 TO KFL-B30
           END-EVALUATE.
           ADD AC-CURR-BAL  TO KFL-DELQ-BAL.
           ADD WS-SHORTFALL TO KFL-SHORTFALL.
      *----------------------------------------------------------------*
      *  3400-CHECK-EXPIRY  -  capture an account whose expiry date is *
      *  before the cutoff for deactivation in the second pass.        *
      *----------------------------------------------------------------*
       3400-CHECK-EXPIRY.
           IF AC-EXPIRY-DATE NOT = SPACES
              AND AC-EXPIRY-DATE NOT = LOW-VALUES
              AND AC-EXPIRY-DATE < KFL-CUTOFF
               IF WS-EXP-CNT < WS-MAX-EXP
                   ADD 1 TO WS-EXP-CNT
                   MOVE AC-ID TO WS-EXP-ID(WS-EXP-CNT)
                   IF WS-EXP-CNT >= WS-MAX-EXP
                       MOVE 'Y' TO WS-CAPPED
                   END-IF
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  4000-PEEK-NEXT  -  publish the resume key when the cap or the
      *  table limit stopped the scan short of end-of-file.            *
      *----------------------------------------------------------------*
       4000-PEEK-NEXT.
           IF WS-EOF-YES
               MOVE 'N' TO KFL-MORE
               GO TO 4000-EXIT
           END-IF.
           EXEC CICS READNEXT
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE 'Y'   TO KFL-MORE
                   MOVE AC-ID TO KFL-NEXT-ACCT
               WHEN DFHRESP(ENDFILE)
                   MOVE 'N' TO KFL-MORE
               WHEN OTHER
                   MOVE 'N' TO KFL-MORE
                   ADD 1 TO KFL-ERRORS
           END-EVALUATE.
       4000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5000-END-BROWSE  -  release the account browse position.
      *----------------------------------------------------------------*
       5000-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-ACCTFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  5500-DEACTIVATE-EXPIRED  -  second pass: re-read each captured
      *  account for UPDATE and rewrite it with an inactive status.
      *----------------------------------------------------------------*
       5500-DEACTIVATE-EXPIRED.
           PERFORM VARYING WS-EX FROM 1 BY 1
                   UNTIL WS-EX > WS-EXP-CNT
               PERFORM 5600-DEACTIVATE-ONE
           END-PERFORM.
      *----------------------------------------------------------------*
      *  5600-DEACTIVATE-ONE  -  update one expired account.           *
      *----------------------------------------------------------------*
       5600-DEACTIVATE-ONE.
           MOVE WS-EXP-ID(WS-EX) TO AC-ID.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               ADD 1 TO KFL-ERRORS
               GO TO 5600-EXIT
           END-IF.
           IF AC-ACTIVE-STATUS = 'N'
               EXEC CICS UNLOCK
                         FILE(WS-ACCTFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
               GO TO 5600-EXIT
           END-IF.
           MOVE 'N' TO AC-ACTIVE-STATUS.
           EXEC CICS REWRITE
                     FILE(WS-ACCTFILE)
                     FROM(ACCT-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KFL-EXPIRED
           ELSE
               ADD 1 TO KFL-ERRORS
           END-IF.
       5600-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  6000-SET-STATUS  -  publish the completion status and message.
      *----------------------------------------------------------------*
       6000-SET-STATUS.
           IF KFL-STATUS = '99'
               GO TO 6000-EXIT
           END-IF.
           IF KFL-READ = ZEROS
               MOVE '10' TO KFL-STATUS
               MOVE 'NO ACCOUNTS PROCESSED' TO KFL-MSG
           ELSE
               MOVE '00' TO KFL-STATUS
               MOVE 'ACCOUNT FLAGGING COMPLETE' TO KFL-MSG
           END-IF.
       6000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *                   E N D   O F   O U F L A G                    *
      *----------------------------------------------------------------*
