      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)
      *  PROGRAM : OUSTMB  -  Build monthly statements per account
      *  TYPE    : SUB  (CICS file control)
      *  FUNCTION: on-line port of batch OBSTMT.  Browse ACCTFILE in
      *            account-id order; for each account collect its cards
      *            from XREFFILE (alternate index on XR-ACCT-ID),
      *            aggregate every transaction from TRANFILE
      *            (alternate index on TR-CARD-NUM) into cycle credit
      *            and debit totals, compute opening / closing balance
      *            and minimum due, then WRITE (or REWRITE) the
      *            statement master (STMTFILE, key ST-KEY).  Counts and
      *            grand totals are returned in the KSTMTB block that is
      *            overlaid on the shared COMMAREA work area.
      *  CALL    : EXEC CICS LINK PROGRAM('OUSTMB')
      *                COMMAREA(ORION-COMMAREA)
      *                LENGTH(LENGTH OF ORION-COMMAREA) END-EXEC.
      *  FILES   : ACCTFILE browse, XREFFILE alt-index browse,
      *            TRANFILE alt-index browse, STMTFILE write / rewrite.
      *  RETURN  : ends with GOBACK (subroutine convention).
      *****************************************************************
      *  MAINTENANCE LOG
      *  ----  ----------  -------------------------------------
      *  0001  2026-08-07  Original - on-line statement build sub.
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUSTMB.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and alternate-index path names.              *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUSTMB'.
           05  WS-XREF-PATH         PIC X(08) VALUE 'XREFACCT'.
           05  WS-TRAN-PATH         PIC X(08) VALUE 'TRANCARD'.
      *----------------------------------------------------------------*
      *  Run-control switches.                                         *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-EOF-SW            PIC X(01) VALUE 'N'.
               88  WS-EOF-YES                 VALUE 'Y'.
               88  WS-EOF-NO                  VALUE 'N'.
           05  WS-BROWSE-SW         PIC X(01) VALUE 'N'.
               88  WS-BR-ON                   VALUE 'Y'.
               88  WS-BR-OFF                  VALUE 'N'.
           05  WS-XREF-EOF          PIC X(01) VALUE 'N'.
               88  WS-XREF-END                VALUE 'Y'.
           05  WS-TRAN-EOF          PIC X(01) VALUE 'N'.
               88  WS-TRAN-END                VALUE 'Y'.
           05  WS-CAPPED            PIC X(01) VALUE 'N'.
      *----------------------------------------------------------------*
      *  Card table - card numbers belonging to the current account.   *
      *----------------------------------------------------------------*
       01  WS-CARD-TABLE.
           05  WS-CARD-CNT          PIC 9(03) VALUE ZERO.
           05  WS-CARD-ENTRY OCCURS 20 TIMES
                            INDEXED BY WS-CX.
               10  WS-CARD-NUM      PIC X(16).
      *----------------------------------------------------------------*
      *  Per-account working accumulators, reset for every account.    *
      *----------------------------------------------------------------*
       01  WS-ACCT-WORK.
           05  WS-TOT-CREDIT        PIC S9(10)V99 VALUE ZERO.
           05  WS-TOT-DEBIT         PIC S9(10)V99 VALUE ZERO.
           05  WS-OPEN-BAL          PIC S9(10)V99 VALUE ZERO.
           05  WS-CLOSE-BAL         PIC S9(10)V99 VALUE ZERO.
           05  WS-MIN-DUE           PIC S9(10)V99 VALUE ZERO.
           05  WS-TRAN-THIS         PIC 9(05) VALUE ZERO.
           05  WS-TCYC-WORK.
               10  WS-TCYC-YY       PIC 9(04) VALUE ZERO.
               10  WS-TCYC-MM       PIC 9(02) VALUE ZERO.
           05  WS-TCYC REDEFINES WS-TCYC-WORK PIC 9(06).
      *----------------------------------------------------------------*
      *  Numeric constants and the run cap.                            *
      *----------------------------------------------------------------*
       01  WS-CONSTANTS.
           05  WS-MAX-CARDS         PIC 9(03) VALUE 20.
           05  WS-MAX               PIC 9(07) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Shared constants and record layouts (READ / READNEXT INTO).   *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RACCT.
       COPY RXREF.
       COPY RTRAN.
       COPY RSTMT.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KSTMTB.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  top level driver.                               *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KSM-PARM TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INIT.
           IF KSM-STATUS NOT = '99'
               PERFORM 2000-POSITION
               IF WS-BR-ON
                   PERFORM 3000-PROC-LOOP
                      UNTIL WS-EOF-YES
                         OR WS-CAPPED = 'Y'
                   PERFORM 4000-PEEK-NEXT
                   PERFORM 5000-END-BROWSE
               END-IF
           END-IF.
           PERFORM 6000-SET-STATUS.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INIT  -  reset the result area and validate the request. *
      *----------------------------------------------------------------*
       1000-INIT.
           SET WS-EOF-NO TO TRUE.
           SET WS-BR-OFF TO TRUE.
           MOVE 'N'   TO WS-CAPPED.
           MOVE '00'  TO KSM-STATUS.
           MOVE SPACES TO KSM-MSG.
           MOVE ZEROS TO KSM-ACCT-READ KSM-STMT-WRITTEN.
           MOVE ZEROS TO KSM-NO-TRAN KSM-ERRORS.
           MOVE ZEROS TO KSM-TOT-CREDIT KSM-TOT-DEBIT.
           MOVE ZEROS TO KSM-NEXT-ACCT.
           MOVE 'N'   TO KSM-MORE.
           MOVE KSM-MAX TO WS-MAX.
           IF KSM-CYCLE = ZEROS
               MOVE '99' TO KSM-STATUS
               MOVE 'STATEMENT CYCLE (YYYYMM) REQUIRED' TO KSM-MSG
           END-IF.
      *----------------------------------------------------------------*
      *  2000-POSITION  -  open the account browse at the resume key.
      *----------------------------------------------------------------*
       2000-POSITION.
           MOVE KSM-START-ACCT TO AC-ID.
           EXEC CICS STARTBR
                     FILE(WS-ACCTFILE)
                     RIDFLD(AC-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-BR-ON TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET WS-EOF-YES TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   MOVE '99' TO KSM-STATUS
                   MOVE 'ACCTFILE STARTBR FAILED' TO KSM-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3000-PROC-LOOP  -  process one account per iteration.         *
      *----------------------------------------------------------------*
       3000-PROC-LOOP.
           PERFORM 3100-READ-ACCT.
           IF NOT WS-EOF-YES
               PERFORM 3200-PROCESS-ACCT
               IF WS-MAX > ZEROS AND KSM-ACCT-READ >= WS-MAX
                   MOVE 'Y' TO WS-CAPPED
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3100-READ-ACCT  -  advance the account browse.                *
      *----------------------------------------------------------------*
       3100-READ-ACCT.
           EXEC CICS READNEXT
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   SET WS-EOF-YES TO TRUE
                   ADD 1 TO KSM-ERRORS
                   MOVE 'ACCTFILE READNEXT FAILED' TO KSM-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-PROCESS-ACCT  -  full statement build for one account.   *
      *----------------------------------------------------------------*
       3200-PROCESS-ACCT.
           ADD 1 TO KSM-ACCT-READ.
           PERFORM 3210-RESET.
           PERFORM 3220-COLLECT-CARDS.
           PERFORM 3300-SUM-TRANS.
           IF WS-TRAN-THIS = ZERO
               ADD 1 TO KSM-NO-TRAN
           END-IF.
           PERFORM 3400-COMPUTE.
           PERFORM 3500-WRITE-STMT.
           ADD WS-TOT-CREDIT TO KSM-TOT-CREDIT.
           ADD WS-TOT-DEBIT  TO KSM-TOT-DEBIT.
      *----------------------------------------------------------------*
      *  3210-RESET  -  clear the per-account working areas.           *
      *----------------------------------------------------------------*
       3210-RESET.
           MOVE ZERO TO WS-CARD-CNT.
           MOVE ZERO TO WS-TOT-CREDIT.
           MOVE ZERO TO WS-TOT-DEBIT.
           MOVE ZERO TO WS-OPEN-BAL.
           MOVE ZERO TO WS-CLOSE-BAL.
           MOVE ZERO TO WS-MIN-DUE.
           MOVE ZERO TO WS-TRAN-THIS.
      *----------------------------------------------------------------*
      *  3220-COLLECT-CARDS  -  browse the xref alternate index by     *
      *  account id and load every card number for this account.       *
      *----------------------------------------------------------------*
       3220-COLLECT-CARDS.
           MOVE 'N'   TO WS-XREF-EOF.
           MOVE AC-ID TO XR-ACCT-ID.
           EXEC CICS STARTBR
                     FILE(WS-XREF-PATH)
                     RIDFLD(XR-ACCT-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               SET WS-XREF-END TO TRUE
               GO TO 3220-EXIT
           END-IF.
           PERFORM 3230-READ-XREF-NEXT.
           PERFORM UNTIL WS-XREF-END
               IF XR-ACCT-ID = AC-ID
                   IF WS-CARD-CNT < WS-MAX-CARDS
                       ADD 1 TO WS-CARD-CNT
                       MOVE XR-CARD-NUM TO WS-CARD-NUM(WS-CARD-CNT)
                   END-IF
                   PERFORM 3230-READ-XREF-NEXT
               ELSE
                   SET WS-XREF-END TO TRUE
               END-IF
           END-PERFORM.
           EXEC CICS ENDBR
                     FILE(WS-XREF-PATH)
                     RESP(WS-RESP-CD)
           END-EXEC.
       3220-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3230-READ-XREF-NEXT  -  advance the xref alternate browse.
      *----------------------------------------------------------------*
       3230-READ-XREF-NEXT.
           EXEC CICS READNEXT
                     FILE(WS-XREF-PATH)
                     INTO(XREF-REC)
                     RIDFLD(XR-ACCT-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-XREF-END TO TRUE
               WHEN OTHER
                   SET WS-XREF-END TO TRUE
                   ADD 1 TO KSM-ERRORS
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3300-SUM-TRANS  -  aggregate transactions across every card.  *
      *----------------------------------------------------------------*
       3300-SUM-TRANS.
           PERFORM VARYING WS-CX FROM 1 BY 1
                   UNTIL WS-CX > WS-CARD-CNT
               PERFORM 3310-BROWSE-CARD
           END-PERFORM.
      *----------------------------------------------------------------*
      *  3310-BROWSE-CARD  -  browse the tran alternate index for one  *
      *  card and accumulate the cycle totals.                         *
      *----------------------------------------------------------------*
       3310-BROWSE-CARD.
           MOVE 'N'                TO WS-TRAN-EOF.
           MOVE WS-CARD-NUM(WS-CX) TO TR-CARD-NUM.
           EXEC CICS STARTBR
                     FILE(WS-TRAN-PATH)
                     RIDFLD(TR-CARD-NUM)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               SET WS-TRAN-END TO TRUE
               GO TO 3310-EXIT
           END-IF.
           PERFORM 3320-READ-TRAN-NEXT.
           PERFORM UNTIL WS-TRAN-END
               IF TR-CARD-NUM = WS-CARD-NUM(WS-CX)
                   PERFORM 3330-ACCUM
                   PERFORM 3320-READ-TRAN-NEXT
               ELSE
                   SET WS-TRAN-END TO TRUE
               END-IF
           END-PERFORM.
           EXEC CICS ENDBR
                     FILE(WS-TRAN-PATH)
                     RESP(WS-RESP-CD)
           END-EXEC.
       3310-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3320-READ-TRAN-NEXT  -  advance the tran alternate browse.
      *----------------------------------------------------------------*
       3320-READ-TRAN-NEXT.
           EXEC CICS READNEXT
                     FILE(WS-TRAN-PATH)
                     INTO(TRAN-REC)
                     RIDFLD(TR-CARD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-TRAN-END TO TRUE
               WHEN OTHER
                   SET WS-TRAN-END TO TRUE
                   ADD 1 TO KSM-ERRORS
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3330-ACCUM  -  classify one transaction as credit or debit.   *
      *----------------------------------------------------------------*
       3330-ACCUM.
      *    only aggregate transactions that fall in the requested
      *    statement cycle (KSM-CYCLE = YYYYMM); TR-PROC-TS is
      *    'YYYY-MM-DD-...' so YYYY = (1:4) and MM = (6:2).
           MOVE TR-PROC-TS (1:4) TO WS-TCYC-YY.
           MOVE TR-PROC-TS (6:2) TO WS-TCYC-MM.
           IF WS-TCYC = KSM-CYCLE
               ADD 1 TO WS-TRAN-THIS
               IF TR-TYPE-CD = 'PY' OR TR-TYPE-CD = 'CR'
                   ADD TR-AMT TO WS-TOT-CREDIT
               ELSE
                   ADD TR-AMT TO WS-TOT-DEBIT
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3400-COMPUTE  -  derive opening balance and minimum due.      *
      *----------------------------------------------------------------*
       3400-COMPUTE.
           MOVE AC-CURR-BAL TO WS-CLOSE-BAL.
           COMPUTE WS-OPEN-BAL =
               WS-CLOSE-BAL - WS-TOT-DEBIT + WS-TOT-CREDIT.
           IF WS-CLOSE-BAL <= ZERO
               MOVE ZERO TO WS-MIN-DUE
           ELSE
               COMPUTE WS-MIN-DUE ROUNDED = WS-CLOSE-BAL * 0.02
               IF WS-CLOSE-BAL <= 25.00
                   MOVE WS-CLOSE-BAL TO WS-MIN-DUE
               ELSE
                   IF WS-MIN-DUE < 25.00
                       MOVE 25.00 TO WS-MIN-DUE
                   END-IF
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3500-WRITE-STMT  -  write the statement; if a record already  *
      *  exists for this account and cycle, rewrite it in place.       *
      *----------------------------------------------------------------*
       3500-WRITE-STMT.
           MOVE SPACES        TO STMT-REC.
           MOVE AC-ID         TO ST-ACCT-ID.
           MOVE KSM-CYCLE     TO ST-CYCLE.
           MOVE WS-OPEN-BAL   TO ST-OPEN-BAL.
           MOVE WS-CLOSE-BAL  TO ST-CLOSE-BAL.
           MOVE WS-TOT-CREDIT TO ST-TOTAL-CREDIT.
           MOVE WS-TOT-DEBIT  TO ST-TOTAL-DEBIT.
           MOVE WS-MIN-DUE    TO ST-MIN-DUE.
           MOVE KSM-DUE-DATE  TO ST-DUE-DATE.
           EXEC CICS WRITE
                     FILE(WS-STMTFILE)
                     FROM(STMT-REC)
                     RIDFLD(ST-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KSM-STMT-WRITTEN
               WHEN DFHRESP(DUPREC)
                   PERFORM 3510-REWRITE-STMT
               WHEN OTHER
                   ADD 1 TO KSM-ERRORS
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3510-REWRITE-STMT  -  replace an existing statement record.
      *----------------------------------------------------------------*
       3510-REWRITE-STMT.
           EXEC CICS READ
                     FILE(WS-STMTFILE)
                     INTO(STMT-REC)
                     RIDFLD(ST-KEY)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               ADD 1 TO KSM-ERRORS
               GO TO 3510-EXIT
           END-IF.
           MOVE WS-OPEN-BAL   TO ST-OPEN-BAL.
           MOVE WS-CLOSE-BAL  TO ST-CLOSE-BAL.
           MOVE WS-TOT-CREDIT TO ST-TOTAL-CREDIT.
           MOVE WS-TOT-DEBIT  TO ST-TOTAL-DEBIT.
           MOVE WS-MIN-DUE    TO ST-MIN-DUE.
           MOVE KSM-DUE-DATE  TO ST-DUE-DATE.
           EXEC CICS REWRITE
                     FILE(WS-STMTFILE)
                     FROM(STMT-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KSM-STMT-WRITTEN
           ELSE
               ADD 1 TO KSM-ERRORS
           END-IF.
       3510-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  4000-PEEK-NEXT  -  when the cap stopped the run, look one
      *  account ahead to publish the resume key for the next page.
      *----------------------------------------------------------------*
       4000-PEEK-NEXT.
           IF WS-EOF-YES
               MOVE 'N' TO KSM-MORE
               GO TO 4000-EXIT
           END-IF.
           EXEC CICS READNEXT
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE 'Y'   TO KSM-MORE
                   MOVE AC-ID TO KSM-NEXT-ACCT
               WHEN DFHRESP(ENDFILE)
                   MOVE 'N' TO KSM-MORE
               WHEN OTHER
                   MOVE 'N' TO KSM-MORE
                   ADD 1 TO KSM-ERRORS
           END-EVALUATE.
       4000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5000-END-BROWSE  -  release the account browse position.
      *----------------------------------------------------------------*
       5000-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-ACCTFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  6000-SET-STATUS  -  publish the completion status and message.
      *----------------------------------------------------------------*
       6000-SET-STATUS.
           IF KSM-STATUS = '99'
               GO TO 6000-EXIT
           END-IF.
           IF KSM-ACCT-READ = ZEROS
               MOVE '10' TO KSM-STATUS
               MOVE 'NO ACCOUNTS PROCESSED' TO KSM-MSG
           ELSE
               MOVE '00' TO KSM-STATUS
               MOVE 'STATEMENT BUILD COMPLETE' TO KSM-MSG
           END-IF.
       6000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *                   E N D   O F   O U S T M B                    *
      *----------------------------------------------------------------*
