      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCACCTV  -  Account View (on-line)                *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: accept an account id, read the account master    *
      *            (ACCTFILE) and display the account details.      *
      *            PF3 = back to menu, PF4 = clear, ENTER = read.    *
      *  NOTE    : GOLDEN reference for all OC* online programs.     *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCACCTV.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCACCTV'.
           05  WS-TRANID            PIC X(04) VALUE 'ORAV'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RACCT.
       COPY RXREF.
       COPY MACCTV.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MACCTVAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Enter account id and press ENTER.' TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MACCTVA')
                     MAPSET('MACCTV')
                     FROM(MACCTVAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-READ-AND-SHOW
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
       2100-READ-AND-SHOW.
           EXEC CICS RECEIVE
                     MAP('MACCTVA')
                     MAPSET('MACCTV')
                     INTO(MACCTVAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF ACCTIDI = SPACES OR ACCTIDI = LOW-VALUES
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE ACCTIDI TO AC-ID
               MOVE AC-ID   TO CA-ACCT-ID
               PERFORM 3000-READ-ACCT
               IF REC-FOUND
                   PERFORM 4000-POPULATE-DETAIL
                   MOVE SPACES TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE WS-MSG-NOTFND TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
       3000-READ-ACCT.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   MOVE 'Error reading account file.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE AC-ID             TO ACCTIDO.
           MOVE AC-ACTIVE-STATUS  TO ACSTATO.
           MOVE AC-CURR-BAL       TO WS-ED-BAL.
           MOVE WS-ED-BAL         TO ACBALO.
           MOVE AC-CREDIT-LIMIT   TO WS-ED-AMT.
           MOVE WS-ED-AMT         TO ACCRLIMO.
           MOVE AC-CASH-LIMIT     TO WS-ED-AMT.
           MOVE WS-ED-AMT         TO ACCSLIMO.
           MOVE AC-OPEN-DATE      TO ACOPENO.
           MOVE AC-EXPIRY-DATE    TO ACEXPO.
           MOVE AC-GROUP-ID       TO ACGRPO.
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MACCTVA')
                     MAPSET('MACCTV')
                     FROM(MACCTVAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
