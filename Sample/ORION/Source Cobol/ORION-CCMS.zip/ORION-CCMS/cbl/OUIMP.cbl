      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)
      *  PROGRAM : OUIMP   -  Account import from a staged feed
      *  TYPE    : SUB  (CICS file control)
      *  FUNCTION: on-line port of batch OBIMP.  Browse the staged
      *            import feed (IMPFILE, KSDS key IMP-KEY) where each
      *            record carries one CSV-style account line, split the
      *            line with UNSTRING, validate the record type, key,
      *            status, monetary amounts and dates, then apply it to
      *            the account master (ACCTFILE) - REWRITE when the key
      *            exists, WRITE when it is new.  Invalid rows are
      *            counted with the last reject reason; header and non
      *            account rows are skipped.  Counts are returned in the
      *            KIMP block overlaid on the shared COMMAREA work area.
      *  CALL    : EXEC CICS LINK PROGRAM('OUIMP')
      *                COMMAREA(ORION-COMMAREA)
      *                LENGTH(LENGTH OF ORION-COMMAREA) END-EXEC.
      *  FILES   : IMPFILE browse, ACCTFILE READ UPDATE / REWRITE /
      *            WRITE.
      *  RETURN  : ends with GOBACK (subroutine convention).
      *****************************************************************
      *  MAINTENANCE LOG
      *  ----  ----------  -------------------------------------
      *  0001  2026-08-07  Original - on-line account import sub.
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUIMP.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity and the staging file name.                  *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUIMP'.
           05  WS-IMPFILE           PIC X(08) VALUE 'IMPFILE'.
      *----------------------------------------------------------------*
      *  Run-control switches.                                         *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-EOF-SW            PIC X(01) VALUE 'N'.
               88  WS-EOF-YES                 VALUE 'Y'.
               88  WS-EOF-NO                  VALUE 'N'.
           05  WS-BROWSE-SW         PIC X(01) VALUE 'N'.
               88  WS-BR-ON                   VALUE 'Y'.
               88  WS-BR-OFF                  VALUE 'N'.
           05  WS-CAPPED            PIC X(01) VALUE 'N'.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  REC-VALID                  VALUE 'Y'.
               88  REC-INVALID                VALUE 'N'.
           05  WS-EXIST-SW          PIC X(01) VALUE 'N'.
               88  ACCT-EXISTS                VALUE 'Y'.
           05  WS-DT-OK             PIC X(01) VALUE 'N'.
      *----------------------------------------------------------------*
      *  Staged feed record (key + CSV data payload).                 *
      *----------------------------------------------------------------*
       01  WS-IMP-REC.
           05  IMP-KEY              PIC X(08).
           05  IMP-DATA             PIC X(300).
      *----------------------------------------------------------------*
      *  Parsed raw text fields (from UNSTRING).                      *
      *----------------------------------------------------------------*
       01  WS-FIELDS.
           05  WS-F-TYPE            PIC X(08).
           05  WS-F-ID              PIC X(11).
           05  WS-F-STATUS          PIC X(04).
           05  WS-F-BAL             PIC X(20).
           05  WS-F-CRLIM           PIC X(20).
           05  WS-F-CSLIM           PIC X(20).
           05  WS-F-OPEN            PIC X(12).
           05  WS-F-EXPIRY          PIC X(12).
           05  WS-F-REISS           PIC X(12).
           05  WS-F-CYCR            PIC X(20).
           05  WS-F-CYDR            PIC X(20).
           05  WS-F-ZIP             PIC X(12).
           05  WS-F-GROUP           PIC X(12).
      *----------------------------------------------------------------*
      *  Converted numeric values.                                     *
      *----------------------------------------------------------------*
       01  WS-PARSED.
           05  WS-N-ID              PIC 9(11)     VALUE ZEROS.
           05  WS-N-BAL             PIC S9(10)V99 VALUE ZEROS.
           05  WS-N-CRLIM           PIC S9(10)V99 VALUE ZEROS.
           05  WS-N-CSLIM           PIC S9(10)V99 VALUE ZEROS.
           05  WS-N-CYCR            PIC S9(10)V99 VALUE ZEROS.
           05  WS-N-CYDR            PIC S9(10)V99 VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Validation work fields.                                       *
      *----------------------------------------------------------------*
       01  WS-VAL-WORK.
           05  WS-TYPE-CHK          PIC X(08) VALUE SPACES.
           05  WS-STATUS-CHK        PIC X(04) VALUE SPACES.
           05  WS-REJ-REASON        PIC X(20) VALUE SPACES.
           05  WS-DT-IN             PIC X(12) VALUE SPACES.
           05  WS-DT                PIC X(10) VALUE SPACES.
           05  WS-FLD-CNT           PIC 9(03) VALUE ZEROS.
           05  WS-MAX               PIC 9(07) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Shared constants and the account record layout.              *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RACCT.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KIMP.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN  -  top level driver.                               *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KIM-PARM TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INIT.
           IF KIM-STATUS NOT = '99'
               PERFORM 2000-POSITION
               IF WS-BR-ON
                   PERFORM 3000-IMPORT-LOOP
                      UNTIL WS-EOF-YES
                         OR WS-CAPPED = 'Y'
                   PERFORM 4000-PEEK-NEXT
                   PERFORM 5000-END-BROWSE
               END-IF
           END-IF.
           PERFORM 6000-SET-STATUS.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INIT  -  reset the result area.                          *
      *----------------------------------------------------------------*
       1000-INIT.
           SET WS-EOF-NO TO TRUE.
           SET WS-BR-OFF TO TRUE.
           MOVE 'N'    TO WS-CAPPED.
           MOVE '00'   TO KIM-STATUS.
           MOVE SPACES TO KIM-MSG.
           MOVE ZEROS  TO KIM-READ KIM-ADDED KIM-UPDATED.
           MOVE ZEROS  TO KIM-ACCEPTED KIM-REJECTED KIM-SKIPPED.
           MOVE ZEROS  TO KIM-ERRORS.
           MOVE SPACES TO KIM-LAST-REASON KIM-LAST-KEY KIM-NEXT-KEY.
           MOVE 'N'    TO KIM-MORE.
           MOVE KIM-MAX TO WS-MAX.
      *----------------------------------------------------------------*
      *  2000-POSITION  -  open the staging browse at the resume key.
      *----------------------------------------------------------------*
       2000-POSITION.
           IF KIM-START-KEY = SPACES OR KIM-START-KEY = LOW-VALUES
               MOVE LOW-VALUES TO IMP-KEY
           ELSE
               MOVE KIM-START-KEY TO IMP-KEY
           END-IF.
           EXEC CICS STARTBR
                     FILE(WS-IMPFILE)
                     RIDFLD(IMP-KEY)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET WS-BR-ON TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET WS-EOF-YES TO TRUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   MOVE '99' TO KIM-STATUS
                   MOVE 'IMPFILE STARTBR FAILED' TO KIM-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3000-IMPORT-LOOP  -  process one staged line per iteration.   *
      *----------------------------------------------------------------*
       3000-IMPORT-LOOP.
           PERFORM 3100-READ-LINE.
           IF NOT WS-EOF-YES
               PERFORM 3200-PROCESS-LINE
               IF WS-MAX > ZEROS AND KIM-READ >= WS-MAX
                   MOVE 'Y' TO WS-CAPPED
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3100-READ-LINE  -  advance the staging browse.                *
      *----------------------------------------------------------------*
       3100-READ-LINE.
           EXEC CICS READNEXT
                     FILE(WS-IMPFILE)
                     INTO(WS-IMP-REC)
                     RIDFLD(IMP-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   CONTINUE
               WHEN DFHRESP(ENDFILE)
                   SET WS-EOF-YES TO TRUE
               WHEN OTHER
                   SET WS-EOF-YES TO TRUE
                   ADD 1 TO KIM-ERRORS
                   MOVE 'IMPFILE READNEXT FAILED' TO KIM-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-PROCESS-LINE  -  classify and apply one staged line.     *
      *----------------------------------------------------------------*
       3200-PROCESS-LINE.
           ADD 1 TO KIM-READ.
           PERFORM 3300-PARSE-LINE.
           MOVE FUNCTION TRIM (WS-F-TYPE) TO WS-TYPE-CHK.
           EVALUATE WS-TYPE-CHK
               WHEN 'RECTYPE'
                   ADD 1 TO KIM-SKIPPED
               WHEN 'CUST'
                   ADD 1 TO KIM-SKIPPED
               WHEN 'ACCT'
                   PERFORM 3400-VALIDATE
                   IF REC-VALID
                       PERFORM 3600-APPLY-ACCT
                   ELSE
                       PERFORM 3700-REJECT
                   END-IF
               WHEN OTHER
                   MOVE 'UNKNOWN RECTYPE' TO WS-REJ-REASON
                   PERFORM 3700-REJECT
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3300-PARSE-LINE  -  split the CSV payload into raw fields.
      *----------------------------------------------------------------*
       3300-PARSE-LINE.
           MOVE SPACES TO WS-FIELDS.
           MOVE ZERO   TO WS-FLD-CNT.
           UNSTRING IMP-DATA DELIMITED BY ','
               INTO WS-F-TYPE   WS-F-ID     WS-F-STATUS
                    WS-F-BAL    WS-F-CRLIM  WS-F-CSLIM
                    WS-F-OPEN   WS-F-EXPIRY WS-F-REISS
                    WS-F-CYCR   WS-F-CYDR   WS-F-ZIP
                    WS-F-GROUP
               TALLYING IN WS-FLD-CNT
           END-UNSTRING.
      *----------------------------------------------------------------*
      *  3400-VALIDATE  -  field-level edits; set reason on failure.
      *----------------------------------------------------------------*
       3400-VALIDATE.
           SET REC-VALID  TO TRUE.
           MOVE SPACES    TO WS-REJ-REASON.
           IF WS-FLD-CNT < 13
               SET REC-INVALID TO TRUE
               MOVE 'TOO FEW FIELDS' TO WS-REJ-REASON
           END-IF.
           IF REC-VALID
               PERFORM 3410-CHK-ID
           END-IF.
           IF REC-VALID
               PERFORM 3420-CHK-STATUS
           END-IF.
           IF REC-VALID
               PERFORM 3430-CHK-AMOUNTS
           END-IF.
           IF REC-VALID
               PERFORM 3440-CHK-DATES
           END-IF.
      *----------------------------------------------------------------*
      *  3410-CHK-ID  -  account id must be numeric and non-zero.
      *----------------------------------------------------------------*
       3410-CHK-ID.
           IF FUNCTION TEST-NUMVAL (WS-F-ID) NOT = 0
               SET REC-INVALID TO TRUE
               MOVE 'INVALID ACCOUNT ID' TO WS-REJ-REASON
           ELSE
               COMPUTE WS-N-ID = FUNCTION NUMVAL (WS-F-ID)
               IF WS-N-ID = ZERO
                   SET REC-INVALID TO TRUE
                   MOVE 'ACCOUNT ID IS ZERO' TO WS-REJ-REASON
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3420-CHK-STATUS  -  active status must be Y or N.             *
      *----------------------------------------------------------------*
       3420-CHK-STATUS.
           MOVE FUNCTION TRIM (WS-F-STATUS) TO WS-STATUS-CHK.
           IF WS-STATUS-CHK NOT = 'Y' AND WS-STATUS-CHK NOT = 'N'
               SET REC-INVALID TO TRUE
               MOVE 'STATUS NOT Y OR N' TO WS-REJ-REASON
           END-IF.
      *----------------------------------------------------------------*
      *  3430-CHK-AMOUNTS  -  five monetary fields must be numeric.
      *----------------------------------------------------------------*
       3430-CHK-AMOUNTS.
           IF FUNCTION TEST-NUMVAL (WS-F-BAL) NOT = 0
               SET REC-INVALID TO TRUE
               MOVE 'INVALID BALANCE' TO WS-REJ-REASON
           ELSE
               COMPUTE WS-N-BAL = FUNCTION NUMVAL (WS-F-BAL)
           END-IF.
           IF REC-VALID
               IF FUNCTION TEST-NUMVAL (WS-F-CRLIM) NOT = 0
                   SET REC-INVALID TO TRUE
                   MOVE 'INVALID CREDIT LIMIT' TO WS-REJ-REASON
               ELSE
                   COMPUTE WS-N-CRLIM = FUNCTION NUMVAL (WS-F-CRLIM)
               END-IF
           END-IF.
           IF REC-VALID
               IF FUNCTION TEST-NUMVAL (WS-F-CSLIM) NOT = 0
                   SET REC-INVALID TO TRUE
                   MOVE 'INVALID CASH LIMIT' TO WS-REJ-REASON
               ELSE
                   COMPUTE WS-N-CSLIM = FUNCTION NUMVAL (WS-F-CSLIM)
               END-IF
           END-IF.
           IF REC-VALID
               IF FUNCTION TEST-NUMVAL (WS-F-CYCR) NOT = 0
                   SET REC-INVALID TO TRUE
                   MOVE 'INVALID CYC CREDIT' TO WS-REJ-REASON
               ELSE
                   COMPUTE WS-N-CYCR = FUNCTION NUMVAL (WS-F-CYCR)
               END-IF
           END-IF.
           IF REC-VALID
               IF FUNCTION TEST-NUMVAL (WS-F-CYDR) NOT = 0
                   SET REC-INVALID TO TRUE
                   MOVE 'INVALID CYC DEBIT' TO WS-REJ-REASON
               ELSE
                   COMPUTE WS-N-CYDR = FUNCTION NUMVAL (WS-F-CYDR)
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3440-CHK-DATES  -  open / expiry / reissue must be YYYY-MM-DD.
      *----------------------------------------------------------------*
       3440-CHK-DATES.
           MOVE WS-F-OPEN TO WS-DT-IN.
           PERFORM 3450-CHK-DATE.
           IF WS-DT-OK NOT = 'Y'
               SET REC-INVALID TO TRUE
               MOVE 'INVALID OPEN DATE' TO WS-REJ-REASON
           END-IF.
           IF REC-VALID
               MOVE WS-F-EXPIRY TO WS-DT-IN
               PERFORM 3450-CHK-DATE
               IF WS-DT-OK NOT = 'Y'
                   SET REC-INVALID TO TRUE
                   MOVE 'INVALID EXPIRY DATE' TO WS-REJ-REASON
               END-IF
           END-IF.
           IF REC-VALID
               MOVE WS-F-REISS TO WS-DT-IN
               PERFORM 3450-CHK-DATE
               IF WS-DT-OK NOT = 'Y'
                   SET REC-INVALID TO TRUE
                   MOVE 'INVALID REISSUE DATE' TO WS-REJ-REASON
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3450-CHK-DATE  -  verify the YYYY-MM-DD shape of WS-DT-IN.
      *----------------------------------------------------------------*
       3450-CHK-DATE.
           MOVE 'N' TO WS-DT-OK.
           MOVE FUNCTION TRIM (WS-DT-IN) TO WS-DT.
           IF WS-DT (5:1) = '-' AND WS-DT (8:1) = '-'
               IF WS-DT (1:4) IS NUMERIC
                  AND WS-DT (6:2) IS NUMERIC
                  AND WS-DT (9:2) IS NUMERIC
                   MOVE 'Y' TO WS-DT-OK
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3600-APPLY-ACCT  -  add or update the account master.         *
      *----------------------------------------------------------------*
       3600-APPLY-ACCT.
           MOVE WS-N-ID TO AC-ID.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET ACCT-EXISTS TO TRUE
               WHEN DFHRESP(NOTFND)
                   MOVE 'N' TO WS-EXIST-SW
               WHEN OTHER
                   MOVE 'READ ERROR' TO WS-REJ-REASON
                   PERFORM 3700-REJECT
                   GO TO 3600-EXIT
           END-EVALUATE.
           PERFORM 3610-BUILD-REC.
           IF ACCT-EXISTS
               EXEC CICS REWRITE
                         FILE(WS-ACCTFILE)
                         FROM(ACCT-REC)
                         RESP(WS-RESP-CD)
               END-EXEC
               IF WS-RESP-CD = DFHRESP(NORMAL)
                   ADD 1 TO KIM-UPDATED
                   ADD 1 TO KIM-ACCEPTED
               ELSE
                   MOVE 'REWRITE FAILED' TO WS-REJ-REASON
                   PERFORM 3700-REJECT
               END-IF
           ELSE
               EXEC CICS WRITE
                         FILE(WS-ACCTFILE)
                         FROM(ACCT-REC)
                         RIDFLD(AC-ID)
                         RESP(WS-RESP-CD)
               END-EXEC
               IF WS-RESP-CD = DFHRESP(NORMAL)
                   ADD 1 TO KIM-ADDED
                   ADD 1 TO KIM-ACCEPTED
               ELSE
                   MOVE 'WRITE FAILED' TO WS-REJ-REASON
                   PERFORM 3700-REJECT
               END-IF
           END-IF.
       3600-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3610-BUILD-REC  -  move validated values into the record.
      *----------------------------------------------------------------*
       3610-BUILD-REC.
           MOVE SPACES TO ACCT-REC.
           MOVE WS-N-ID       TO AC-ID.
           MOVE WS-STATUS-CHK TO AC-ACTIVE-STATUS.
           MOVE WS-N-BAL      TO AC-CURR-BAL.
           MOVE WS-N-CRLIM    TO AC-CREDIT-LIMIT.
           MOVE WS-N-CSLIM    TO AC-CASH-LIMIT.
           MOVE FUNCTION TRIM (WS-F-OPEN)   TO AC-OPEN-DATE.
           MOVE FUNCTION TRIM (WS-F-EXPIRY) TO AC-EXPIRY-DATE.
           MOVE FUNCTION TRIM (WS-F-REISS)  TO AC-REISSUE-DATE.
           MOVE WS-N-CYCR     TO AC-CYC-CREDIT.
           MOVE WS-N-CYDR     TO AC-CYC-DEBIT.
           MOVE FUNCTION TRIM (WS-F-ZIP)    TO AC-ADDR-ZIP.
           MOVE FUNCTION TRIM (WS-F-GROUP)  TO AC-GROUP-ID.
      *----------------------------------------------------------------*
      *  3700-REJECT  -  count one rejected line and keep the reason.
      *----------------------------------------------------------------*
       3700-REJECT.
           ADD 1 TO KIM-REJECTED.
           MOVE WS-REJ-REASON TO KIM-LAST-REASON.
           MOVE IMP-KEY       TO KIM-LAST-KEY.
      *----------------------------------------------------------------*
      *  4000-PEEK-NEXT  -  publish the resume key when the cap stopped
      *  the run short of end-of-file.                                 *
      *----------------------------------------------------------------*
       4000-PEEK-NEXT.
           IF WS-EOF-YES
               MOVE 'N' TO KIM-MORE
               GO TO 4000-EXIT
           END-IF.
           EXEC CICS READNEXT
                     FILE(WS-IMPFILE)
                     INTO(WS-IMP-REC)
                     RIDFLD(IMP-KEY)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE 'Y'     TO KIM-MORE
                   MOVE IMP-KEY TO KIM-NEXT-KEY
               WHEN DFHRESP(ENDFILE)
                   MOVE 'N' TO KIM-MORE
               WHEN OTHER
                   MOVE 'N' TO KIM-MORE
                   ADD 1 TO KIM-ERRORS
           END-EVALUATE.
       4000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  5000-END-BROWSE  -  release the staging browse position.
      *----------------------------------------------------------------*
       5000-END-BROWSE.
           EXEC CICS ENDBR
                     FILE(WS-IMPFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  6000-SET-STATUS  -  publish the completion status and message.
      *----------------------------------------------------------------*
       6000-SET-STATUS.
           IF KIM-STATUS = '99'
               GO TO 6000-EXIT
           END-IF.
           IF KIM-READ = ZEROS
               MOVE '10' TO KIM-STATUS
               MOVE 'IMPORT FEED IS EMPTY' TO KIM-MSG
           ELSE
               MOVE '00' TO KIM-STATUS
               MOVE 'ACCOUNT IMPORT COMPLETE' TO KIM-MSG
           END-IF.
       6000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *                   E N D   O F   O U I M P                      *
      *----------------------------------------------------------------*
