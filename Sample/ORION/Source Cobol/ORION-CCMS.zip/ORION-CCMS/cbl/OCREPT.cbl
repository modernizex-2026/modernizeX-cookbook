      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCREPT   -  Report Request (on-line)             *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: accept a report type and a from/to date range.    *
      *            Validate the dates through subroutine OUDATE, then *
      *            browse the requested file (BILLFILE for bill       *
      *            payments, TRANFILE for transactions) with STARTBR /*
      *            READNEXT / ENDBR, accumulate a count and a total   *
      *            for records whose date falls inside the range and  *
      *            display the summary on the screen.                 *
      *  MAP     : MREPTA of mapset MREPT.                           *
      *  TRANID  : ORRP.  PF3 = menu, PF4 = clear, ENTER = run.      *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCREPT.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identification constants.                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCREPT'.
           05  WS-TRANID            PIC X(04) VALUE 'ORRP'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Report work fields.                                           *
      *----------------------------------------------------------------*
       01  WS-REPORT-WORK.
           05  WS-RPT-TYPE          PIC X(02) VALUE SPACES.
               88  RPT-BILLS                 VALUE '01'.
               88  RPT-TRANS                 VALUE '02'.
           05  WS-FROM-DATE         PIC X(10) VALUE SPACES.
           05  WS-TO-DATE           PIC X(10) VALUE SPACES.
           05  WS-REC-DATE          PIC X(10) VALUE SPACES.
           05  WS-TOTAL             PIC S9(13)V99 VALUE ZEROS.
           05  WS-RPT-COUNT         PIC 9(07) VALUE ZEROS.
           05  WS-BROWSE-FLG        PIC X(01) VALUE 'N'.
               88  BROWSE-STARTED            VALUE 'Y'.
               88  BROWSE-NOT-STARTED        VALUE 'N'.
      *----------------------------------------------------------------*
      *  Display-editing fields for the summary line.                  *
      *----------------------------------------------------------------*
       01  WS-EDIT-FIELDS.
           05  WS-ED-CNT            PIC ZZZZZZ9.
           05  WS-ED-TOT            PIC -,---,---,---,--9.99.
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY RBILL.
       COPY RTRAN.
       COPY KDATE.
       COPY MREPT.
       COPY DFHAID.
       COPY DFHBMSCA.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN : pseudo-conversational entry point.                *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               MOVE SPACES      TO CA-ERR-MSG
               IF CA-FIRST-ENTER
                   PERFORM 1000-SEND-INITIAL
               ELSE
                   PERFORM 2000-PROCESS-INPUT
               END-IF
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL : paint an empty request screen.            *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MREPTAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE 'Type 01=Bills 02=Trans, dates YYYY-MM-DD.'
               TO ERRMSGO.
           EXEC CICS SEND
                     MAP('MREPTA')
                     MAPSET('MREPT')
                     FROM(MREPTAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT : dispatch on the AID key.                 *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHENTER
                   PERFORM 2100-RUN-REPORT
               WHEN OTHER
                   PERFORM 1000-SEND-INITIAL
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2100-RUN-REPORT : receive input, validate it and, when valid, *
      *  produce the requested summary.                                *
      *----------------------------------------------------------------*
       2100-RUN-REPORT.
           PERFORM 2110-RECEIVE-MAP.
           PERFORM 2120-VALIDATE-TYPE.
           IF ERR-FLG-ON
               PERFORM 8100-SEND-DATAONLY
               GO TO 2100-EXIT
           END-IF.
           PERFORM 2130-VALIDATE-DATES.
           IF ERR-FLG-ON
               PERFORM 8100-SEND-DATAONLY
               GO TO 2100-EXIT
           END-IF.
           MOVE ZEROS TO WS-TOTAL.
           MOVE ZEROS TO WS-RPT-COUNT.
           EVALUATE TRUE
               WHEN RPT-BILLS
                   PERFORM 2200-REPORT-BILLS
               WHEN RPT-TRANS
                   PERFORM 2300-REPORT-TRANS
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Unsupported report type.' TO ERRMSGO
           END-EVALUATE.
           IF ERR-FLG-OFF
               PERFORM 2400-BUILD-SUMMARY
           END-IF.
           PERFORM 8100-SEND-DATAONLY.
       2100-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2110-RECEIVE-MAP : read the report request into MREPTAI.      *
      *----------------------------------------------------------------*
       2110-RECEIVE-MAP.
           EXEC CICS RECEIVE
                     MAP('MREPTA')
                     MAPSET('MREPT')
                     INTO(MREPTAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  2120-VALIDATE-TYPE : the report type must be 01 or 02.        *
      *----------------------------------------------------------------*
       2120-VALIDATE-TYPE.
           SET ERR-FLG-OFF TO TRUE.
           IF RPTYPEI = SPACES OR RPTYPEI = LOW-VALUES
               SET ERR-FLG-ON TO TRUE
               MOVE 'Report type is required.' TO ERRMSGO
               GO TO 2120-EXIT
           END-IF.
           MOVE RPTYPEI TO WS-RPT-TYPE.
           IF NOT (RPT-BILLS OR RPT-TRANS)
               SET ERR-FLG-ON TO TRUE
               MOVE 'Report type must be 01 or 02.' TO ERRMSGO
           END-IF.
       2120-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2130-VALIDATE-DATES : both dates are required and must be     *
      *  valid calendar dates (checked by OUDATE), and the from date   *
      *  cannot be later than the to date.                             *
      *----------------------------------------------------------------*
       2130-VALIDATE-DATES.
           SET ERR-FLG-OFF TO TRUE.
           IF RPFROMI = SPACES OR RPFROMI = LOW-VALUES
              OR RPTOI = SPACES OR RPTOI = LOW-VALUES
               SET ERR-FLG-ON TO TRUE
               MOVE 'From and to dates are required.' TO ERRMSGO
               GO TO 2130-EXIT
           END-IF.
           MOVE RPFROMI TO WS-FROM-DATE.
           MOVE RPTOI   TO WS-TO-DATE.
           MOVE 'VALD'       TO KD-FUNC.
           MOVE WS-FROM-DATE TO KD-DATE-IN.
           MOVE SPACES       TO KD-DATE-OUT.
           CALL 'OUDATE' USING KDATE-PARM.
           IF KD-STATUS NOT = '00'
               SET ERR-FLG-ON TO TRUE
               MOVE 'From date is not a valid date.' TO ERRMSGO
               GO TO 2130-EXIT
           END-IF.
           MOVE 'VALD'     TO KD-FUNC.
           MOVE WS-TO-DATE TO KD-DATE-IN.
           MOVE SPACES     TO KD-DATE-OUT.
           CALL 'OUDATE' USING KDATE-PARM.
           IF KD-STATUS NOT = '00'
               SET ERR-FLG-ON TO TRUE
               MOVE 'To date is not a valid date.' TO ERRMSGO
               GO TO 2130-EXIT
           END-IF.
           IF WS-FROM-DATE > WS-TO-DATE
               SET ERR-FLG-ON TO TRUE
               MOVE 'From date is later than to date.' TO ERRMSGO
           END-IF.
       2130-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2200-REPORT-BILLS : browse BILLFILE, count and total the      *
      *  bill payments whose pay date is inside the range.             *
      *----------------------------------------------------------------*
       2200-REPORT-BILLS.
           SET ERR-FLG-OFF TO TRUE.
           MOVE 'N' TO WS-END-FLG.
           MOVE ZEROS TO BL-ID.
           PERFORM 2210-STARTBR-BILL.
           IF ERR-FLG-ON
               GO TO 2200-EXIT
           END-IF.
           PERFORM 2220-READ-BILLS UNTIL END-OF-FILE.
           PERFORM 2230-ENDBR-BILL.
       2200-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2210-STARTBR-BILL : position the browse at the start of the   *
      *  bill payment file.                                            *
      *----------------------------------------------------------------*
       2210-STARTBR-BILL.
           EXEC CICS STARTBR
                     FILE(WS-BILLFILE)
                     RIDFLD(BL-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BROWSE-STARTED TO TRUE
               WHEN DFHRESP(NOTFND)
                   MOVE 'Y' TO WS-END-FLG
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error starting bill browse.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2220-READ-BILLS : read the next bill record and, when it is   *
      *  in range, accumulate the count and amount.                    *
      *----------------------------------------------------------------*
       2220-READ-BILLS.
           EXEC CICS READNEXT
                     FILE(WS-BILLFILE)
                     INTO(BILL-REC)
                     RIDFLD(BL-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE BL-PAY-DATE TO WS-REC-DATE
                   IF WS-REC-DATE >= WS-FROM-DATE
                      AND WS-REC-DATE <= WS-TO-DATE
                       ADD 1          TO WS-RPT-COUNT
                       ADD BL-AMOUNT  TO WS-TOTAL
                   END-IF
               WHEN DFHRESP(ENDFILE)
                   MOVE 'Y' TO WS-END-FLG
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error reading bill file.' TO ERRMSGO
                   MOVE 'Y' TO WS-END-FLG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2230-ENDBR-BILL : terminate the bill browse.                  *
      *----------------------------------------------------------------*
       2230-ENDBR-BILL.
           EXEC CICS ENDBR
                     FILE(WS-BILLFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  2300-REPORT-TRANS : browse TRANFILE, count and total the      *
      *  transactions whose origination date is inside the range.      *
      *----------------------------------------------------------------*
       2300-REPORT-TRANS.
           SET ERR-FLG-OFF TO TRUE.
           MOVE 'N' TO WS-END-FLG.
           MOVE LOW-VALUES TO TR-ID.
           PERFORM 2310-STARTBR-TRAN.
           IF ERR-FLG-ON
               GO TO 2300-EXIT
           END-IF.
           PERFORM 2320-READ-TRANS UNTIL END-OF-FILE.
           PERFORM 2330-ENDBR-TRAN.
       2300-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  2310-STARTBR-TRAN : position the browse at the start of the   *
      *  transaction file.                                            *
      *----------------------------------------------------------------*
       2310-STARTBR-TRAN.
           EXEC CICS STARTBR
                     FILE(WS-TRANFILE)
                     RIDFLD(TR-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BROWSE-STARTED TO TRUE
               WHEN DFHRESP(NOTFND)
                   MOVE 'Y' TO WS-END-FLG
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error starting tran browse.' TO ERRMSGO
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2320-READ-TRANS : read the next transaction and, when it is   *
      *  in range, accumulate the count and amount.  The first ten     *
      *  characters of the origination timestamp hold the date.        *
      *----------------------------------------------------------------*
       2320-READ-TRANS.
           EXEC CICS READNEXT
                     FILE(WS-TRANFILE)
                     INTO(TRAN-REC)
                     RIDFLD(TR-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   MOVE TR-ORIG-TS(1:10) TO WS-REC-DATE
                   IF WS-REC-DATE >= WS-FROM-DATE
                      AND WS-REC-DATE <= WS-TO-DATE
                       ADD 1       TO WS-RPT-COUNT
                       ADD TR-AMT  TO WS-TOTAL
                   END-IF
               WHEN DFHRESP(ENDFILE)
                   MOVE 'Y' TO WS-END-FLG
               WHEN OTHER
                   SET ERR-FLG-ON TO TRUE
                   MOVE 'Error reading tran file.' TO ERRMSGO
                   MOVE 'Y' TO WS-END-FLG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2330-ENDBR-TRAN : terminate the transaction browse.           *
      *----------------------------------------------------------------*
       2330-ENDBR-TRAN.
           EXEC CICS ENDBR
                     FILE(WS-TRANFILE)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  2400-BUILD-SUMMARY : format the count and total into the      *
      *  message line.                                                *
      *----------------------------------------------------------------*
       2400-BUILD-SUMMARY.
           MOVE WS-RPT-COUNT TO WS-ED-CNT.
           MOVE WS-TOTAL     TO WS-ED-TOT.
           MOVE SPACES       TO ERRMSGO.
           STRING 'Type '   DELIMITED BY SIZE
                  WS-RPT-TYPE DELIMITED BY SIZE
                  ' Count: ' DELIMITED BY SIZE
                  WS-ED-CNT   DELIMITED BY SIZE
                  ' Total: ' DELIMITED BY SIZE
                  WS-ED-TOT   DELIMITED BY SIZE
                  INTO ERRMSGO
           END-STRING.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU : return control to the main menu.            *
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER : fill the standard screen header.       *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY : resend the map without erasing.          *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MREPTA')
                     MAPSET('MREPT')
                     FROM(MREPTAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME : obtain the current date and time.        *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN : return pseudo-conversationally.                 *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
