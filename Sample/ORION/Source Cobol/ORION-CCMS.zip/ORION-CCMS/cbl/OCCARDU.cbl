      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OCCARDU  -  Card Update (on-line)                 *
      *  TYPE    : CICS ONLINE  (pseudo-conversational)             *
      *  FUNCTION: read a card by CD-NUM, display it and let the     *
      *            operator change the embossed name, expiry date    *
      *            and active status, then REWRITE the CARDFILE      *
      *            record.                                           *
      *  KEYS    : ENTER = read / validate                          *
      *            PF5   = save (confirm) the change                *
      *            PF3   = main menu       PF4 = clear               *
      *  STATE   : CA-WORK-AREA(1:1)  'K' key entry / 'E' edit       *
      *  NOTE    : modelled on the GOLDEN template OCACCTV.         *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OCCARDU.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity constants.                                   *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OCCARDU'.
           05  WS-TRANID            PIC X(04) VALUE 'ORCU'.
           05  WS-MENU-PGM          PIC X(08) VALUE 'OCMENU'.
      *----------------------------------------------------------------*
      *  Validation / update switches.                               *
      *----------------------------------------------------------------*
       01  WS-WORK-FLAGS.
           05  WS-VALID-SW          PIC X(01) VALUE 'Y'.
               88  WS-VALID                   VALUE 'Y'.
               88  WS-INVALID                 VALUE 'N'.
           05  WS-UPD-SW            PIC X(01) VALUE 'N'.
               88  WS-UPD-OK                  VALUE 'Y'.
               88  WS-UPD-BAD                 VALUE 'N'.
      *----------------------------------------------------------------*
      *  State byte constants.                                        *
      *----------------------------------------------------------------*
       01  WS-STATE-CONST.
           05  WS-ST-KEY            PIC X(01) VALUE 'K'.
           05  WS-ST-EDIT           PIC X(01) VALUE 'E'.
      *----------------------------------------------------------------*
      *  Card number validation work area.                           *
      *----------------------------------------------------------------*
       01  WS-CARDCHK.
           05  WS-CN-IN             PIC X(16) VALUE SPACES.
           05  WS-CN-POS            PIC 9(02) VALUE ZEROS.
           05  WS-CN-CHAR           PIC X(01) VALUE SPACES.
           05  WS-CN-DIGITS         PIC 9(02) VALUE ZEROS.
      *----------------------------------------------------------------*
      *  Validated new field values, staged before the REWRITE.       *
      *----------------------------------------------------------------*
       01  WS-NEW-VALUES.
           05  WS-NEW-NAME          PIC X(50) VALUE SPACES.
           05  WS-NEW-EXPIRY        PIC X(10) VALUE SPACES.
           05  WS-NEW-STATUS        PIC X(01) VALUE SPACES.
      *----------------------------------------------------------------*
      *  Shared copybooks.                                            *
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY WMSG.
       COPY WHEAD.
       COPY KCOMM.
       COPY KDATE.
       COPY RCARD.
       COPY MCARDU.
       COPY DFHAID.
       COPY DFHBMSCA.
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-COMMAREA          PIC X(01)
               OCCURS 1 TO 32767 TIMES DEPENDING ON EIBCALEN.
      *----------------------------------------------------------------*
       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
      *  0000-MAIN : standard dispatcher.                            *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ERR-FLG-OFF TO TRUE.
           MOVE SPACES TO CA-ERR-MSG.
           IF EIBCALEN = 0
               INITIALIZE ORION-COMMAREA
               PERFORM 1000-SEND-INITIAL
           ELSE
               MOVE DFHCOMMAREA TO ORION-COMMAREA
               EVALUATE TRUE
                   WHEN CA-FIRST-ENTER
                       PERFORM 1000-SEND-INITIAL
                   WHEN OTHER
                       PERFORM 2000-PROCESS-INPUT
               END-EVALUATE
           END-IF.
           PERFORM 9000-RETURN.
      *----------------------------------------------------------------*
      *  1000-SEND-INITIAL : prompt for a card number.              *
      *----------------------------------------------------------------*
       1000-SEND-INITIAL.
           MOVE LOW-VALUES TO MCARDUAO.
           PERFORM 8000-POPULATE-HEADER.
           MOVE WS-ST-KEY TO CA-WORK-AREA(1:1).
           IF CA-CARD-NUM = SPACES OR CA-CARD-NUM = LOW-VALUES
               MOVE 'Enter card number and press ENTER.' TO ERRMSGO
           ELSE
               MOVE CA-CARD-NUM TO CARDNUMO
               MOVE 'Press ENTER to load the selected card.'
                   TO ERRMSGO
           END-IF.
           EXEC CICS SEND
                     MAP('MCARDUA')
                     MAPSET('MCARDU')
                     FROM(MCARDUAO)
                     ERASE
                     RESP(WS-RESP-CD)
           END-EXEC.
           MOVE 1 TO CA-PGM-CONTEXT.
      *----------------------------------------------------------------*
      *  2000-PROCESS-INPUT : react to the attention identifier.      *
      *----------------------------------------------------------------*
       2000-PROCESS-INPUT.
           EVALUATE EIBAID
               WHEN DFHPF3
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF12
                   PERFORM 7000-XCTL-MENU
               WHEN DFHPF4
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHCLEAR
                   PERFORM 1000-SEND-INITIAL
               WHEN DFHPF5
                   PERFORM 2300-SAVE
               WHEN DFHENTER
                   PERFORM 2100-ENTER
               WHEN OTHER
                   MOVE WS-MSG-INVALID-KEY TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2050-RECEIVE : read the map; treat MAPFAIL as empty input.   *
      *----------------------------------------------------------------*
       2050-RECEIVE.
           EXEC CICS RECEIVE
                     MAP('MCARDUA')
                     MAPSET('MCARDU')
                     INTO(MCARDUAI)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(MAPFAIL)
               MOVE LOW-VALUES TO MCARDUAI
           END-IF.
      *----------------------------------------------------------------*
      *  2100-ENTER : ENTER key - branch on the current state.        *
      *----------------------------------------------------------------*
       2100-ENTER.
           PERFORM 2050-RECEIVE.
           EVALUATE CA-WORK-AREA(1:1)
               WHEN WS-ST-EDIT
                   PERFORM 2250-VALIDATE-ONLY
               WHEN OTHER
                   PERFORM 2200-LOOKUP
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  2200-LOOKUP : key state - read the card and open for edit.   *
      *----------------------------------------------------------------*
       2200-LOOKUP.
           PERFORM 6000-VALIDATE-CARDNUM.
           IF WS-INVALID
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE WS-CN-IN TO CD-NUM
               MOVE CD-NUM   TO CA-CARD-NUM
               PERFORM 3000-READ-CARD
               IF REC-FOUND
                   PERFORM 4000-POPULATE-DETAIL
                   MOVE WS-ST-EDIT TO CA-WORK-AREA(1:1)
                   MOVE 'Card found. Change fields, PF5 to save.'
                       TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   MOVE WS-MSG-NOTFND TO ERRMSGO
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  2250-VALIDATE-ONLY : edit state, ENTER - validate only.      *
      *----------------------------------------------------------------*
       2250-VALIDATE-ONLY.
           PERFORM 5000-VALIDATE-ALL.
           IF WS-INVALID
               PERFORM 8100-SEND-DATAONLY
           ELSE
               MOVE 'Changes are valid.  Press PF5 to confirm save.'
                   TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           END-IF.
      *----------------------------------------------------------------*
      *  2300-SAVE : PF5 - re-validate then REWRITE the card.         *
      *----------------------------------------------------------------*
       2300-SAVE.
           IF CA-WORK-AREA(1:1) NOT = WS-ST-EDIT
               MOVE 'Enter a card number and press ENTER first.'
                   TO ERRMSGO
               PERFORM 8100-SEND-DATAONLY
           ELSE
               PERFORM 2050-RECEIVE
               PERFORM 5000-VALIDATE-ALL
               IF WS-INVALID
                   PERFORM 8100-SEND-DATAONLY
               ELSE
                   PERFORM 3500-UPDATE-CARD
                   IF WS-UPD-OK
                       PERFORM 4000-POPULATE-DETAIL
                   END-IF
                   PERFORM 8100-SEND-DATAONLY
               END-IF
           END-IF.
      *----------------------------------------------------------------*
      *  3000-READ-CARD : random read of CARDFILE by CD-NUM.         *
      *----------------------------------------------------------------*
       3000-READ-CARD.
           SET REC-NOT-FOUND TO TRUE.
           EXEC CICS READ
                     FILE(WS-CARDFILE)
                     INTO(CARD-REC)
                     RIDFLD(CD-NUM)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET REC-FOUND TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET REC-NOT-FOUND TO TRUE
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3500-UPDATE-CARD : READ UPDATE, apply and REWRITE.          *
      *----------------------------------------------------------------*
       3500-UPDATE-CARD.
           SET WS-UPD-BAD TO TRUE.
           MOVE CA-CARD-NUM TO CD-NUM.
           EXEC CICS READ
                     FILE(WS-CARDFILE)
                     INTO(CARD-REC)
                     RIDFLD(CD-NUM)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   PERFORM 3600-APPLY-UPDATE
               WHEN DFHRESP(NOTFND)
                   MOVE 'Card no longer exists. Update aborted.'
                       TO ERRMSGO
               WHEN OTHER
                   PERFORM 9500-ABEND-RTN
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3600-APPLY-UPDATE : move new values in and REWRITE.          *
      *----------------------------------------------------------------*
       3600-APPLY-UPDATE.
           MOVE WS-NEW-NAME   TO CD-EMBOSSED-NAME.
           MOVE WS-NEW-EXPIRY TO CD-EXPIRY-DATE.
           MOVE WS-NEW-STATUS TO CD-ACTIVE-STATUS.
           EXEC CICS REWRITE
                     FILE(WS-CARDFILE)
                     FROM(CARD-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               SET WS-UPD-OK TO TRUE
               MOVE 'Card updated successfully.' TO ERRMSGO
           ELSE
               MOVE 'Update failed during REWRITE.' TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  4000-POPULATE-DETAIL : move CARD-REC into the output map.    *
      *----------------------------------------------------------------*
       4000-POPULATE-DETAIL.
           MOVE CD-NUM            TO CARDNUMO.
           MOVE CD-EMBOSSED-NAME  TO CDNAMEO.
           MOVE CD-EXPIRY-DATE    TO CDEXPO.
           MOVE CD-ACTIVE-STATUS  TO CDSTATO.
      *----------------------------------------------------------------*
      *  5000-VALIDATE-ALL : drive the individual field validations.  *
      *----------------------------------------------------------------*
       5000-VALIDATE-ALL.
           SET WS-VALID TO TRUE.
           MOVE SPACES TO ERRMSGO.
           IF WS-VALID
               PERFORM 5010-VAL-NAME
           END-IF.
           IF WS-VALID
               PERFORM 5020-VAL-EXPIRY
           END-IF.
           IF WS-VALID
               PERFORM 5030-VAL-STATUS
           END-IF.
      *----------------------------------------------------------------*
      *  5010-VAL-NAME : embossed name is required.                  *
      *----------------------------------------------------------------*
       5010-VAL-NAME.
           IF CDNAMEI = SPACES OR CDNAMEI = LOW-VALUES
               SET WS-INVALID TO TRUE
               MOVE 'Embossed name is required.' TO ERRMSGO
           ELSE
               MOVE CDNAMEI TO WS-NEW-NAME
           END-IF.
      *----------------------------------------------------------------*
      *  5020-VAL-EXPIRY : expiry date validated by OUDATE (VALD).    *
      *----------------------------------------------------------------*
       5020-VAL-EXPIRY.
           MOVE 'VALD'  TO KD-FUNC.
           MOVE CDEXPI  TO KD-DATE-IN.
           MOVE SPACES  TO KD-DATE-OUT.
           MOVE '00'    TO KD-STATUS.
           CALL 'OUDATE' USING KDATE-PARM.
           IF KD-STATUS = '00'
               MOVE CDEXPI TO WS-NEW-EXPIRY
           ELSE
               SET WS-INVALID TO TRUE
               MOVE 'Expiry date invalid, use YYYY-MM-DD.' TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  5030-VAL-STATUS : active status must be Y or N.             *
      *----------------------------------------------------------------*
       5030-VAL-STATUS.
           IF CDSTATI = 'Y' OR CDSTATI = 'N'
               MOVE CDSTATI TO WS-NEW-STATUS
           ELSE
               SET WS-INVALID TO TRUE
               MOVE 'Active status must be Y or N.' TO ERRMSGO
           END-IF.
      *----------------------------------------------------------------*
      *  6000-VALIDATE-CARDNUM : card number must be 16 digits.       *
      *----------------------------------------------------------------*
       6000-VALIDATE-CARDNUM.
           SET WS-VALID TO TRUE.
           MOVE CARDNUMI TO WS-CN-IN.
           INSPECT WS-CN-IN REPLACING ALL LOW-VALUE BY SPACE.
           IF WS-CN-IN = SPACES
               SET WS-INVALID TO TRUE
               MOVE WS-MSG-REQUIRED TO ERRMSGO
               GO TO 6000-EXIT
           END-IF.
           MOVE ZEROS TO WS-CN-DIGITS.
           PERFORM VARYING WS-CN-POS FROM 1 BY 1
                   UNTIL WS-CN-POS > 16
               MOVE WS-CN-IN(WS-CN-POS:1) TO WS-CN-CHAR
               IF WS-CN-CHAR >= '0' AND WS-CN-CHAR <= '9'
                   ADD 1 TO WS-CN-DIGITS
               ELSE
                   SET WS-INVALID TO TRUE
               END-IF
           END-PERFORM.
           IF WS-INVALID OR WS-CN-DIGITS NOT = 16
               SET WS-INVALID TO TRUE
               MOVE 'Card number must be exactly 16 digits.'
                   TO ERRMSGO
           END-IF.
       6000-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  7000-XCTL-MENU : return to the main menu.                    *
      *----------------------------------------------------------------*
       7000-XCTL-MENU.
           MOVE WS-PGMNAME TO CA-FROM-PROGRAM.
           MOVE WS-TRANID  TO CA-FROM-TRANID.
           MOVE 0          TO CA-PGM-CONTEXT.
           EXEC CICS XCTL
                     PROGRAM(WS-MENU-PGM)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8000-POPULATE-HEADER : common screen header.                *
      *----------------------------------------------------------------*
       8000-POPULATE-HEADER.
           MOVE WS-TRANID    TO TRNNAMEO.
           MOVE WS-PGMNAME   TO PGMNAMEO.
           MOVE WS-HDR-TITLE TO TITLEO.
           PERFORM 8500-GET-DATE-TIME.
           MOVE WS-HDR-DATE  TO CURDATEO.
           MOVE WS-HDR-TIME  TO CURTIMEO.
      *----------------------------------------------------------------*
      *  8100-SEND-DATAONLY : refresh header and resend.             *
      *----------------------------------------------------------------*
       8100-SEND-DATAONLY.
           PERFORM 8000-POPULATE-HEADER.
           EXEC CICS SEND
                     MAP('MCARDUA')
                     MAPSET('MCARDU')
                     FROM(MCARDUAO)
                     DATAONLY
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  8500-GET-DATE-TIME : formatted current date and time.        *
      *----------------------------------------------------------------*
       8500-GET-DATE-TIME.
           EXEC CICS ASKTIME
                     ABSTIME(WS-AMT)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS FORMATTIME
                     ABSTIME(WS-AMT)
                     DATESEP('-')
                     YYYYMMDD(WS-HDR-DATE)
                     TIME(WS-HDR-TIME)
                     TIMESEP(':')
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9000-RETURN : pseudo-conversational return.                 *
      *----------------------------------------------------------------*
       9000-RETURN.
           EXEC CICS RETURN
                     TRANSID(WS-TRANID)
                     COMMAREA(ORION-COMMAREA)
                     RESP(WS-RESP-CD)
           END-EXEC.
      *----------------------------------------------------------------*
      *  9500-ABEND-RTN : unrecoverable file error.                  *
      *----------------------------------------------------------------*
       9500-ABEND-RTN.
           MOVE 'OCCARDU: unrecoverable file error. Contact support.'
               TO WS-MSG-TEXT.
           EXEC CICS SEND TEXT
                     FROM(WS-MSG-TEXT)
                     LENGTH(LENGTH OF WS-MSG-TEXT)
                     ERASE
                     FREEKB
                     RESP(WS-RESP-CD)
           END-EXEC.
           EXEC CICS RETURN
                     RESP(WS-RESP-CD)
           END-EXEC.
