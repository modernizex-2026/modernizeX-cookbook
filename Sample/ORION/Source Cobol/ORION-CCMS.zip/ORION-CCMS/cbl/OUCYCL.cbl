      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUCYCL  -  Cycle / end-of-month roll SUB          *
      *  TYPE    : SUB  (CICS file control)                          *
      *  FUNCTION: roll the billing cycle on demand.  Browses the     *
      *            account master (ACCTFILE); for every account it    *
      *            captures the cycle credit and debit, posts the net *
      *            cycle activity to the running balance              *
      *            (new = current + cycle-debit - cycle-credit),       *
      *            classifies the carried-forward balance (zero /      *
      *            current / over-limit / in-credit), READs the        *
      *            account for UPDATE, stores new balance, resets     *
      *            the cycle credit / debit buckets to zero and        *
      *            REWRITEs the account.  Consolidates the batch       *
      *            OBCYCL, OBREOM and OBBALFWD cycle programs.         *
      *  CALL    : EXEC CICS LINK PROGRAM('OUCYCL')                   *
      *                COMMAREA(ORION-COMMAREA) END-EXEC.             *
      *  REQUEST : KO-PARM-ACCT optional single account (0 = all).    *
      *  RESULT  : KO-READ read       KO-POSTED rolled                *
      *            KO-UPDATE rewritten KO-SELECT rolled with activity  *
      *            KO-C1 over-limit    KO-C2 zero    KO-C3 in-credit   *
      *            KO-AMT-1 cycle credit  KO-AMT-2 cycle debit         *
      *            KO-AMT-3 forward balance total.                     *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUCYCL.
       AUTHOR.     ORION-CCMS-ONLINE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *----------------------------------------------------------------*
      *  Program identity.                                             *
      *----------------------------------------------------------------*
       01  WS-PROGRAM-VARS.
           05  WS-PGMNAME           PIC X(08) VALUE 'OUCYCL'.
      *----------------------------------------------------------------*
      *  Browse and control switches.                                  *
      *----------------------------------------------------------------*
       01  WS-FLAGS.
           05  WS-BR-END-SW         PIC X(01) VALUE 'N'.
               88  BR-END                     VALUE 'Y'.
               88  BR-MORE                    VALUE 'N'.
           05  WS-BR-STARTED-SW     PIC X(01) VALUE 'N'.
               88  BR-STARTED                 VALUE 'Y'.
               88  BR-NOT-STARTED             VALUE 'N'.
           05  WS-FILTER-ON         PIC X(01) VALUE 'N'.
               88  FILTER-ACTIVE              VALUE 'Y'.
      *----------------------------------------------------------------*
      *  Per-account capture / computation work fields.                *
      *----------------------------------------------------------------*
       01  WS-CALC.
           05  WS-OLD-BAL           PIC S9(11)V99 VALUE ZEROS.
           05  WS-NEW-BAL           PIC S9(11)V99 VALUE ZEROS.
           05  WS-CAP-CREDIT        PIC S9(10)V99 VALUE ZEROS.
           05  WS-CAP-DEBIT         PIC S9(10)V99 VALUE ZEROS.
           05  WS-FILTER-ACCT       PIC 9(11)     VALUE ZEROS.
      *----------------------------------------------------------------*
       COPY WCONST.
       COPY RACCT.
      *----------------------------------------------------------------*
       LINKAGE SECTION.
       COPY KCOMM.
       COPY KOPS.
      *================================================================*
       PROCEDURE DIVISION USING ORION-COMMAREA.
      *----------------------------------------------------------------*
      *  0000-MAIN : overlay request, run the browse, return.          *
      *----------------------------------------------------------------*
       0000-MAIN.
           SET ADDRESS OF KOPS-AREA TO ADDRESS OF CA-WORK-AREA.
           PERFORM 1000-INITIALISE.
           PERFORM 3000-BROWSE-DRIVER.
           PERFORM 9000-FINALISE.
           GOBACK.
      *----------------------------------------------------------------*
      *  1000-INITIALISE : clear results, note any single filter.      *
      *----------------------------------------------------------------*
       1000-INITIALISE.
           SET KO-OK TO TRUE.
           MOVE SPACES TO KO-STATUS-MSG.
           MOVE ZEROS TO KO-READ-CNT.
           MOVE ZEROS TO KO-SELECT-CNT.
           MOVE ZEROS TO KO-UPDATE-CNT.
           MOVE ZEROS TO KO-POSTED-CNT.
           MOVE ZEROS TO KO-REJECT-CNT.
           MOVE ZEROS TO KO-SKIP-CNT.
           MOVE ZEROS TO KO-TRAN-CNT.
           MOVE ZEROS TO KO-C1.
           MOVE ZEROS TO KO-C2.
           MOVE ZEROS TO KO-C3.
           MOVE ZEROS TO KO-AMT-1.
           MOVE ZEROS TO KO-AMT-2.
           MOVE ZEROS TO KO-AMT-3.
           MOVE 'N' TO WS-FILTER-ON.
           IF KO-PARM-ACCT > ZERO
               MOVE KO-PARM-ACCT TO WS-FILTER-ACCT
               SET FILTER-ACTIVE TO TRUE
           END-IF.
           SET BR-MORE TO TRUE.
           SET BR-NOT-STARTED TO TRUE.
      *----------------------------------------------------------------*
      *  3000-BROWSE-DRIVER : browse accounts and roll each cycle.     *
      *----------------------------------------------------------------*
       3000-BROWSE-DRIVER.
           PERFORM 3100-START-BROWSE.
           IF BR-STARTED
               PERFORM 3200-READ-NEXT-ACCT
               PERFORM 4000-PROCESS-ACCT
                   UNTIL BR-END OR KO-ERROR
               PERFORM 3400-END-BROWSE
           END-IF.
      *----------------------------------------------------------------*
      *  3100-START-BROWSE : STARTBR at filter key or file start.      *
      *----------------------------------------------------------------*
       3100-START-BROWSE.
           IF FILTER-ACTIVE
               MOVE WS-FILTER-ACCT TO AC-ID
           ELSE
               MOVE ZEROS TO AC-ID
           END-IF.
           EXEC CICS STARTBR
                     FILE(WS-ACCTFILE)
                     RIDFLD(AC-ID)
                     GTEQ
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   SET BR-STARTED TO TRUE
               WHEN DFHRESP(NOTFND)
                   SET BR-END TO TRUE
                   MOVE 'NO ACCOUNTS TO ROLL.' TO KO-STATUS-MSG
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'STARTBR ACCTFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  3200-READ-NEXT-ACCT : read one account forward.               *
      *----------------------------------------------------------------*
       3200-READ-NEXT-ACCT.
           EXEC CICS READNEXT
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     RESP(WS-RESP-CD)
           END-EXEC.
           EVALUATE WS-RESP-CD
               WHEN DFHRESP(NORMAL)
                   ADD 1 TO KO-READ-CNT
               WHEN DFHRESP(ENDFILE)
                   SET BR-END TO TRUE
               WHEN OTHER
                   SET BR-END TO TRUE
                   SET KO-ERROR TO TRUE
                   MOVE 'READNEXT ACCTFILE FAILED.' TO KO-STATUS-MSG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4000-PROCESS-ACCT : capture, classify and roll one account.   *
      *----------------------------------------------------------------*
       4000-PROCESS-ACCT.
           IF FILTER-ACTIVE AND AC-ID NOT = WS-FILTER-ACCT
               SET BR-END TO TRUE
           ELSE
               PERFORM 4100-CAPTURE
               PERFORM 4200-CLASSIFY
               PERFORM 4300-ROLL-CYCLE
               PERFORM 3200-READ-NEXT-ACCT
           END-IF.
      *----------------------------------------------------------------*
      *  4100-CAPTURE : save the cycle figures and post the net.       *
      *----------------------------------------------------------------*
       4100-CAPTURE.
           MOVE AC-CURR-BAL   TO WS-OLD-BAL.
           MOVE AC-CYC-CREDIT TO WS-CAP-CREDIT.
           MOVE AC-CYC-DEBIT  TO WS-CAP-DEBIT.
           COMPUTE WS-NEW-BAL =
               AC-CURR-BAL + AC-CYC-DEBIT - AC-CYC-CREDIT.
           IF WS-CAP-CREDIT NOT = ZERO OR WS-CAP-DEBIT NOT = ZERO
               ADD 1 TO KO-SELECT-CNT
           END-IF.
           ADD WS-CAP-CREDIT TO KO-AMT-1.
           ADD WS-CAP-DEBIT  TO KO-AMT-2.
      *----------------------------------------------------------------*
      *  4200-CLASSIFY : bucket the carried-forward balance.           *
      *----------------------------------------------------------------*
       4200-CLASSIFY.
           EVALUATE TRUE
               WHEN WS-NEW-BAL < ZERO
                   ADD 1 TO KO-C3
               WHEN WS-NEW-BAL = ZERO
                   ADD 1 TO KO-C2
               WHEN WS-NEW-BAL > AC-CREDIT-LIMIT
                   ADD 1 TO KO-C1
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *----------------------------------------------------------------*
      *  4300-ROLL-CYCLE : READ for UPDATE, post net, reset, REWRITE.  *
      *----------------------------------------------------------------*
       4300-ROLL-CYCLE.
           EXEC CICS READ
                     FILE(WS-ACCTFILE)
                     INTO(ACCT-REC)
                     RIDFLD(AC-ID)
                     UPDATE
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD NOT = DFHRESP(NORMAL)
               ADD 1 TO KO-REJECT-CNT
               GO TO 4300-EXIT
           END-IF.
           MOVE WS-NEW-BAL TO AC-CURR-BAL.
           MOVE ZERO TO AC-CYC-CREDIT.
           MOVE ZERO TO AC-CYC-DEBIT.
           EXEC CICS REWRITE
                     FILE(WS-ACCTFILE)
                     FROM(ACCT-REC)
                     RESP(WS-RESP-CD)
           END-EXEC.
           IF WS-RESP-CD = DFHRESP(NORMAL)
               ADD 1 TO KO-POSTED-CNT
               ADD 1 TO KO-UPDATE-CNT
               ADD WS-NEW-BAL TO KO-AMT-3
           ELSE
               ADD 1 TO KO-REJECT-CNT
           END-IF.
       4300-EXIT.
           EXIT.
      *----------------------------------------------------------------*
      *  3400-END-BROWSE : release the account browse.                 *
      *----------------------------------------------------------------*
       3400-END-BROWSE.
           IF BR-STARTED
               EXEC CICS ENDBR
                         FILE(WS-ACCTFILE)
                         RESP(WS-RESP-CD)
               END-EXEC
           END-IF.
      *----------------------------------------------------------------*
      *  9000-FINALISE : set the completion status message.            *
      *----------------------------------------------------------------*
       9000-FINALISE.
           IF KO-ERROR
               CONTINUE
           ELSE
               IF KO-REJECT-CNT > 0
                   SET KO-WARN TO TRUE
               ELSE
                   SET KO-OK TO TRUE
               END-IF
               MOVE 'CYCLE ROLL PROCESSING COMPLETE.' TO KO-STATUS-MSG
           END-IF.
