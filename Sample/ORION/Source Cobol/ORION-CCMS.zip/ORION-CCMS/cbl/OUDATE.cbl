      *****************************************************************
      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *
      *  PROGRAM : OUDATE  -  date utility subroutine               *
      *  TYPE    : SUBROUTINE (CALL / EXEC CICS LINK)               *
      *  FUNCTION: VALD = validate YYYY-MM-DD ; TODY = current date ;*
      *            FMT  = pass through (already YYYY-MM-DD).          *
      *  CALL    : CALL 'OUDATE' USING KDATE-PARM.                   *
      *****************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. OUDATE.
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-WORK.
           05  WS-CURR              PIC X(21).
           05  WS-Y                 PIC 9(04).
           05  WS-M                 PIC 9(02).
           05  WS-D                 PIC 9(02).
           05  WS-DIM               PIC 9(02).
       01  WS-DATE-N REDEFINES WS-WORK.
           05  FILLER               PIC X(21).
       01  WS-EDIT-DATE.
           05  WS-ED-Y              PIC 9(04).
           05  FILLER               PIC X(01) VALUE '-'.
           05  WS-ED-M              PIC 9(02).
           05  FILLER               PIC X(01) VALUE '-'.
           05  WS-ED-D              PIC 9(02).
       LINKAGE SECTION.
       COPY KDATE.
       PROCEDURE DIVISION USING KDATE-PARM.
       0000-MAIN.
           MOVE '00' TO KD-STATUS.
           EVALUATE KD-FUNC
               WHEN 'TODY'  PERFORM 1000-TODAY
               WHEN 'VALD'  PERFORM 2000-VALIDATE
               WHEN 'FMT '  MOVE KD-DATE-IN TO KD-DATE-OUT
               WHEN OTHER   MOVE '99' TO KD-STATUS
           END-EVALUATE.
           GOBACK.
      *----------------------------------------------------------------*
       1000-TODAY.
           MOVE FUNCTION CURRENT-DATE TO WS-CURR.
           MOVE WS-CURR(1:4) TO WS-ED-Y.
           MOVE WS-CURR(5:2) TO WS-ED-M.
           MOVE WS-CURR(7:2) TO WS-ED-D.
           MOVE WS-EDIT-DATE TO KD-DATE-OUT.
      *----------------------------------------------------------------*
       2000-VALIDATE.
           MOVE KD-DATE-IN TO KD-DATE-OUT.
           IF KD-DATE-IN(1:4) NOT NUMERIC
              OR KD-DATE-IN(6:2) NOT NUMERIC
              OR KD-DATE-IN(9:2) NOT NUMERIC
               MOVE '99' TO KD-STATUS
               GO TO 2000-EXIT
           END-IF.
           MOVE KD-DATE-IN(1:4) TO WS-Y.
           MOVE KD-DATE-IN(6:2) TO WS-M.
           MOVE KD-DATE-IN(9:2) TO WS-D.
           IF WS-M < 1 OR WS-M > 12
               MOVE '99' TO KD-STATUS
               GO TO 2000-EXIT
           END-IF.
           EVALUATE WS-M
               WHEN 2  MOVE 29 TO WS-DIM
               WHEN 4  MOVE 30 TO WS-DIM
               WHEN 6  MOVE 30 TO WS-DIM
               WHEN 9  MOVE 30 TO WS-DIM
               WHEN 11 MOVE 30 TO WS-DIM
               WHEN OTHER MOVE 31 TO WS-DIM
           END-EVALUATE.
           IF WS-D < 1 OR WS-D > WS-DIM
               MOVE '99' TO KD-STATUS
           END-IF.
       2000-EXIT.
           EXIT.
