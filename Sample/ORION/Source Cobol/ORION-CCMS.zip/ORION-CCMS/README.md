# ORION-CCMS — ORION Credit Card Management System

An **original**, **online-centric** credit-card management application for
**IBM z/OS — Enterprise COBOL + CICS + BMS + VSAM + DB2 + IMS (DL/I) + MQ + JCL**.
It implements the standard credit-card business domain (accounts, cards,
customers, transactions, bill pay, statements, users, authorization) as CICS
pseudo-conversational BMS transactions. Every function is a screen; all
non-screen processing (posting, maintenance, inquiry-browse, MQ authorization,
IMS pending-auth) is a **sub-program the screen calls via `EXEC CICS LINK`** —
there is no standalone batch tier. See `docs/enrich_en.md` for the full,
enrichment-style overview.

> **Originality.** This is original work. It reproduces only the *ideas* of a
> credit-card system (not copyrightable) — the data model, program structure,
> BMS screens, identifiers and comments are all newly authored. It was written
> from scratch and does **not** copy the AWS CardDemo source (which is Apache-2.0);
> no third-party source was copied, transformed or obfuscated.

---

## 1. Layout (mainframe-style)
```
ORION-CCMS/
├─ cbl/    COBOL programs   (OC* online CICS, OD* online CICS+DB2, OU* sub-programs)
├─ cpy/    copybooks        (R* records, KCOMM commarea, K* linkage, W* common, M* BMS DSECTs)
├─ bms/    BMS map source   (M* mapsets)
├─ jcl/    JCL jobs         (compile/link, DEFINE VSAM, IMS DBDGEN/PSBGEN/ACBGEN, MQ DEFINE)
├─ proc/   cataloged procedures
├─ csd/    CICS resource definitions (DFHCSDUP: ORION.csd, ORION2.csd, ORION3.csd)
├─ ddl/    DB2 schema (ORION.ddl)
├─ dbd/    IMS DBD source (OPAUDB — pending-authorization DB)
├─ psb/    IMS PSB source (OPAUPSB)
├─ data/   sample flat-file data for the load jobs
├─ docs/   SPEC.md (data model), ENTRY_AND_FUNCTIONS.md, enrich_en.md
└─ tools/  generators (gen_copybooks/gen_bms/gen_entrydoc/gen_enrich.py) + checkers (check_ccms.py, audit2.py)
```

## 2. Naming
* Programs — `OC` online (CICS), `OD` DB2 batch (EXEC SQL), `OB` batch, `OU` subroutine.
* Transactions — `OR**` (ORSN sign-on, ORMN menu, ORAV acct view, …).
* BMS — mapset `M<screen>`, map `M<screen>A`, DSECT copybook = mapset.
* Copybooks — `R<entity>` record, `KCOMM` commarea, `W*` common, `K*` sub linkage.
Full field-level model and conventions: **`docs/SPEC.md`**.

## 3. Architecture
* **On-line (CICS)** pseudo-conversational: sign-on `OCSGNON` (ORSN) → menu
  `OCMENU`/admin `OCADMEN` → each function `XCTL`s in, carrying the shared
  **COMMAREA** (`KCOMM`); PF3 returns. All terminal I/O via BMS
  (`SEND/RECEIVE MAP`), all file I/O via `EXEC CICS READ/WRITE/REWRITE/DELETE`
  with `RESP`/`DFHRESP`.
* **Batch** classic VSAM: `SELECT/FD`, `OPEN/READ/WRITE`, control totals, driven
  by JCL.
* **Data**: 12 VSAM KSDS (account, card, customer, xref, transaction, tran type,
  tran category, disclosure group, user security, bill, statement, control).

## 4. Build & run (z/OS)
1. **Define files**: run `jcl/DEFVSAM.jcl` (IDCAMS DEFINE CLUSTER × 12) then the
   `LOAD*` jobs (IDCAMS REPRO from `data/`).
2. **Compile/link**: `jcl/COMPILE.jcl` — CICS translate + COBOL compile + link for
   online programs; plain compile+link for batch. BMS maps assembled from `bms/`.
3. **Install CICS resources**: `csd/ORION.csd` via DFHCSDUP, then
   `CEDA INSTALL GROUP(ORIONG)`.
4. **Run on-line**: clear a CICS screen and enter transaction **`ORSN`** →
   sign on → main menu.
5. **Run batch**: submit the `RUN*` jobs in `jcl/`.

See **`docs/ENTRY_AND_FUNCTIONS.md`** for the entry app, full menu tree and every
function.

## 5. Verification status (important — honest)
* This host has **no IBM Enterprise COBOL / CICS translator / BMS assembler**, so
  the code was **not compile-verified** here (unlike a target that has the IBM
  toolchain). It is written to IBM CICS/BMS dialect and passes:
  * `tools/check_ccms.py` — column ≤72, `COPY` resolution, `PROGRAM-ID`,
    **EXEC CICS / END-EXEC balance**, tabs, LOC.
  * parsing by the mainframe-analysis pipeline (`extract_data.jar`, dialect `ibm`)
    which produces the AST + metadata cleanly.
* On a z/OS or Micro Focus Enterprise Server environment, compile with the CICS
  translator (`XOPTS`), the BMS assembler, and IBM Enterprise COBOL.

## 6. Copybook / BMS generation
`cpy/R*.cpy` (record layouts) come from `tools/gen_copybooks.py`; `bms/*.bms` and
their `cpy/M*.cpy` DSECTs come from `tools/gen_bms.py` (one spec → both the BMS
source and the matching COBOL DSECT, guaranteeing they agree). Regenerate:
```
python tools/gen_copybooks.py && python tools/gen_bms.py
```
