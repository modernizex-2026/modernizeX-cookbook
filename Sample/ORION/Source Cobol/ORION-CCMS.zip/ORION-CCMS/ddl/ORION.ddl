-- ================================================
-- ORION-CCMS : DB2 z/OS table equivalents of the
-- 12 VSAM KSDS files (DB2 variant of the data model).
-- Money = DECIMAL(p,2); ids DECIMAL(n,0); dates CHAR(10)
-- kept as character to mirror the VSAM YYYY-MM-DD fields.
-- ================================================

CREATE DATABASE ORIONDB;

CREATE TABLESPACE ORIONTS IN ORIONDB;

-- ---- ACCTFILE / account master ----
CREATE TABLE ORION.ACCT (
    AC_ID              DECIMAL(11,0)  NOT NULL,
    AC_ACTIVE_STATUS   CHAR(1)        NOT NULL,
    AC_CURR_BAL        DECIMAL(12,2)  NOT NULL,
    AC_CREDIT_LIMIT    DECIMAL(12,2)  NOT NULL,
    AC_CASH_LIMIT      DECIMAL(12,2)  NOT NULL,
    AC_OPEN_DATE       CHAR(10)       NOT NULL,
    AC_EXPIRY_DATE     CHAR(10)       NOT NULL,
    AC_REISSUE_DATE    CHAR(10)       NOT NULL,
    AC_CYC_CREDIT      DECIMAL(12,2)  NOT NULL,
    AC_CYC_DEBIT       DECIMAL(12,2)  NOT NULL,
    AC_ADDR_ZIP        CHAR(10)       NOT NULL,
    AC_GROUP_ID        CHAR(10)       NOT NULL,
    PRIMARY KEY (AC_ID)
)
    IN ORIONDB.ORIONTS;

-- ---- CARDFILE / card master ----
CREATE TABLE ORION.CARD (
    CD_NUM             CHAR(16)       NOT NULL,
    CD_ACCT_ID         DECIMAL(11,0)  NOT NULL,
    CD_CVV             CHAR(3)        NOT NULL,
    CD_EMBOSSED_NAME   CHAR(50)       NOT NULL,
    CD_EXPIRY_DATE     CHAR(10)       NOT NULL,
    CD_ACTIVE_STATUS   CHAR(1)        NOT NULL,
    PRIMARY KEY (CD_NUM)
)
    IN ORIONDB.ORIONTS;
CREATE INDEX ORION.CARD_ACCT_IX
    ON ORION.CARD (CD_ACCT_ID);

-- ---- CUSTFILE / customer master ----
CREATE TABLE ORION.CUST (
    CU_ID              DECIMAL(9,0)   NOT NULL,
    CU_FIRST_NAME      CHAR(25)       NOT NULL,
    CU_MIDDLE_NAME     CHAR(25)       NOT NULL,
    CU_LAST_NAME       CHAR(25)       NOT NULL,
    CU_ADDR_LINE_1     CHAR(50)       NOT NULL,
    CU_ADDR_LINE_2     CHAR(50)       NOT NULL,
    CU_ADDR_CITY       CHAR(50)       NOT NULL,
    CU_ADDR_STATE      CHAR(2)        NOT NULL,
    CU_ADDR_COUNTRY    CHAR(3)        NOT NULL,
    CU_ADDR_ZIP        CHAR(10)       NOT NULL,
    CU_PHONE_1         CHAR(15)       NOT NULL,
    CU_PHONE_2         CHAR(15)       NOT NULL,
    CU_SSN             DECIMAL(9,0)   NOT NULL,
    CU_GOVT_ID         CHAR(20)       NOT NULL,
    CU_DOB             CHAR(10)       NOT NULL,
    CU_FICO_SCORE      DECIMAL(3,0)   NOT NULL,
    PRIMARY KEY (CU_ID)
)
    IN ORIONDB.ORIONTS;

-- ---- XREFFILE / card cross reference ----
CREATE TABLE ORION.XREF (
    XR_CARD_NUM        CHAR(16)       NOT NULL,
    XR_ACCT_ID         DECIMAL(11,0)  NOT NULL,
    XR_CUST_ID         DECIMAL(9,0)   NOT NULL,
    PRIMARY KEY (XR_CARD_NUM)
)
    IN ORIONDB.ORIONTS;
CREATE INDEX ORION.XREF_ACCT_IX
    ON ORION.XREF (XR_ACCT_ID);
CREATE INDEX ORION.XREF_CUST_IX
    ON ORION.XREF (XR_CUST_ID);

-- ---- TRANFILE / transaction ----
CREATE TABLE ORION.TRAN (
    TR_ID              CHAR(16)       NOT NULL,
    TR_TYPE_CD         CHAR(2)        NOT NULL,
    TR_CAT_CD          DECIMAL(4,0)   NOT NULL,
    TR_SOURCE          CHAR(10)       NOT NULL,
    TR_DESC            CHAR(100)      NOT NULL,
    TR_AMT             DECIMAL(11,2)  NOT NULL,
    TR_MERCHANT_ID     DECIMAL(9,0)   NOT NULL,
    TR_MERCHANT_NAME   CHAR(50)       NOT NULL,
    TR_MERCHANT_CITY   CHAR(50)       NOT NULL,
    TR_MERCHANT_ZIP    CHAR(10)       NOT NULL,
    TR_CARD_NUM        CHAR(16)       NOT NULL,
    TR_ORIG_TS         CHAR(26)       NOT NULL,
    TR_PROC_TS         CHAR(26)       NOT NULL,
    PRIMARY KEY (TR_ID)
)
    IN ORIONDB.ORIONTS;
CREATE INDEX ORION.TRAN_CARD_IX
    ON ORION.TRAN (TR_CARD_NUM);

-- ---- TTYPFILE / transaction type ----
CREATE TABLE ORION.TTYP (
    TT_CD              CHAR(2)        NOT NULL,
    TT_DESC            CHAR(50)       NOT NULL,
    PRIMARY KEY (TT_CD)
)
    IN ORIONDB.ORIONTS;

-- ---- TCATFILE / transaction category ----
CREATE TABLE ORION.TCAT (
    TC_TYPE_CD         CHAR(2)        NOT NULL,
    TC_CD              DECIMAL(4,0)   NOT NULL,
    TC_DESC            CHAR(50)       NOT NULL,
    PRIMARY KEY (TC_TYPE_CD, TC_CD)
)
    IN ORIONDB.ORIONTS;

-- ---- DGRPFILE / disclosure group ----
CREATE TABLE ORION.DGRP (
    DG_ACCT_GROUP      CHAR(10)       NOT NULL,
    DG_TYPE_CD         CHAR(2)        NOT NULL,
    DG_CAT_CD          DECIMAL(4,0)   NOT NULL,
    DG_INT_RATE        DECIMAL(6,2)   NOT NULL,
    PRIMARY KEY (DG_ACCT_GROUP, DG_TYPE_CD, DG_CAT_CD)
)
    IN ORIONDB.ORIONTS;

-- ---- USRSEC / user security ----
CREATE TABLE ORION.USRSEC (
    US_ID              CHAR(8)        NOT NULL,
    US_FIRST_NAME      CHAR(20)       NOT NULL,
    US_LAST_NAME       CHAR(20)       NOT NULL,
    US_PASSWORD        CHAR(8)        NOT NULL,
    US_TYPE            CHAR(1)        NOT NULL,
    PRIMARY KEY (US_ID)
)
    IN ORIONDB.ORIONTS;

-- ---- BILLFILE / bill payment ----
CREATE TABLE ORION.BILL (
    BL_ID              DECIMAL(11,0)  NOT NULL,
    BL_ACCT_ID         DECIMAL(11,0)  NOT NULL,
    BL_AMOUNT          DECIMAL(12,2)  NOT NULL,
    BL_PAY_DATE        CHAR(10)       NOT NULL,
    BL_CONFIRM_NUM     CHAR(16)       NOT NULL,
    BL_STATUS          CHAR(1)        NOT NULL,
    PRIMARY KEY (BL_ID)
)
    IN ORIONDB.ORIONTS;
CREATE INDEX ORION.BILL_ACCT_IX
    ON ORION.BILL (BL_ACCT_ID);

-- ---- STMTFILE / statement ----
CREATE TABLE ORION.STMT (
    ST_ACCT_ID         DECIMAL(11,0)  NOT NULL,
    ST_CYCLE           DECIMAL(6,0)   NOT NULL,
    ST_OPEN_BAL        DECIMAL(12,2)  NOT NULL,
    ST_CLOSE_BAL       DECIMAL(12,2)  NOT NULL,
    ST_TOTAL_CREDIT    DECIMAL(12,2)  NOT NULL,
    ST_TOTAL_DEBIT     DECIMAL(12,2)  NOT NULL,
    ST_MIN_DUE         DECIMAL(12,2)  NOT NULL,
    ST_DUE_DATE        CHAR(10)       NOT NULL,
    PRIMARY KEY (ST_ACCT_ID, ST_CYCLE)
)
    IN ORIONDB.ORIONTS;

-- ---- CTRLFILE / control counters ----
CREATE TABLE ORION.CTRL (
    CT_KEY             CHAR(8)        NOT NULL,
    CT_LAST_VALUE      DECIMAL(11,0)  NOT NULL,
    CT_DESC            CHAR(30)       NOT NULL,
    PRIMARY KEY (CT_KEY)
)
    IN ORIONDB.ORIONTS;

