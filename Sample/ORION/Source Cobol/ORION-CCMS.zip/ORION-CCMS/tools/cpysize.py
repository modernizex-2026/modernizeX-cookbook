# -*- coding: utf-8 -*-
# Rough COBOL copybook byte-size estimator, used to verify that a K* LINK area
# overlaid on CA-WORK-AREA (SET ADDRESS OF K* TO ADDRESS OF CA-WORK-AREA) does
# not exceed CA-WORK-AREA's size (else the overlay overruns the COMMAREA).
import os, re, glob, sys
ROOT = os.path.join(os.path.dirname(__file__), "..")

def area(line):
    b = line.rstrip("\r\n")
    if len(b) >= 7 and b[6] in "*/":
        return None
    return b[6:72] if len(b) > 6 else ""

def pic_size(pic, usage):
    # expand (n) repeats
    s = pic.upper()
    out = []
    i = 0
    while i < len(s):
        c = s[i]
        if c == "(":
            j = s.find(")", i)
            n = int(re.sub(r"\D", "", s[i+1:j]) or "1")
            if out:
                out[-1] = (out[-1][0], n)
            i = j + 1
        else:
            out.append((c, 1))
            i += 1
    digits = 0      # count of 9 (incl after V) for numeric usages
    disp = 0        # display byte count
    for ch, n in out:
        if ch in "9":
            digits += n; disp += n
        elif ch in "XAZ*+-,./B0$ECRD S".replace(" ", ""):
            if ch == "S":       # sign overpunch, no byte
                continue
            if ch in "VP":
                continue
            disp += n
        elif ch in "VP":
            continue
        else:
            disp += n
    u = usage.upper()
    if "COMP-3" in u or "PACKED" in u:
        return (digits + 1 + 1) // 2 if digits else 1
    if "COMP-1" in u:
        return 4
    if "COMP-2" in u:
        return 8
    if "COMP-5" in u or "COMP-4" in u or "COMP" in u or "BINARY" in u:
        return 2 if digits <= 4 else (4 if digits <= 9 else 8)
    return disp

DEF = re.compile(r"^\s*(\d\d)\s+([A-Z0-9][A-Z0-9-]*)(.*)$")

def area_size(path, target=None):
    """size of a specific 01/05 name, or the first 01."""
    lines = [area(l) for l in open(path, encoding="utf-8", errors="replace")]
    items = []
    for c in lines:
        if c is None:
            continue
        cu = c.upper()
        m = DEF.match(cu)
        if not m:
            continue
        lvl = int(m.group(1)); name = m.group(2); rest = m.group(3)
        if name == "FILLER":
            name = "FILLER"
        occ = 1
        mo = re.search(r"OCCURS\s+(\d+)", rest)
        if mo: occ = int(mo.group(1))
        redef = bool(re.search(r"\bREDEFINES\b", rest))
        pic = ""
        mp = re.search(r"\bPIC(?:TURE)?\s+(?:IS\s+)?(\S+)", rest)
        if mp: pic = mp.group(1).rstrip(".")
        usage = rest
        items.append((lvl, name, occ, redef, pic, usage))
    # stack rollup
    def rollup(start, want=None):
        # compute size of item at index start (its subtree), return (size, next_index)
        lvl, name, occ, redef, pic, usage = items[start]
        i = start + 1
        if pic:
            sz = pic_size(pic, usage)
        else:
            sz = 0
            while i < len(items) and items[i][0] > lvl:
                if items[i][0] <= lvl:
                    break
                # only direct children (next level down); rollup handles nesting
                csz, i = rollup(i)
                sz += csz
        total = 0 if redef else sz * occ
        return (total if not redef else sz * occ), i
    # find target
    idx = 0
    total = 0
    while idx < len(items):
        lvl, name, occ, redef, pic, usage = items[idx]
        if target is None:
            if lvl == 1:
                sz, nxt = rollup(idx)
                return sz
            idx += 1
        else:
            if name == target:
                sz, nxt = rollup(idx)
                return sz
            idx += 1
    return None

# CA-WORK-AREA size from KCOMM
kcomm = os.path.join(ROOT, "cpy", "KCOMM.cpy")
cwa = area_size(kcomm, "CA-WORK-AREA")
print("CA-WORK-AREA size (KCOMM):", cwa, "bytes")
print()
print("Binding-aware overlay check (only subs that overlay CA-WORK-AREA can")
print("overrun the COMMAREA; subs that pass K* directly as the LINK COMMAREA")
print("are limited by the 32K CICS commarea, not CA-WORK-AREA):")
print()
OVL = re.compile(r"SET\s+ADDRESS\s+OF\s+[A-Z0-9-]+\s+TO\s+ADDRESS\s+OF\s+CA-WORK-AREA")
COPYK = re.compile(r"\bCOPY\s+(K[A-Z0-9]+)")
bad = 0
for f in sorted(glob.glob(os.path.join(ROOT, "cbl", "OU*.cbl"))):
    src = "".join(l for l in open(f, encoding="utf-8", errors="replace"))
    if not OVL.search(src):
        continue                      # USING-commarea sub: not overlaid, skip
    nm = os.path.basename(f)[:-4]
    ks = [k for k in COPYK.findall(src) if k != "KCOMM"]
    for k in ks:
        p = os.path.join(ROOT, "cpy", k + ".cpy")
        if not os.path.exists(p):
            continue
        sz = area_size(p)
        flag = ""
        if cwa and sz and sz > cwa:
            flag = "  <<< OVERRUN (%d > %d)" % (sz, cwa); bad += 1
        print("  %-9s overlays %-8s = %5s bytes (<= %s)%s"
              % (nm, k, sz, cwa, flag))
print()
print("REAL OVERLAY OVERRUNS:", bad)
sys.exit(1 if bad else 0)
