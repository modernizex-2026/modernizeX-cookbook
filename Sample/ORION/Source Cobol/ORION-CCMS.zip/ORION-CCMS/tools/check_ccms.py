#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ORION-CCMS static checker (no IBM/CICS compiler available on this host).
Checks cbl/*.cbl and cpy/*.cpy for:
  * lines longer than 72 columns (IBM fixed format)
  * tab characters
  * COPY <name> that has no cpy/<name>.cpy  (DFH* are IBM-supplied -> exempt)
  * PROGRAM-ID present in each program
  * EXEC CICS / END-EXEC balance per program
and prints a LOC summary.
"""
import os, re, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CBL, CPY, BMS = (os.path.join(ROOT, d) for d in ("cbl", "cpy", "bms"))

copy_re = re.compile(r"^\s*COPY\s+([A-Z0-9][A-Z0-9-]*)", re.I)
pid_re  = re.compile(r"PROGRAM-ID", re.I)

def avail():
    s = set()
    if os.path.isdir(CPY):
        for f in os.listdir(CPY):
            if f.lower().endswith(".cpy"):
                s.add(os.path.splitext(f)[0].upper())
    return s

def is_code(l):
    return not (len(l) > 6 and l[6] in ("*", "/"))

def main():
    cpys = avail()
    longl, tabs, misscopy, nopid, cics_imb = [], [], [], [], []
    total = {"cbl": 0, "cpy": 0, "bms": 0}
    for d, key in ((CBL, "cbl"), (CPY, "cpy"), (BMS, "bms")):
        if not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            ext = os.path.splitext(fn)[1].lower()
            if ext not in (".cbl", ".cpy", ".bms"):
                continue
            path = os.path.join(d, fn)
            has_pid = False
            n_cics = n_endx = 0
            for i, line in enumerate(open(path, errors="replace"), 1):
                line = line.rstrip("\n").rstrip("\r")
                total[key] += 1
                if len(line) > 72:
                    longl.append("%s/%s:%d (%d)" % (key, fn, i, len(line)))
                if "\t" in line:
                    tabs.append("%s/%s:%d" % (key, fn, i))
                if key == "bml":
                    continue
                if pid_re.search(line):
                    has_pid = True
                if is_code(line):
                    if "EXEC CICS" in line or "EXEC SQL" in line:
                        n_cics += 1
                    if "END-EXEC" in line:
                        n_endx += 1
                    m = copy_re.match(line)
                    if m:
                        nm = m.group(1).upper()
                        if nm.startswith("DFH"):
                            pass
                        elif nm not in cpys:
                            misscopy.append("%s/%s:%d COPY %s" % (key, fn, i, nm))
            if key == "cbl":
                if not has_pid:
                    nopid.append(fn)
                if n_cics != n_endx:
                    cics_imb.append("%s: EXEC CICS=%d END-EXEC=%d"
                                    % (fn, n_cics, n_endx))
    def sec(t, items):
        print("\n== %s == (%d)" % (t, len(items)))
        for x in items[:40]:
            print("  " + x)
        if len(items) > 40:
            print("  ... +%d more" % (len(items) - 40))
    print("ORION-CCMS static check   copybooks:", len(cpys))
    sec("LINES > 72", longl)
    sec("TABS", tabs)
    sec("UNRESOLVED COPY", misscopy)
    sec("MISSING PROGRAM-ID", nopid)
    sec("EXEC CICS / END-EXEC IMBALANCE", cics_imb)
    print("\n== LOC ==")
    for k in ("cbl", "cpy", "bms"):
        print("  %-4s %6d" % (k, total[k]))
    print("  %-4s %6d" % ("ALL", sum(total.values())))
    prob = len(longl)+len(tabs)+len(misscopy)+len(nopid)+len(cics_imb)
    print("\nPROBLEMS:", prob)
    sys.exit(1 if prob else 0)

if __name__ == "__main__":
    main()
