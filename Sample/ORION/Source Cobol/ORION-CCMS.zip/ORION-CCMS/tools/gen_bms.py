#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ORION-CCMS BMS generator.
From one compact map spec it emits BOTH:
  bms/<mapset>.bms   - BMS macro source (DFHMSD/DFHMDI/DFHMDF)
  cpy/<mapset>.cpy   - the COBOL DSECT the programs COPY (mapI / mapO)
A standard header (Tran/Title/Date/Pgm/Time/Errmsg/PF-keys) is injected into
every map.  Field names are <=7 chars so name+suffix stays a valid COBOL word.
"""
import os
BMS = os.path.join(os.path.dirname(__file__), "..", "bms")
CPY = os.path.join(os.path.dirname(__file__), "..", "cpy")

# label(text) = protected literal ; inp/out = named fields
def lbl(r, c, text, color="BLUE"):      return ("L", r, c, len(text), text, color, None)
def inp(r, c, name, ln, color="GREEN"): return ("I", r, c, ln, "", color, name)
def out(r, c, name, ln, color="TURQUOISE"): return ("O", r, c, ln, "", color, name)

MAPS = []
def m(mapset, title, body): MAPS.append((mapset, title, body))

# ---- standard header (added to every map) ------------------------------
def header():
    return [
        lbl(1, 1, "Tran:"), out(1, 7, "TRNNAME", 4, "BLUE"),
        out(1, 21, "TITLE", 40, "YELLOW"),
        lbl(1, 65, "Date:"), out(1, 71, "CURDATE", 10, "BLUE"),
        lbl(2, 1, "Pgm :"), out(2, 7, "PGMNAME", 8, "BLUE"),
        lbl(2, 65, "Time:"), out(2, 71, "CURTIME", 8, "BLUE"),
    ]
def footer():
    return [out(23, 1, "ERRMSG", 78, "RED"),
            lbl(24, 1, "ENTER=Process  PF3=Back  PF4=Clear", "TURQUOISE")]

# ---- screens -----------------------------------------------------------
m("MSGNON", "Sign On", [
    lbl(10, 20, "User ID :"),  inp(10, 31, "USERID", 8),
    lbl(12, 20, "Password:"),  inp(12, 31, "PASSWD", 8),
    lbl(14, 20, "Type your credentials and press ENTER.", "TURQUOISE")])

m("MMENU", "Main Menu", [
    lbl(6, 10, "1. Account View"),   lbl(7, 10, "2. Account Update"),
    lbl(8, 10, "3. Card List"),      lbl(9, 10, "4. Card View"),
    lbl(10, 10, "5. Card Update"),   lbl(11, 10, "6. Customer View"),
    lbl(12, 10, "7. Transaction List"), lbl(13, 10, "8. Transaction Add"),
    lbl(14, 10, "9. Bill Payment"),  lbl(15, 10, "10. Reports"),
    lbl(17, 10, "Option:"), inp(17, 18, "OPTION", 2)])

m("MADMEN", "Admin Menu", [
    lbl(6, 10, "1. User List"),  lbl(7, 10, "2. User Add"),
    lbl(8, 10, "3. User Update"), lbl(9, 10, "4. User Delete"),
    lbl(11, 10, "Option:"), inp(11, 18, "OPTION", 2)])

m("MACCTV", "Account View", [
    lbl(6, 5, "Account ID:"), inp(6, 17, "ACCTID", 11),
    lbl(8, 5, "Status    :"), out(8, 17, "ACSTAT", 1),
    lbl(9, 5, "Curr Bal  :"), out(9, 17, "ACBAL", 15),
    lbl(10, 5, "Credit Lim:"), out(10, 17, "ACCRLIM", 15),
    lbl(11, 5, "Cash Lim  :"), out(11, 17, "ACCSLIM", 15),
    lbl(12, 5, "Open Date :"), out(12, 17, "ACOPEN", 10),
    lbl(13, 5, "Expiry    :"), out(13, 17, "ACEXP", 10),
    lbl(14, 5, "Group ID  :"), out(14, 17, "ACGRP", 10)])

m("MACCTU", "Account Update", [
    lbl(6, 5, "Account ID:"), inp(6, 17, "ACCTID", 11),
    lbl(8, 5, "Status    :"), inp(8, 17, "ACSTAT", 1),
    lbl(9, 5, "Credit Lim:"), inp(9, 17, "ACCRLIM", 13),
    lbl(10, 5, "Cash Lim  :"), inp(10, 17, "ACCSLIM", 13),
    lbl(11, 5, "Expiry    :"), inp(11, 17, "ACEXP", 10),
    lbl(12, 5, "Group ID  :"), inp(12, 17, "ACGRP", 10)])

m("MCARDL", "Card List", [
    lbl(5, 5, "Acct ID:"), inp(5, 14, "ACCTID", 11),
    lbl(7, 3, "Card Number"), lbl(7, 25, "Status"),
    out(8, 3, "CARD1", 16), out(8, 25, "STAT1", 1),
    out(9, 3, "CARD2", 16), out(9, 25, "STAT2", 1),
    out(10, 3, "CARD3", 16), out(10, 25, "STAT3", 1),
    out(11, 3, "CARD4", 16), out(11, 25, "STAT4", 1),
    out(12, 3, "CARD5", 16), out(12, 25, "STAT5", 1)])

m("MCARDV", "Card View", [
    lbl(6, 5, "Card Num :"), inp(6, 17, "CARDNUM", 16),
    lbl(8, 5, "Acct ID  :"), out(8, 17, "CDACCT", 11),
    lbl(9, 5, "Name     :"), out(9, 17, "CDNAME", 50),
    lbl(10, 5, "Expiry   :"), out(10, 17, "CDEXP", 10),
    lbl(11, 5, "Status   :"), out(11, 17, "CDSTAT", 1)])

m("MCARDU", "Card Update", [
    lbl(6, 5, "Card Num :"), inp(6, 17, "CARDNUM", 16),
    lbl(8, 5, "Name     :"), inp(8, 17, "CDNAME", 50),
    lbl(9, 5, "Expiry   :"), inp(9, 17, "CDEXP", 10),
    lbl(10, 5, "Status   :"), inp(10, 17, "CDSTAT", 1)])

m("MCUSTV", "Customer View", [
    lbl(6, 5, "Cust ID :"), inp(6, 16, "CUSTID", 9),
    lbl(8, 5, "Name    :"), out(8, 16, "CUNAME", 50),
    lbl(9, 5, "Address :"), out(9, 16, "CUADDR", 50),
    lbl(10, 5, "City    :"), out(10, 16, "CUCITY", 50),
    lbl(11, 5, "Phone   :"), out(11, 16, "CUPHONE", 15),
    lbl(12, 5, "FICO    :"), out(12, 16, "CUFICO", 3)])

m("MCUSTU", "Customer Update", [
    lbl(6, 5, "Cust ID :"), inp(6, 16, "CUSTID", 9),
    lbl(8, 5, "First   :"), inp(8, 16, "CUFNAM", 25),
    lbl(9, 5, "Last    :"), inp(9, 16, "CULNAM", 25),
    lbl(10, 5, "Address :"), inp(10, 16, "CUADDR", 50),
    lbl(11, 5, "City    :"), inp(11, 16, "CUCITY", 50),
    lbl(12, 5, "Phone   :"), inp(12, 16, "CUPHONE", 15)])

m("MTRANL", "Transaction List", [
    lbl(5, 5, "Card Num:"), inp(5, 15, "CARDNUM", 16),
    lbl(7, 3, "Tran ID"), lbl(7, 22, "Amount"), lbl(7, 40, "Type"),
    out(8, 3, "TRN1", 16), out(8, 22, "AMT1", 15), out(8, 40, "TYP1", 2),
    out(9, 3, "TRN2", 16), out(9, 22, "AMT2", 15), out(9, 40, "TYP2", 2),
    out(10, 3, "TRN3", 16), out(10, 22, "AMT3", 15), out(10, 40, "TYP3", 2),
    out(11, 3, "TRN4", 16), out(11, 22, "AMT4", 15), out(11, 40, "TYP4", 2),
    out(12, 3, "TRN5", 16), out(12, 22, "AMT5", 15), out(12, 40, "TYP5", 2)])

m("MTRANV", "Transaction View", [
    lbl(6, 5, "Tran ID :"), inp(6, 16, "TRANID", 16),
    lbl(8, 5, "Card Num:"), out(8, 16, "TRCARD", 16),
    lbl(9, 5, "Type    :"), out(9, 16, "TRTYPE", 2),
    lbl(10, 5, "Amount  :"), out(10, 16, "TRAMT", 15),
    lbl(11, 5, "Merchant:"), out(11, 16, "TRMERCH", 50),
    lbl(12, 5, "Desc    :"), out(12, 16, "TRDESC", 50)])

m("MTRANA", "Transaction Add", [
    lbl(6, 5, "Card Num:"), inp(6, 16, "CARDNUM", 16),
    lbl(7, 5, "Type    :"), inp(7, 16, "TRTYPE", 2),
    lbl(8, 5, "Category:"), inp(8, 16, "TRCAT", 4),
    lbl(9, 5, "Amount  :"), inp(9, 16, "TRAMT", 12),
    lbl(10, 5, "Merchant:"), inp(10, 16, "TRMERCH", 50),
    lbl(11, 5, "Desc    :"), inp(11, 16, "TRDESC", 50)])

m("MBILLP", "Bill Payment", [
    lbl(6, 5, "Account ID :"), inp(6, 18, "ACCTID", 11),
    lbl(8, 5, "Curr Bal   :"), out(8, 18, "BLBAL", 15),
    lbl(10, 5, "Pay Amount :"), inp(10, 18, "BLAMT", 12),
    lbl(12, 5, "Confirm(Y):"), inp(12, 18, "BLCONF", 1)])

m("MREPT", "Reports", [
    lbl(6, 5, "Report Type:"), inp(6, 18, "RPTYPE", 2),
    lbl(7, 5, "From Date  :"), inp(7, 18, "RPFROM", 10),
    lbl(8, 5, "To Date    :"), inp(8, 18, "RPTO", 10),
    lbl(10, 5, "1=Trans 2=Accts 3=Cards", "TURQUOISE")])

m("MUSRL", "User List", [
    lbl(7, 3, "User ID"), lbl(7, 15, "Name"), lbl(7, 45, "Type"),
    out(8, 3, "USR1", 8), out(8, 15, "UNM1", 25), out(8, 45, "UTY1", 1),
    out(9, 3, "USR2", 8), out(9, 15, "UNM2", 25), out(9, 45, "UTY2", 1),
    out(10, 3, "USR3", 8), out(10, 15, "UNM3", 25), out(10, 45, "UTY3", 1),
    out(11, 3, "USR4", 8), out(11, 15, "UNM4", 25), out(11, 45, "UTY4", 1)])

m("MUSRA", "User Add", [
    lbl(6, 5, "User ID :"), inp(6, 16, "USERID", 8),
    lbl(7, 5, "First   :"), inp(7, 16, "USFNAM", 20),
    lbl(8, 5, "Last    :"), inp(8, 16, "USLNAM", 20),
    lbl(9, 5, "Password:"), inp(9, 16, "USPWD", 8),
    lbl(10, 5, "Type A/U:"), inp(10, 16, "USTYPE", 1)])

m("MUSRU", "User Update", [
    lbl(6, 5, "User ID :"), inp(6, 16, "USERID", 8),
    lbl(7, 5, "First   :"), inp(7, 16, "USFNAM", 20),
    lbl(8, 5, "Last    :"), inp(8, 16, "USLNAM", 20),
    lbl(9, 5, "Password:"), inp(9, 16, "USPWD", 8),
    lbl(10, 5, "Type A/U:"), inp(10, 16, "USTYPE", 1)])

m("MUSRD", "User Delete", [
    lbl(6, 5, "User ID :"), inp(6, 16, "USERID", 8),
    lbl(8, 5, "Name    :"), out(8, 16, "USNAME", 40),
    lbl(10, 5, "Confirm delete (Y):"), inp(10, 30, "USCONF", 1)])

# ---- top-up screens (wave 2) -------------------------------------------
m("MACCTL", "Account List", [
    lbl(5, 5, "From Acct:"), inp(5, 16, "FRACCT", 11),
    lbl(7, 3, "Account ID"), lbl(7, 18, "Status"), lbl(7, 28, "Balance"),
    out(8, 3, "ACL1", 11), out(8, 18, "ACS1", 1), out(8, 28, "ACB1", 15),
    out(9, 3, "ACL2", 11), out(9, 18, "ACS2", 1), out(9, 28, "ACB2", 15),
    out(10, 3, "ACL3", 11), out(10, 18, "ACS3", 1), out(10, 28, "ACB3", 15),
    out(11, 3, "ACL4", 11), out(11, 18, "ACS4", 1), out(11, 28, "ACB4", 15),
    out(12, 3, "ACL5", 11), out(12, 18, "ACS5", 1), out(12, 28, "ACB5", 15)])

m("MACCTA", "Account Open", [
    lbl(6, 5, "Account ID:"), inp(6, 18, "ACCTID", 11),
    lbl(7, 5, "Cust ID   :"), inp(7, 18, "CUSTID", 9),
    lbl(8, 5, "Credit Lim:"), inp(8, 18, "ACCRLIM", 13),
    lbl(9, 5, "Cash Lim  :"), inp(9, 18, "ACCSLIM", 13),
    lbl(10, 5, "Open Date :"), inp(10, 18, "ACOPEN", 10),
    lbl(11, 5, "Group ID  :"), inp(11, 18, "ACGRP", 10)])

m("MCUSTL", "Customer List", [
    lbl(5, 5, "From Cust:"), inp(5, 16, "FRCUST", 9),
    lbl(7, 3, "Cust ID"), lbl(7, 14, "Name"), lbl(7, 45, "FICO"),
    out(8, 3, "CUL1", 9), out(8, 14, "CUN1", 30), out(8, 45, "CUF1", 3),
    out(9, 3, "CUL2", 9), out(9, 14, "CUN2", 30), out(9, 45, "CUF2", 3),
    out(10, 3, "CUL3", 9), out(10, 14, "CUN3", 30), out(10, 45, "CUF3", 3),
    out(11, 3, "CUL4", 9), out(11, 14, "CUN4", 30), out(11, 45, "CUF4", 3)])

m("MCUSTA", "Customer Add", [
    lbl(6, 5, "Cust ID :"), inp(6, 16, "CUSTID", 9),
    lbl(7, 5, "First   :"), inp(7, 16, "CUFNAM", 25),
    lbl(8, 5, "Last    :"), inp(8, 16, "CULNAM", 25),
    lbl(9, 5, "Address :"), inp(9, 16, "CUADDR", 50),
    lbl(10, 5, "City    :"), inp(10, 16, "CUCITY", 50),
    lbl(11, 5, "SSN     :"), inp(11, 16, "CUSSN", 9),
    lbl(12, 5, "FICO    :"), inp(12, 16, "CUFICO", 3)])

m("MCARDA", "Card Add", [
    lbl(6, 5, "Card Num :"), inp(6, 17, "CARDNUM", 16),
    lbl(7, 5, "Acct ID  :"), inp(7, 17, "CDACCT", 11),
    lbl(8, 5, "Name     :"), inp(8, 17, "CDNAME", 50),
    lbl(9, 5, "CVV      :"), inp(9, 17, "CDCVV", 3),
    lbl(10, 5, "Expiry   :"), inp(10, 17, "CDEXP", 10)])

m("MTTYP", "Tran Type Maint", [
    lbl(6, 5, "Type Code:"), inp(6, 17, "TTCD", 2),
    lbl(8, 5, "Desc     :"), inp(8, 17, "TTDESC", 50)])

m("MTCAT", "Tran Category Maint", [
    lbl(6, 5, "Type Code:"), inp(6, 17, "TCTYPE", 2),
    lbl(7, 5, "Cat Code :"), inp(7, 17, "TCCD", 4),
    lbl(9, 5, "Desc     :"), inp(9, 17, "TCDESC", 50)])

m("MDGRP", "Disclosure Group Maint", [
    lbl(6, 5, "Acct Group:"), inp(6, 18, "DGGRP", 10),
    lbl(7, 5, "Type Code :"), inp(7, 18, "DGTYPE", 2),
    lbl(8, 5, "Cat Code  :"), inp(8, 18, "DGCAT", 4),
    lbl(10, 5, "Int Rate :"), inp(10, 18, "DGRATE", 7)])

m("MSTMV", "Statement View", [
    lbl(6, 5, "Acct ID :"), inp(6, 16, "ACCTID", 11),
    lbl(7, 5, "Cycle   :"), inp(7, 16, "STCYC", 6),
    lbl(9, 5, "Open Bal:"), out(9, 16, "STOPEN", 15),
    lbl(10, 5, "Close   :"), out(10, 16, "STCLOSE", 15),
    lbl(11, 5, "Min Due :"), out(11, 16, "STMIN", 15),
    lbl(12, 5, "Due Date:"), out(12, 16, "STDUE", 10)])

m("MTSRCH", "Transaction Search", [
    lbl(5, 5, "Card Num:"), inp(5, 15, "CARDNUM", 16),
    lbl(6, 5, "From Amt:"), inp(6, 15, "FRAMT", 12),
    lbl(6, 40, "To Amt:"), inp(6, 48, "TOAMT", 12),
    out(8, 3, "SR1", 70), out(9, 3, "SR2", 70),
    out(10, 3, "SR3", 70), out(11, 3, "SR4", 70), out(12, 3, "SR5", 70)])

m("MPWDCH", "Password Change", [
    lbl(6, 5, "User ID :"), inp(6, 17, "USERID", 8),
    lbl(8, 5, "Old Pass:"), inp(8, 17, "OLDPWD", 8),
    lbl(9, 5, "New Pass:"), inp(9, 17, "NEWPWD", 8),
    lbl(10, 5, "Confirm :"), inp(10, 17, "CFMPWD", 8)])

# ------------------------------------------------------------------ emit
def bms_attr(kind):
    if kind == "L":  return "ASKIP,NORM"
    if kind == "I":  return "UNPROT,IC,FSET"
    return "ASKIP,NORM"          # output

def bline(s, cont):
    """One BMS source line: content in cols 1-71, 'X' continuation at col 72."""
    s = s[:71]
    return (s.ljust(71) + "X") if cont else s

def gen_bms(mapset, title, fields):
    L = []
    L.append(bline("%-8s DFHMSD TYPE=&&SYSPARM,MODE=INOUT,LANG=COBOL," % mapset, True))
    L.append(bline("               STORAGE=AUTO,TIOAPFX=YES,CTRL=(FREEKB,ALARM)", False))
    L.append(bline("%-8s DFHMDI SIZE=(24,80),LINE=1,COLUMN=1" % (mapset[:6] + "A"), False))
    for kind, r, c, ln, text, color, name in fields:
        nm = name if name else "        "
        L.append(bline("%-8s DFHMDF POS=(%02d,%02d),LENGTH=%d," % (nm, r, c, ln), True))
        cont = bool(text)
        L.append(bline("               ATTRB=(%s),COLOR=%s%s"
                       % (bms_attr(kind), color, "," if cont else ""), cont))
        if text:
            L.append(bline("               INITIAL='%s'" % text.replace("'", ""), False))
    L.append(bline("%-8s DFHMSD TYPE=FINAL" % " ", False))
    L.append(bline("         END", False))
    return "\n".join(L) + "\n"

def gen_dsect(mapset, fields):
    mp = mapset[:6] + "A"
    named = [f for f in fields if f[6]]
    I = ["      *----------------------------------------------------------------",
         "      *  ORION-CCMS BMS DSECT (generated) - mapset %s" % mapset,
         "      *----------------------------------------------------------------",
         "       01  %sI." % mp, "           02  FILLER PIC X(12)."]
    for kind, r, c, ln, text, color, name in named:
        I.append("           02  %sL PIC S9(04) COMP." % name)
        I.append("           02  %sF PIC X." % name)
        I.append("           02  FILLER REDEFINES %sF." % name)
        I.append("               03  %sA PIC X." % name)
        I.append("           02  %sI PIC X(%02d)." % (name, ln))
    I.append("       01  %sO REDEFINES %sI." % (mp, mp))
    I.append("           02  FILLER PIC X(12).")
    for kind, r, c, ln, text, color, name in named:
        I.append("           02  FILLER PIC X(03).")
        I.append("           02  %sO PIC X(%02d)." % (name, ln))
    return "\n".join(I) + "\n"

def main():
    os.makedirs(BMS, exist_ok=True); os.makedirs(CPY, exist_ok=True)
    for mapset, title, body in MAPS:
        fields = header() + body + footer()
        open(os.path.join(BMS, mapset + ".bms"), "w", newline="\r\n").write(
            gen_bms(mapset, title, fields))
        open(os.path.join(CPY, mapset + ".cpy"), "w", newline="\r\n").write(
            gen_dsect(mapset, fields))
    print("generated %d BMS mapsets (.bms) + %d DSECT copybooks (.cpy)"
          % (len(MAPS), len(MAPS)))

if __name__ == "__main__":
    main()
