# -*- coding: utf-8 -*-
# ORION-CCMS deep auditor (beyond check_ccms.py).
# Cross-file semantic checks with COPY expansion:
#   1) PERFORM/GO TO targets resolve to a defined paragraph
#   2) duplicate paragraph names
#   3) program has a terminator (GOBACK / EXIT PROGRAM / STOP RUN, or
#      EXEC CICS RETURN for OC online)
#   4) FILE STATUS variable named on a SELECT is defined in DATA DIVISION
#   5) referenced data-names resolve to a definition (WS/FD/LINKAGE + COPY)
#      -- literals, EXEC blocks, reserved/DFH/FUNCTION words excluded
import os, re, glob, sys

ROOT = os.path.join(os.path.dirname(__file__), "..")
CBL = os.path.join(ROOT, "cbl")
CPY = os.path.join(ROOT, "cpy")

RESERVED = set("""
ACCEPT ACCESS ADD ADDRESS ADVANCING AFTER ALL ALPHABETIC ALSO ALTER AND ANY ARE
AREA ASCENDING ASSIGN AT AUTHOR BEFORE BINARY BLANK BLOCK BOTTOM BY CALL CANCEL
CHARACTER CHARACTERS CLASS CLOSE COBOL CODE COLUMN COMMA COMMON COMP COMP-1
COMP-2 COMP-3 COMP-4 COMP-5 COMPUTATIONAL COMPUTE CONFIGURATION CONTAINS CONTENT
CONTINUE CONTROL CONTROLS CONVERTING COPY CORR CORRESPONDING COUNT CURRENCY DATA
DATE DAY DE DECIMAL-POINT DECLARATIVES DELETE DELIMITED DELIMITER DEPENDING
DESCENDING DISPLAY DIVIDE DIVISION DOWN DUPLICATES DYNAMIC EGCS ELSE END
END-ADD END-CALL END-COMPUTE END-DELETE END-DIVIDE END-EVALUATE END-IF
END-MULTIPLY END-OF-PAGE END-PERFORM END-READ END-RECEIVE END-RETURN END-REWRITE
END-SEARCH END-START END-STRING END-SUBTRACT END-UNSTRING END-WRITE END-EXEC
ENTER ENVIRONMENT EOP EQUAL ERROR EVALUATE EVERY EXCEPTION EXEC EXIT EXTEND
EXTERNAL FALSE FD FILE FILE-CONTROL FILLER FIRST FOOTING FOR FROM FUNCTION
GENERATE GIVING GLOBAL GO GOBACK GREATER GROUP HIGH-VALUE HIGH-VALUES I-O
I-O-CONTROL ID IDENTIFICATION IF IN INDEX INDEXED INITIAL INITIALIZE INPUT
INPUT-OUTPUT INSPECT INSTALLATION INTO INVALID IS JUST JUSTIFIED KEY LABEL
LEADING LEFT LENGTH LESS LINAGE LINE LINES LINKAGE LOCK LOW-VALUE LOW-VALUES
MEMORY MERGE MODE MODULES MOVE MULTIPLY NATIVE NEGATIVE NEXT NO NOT NUMERIC
OBJECT-COMPUTER OCCURS OF OFF OMITTED ON OPEN OPTIONAL OR ORDER ORGANIZATION
OUTPUT OVERFLOW PAGE PERFORM PIC PICTURE PLUS POINTER POSITION POSITIVE
PROCEDURE PROCEED PROGRAM PROGRAM-ID QUOTE QUOTES RANDOM READ RECORD RECORDS
REDEFINES REEL REFERENCE RELATIVE RELEASE REMAINDER REMOVAL RENAMES REPLACING
RERUN RESERVE RETURN RETURNING REVERSED REWIND REWRITE RIGHT ROUNDED RUN SAME
SD SEARCH SECTION SECURITY SELECT SENTENCE SEPARATE SEQUENCE SEQUENTIAL SET SIGN
SIZE SORT SORT-MERGE SOURCE-COMPUTER SPACE SPACES SPECIAL-NAMES STANDARD
STANDARD-1 STANDARD-2 START STATUS STOP STRING SUBTRACT SUM SYMBOLIC SYNC
SYNCHRONIZED TALLYING TAPE TEST THAN THEN THROUGH THRU TIME TIMES TO TOP TRUE
TYPE UNIT UNSTRING UNTIL UP UPON USAGE USE USING VALUE VALUES VARYING WHEN WITH
WORKING-STORAGE WRITE ZERO ZEROES ZEROS TALLY RETURN-CODE SORT-RETURN
NUMVAL NUMVAL-C CURRENT-DATE INTEGER-OF-DATE DATE-OF-INTEGER UPPER-CASE
LOWER-CASE WHEN-COMPILED MAX MIN MOD REM DAY-OF-WEEK INTEGER LENGTH-AN
TEST-NUMVAL TEST-NUMVAL-C INTEGER-PART INTEGER-OF-DAY DAY-OF-INTEGER ABS SQRT
REVERSE TRIM ORD ORD-MAX ORD-MIN STANDARD-DEVIATION VARIANCE MEAN MEDIAN RANGE
MIDRANGE EXP LOG LOG10 FACTORIAL RANDOM SIN COS TAN ASIN ACOS ATAN
""".split())
INDEXED_RE = re.compile(r"\bINDEXED\s+BY\s+(.+)$")

DEF_RE = re.compile(r"^\s*(\d\d)\s+([A-Z0-9][A-Z0-9-]*)")
FD_RE = re.compile(r"^\s*(?:FD|SD)\s+([A-Z0-9][A-Z0-9-]*)")
SEL_RE = re.compile(r"\bSELECT\s+([A-Z0-9][A-Z0-9-]*)")
COPY_RE = re.compile(r"\bCOPY\s+([A-Z0-9][A-Z0-9-]*)")
PARA_RE = re.compile(r"^ {1,4}([A-Z0-9][A-Z0-9-]*)\.\s*$")
PERF_RE = re.compile(r"\bPERFORM\s+([A-Z0-9][A-Z0-9-]*)(?:\s+(?:THRU|THROUGH)\s+([A-Z0-9][A-Z0-9-]*))?")
GOTO_RE = re.compile(r"\bGO\s+TO\s+([A-Z0-9][A-Z0-9-]*)")
SECT_RE = re.compile(r"^ {1,4}([A-Z0-9][A-Z0-9-]*)\s+SECTION\s*\.\s*$")
FS_RE = re.compile(r"\bFILE\s+STATUS\s+(?:IS\s+)?([A-Z0-9][A-Z0-9-]*)")
TOKEN_RE = re.compile(r"[A-Z0-9][A-Z0-9-]*")

def area(line):
    # content columns 7..72 (0-based 6..72); col7 '*'/ '/' => comment
    body = line.rstrip("\n")
    if len(body) >= 7 and body[6] in "*/":
        return None
    return body[6:72] if len(body) > 6 else ""

def strip_lit(s):
    s = re.sub(r"'[^']*'", " ", s)
    s = re.sub(r'"[^"]*"', " ", s)
    return s

def copy_names(path, seen):
    """all data-names defined in a copybook (recursively)."""
    if path in seen or not os.path.exists(path):
        return set()
    seen.add(path)
    names = set()
    for raw in open(path, encoding="utf-8", errors="replace"):
        c = area(raw)
        if c is None:
            continue
        cu = c.upper()
        m = DEF_RE.match(cu)
        if m:
            if m.group(2) != "FILLER":
                names.add(m.group(2))
        for cp in COPY_RE.findall(cu):
            names |= copy_names(os.path.join(CPY, cp + ".cpy"), seen)
    return names

def audit(path):
    findings = []
    pid = os.path.basename(path)[:-4]
    lines = open(path, encoding="utf-8", errors="replace").readlines()
    defined = set()          # data-names
    paras = []               # (name, lineno)
    para_set = set()
    fs_vars = set()          # file-status var names declared on SELECT
    div = 0                  # 0 pre, 1 data, 2 procedure
    in_exec = False
    perfs = []               # (target, lineno) incl THRU
    gotos = []
    refs = {}                # name -> first lineno (procedure, non-exec)
    has_goback = has_cicsret = has_exec_cics = False
    for i, raw in enumerate(lines, 1):
        c = area(raw)
        if c is None:
            continue
        cu = c.upper()
        if "DATA DIVISION" in cu:
            div = 1; continue
        if "PROCEDURE DIVISION" in cu:
            div = 2; continue
        # SELECT / FILE STATUS (environment div, before data)
        for f in FS_RE.findall(cu):
            fs_vars.add(f)
        if div <= 1:
            m = DEF_RE.match(cu)
            if m and m.group(2) != "FILLER":
                defined.add(m.group(2))
            m = FD_RE.match(cu)
            if m:
                defined.add(m.group(1))
            for s in SEL_RE.findall(cu):
                defined.add(s)
            for cp in COPY_RE.findall(cu):
                defined |= copy_names(os.path.join(CPY, cp + ".cpy"), set())
            mi = INDEXED_RE.search(cu)
            if mi:
                for t in re.findall(r"[A-Z0-9][A-Z0-9-]*", mi.group(1)):
                    defined.add(t)
            continue
        # PROCEDURE DIVISION
        ms = SECT_RE.match(cu)
        if ms:
            para_set.add(ms.group(1))       # section names are perform targets too
            continue
        m = PARA_RE.match(cu)
        if m:
            nm = m.group(1)
            if nm in para_set:
                findings.append(("dup-para", i, "duplicate paragraph %s" % nm))
            paras.append((nm, i)); para_set.add(nm)
            continue
        # track EXEC spans
        if "EXEC CICS" in cu or "EXEC SQL" in cu:
            in_exec = True
        if "EXEC CICS" in cu:
            has_exec_cics = True
        if "GOBACK" in cu or "EXIT PROGRAM" in cu or "STOP RUN" in cu:
            has_goback = True
        if in_exec and re.search(r"\bRETURN\b", cu):
            has_cicsret = True
        if not in_exec:
            for m in PERF_RE.finditer(cu):
                perfs.append((m.group(1), i))
                if m.group(2):
                    perfs.append((m.group(2), i))
            for g in GOTO_RE.findall(cu):
                gotos.append((g, i))
            body = strip_lit(cu)
            for t in TOKEN_RE.findall(body):
                if "-" in t and t not in refs:
                    refs[t] = i
        if "END-EXEC" in cu:
            in_exec = False
    # ---- checks ----
    for tgt, ln in perfs + gotos:
        if tgt in RESERVED or re.fullmatch(r"[0-9-]+", tgt):
            continue
        if tgt not in para_set:
            findings.append(("bad-perform", ln, "PERFORM/GO TO undefined para %s" % tgt))
    if not (has_goback or has_cicsret):
        findings.append(("no-terminator", 0, "no GOBACK/EXIT PROGRAM/STOP RUN/CICS RETURN"))
    for v in fs_vars:
        if v not in defined:
            findings.append(("fs-undef", 0, "FILE STATUS var %s not defined" % v))
    # undefined data-name references
    for name, ln in refs.items():
        if name in defined or name in para_set or name in RESERVED:
            continue
        if name.startswith("DFH"):
            continue
        if re.fullmatch(r"[0-9-]+", name):
            continue
        findings.append(("undef-name", ln, "data-name %s not defined" % name))
    return pid, findings

def main():
    total = 0
    by_cat = {}
    progs_with = 0
    for f in sorted(glob.glob(os.path.join(CBL, "*.cbl"))):
        pid, fnd = audit(f)
        if fnd:
            progs_with += 1
            print("\n%s (%d):" % (pid, len(fnd)))
            for cat, ln, msg in fnd:
                print("   [%s] line %s  %s" % (cat, ln, msg))
                by_cat[cat] = by_cat.get(cat, 0) + 1
                total += 1
    print("\n==================== AUDIT2 SUMMARY ====================")
    print("programs with findings: %d / %d" % (progs_with, len(glob.glob(os.path.join(CBL, '*.cbl')))))
    for cat in sorted(by_cat):
        print("   %-16s %d" % (cat, by_cat[cat]))
    print("TOTAL findings: %d" % total)
    return total

sys.exit(1 if main() else 0)
