# -*- coding: utf-8 -*-
# ORION-CCMS: emit compact-but-real IBM COBOL batch report programs.
# Unique program names (no collision with the top-up agent wave).
import os
BASE = os.path.join(os.path.dirname(__file__), "..", "cbl")

def prog(pid, title, func, src_dd, src_cpy, body_paras, extra_ws=None):
    L = []
    B = "      *****************************************************************"
    L += [B,
        "      *  SYSTEM  : ORION-CCMS  (Credit Card Management)              *",
        "      *  PROGRAM : %-8s -  %-33s*" % (pid, title[:33]),
        "      *  TYPE    : BATCH  (VSAM)                                     *",
        "      *  FUNCTION: %-49s*" % func[:49],
        B,
        "       IDENTIFICATION DIVISION.",
        "       PROGRAM-ID. %s." % pid,
        "       ENVIRONMENT DIVISION.",
        "       INPUT-OUTPUT SECTION.",
        "       FILE-CONTROL.",
        "           SELECT SRC-FILE ASSIGN TO %s" % src_dd,
        "                  ORGANIZATION INDEXED ACCESS SEQUENTIAL",
        "                  RECORD KEY %s FILE STATUS WS-SRC-FS." % KEYS[src_dd],
        "           SELECT RPT-FILE ASSIGN TO RPTFILE",
        "                  ORGANIZATION LINE SEQUENTIAL FILE STATUS WS-RPT-FS.",
        "       DATA DIVISION.",
        "       FILE SECTION.",
        "       FD  SRC-FILE.",
        "       COPY %s." % src_cpy,
        "       FD  RPT-FILE.",
        "       01  RPT-REC                  PIC X(132).",
        "       WORKING-STORAGE SECTION.",
        "       01  WS-STATUS.",
        "           05  WS-SRC-FS            PIC X(02) VALUE '00'.",
        "           05  WS-RPT-FS            PIC X(02) VALUE '00'.",
        "           05  WS-EOF               PIC X(01) VALUE 'N'.",
        "               88  END-OF-SRC                 VALUE 'Y'.",
        "       01  WS-CNTRS.",
        "           05  WS-READ-CNT          PIC 9(07) VALUE ZEROS.",
        "           05  WS-SEL-CNT           PIC 9(07) VALUE ZEROS.",
        "           05  WS-PAGE              PIC 9(05) VALUE ZEROS.",
        "           05  WS-LINE              PIC 9(03) VALUE 99.",
        "           05  WS-TOT-AMT           PIC S9(15)V99 VALUE ZEROS.",
        "       01  WS-CURR                  PIC X(21).",
        "       01  WS-DATE-EDIT             PIC X(10).",]
    if extra_ws:
        L += extra_ws
    L += [
        "       01  WS-H1.",
        "           05  FILLER PIC X(11) VALUE 'ORION-CCMS '.",
        "           05  FILLER PIC X(45) VALUE",
        "               '%s'." % title[:45],
        "           05  FILLER PIC X(61) VALUE SPACES.",
        "           05  FILLER PIC X(06) VALUE 'PAGE  '.",
        "           05  WH-PAGE PIC ZZZ9.",
        "       01  WS-H2.",
        "           05  FILLER PIC X(10) VALUE 'RUN DATE: '.",
        "           05  WH-DATE PIC X(10).",
        "           05  FILLER PIC X(112) VALUE SPACES.",
        "       01  WS-DET.",
        "           05  WD-KEY  PIC X(16).",
        "           05  FILLER  PIC X(02) VALUE SPACES.",
        "           05  WD-TXT  PIC X(45).",
        "           05  FILLER  PIC X(02) VALUE SPACES.",
        "           05  WD-AMT  PIC -,---,---,--9.99.",
        "           05  FILLER  PIC X(49) VALUE SPACES.",
        "       01  WS-T1.",
        "           05  FILLER PIC X(18) VALUE 'RECORDS READ    : '.",
        "           05  WT-READ PIC ZZZ,ZZ9.",
        "           05  FILLER PIC X(14) VALUE '   SELECTED : '.",
        "           05  WT-SEL PIC ZZZ,ZZ9.",
        "       01  WS-T2.",
        "           05  FILLER PIC X(18) VALUE 'TOTAL AMOUNT    : '.",
        "           05  WT-AMT PIC -,---,---,---,--9.99.",
        "       PROCEDURE DIVISION.",
        "       0000-MAIN.",
        "           PERFORM 1000-INIT.",
        "           PERFORM 2000-PROCESS UNTIL END-OF-SRC.",
        "           PERFORM 3000-FINISH.",
        "           GOBACK.",
        "       1000-INIT.",
        "           MOVE FUNCTION CURRENT-DATE TO WS-CURR.",
        "           MOVE WS-CURR(1:4) TO WS-DATE-EDIT(1:4).",
        "           MOVE '-' TO WS-DATE-EDIT(5:1).",
        "           MOVE WS-CURR(5:2) TO WS-DATE-EDIT(6:2).",
        "           MOVE '-' TO WS-DATE-EDIT(8:1).",
        "           MOVE WS-CURR(7:2) TO WS-DATE-EDIT(9:2).",
        "           MOVE WS-DATE-EDIT TO WH-DATE.",
        "           OPEN INPUT SRC-FILE.",
        "           IF WS-SRC-FS NOT = '00'",
        "               DISPLAY '%s: open FS=' WS-SRC-FS" % pid,
        "               SET END-OF-SRC TO TRUE",
        "           END-IF.",
        "           OPEN OUTPUT RPT-FILE.",
        "           PERFORM 2500-READ.",
        "       1500-HEADING.",
        "           ADD 1 TO WS-PAGE.",
        "           MOVE WS-PAGE TO WH-PAGE.",
        "           MOVE WS-H1 TO RPT-REC.",
        "           WRITE RPT-REC AFTER ADVANCING PAGE.",
        "           MOVE WS-H2 TO RPT-REC.",
        "           WRITE RPT-REC.",
        "           MOVE SPACES TO RPT-REC.",
        "           WRITE RPT-REC.",
        "           MOVE 4 TO WS-LINE.",]
    L += body_paras
    L += [
        "       2500-READ.",
        "           READ SRC-FILE NEXT RECORD",
        "               AT END SET END-OF-SRC TO TRUE",
        "           END-READ.",
        "       2800-WRITE-DET.",
        "           IF WS-LINE > 55",
        "               PERFORM 1500-HEADING",
        "           END-IF.",
        "           MOVE WS-DET TO RPT-REC.",
        "           WRITE RPT-REC.",
        "           ADD 1 TO WS-LINE.",
        "       3000-FINISH.",
        "           IF WS-PAGE = 0",
        "               PERFORM 1500-HEADING",
        "           END-IF.",
        "           MOVE WS-READ-CNT TO WT-READ.",
        "           MOVE WS-SEL-CNT  TO WT-SEL.",
        "           MOVE WS-TOT-AMT  TO WT-AMT.",
        "           MOVE SPACES TO RPT-REC.",
        "           WRITE RPT-REC.",
        "           MOVE WS-T1 TO RPT-REC.",
        "           WRITE RPT-REC.",
        "           MOVE WS-T2 TO RPT-REC.",
        "           WRITE RPT-REC.",
        "           CLOSE SRC-FILE RPT-FILE.",
        "           DISPLAY '%s: read ' WS-READ-CNT" % pid,
        "                   ' selected ' WS-SEL-CNT.",]
    path = os.path.join(BASE, "%s.cbl" % pid)
    with open(path, "w", newline="\r\n") as f:
        f.write("\n".join(L) + "\n")
    n = sum(1 for _ in open(path))
    bad = [i + 1 for i, ln in enumerate(open(path)) if len(ln.rstrip("\n")) > 72]
    return n, bad

KEYS = {"TRANFILE": "TR-ID", "CARDFILE": "CD-NUM",
        "CUSTFILE": "CU-ID", "ACCTFILE": "AC-ID"}

specs = []

# 1) OBRTOP - top spenders (high-value transactions)
specs.append(("OBRTOP", "TOP-SPENDER TRANSACTION REPORT",
    "list transactions above a spend threshold", "TRANFILE", "RTRAN", [
    "       2000-PROCESS.",
    "           ADD 1 TO WS-READ-CNT.",
    "           IF TR-AMT > 1000.00",
    "               ADD 1 TO WS-SEL-CNT",
    "               ADD TR-AMT TO WS-TOT-AMT",
    "               MOVE TR-CARD-NUM TO WD-KEY",
    "               MOVE TR-MERCHANT-NAME TO WD-TXT",
    "               MOVE TR-AMT TO WD-AMT",
    "               PERFORM 2800-WRITE-DET",
    "           END-IF.",
    "           PERFORM 2500-READ."], None))

# 2) OBCARDX - card master extract listing
specs.append(("OBCARDX", "CARD MASTER EXTRACT REPORT",
    "list active card master records", "CARDFILE", "RCARD", [
    "       2000-PROCESS.",
    "           ADD 1 TO WS-READ-CNT.",
    "           IF CD-ACTIVE-STATUS = 'Y'",
    "               ADD 1 TO WS-SEL-CNT",
    "               MOVE CD-NUM TO WD-KEY",
    "               MOVE CD-EMBOSSED-NAME TO WD-TXT",
    "               MOVE ZERO TO WD-AMT",
    "               PERFORM 2800-WRITE-DET",
    "           END-IF.",
    "           PERFORM 2500-READ."], None))

# 3) OBRSCORE - FICO distribution
specs.append(("OBRSCORE", "FICO SCORE LISTING",
    "list customers with FICO score", "CUSTFILE", "RCUST", [
    "       2000-PROCESS.",
    "           ADD 1 TO WS-READ-CNT.",
    "           ADD 1 TO WS-SEL-CNT.",
    "           MOVE CU-ID TO WD-KEY.",
    "           MOVE SPACES TO WD-TXT.",
    "           STRING CU-LAST-NAME DELIMITED BY SPACE",
    "                  ', ' DELIMITED BY SIZE",
    "                  CU-FIRST-NAME DELIMITED BY SPACE",
    "                  INTO WD-TXT",
    "           END-STRING.",
    "           MOVE CU-FICO-SCORE TO WD-AMT.",
    "           ADD CU-FICO-SCORE TO WS-TOT-AMT.",
    "           PERFORM 2800-WRITE-DET.",
    "           PERFORM 2500-READ."], None))

# 4) OBRDORM - dormant accounts (no cycle activity)
specs.append(("OBRDORM", "DORMANT ACCOUNT REPORT",
    "list accounts with no cycle activity", "ACCTFILE", "RACCT", [
    "       2000-PROCESS.",
    "           ADD 1 TO WS-READ-CNT.",
    "           IF AC-CYC-CREDIT = 0 AND AC-CYC-DEBIT = 0",
    "               ADD 1 TO WS-SEL-CNT",
    "               ADD AC-CURR-BAL TO WS-TOT-AMT",
    "               MOVE AC-ID TO WD-KEY",
    "               MOVE 'DORMANT - NO CYCLE ACTIVITY' TO WD-TXT",
    "               MOVE AC-CURR-BAL TO WD-AMT",
    "               PERFORM 2800-WRITE-DET",
    "           END-IF.",
    "           PERFORM 2500-READ."], None))

# 5) OBRAVAIL - available credit report
specs.append(("OBRAVAIL", "AVAILABLE CREDIT REPORT",
    "list available credit per account", "ACCTFILE", "RACCT", [
    "       2000-PROCESS.",
    "           ADD 1 TO WS-READ-CNT.",
    "           ADD 1 TO WS-SEL-CNT.",
    "           COMPUTE WS-WORK-AMT =",
    "               AC-CREDIT-LIMIT - AC-CURR-BAL.",
    "           ADD WS-WORK-AMT TO WS-TOT-AMT.",
    "           MOVE AC-ID TO WD-KEY.",
    "           MOVE 'AVAILABLE CREDIT' TO WD-TXT.",
    "           MOVE WS-WORK-AMT TO WD-AMT.",
    "           PERFORM 2800-WRITE-DET.",
    "           PERFORM 2500-READ."],
    ["       01  WS-WORK-AMT             PIC S9(13)V99 VALUE ZEROS."]))

# 6) OBRZIP - cardholder geographic listing by ZIP
specs.append(("OBRZIP", "ACCOUNT ZIP DISTRIBUTION",
    "list accounts by mailing ZIP code", "ACCTFILE", "RACCT", [
    "       2000-PROCESS.",
    "           ADD 1 TO WS-READ-CNT.",
    "           ADD 1 TO WS-SEL-CNT.",
    "           MOVE AC-ID TO WD-KEY.",
    "           STRING 'ZIP ' DELIMITED BY SIZE",
    "                  AC-ADDR-ZIP DELIMITED BY SIZE",
    "                  '  GROUP ' DELIMITED BY SIZE",
    "                  AC-GROUP-ID DELIMITED BY SIZE",
    "                  INTO WD-TXT",
    "           END-STRING.",
    "           MOVE AC-CURR-BAL TO WD-AMT.",
    "           ADD AC-CURR-BAL TO WS-TOT-AMT.",
    "           PERFORM 2800-WRITE-DET.",
    "           PERFORM 2500-READ."], None))

total = 0
for s in specs:
    n, bad = prog(*s)
    total += n
    print("%-9s %4d lines %s" % (s[0], n, ("BAD:%s" % bad) if bad else "ok"))
print("TOTAL new lines:", total)
