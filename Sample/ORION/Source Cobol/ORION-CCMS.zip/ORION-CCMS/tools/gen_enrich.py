# -*- coding: utf-8 -*-
# Generate docs/enrich_en.md (CardDemo-style enrichment doc) for ORION-CCMS.
# Curated prose + tables generated from the source tree.
import os, glob, re
ROOT = os.path.join(os.path.dirname(__file__), "..")
def rd(p): return open(p, encoding="utf-8", errors="replace").read()

# ---- program facts ----
def banner(f):
    pid = desc = ""
    t = rd(f)
    for ln in t.splitlines():
        m = re.search(r"PROGRAM\s*:\s*(\S+)\s*-\s*(.+?)\s*\*?\s*$", ln)
        if m and not pid:
            pid, desc = m.group(1), m.group(2).strip()
    if not pid:
        pid = os.path.basename(f)[:-4]
    cics = "EXEC CICS" in t
    sql = "EXEC SQL" in t
    ims = "CBLTDLI" in t
    mq = bool(re.search(r"MQOPEN|MQPUT|MQGET|MQCONN", t))
    bms = bool(re.search(r"SEND\s+MAP|RECEIVE\s+MAP", t))
    tech = []
    if cics: tech.append("CICS")
    if bms: tech.append("BMS")
    if sql: tech.append("DB2")
    if ims: tech.append("IMS")
    if mq: tech.append("MQ")
    if not (cics or sql): tech.append("VSAM/batch")
    return pid, desc, tech

# ---- TRAN map from CSD ----
tran = {}
for c in glob.glob(os.path.join(ROOT, "csd", "*.csd")):
    txt = rd(c)
    for m in re.finditer(r"DEFINE\s+TRANSACTION\((\w+)\)[\s\S]{0,120}?PROGRAM\((\w+)\)", txt):
        tran[m.group(2)] = m.group(1)

progs = [banner(f) for f in sorted(glob.glob(os.path.join(ROOT, "cbl", "*.cbl")))]

def kind(pid): return "Sub" if pid.startswith("OU") else "Main"
def trig(pid):
    if pid.startswith("OU"): return "LINK"
    return tran.get(pid, "UI")

# ---- assemble ----
O = []
def w(s=""): O.append(s)

w("# ORION-CCMS - Enrichment (English)")
w()
w("> Human-curated enrichment for the **ORION-CCMS** credit-card management "
  "system (original IBM z/OS COBOL work; domain-alike of a card platform, not "
  "copied from any product). Sliced per LLM call level via "
  "`<!-- enrich-include: ... -->` tags.")
w("> **Note**: technical identifiers (program IDs, DDNAMEs, DB2 table names, "
  "copybook names, BMS map names, IMS DBD/PSB, MQ queue names) stay in their "
  "original Latin form. Only business prose is in English.")
w()
w("---")
w()

w("## 1. System Overview")
w("<!-- enrich-include: all -->")
w()
n_oc = sum(1 for p in progs if p[0].startswith("OC"))
n_od = sum(1 for p in progs if p[0].startswith("OD"))
n_ou = sum(1 for p in progs if p[0].startswith("OU"))
w("ORION-CCMS is an **online-centric** IBM mainframe credit-card management "
  "system. Every business function is a **CICS pseudo-conversational BMS "
  "screen**; all non-screen processing (balance posting, account maintenance, "
  "report/inquiry browsing, authorization, cross-reference rebuild) is a "
  "**sub-program** the screen drives with `EXEC CICS LINK`. There is no "
  "standalone report/batch tier - former batch jobs were converted to "
  "operator-initiated online sub-programs.")
w()
w("**Technology stack (diverse, mainframe-native):**")
w()
w("- **CICS + BMS** - online transactions and 3270 maps.")
w("- **VSAM (KSDS/AIX)** - primary master/detail data stores.")
w("- **DB2 (EXEC SQL)** - relational access variant for account/card/customer/"
  "transaction screens (the `OD*` family).")
w("- **IMS DB (DL/I, `CALL 'CBLTDLI'`)** - the pending-authorization database "
  "(`OPAUDB` / PSB `OPAUPSB` / segment `PAUSEG`).")
w("- **IBM MQ (MQI `CALL`)** - the authorization request/reply flow and a "
  "VSAM->MQ transaction feed bridge.")
w("- **JCL** - compile/link (CICS translate `DFHYITVL`, CICS+DB2 `DFHYITDL`), "
  "IMS DBDGEN/PSBGEN/ACBGEN, VSAM DEFINE, MQ DEFINE.")
w()
w("**Program families (%d programs total):**" % len(progs))
w()
w("- **`OC*` on-line CICS screens (%d)** - sign-on, menu, account/card/"
  "customer/transaction maintenance, bill pay, statement view, user admin, "
  "consolidated inquiry screens, admin operations/utilities." % n_oc)
w("- **`OD*` on-line CICS + DB2 screens (%d)** - DB2-backed view variants." % n_od)
w("- **`OU*` sub-programs (%d)** - CICS-linked posting/maintenance/inquiry-"
  "browse plus the MQ and IMS DL/I access modules." % n_ou)
w()

w("## 2. Naming Conventions")
w("<!-- enrich-include: all -->")
w()
w("| Prefix | Category |")
w("|---|---|")
w("| `OC` | CICS on-line screen program |")
w("| `OD` | CICS on-line screen program with DB2 (EXEC SQL) |")
w("| `OU` | Sub-program / utility (called via `EXEC CICS LINK` or `CALL`) |")
w("| `OB` | Batch (residual - none in the online-centric build) |")
w()
w("- **Transactions** - 4-char `OR**` codes (e.g. `ORSN` sign-on, `ORMN`/menu, "
  "`ORAI` account inquiry, `ORAQ` MQ authorization, `ORPI` IMS pending-auth).")
w("- **BMS** - mapset `M<screen>`, map `M<screen>A`, DSECT copybook = mapset name.")
w("- **Copybooks** - `R<entity>` record, `KCOMM` shared COMMAREA, `K*` sub "
  "linkage/interface, `W*` shared constants/messages/heading, `M*` BMS DSECT.")
w("- **VSAM DDNAMEs** - business name + `FILE` (e.g. `ACCTFILE`, `CARDFILE`, "
  "`TRANFILE`, `XREFFILE`).")
w("- **DB2 tables** - schema `ORION.<ENTITY>` (PK per `ddl/ORION.ddl`).")
w("- **IMS** - DBD `OPAUDB`, PSB `OPAUPSB`, segment `PAUSEG`.")
w("- **MQ** - queue manager `ORIONQM1`; queues `ORION.<PURPOSE>.QUEUE`.")
w()

w("## 3. Glossary")
w("<!-- enrich-include: all -->")
w()
w("| Term | Notes |")
w("|---|---|")
for term, note in [
 ("Credit card","core domain"),("Account","cardholder account (ACCTFILE / ORION.ACCT)"),
 ("Card","plastic card record (CARDFILE / ORION.CARD)"),
 ("Customer","cardholder person (CUSTFILE / ORION.CUST)"),
 ("Cross-reference","card->account->customer link (XREFFILE / ORION.XREF)"),
 ("Transaction","posted card transaction (TRANFILE / ORION.TRAN)"),
 ("Transaction type / category","classification (TTYPFILE / TCATFILE)"),
 ("Statement","monthly billing statement (STMTFILE / ORION.STMT)"),
 ("Bill / payment","incoming payment posting (ORION.BILL)"),
 ("Authorization","real-time approve/decline (MQ flow + IMS pending-auth)"),
 ("Pending authorization","IMS PAUSEG segment awaiting settlement"),
 ("Delinquency","balance past minimum-due threshold"),
 ("Utilization","balance / credit-limit ratio"),
 ("Charge-off","write-off of a severely delinquent account"),
 ("Inquiry screen","read-only paged BMS browse (replaces a batch report)"),
 ("Reports menu","`OCRPTMN` - fronts the inquiry screens"),
 ("Operations screen","`OCOPS` - runs posting sub-programs"),
 ("Data-utilities screen","`OCUTIL` - runs maintenance sub-programs"),
 ("Sub-program","non-screen module reached via EXEC CICS LINK / CALL"),
 ("Copybook","COBOL COPY include"),("Mapset / Map","BMS screen definition"),
 ("KSDS / AIX","VSAM key-sequenced dataset / alternate index"),
 ("DL/I","IMS data-language interface (CALL 'CBLTDLI')"),
 ("MQI","IBM MQ call interface (MQOPEN/MQPUT/MQGET)"),
 ("COMMAREA","CICS communication area (KCOMM)"),
]:
    w("| %s | %s |" % (term, note))
w()

w("## 4. Documentation Tone")
w("<!-- enrich-include: all -->")
w()
w("- English for business prose; technical IDs stay in source form.")
w("- On-line programs are CICS transactions - describe them with their BMS "
  "map + `EIBCALEN`/`EIBAID`/`DFHRESP` branching and the COMMAREA they carry.")
w("- Sub-programs: describe as \"sub called by <screen> via EXEC CICS LINK\", "
  "naming the file/table/queue/segment they touch.")
w("- DB2 programs: name the `ORION.*` table and the SQL operation.")
w("- IMS programs: name the PSB/DBD/segment and the DL/I function.")
w("- MQ programs: name the queue and MQI verb.")
w()

w("## 5. Known Quirks")
w("<!-- enrich-include: program,project -->")
w()
for q in [
 "**`OCSGNON` (ORSN)** is the entry point; it dispatches to `OCMENU` (main) "
 "or `OCADMEN` (admin).",
 "**`OCMENU` option 10 -> `OCRPTMN`**, the consolidated Reports/Inquiry menu "
 "that XCTLs to the six inquiry screens.",
 "**Inquiry screens** (`OCACTIN`/`OCCRDIN`/`OCCUSIN`/`OCTRNIN`/`OCSTMIN`/"
 "`OCANLIN`) each LINK a browse sub (`OUACTIN` ...) that walks a VSAM file "
 "with `STARTBR`/`READNEXT`/`ENDBR` under a filter and returns one page; they "
 "replace the former batch reports.",
 "**`OCANLIN`** has a MODE field: REWARDS / FRAUD / GL / RECON - one screen, "
 "four analytics, computed by `OUANLIN`.",
 "**`OCOPS` (OROP)** runs posting subs (`OUPOST` post, `OUPAY` payment, "
 "`OUINT` interest, `OUFEE` fee, `OUCHGF` charge-off, `OUCLOS` close, "
 "`OURNEW` renewal, `OUCYCL` cycle).",
 "**`OCUTIL` (ORUT)** runs maintenance subs (`OUXREF` rebuild xref, `OUSTMB` "
 "build statement, `OUFLAG` flag, `OUIMP` import, `OUARCH` archive, "
 "`OUPURG` purge, `OUBKP` backup).",
 "**`OCAUTHQ` (ORAQ)** authorization screen -> `OUMQREQ` (MQI): builds the "
 "request, MQPUT/MQGET on `ORION.AUTH.REQUEST.QUEUE`/`...REPLY.QUEUE`, and "
 "authorizes locally via XREF->ACCT so it runs without a live queue manager.",
 "**`OUMQBRG`** is the VSAM->MQ bridge (reads TRANFILE, MQPUT to "
 "`ORION.TRAN.OUTBOUND.QUEUE`) - the one module that can also run as batch.",
 "**`OCPAUIN` (ORPI)** pending-auth inquiry -> `OUIMSPA` DL/I sub: GU/GN/ISRT/"
 "REPL/DLET on segment `PAUSEG` of `OPAUDB`; PCB status checked after each "
 "`CALL 'CBLTDLI'`.",
 "**`OURNEW`** keeps the leap-year guard: a Feb-29 expiry extended to a "
 "non-leap year is clamped to Feb-28 via `FUNCTION MOD`.",
]:
    w("- " + q)
w()

w("## 6. Programs (sorted by ID)")
w("<!-- enrich-include: program,project -->")
w()
w("> Kind = Main (screen) / Sub. Trigger = TRAN code (UI) or LINK "
  "(called by a screen). Tech lists the technologies each program uses.")
w()
w("| ID | Business Name | Tech | Kind | Trigger |")
w("|---|---|---|---|---|")
for pid, desc, tech in progs:
    w("| %s | %s | %s | %s | %s |"
      % (pid, desc[:52] or "-", " ".join(tech), kind(pid), trig(pid)))
w()

w("## 7. Dataset / File Inventory")
w("<!-- enrich-include: program,project -->")
w()
w("> On-line programs access VSAM via CICS file control "
  "(`EXEC CICS READ FILE(...)`); the FCT names below are the canonical data "
  "stores (`docs/SPEC.md` §3).")
w()
w("### VSAM (FCT name)")
w()
vdesc = [("ACCTFILE","KSDS","Account master (key AC-ID)"),
 ("CARDFILE","KSDS","Card master (key CD-NUM)"),
 ("CUSTFILE","KSDS","Customer master (key CU-ID)"),
 ("XREFFILE","KSDS+AIX","Card->account->customer cross-reference"),
 ("TRANFILE","KSDS","Transaction history (key TR-ID)"),
 ("TTYPFILE","KSDS","Transaction-type master"),
 ("TCATFILE","KSDS","Transaction-category master"),
 ("STMTFILE","KSDS","Statement master"),
 ("DGRPFILE","KSDS","Disclosure-group master"),
 ("CTRLFILE","KSDS","Control / sequence-counter file"),
 ("USRSEC","KSDS","User security master"),
 ("ARCHFILE","ESDS","Transaction archive (OUARCH)"),
 ("IMPFILE","seq","Import staging feed (OUIMP)"),
 ("BKPFILE","seq","Transaction backup feed (OUBKP)")]
w("| FCT / file | Type | Business |")
w("|---|---|---|")
for d, ty, ds in vdesc:
    w("| `%s` | %s | %s |" % (d, ty, ds))
w()
w("### DB2 tables (`ddl/ORION.ddl`)")
w()
w("| Table | Business |")
w("|---|---|")
ddl = rd(os.path.join(ROOT,"ddl","ORION.ddl")) if os.path.exists(os.path.join(ROOT,"ddl","ORION.ddl")) else ""
db2desc = {"ACCT":"Account master","BILL":"Bill / payment postings",
 "CARD":"Card master","CTRL":"Control / sequence counters","CUST":"Customer master",
 "DGRP":"Disclosure-group master","STMT":"Statement master",
 "TCAT":"Transaction-category master","TRAN":"Transaction history",
 "TTYP":"Transaction-type master","USRSEC":"User security","XREF":"Cross-reference"}
for t in sorted(set(re.findall(r"CREATE\s+TABLE\s+(ORION\.\w+)", ddl, re.I))):
    e = t.split(".")[-1].upper()
    w("| `%s` | %s |" % (t, db2desc.get(e, e.title())))
w()
w("### IMS DB")
w()
w("| DBD | PSB | Segment | Access |")
w("|---|---|---|---|")
w("| `OPAUDB` | `OPAUPSB` | `PAUSEG` | HDAM/OSAM, DL/I via `OUIMSPA` |")
w()
w("### MQ (queue manager `ORIONQM1`)")
w()
w("| Queue | Purpose |")
w("|---|---|")
w("| `ORION.AUTH.REQUEST.QUEUE` | authorization requests (`OUMQREQ` MQPUT) |")
w("| `ORION.AUTH.REPLY.QUEUE` | authorization replies (`OUMQREQ` MQGET) |")
w("| `ORION.TRAN.OUTBOUND.QUEUE` | transaction feed (`OUMQBRG` MQPUT) |")
w()

w("## 8. Copybook Catalog")
w("<!-- enrich-include: program,project -->")
w()
cpys = sorted(os.path.basename(f)[:-4] for f in glob.glob(os.path.join(ROOT,"cpy","*.cpy")))
rec = [c for c in cpys if c.startswith("R")]
dsect = [c for c in cpys if c.startswith("M")]
link = [c for c in cpys if c.startswith("K")]
comm = [c for c in cpys if c.startswith("W")]
w("- **Record layouts (`R*`, %d):** %s" % (len(rec), ", ".join("`%s`"%c for c in rec)))
w("- **BMS DSECTs (`M*`, %d):** %s" % (len(dsect), ", ".join("`%s`"%c for c in dsect)))
w("- **Linkage / interface (`K*`, %d):** %s" % (len(link), ", ".join("`%s`"%c for c in link)))
w("- **Shared common (`W*`, %d):** %s" % (len(comm), ", ".join("`%s`"%c for c in comm)))
w()

w("## 9. BMS Maps (screen definitions)")
w("<!-- enrich-include: program,project -->")
w()
# map -> program that COPYs the DSECT
prog_src = {os.path.basename(f)[:-4]: rd(f) for f in glob.glob(os.path.join(ROOT,"cbl","*.cbl"))}
w("| Mapset | Used by | Screen |")
w("|---|---|---|")
mdesc = {p:d for p,d,_ in progs}
for m in sorted(os.path.basename(f)[:-4] for f in glob.glob(os.path.join(ROOT,"bms","*.bms"))):
    users = [p for p,s in prog_src.items() if re.search(r"COPY\s+%s\b"%m, s)]
    u = users[0] if users else "-"
    w("| `%s` | `%s` | %s |" % (m, u, mdesc.get(u,"-")[:40]))
w()

w("## 10. On-line Transaction Flow")
w("<!-- enrich-include: all -->")
w()
w("ORION-CCMS has no batch scheduler - it is driven from the 3270 terminal:")
w()
w("1. **Sign-on** `ORSN` (`OCSGNON`) validates `USRSEC`.")
w("2. **Main menu** `OCMENU` (or admin `OCADMEN`) - operator picks a function; "
  "the menu `XCTL`s to the screen carrying the shared COMMAREA `KCOMM`.")
w("3. **Maintenance** screens READ/WRITE/REWRITE VSAM (or DB2 for `OD*`).")
w("4. **Inquiry** via `OCRPTMN` -> the six inquiry screens (paged browse subs).")
w("5. **Operations** `OCOPS` / **Utilities** `OCUTIL` LINK the posting / "
  "maintenance subs (former batch jobs).")
w("6. **Authorization** `OCAUTHQ` (MQ) and `OCPAUIN` (IMS pending-auth).")
w("7. **PF3** returns up the chain to the menu / sign-on.")
w()

w("## 11. References")
w("<!-- enrich-include: all -->")
w()
w("- `docs/SPEC.md` - authoritative data model + conventions")
w("- `docs/ENTRY_AND_FUNCTIONS.md` - generated program inventory")
w("- `README.md` - project description + build/validation status")
w("- `ddl/ORION.ddl` - DB2 schema ; `dbd/` + `psb/` - IMS gen source")
w("- `csd/ORION*.csd` - CICS resource definitions")
w("- `tools/` - generators (`gen_bms.py`, `gen_copybooks.py`, `gen_entrydoc.py`, "
  "`gen_enrich.py`) + checkers (`check_ccms.py`, `audit2.py`)")

open(os.path.join(ROOT,"docs","enrich_en.md"),"w",encoding="utf-8",newline="\n"
    ).write("\n".join(O)+"\n")
n=sum(1 for _ in open(os.path.join(ROOT,"docs","enrich_en.md"),encoding="utf-8"))
print("wrote docs/enrich_en.md :", n, "lines ;", len(progs), "programs")
