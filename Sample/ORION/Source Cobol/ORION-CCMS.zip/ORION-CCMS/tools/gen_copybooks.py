#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ORION-CCMS record-layout copybook generator (IBM Enterprise COBOL fixed fmt).
Emits cpy/R*.cpy from the data model in docs/SPEC.md section 3."""
import os
CPY = os.path.join(os.path.dirname(__file__), "..", "cpy")

def f(n, p): return (n, p)
def g(n, kids): return (n, None, kids)

FILES = []
def add(cpy, rec, title, fields): FILES.append((cpy, rec, title, fields))

add("RACCT", "ACCT-REC", "Account master record", [
    f("AC-ID","PIC 9(11)"), f("AC-ACTIVE-STATUS","PIC X(01)"),
    f("AC-CURR-BAL","PIC S9(10)V99"), f("AC-CREDIT-LIMIT","PIC S9(10)V99"),
    f("AC-CASH-LIMIT","PIC S9(10)V99"), f("AC-OPEN-DATE","PIC X(10)"),
    f("AC-EXPIRY-DATE","PIC X(10)"), f("AC-REISSUE-DATE","PIC X(10)"),
    f("AC-CYC-CREDIT","PIC S9(10)V99"), f("AC-CYC-DEBIT","PIC S9(10)V99"),
    f("AC-ADDR-ZIP","PIC X(10)"), f("AC-GROUP-ID","PIC X(10)"),
    f("FILLER","PIC X(178)")])

add("RCARD", "CARD-REC", "Card master record", [
    f("CD-NUM","PIC X(16)"), f("CD-ACCT-ID","PIC 9(11)"),
    f("CD-CVV","PIC X(03)"), f("CD-EMBOSSED-NAME","PIC X(50)"),
    f("CD-EXPIRY-DATE","PIC X(10)"), f("CD-ACTIVE-STATUS","PIC X(01)"),
    f("FILLER","PIC X(59)")])

add("RCUST", "CUST-REC", "Customer master record", [
    f("CU-ID","PIC 9(09)"), f("CU-FIRST-NAME","PIC X(25)"),
    f("CU-MIDDLE-NAME","PIC X(25)"), f("CU-LAST-NAME","PIC X(25)"),
    f("CU-ADDR-LINE-1","PIC X(50)"), f("CU-ADDR-LINE-2","PIC X(50)"),
    f("CU-ADDR-CITY","PIC X(50)"), f("CU-ADDR-STATE","PIC X(02)"),
    f("CU-ADDR-COUNTRY","PIC X(03)"), f("CU-ADDR-ZIP","PIC X(10)"),
    f("CU-PHONE-1","PIC X(15)"), f("CU-PHONE-2","PIC X(15)"),
    f("CU-SSN","PIC 9(09)"), f("CU-GOVT-ID","PIC X(20)"),
    f("CU-DOB","PIC X(10)"), f("CU-FICO-SCORE","PIC 9(03)"),
    f("FILLER","PIC X(51)")])

add("RXREF", "XREF-REC", "Card cross-reference record", [
    f("XR-CARD-NUM","PIC X(16)"), f("XR-ACCT-ID","PIC 9(11)"),
    f("XR-CUST-ID","PIC 9(09)"), f("FILLER","PIC X(14)")])

add("RTRAN", "TRAN-REC", "Transaction record", [
    f("TR-ID","PIC X(16)"), f("TR-TYPE-CD","PIC X(02)"),
    f("TR-CAT-CD","PIC 9(04)"), f("TR-SOURCE","PIC X(10)"),
    f("TR-DESC","PIC X(100)"), f("TR-AMT","PIC S9(09)V99"),
    f("TR-MERCHANT-ID","PIC 9(09)"), f("TR-MERCHANT-NAME","PIC X(50)"),
    f("TR-MERCHANT-CITY","PIC X(50)"), f("TR-MERCHANT-ZIP","PIC X(10)"),
    f("TR-CARD-NUM","PIC X(16)"), f("TR-ORIG-TS","PIC X(26)"),
    f("TR-PROC-TS","PIC X(26)"), f("FILLER","PIC X(20)")])

add("RTTYP", "TTYP-REC", "Transaction type record", [
    f("TT-CD","PIC X(02)"), f("TT-DESC","PIC X(50)"), f("FILLER","PIC X(08)")])

add("RTCAT", "TCAT-REC", "Transaction category record", [
    g("TC-KEY", [f("TC-TYPE-CD","PIC X(02)"), f("TC-CD","PIC 9(04)")]),
    f("TC-DESC","PIC X(50)"), f("FILLER","PIC X(04)")])

add("RDGRP", "DGRP-REC", "Disclosure/interest group record", [
    g("DG-KEY", [f("DG-ACCT-GROUP","PIC X(10)"), f("DG-TYPE-CD","PIC X(02)"),
                 f("DG-CAT-CD","PIC 9(04)")]),
    f("DG-INT-RATE","PIC S9(04)V99"), f("FILLER","PIC X(28)")])

add("RUSER", "USER-REC", "User security record", [
    f("US-ID","PIC X(08)"), f("US-FIRST-NAME","PIC X(20)"),
    f("US-LAST-NAME","PIC X(20)"), f("US-PASSWORD","PIC X(08)"),
    f("US-TYPE","PIC X(01)"), f("FILLER","PIC X(23)")])

add("RBILL", "BILL-REC", "Bill payment record", [
    f("BL-ID","PIC 9(11)"), f("BL-ACCT-ID","PIC 9(11)"),
    f("BL-AMOUNT","PIC S9(10)V99"), f("BL-PAY-DATE","PIC X(10)"),
    f("BL-CONFIRM-NUM","PIC X(16)"), f("BL-STATUS","PIC X(01)"),
    f("FILLER","PIC X(20)")])

add("RSTMT", "STMT-REC", "Statement record", [
    g("ST-KEY", [f("ST-ACCT-ID","PIC 9(11)"), f("ST-CYCLE","PIC 9(06)")]),
    f("ST-OPEN-BAL","PIC S9(10)V99"), f("ST-CLOSE-BAL","PIC S9(10)V99"),
    f("ST-TOTAL-CREDIT","PIC S9(10)V99"), f("ST-TOTAL-DEBIT","PIC S9(10)V99"),
    f("ST-MIN-DUE","PIC S9(10)V99"), f("ST-DUE-DATE","PIC X(10)"),
    f("FILLER","PIC X(20)")])

add("RCTRL", "CTRL-REC", "Control / counter record", [
    f("CT-KEY","PIC X(08)"), f("CT-LAST-VALUE","PIC 9(11)"),
    f("CT-DESC","PIC X(30)"), f("FILLER","PIC X(11)")])

def emit(fields):
    out = []
    for fd in fields:
        if len(fd) == 3:  # group
            name, _, kids = fd
            out.append("           05  %s." % name)
            for kn, kp in kids:
                out.append("             10  %-18s%s." % (kn, kp))
        else:
            name, pic = fd
            out.append("           05  %-20s%s." % (name, pic))
    return out

def main():
    os.makedirs(CPY, exist_ok=True)
    for cpy, rec, title, fields in FILES:
        lines = [
            "      *----------------------------------------------------------------",
            "      *  ORION-CCMS copybook - %s : %s" % (cpy, title),
            "      *----------------------------------------------------------------",
            "       01  %s." % rec,
        ] + emit(fields)
        with open(os.path.join(CPY, cpy + ".cpy"), "w", newline="\r\n") as fh:
            fh.write("\n".join(lines) + "\n")
    print("generated %d record copybooks" % len(FILES))

if __name__ == "__main__":
    main()
