# -*- coding: utf-8 -*-
# Regenerate docs/ENTRY_AND_FUNCTIONS.md from program banners + LOC.
import os, glob, re
ROOT = os.path.join(os.path.dirname(__file__), "..")
CBL = os.path.join(ROOT, "cbl")

def banner(path):
    pid = desc = typ = ""
    loc = 0
    for ln in open(path, encoding="utf-8", errors="replace"):
        loc += 1
        m = re.search(r"PROGRAM\s*:\s*(\S+)\s*-\s*(.+?)\s*\*?\s*$", ln)
        if m and not pid:
            pid, desc = m.group(1), m.group(2).strip()
        m = re.search(r"TYPE\s*:\s*(.+?)\s*\*?\s*$", ln)
        if m and not typ:
            typ = m.group(1).strip()
    if not pid:
        pid = os.path.basename(path)[:-4]
    return pid, desc, typ, loc

rows = [banner(f) for f in sorted(glob.glob(os.path.join(CBL, "*.cbl")))]
groups = [
    ("On-line CICS screens (VSAM)", "OC"),
    ("On-line CICS + DB2 screens", "OD"),
    ("Sub-programs (CICS-linked / MQ / IMS DL/I)", "OU"),
    ("Batch (residual)", "OB"),
]
total = len(rows)
total_loc = sum(r[3] for r in rows)

out = []
out.append("# ORION-CCMS - Entry Application & Functions\n")
out.append(
    "Entry transaction **ORSN** -> `OCSGNON` (sign-on, validates USRSEC) -> "
    "`OCMENU` (main menu) or `OCADMEN` (admin). Each function is reached by a "
    "menu option which `XCTL`s to the program carrying the shared COMMAREA "
    "(`KCOMM`); PF3 returns. This is an ONLINE-CENTRIC system: every function "
    "is a BMS screen; non-screen processing (posting, maintenance, inquiry "
    "browse, MQ auth, IMS DL/I) is a sub-program the screen calls via "
    "`EXEC CICS LINK`. Tech: CICS/BMS + VSAM + DB2 + IMS + MQ. "
    "See `docs/SPEC.md` for the data model.\n")
out.append(
    "**Totals:** %d programs, %d COBOL LOC (see README for full artifact "
    "counts).\n" % (total, total_loc))
out.append("## Menu tree\n```")
out.append("ORSN OCSGNON (sign on)")
out.append(" +-- OCMENU  (main)  Acct / Card / Cust / Tran / Bill Pay / Reports")
out.append(" +-- OCADMEN (admin) User maintenance (list/add/upd/del)")
out.append(" (plus list & add screens, tran search, type/category/group maint,")
out.append("  statement view, password change; DB2 report/posting variants OD*)")
out.append("```\n")

for title, pre in groups:
    grp = [r for r in rows if r[0].startswith(pre)]
    out.append("## %s (%d programs)\n" % (title, len(grp)))
    out.append("| ID | Type | Function | LOC |")
    out.append("|----|------|----------|----:|")
    for pid, desc, typ, loc in grp:
        out.append("| %s | %s | %s | %d |" % (pid, typ, desc, loc))
    out.append("")

with open(os.path.join(ROOT, "docs", "ENTRY_AND_FUNCTIONS.md"),
          "w", encoding="utf-8", newline="\n") as f:
    f.write("\n".join(out) + "\n")
print("wrote docs/ENTRY_AND_FUNCTIONS.md : %d programs, %d LOC" % (total, total_loc))
for title, pre in groups:
    print("  %-32s %d" % (title, len([r for r in rows if r[0].startswith(pre)])))
