***************************************************************
*  ORION-CCMS  -  CICS resource definitions (DFHCSDUP)
*  GROUP(ORIONG) : programs, transactions, mapsets, files
*  Usage: //DFHCSD EXEC PGM=DFHCSDUP ; SYSIN = this member
***************************************************************
*
*--------------------------------------------------------------
* PROGRAMS - online (OC*) and subroutines (OU*)
*--------------------------------------------------------------
DEFINE PROGRAM(OCSGNON) GROUP(ORIONG)           -
       DESCRIPTION(SIGN-ON)                     -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCMENU) GROUP(ORIONG)            -
       DESCRIPTION(MAIN MENU)                   -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCADMEN) GROUP(ORIONG)           -
       DESCRIPTION(ADMIN MENU)                  -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCACCTV) GROUP(ORIONG)           -
       DESCRIPTION(ACCOUNT VIEW)                -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCACCTU) GROUP(ORIONG)           -
       DESCRIPTION(ACCOUNT UPDATE)              -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCCARDL) GROUP(ORIONG)           -
       DESCRIPTION(CARD LIST)                   -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCCARDV) GROUP(ORIONG)           -
       DESCRIPTION(CARD VIEW)                   -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCCARDU) GROUP(ORIONG)           -
       DESCRIPTION(CARD UPDATE)                 -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCCUSTV) GROUP(ORIONG)           -
       DESCRIPTION(CUSTOMER VIEW)               -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCCUSTU) GROUP(ORIONG)           -
       DESCRIPTION(CUSTOMER UPDATE)             -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCTRANL) GROUP(ORIONG)           -
       DESCRIPTION(TRANSACTION LIST)            -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCTRANV) GROUP(ORIONG)           -
       DESCRIPTION(TRANSACTION VIEW)            -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCTRANA) GROUP(ORIONG)           -
       DESCRIPTION(TRANSACTION ADD)             -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCBILLP) GROUP(ORIONG)           -
       DESCRIPTION(BILL PAYMENT)                -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCREPT) GROUP(ORIONG)            -
       DESCRIPTION(REPORT REQUEST)              -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCUSRL) GROUP(ORIONG)            -
       DESCRIPTION(USER LIST)                   -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCUSRA) GROUP(ORIONG)            -
       DESCRIPTION(USER ADD)                    -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCUSRU) GROUP(ORIONG)            -
       DESCRIPTION(USER UPDATE)                 -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCUSRD) GROUP(ORIONG)            -
       DESCRIPTION(USER DELETE)                 -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OUDATE) GROUP(ORIONG)            -
       DESCRIPTION(DATE UTILITY SUBROUTINE)     -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OUMSG) GROUP(ORIONG)             -
       DESCRIPTION(MESSAGE TEXT SUBROUTINE)     -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OUABND) GROUP(ORIONG)            -
       DESCRIPTION(ABEND HANDLER SUBROUTINE)    -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
*
*--------------------------------------------------------------
* TRANSACTIONS - OR** mapped to owning program
*--------------------------------------------------------------
DEFINE TRANSACTION(ORSN) GROUP(ORIONG)          -
       PROGRAM(OCSGNON)                         -
       DESCRIPTION(SIGN-ON)                     -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORMN) GROUP(ORIONG)          -
       PROGRAM(OCMENU)                          -
       DESCRIPTION(MAIN MENU)                   -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORAD) GROUP(ORIONG)          -
       PROGRAM(OCADMEN)                         -
       DESCRIPTION(ADMIN MENU)                  -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORAV) GROUP(ORIONG)          -
       PROGRAM(OCACCTV)                         -
       DESCRIPTION(ACCOUNT VIEW)                -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORAU) GROUP(ORIONG)          -
       PROGRAM(OCACCTU)                         -
       DESCRIPTION(ACCOUNT UPDATE)              -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORCL) GROUP(ORIONG)          -
       PROGRAM(OCCARDL)                         -
       DESCRIPTION(CARD LIST)                   -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORCV) GROUP(ORIONG)          -
       PROGRAM(OCCARDV)                         -
       DESCRIPTION(CARD VIEW)                   -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORCU) GROUP(ORIONG)          -
       PROGRAM(OCCARDU)                         -
       DESCRIPTION(CARD UPDATE)                 -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORUV) GROUP(ORIONG)          -
       PROGRAM(OCCUSTV)                         -
       DESCRIPTION(CUSTOMER VIEW)               -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORUU) GROUP(ORIONG)          -
       PROGRAM(OCCUSTU)                         -
       DESCRIPTION(CUSTOMER UPDATE)             -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORTL) GROUP(ORIONG)          -
       PROGRAM(OCTRANL)                         -
       DESCRIPTION(TRANSACTION LIST)            -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORTV) GROUP(ORIONG)          -
       PROGRAM(OCTRANV)                         -
       DESCRIPTION(TRANSACTION VIEW)            -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORTA) GROUP(ORIONG)          -
       PROGRAM(OCTRANA)                         -
       DESCRIPTION(TRANSACTION ADD)             -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORBP) GROUP(ORIONG)          -
       PROGRAM(OCBILLP)                         -
       DESCRIPTION(BILL PAYMENT)                -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORRP) GROUP(ORIONG)          -
       PROGRAM(OCREPT)                          -
       DESCRIPTION(REPORT REQUEST)              -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORUL) GROUP(ORIONG)          -
       PROGRAM(OCUSRL)                          -
       DESCRIPTION(USER LIST)                   -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORUA) GROUP(ORIONG)          -
       PROGRAM(OCUSRA)                          -
       DESCRIPTION(USER ADD)                    -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORUP) GROUP(ORIONG)          -
       PROGRAM(OCUSRU)                          -
       DESCRIPTION(USER UPDATE)                 -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORUD) GROUP(ORIONG)          -
       PROGRAM(OCUSRD)                          -
       DESCRIPTION(USER DELETE)                 -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
*
*--------------------------------------------------------------
* MAPSETS - BMS (M*)
*--------------------------------------------------------------
DEFINE MAPSET(MSGNON) GROUP(ORIONG)             -
       DESCRIPTION(SIGN-ON MAP)                 -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MMENU) GROUP(ORIONG)              -
       DESCRIPTION(MAIN MENU MAP)               -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MADMEN) GROUP(ORIONG)             -
       DESCRIPTION(ADMIN MENU MAP)              -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MACCTV) GROUP(ORIONG)             -
       DESCRIPTION(ACCOUNT VIEW MAP)            -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MACCTU) GROUP(ORIONG)             -
       DESCRIPTION(ACCOUNT UPDATE MAP)          -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MCARDL) GROUP(ORIONG)             -
       DESCRIPTION(CARD LIST MAP)               -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MCARDV) GROUP(ORIONG)             -
       DESCRIPTION(CARD VIEW MAP)               -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MCARDU) GROUP(ORIONG)             -
       DESCRIPTION(CARD UPDATE MAP)             -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MCUSTV) GROUP(ORIONG)             -
       DESCRIPTION(CUSTOMER VIEW MAP)           -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MCUSTU) GROUP(ORIONG)             -
       DESCRIPTION(CUSTOMER UPDATE MAP)         -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MTRANL) GROUP(ORIONG)             -
       DESCRIPTION(TRANSACTION LIST MAP)        -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MTRANV) GROUP(ORIONG)             -
       DESCRIPTION(TRANSACTION VIEW MAP)        -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MTRANA) GROUP(ORIONG)             -
       DESCRIPTION(TRANSACTION ADD MAP)         -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MBILLP) GROUP(ORIONG)             -
       DESCRIPTION(BILL PAYMENT MAP)            -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MREPT) GROUP(ORIONG)              -
       DESCRIPTION(REPORT REQUEST MAP)          -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MUSRL) GROUP(ORIONG)              -
       DESCRIPTION(USER LIST MAP)               -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MUSRA) GROUP(ORIONG)              -
       DESCRIPTION(USER ADD MAP)                -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MUSRU) GROUP(ORIONG)              -
       DESCRIPTION(USER UPDATE MAP)             -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MUSRD) GROUP(ORIONG)              -
       DESCRIPTION(USER DELETE MAP)             -
       RESIDENT(NO) STATUS(ENABLED)
*
*--------------------------------------------------------------
* FILES - VSAM KSDS (DDNAME = file name)
*--------------------------------------------------------------
DEFINE FILE(ACCTFILE) GROUP(ORIONG)             -
       DSNAME(ORION.ACCTFILE)                   -
       RECORDFORMAT(F) RECORDSIZE(300)          -
       KEYLENGTH(11) LSRPOOLID(1)               -
       STRINGS(4) STATUS(ENABLED)               -
       ADD(YES) UPDATE(YES) DELETE(YES)         -
       READ(YES) BROWSE(YES)                    -
       RECOVERY(BACKOUTONLY)
DEFINE FILE(CARDFILE) GROUP(ORIONG)             -
       DSNAME(ORION.CARDFILE)                   -
       RECORDFORMAT(F) RECORDSIZE(150)          -
       KEYLENGTH(16) LSRPOOLID(1)               -
       STRINGS(4) STATUS(ENABLED)               -
       ADD(YES) UPDATE(YES) DELETE(YES)         -
       READ(YES) BROWSE(YES)                    -
       RECOVERY(BACKOUTONLY)
DEFINE FILE(CARPTH1) GROUP(ORIONG)              -
       DSNAME(ORION.CARDFILE.PATH1)             -
       RECORDFORMAT(F) KEYLENGTH(11)            -
       LSRPOOLID(1) STRINGS(4)                  -
       READ(YES) BROWSE(YES)                    -
       ADD(NO) UPDATE(NO) DELETE(NO)            -
       STATUS(ENABLED)
DEFINE FILE(CUSTFILE) GROUP(ORIONG)             -
       DSNAME(ORION.CUSTFILE)                   -
       RECORDFORMAT(F) RECORDSIZE(372)          -
       KEYLENGTH(9) LSRPOOLID(1)                -
       STRINGS(4) STATUS(ENABLED)               -
       ADD(YES) UPDATE(YES) DELETE(YES)         -
       READ(YES) BROWSE(YES)                    -
       RECOVERY(BACKOUTONLY)
DEFINE FILE(XREFFILE) GROUP(ORIONG)             -
       DSNAME(ORION.XREFFILE)                   -
       RECORDFORMAT(F) RECORDSIZE(50)           -
       KEYLENGTH(16) LSRPOOLID(1)               -
       STRINGS(4) STATUS(ENABLED)               -
       ADD(YES) UPDATE(YES) DELETE(YES)         -
       READ(YES) BROWSE(YES)                    -
       RECOVERY(BACKOUTONLY)
DEFINE FILE(XREPTH1) GROUP(ORIONG)              -
       DSNAME(ORION.XREFFILE.PATH1)             -
       RECORDFORMAT(F) KEYLENGTH(11)            -
       LSRPOOLID(1) STRINGS(4)                  -
       READ(YES) BROWSE(YES)                    -
       ADD(NO) UPDATE(NO) DELETE(NO)            -
       STATUS(ENABLED)
DEFINE FILE(XREPTH2) GROUP(ORIONG)              -
       DSNAME(ORION.XREFFILE.PATH2)             -
       RECORDFORMAT(F) KEYLENGTH(9)             -
       LSRPOOLID(1) STRINGS(4)                  -
       READ(YES) BROWSE(YES)                    -
       ADD(NO) UPDATE(NO) DELETE(NO)            -
       STATUS(ENABLED)
DEFINE FILE(TRANFILE) GROUP(ORIONG)             -
       DSNAME(ORION.TRANFILE)                   -
       RECORDFORMAT(F) RECORDSIZE(350)          -
       KEYLENGTH(16) LSRPOOLID(1)               -
       STRINGS(4) STATUS(ENABLED)               -
       ADD(YES) UPDATE(YES) DELETE(YES)         -
       READ(YES) BROWSE(YES)                    -
       RECOVERY(BACKOUTONLY)
DEFINE FILE(TRAPTH1) GROUP(ORIONG)              -
       DSNAME(ORION.TRANFILE.PATH1)             -
       RECORDFORMAT(F) KEYLENGTH(16)            -
       LSRPOOLID(1) STRINGS(4)                  -
       READ(YES) BROWSE(YES)                    -
       ADD(NO) UPDATE(NO) DELETE(NO)            -
       STATUS(ENABLED)
DEFINE FILE(TTYPFILE) GROUP(ORIONG)             -
       DSNAME(ORION.TTYPFILE)                   -
       RECORDFORMAT(F) RECORDSIZE(60)           -
       KEYLENGTH(2) LSRPOOLID(1)                -
       STRINGS(4) STATUS(ENABLED)               -
       ADD(YES) UPDATE(YES) DELETE(YES)         -
       READ(YES) BROWSE(YES)                    -
       RECOVERY(BACKOUTONLY)
DEFINE FILE(TCATFILE) GROUP(ORIONG)             -
       DSNAME(ORION.TCATFILE)                   -
       RECORDFORMAT(F) RECORDSIZE(60)           -
       KEYLENGTH(6) LSRPOOLID(1)                -
       STRINGS(4) STATUS(ENABLED)               -
       ADD(YES) UPDATE(YES) DELETE(YES)         -
       READ(YES) BROWSE(YES)                    -
       RECOVERY(BACKOUTONLY)
DEFINE FILE(DGRPFILE) GROUP(ORIONG)             -
       DSNAME(ORION.DGRPFILE)                   -
       RECORDFORMAT(F) RECORDSIZE(50)           -
       KEYLENGTH(16) LSRPOOLID(1)               -
       STRINGS(4) STATUS(ENABLED)               -
       ADD(YES) UPDATE(YES) DELETE(YES)         -
       READ(YES) BROWSE(YES)                    -
       RECOVERY(BACKOUTONLY)
DEFINE FILE(USRSEC) GROUP(ORIONG)               -
       DSNAME(ORION.USRSEC)                     -
       RECORDFORMAT(F) RECORDSIZE(80)           -
       KEYLENGTH(8) LSRPOOLID(1)                -
       STRINGS(4) STATUS(ENABLED)               -
       ADD(YES) UPDATE(YES) DELETE(YES)         -
       READ(YES) BROWSE(YES)                    -
       RECOVERY(BACKOUTONLY)
DEFINE FILE(BILLFILE) GROUP(ORIONG)             -
       DSNAME(ORION.BILLFILE)                   -
       RECORDFORMAT(F) RECORDSIZE(81)           -
       KEYLENGTH(11) LSRPOOLID(1)               -
       STRINGS(4) STATUS(ENABLED)               -
       ADD(YES) UPDATE(YES) DELETE(YES)         -
       READ(YES) BROWSE(YES)                    -
       RECOVERY(BACKOUTONLY)
DEFINE FILE(STMTFILE) GROUP(ORIONG)             -
       DSNAME(ORION.STMTFILE)                   -
       RECORDFORMAT(F) RECORDSIZE(107)          -
       KEYLENGTH(17) LSRPOOLID(1)               -
       STRINGS(4) STATUS(ENABLED)               -
       ADD(YES) UPDATE(YES) DELETE(YES)         -
       READ(YES) BROWSE(YES)                    -
       RECOVERY(BACKOUTONLY)
DEFINE FILE(CTRLFILE) GROUP(ORIONG)             -
       DSNAME(ORION.CTRLFILE)                   -
       RECORDFORMAT(F) RECORDSIZE(60)           -
       KEYLENGTH(8) LSRPOOLID(1)                -
       STRINGS(4) STATUS(ENABLED)               -
       ADD(YES) UPDATE(YES) DELETE(YES)         -
       READ(YES) BROWSE(YES)                    -
       RECOVERY(BACKOUTONLY)
*
*  End of ORION-CCMS group definitions
