***************************************************************
*  ORION-CCMS  -  CICS resource definitions (DFHCSDUP)
*  GROUP(ORIONG2) : WAVE-2 on-line resources.
*  Adds the new self-service / maintenance OC* programs and
*  the DB2-backed OD* on-line programs (transactions OD01-OD06).
*  VSAM FILE definitions remain in ORION.csd / GROUP(ORIONG);
*  the OD* programs reach DB2 through a bound PLAN (see the
*  RUNDxxxx jobs) associated by a DB2ENTRY / DB2TRAN or RCT.
*  Usage: //DFHCSD EXEC PGM=DFHCSDUP ; SYSIN = this member
*         ADD GROUP(ORIONG2) LIST(ORIONLST) to install.
***************************************************************
*
*--------------------------------------------------------------
* PROGRAMS - new on-line OC* (VSAM) programs
*--------------------------------------------------------------
DEFINE PROGRAM(OCACCTL) GROUP(ORIONG2)          -
       DESCRIPTION(ACCOUNT LIST)                -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCACCTA) GROUP(ORIONG2)          -
       DESCRIPTION(ACCOUNT ADD)                 -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCCUSTL) GROUP(ORIONG2)          -
       DESCRIPTION(CUSTOMER LIST)               -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCCUSTA) GROUP(ORIONG2)          -
       DESCRIPTION(CUSTOMER ADD)                -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCCARDA) GROUP(ORIONG2)          -
       DESCRIPTION(CARD ADD)                    -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCTTYP) GROUP(ORIONG2)           -
       DESCRIPTION(TRAN TYPE MAINT)             -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCTCAT) GROUP(ORIONG2)           -
       DESCRIPTION(TRAN CAT MAINT)              -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCDGRP) GROUP(ORIONG2)           -
       DESCRIPTION(DISCL GROUP MAINT)           -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCSTMV) GROUP(ORIONG2)           -
       DESCRIPTION(STATEMENT VIEW)              -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCTSRCH) GROUP(ORIONG2)          -
       DESCRIPTION(TRAN SEARCH)                 -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(OCPWDCH) GROUP(ORIONG2)          -
       DESCRIPTION(PASSWORD CHANGE)             -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
*
*--------------------------------------------------------------
* PROGRAMS - new DB2-backed on-line OD* programs
*--------------------------------------------------------------
DEFINE PROGRAM(ODACCTV) GROUP(ORIONG2)          -
       DESCRIPTION(DB2 ACCOUNT VIEW)            -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(ODACCTU) GROUP(ORIONG2)          -
       DESCRIPTION(DB2 ACCOUNT UPDATE)          -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(ODCARDV) GROUP(ORIONG2)          -
       DESCRIPTION(DB2 CARD VIEW)               -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(ODCUSTV) GROUP(ORIONG2)          -
       DESCRIPTION(DB2 CUSTOMER VIEW)           -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(ODTRANL) GROUP(ORIONG2)          -
       DESCRIPTION(DB2 TRAN LIST)               -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
DEFINE PROGRAM(ODTRANA) GROUP(ORIONG2)          -
       DESCRIPTION(DB2 TRAN ADD)                -
       LANGUAGE(LE370) RELOAD(NO)               -
       DATALOCATION(ANY) EXECKEY(USER)          -
       CONCURRENCY(QUASIRENT) STATUS(ENABLED)
*
*--------------------------------------------------------------
* TRANSACTIONS - new OC* self-service / maintenance tranids
*--------------------------------------------------------------
DEFINE TRANSACTION(ORLA) GROUP(ORIONG2)         -
       PROGRAM(OCACCTL)                         -
       DESCRIPTION(ACCOUNT LIST)                -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(OROA) GROUP(ORIONG2)         -
       PROGRAM(OCACCTA)                         -
       DESCRIPTION(ACCOUNT ADD)                 -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORLC) GROUP(ORIONG2)         -
       PROGRAM(OCCUSTL)                         -
       DESCRIPTION(CUSTOMER LIST)               -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(OROC) GROUP(ORIONG2)         -
       PROGRAM(OCCUSTA)                         -
       DESCRIPTION(CUSTOMER ADD)                -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(OROD) GROUP(ORIONG2)         -
       PROGRAM(OCCARDA)                         -
       DESCRIPTION(CARD ADD)                    -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORTT) GROUP(ORIONG2)         -
       PROGRAM(OCTTYP)                          -
       DESCRIPTION(TRAN TYPE MAINT)             -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORTC) GROUP(ORIONG2)         -
       PROGRAM(OCTCAT)                          -
       DESCRIPTION(TRAN CAT MAINT)              -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORDG) GROUP(ORIONG2)         -
       PROGRAM(OCDGRP)                          -
       DESCRIPTION(DISCL GROUP MAINT)           -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORSV) GROUP(ORIONG2)         -
       PROGRAM(OCSTMV)                          -
       DESCRIPTION(STATEMENT VIEW)              -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORTS) GROUP(ORIONG2)         -
       PROGRAM(OCTSRCH)                         -
       DESCRIPTION(TRAN SEARCH)                 -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(ORPW) GROUP(ORIONG2)         -
       PROGRAM(OCPWDCH)                         -
       DESCRIPTION(PASSWORD CHANGE)             -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
*
*--------------------------------------------------------------
* TRANSACTIONS - new DB2-backed OD* tranids (OD01-OD06)
*--------------------------------------------------------------
DEFINE TRANSACTION(OD01) GROUP(ORIONG2)         -
       PROGRAM(ODACCTV)                         -
       DESCRIPTION(DB2 ACCOUNT VIEW)            -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(OD02) GROUP(ORIONG2)         -
       PROGRAM(ODACCTU)                         -
       DESCRIPTION(DB2 ACCOUNT UPDATE)          -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(OD03) GROUP(ORIONG2)         -
       PROGRAM(ODCARDV)                         -
       DESCRIPTION(DB2 CARD VIEW)               -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(OD04) GROUP(ORIONG2)         -
       PROGRAM(ODCUSTV)                         -
       DESCRIPTION(DB2 CUSTOMER VIEW)           -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(OD05) GROUP(ORIONG2)         -
       PROGRAM(ODTRANL)                         -
       DESCRIPTION(DB2 TRAN LIST)               -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
DEFINE TRANSACTION(OD06) GROUP(ORIONG2)         -
       PROGRAM(ODTRANA)                         -
       DESCRIPTION(DB2 TRAN ADD)                -
       TASKDATALOC(ANY) TASKDATAKEY(USER)       -
       STATUS(ENABLED)
*
*--------------------------------------------------------------
* MAPSETS - 11 new BMS mapsets (M*)
* (DB2 OD* programs reuse MACCTV/MACCTU/MCARDV/MCUSTV/
*  MTRANL/MTRANA already defined in ORION.csd / GROUP(ORIONG))
*--------------------------------------------------------------
DEFINE MAPSET(MACCTL) GROUP(ORIONG2)            -
       DESCRIPTION(ACCOUNT LIST MAP)            -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MACCTA) GROUP(ORIONG2)            -
       DESCRIPTION(ACCOUNT ADD MAP)             -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MCUSTL) GROUP(ORIONG2)            -
       DESCRIPTION(CUSTOMER LIST MAP)           -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MCUSTA) GROUP(ORIONG2)            -
       DESCRIPTION(CUSTOMER ADD MAP)            -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MCARDA) GROUP(ORIONG2)            -
       DESCRIPTION(CARD ADD MAP)                -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MTTYP) GROUP(ORIONG2)             -
       DESCRIPTION(TRAN TYPE MAP)               -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MTCAT) GROUP(ORIONG2)             -
       DESCRIPTION(TRAN CAT MAP)                -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MDGRP) GROUP(ORIONG2)             -
       DESCRIPTION(DISCL GROUP MAP)             -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MSTMV) GROUP(ORIONG2)             -
       DESCRIPTION(STATEMENT VIEW MAP)          -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MTSRCH) GROUP(ORIONG2)            -
       DESCRIPTION(TRAN SEARCH MAP)             -
       RESIDENT(NO) STATUS(ENABLED)
DEFINE MAPSET(MPWDCH) GROUP(ORIONG2)            -
       DESCRIPTION(PASSWORD CHANGE MAP)         -
       RESIDENT(NO) STATUS(ENABLED)
*
*  End of ORION-CCMS GROUP(ORIONG2) wave-2 definitions
